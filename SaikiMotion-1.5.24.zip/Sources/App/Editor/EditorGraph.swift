// EditorGraph.swift — the graph editor panel (value plot, easing curve, presets).

import UIKit

extension EditorViewController {
        // ---------------------------------------------------------------- graph

        func buildGraph(_ l: Layer) {
            let p: UIStackView = panelList
            text(p, "Graph editor", C.TEXT, 16, true)
            // Kotlin props is a HashMap (unordered); sorted here so the chip row is stable.
            let animated = l.props.filter { $0.value.keys.count >= 2 }.map { $0.key }.sorted()
            if animated.isEmpty {
                text(p, "Add two keyframes to a parameter (tap its name, then the keyframe button) or tap a keyframe in the timeline.")
                return
            }
            if !animated.contains(graphProp) { graphProp = animated[0]; graphKey = 0 }
            p.addArrangedSubview(chipRow(animated.map { Registry.propDef($0)?.label ?? $0 },
                                         animated.firstIndex(of: graphProp) ?? 0) { [weak self] i in
                guard let self = self else { return }
                self.graphProp = animated[i]
                self.graphKey = 0
                self.refreshPanel()
            })
            let tr = l.track(graphProp)
            if tr.keys.count >= 2 {
                graphKey = clamp(graphKey, 0, tr.keys.count - 2)
            }
            let vg = ValueGraphView(frame: .zero)
            vg.track = tr
            vg.t0 = max(0, (tr.keys.first?.t ?? 0) - 0.3)
            vg.t1 = max(vg.t0 + 0.5, (tr.keys.last?.t ?? 1) + 0.3)
            vg.selIdx = graphKey
            vg.onPick = { [weak self] i in
                guard let self = self else { return }
                if tr.keys.count >= 2 { self.graphKey = clamp(i, 0, tr.keys.count - 2) }
                if tr.keys.indices.contains(i) { Editor.time = tr.keys[i].t }
                self.onTimeChanged(); self.refreshPanel()
            }
            put(p, vg, 150)
            text(p, "Segment \(graphKey + 1) of \(max(tr.keys.count - 1, 1)). Tap a dot to choose a keyframe.", C.DIM, 12)
            guard tr.keys.indices.contains(graphKey) else { return }
            let key = tr.keys[graphKey]
            addPlain(p, "Keyframe time (s)", 0, Editor.scene.duration, key.t, 2) { [weak self] v in
                key.t = v
                tr.keys.sort { $0.t < $1.t }
                self?.render()
            }
            if let pd = Registry.propDef(graphProp) {
                addPlain(p, "Keyframe value", pd.min, pd.max, key.v, pd.dec) { [weak self] v in
                    key.v = v
                    self?.render()
                }
            }
            text(p, "Easing curve to the next keyframe", C.GREEN, 13, true)
            if key.ease == .ELASTIC || key.ease == .WAVE {
                addPlain(p, "Strength", 0, 2, key.amp, 2) { [weak self] v in
                    key.amp = v
                    self?.render()
                    self?.panelList.arrangedSubviews.forEach { ($0 as? GraphView)?.setNeedsDisplay() }
                }
            }
            if key.ease == .ELASTIC || key.ease == .WAVE || key.ease == .STEPS {
                addPlain(p, key.ease == .STEPS ? "Steps" : "Count", 1, 12, Float(key.cn), 0) { [weak self] v in
                    key.cn = clamp(Int(v), 1, 12)
                    self?.render()
                    self?.panelList.arrangedSubviews.forEach { ($0 as? GraphView)?.setNeedsDisplay() }
                }
            }
            let g = GraphView(frame: .zero)
            g.key = key
            g.onBegin = { [weak self] in self?.pushUndo() }
            g.onChange = { [weak self] in self?.render() }
            put(p, g, 220)
            if key.isBezier() && !key.rev { text(p, "Drag the green handles. Pull a handle above the top for overshoot.", C.DIM, 12) }
            let acts = hRow()
            acts.distribution = .fillEqually
            acts.spacing = 3
            acts.addArrangedSubview(wrap(pill("Copy curve") { [weak self] in
                self?.curveClip = Key(0, 0, .CUSTOM)
                self?.curveClip?.copyCurveFrom(key)
                Snack.show("Curve copied")
            }, 0, 40, 0, 0, 0, 0))
            acts.addArrangedSubview(wrap(pill("Paste") { [weak self] in
                guard let self = self, let c = self.curveClip else { Snack.show("No curve copied"); return }
                self.pushUndo()
                key.copyCurveFrom(c)
                self.refreshPanel(); self.render()
            }, 0, 40, 0, 0, 0, 0))
            acts.addArrangedSubview(wrap(pill("Reverse") { [weak self] in
                guard let self = self else { return }
                self.pushUndo()
                key.rev = !key.rev
                self.refreshPanel(); self.render()
            }, 0, 40, 0, 0, 0, 0))
            put(p, acts, 40)
            put(p, pill("Apply this curve to every segment") { [weak self] in
                guard let self = self else { return }
                self.pushUndo()
                for k in tr.keys { k.copyCurveFrom(key) }
                self.render()
            }, 42)
            text(p, "Curve presets", C.TEXT, 14, true)
            let hscroll = UIScrollView()
            hscroll.showsHorizontalScrollIndicator = false
            let row = hRow()
            row.spacing = 3
            hscroll.addSubview(row)
            row.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                row.topAnchor.constraint(equalTo: hscroll.contentLayoutGuide.topAnchor),
                row.bottomAnchor.constraint(equalTo: hscroll.contentLayoutGuide.bottomAnchor),
                row.leadingAnchor.constraint(equalTo: hscroll.contentLayoutGuide.leadingAnchor),
                row.trailingAnchor.constraint(equalTo: hscroll.contentLayoutGuide.trailingAnchor),
                row.heightAnchor.constraint(equalTo: hscroll.frameLayoutGuide.heightAnchor)
            ])
            func bz(_ x1: Float, _ y1: Float, _ x2: Float, _ y2: Float) -> Key {
                let k = Key(0, 0, .CUSTOM)
                k.x1 = x1; k.y1 = y1; k.x2 = x2; k.y2 = y2
                return k
            }
            var builtins: [(String, Key)] = [
                ("Linear", Key(0, 0, .LINEAR)),
                ("Ease In", Key(0, 0, .EASE_IN)),
                ("Ease Out", Key(0, 0, .EASE_OUT)),
                ("Smooth", Key(0, 0, .EASE_IN_OUT)),
                ("Back", bz(0.34, 1.56, 0.64, 1)),
                ("Expo", bz(0.7, 0, 0.84, 0)),
                ("Snap", bz(1, 0, 0, 1))
            ]
            let el = Key(0, 0, .ELASTIC); el.cn = 3
            builtins.append(("Elastic", el))
            builtins.append(("Bounce", Key(0, 0, .BOUNCE)))
            let wv = Key(0, 0, .WAVE); wv.cn = 2
            builtins.append(("Wave", wv))
            let st = Key(0, 0, .STEPS); st.cn = 4
            builtins.append(("Steps", st))
            for (nm, k) in builtins {
                let tv = CurveThumb(k, nm)
                tv.onClick = { [weak self] in
                    guard let self = self else { return }
                    self.pushUndo()
                    key.copyCurveFrom(k)
                    self.refreshPanel(); self.render()
                }
                row.addArrangedSubview(wrap(tv, 78, 78, 3, 3, 3, 3))
            }
            put(p, hscroll, 86)
            text(p, "Easing type", C.DIM, 12)
            let types = ["Bezier", "Elastic", "Bounce", "Wave", "Steps"]
            let cur: Int
            switch key.ease {
            case .ELASTIC: cur = 1
            case .BOUNCE: cur = 2
            case .WAVE: cur = 3
            case .STEPS: cur = 4
            default: cur = 0
            }
            p.addArrangedSubview(chipRow(types, cur) { [weak self] i in
                guard let self = self else { return }
                self.pushUndo()
                switch i {
                case 0: if !key.isBezier() { key.preset(.EASE_IN_OUT) }
                case 1: key.ease = .ELASTIC; key.cn = 3; key.amp = 1
                case 2: key.preset(.BOUNCE)
                case 3: key.ease = .WAVE; key.cn = 2; key.amp = 1
                default: key.ease = .STEPS; key.cn = 4
                }
                self.refreshPanel(); self.render()
            })
            let names = ["Linear", "Ease In", "Ease Out", "Ease In-Out", "Bounce", "Back", "Expo", "Snap"]
            p.addArrangedSubview(chipRow(names, -1) { [weak self] i in
                guard let self = self else { return }
                self.pushUndo()
                switch i {
                case 0: key.preset(.LINEAR)
                case 1: key.preset(.EASE_IN)
                case 2: key.preset(.EASE_OUT)
                case 3: key.preset(.EASE_IN_OUT)
                case 4: key.preset(.BOUNCE)
                default:
                    let v: [[Float]] = [[0.34, 1.56, 0.64, 1], [0.7, 0, 0.84, 0], [1, 0, 0, 1]]
                    let q = v[i - 5]
                    key.ease = .CUSTOM
                    key.x1 = q[0]; key.y1 = q[1]; key.x2 = q[2]; key.y2 = q[4 - 1]
                }
                self.refreshPanel(); self.render()
            })
            put(p, pill("Copy this curve to every segment") { [weak self] in
                guard let self = self else { return }
                self.pushUndo()
                for k in tr.keys {
                    k.ease = key.ease
                    k.x1 = key.x1; k.y1 = key.y1; k.x2 = key.x2; k.y2 = key.y2
                }
                self.render()
            }, 42)
            text(p, "Drag the green handles. Pull a handle above the top for overshoot.", C.DIM, 12)
        }
}
