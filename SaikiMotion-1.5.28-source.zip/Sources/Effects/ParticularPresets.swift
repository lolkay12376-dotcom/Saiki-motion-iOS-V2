// ParticularPresets.swift — the built-in particle presets (Effects).
//
// R22 parity with the reference editor's Particular preset chips: Rain,
// Snow, Fire, Sparks, Fireworks, Dust and Bokeh. The reference's internal
// values are in its own unit system (pixel-ish velocities, millisecond
// lives); here they are adapted to this engine's world-unit scale while
// keeping each preset's character: rain = a wide, fast, thin downward
// streak field; snow = slow drift with turbulence; fire = rising additive
// embers that shrink and redden; sparks = a fast, tight, gravity-slammed
// burst; fireworks = one radial burst per cycle; dust = a lazy ambient
// field; bokeh = a few large soft discs.

import Foundation

enum ParticularPresets {

    /// One preset = the particles effect + a table of parameter overrides.
    /// Keys are the layer's track keys (the effect is single-instance).
    /// Colors ride the ColorParam tracks (_r/_g/_b/_a) exactly like a
    /// captured preset would write them.
    private static func make(_ name: String, _ colA: UInt32, _ colB: UInt32,
                             _ v: [String: Float]) -> JObj {
        func colorTracks(_ key: String, _ argb: UInt32) -> JObj {
            func tr(_ x: Float) -> JObj {
                JObj().put("base", Double(x)).put("expr", "").put("exprOn", false)
                      .put("keys", JArr())
            }
            return JObj()
                .put("_r", tr(Float((argb >> 16) & 0xFF) / 255))
                .put("_g", tr(Float((argb >> 8) & 0xFF) / 255))
                .put("_b", tr(Float(argb & 0xFF) / 255))
                .put("_a", tr(Float((argb >> 24) & 0xFF) / 255))
        }
        let tracks = JObj()
        for (k, val) in v {
            tracks.put(k, JObj().put("base", Double(val)).put("expr", "").put("exprOn", false)
                                              .put("keys", JArr()))
        }
        tracks.put("pColA", colorTracks("pColA", colA))
        tracks.put("pColB", colorTracks("pColB", colB))
        let fx = JArr().put(JObj().put("id", "particles").put("tracks", tracks))
        return JObj().put("name", name).put("fx", fx)
    }

    /// Looks up one preset's payload by name (the effect-panel chips).
    static func preset(_ name: String) -> JObj {
        all.first { $0.0 == name }?.1 ?? JObj()
    }

    static let all: [(String, JObj)] = [
        // wide fast downward streaks, slight wind, thin & translucent
        make("Rain", 0xFFC7DBFF, 0xFFA8C4EE, [
            "pRate": 500, "pPreRoll": 3, "pPosY": 0.9,
            "pEmX": 1.6, "pEmY": 0.02,
            "pAngle": 270, "pSpread": 4, "pSpeed": 1.8, "pVelRand": 0.25,
            "pGravity": 0.4, "pWindX": 0.16,
            "pLife": 2.2, "pLifeRand": 0.25,
            "pSize": 0.02, "pSizeRand": 0.5, "pSizeEnd": 0.02,
            "pOpacity": 0.42, "pFadeIn": 0.03, "pFadeOut": 0.08,
            "pFeather": 0.35, "pStretch": 3.2, "pCount": 600,
        ]),
        // slow drifting white flakes with turbulence
        make("Snow", 0xFFFFFFFF, 0xFFE8F0FF, [
            "pRate": 90, "pPreRoll": 4, "pPosY": 0.9,
            "pEmX": 1.8, "pEmY": 0.02,
            "pAngle": 270, "pSpread": 12, "pSpeed": 0.35, "pVelRand": 0.5,
            "pGravity": 0.06, "pWindX": 0.08,
            "pTurb": 0.5, "pTurbSpd": 0.6,
            "pLife": 6, "pLifeRand": 0.4,
            "pSize": 0.03, "pSizeRand": 0.7, "pSizeEnd": 0.028,
            "pOpacity": 0.9, "pFadeIn": 0.06, "pFadeOut": 0.12,
            "pFeather": 0.8, "pCount": 400,
        ]),
        // rising additive embers, shrinking and reddening as they age
        make("Fire", 0xFFFFD24A, 0xFFD1350A, [
            "pRate": 260, "pPreRoll": 1.5, "pPosY": -0.75,
            "pEmX": 0.5, "pEmY": 0.06,
            "pAngle": 90, "pSpread": 22, "pSpeed": 0.8, "pVelRand": 0.5,
            "pGravity": -0.25, "pWindX": 0.05,
            "pTurb": 0.35, "pTurbSpd": 1.6,
            "pLife": 1.6, "pLifeRand": 0.35,
            "pSize": 0.05, "pSizeRand": 0.6, "pSizeEnd": 0.006,
            "pOpacity": 0.85, "pFadeIn": 0.08, "pFadeOut": 0.55,
            "pFeather": 1, "pStretch": 0.8, "pAdd": 1, "pCount": 500,
        ]),
        // fast tight burst slammed down by gravity, tiny bright points
        make("Sparks", 0xFFFFF3C4, 0xFFFF6A05, [
            "pRate": 220, "pPreRoll": 0.8,
            "pEmX": 0.04, "pEmY": 0.04,
            "pAngle": 90, "pSpread": 45, "pSpeed": 1.4, "pVelRand": 0.7,
            "pGravity": 0.9, "pDrag": 0.3,
            "pTurb": 0.12, "pTurbSpd": 2,
            "pLife": 1.2, "pLifeRand": 0.5,
            "pSize": 0.014, "pSizeRand": 0.6, "pSizeEnd": 0.002,
            "pOpacity": 1, "pFadeIn": 0.05, "pFadeOut": 0.5,
            "pFeather": 0.5, "pStretch": 2.6, "pColRand": 0.4,
            "pAdd": 1, "pCount": 500,
        ]),
        // one radial burst per cycle: outwards from a point, drag-heavy
        make("Fireworks", 0xFFFFF2B3, 0xFFFF8F1F, [
            "pRate": 40, "pPreRoll": 1.2,
            "pEmX": 0.02, "pEmY": 0.02,
            "pAngle": 90, "pSpread": 180, "pOutwards": 1,
            "pSpeed": 1.1, "pVelRand": 0.4,
            "pGravity": 0.35, "pDrag": 0.45,
            "pLife": 2.4, "pLifeRand": 0.3,
            "pSize": 0.016, "pSizeRand": 0.5, "pSizeEnd": 0.002,
            "pOpacity": 1, "pFadeIn": 0.05, "pFadeOut": 0.7,
            "pFeather": 0.5, "pStretch": 1.4, "pColRand": 0.5,
            "pAdd": 1, "pCount": 500,
        ]),
        // lazy ambient field that fills the frame and hangs
        make("Dust", 0xFFF7F3E2, 0xFFEFE8CF, [
            "pRate": 120, "pPreRoll": 8,
            "pEmX": 2.2, "pEmY": 1.4,
            "pSpeed": 0.06, "pVelRand": 0.8,
            "pWindX": 0.05, "pDrag": 0.4,
            "pTurb": 0.22, "pTurbSpd": 0.5,
            "pLife": 10, "pLifeRand": 0.5,
            "pSize": 0.014, "pSizeRand": 0.8, "pSizeEnd": 0.014,
            "pOpacity": 0.5, "pFadeIn": 0.3, "pFadeOut": 0.4,
            "pFeather": 1, "pCount": 500,
        ]),
        // a few large, very soft, slowly floating discs
        make("Bokeh", 0xFFEBD9A8, 0xFFFCF4DC, [
            "pRate": 40, "pPreRoll": 12,
            "pEmX": 2.4, "pEmY": 1.5,
            "pSpeed": 0.04, "pVelRand": 0.7,
            "pTurb": 0.1, "pTurbSpd": 0.35,
            "pLife": 14, "pLifeRand": 0.5,
            "pSize": 0.07, "pSizeRand": 0.9, "pSizeEnd": 0.05,
            "pOpacity": 0.55, "pFadeIn": 0.2, "pFadeOut": 0.5,
            "pFeather": 1, "pColRand": 0.25, "pAdd": 1, "pCount": 300,
        ]),
    ]
}
