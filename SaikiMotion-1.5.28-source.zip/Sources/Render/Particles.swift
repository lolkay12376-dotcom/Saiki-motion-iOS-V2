// Particles.swift — the deterministic particle field (Render).
//
// R22 "Particular" parity (feature parity with the reference editors):
// a real emitter — particles are BORN at a staggered rate (particles/sec)
// with a pre-roll so the field is already developed at t = 0, inside an
// emitter box (size X/Y) offset by Position X/Y, fly along a direction cone
// (tilt ± spread in degrees, optionally spinning over their life, optionally
// bursting outwards from the emitter center) with velocity + per-particle
// velocity randomness, gravity, wind and air drag, wander by turbulence, and
// die after `life` seconds (± life random). Each particle has size → end
// size, opacity with fade-in/out windows, feathered edges, motion stretch
// along its velocity and color jitter.
//
// State stays a pure function of (seed, time): every particle's birth phase
// is a hash of its index, so scrubbing and export produce identical results
// with zero state between frames.
//
// Legacy projects: layers that animated the old Direction X/Y tracks keep
// the old vector model so nothing breaks.

import Foundation

struct Particle {
    var x: Float
    var y: Float
    var size: Float
    var life: Float     // 0 fresh → 1 dead
    var alpha: Float    // opacity × fade-in/out window
    var angle: Float    // heading (radians) — motion stretch axis
    var colJit: Float   // 0 → color A..B mix, ± colorRandom jitter
}

enum ParticlesSim {

    /// The full parameter set of the emitter (read from the layer's tracks).
    struct Params {
        var rate: Float = 60            // particles per second
        var maxCount: Int = 400         // hard cap (GPU buffer safety)
        var preRoll: Float = 1          // seconds simulated before t = 0
        var posX: Float = 0             // emitter center offset
        var posY: Float = 0
        var angleDeg: Float = 90        // direction tilt, degrees (90 = up)
        var spreadDeg: Float = 25       // cone half-angle, degrees
        var emX: Float = 0.3            // emitter box width (world units)
        var emY: Float = 0.3            // emitter box height
        var speed: Float = 0.6          // velocity
        var velRandom: Float = 0        // 0...1 per-particle velocity jitter
        var dirSpin: Float = 0          // degrees/sec heading rotation
        var outwards: Float = 0         // 0...1 radial burst from center
        var gravity: Float = 0.3
        var windX: Float = 0
        var windY: Float = 0
        var airDrag: Float = 0          // 0...1 velocity decay per second
        var life: Float = 3
        var lifeRandom: Float = 0       // 0...1
        var seed: Float = 0
        var turb: Float = 0             // turbulence amount
        var turbSpd: Float = 1          // turbulence speed
        var size: Float = 0.04
        var sizeRandom: Float = 0       // 0...1
        var sizeEnd: Float = 0.04       // size at end of life
        var opacity: Float = 1
        var fadeIn: Float = 0.1         // fraction of life spent fading in
        var fadeOut: Float = 0.1        // fraction of life spent fading out
        var motionStretch: Float = 0    // 0 = round, 1+ = elongated
        var colorRandom: Float = 0      // 0...1 per-particle color jitter
        var legacy: Bool = false        // old projects: dirX/dirY + disc birth
        var dirX: Float = 0
        var dirY: Float = -0.4
    }

    static func field(_ p: Params, t: Float) -> [Particle] {
        // legacy model: the old behavior, untouched
        if p.legacy { return legacyField(p, t) }

        let life = max(0.05, p.life)
        let rate = max(1, p.rate)
        // steady-state population: rate × lifetime, capped
        let n = max(1, min(p.maxCount, Int((rate * life).rounded(.up))))
        let cycle = Float(n) / rate          // births repeat over this span
        // pre-roll: the clock starts preRoll seconds before the scene, so at
        // t = 0 the field is already mid-flight (matches the reference's
        // Pre-roll, which keeps new emitters from "warming up" on screen)
        let time = max(0, t) + max(0, p.preRoll)

        var out: [Particle] = []
        out.reserveCapacity(n)

        for i in 0..<n {
            let fi = Float(i)
            let h0 = hash(p.seed * 131.0 + fi)
            let h1 = hash(p.seed * 977.0 + fi * 7.0)
            let h2 = hash(p.seed * 3313.0 + fi * 13.0)
            let h3 = hash(p.seed * 6151.0 + fi * 29.0)
            let h4 = hash(p.seed * 7919.0 + fi * 3.0)
            let h5 = hash(p.seed * 104729.0 + fi * 11.0)

            // staggered, looping births: age wraps over `cycle`, so the field
            // is already full and stays population-stable forever
            let birth = (fi + h0 * 0.98) * (cycle / Float(n))
            var age = (time - birth).truncatingRemainder(dividingBy: cycle)
            if age < 0 { age += cycle }
            let myLife = life * (1 - p.lifeRandom * h5)     // ± life random
            if age > myLife { continue }        // dead this instant
            let lf = age / myLife               // 0 fresh → 1 about to die

            // birth place: emitter box around (posX, posY)
            var bx = p.posX + (h1 - 0.5) * p.emX
            var by = p.posY + (h2 - 0.5) * p.emY

            // heading: tilt + spread cone + spin over life; "outwards" bends
            // the heading away from the emitter center (radial burst)
            var a = (p.angleDeg + (h3 - 0.5) * 2 * p.spreadDeg) * Float.pi / 180
            a += p.dirSpin * age * Float.pi / 180
            let v0 = p.speed * (1 - p.velRandom * h4)   // velocity randomness
            var vx = cos(a) * v0
            var vy = sin(a) * v0
            if p.outwards > 0.001 {
                let ox = bx - p.posX, oy = by - p.posY
                let ol = max(sqrt(ox * ox + oy * oy), 0.0001)
                let k = p.outwards
                vx = vx * (1 - k) + (ox / ol) * v0 * k
                vy = vy * (1 - k) + (oy / ol) * v0 * k
            }

            // integrate with gravity, wind and exponential air drag
            var x = bx, y = by
            if p.airDrag > 0.001 {
                // drag: v(t) = v0 * e^(-drag*t) + terminal (gravity/wind) term
                let d = p.airDrag
                let e = exp(-d * age)
                let s = (1 - e) / d
                x += vx * s + p.windX * (age - s)
                y += vy * s + (p.gravity + p.windY) * (age - s)
                vx = vx * e + p.windX * (1 - e)
                vy = vy * e + (p.gravity + p.windY) * (1 - e)
            } else {
                x += vx * age + p.windX * age * age * 0.5
                y += vy * age + (p.gravity + p.windY) * age * age * 0.5
            }

            // turbulence: two incommensurate sines per particle read as a
            // wandering drift that grows with age (never before birth)
            if p.turb > 0.001 {
                let ph1 = h1 * 41.0, ph2 = h2 * 47.0
                let w = min(age, 3.0) * p.turbSpd
                x += p.turb * (sin(w * 2.1 + ph1) + 0.5 * sin(w * 5.3 + ph2)) * 0.22 * w
                y += p.turb * (cos(w * 1.7 + ph2) + 0.5 * sin(w * 4.1 + ph1)) * 0.22 * w
            }

            // size: per-particle variance, birth→death interpolation
            let sizeVar = 1 - p.sizeRandom * h2
            let sz = max(0.001, (p.size + (p.sizeEnd - p.size) * lf) * sizeVar)

            // opacity: global × fade-in window × fade-out window
            var alpha = p.opacity
            if p.fadeIn > 0.001 { alpha *= clamp01(lf / p.fadeIn) }
            if p.fadeOut > 0.001 { alpha *= clamp01((1 - lf) / p.fadeOut) }

            // heading for motion stretch (velocity after all forces)
            let ang = atan2(vy, vx)
            // color jitter: 0 = on the A→B ramp, ±colorRandom around it
            let cj = clamp01(lf + (h0 - 0.5) * 2 * p.colorRandom)

            out.append(Particle(x: x, y: y, size: sz, life: lf,
                                alpha: alpha, angle: ang, colJit: cj))
        }
        return out
    }

    /// The pre-R21 model, kept bit-for-bit for old projects.
    private static func legacyField(_ p: Params, t: Float) -> [Particle] {
        let life = max(0.05, p.life)
        let rate = max(1, p.rate)
        let n = max(1, min(p.maxCount, Int((rate * life).rounded(.up))))
        let cycle = Float(n) / rate
        let time = max(0, t)

        var out: [Particle] = []
        out.reserveCapacity(n)

        for i in 0..<n {
            let fi = Float(i)
            let h0 = hash(p.seed * 131.0 + fi)
            let h1 = hash(p.seed * 977.0 + fi * 7.0)
            let h2 = hash(p.seed * 3313.0 + fi * 13.0)
            let h3 = hash(p.seed * 6151.0 + fi * 29.0)
            let h4 = hash(p.seed * 7919.0 + fi * 3.0)

            let birth = (fi + h0 * 0.98) * (cycle / Float(n))
            var age = (time - birth).truncatingRemainder(dividingBy: cycle)
            if age < 0 { age += cycle }
            if age > life { continue }
            let lf = age / life

            let ang = h1 * 2 * Float.pi
            let rad = sqrt(h2) * p.emX * 0.5
            let bx = cos(ang) * rad
            let by = sin(ang) * rad
            let vx = (p.dirX + (h3 - 0.5) * p.emX * 0.6) * p.speed
            let vy = (p.dirY + (h4 - 0.5) * p.emX * 0.6) * p.speed

            var x = bx + vx * age
            var y = by + vy * age + p.gravity * age * age * 0.5
            if p.turb > 0.001 {
                let ph1 = h1 * 41.0, ph2 = h2 * 47.0
                let w = min(age, 3.0) * p.turbSpd
                x += p.turb * (sin(w * 2.1 + ph1) + 0.5 * sin(w * 5.3 + ph2)) * 0.22 * w
                y += p.turb * (cos(w * 1.7 + ph2) + 0.5 * sin(w * 4.1 + ph1)) * 0.22 * w
            }
            let sizeVar = 0.5 + h2 * 0.9
            out.append(Particle(x: x, y: y, size: sizeVar * (0.8 + 0.4 * lf), life: lf,
                                alpha: 1, angle: 0, colJit: lf))
        }
        return out
    }

    private static func clamp01(_ x: Float) -> Float { x < 0 ? 0 : (x > 1 ? 1 : x) }

    private static func hash(_ x: Float) -> Float {
        var n = UInt32(truncatingIfNeeded: Int64(x * 8192.0))
        n = n &* 747796405 &+ 2891336453
        n = ((n >> ((n >> 28) + 4)) ^ n) &* 277803737
        n = (n >> 22) ^ n
        return Float(n % 100000) / 100000
    }
}
