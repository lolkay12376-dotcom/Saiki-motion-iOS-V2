// EffectsGalleryViewController.swift — the effects browser (Community tab).
//
// Grid of Registry entries rendered through EffectThumbs. Browse mode shows
// before/after cards (the same ones the editor's Effects panel uses) and an
// info page per effect; pick mode hands a def back to the caller.

import UIKit

final class EffectsGalleryViewController: UIViewController {

    enum Mode { case pick, browse }

    private let mode: Mode
    var onPick: ((EffectDef) -> Void)?

    private var defs: [EffectDef] = []
    private var searchQuery = ""
    private var collectionView: UICollectionView!

    init(mode: Mode) {
        self.mode = mode
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("EffectsGalleryViewController is built in code")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = argbToUIColor(C.BG)
        title = L10n.tr("Example effects")

        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width: 116, height: 168)
        layout.sectionInset = UIEdgeInsets(top: 12, left: 12, bottom: 12, right: 12)
        layout.minimumInteritemSpacing = 10
        layout.minimumLineSpacing = 14

        collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.backgroundColor = .clear
        collectionView.register(EffectCell.self, forCellWithReuseIdentifier: "effect")
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(collectionView)

        NSLayoutConstraint.activate([
            collectionView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
        ])

        reload()
        EffectThumbs.generate(self, nil) { [weak self] in
            self?.collectionView.reloadData()
        }
    }

    private func reload() {
        Registry.initialize()
        let q = searchQuery.trimmingCharacters(in: .whitespaces).lowercased()
        let interesting = Registry.order.filter { d in
            // hide the internal single-instance helpers from the gallery
            d.kind != 1
        }
        defs = q.isEmpty ? interesting : interesting.filter {
            $0.name.lowercased().contains(q) || d($0).lowercased().contains(q)
        }
    }

    private func d(_ def: EffectDef) -> String { def.desc }

    private func pick(_ def: EffectDef) {
        if mode == .pick {
            onPick?(def)
            if navigationController != nil {
                navigationController?.popViewController(animated: true)
            } else {
                dismiss(animated: true)
            }
        } else {
            navigationController?.pushViewController(EffectInfoViewController(def: def), animated: true)
        }
    }
}

extension EffectsGalleryViewController: UICollectionViewDataSource {
    func collectionView(_ cv: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        defs.count
    }

    func collectionView(_ cv: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = cv.dequeueReusableCell(withReuseIdentifier: "effect", for: indexPath) as! EffectCell
        if let def = defs[safe: indexPath.item] {
            cell.show(def: def)
        }
        return cell
    }
}

extension EffectsGalleryViewController: UICollectionViewDelegate {
    func collectionView(_ cv: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        cv.deselectItem(at: indexPath, animated: true)
        if let def = defs[safe: indexPath.item] { pick(def) }
    }
}

/// Card cell: before/after thumbnail + name + category.
final class EffectCell: UICollectionViewCell {

    private let card = EffectCard("", "")
    private var defId: String?

    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.layer.cornerRadius = 12
        contentView.clipsToBounds = true

        card.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(card)
        NSLayoutConstraint.activate([
            card.topAnchor.constraint(equalTo: contentView.topAnchor),
            card.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
            card.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            card.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
        ])
    }

    required init?(coder: NSCoder) {
        fatalError("EffectCell is built in code")
    }

    func show(def: EffectDef) {
        defId = def.id
        card.name = def.name
        card.category = def.category
        card.anim = def.previewAnim
        card.thumbId = def.id
        card.origId = EffectThumbs.origKey(def.id)
        card.before = EffectThumbs.cached(EffectThumbs.origKey(def.id)) ?? EffectThumbs.raw(def.id)
        card.after = EffectThumbs.cached(def.id)
        card.setNeedsDisplay()
    }
}

/// Read-only viewer for one effect definition.
final class EffectInfoViewController: UIViewController {

    private let def: EffectDef

    init(def: EffectDef) {
        self.def = def
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("EffectInfoViewController is built in code")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = argbToUIColor(C.BG)
        title = def.name

        let scroll = CapScroll()
        scroll.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scroll)

        let col = UIStackView()
        col.axis = .vertical
        col.spacing = 8
        col.translatesAutoresizingMaskIntoConstraints = false
        scroll.addSubview(col)
        NSLayoutConstraint.activate([
            col.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor, constant: 12),
            col.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor, constant: -12),
            col.leadingAnchor.constraint(equalTo: scroll.contentLayoutGuide.leadingAnchor, constant: 16),
            col.trailingAnchor.constraint(equalTo: scroll.contentLayoutGuide.trailingAnchor, constant: -16),
            col.widthAnchor.constraint(equalTo: scroll.frameLayoutGuide.widthAnchor, constant: -32),
            scroll.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scroll.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            scroll.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scroll.trailingAnchor.constraint(equalTo: view.trailingAnchor),
        ])

        let card = EffectCard(def.name, def.category)
        card.anim = def.previewAnim
        card.thumbId = def.id
        card.origId = EffectThumbs.origKey(def.id)
        card.before = EffectThumbs.cached(EffectThumbs.origKey(def.id)) ?? EffectThumbs.raw(def.id)
        card.after = EffectThumbs.cached(def.id)
        card.heightAnchor.constraint(equalToConstant: 240).isActive = true
        col.addArrangedSubview(card)

        var text = "\(def.name) — \(def.category)\n\n\(def.desc)\n\nParameters:\n"
        if def.props.isEmpty {
            text += "  none\n"
        }
        for p in def.props {
            if let opts = p.options {
                text += "  • \(p.label) — \(opts.joined(separator: " / "))\n"
            } else {
                text += String(format: "  • %@ — %g … %g (default %g)\n", p.label, p.min, p.max, p.def)
            }
        }
        if !def.colors.isEmpty {
            text += "\nColors:\n"
            for cp in def.colors {
                text += String(format: "  • %@ — #%08X\n", cp.label, UInt32(bitPattern: cp.def))
            }
        }
        if !def.inputs.isEmpty {
            text += "\nLayer inputs: " + def.inputs.joined(separator: ", ") + "\n"
        }
        if !def.builtin {
            text += "\nCustom effect"
        }
        if let err = Registry.errors[def.id] {
            text += "\n\nShader error:\n" + err
        }

        let tv = UILabel()
        tv.text = text
        tv.textColor = argbToUIColor(C.TEXT)
        tv.font = sysFont(13)
        tv.numberOfLines = 0
        col.addArrangedSubview(tv)
    }
}

/// UITableViewCell with a working detail label under registration.
/// (Dequeued cells come back in .default style, where detailTextLabel is
/// nil — forcing .subtitle here revives it.)
final class SubtitleCell: UITableViewCell {
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: .subtitle, reuseIdentifier: reuseIdentifier)
    }

    required init?(coder: NSCoder) {
        fatalError("SubtitleCell is built in code")
    }
}
