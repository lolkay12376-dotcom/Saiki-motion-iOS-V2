// Anim.swift — keyframes, tracks and expressions (Model).
//
// Kotlin Core/Anim.kt: every animatable value on a layer is a Track (a base
// value + a keyframe list). Keys interpolate with named eases — bezier with
// drag handles, plus elastic/bounce/wave/steps formulas — and a Track can
// carry an expression that post-processes the keyframed value each frame.
//
// Coordinate conventions carried over unchanged:
//   * key time is seconds on the scene timeline;
//   * x1/y1/x2/y2 are normalized bezier handle positions (0..1 box);
//   * `rev` mirrors the curve.

import Foundation

// MARK: - Ease

enum Ease: Int {
    case LINEAR = 0
    case EASE_IN = 1
    case EASE_OUT = 2
    case EASE_IN_OUT = 3
    case CUSTOM = 4
    case BOUNCE = 5
    case ELASTIC = 6
    case WAVE = 7
    case STEPS = 8
    case HOLD = 9          // R22: reference-parity — value holds until the next key

    var label: String {
        switch self {
        case .LINEAR: return "Linear"
        case .EASE_IN: return "Ease In"
        case .EASE_OUT: return "Ease Out"
        case .EASE_IN_OUT: return "Ease In-Out"
        case .CUSTOM: return "Custom"
        case .BOUNCE: return "Bounce"
        case .ELASTIC: return "Elastic"
        case .WAVE: return "Wave"
        case .STEPS: return "Steps"
        case .HOLD: return "Hold"
        }
    }
}

// MARK: - Key

final class Key {
    var t: Float
    var v: Float
    var ease: Ease
    // cubic handles (normalized)
    var x1: Float = 0.42; var y1: Float = 0.0
    var x2: Float = 0.58; var y2: Float = 1.0
    // elastic / wave / steps tuning
    var amp: Float = 1
    var cn: Int = 3
    var rev = false

    init(_ t: Float, _ v: Float, _ ease: Ease) {
        self.t = t
        self.v = v
        self.ease = ease
    }

    func isBezier() -> Bool {
        ease == .CUSTOM || ease == .LINEAR || ease == .EASE_IN || ease == .EASE_OUT || ease == .EASE_IN_OUT
    }

    /// Applies a named ease's canonical handle positions.
    func preset(_ e: Ease) {
        ease = e
        switch e {
        case .LINEAR: x1 = 0; y1 = 0; x2 = 1; y2 = 1
        case .EASE_IN: x1 = 0.42; y1 = 0; x2 = 1; y2 = 1
        case .EASE_OUT: x1 = 0; y1 = 0; x2 = 0.58; y2 = 1
        case .EASE_IN_OUT: x1 = 0.42; y1 = 0; x2 = 0.58; y2 = 1
        default: break
        }
    }

    /// Copies only the curve (ease + handles + tuning) from another key.
    func copyCurveFrom(_ o: Key) {
        ease = o.ease
        x1 = o.x1; y1 = o.y1; x2 = o.x2; y2 = o.y2
        amp = o.amp; cn = o.cn; rev = o.rev
    }

    func copy() -> Key {
        let k = Key(t, v, ease)
        k.copyCurveFrom(self)
        return k
    }

    // -- serialization --

    func toJson() -> JObj {
        let o = JObj().put("t", Double(t)).put("v", Double(v)).put("ease", ease.rawValue)
        o.put("x1", Double(x1)).put("y1", Double(y1)).put("x2", Double(x2)).put("y2", Double(y2))
        o.put("amp", Double(amp)).put("cn", Int64(cn)).put("rev", rev)
        return o
    }

    static func fromJson(_ o: JObj) -> Key {
        let k = Key(o.optFloat("t"), o.optFloat("v"), Ease(rawValue: o.optInt("ease")) ?? .LINEAR)
        k.x1 = o.optFloat("x1", 0.42); k.y1 = o.optFloat("y1", 0)
        k.x2 = o.optFloat("x2", 0.58); k.y2 = o.optFloat("y2", 1)
        k.amp = o.optFloat("amp", 1); k.cn = o.optInt("cn", 3)
        k.rev = o.optBool("rev")
        return k
    }
}

// MARK: - Track

final class Track {
    var base: Float
    var keys: [Key] = []
    var exprSrc = ""
    var exprOn = false

    init(_ base: Float = 0) {
        self.base = base
    }

    /// The evaluated value at `t`: keyframe interpolation, else the base.
    func eval(_ t: Float) -> Float {
        if keys.isEmpty { return base }
        if keys.count == 1 { return keys[0].v }
        if t <= keys[0].t { return keys[0].v }
        if t >= keys[keys.count - 1].t { return keys[keys.count - 1].v }
        for i in 0..<(keys.count - 1) {
            let a = keys[i], b = keys[i + 1]
            if t >= a.t && t <= b.t {
                let span = b.t - a.t
                if span <= 0 { return b.v }
                var u = (t - a.t) / span
                var va = a.v, vb = b.v
                if a.rev { u = 1 - u; va = b.v; vb = a.v }
                if a.ease == .HOLD { return va }   // hold: flat until the next key
                return va + (vb - va) * Track.easeAt(a, u)
            }
        }
        return base
    }

    /// Sets the value at `t` — keyframed when the track has keys (or when the
    /// editor's auto-key is on), otherwise it moves the base value.
    func set(_ t: Float, _ v: Float, _ autoKey: Bool) {
        if keys.isEmpty {
            if autoKey {
                keys.append(Key(t, v, .EASE_IN_OUT))
            } else {
                base = v
            }
            return
        }
        // snap onto an existing key when close
        if let i = keys.firstIndex(where: { abs($0.t - t) < 0.02 }) {
            keys[i].v = v
            return
        }
        if autoKey {
            keys.append(Key(t, v, .EASE_IN_OUT))
            keys.sort { $0.t < $1.t }
        } else {
            // move the whole curve by the delta so dragging stays intuitive
            let cur = eval(t)
            let d = v - cur
            base += d
            for k in keys { k.v += d }
        }
    }

    /// Adds or removes a key at the current evaluated value (the diamond).
    func toggleKey(_ t: Float) {
        if let i = keys.firstIndex(where: { abs($0.t - t) < 0.02 }) {
            keys.remove(at: i)
        } else {
            keys.append(Key(t, eval(t), .EASE_IN_OUT))
            keys.sort { $0.t < $1.t }
        }
    }

    func keyAt(_ t: Float) -> Key? {
        keys.first { abs($0.t - t) < 0.04 }
    }

    // -- expressions --

    /// Compiles + stores an expression. Returns false (and keeps the old one)
    /// when the source does not parse.
    @discardableResult
    func setExpr(_ src: String) -> Bool {
        if src.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            exprSrc = ""
            return true
        }
        guard Expr.compile(src) != nil else { return false }
        exprSrc = src
        return true
    }

    func exprActive() -> Bool {
        exprOn && !exprSrc.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    /// Value with the expression applied. `time` is the scene time so
    /// `t = time` in the expression language. The env carries the comp's
    /// shape and this track's keyframes (numKeys / key(n) / loopOut).
    func evalExpr(_ t: Float, _ time: Float, _ markers: [String: Float],
                  fps: Float = 30, compW: Float = 1920, compH: Float = 1080,
                  compDur: Float = 10) -> Float {
        let v = eval(t)
        guard exprActive() else { return v }
        guard let fn = Expr.compile(exprSrc) else { return v }
        let env = ExprEnv(fps: fps, keyTimes: keys.map { $0.t },
                          keyVals: keys.map { $0.v }, markers: markers,
                          compW: compW, compH: compH, compDur: compDur)
        return fn(v, time, env)
    }

    func copyExprFrom(_ o: Track) {
        exprSrc = o.exprSrc
        exprOn = o.exprOn
    }

    // -- serialization --

    func toJson() -> JObj {
        let o = JObj().put("base", Double(base)).put("expr", exprSrc).put("exprOn", exprOn)
        let arr = JArr()
        for k in keys { arr.put(k.toJson()) }
        o.put("keys", arr)
        return o
    }

    func load(_ o: JObj) {
        base = o.optFloat("base")
        exprSrc = o.optString("expr")
        exprOn = o.optBool("exprOn")
        keys = []
        if let a = o.optJSONArray("keys") {
            for i in 0..<a.count {
                if let ko = a.optJSONObject(i) { keys.append(Key.fromJson(ko)) }
            }
        }
        keys.sort { $0.t < $1.t }
    }

    // MARK: easing math

    /// u in 0..1 → eased 0..1 for the segment leaving key `a`.
    static func easeAt(_ a: Key, _ u: Float) -> Float {
        switch a.ease {
        case .LINEAR: return u
        case .EASE_IN, .EASE_OUT, .EASE_IN_OUT, .CUSTOM:
            return bezier(u, a.x1, a.y1, a.x2, a.y2)
        case .BOUNCE: return bounceOut(u)
        case .ELASTIC: return elasticOut(u, a.amp, a.cn)
        case .WAVE: return wave(u, a.amp, a.cn)
        case .STEPS: return stepped(u, a.cn)
        case .HOLD: return 0            // handled by Track.eval (flat)
        }
    }

    /// Cubic bezier with Newton-Raphson solve (CSS timing function).
    static func bezier(_ u: Float, _ x1: Float, _ y1: Float, _ x2: Float, _ y2: Float) -> Float {
        if u <= 0 { return 0 }
        if u >= 1 { return 1 }
        func cx(_ t: Float) -> Float { ((1 - 3 * x2 + 3 * x1) * t + (3 * x2 - 6 * x1)) * t * t + 3 * x1 * t }
        func cy(_ t: Float) -> Float { ((1 - 3 * y2 + 3 * y1) * t + (3 * y2 - 6 * y1)) * t * t + 3 * y1 * t }
        var t = u
        for _ in 0..<8 {
            let x = cx(t) - u
            if abs(x) < 1e-5 { break }
            let d = (3 * (1 - 3 * x2 + 3 * x1) * t + 2 * (3 * x2 - 6 * x1)) * t + 3 * x1
            if abs(d) < 1e-6 { break }
            t -= x / d
        }
        t = clamp(t, 0, 1)
        return cy(t)
    }

    static func bounceOut(_ u: Float) -> Float {
        let n1: Float = 7.5625, d1: Float = 2.75
        if u < 1 / d1 { return n1 * u * u }
        if u < 2 / d1 { let x = u - 1.5 / d1; return n1 * x * x + 0.75 }
        if u < 2.5 / d1 { let x = u - 2.25 / d1; return n1 * x * x + 0.9375 }
        let x = u - 2.625 / d1
        return n1 * x * x + 0.984375
    }

    static func elasticOut(_ u: Float, _ amp: Float, _ n: Int) -> Float {
        if u <= 0 { return 0 }
        if u >= 1 { return 1 }
        let c = max(Float(n), 1)
        let p = 0.3 * amp
        let s = p / 4
        return pow(2, -10 * u) * sin((u - s) * (2 * Float.pi) / p) * amp + 1
    }

    static func wave(_ u: Float, _ amp: Float, _ n: Int) -> Float {
        let c = max(Float(n), 1)
        return u + sin(u * c * 2 * Float.pi) * 0.5 * amp / c
    }

    static func stepped(_ u: Float, _ n: Int) -> Float {
        let c = max(n, 1)
        return floor(u * Float(c)) / Float(c)
    }
}

// MARK: - Expressions
//
// A tiny recursive-descent expression language (the Kotlin app shipped the
// same surface): t/time, v/value, frame, fps, pi, thisComp.width/height/
// duration/frameRate, numbers, + - * / % ^, comparisons, if(c,a,b),
// step(a,b), wiggle(freq,amp), shake, noise, sin, cos, abs, min, max,
// clamp, pow, sqrt, linear/ease/easeIn/easeOut(t,tMin,tMax,v1,v2),
// degreesToRadians, radiansToDegrees, floor, round, mix, marker.key("name"),
// seedRandom(seed[, timeless]), random(), rand(lo, hi), gaussRandom(),
// timeToFrames, framesToTime, posterizeTime, key(n).time, numKeys,
// loopOut/loopIn([mode]) with cycle / pingpong / offset.
// random()/rand() are deterministic: quantized to 1/60s frames and hashed
// with the seed set by seedRandom, so playback and export match exactly.

/// Per-evaluation environment: the comp's shape + this track's keyframes.
struct ExprEnv {
    var fps: Float = 30
    var keyTimes: [Float] = []
    var keyVals: [Float] = []
    var markers: [String: Float] = [:]
    var compW: Float = 1920
    var compH: Float = 1080
    var compDur: Float = 10
}

enum Expr {
    struct Ctx {
        var t: Float = 0
        var v: Float = 0
        var env: ExprEnv = ExprEnv()
        var seed: Int32 = 0
        var seedSet = false
        var timeless = false
    }

    indirect enum Node {
        case num(Float)
        case tVar
        case vVar
        case piC
        case envVar(String)          // frame, fps, numKeys, index, comp members
        case marker(String)
        case neg(Node)
        case bin(String, Node, Node)
        case cmp(String, Node, Node)
        case call(String, [Node])
        case seq(Node, Node)     // "a; b" — run both, return b (side effects: seedRandom)
    }

    // -- parser --

    static func compile(_ src: String) -> ((Float, Float, ExprEnv) -> Float)? {
        let toks = tokenize(src)
        guard !toks.isEmpty else { return nil }
        var pos = 0
        func peek() -> String? { pos < toks.count ? toks[pos] : nil }
        func next() -> String? { defer { if pos < toks.count { pos += 1 } }; return peek() }
        func expect(_ s: String) -> Bool { next() == s }

        func parseExpr() -> Node? {
            guard var left = parseCmp() else { return nil }
            while let op = peek(), op == "&&" || op == "||" {
                _ = next()
                guard let right = parseCmp() else { return nil }
                left = .bin(op, left, right)
            }
            return left
        }
        func parseCmp() -> Node? {
            guard var left = parseAdd() else { return nil }
            while let op = peek(), ["<", ">", "<=", ">=", "==", "!="].contains(op) {
                _ = next()
                guard let right = parseAdd() else { return nil }
                left = .cmp(op, left, right)
            }
            return left
        }
        func parseAdd() -> Node? {
            guard var left = parseMul() else { return nil }
            while let op = peek(), op == "+" || op == "-" {
                _ = next()
                guard let right = parseMul() else { return nil }
                left = .bin(op, left, right)
            }
            return left
        }
        func parseMul() -> Node? {
            guard var left = parsePow() else { return nil }
            while let op = peek(), op == "*" || op == "/" || op == "%" {
                _ = next()
                guard let right = parsePow() else { return nil }
                left = .bin(op, left, right)
            }
            return left
        }
        func parsePow() -> Node? {
            guard let left = parseUnary() else { return nil }
            if let op = peek(), op == "^" {
                _ = next()
                guard let right = parsePow() else { return nil }
                return .bin(op, left, right)
            }
            return left
        }
        func parseUnary() -> Node? {
            if let op = peek(), op == "-" {
                _ = next()
                guard let n = parseUnary() else { return nil }
                return .neg(n)
            }
            if let op = peek(), op == "+" {
                _ = next()
                return parseUnary()
            }
            return parseAtom()
        }
        func parseAtom() -> Node? {
            guard let tok = next() else { return nil }
            if let d = Float(tok) { return .num(d) }
            if tok == "t" || tok == "time" { return .tVar }
            if tok == "v" || tok == "value" { return .vVar }
            if tok == "pi" { return .piC }
            if tok == "(" {
                let inner = parseExpr()
                guard expect(")") else { return nil }
                return inner
            }
            // identifier: function call or marker.key
            if tok == "marker" {
                if peek() == "." {
                    _ = next()
                    if next() == "key", expect("("), let nameTok = next(), expect(")") {
                        var raw = nameTok
                        if raw.hasPrefix("s:") { raw = String(raw.dropFirst(2)) }
                        raw = String(raw.dropFirst(raw.hasPrefix("\"") ? 1 : 0))
                        if raw.hasSuffix("\"") { raw = String(raw.dropLast()) }
                        return .marker(raw)
                    }
                    return nil
                }
                return nil
            }
            // thisComp.width / .height / .duration / .frameRate / .numLayers
            if tok == "thisComp" || tok == "comp" {
                if peek() == "." {
                    _ = next()
                    if let member = next() {
                        switch member {
                        case "width": return .envVar("compW")
                        case "height": return .envVar("compH")
                        case "duration": return .envVar("compDur")
                        case "frameRate": return .envVar("fps")
                        case "numLayers": return .num(1)
                        default: return nil
                        }
                    }
                }
                return .envVar("compDur")
            }
            // bare env variables
            if tok == "frame" { return .envVar("frame") }
            if tok == "fps" { return .envVar("fps") }
            if tok == "numKeys" { return .envVar("numKeys") }
            if tok == "index" { return .envVar("index") }
            // string literal → loop-mode number (loopOut("cycle") reads as 0)
            if tok.hasPrefix("s:") {
                switch String(tok.dropFirst(2)) {
                case "cycle": return .num(0)
                case "pingpong": return .num(1)
                case "offset", "continue": return .num(2)
                default: return .num(0)
                }
            }
            if peek() == "(" {
                _ = next()
                var args: [Node] = []
                if peek() != ")" {
                    while true {
                        guard let a = parseExpr() else { return nil }
                        args.append(a)
                        if peek() == "," { _ = next(); continue }
                        break
                    }
                }
                guard expect(")") else { return nil }
                // shake = the reference's wiggle variant
                if tok == "shake" { return .call("wiggle", args) }
                return .call(tok, args)
            }
            return nil
        }

        guard var ast = parseExpr() else { return nil }
        // statement sequences: "seedRandom(5); v + rand(-1, 1)" — semicolons
        // (and newlines, which the tokenizer already skips) chain
        // expressions; earlier ones run for side effects, the last is the value
        while pos < toks.count, toks[pos] == ";" {
            _ = next()
            if pos >= toks.count { break }          // trailing ";" is fine
            guard let nxt = parseExpr() else { return nil }
            ast = .seq(ast, nxt)
        }
        guard pos >= toks.count else { return nil }

        // closure over the compiled AST
        let node = ast
        return { t, v, env in
            var c = Ctx(t: t, v: v, env: env)
            return eval(node, &c)
        }
    }

    private static func tokenize(_ s: String) -> [String] {
        var out: [String] = []
        var i = s.startIndex
        let end = s.endIndex
        while i < end {
            let c = s[i]
            if c.isWhitespace { i = s.index(after: i); continue }
            if c.isNumber || c == "." {
                var j = i
                while j < end, s[j].isNumber || s[j] == "." { j = s.index(after: j) }
                out.append(String(s[i..<j]))
                i = j
            } else if c.isLetter || c == "_" {
                var j = i
                while j < end, s[j].isLetter || s[j].isNumber || s[j] == "_" { j = s.index(after: j) }
                out.append(String(s[i..<j]))
                i = j
            } else if c == "\"" {
                var j = s.index(after: i)
                while j < end, s[j] != "\"" { j = s.index(after: j) }
                out.append("s:" + String(s[s.index(after: i)..<j]))
                i = (j < end) ? s.index(after: j) : j
            } else {
                let two = s.index(after: i) < end ? String(s[i...s.index(after: i)]) : ""
                if ["<=", ">=", "==", "!=", "&&", "||"].contains(two) {
                    out.append(two)
                    i = s.index(after: s.index(after: i))
                } else {
                    out.append(String(c))
                    i = s.index(after: i)
                }
            }
        }
        return out
    }

    private static func eval(_ n: Node, _ ctx: inout Ctx) -> Float {
        switch n {
        case .num(let d): return d
        case .tVar: return ctx.t
        case .vVar: return ctx.v
        case .piC: return Float.pi
        case .envVar(let name):
            switch name {
            case "frame": return ctx.t * ctx.env.fps
            case "fps", "frameRate": return ctx.env.fps
            case "numKeys": return Float(ctx.env.keyTimes.count)
            case "index": return 1
            case "compW", "width": return ctx.env.compW
            case "compH", "height": return ctx.env.compH
            case "compDur", "duration": return ctx.env.compDur
            default: return 0
            }
        case .marker(let name): return ctx.env.markers[name] ?? 0
        case .seq(let a, let b):
            _ = eval(a, &ctx)
            return eval(b, &ctx)
        case .neg(let a): return -eval(a, &ctx)
        case .bin(let op, let a, let b):
            let x = eval(a, &ctx), y = eval(b, &ctx)
            switch op {
            case "+": return x + y
            case "-": return x - y
            case "*": return x * y
            case "/": return y == 0 ? 0 : x / y
            case "%": return y == 0 ? 0 : x.truncatingRemainder(dividingBy: y)
            case "^": return pow(x, y)
            case "&&": return (x != 0 && y != 0) ? 1 : 0
            case "||": return (x != 0 || y != 0) ? 1 : 0
            default: return 0
            }
        case .cmp(let op, let a, let b):
            let x = eval(a, &ctx), y = eval(b, &ctx)
            switch op {
            case "<": return x < y ? 1 : 0
            case ">": return x > y ? 1 : 0
            case "<=": return x <= y ? 1 : 0
            case ">=": return x >= y ? 1 : 0
            case "==": return x == y ? 1 : 0
            default: return x != y ? 1 : 0
            }
        case .call(let name, let args):
            // left-to-right, threading the context: seedRandom() must affect
            // the random()/rand() calls that come after it in the same line
            var a: [Float] = []
            a.reserveCapacity(args.count)
            for arg in args { a.append(eval(arg, &ctx)) }
            switch name {
            case "sin": return a.count > 0 ? sin(a[0]) : 0
            case "cos": return a.count > 0 ? cos(a[0]) : 0
            case "abs": return a.count > 0 ? abs(a[0]) : 0
            case "min": return a.count > 1 ? min(a[0], a[1]) : (a.first ?? 0)
            case "max": return a.count > 1 ? max(a[0], a[1]) : (a.first ?? 0)
            case "clamp":
                if a.count > 2 { return clamp(a[0], a[1], a[2]) }
                return a.first ?? 0
            case "pow": return a.count > 1 ? pow(a[0], a[1]) : 0
            case "sqrt": return a.count > 0 ? sqrt(max(0, a[0])) : 0
            case "floor": return a.count > 0 ? floor(a[0]) : 0
            case "round": return a.count > 0 ? a[0].rounded() : 0
            case "ceil": return a.count > 0 ? ceil(a[0]) : 0
            case "mix":
                if a.count > 2 { return a[0] + (a[1] - a[0]) * a[2] }
                return a.first ?? 0
            case "if":
                if a.count > 2 { return a[0] != 0 ? a[1] : a[2] }
                return a.first ?? 0
            case "step":
                if a.count > 1 { return a[1] >= a[0] ? 1 : 0 }
                return 0
            case "linear":
                if a.count > 3 {
                    let u = clamp((a[0] - a[1]) / max(0.0001, a[2] - a[1]), 0, 1)
                    return a[3] + (a[4 < a.count ? 4 : 3] - a[3]) * u
                }
                return a.first ?? 0
            case "wiggle":
                if a.count > 1 {
                    let f = max(0.01, a[0])
                    let i0 = Int(floor(ctx.t * f))
                    let fr = ctx.t * f - Float(i0)
                    // golden-ratio hash: the constant exceeds Int64.max, so
                    // the multiply must run in UInt64 (bit-identical to the
                    // Int64 wrap-around the Kotlin original did)
                    var s = UInt64(truncatingIfNeeded: i0) &* 0x9E3779B97F4A7C15
                    _ = ktRandom(&s)
                    let r0 = Float(ktRandom(&s) % 2000) / 1000 - 1
                    let r1 = Float(ktRandom(&s) % 2000) / 1000 - 1
                    let u = fr * fr * (3 - 2 * fr)
                    return (r0 + (r1 - r0) * u) * a[1]
                }
                return 0
            case "noise":
                return a.count > 0 ? noise1(a[0]) * 2 - 1 : 0
            case "random":
                return seededRandom(&ctx)
            case "rand":
                if a.count > 1 {
                    let r = seededRandom(&ctx)
                    return a[0] + (a[1] - a[0]) * r
                }
                return seededRandom(&ctx)
            case "seedRandom", "seedrandom":
                // seedRandom(seed[, timeless]) — After Effects style: sets the
                // seed for the random()/rand() calls after it in the same
                // expression. timeless=1 freezes them (no per-frame change).
                if a.count > 0 { ctx.seed = Int32(clamp(a[0], -100000, 100000)); ctx.seedSet = true }
                if a.count > 1 { ctx.timeless = a[1] != 0 }
                return 0
            case "gaussRandom", "gaussrandom":
                // Box-Muller over two seeded uniforms — AE's bell-curve random
                let u1 = max(1e-5, seededRandom(&ctx))
                let u2 = seededRandom(&ctx)
                if a.count > 1 { return a[0] + (a[1] - a[0]) * sqrt(-2 * log(u1)) * cos(2 * Float.pi * u2) }
                return sqrt(-2 * log(u1)) * cos(2 * Float.pi * u2)
            case "ease":
                if a.count > 3 {
                    let u = clamp((a[0] - a[1]) / max(0.0001, a[2] - a[1]), 0, 1)
                    let p = u * u * (3 - 2 * u)      // smoothstep
                    return a[3] + (a[a.count > 4 ? 4 : 3] - a[3]) * p
                }
                return a.first ?? 0
            case "easeIn":
                if a.count > 3 {
                    let u = clamp((a[0] - a[1]) / max(0.0001, a[2] - a[1]), 0, 1)
                    return a[3] + (a[a.count > 4 ? 4 : 3] - a[3]) * u * u
                }
                return a.first ?? 0
            case "easeOut":
                if a.count > 3 {
                    let u = clamp((a[0] - a[1]) / max(0.0001, a[2] - a[1]), 0, 1)
                    return a[3] + (a[a.count > 4 ? 4 : 3] - a[3]) * u * (2 - u)
                }
                return a.first ?? 0
            case "degreesToRadians": return a.count > 0 ? a[0] * Float.pi / 180 : 0
            case "radiansToDegrees": return a.count > 0 ? a[0] * 180 / Float.pi : 0
            case "timeToFrames":
                return (a.count > 0 ? a[0] : ctx.t) * ctx.env.fps
            case "framesToTime":
                return (a.count > 0 ? a[0] : 0) / max(1, ctx.env.fps)
            case "posterizeTime":
                // quantizes the clock to a[0] samples per second
                if a.count > 0, a[0] > 0.01 {
                    return (ctx.t * a[0]).rounded(.down) / a[0]
                }
                return ctx.t
            case "key":
                // key(n) → that keyframe's time (AE: key(n).time)
                if a.count > 0 {
                    let i = Int(a[0])
                    if i >= 1, i <= ctx.env.keyTimes.count { return ctx.env.keyTimes[i - 1] }
                }
                return 0
            case "loopOut", "loopout":
                return loop(ctx, a.first ?? 0, out: true)
            case "loopIn", "loopin":
                return loop(ctx, a.first ?? 0, out: false)
            default: return 0
            }
        }
    }

    /// loopOut/loopIn — repeat the keyframe segment past its last key (or
    /// before its first). Mode: 0 = cycle (AE "cycle"), 1 = pingpong
    /// ("pingpong"), 2 = continuing the delta ("offset"). Linear between
    /// keys inside the looped segment — the mini-language has no bezier here.
    private static func loop(_ ctx: Ctx, _ mode: Float, out: Bool) -> Float {
        let ts = ctx.env.keyTimes
        let vs = ctx.env.keyVals
        let n = ts.count
        guard n >= 2, vs.count == n else { return ctx.v }
        let span = ts[n - 1] - ts[0]
        guard span > 0.0001 else { return ctx.v }
        // linear interp of the keyframe segment at u in 0..1
        func seg(_ u: Float) -> Float {
            var uu = u.truncatingRemainder(dividingBy: 1)
            if uu < 0 { uu += 1 }
            for i in 0..<(n - 1) {
                let k0 = (ts[i] - ts[0]) / span, k1 = (ts[i + 1] - ts[0]) / span
                if uu >= k0 - 1e-5 && uu <= k1 + 1e-5 {
                    let f = k1 > k0 ? (uu - k0) / (k1 - k0) : 0
                    return vs[i] + (vs[i + 1] - vs[i]) * f
                }
            }
            return vs[n - 1]
        }
        if out {
            guard ctx.t > ts[n - 1] else { return ctx.v }
            let over = ctx.t - ts[n - 1]
            let cycles = Int(over / span)
            let u = over / span
            if mode == 1 && cycles % 2 == 1 {          // pingpong: every other
                return seg(1 - (u - Float(cycles)))     // cycle runs backwards
            }
            var base = seg(u)
            if mode == 2 { base += (vs[n - 1] - vs[0]) * Float(cycles + 1) }
            return base
        } else {
            guard ctx.t < ts[0] else { return ctx.v }
            let under = ts[0] - ctx.t
            let cycles = Int(under / span)
            let u = under / span
            if mode == 1 && cycles % 2 == 1 {
                return seg(1 - (u - Float(cycles)))
            }
            var base = seg(-u)
            if mode == 2 { base -= (vs[n - 1] - vs[0]) * Float(cycles + 1) }
            return base
        }
    }

    /// Deterministic 0...1 random: hashed from the active seed (seedRandom)
    /// and the current frame — quantized to 1/60s so playback and a 60fps
    /// export sample identical values; timeless seeds skip the frame term.
    private static func seededRandom(_ ctx: inout Ctx) -> Float {
        // the mixing constants exceed Int32.max, so everything runs in UInt32
        // (bit-identical to the wrap-around arithmetic the Kotlin hash used)
        var s = UInt32(truncatingIfNeeded: ctx.seed) &* 747796405 &+ 2891336453
        if !ctx.timeless {
            let frame = Int64((ctx.t * 60).rounded(.down))
            s = UInt32(truncatingIfNeeded: Int64(s) &+ frame &* 2654435761)
        }
        s = s &* 747796405 &+ 2891336453
        s = ((s >> ((s >> 28) + 4)) ^ s) &* 277803737
        s = (s >> 22) ^ s
        return Float(s % 100000) / 100000
    }
}
