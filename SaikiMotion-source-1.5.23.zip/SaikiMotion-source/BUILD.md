# BUILD.md — building SaikiMotion with Xcode (via XcodeGen)

The Xcode project is **generated** from `project.yml` by [XcodeGen] — no
`.xcodeproj` is committed to the repo. GitHub's macOS runners have Xcode
preinstalled, so CI needs nothing but Homebrew. Spec syntax verified against
XcodeGen's own `Docs/ProjectSpec.md`.

[XcodeGen]: https://github.com/yonaskolb/XcodeGen

Two ways to build; pick ONE.

---

## Way 1 — GitHub Actions (RECOMMENDED: no Mac, no install, nothing local)

The repo already contains the workflow: `.github/workflows/build.yml`.
It runs `xcodegen generate` → `xcodebuild` → packages an unsigned `.ipa`.

1. Create a GitHub account if needed, then create a **new repository**
   (e.g. `saikimotion-source`). **Do NOT** add a README/.gitignore/license
   during creation (keeps the push conflict-free).
2. Upload the project (see §"Pushing to GitHub" below). **The source files
   must actually be in the repo** — a `.zip` file sitting in the repo is NOT
   extracted by GitHub; the workflow can only build files that are committed.
3. Open the repo → **Actions** tab → if it didn't start on push, select
   **Build SaikiMotion IPA** → **Run workflow** → branch `main`.
4. Wait for the run to finish (green check, ~5–10 min first time).
5. Click the finished run → scroll to **Artifacts** → download
   **SaikiMotion-1.5.23-unsigned-ipa** → unzip it → you have the `.ipa`.
6. **Delete the old SaikiMotion entry in LiveContainer first**, then import
   the new `.ipa`. (Importing over a same-version entry is the round-18 trap
   that kept your phone running stale builds.)

Free-plan note: macOS runners bill at 10× — a build costs ~50–100 billed
minutes of your 2000/month budget. Fine for occasional builds; don't loop it.

### Pushing to GitHub (from a terminal in the unzipped folder)

```bash
cd SaikiMotion-source
git init
git add .
git commit -m "SaikiMotion source 1.5.23 + XcodeGen + CI"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/saikimotion-source.git
git push -u origin main
```

(`YOUR-USERNAME` = your GitHub name. If git asks for a password, it wants a
**Personal Access Token** — GitHub → Settings → Developer settings →
Personal access tokens → Tokens (classic) → Generate — not your account
password. Check the `repo` permission box.)

No terminal? Alternative: repo page → **Add file → Upload files** → drag the
CONTENTS of SaikiMotion-source (including the `.github` folder — enable
"show hidden files" in your file manager, or the workflow won't upload!).
After committing, the repo root should show: `Sources/`, `native/`, `docs/`,
`.github/`, `project.yml`, `Info.plist`, `Package.swift`, `BUILD.md`, …
**If you see a `.zip` file instead, the upload is wrong — GitHub does not
unzip.**

---

## Way 2 — Build locally with Xcode (any Mac)

1. Install Xcode (free from the App Store, launch once) and Homebrew.
2. `brew install xcodegen`
3. In this folder:

```bash
xcodegen generate     # creates SaikiMotion.xcodeproj from project.yml
xcodebuild -project SaikiMotion.xcodeproj -scheme SaikiMotion \
  -configuration Release -destination 'generic/platform=iOS' \
  -derivedDataPath build \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY="" build
```

4. Package the unsigned .ipa (what LiveContainer expects):

```bash
mkdir -p Payload && cp -R build/Build/Products/Release-iphoneos/SaikiMotion.app Payload/
zip -qry SaikiMotion-1.5.23-unsigned.ipa Payload
```

Or just open `SaikiMotion.xcodeproj` in Xcode and hit Cmd+R on a simulator.

### Legacy: xtool still works too

`Package.swift` + `xtool.yml` are kept in sync with `project.yml`, so
`xtool dev build --ipa` (SwiftPM route) remains available if you have xtool
installed. Both paths exclude the same three not-yet-recovered files.

### Target layout (all three definitions agree)

| Target | Type | Sources |
|---|---|---|
| `CCrashLog` | static framework (`DEFINES_MODULE=YES`) | `Sources/CCrashLog` (C only) |
| `SaikiMotion` | application | `Sources` minus `CCrashLog/`, minus the 3 files listed in MISSING-SOURCE.md |

Deployment target iOS 16.0 · bundle id `com.saiki.motion.app` · Swift 5 mode.
As each missing source file is recovered, delete its line from BOTH
`project.yml` (excludes) and `Package.swift` (exclude).

---

## Verifying you're really running the new build

Account/About shows `1.5.23 (23)`. If it shows anything else, the import
didn't replace — delete and re-import in LiveContainer.

## What must never come back (the 19-round lessons)

- No synchronous save on the edit path — `markDirty()` + `maybeIdleSave()`
  only (see EditorViewController.swift).
- No Swift in signal context — crash logging is 100% C (CCrashLog).
- No `glReadPixels`/`glCopyTexImage` per-frame caches (round-16 freeze
  machine; design deleted, not ported).
- No absolute link-time addresses in code (round-5/14/18 crash class) —
  impossible in Swift source by construction.
- Version keys (`CFBundleShortVersionString` AND `CFBundleVersion`) bump on
  **every** build — that's how we escaped the round-18 stale-build trap.
