# BUILD.md — building SaikiMotion with xtool

Every command in this file is **verified against xtool's own source code**
(`xtool-org/xtool`, PackLib + DevCommand) and its official docs — not guessed.
Two ways to build; pick ONE.

---

## Way 1 — GitHub Actions (RECOMMENDED: no Mac, no install, nothing local)

The repo already contains the workflow: `.github/workflows/build.yml`.

1. Create a GitHub account if needed, then create a **new repository**
   (e.g. `saikimotion-source`). **Do NOT** add a README/.gitignore/license
   during creation (keeps the push conflict-free).
2. Upload the project (exact commands in §"Pushing to GitHub" below).
3. Open the repo → **Actions** tab → if it didn't start on push, select
   **Build SaikiMotion IPA** → **Run workflow** → branch `main`.
4. Wait for the run to finish (green check, ~5–10 min first time).
5. Click the finished run → scroll to **Artifacts** → download
   **SaikiMotion-1.5.23-unsigned-ipa** → unzip it → you have the `.ipa`.
6. **Delete the old SaikiMotion entry in LiveContainer first**, then import
   the new `.ipa`. (Importing over a same-version entry is the round-18 trap
   that kept your phone running stale builds.)

Free-plan note: macOS runners bill at 10× — a build costs ~50–100 billed
minutes of your 2000/month budget. Fine for occasional builds; don't loop it.

### Pushing to GitHub (from a terminal in the unzipped folder)

```bash
cd SaikiMotion-source
git init
git add .
git commit -m "SaikiMotion source 1.5.23 + xtool + CI"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/saikimotion-source.git
git push -u origin main
```

(`YOUR-USERNAME` = your GitHub name. If git asks for a password, it wants a
**Personal Access Token** — GitHub → Settings → Developer settings →
Personal access tokens → Tokens (classic) → Generate — not your account
password. Check the `repo` permission box.)

No terminal? Alternative: repo page → **Add file → Upload files** → drag the
CONTENTS of SaikiMotion-source (including the `.github` folder — enable
"show hidden files" in your file manager, or the workflow won't upload!).

---

## Way 2 — Build locally with xtool (macOS, Linux, or Windows/WSL)

- **macOS:** install Xcode (free from the App Store, launch once), then
  `brew install xtool-org/tap/xtool`. No `xtool setup`/login needed —
  building needs no Apple ID.
- **Linux/Windows(WSL):** follow xtool.sh → Installation (Linux/Windows);
  xtool downloads its own Darwin Swift SDK (~GBs, one time).

Then, in this folder:

```bash
xtool dev build --ipa
```

Output: `./xtool/SaikiMotion.ipa` (unsigned — correct for LiveContainer).
Inspect the built bundle at `./xtool/SaikiMotion.app` if curious.

### Command reference (what exists, what doesn't)

| Command | Exists? | Use |
|---|---|---|
| `xtool dev build --ipa` | ✅ | **This is the one.** Builds + packages the .ipa |
| `xtool dev build` | ✅ | Builds `xtool/SaikiMotion.app` only |
| `xtool dev build --sign` | ✅ but… | Requires `xtool auth` (Apple ID). **Not needed for LC** — LC signs on import |
| `xtool build` | ❌ doesn't exist | (common mistake — `build` is a subcommand of `dev`) |
| `xtool dev` | ✅ | build+install+launch on a USB device (needs auth) |
| `xtool dev xcode` | ✅ | generates an Xcode project |

### Project layout that xtool REQUIRES (break these = silent failure)

1. **`xtool.yml` must exist** with `version: 1` + `bundleID` — it's the
   project spec; without it xtool has no bundle ID.
2. **Package.swift must have exactly ONE `.library` product** — the app.
   A `.executableTarget`/executable product is rejected by xtool's planner
   ("An xtool project should contain exactly one library product").
3. `@main` inside the library target is fine — SwiftPM compiles targets
   with `-parse-as-library`, so `@main` emits the entry symbol.
4. `infoPath: Info.plist` in xtool.yml — your keys override xtool's
   generated bare-bones plist.
5. Deployment target comes from `platforms: [.iOS(.v16)]` in Package.swift.

---

## Verifying you're really running the new build

Account/About shows `1.5.23 (23)`. If it shows anything else, the import
didn't replace — delete and re-import in LiveContainer.

## What must never come back (the 19-round lessons)

- No synchronous save on the edit path — `markDirty()` + `maybeIdleSave()`
  only (see EditorViewController.swift).
- No Swift in signal context — crash logging is 100% C (CCrashLog).
- No `glReadPixels`/`glCopyTexImage` per-frame caches (round-16 freeze
  machine; design deleted, not ported).
- No absolute link-time addresses in code (round-5/14/18 crash class) —
  impossible in Swift source by construction.
- Version keys (`CFBundleShortVersionString` AND `CFBundleVersion`) bump on
  **every** build — that's how we escaped the round-18 stale-build trap.
