/* CCrashLog — implementation. See include/CCrashLog.h for the contract. */

#include "CCrashLog.h"
#include <signal.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/time.h>

#define RING_SLOTS 32
#define TAG_LEN    15

typedef struct {
    volatile uint64_t seq;                 /* total notes ever written */
    char  tags[RING_SLOTS][TAG_LEN + 1];   /* tag text */
    uint64_t seqs[RING_SLOTS];             /* sequence number of each slot */
} Ring;

static int   g_fd = -1;
static Ring  g_ring;
static volatile int   g_watch_frozen = 0;
static char  g_watch_detail[64];

/* ---------------------------------------------------------------- helpers */

static void xwrite(const char *s, size_t n) {
    if (g_fd >= 0) {
        ssize_t r = write(g_fd, s, n);
        (void)r;
    }
}

static void wstr(const char *s) { xwrite(s, strlen(s)); }

/* Fixed-width hex/decimal formatters — no printf in signal context. */
static char *fmthex(char *p, uint64_t v, int width) {
    static const char d[] = "0123456789abcdef";
    for (int i = width - 1; i >= 0; i--) { p[i] = d[v & 0xF]; v >>= 4; }
    return p + (width > 0 ? width : 0);
}
static char *fmtdec(char *p, uint64_t v) {
    char tmp[24]; int n = 0;
    do { tmp[n++] = (char)('0' + (v % 10)); v /= 10; } while (v);
    while (n) *p++ = tmp[--n];
    return p;
}

/* ---------------------------------------------------------------- handler */

static void crash_handler(int sig, siginfo_t *si, void *uc_) {
    /* 1 — report */
    const char *signame =
        sig == SIGSEGV ? "SIGSEGV" : sig == SIGBUS  ? "SIGBUS"  :
        sig == SIGABRT ? "SIGABRT" : sig == SIGILL  ? "SIGILL"  :
        sig == SIGFPE  ? "SIGFPE"  : sig == SIGTRAP ? "SIGTRAP" : "SIGNAL";
    wstr("\n=== SAIKIMOTION CRASH ===\nsignal: "); wstr(signame);
    wstr(" (");
    { char b[12]; char *p = fmtdec(b, (uint64_t)sig); xwrite(b, (size_t)(p - b)); }
    wstr(")\n");

    wstr("fault address: 0x");
    { char b[18]; char *p = fmthex(b, (uint64_t)(si ? si->si_addr : 0), 16); xwrite(b, (size_t)(p - b)); }
    wstr("\n");

    /* 2 — all registers from the ucontext (arm64) */
    wstr("registers:\n");
    if (uc_) {
        ucontext_t *uc = (ucontext_t *)uc_;
#if defined(__APPLE__) && (defined(__arm64__) || defined(__aarch64__))
        _STRUCT_MCONTEXT64 *m = &uc->uc_mcontext;
        const char *names[29] = {"x0","x1","x2","x3","x4","x5","x6","x7","x8","x9",
                                 "x10","x11","x12","x13","x14","x15","x16","x17","x18","x19",
                                 "x20","x21","x22","x23","x24","x25","x26","x27","x28"};
        for (int i = 0; i < 29; i++) {
            char line[64]; char *q = line;
            const char *nm = names[i]; while (*nm) *q++ = *nm++;
            *q++ = ':'; *q++ = ' '; *q++ = '0'; *q++ = 'x';
            q = fmthex(q, m->__ss.__x[i], 16); *q++ = '\n';
            xwrite(line, (size_t)(q - line));
        }
        { char line[96]; char *q = line;
          q = (char *)memcpy(q, "fp: 0x", 6) + 6; q = fmthex(q, m->__ss.__fp, 16);
          q = (char *)memcpy(q, "  lr: 0x", 8) + 8; q = fmthex(q, m->__ss.__lr, 16);
          q = (char *)memcpy(q, "\nsp: 0x", 7) + 7; q = fmthex(q, m->__ss.__sp, 16);
          q = (char *)memcpy(q, "  pc: 0x", 8) + 8; q = fmthex(q, m->__ss.__pc, 16);
          *q++ = '\n'; xwrite(line, (size_t)(q - line)); }
#endif
    } else {
        wstr("(no ucontext)\n");
    }

    /* 3 — the action ring (last things the app did) */
    wstr("recent actions:\n");
    {
        uint64_t total = g_ring.seq;
        int shown = 0;
        for (uint64_t s = total > RING_SLOTS ? total - RING_SLOTS : 0; s < total && shown < RING_SLOTS; s++, shown++) {
            uint32_t idx = (uint32_t)(s % RING_SLOTS);
            char line[TAG_LEN + 24]; char *q = line;
            q = (char *)memcpy(q, "  ", 2) + 2; q = fmtdec(q, s + 1); *q++ = ' ';
            size_t tl = strnlen(g_ring.tags[idx], TAG_LEN);
            memcpy(q, g_ring.tags[idx], tl); q += tl; *q++ = '\n';
            xwrite(line, (size_t)(q - line));
        }
    }

    /* 4 — watchdog state */
    if (g_watch_frozen) {
        wstr("watchdog: FROZEN — "); wstr(g_watch_detail); wstr("\n");
    } else {
        wstr("watchdog: idle\n");
    }
    wstr("=== END REPORT ===\n");

    /* 5 — get out of the way: default disposition, re-raise, let iOS log it */
    signal(sig, SIG_DFL);
    raise(sig);
}

/* ---------------------------------------------------------------- publics */

void ccrash_note(const char *tag) {
    if (!tag) return;
    uint64_t s = g_ring.seq;                    /* single writer (main thread) */
    uint32_t idx = (uint32_t)(s % RING_SLOTS);
    size_t i = 0;
    for (; tag[i] && i < TAG_LEN; i++) g_ring.tags[idx][i] = tag[i];
    g_ring.tags[idx][i] = 0;
    g_ring.seqs[idx] = s + 1;
    g_ring.seq = s + 1;
}

void ccrash_set_watchdog(int frozen, const char *detail) {
    g_watch_frozen = frozen ? 1 : 0;
    if (detail) {
        size_t i = 0;
        for (; detail[i] && i < sizeof(g_watch_detail) - 1; i++) g_watch_detail[i] = detail[i];
        g_watch_detail[i] = 0;
    } else {
        g_watch_detail[0] = 0;
    }
}

void ccrash_report_freeze(const char *detail) {
    wstr("\n=== SAIKIMOTION FREEZE ===\n");
    wstr("detail: "); wstr(detail ? detail : "(none)"); wstr("\n");
    wstr("The main thread stopped responding while unsaved work was in flight.\n");
    wstr("=== END REPORT ===\n");
}

int ccrash_install(const char *dir_path) {
    if (g_fd >= 0) return 0;                   /* idempotent */

    if (dir_path) {
        char path[1024];
        size_t n = strlen(dir_path);
        if (n > 900) return -1;
        memcpy(path, dir_path, n); path[n] = 0;
        /* <dir>/crash_<epochms>.log */
        struct timeval tv; gettimeofday(&tv, NULL);
        uint64_t ms = ((uint64_t)tv.tv_sec * 1000) + (uint64_t)(tv.tv_usec / 1000);
        char *p = path + n; *p++ = '/';
        const char *stem = "crash_"; while (*stem) *p++ = *stem++;
        p = fmtdec(p, ms);
        const char *suf = ".log"; while (*suf) *p++ = *suf++;
        *p = 0;

        g_fd = open(path, O_CREAT | O_WRONLY | O_APPEND, 0644);
        if (g_fd < 0) return -1;
        wstr("SaikiMotion crash logger installed.\n");
    }

    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_sigaction = crash_handler;
    sa.sa_flags = SA_SIGINFO;
    sigemptyset(&sa.sa_mask);
    static const int sigs[] = { SIGSEGV, SIGBUS, SIGABRT, SIGILL, SIGFPE, SIGTRAP };
    for (size_t i = 0; i < sizeof(sigs) / sizeof(sigs[0]); i++) {
        sigaction(sigs[i], &sa, NULL);
    }
    return 0;
}
