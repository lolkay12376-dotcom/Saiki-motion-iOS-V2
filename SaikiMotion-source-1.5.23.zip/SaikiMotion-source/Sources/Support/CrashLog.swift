// CrashLog.swift — Swift side of the round-19 crash logger.
//
// Contract (from 19 rounds of binary patching, distilled):
//   * Install once, as early as possible in process lifetime.
//   * Never log from a signal handler in Swift — that is exactly the
//     round-14 "emergency save from signal context" bug that wedged the
//     main thread for 30+ seconds. All signal-context work lives in C.
//   * Uncaught NSExceptions are logged here too (main thread, safe to
//     use Foundation), then re-raised so iOS still writes its .ips.

import Foundation
import CCrashLog

enum CrashLog {

    /// Create <Documents>/Crash and install handlers. Safe to call twice.
    static func install() {
        let dir = crashDir()
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        _ = dir.path.utf8CString.withUnsafeBufferPointer { buf -> Int32 in
            guard let base = buf.baseAddress else { return -1 }
            return ccrash_install(base)
        }

        // Route uncaught NSExceptions into the same report file. The handler
        // itself runs on the crashing thread *before* the abort, so Foundation
        // is allowed — but keep it minimal anyway.
        NSSetUncaughtExceptionHandler { exc in
            note("nsexc")
            let name = exc.name.rawValue
            let reason = exc.reason ?? ""
            let msg = "UNCAUGHT EXCEPTION: \(name) — \(reason)\n"
            let dir = crashDir()
            let f = dir.appendingPathComponent("latest_exception.log")
            try? msg.write(to: f, atomically: true, encoding: .utf8)
        }
    }

    /// Record what the app is doing — shows up in the crash report ring.
    /// Cheap (one memcpy); call it at every interesting transition.
    static func note(_ tag: String) {
        tag.utf8CString.withUnsafeBufferPointer { buf in
            if let base = buf.baseAddress { ccrash_note(base) }
        }
    }

    /// Directory shown in the Files app (R15/R19 user-visible crash folder).
    static func crashDir() -> URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? FileManager.default.temporaryDirectory
        return docs.appendingPathComponent("Crash", isDirectory: true)
    }

    /// Count of reports — Extras tab shows this (R19 §7).
    static func reportCount() -> Int {
        let files = (try? FileManager.default.contentsOfDirectory(at: crashDir(),
                                                                  includingPropertiesForKeys: nil)) ?? []
        return files.filter { $0.pathExtension == "log" }.count
    }
}
