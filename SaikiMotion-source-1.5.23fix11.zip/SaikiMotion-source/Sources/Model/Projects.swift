// Projects.swift — the project store (Model).
//
// One JSON file per project in <Documents>/SaikiMotion/projects, media in
// <Documents>/SaikiMotion/media — the same sandbox layout every round of the
// finished app used, so old projects keep opening.

import Foundation

enum Projects {

    static var root: URL { Paths.root }

    static var dir: URL { root.appendingPathComponent("projects", isDirectory: true) }

    static func mediaDir() -> URL { root.appendingPathComponent("media", isDirectory: true) }

    static func fileURL(_ id: String) -> URL {
        dir.appendingPathComponent("\(id).json")
    }

    /// Creates the sandbox folders. Safe any number of times.
    static func ensureDirs() {
        Paths.ensure()
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        try? FileManager.default.createDirectory(at: mediaDir(), withIntermediateDirectories: true)
    }

    /// Saves the project (bumps updatedAt). The editor's spelling takes the
    /// id + the live object; the home list uses the inout form.
    @discardableResult
    static func save(_ id: String, _ project: Project) -> String? {
        ensureDirs()
        project.updatedAt = Date()
        project.id = id
        let text = project.toJson().toString(2)
        try? text.write(to: fileURL(id), atomically: true, encoding: .utf8)
        StoreNotification.post(.projectsChanged)
        return text
    }

    @discardableResult
    static func save(_ project: inout Project) -> String? {
        save(project.id, project)
    }

    static func load(_ id: String) -> Project? {
        guard let text = try? String(contentsOf: fileURL(id), encoding: .utf8) else { return nil }
        guard let o = JObj.parse(text) else { return nil }
        return Project.fromJson(o)
    }

    /// All projects, newest-touched first.
    static func list() -> [Project] {
        ensureDirs()
        let files = (try? FileManager.default.contentsOfDirectory(at: dir, includingPropertiesForKeys: [.contentModificationDateKey])) ?? []
        return files
            .filter { $0.pathExtension == "json" }
            .compactMap { load($0.deletingPathExtension().lastPathComponent) }
            .sorted { $0.updatedAt > $1.updatedAt }
    }

    static func delete(_ id: String) {
        try? FileManager.default.removeItem(at: fileURL(id))
        StoreNotification.post(.projectsChanged)
    }

    /// Renames a project in place (keeps id, timestamps refresh on save).
    static func rename(_ id: String, _ name: String) {
        guard var p = load(id) else { return }
        p.name = name
        save(&p)
    }

    /// Deep-copies a project under a new id ("Name copy"), like the
    /// original's Projects.duplicate(name).
    @discardableResult
    static func duplicate(_ id: String) -> Project? {
        guard let p = load(id) else { return nil }
        guard let o = JObj.parse(p.toJson().toString(0)) else { return nil }
        var copy = Project.fromJson(o)
        copy.id = UUID().uuidString
        copy.name = p.name + " copy"
        save(&copy)
        return copy
    }

    /// The JSON file as stored on disk — the share/export payload.
    /// (Same as fileURL(_:); the original exposed this for the share sheet.)
    static func exportURL(_ id: String) -> URL { fileURL(id) }

    /// Imports a project JSON picked in the document picker: copies it into
    /// the store under a fresh id so re-importing never collides. (The picker
    /// opens asCopy, so security scope is optional.)
    @discardableResult
    static func importFile(_ url: URL) -> Project? {
        let scoped = url.startAccessingSecurityScope()
        defer { if scoped { url.stopAccessingSecurityScope() } }
        guard let text = try? String(contentsOf: url, encoding: .utf8),
              let o = JObj.parse(text) else { return nil }
        var p = Project.fromJson(o)
        p.id = UUID().uuidString
        if p.name.isEmpty { p.name = url.deletingPathExtension().lastPathComponent }
        save(&p)
        return p
    }

    /// "1080p portrait · 30 fps" style label for list rows.
    static func resLabel(_ w: Int, _ h: Int) -> String {
        let ar: String
        let r = Double(w) / Double(max(h, 1))
        if r > 1.2 { ar = "landscape" }
        else if r < 0.83 { ar = "portrait" }
        else { ar = "square" }
        let hd = max(w, h)
        let tag = hd >= 2000 ? "2K" : (hd >= 1000 ? "1080p" : "SD")
        return "\(tag) \(ar)"
    }

    /// Project-row label (scene + layer counts).
    static func resLabel(_ p: Project) -> String {
        let layers = p.scenes.reduce(0) { $0 + $1.layers.count }
        let word = p.scenes.count == 1 ? "scene" : "scenes"
        return "\(p.scenes.count) \(word) · \(layers) layers · \(p.fps) fps"
    }
}
