// HomeViewController.swift — 1:1 reconstruction of the original home screen.
//
// Rebuilt from the original binary (1.5.21) rather than the round-19 spec:
//   • symbols recovered from the app: buildUi(), refresh(), projectRow(),
//     showNewDialog(), showMenu(), showExport(), countLabel, list, kerned(),
//     makeField(), TapGesture, LongPressGesture, documentPicker(),
//     didFirstAppear, preferredStatusBarStyle
//   • UI strings recovered from the app: "New project",
//     "No projects yet. Tap NEW PROJECT to start.", "IMPORT PROJECT FILE",
//     "Rename project", "Duplicate", "Delete project?",
//     "Export project file", "Don't show again"
//   • the original screenshot: black background, bottom bar with FIVE tabs
//     (Account, Projects, AI, Community, Extras), custom icons above
//     UPPERCASE letter-spaced labels, orange (#FF8A1F) selected, gray
//     unselected, and a full-width dark-brown "IMPORT PROJECT FILE" button
//     pinned above the bar.
//
// What's New (WelcomeViewController) shows once per version on first appear,
// exactly like the original's welcome/changelog card.

import UIKit
import UniformTypeIdentifiers

final class HomeViewController: UIViewController {

    private enum Tab: Int, CaseIterable {
        case account, projects, ai, community, extras

        var label: String {
            switch self {
            case .account: return "Account"
            case .projects: return "Projects"
            case .ai: return "AI"
            case .community: return "Community"
            case .extras: return "Extras"
            }
        }

        var icon: String {
            switch self {
            case .account: return "account"
            case .projects: return "film"
            case .ai: return "sparkle_tab"
            case .community: return "people"
            case .extras: return "grid_plus"
            }
        }
    }

    // chrome
    private var barButtons: [HomeTabButton] = []
    private let content = UIView()
    private var current: UIView?
    private var tabChild: UIViewController?
    private var selectedTab: Tab = .projects
    private var didFirstAppear = false

    // projects tab state
    private var projects: [Project] = []
    private var countLabel: UILabel?
    private var listStack: UIStackView?

    private let pad: CGFloat = 16

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = argbToUIColor(C.BG)
        CrashLog.note("home")
        buildUi()
        show(.projects)

        NotificationCenter.default.addObserver(self, selector: #selector(storeChanged),
                                               name: .projectsChanged, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(languageChanged),
                                               name: .languageChanged, object: nil)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        // The whole app draws its own chrome (the editor does the same on
        // its side); no system navigation bar anywhere.
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        guard !didFirstAppear else { return }
        didFirstAppear = true
        maybeShowWelcome()
    }

    // MARK: - buildUi -------------------------------------------------------

    private func buildUi() {
        let bar = UIStackView()
        bar.axis = .horizontal
        bar.distribution = .fillEqually
        bar.backgroundColor = argbToUIColor(C.BG)
        bar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(bar)

        for tab in Tab.allCases {
            let b = HomeTabButton()
            b.icon = tab.icon
            b.setLabel(kerned(L10n.tr(tab.label), 9, .semibold, kern: 1.0))
            b.on = tab == .projects
            b.tapped = { [weak self] in self?.show(tab) }
            bar.addArrangedSubview(b)
            barButtons.append(b)
        }

        content.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(content)

        NSLayoutConstraint.activate([
            bar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            bar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            bar.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            bar.heightAnchor.constraint(equalToConstant: 58),
            content.topAnchor.constraint(equalTo: view.topAnchor),
            content.bottomAnchor.constraint(equalTo: bar.topAnchor),
            content.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            content.trailingAnchor.constraint(equalTo: view.trailingAnchor),
        ])
    }

    // MARK: - tab switching ---------------------------------------------------

    private func show(_ tab: Tab) {
        selectedTab = tab
        for (i, b) in barButtons.enumerated() {
            b.on = i == tab.rawValue
        }
        if let child = tabChild {
            child.willMove(toParent: nil)
            child.view.removeFromSuperview()
            child.removeFromParent()
            tabChild = nil
        }
        current?.removeFromSuperview()
        let v = buildTab(tab)
        v.translatesAutoresizingMaskIntoConstraints = false
        content.addSubview(v)
        NSLayoutConstraint.activate([
            v.topAnchor.constraint(equalTo: content.topAnchor),
            v.bottomAnchor.constraint(equalTo: content.bottomAnchor),
            v.leadingAnchor.constraint(equalTo: content.leadingAnchor),
            v.trailingAnchor.constraint(equalTo: content.trailingAnchor),
        ])
        current = v
    }

    private func buildTab(_ tab: Tab) -> UIView {
        switch tab {
        case .projects: return buildProjects()
        case .account: return buildAccount()
        case .ai: return buildAi()
        case .community: return buildCommunity()
        case .extras: return buildExtras()
        }
    }

    @objc private func storeChanged() { refresh() }
    @objc private func languageChanged() {
        for (i, b) in barButtons.enumerated() {
            if let tab = Tab(rawValue: i) { b.setLabel(kerned(L10n.tr(tab.label), 9, .semibold, kern: 1.0)) }
        }
        show(selectedTab)
    }

    // MARK: - Projects tab ----------------------------------------------------

    private func buildProjects() -> UIView {
        let wrap = UIView()

        // header
        let header = UILabel()
        header.attributedText = kerned(L10n.tr("Projects"), 24, .bold)
        header.textColor = argbToUIColor(C.TEXT)
        header.translatesAutoresizingMaskIntoConstraints = false
        wrap.addSubview(header)

        let count = UILabel()
        count.font = .systemFont(ofSize: 12)
        count.textColor = argbToUIColor(C.DIM)
        count.translatesAutoresizingMaskIntoConstraints = false
        wrap.addSubview(count)
        countLabel = count

        // NEW PROJECT (the primary action — the empty state points here)
        let newBtn = HomeBigButton()
        newBtn.title = kerned(L10n.tr("New project"), 15, .bold)
        newBtn.bg = C.GREEN
        newBtn.fg = Int32(bitPattern: 0xFF141414)
        newBtn.tapped = { [weak self] in self?.showNewDialog() }
        newBtn.translatesAutoresizingMaskIntoConstraints = false
        wrap.addSubview(newBtn)

        // scrollable list
        let scroll = UIScrollView()
        scroll.alwaysBounceVertical = true
        scroll.translatesAutoresizingMaskIntoConstraints = false
        wrap.addSubview(scroll)

        let stack = UIStackView()
        stack.axis = .vertical
        stack.spacing = 10
        stack.translatesAutoresizingMaskIntoConstraints = false
        scroll.addSubview(stack)
        listStack = stack

        // IMPORT PROJECT FILE pinned above the tab bar
        let importBtn = HomeBigButton()
        importBtn.title = kerned("IMPORT PROJECT FILE", 13, .bold)
        importBtn.bg = Int32(bitPattern: 0xFF3A2410)      // the original's dark brown
        importBtn.fg = C.GREEN
        importBtn.icon = "import"
        importBtn.tapped = { [weak self] in self?.pickProjectFile() }
        importBtn.translatesAutoresizingMaskIntoConstraints = false
        wrap.addSubview(importBtn)

        let divider = UIView()
        divider.backgroundColor = argbToUIColor(C.LINE)
        divider.translatesAutoresizingMaskIntoConstraints = false
        wrap.addSubview(divider)

        NSLayoutConstraint.activate([
            header.topAnchor.constraint(equalTo: wrap.safeAreaLayoutGuide.topAnchor, constant: 14),
            header.leadingAnchor.constraint(equalTo: wrap.leadingAnchor, constant: pad),
            count.centerYAnchor.constraint(equalTo: header.centerYAnchor),
            count.trailingAnchor.constraint(equalTo: wrap.trailingAnchor, constant: -pad),
            newBtn.topAnchor.constraint(equalTo: header.bottomAnchor, constant: 14),
            newBtn.leadingAnchor.constraint(equalTo: wrap.leadingAnchor, constant: pad),
            newBtn.trailingAnchor.constraint(equalTo: wrap.trailingAnchor, constant: -pad),
            newBtn.heightAnchor.constraint(equalToConstant: 46),
            scroll.topAnchor.constraint(equalTo: newBtn.bottomAnchor, constant: 12),
            scroll.leadingAnchor.constraint(equalTo: wrap.leadingAnchor),
            scroll.trailingAnchor.constraint(equalTo: wrap.trailingAnchor),
            scroll.bottomAnchor.constraint(equalTo: importBtn.topAnchor, constant: -12),
            stack.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor, constant: 4),
            stack.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor, constant: -16),
            stack.leadingAnchor.constraint(equalTo: scroll.contentLayoutGuide.leadingAnchor, constant: pad),
            stack.trailingAnchor.constraint(equalTo: scroll.contentLayoutGuide.trailingAnchor, constant: -pad),
            stack.widthAnchor.constraint(equalTo: scroll.frameLayoutGuide.widthAnchor, constant: -2 * pad),
            importBtn.leadingAnchor.constraint(equalTo: wrap.leadingAnchor, constant: pad),
            importBtn.trailingAnchor.constraint(equalTo: wrap.trailingAnchor, constant: -pad),
            importBtn.bottomAnchor.constraint(equalTo: wrap.bottomAnchor, constant: -12),
            importBtn.heightAnchor.constraint(equalToConstant: 46),
            divider.leadingAnchor.constraint(equalTo: wrap.leadingAnchor),
            divider.trailingAnchor.constraint(equalTo: wrap.trailingAnchor),
            divider.bottomAnchor.constraint(equalTo: wrap.bottomAnchor),
            divider.heightAnchor.constraint(equalToConstant: 0.5),
        ])

        refresh()
        return wrap
    }

    /// Rebuilds the project card list + count (the original's refresh()).
    private func refresh() {
        projects = Projects.list()
        let stack = listStack
        let count = countLabel
        guard projects.count > 0 || stack != nil else { return }
        stack?.arrangedSubviews.forEach { $0.removeFromSuperview() }

        if projects.isEmpty {
            let empty = UILabel()
            empty.text = L10n.tr("No projects yet. Tap NEW PROJECT to start.")
            empty.font = .systemFont(ofSize: 13)
            empty.textColor = argbToUIColor(C.DIM)
            empty.textAlignment = .center
            empty.numberOfLines = 0
            stack?.addArrangedSubview(empty)
            count?.text = nil
            return
        }

        count?.text = "\(projects.count) \(L10n.tr("projects"))"
        for (i, p) in projects.enumerated() {
            stack?.addArrangedSubview(projectRow(i, p))
        }
    }

    /// One project card (the original's projectRow). Tap opens the editor;
    /// long-press opens Rename / Duplicate / Delete / Export.
    private func projectRow(_ index: Int, _ info: Project) -> UIView {
        let card = UIView()
        card.backgroundColor = argbToUIColor(C.CARD)
        card.layer.cornerRadius = 14

        let name = UILabel()
        name.text = info.name
        name.font = .systemFont(ofSize: 16, weight: .semibold)
        name.textColor = argbToUIColor(C.TEXT)
        name.translatesAutoresizingMaskIntoConstraints = false
        card.addSubview(name)

        let meta = UILabel()
        meta.text = Projects.resLabel(info)
        meta.font = .systemFont(ofSize: 12)
        meta.textColor = argbToUIColor(C.DIM)
        meta.translatesAutoresizingMaskIntoConstraints = false
        card.addSubview(meta)

        let date = UILabel()
        date.text = relativeDate(info.updatedAt)
        date.font = .systemFont(ofSize: 11)
        date.textColor = argbToUIColor(C.DIM)
        date.translatesAutoresizingMaskIntoConstraints = false
        card.addSubview(date)

        NSLayoutConstraint.activate([
            name.topAnchor.constraint(equalTo: card.topAnchor, constant: 12),
            name.leadingAnchor.constraint(equalTo: card.leadingAnchor, constant: 14),
            name.trailingAnchor.constraint(equalTo: date.leadingAnchor, constant: -8),
            meta.topAnchor.constraint(equalTo: name.bottomAnchor, constant: 3),
            meta.leadingAnchor.constraint(equalTo: card.leadingAnchor, constant: 14),
            meta.bottomAnchor.constraint(equalTo: card.bottomAnchor, constant: -12),
            date.centerYAnchor.constraint(equalTo: name.centerYAnchor),
            date.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -14),
            card.heightAnchor.constraint(greaterThanOrEqualToConstant: 64),
        ])

        let tap = UITapGestureRecognizer(target: self, action: #selector(rowTapped(_:)))
        card.addGestureRecognizer(tap)

        let long = UILongPressGestureRecognizer()
        long.minimumPressDuration = 0.35
        long.addTarget(self, action: #selector(rowLongPressed(_:)))
        card.tag = 200 + index
        card.addGestureRecognizer(long)
        card.isUserInteractionEnabled = true
        return card
    }

    @objc private func rowTapped(_ g: UITapGestureRecognizer) {
        guard g.state == .ended, let card = g.view,
              let p = projects[safe: card.tag - 200] else { return }
        open(p)
    }

    @objc private func rowLongPressed(_ g: UILongPressGestureRecognizer) {
        guard g.state == .began,
              let card = g.view,
              let p = projects[safe: card.tag - 200] else { return }
        showMenu(p)
    }

    private func open(_ project: Project) {
        CrashLog.note("open_project")
        navigationController?.pushViewController(EditorViewController(projectId: project.id),
                                                 animated: true)
    }

    // MARK: - dialogs (the original's showNewDialog / showMenu / showExport) --

    /// New Project: name field + Create. The dialog is the shared Dlg card,
    /// same as the original's makeField + Create.
    private func showNewDialog() {
        let field = makeField("")
        Dlg(self)
            .setTitle(L10n.tr("New Project"))
            .setView(field)
            .setPositiveButton(L10n.tr("Create")) { [weak self] _, _ in
                let name = (field.text ?? "").trimmingCharacters(in: .whitespaces)
                guard !name.isEmpty else { return }
                var project = Project(name: name)
                Projects.save(&project)
                self?.refresh()
                self?.open(project)
            }
            .setNegativeButton(L10n.tr("Cancel"), nil)
            .show()
    }

    /// Long-press menu on a project card.
    private func showMenu(_ p: Project) {
        Dlg(self)
            .setIconItems([L10n.tr("Rename project"), L10n.tr("Duplicate"),
                           L10n.tr("Delete project?"), L10n.tr("Export project file")],
                          ["edit", "dup", "trash", "export"]) { [weak self] _, which in
                guard let self = self else { return }
                switch which {
                case 0: self.showRename(p)
                case 1:
                    _ = Projects.duplicate(p.id)
                    self.refresh()
                case 2: self.confirmDelete(p)
                case 3: self.showExport(p)
                default: break
                }
            }
            .show()
    }

    private func showRename(_ p: Project) {
        let field = makeField(p.name)
        Dlg(self)
            .setTitle(L10n.tr("Rename project"))
            .setView(field)
            .setPositiveButton(L10n.tr("OK")) { [weak self] _, _ in
                let name = (field.text ?? "").trimmingCharacters(in: .whitespaces)
                if !name.isEmpty { Projects.rename(p.id, name) }
                self?.refresh()
            }
            .setNegativeButton(L10n.tr("Cancel"), nil)
            .show()
    }

    private func confirmDelete(_ p: Project) {
        Dlg(self)
            .setTitle(L10n.tr("Delete project?"))
            .setMessage("\"\(p.name)\"")
            .setPositiveButton(L10n.tr("Delete")) { [weak self] _, _ in
                Projects.delete(p.id)
                self?.refresh()
            }
            .setNegativeButton(L10n.tr("Cancel"), nil)
            .show()
    }

    /// Shares the project JSON file (the original's showExport).
    private func showExport(_ info: Project) {
        let url = Projects.exportURL(info.id)
        let share = UIActivityViewController(activityItems: [url], applicationActivities: nil)
        share.popoverPresentationController?.sourceView = view
        present(share, animated: true)
    }

    /// The name input used by New / Rename (the original's makeField).
    private func makeField(_ initial: String) -> UITextField {
        let f = UITextField()
        f.text = initial
        f.placeholder = L10n.tr("New Project")
        f.font = .systemFont(ofSize: 15)
        f.textColor = argbToUIColor(C.TEXT)
        f.backgroundColor = argbToUIColor(C.CARD2)
        f.layer.cornerRadius = 10
        f.autocorrectionType = .no
        f.returnKeyType = .done
        f.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 12, height: 1))
        f.leftViewMode = .always
        f.heightAnchor.constraint(equalToConstant: 40).isActive = true
        return f
    }

    // MARK: - import (the original's documentPicker) ---------------------------

    private func pickProjectFile() {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.json],
                                                    asCopy: true)
        picker.delegate = self
        picker.allowsMultipleSelection = false
        present(picker, animated: true)
    }

    // MARK: - What's New --------------------------------------------------------

    private func maybeShowWelcome() {
        let seen = UserDefaults.standard.string(forKey: "whatsnew.seen") ?? ""
        let never = UserDefaults.standard.bool(forKey: "whatsnew.never")
        guard seen != AppInfo.version, !never else { return }
        let w = WelcomeViewController()
        w.modalPresentationStyle = .overFullScreen
        w.modalTransitionStyle = .crossDissolve
        present(w, animated: true)
    }

    // MARK: - other tabs --------------------------------------------------------

    private func cardView() -> (UIView, UIStackView) {
        let wrap = UIView()
        let stack = UIStackView()
        stack.axis = .vertical
        stack.spacing = 12
        stack.translatesAutoresizingMaskIntoConstraints = false
        wrap.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.topAnchor.constraint(equalTo: wrap.safeAreaLayoutGuide.topAnchor, constant: 18),
            stack.leadingAnchor.constraint(equalTo: wrap.leadingAnchor, constant: pad),
            stack.trailingAnchor.constraint(equalTo: wrap.trailingAnchor, constant: -pad),
        ])
        return (wrap, stack)
    }

    private func tabHeader(_ text: String) -> UILabel {
        let l = UILabel()
        l.attributedText = kerned(text, 24, .bold)
        l.textColor = argbToUIColor(C.TEXT)
        return l
    }

    private func infoCard(_ title: String, _ lines: [String]) -> UIView {
        let card = UIView()
        card.backgroundColor = argbToUIColor(C.CARD)
        card.layer.cornerRadius = 14
        let stack = UIStackView()
        stack.axis = .vertical
        stack.spacing = 6
        stack.translatesAutoresizingMaskIntoConstraints = false
        card.addSubview(stack)
        let t = UILabel()
        t.attributedText = kerned(title.uppercased(), 12, .semibold)
        t.textColor = argbToUIColor(C.GREEN)
        stack.addArrangedSubview(t)
        for ln in lines {
            let l = UILabel()
            l.text = ln
            l.font = .systemFont(ofSize: 13)
            l.textColor = argbToUIColor(C.DIM)
            l.numberOfLines = 0
            stack.addArrangedSubview(l)
        }
        NSLayoutConstraint.activate([
            stack.topAnchor.constraint(equalTo: card.topAnchor, constant: 14),
            stack.bottomAnchor.constraint(equalTo: card.bottomAnchor, constant: -14),
            stack.leadingAnchor.constraint(equalTo: card.leadingAnchor, constant: 14),
            stack.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -14),
        ])
        return card
    }

    private func buildAccount() -> UIView {
        let (wrap, stack) = cardView()
        stack.addArrangedSubview(tabHeader(L10n.tr("Account")))
        stack.addArrangedSubview(infoCard("SaikiMotion", [
            "\(L10n.tr("Version")): \(AppInfo.displayVersion)",
            AppInfo.bundleId,
            L10n.tr("Offline notice"),
        ]))
        return wrap
    }

    private func buildAi() -> UIView {
        let (wrap, stack) = cardView()
        stack.addArrangedSubview(tabHeader(L10n.tr("AI")))
        stack.addArrangedSubview(infoCard("AI", [
            "AI tools are offline in this build.",
            "Keyframe expressions (wiggle, noise, markers) cover the motion side.",
            L10n.tr("Offline notice"),
        ]))
        return wrap
    }

    private func buildCommunity() -> UIView {
        let wrap = UIView()
        let header = tabHeader(L10n.tr("Community"))
        header.translatesAutoresizingMaskIntoConstraints = false
        wrap.addSubview(header)
        NSLayoutConstraint.activate([
            header.topAnchor.constraint(equalTo: wrap.safeAreaLayoutGuide.topAnchor, constant: 14),
            header.leadingAnchor.constraint(equalTo: wrap.leadingAnchor, constant: pad),
        ])
        // the bundled SDK example effects (the real defs, read-only)
        let gallery = EffectsGalleryViewController(mode: .browse)
        addChild(gallery)
        gallery.view.translatesAutoresizingMaskIntoConstraints = false
        wrap.addSubview(gallery.view)
        NSLayoutConstraint.activate([
            gallery.view.topAnchor.constraint(equalTo: header.bottomAnchor, constant: 8),
            gallery.view.leadingAnchor.constraint(equalTo: wrap.leadingAnchor),
            gallery.view.trailingAnchor.constraint(equalTo: wrap.trailingAnchor),
            gallery.view.bottomAnchor.constraint(equalTo: wrap.bottomAnchor),
        ])
        gallery.didMove(toParent: self)
        tabChild = gallery
        return wrap
    }

    private func buildExtras() -> UIView {
        let (wrap, stack) = cardView()
        stack.addArrangedSubview(tabHeader(L10n.tr("Extras")))
        stack.addArrangedSubview(infoCard(L10n.tr("Crash reports"), [
            "\(CrashLog.reportCount()) \(L10n.tr("in the Crash folder of this app"))",
        ]))
        // language picker (the original localized the whole app; the picker
        // lives here so every tab re-renders in the chosen language)
        let rows = UIStackView()
        rows.axis = .vertical
        rows.spacing = 0
        for lang in L10n.languages {
            let b = UIButton(type: .system)
            b.setTitle((lang.code == L10n.current ? "• " : "   ") + lang.label,
                       for: .normal)
            b.setTitleColor(argbToUIColor(lang.code == L10n.current ? C.GREEN : C.DIM),
                            for: .normal)
            b.titleLabel?.font = .systemFont(ofSize: 14)
            b.contentHorizontalAlignment = .left
            b.heightAnchor.constraint(equalToConstant: 34).isActive = true
            b.addAction(UIAction { [weak self] _ in
                L10n.current = lang.code
                StoreNotification.post(.languageChanged)
                self?.refresh()
            }, for: .touchUpInside)
            rows.addArrangedSubview(b)
        }
        let langCard = UIView()
        langCard.backgroundColor = argbToUIColor(C.CARD)
        langCard.layer.cornerRadius = 14
        rows.translatesAutoresizingMaskIntoConstraints = false
        langCard.addSubview(rows)
        NSLayoutConstraint.activate([
            rows.topAnchor.constraint(equalTo: langCard.topAnchor, constant: 8),
            rows.bottomAnchor.constraint(equalTo: langCard.bottomAnchor, constant: -8),
            rows.leadingAnchor.constraint(equalTo: langCard.leadingAnchor, constant: 14),
            rows.trailingAnchor.constraint(equalTo: langCard.trailingAnchor, constant: -14),
        ])
        stack.addArrangedSubview(langCard)
        return wrap
    }

    // MARK: - helpers ------------------------------------------------------------

    /// Uppercase letter-spaced text — the original's kerned() helper.
    private func kerned(_ s: String, _ size: CGFloat = 13, _ weight: UIFont.Weight = .medium,
                        kern: CGFloat = 1.6)
        -> NSAttributedString {
        NSAttributedString(string: s.uppercased(), attributes: [
            .kern: kern,
            .font: UIFont.systemFont(ofSize: size, weight: weight),
        ])
    }

    private func relativeDate(_ d: Date) -> String {
        let f = RelativeDateTimeFormatter()
        f.unitsStyle = .abbreviated
        return f.localizedString(for: d, relativeTo: Date())
    }
}

// MARK: - document picker delegate ----------------------------------------------

extension HomeViewController: UIDocumentPickerDelegate {
    func documentPicker(_ controller: UIDocumentPickerViewController,
                        didPickDocumentsAt urls: [URL]) {
        guard let url = urls.first else { return }
        if Projects.importFile(url) != nil {
            refresh()
            toast(L10n.tr("Import"))
        } else {
            toast("Not a SaikiMotion project file")
        }
    }
}

// MARK: - toast --------------------------------------------------------------------

extension HomeViewController {
    func toast(_ text: String) {
        guard let window = appKeyWindow() else { return }
        let l = UILabel()
        l.text = "  \(text)  "
        l.font = .systemFont(ofSize: 13, weight: .medium)
        l.textColor = argbToUIColor(C.TEXT)
        l.backgroundColor = UIColor(white: 0, alpha: 0.72)
        l.layer.cornerRadius = 14
        l.clipsToBounds = true
        l.textAlignment = .center
        l.numberOfLines = 0
        l.translatesAutoresizingMaskIntoConstraints = false
        window.addSubview(l)
        NSLayoutConstraint.activate([
            l.centerXAnchor.constraint(equalTo: window.centerXAnchor),
            l.bottomAnchor.constraint(equalTo: window.safeAreaLayoutGuide.bottomAnchor, constant: -90),
            l.leadingAnchor.constraint(greaterThanOrEqualTo: window.leadingAnchor, constant: 24),
            l.trailingAnchor.constraint(lessThanOrEqualTo: window.trailingAnchor, constant: -24),
        ])
        UIView.animate(withDuration: 0.25, delay: 1.8, options: [.curveEaseIn]) {
            l.alpha = 0
        } completion: { _ in
            l.removeFromSuperview()
        }
    }
}

// MARK: - home tab bar button ---------------------------------------------------------

/// One bottom-bar item: custom icon above an uppercase letter-spaced label.
/// Orange when selected, gray when not — the original's five-tab bar.
/// (TapView is the UI kit's closure-tappable view — the same mechanism the
/// original used everywhere.)
private final class HomeTabButton: TapView {

    var icon: String = "" { didSet { iconView.name = icon; iconView.setNeedsDisplay() } }
    var on = false {
        didSet {
            iconView.color = on ? C.GREEN : C.DIM
            iconView.setNeedsDisplay()
            label.textColor = argbToUIColor(on ? C.GREEN : C.DIM)
        }
    }
    var tapped: (() -> Void)?

    private let iconView = TabIcon()
    private let label = UILabel()

    init() {
        super.init(frame: .zero)
        onClick = { [weak self] in self?.tapped?() }
        iconView.translatesAutoresizingMaskIntoConstraints = false
        addSubview(iconView)
        label.font = .systemFont(ofSize: 9, weight: .semibold)
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        addSubview(label)

        NSLayoutConstraint.activate([
            iconView.centerXAnchor.constraint(equalTo: centerXAnchor),
            iconView.topAnchor.constraint(equalTo: topAnchor, constant: 7),
            iconView.widthAnchor.constraint(equalToConstant: 24),
            iconView.heightAnchor.constraint(equalToConstant: 24),
            label.topAnchor.constraint(equalTo: iconView.bottomAnchor, constant: 3),
            label.centerXAnchor.constraint(equalTo: centerXAnchor),
            label.leadingAnchor.constraint(greaterThanOrEqualTo: leadingAnchor, constant: 2),
            label.trailingAnchor.constraint(lessThanOrEqualTo: trailingAnchor, constant: -2),
        ])
    }

    func setLabel(_ a: NSAttributedString) {
        label.attributedText = a
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.8
        setNeedsLayout()
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

/// The five tab icons, drawn with CGContext in the same stroke style as the
/// editor's icon kit (person / film frame / sparkles / two people / grid with +).
private final class TabIcon: UIView {

    var color: Int32 = C.DIM
    var name: String = ""

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let s = min(rect.width, rect.height)
        c.saveGState()
        c.translateBy(x: rect.midX - s / 2, y: rect.midY - s / 2)
        c.scaleBy(x: s / 24, y: s / 24)
        c.setStrokeColor(argbToUIColor(color).cgColor)
        c.setFillColor(argbToUIColor(color).cgColor)
        c.setLineWidth(1.8)
        c.setLineCap(.round)
        c.setLineJoin(.round)

        func star(_ cx: CGFloat, _ cy: CGFloat, _ r: CGFloat) {
            let p = UIBezierPath()
            p.move(to: CGPoint(x: cx, y: cy - r))
            p.addQuadCurve(to: CGPoint(x: cx + r, y: cy), controlPoint: CGPoint(x: cx + r * 0.18, y: cy - r * 0.18))
            p.addQuadCurve(to: CGPoint(x: cx, y: cy + r), controlPoint: CGPoint(x: cx + r * 0.18, y: cy + r * 0.18))
            p.addQuadCurve(to: CGPoint(x: cx - r, y: cy), controlPoint: CGPoint(x: cx - r * 0.18, y: cy + r * 0.18))
            p.addQuadCurve(to: CGPoint(x: cx, y: cy - r), controlPoint: CGPoint(x: cx - r * 0.18, y: cy - r * 0.18))
            p.close()
            c.addPath(p.cgPath)
            c.fillPath()
        }

        switch name {
        case "account":
            c.strokeEllipse(in: CGRect(x: 8.4, y: 3.6, width: 7.2, height: 7.2))
            let body = UIBezierPath()
            body.addArc(withCenter: CGPoint(x: 12, y: 21), radius: 8.4,
                        startAngle: .pi, endAngle: 0, clockwise: true)
            c.addPath(body.cgPath)
            c.strokePath()
        case "film":
            let r = UIBezierPath(roundedRect: CGRect(x: 3.5, y: 4.5, width: 17, height: 15),
                                 cornerRadius: 2.5)
            c.addPath(r.cgPath)
            c.strokePath()
            let inner = UIBezierPath(roundedRect: CGRect(x: 8, y: 7.5, width: 8, height: 9),
                                     cornerRadius: 1.5)
            c.addPath(inner.cgPath)
            c.strokePath()
            for y in [CGFloat(7), CGFloat(13)] {
                c.fill(CGRect(x: 5.4, y: y, width: 1.6, height: 2.6))
                c.fill(CGRect(x: 17, y: y, width: 1.6, height: 2.6))
            }
        case "sparkle_tab":
            star(10, 10, 6.5)
            star(17, 16.5, 3.6)
            c.setLineWidth(1.6)
            let plus = UIBezierPath()
            plus.move(to: CGPoint(x: 17.5, y: 6.5))
            plus.addLine(to: CGPoint(x: 21.5, y: 6.5))
            plus.move(to: CGPoint(x: 19.5, y: 4.5))
            plus.addLine(to: CGPoint(x: 19.5, y: 8.5))
            c.addPath(plus.cgPath)
            c.strokePath()
        case "people":
            c.setLineWidth(1.6)
            c.strokeEllipse(in: CGRect(x: 4.2, y: 6.2, width: 6, height: 6))
            let b1 = UIBezierPath()
            b1.addArc(withCenter: CGPoint(x: 7.2, y: 19.5), radius: 6.4,
                      startAngle: .pi, endAngle: 0, clockwise: true)
            c.addPath(b1.cgPath)
            c.strokePath()
            c.strokeEllipse(in: CGRect(x: 13.8, y: 7.2, width: 5.4, height: 5.4))
            let b2 = UIBezierPath()
            b2.addArc(withCenter: CGPoint(x: 16.5, y: 19.5), radius: 5.8,
                      startAngle: .pi * 1.12, endAngle: -0.12 * .pi, clockwise: true)
            c.addPath(b2.cgPath)
            c.strokePath()
        case "grid_plus":
            for (x, y) in [(CGFloat(4), CGFloat(4)), (13.5, 4), (4, 13.5)] {
                let r = UIBezierPath(roundedRect: CGRect(x: x, y: y, width: 6.5, height: 6.5),
                                     cornerRadius: 1.6)
                c.addPath(r.cgPath)
                c.strokePath()
            }
            let plus = UIBezierPath()
            plus.move(to: CGPoint(x: 16.75, y: 13.5))
            plus.addLine(to: CGPoint(x: 16.75, y: 20))
            plus.move(to: CGPoint(x: 13.5, y: 16.75))
            plus.addLine(to: CGPoint(x: 20, y: 16.75))
            c.addPath(plus.cgPath)
            c.strokePath()
        default:
            break
        }
        c.restoreGState()
    }
}

// MARK: - big action button --------------------------------------------------------

/// Full-width action button used by NEW PROJECT (orange) and
/// IMPORT PROJECT FILE (the original's dark brown + orange text).
private final class HomeBigButton: TapView {

    var title: NSAttributedString? { didSet { label.attributedText = title; setNeedsDisplay() } }
    var bg: Int32 = C.GREEN { didSet { setNeedsDisplay() } }
    var fg: Int32 = Int32(bitPattern: 0xFF141414) { didSet { setNeedsDisplay() } }
    var icon: String? { didSet { setNeedsDisplay() } }
    var tapped: (() -> Void)?

    private let label = UILabel()

    init() {
        super.init(frame: .zero)
        onClick = { [weak self] in self?.tapped?() }
        layer.cornerRadius = 23
        clipsToBounds = true
        label.textAlignment = .center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.8
        addSubview(label)
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        setNeedsDisplay()
        let size = label.sizeThatFits(CGSize(width: bounds.width - 100, height: bounds.height))
        let shift: CGFloat = icon != nil ? 12 : 0
        label.frame = CGRect(x: bounds.midX - size.width / 2 + shift,
                             y: bounds.midY - size.height / 2,
                             width: size.width, height: size.height)
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        c.setFillColor(argbToUIColor(bg).cgColor)
        c.fill(bounds)
        label.textColor = argbToUIColor(fg)
        if let ic = icon {
            Icons.draw(c, ic, 26, bounds.midY, 20, fg)
        }
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - What's New ---------------------------------------------------------------------

/// The changelog card shown once per version — dark card, orange title,
/// scrollable notes, "Don't show again" + orange "Close" (the original's
/// WelcomeViewController).
final class WelcomeViewController: UIViewController {

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(white: 0, alpha: 0.6)

        let card = UIView()
        card.backgroundColor = argbToUIColor(C.PANEL)
        card.layer.cornerRadius = 20
        card.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(card)

        let title = UILabel()
        title.attributedText = NSAttributedString(string: "What's New".uppercased(), attributes: [
            .kern: 1.6, .font: UIFont.systemFont(ofSize: 17, weight: .bold),
        ])
        title.textColor = argbToUIColor(C.GREEN)
        title.translatesAutoresizingMaskIntoConstraints = false
        card.addSubview(title)

        let ver = UILabel()
        ver.text = "\(AppInfo.version) (\(AppInfo.build))"
        ver.font = .systemFont(ofSize: 12)
        ver.textColor = argbToUIColor(C.DIM)
        ver.translatesAutoresizingMaskIntoConstraints = false
        card.addSubview(ver)

        let body = UILabel()
        body.numberOfLines = 0
        body.attributedText = lineSpaced(notes())
        body.textColor = argbToUIColor(C.TEXT)
        body.font = .systemFont(ofSize: 13)
        body.translatesAutoresizingMaskIntoConstraints = false
        let scroll = UIScrollView()
        scroll.translatesAutoresizingMaskIntoConstraints = false
        scroll.addSubview(body)
        card.addSubview(scroll)

        let neverBtn = UIButton(type: .system)
        neverBtn.setTitle(L10n.tr("Don't show again"), for: .normal)
        neverBtn.setTitleColor(argbToUIColor(C.TEXT), for: .normal)
        neverBtn.titleLabel?.font = .systemFont(ofSize: 14, weight: .semibold)
        neverBtn.backgroundColor = argbToUIColor(C.CARD2)
        neverBtn.layer.cornerRadius = 20
        neverBtn.translatesAutoresizingMaskIntoConstraints = false
        neverBtn.addAction(UIAction { [weak self] _ in
            UserDefaults.standard.set(true, forKey: "whatsnew.never")
            self?.dismiss(animated: true)
        }, for: .touchUpInside)
        card.addSubview(neverBtn)

        let closeBtn = UIButton(type: .system)
        closeBtn.setTitle(L10n.tr("Close"), for: .normal)
        closeBtn.setTitleColor(argbToUIColor(Int32(bitPattern: 0xFF141414)), for: .normal)
        closeBtn.titleLabel?.font = .systemFont(ofSize: 14, weight: .bold)
        closeBtn.backgroundColor = argbToUIColor(C.GREEN)
        closeBtn.layer.cornerRadius = 20
        closeBtn.translatesAutoresizingMaskIntoConstraints = false
        closeBtn.addAction(UIAction { [weak self] _ in
            UserDefaults.standard.set(AppInfo.version, forKey: "whatsnew.seen")
            self?.dismiss(animated: true)
        }, for: .touchUpInside)
        card.addSubview(closeBtn)

        NSLayoutConstraint.activate([
            card.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            card.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            card.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.88),
            card.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.66),
            title.topAnchor.constraint(equalTo: card.topAnchor, constant: 18),
            title.leadingAnchor.constraint(equalTo: card.leadingAnchor, constant: 18),
            ver.centerYAnchor.constraint(equalTo: title.centerYAnchor),
            ver.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -18),
            scroll.topAnchor.constraint(equalTo: title.bottomAnchor, constant: 12),
            scroll.leadingAnchor.constraint(equalTo: card.leadingAnchor, constant: 18),
            scroll.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -18),
            scroll.bottomAnchor.constraint(equalTo: neverBtn.topAnchor, constant: -14),
            body.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor),
            body.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor),
            body.leadingAnchor.constraint(equalTo: scroll.contentLayoutGuide.leadingAnchor),
            body.trailingAnchor.constraint(equalTo: scroll.contentLayoutGuide.trailingAnchor),
            body.widthAnchor.constraint(equalTo: scroll.frameLayoutGuide.widthAnchor),
            neverBtn.leadingAnchor.constraint(equalTo: card.leadingAnchor, constant: 18),
            neverBtn.bottomAnchor.constraint(equalTo: card.bottomAnchor, constant: -18),
            neverBtn.heightAnchor.constraint(equalToConstant: 40),
            closeBtn.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -18),
            closeBtn.bottomAnchor.constraint(equalTo: card.bottomAnchor, constant: -18),
            closeBtn.heightAnchor.constraint(equalToConstant: 40),
            closeBtn.widthAnchor.constraint(equalTo: neverBtn.widthAnchor),
            closeBtn.leadingAnchor.constraint(equalTo: neverBtn.trailingAnchor, constant: 10),
        ])
    }

    private func lineSpaced(_ s: String) -> NSAttributedString {
        let p = NSMutableParagraphStyle()
        p.lineSpacing = 4
        p.paragraphSpacing = 8
        return NSAttributedString(string: s, attributes: [.paragraphStyle: p])
    }

    private func notes() -> String {
        """
        The full app, rebuilt from source.

        - Projects: create, rename, duplicate, export and import project files.
        - The complete editor: timeline, keyframes, graph editor and expressions.
        - 70+ GPU effects with the effect SDK and its IDE.
        - Text with per-letter animations, flares, particles and water.
        - 3D models (GLB and ABC), VDB volumes and cameras.
        - Motion blur and MP4 export with audio.

        Works fully offline. No account needed.
        """
    }
}
