// EffectThumbs.swift — before/after thumbnails for the effect browser (Effects).
//
// Renders every effect in the catalog against generated sample images on a
// background GL context, offscreen, then hands UIImages to `cache` — the
// cards pick them up asynchronously. `__orig:<id>` holds the untouched
// sample; `<id>` holds the processed result. Shader problems land in
// Registry.errors with the same pass, so the browser and the SDK IDE show
// one consistent story.

import UIKit
import OpenGLES
import GLKit
import Foundation

enum EffectThumbs {

    static var cache: [String: UIImage] = [:]
    static var lastError = ""

    private static let queue = DispatchQueue(label: "saiki.thumbs", qos: .userInitiated)
    private static var generating = false

    static func origKey(_ id: String) -> String { "__orig:" + id }

    static func ready(_ id: String) -> Bool { cache[id] != nil }

    /// The raw sample image for an effect id (same variant the generation
    /// pass used for it, so before/after cards match).
    static func raw(_ id: String) -> UIImage? {
        sampleAt(id.hashValue)
    }

    /// Editor spelling: (vc, preview, done).
    static func generate(_ vc: UIViewController, _ preview: PreviewView?,
                         _ done: @escaping () -> Void) {
        generate(done)
    }

    /// SDK IDE spelling: (done).
    static func generate(_ done: @escaping () -> Void) {
        queue.async {
            runGeneration()
            DispatchQueue.main.async(execute: done)
        }
    }

    /// Renders the whole catalog (skips ids already cached).
    private static func runGeneration() {
        guard !generating else { return }
        generating = true
        defer { generating = false }

        guard let ctx = GLContext.make() else {
            lastError = "GL unavailable"
            return
        }
        let prev = EAGLContext.current()
        EAGLContext.setCurrent(ctx)
        defer { EAGLContext.setCurrent(prev) }

        let size = 256
        let target = Gl.Target(size, size)
        guard let quad = GLProgram(vertex: GLProgram.defaultVertex, fragment: """
precision mediump float;
varying vec2 vUv;
uniform sampler2D uTex;
uniform float uFlipY;
uniform mat3 uMat;
uniform vec2 uQuad;
uniform float uAspect;
void main() {
    vec2 p = vec2(vUv.x, mix(vUv.y, 1.0 - vUv.y, uFlipY));
    vec2 w = (uMat * vec3((vUv - 0.5) * uQuad, 1.0)).xy;
    gl_Position = vec4(w.x / uAspect, w.y, 0.0, 1.0);
    gl_FragColor = texture2D(uTex, p);
}
""") else {
            lastError = "quad shader failed"
            return
        }

        // sample textures
        var sampleTex: [GLuint] = []
        for i in 0..<3 {
            if let t = Gl.upload(sample(String(i))) {
                sampleTex.append(t)
            }
        }
        guard !sampleTex.isEmpty else {
            lastError = "sample upload failed"
            return
        }

        for def in Registry.order {
            let key = def.id
            if cache[key] != nil { continue }
            // pass-through defs (remap, particles, transform) show the raw sample
            let passThrough = def.kind == 1 || def.glsl.contains("return src(uv);") && def.props.isEmpty
            if passThrough && def.id != "tile" {
                cacheMutex.lock()
                cache[key] = sampleAt(key.hashValue)
                cache[origKey(def.id)] = sampleAt(key.hashValue)
                cacheMutex.unlock()
                continue
            }

            let (src, _) = Gl.effectShaderSource(def)
            guard let prog = GLProgram(vertex: GLProgram.defaultVertex, fragment: src) else {
                Registry.noteError(def.id, Gl.lastShaderLog)
                continue
            }

            let which = abs(def.id.hashValue) % sampleTex.count
            let inTex = sampleTex[which]

            // 1 — draw the sample into the target
            target.bind()
            glDisable(GLenum(GL_BLEND))
            glViewport(0, 0, GLsizei(size), GLsizei(size))
            quad.use()
            quad.setFloat("uFlipY", 1)
            quad.setMat3("uMat", [1, 0, 0, 0, 1, 0, 0, 0, 1])
            quad.setVec2("uQuad", 2, 2)
            quad.setFloat("uAspect", 1)
            quad.setTexture("uTex", inTex, 0)
            Gl.drawQuad(quad)

            let before = target.readImage()

            // 2 — apply the effect with default parameter values
            prog.use()
            prog.setTexture("uTex", target.tex, 0)
            prog.setVec2("uRes", Float(size), Float(size))
            prog.setFloat("uTime", 1.7)
            prog.setFloat("uHas0", 0)
            prog.setFloat("uHas1", 0)
            for pd in def.props {
                prog.setFloat(pd.key, pd.def)
            }
            for cp in def.colors {
                let d = UInt32(bitPattern: cp.def)
                prog.setVec4(cp.key,
                             Float((d >> 16) & 0xFF) / 255,
                             Float((d >> 8) & 0xFF) / 255,
                             Float(d & 0xFF) / 255,
                             Float((d >> 24) & 0xFF) / 255)
            }
            Gl.drawQuad(prog)

            let after = target.readImage()

            cacheMutex.lock()
            if let b = before { cache[origKey(def.id)] = b }
            if let a = after { cache[def.id] = a }
            cacheMutex.unlock()
        }

        // free sample textures on this context
        for t in sampleTex { Gl.delete(t) }
    }

    private static let cacheMutex = NSLock()

    // MARK: - sample images
    //
    // Deterministic "photos" so every install shows the same cards: a dusk
    // landscape, a colorful still-life and a portrait-ish gradient with
    // strong highlights and shadows (good for glow / keying / color fx).

    private static var sampleImages: [String: UIImage] = [:]

    static func sample(_ variant: String) -> UIImage {
        if let img = sampleImages[variant] { return img }
        let n = 320
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 1
        let r = UIGraphicsImageRenderer(size: CGSize(width: n, height: n), format: fmt)
        let img = r.image { ctx in
            let c = ctx.cgContext
            let v = Int(variant.last?.wholeNumberValue ?? 0) % 3
            if v == 0 {
                // dusk hills
                let sky = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(),
                                     colors: [UIColor(red: 1.0, green: 0.62, blue: 0.35, alpha: 1).cgColor,
                                              UIColor(red: 0.23, green: 0.16, blue: 0.42, alpha: 1).cgColor] as CFArray,
                                     locations: [0, 1])!
                c.drawLinearGradient(sky, start: .zero, end: CGPoint(x: 0, y: CGFloat(n)), options: [])
                c.setFillColor(UIColor(red: 1, green: 0.9, blue: 0.6, alpha: 1).cgColor)
                c.fillEllipse(in: CGRect(x: CGFloat(n) * 0.62, y: CGFloat(n) * 0.22, width: 46, height: 46))
                c.setFillColor(UIColor(red: 0.12, green: 0.1, blue: 0.2, alpha: 1).cgColor)
                c.move(to: CGPoint(x: 0, y: CGFloat(n) * 0.72))
                c.addLine(to: CGPoint(x: CGFloat(n) * 0.35, y: CGFloat(n) * 0.5))
                c.addLine(to: CGPoint(x: CGFloat(n) * 0.62, y: CGFloat(n) * 0.76))
                c.addLine(to: CGPoint(x: CGFloat(n), y: CGFloat(n) * 0.6))
                c.addLine(to: CGPoint(x: CGFloat(n), y: CGFloat(n)))
                c.addLine(to: CGPoint(x: 0, y: CGFloat(n)))
                c.closePath()
                c.fillPath()
                c.setFillColor(UIColor.black.withAlphaComponent(0.35).cgColor)
                c.fill(CGRect(x: 0, y: CGFloat(n) * 0.86, width: CGFloat(n), height: CGFloat(n) * 0.14))
            } else if v == 1 {
                // still life blocks
                let g = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(),
                                   colors: [UIColor(red: 0.1, green: 0.12, blue: 0.16, alpha: 1).cgColor,
                                            UIColor(red: 0.24, green: 0.28, blue: 0.34, alpha: 1).cgColor] as CFArray,
                                   locations: [0, 1])!
                c.drawLinearGradient(g, start: .zero, end: CGPoint(x: CGFloat(n), y: CGFloat(n)), options: [])
                let cols: [UIColor] = [UIColor(red: 0.95, green: 0.3, blue: 0.32, alpha: 1),
                                       UIColor(red: 0.98, green: 0.75, blue: 0.2, alpha: 1),
                                       UIColor(red: 0.25, green: 0.65, blue: 0.9, alpha: 1),
                                       UIColor(red: 0.4, green: 0.85, blue: 0.55, alpha: 1)]
                let rects = [CGRect(x: 30, y: 60, width: 110, height: 110),
                             CGRect(x: 160, y: 40, width: 90, height: 140),
                             CGRect(x: 80, y: 170, width: 160, height: 100),
                             CGRect(x: 210, y: 180, width: 70, height: 70)]
                for (i, rc) in rects.enumerated() {
                    c.setFillColor(cols[i % cols.count].cgColor)
                    c.fill(rc)
                }
            } else {
                // portrait gradient + bright window + skin tones
                let g = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(),
                                   colors: [UIColor(red: 0.85, green: 0.78, blue: 0.72, alpha: 1).cgColor,
                                            UIColor(red: 0.35, green: 0.3, blue: 0.28, alpha: 1).cgColor] as CFArray,
                                   locations: [0, 1])!
                c.drawLinearGradient(g, start: CGPoint(x: 0, y: 0), end: CGPoint(x: CGFloat(n), y: CGFloat(n)),
                                     options: [])
                c.setFillColor(UIColor(white: 1, alpha: 0.95).cgColor)
                c.fill(CGRect(x: CGFloat(n) * 0.66, y: 24, width: 74, height: 96))
                c.setFillColor(UIColor(red: 0.72, green: 0.5, blue: 0.4, alpha: 1).cgColor)
                c.fillEllipse(in: CGRect(x: CGFloat(n) * 0.3, y: CGFloat(n) * 0.34, width: 120, height: 150))
                c.setFillColor(UIColor(red: 0.2, green: 0.16, blue: 0.14, alpha: 1).cgColor)
                c.fillEllipse(in: CGRect(x: CGFloat(n) * 0.3 + 18, y: CGFloat(n) * 0.34 + 52, width: 26, height: 16))
                c.fillEllipse(in: CGRect(x: CGFloat(n) * 0.3 + 76, y: CGFloat(n) * 0.34 + 52, width: 26, height: 16))
            }
        }
        sampleImages[variant] = img
        return img
    }

    /// Sample image by any hashable seed (stable within one run).
    static func sampleAt(_ seed: Int) -> UIImage {
        sample(String(abs(seed) % 3))
    }

    /// Drops cached thumbs (effect edited / deleted).
    static func invalidate() {
        cacheMutex.lock()
        cache.removeAll()
        cacheMutex.unlock()
    }
}
