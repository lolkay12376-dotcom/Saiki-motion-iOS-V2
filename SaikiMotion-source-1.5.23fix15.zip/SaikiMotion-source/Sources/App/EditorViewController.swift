// iOS port of EditorActivity.kt — SaikiMotion
// The whole editor screen: top bar, preview area (AspectLayout + PreviewView + OverlayView),
// transport row, timeline, bottom tool bar, the side-railed property panel (Edit / Transform /
// Effects / Blending / Speed / Graph), the bezier graph editor, effects browser with rendered
// thumbnails, custom effect import/export + creation, presets, the text tool with fonts,
// the color picker with eyedropper, keyframes/auto-key, expressions, markers, audio playback,
// the undo stack, the playback loop and every import picker.
//
// PORT NOTES (lifecycle + platform):
//  - Activity → UIViewController built 100% programmatically. onCreate → viewDidLoad,
//    onResume → viewWillAppear, onPause → viewWillDisappear, onDestroy → deinit.
//  - onBackPressed → onBack(): closes the panel / deselects / pops or dismisses the VC.
//    The navigation bar is hidden while the editor is on screen (the editor has its own top bar).
//  - onConfigurationChanged (full buildUi() rebuild) → RootLayout computes the portrait and
//    landscape layouts dynamically in layoutSubviews, so no rebuild is needed on rotation.
//  - windowSoftInputMode adjustResize → UIResponder.keyboardWillShow/Hide notifications that
//    shrink the root layout (and the full-screen Effects panel) above the keyboard.
//  - Choreographer.postFrameCallback → CADisplayLink on .main/.common with a weak proxy target
//    (the link retains the proxy, the proxy does not retain the VC, so deinit can invalidate).
//  - android.media.MediaPlayer → AVAudioPlayer: players are created + prepared on a background
//    thread (prepareAsync parity); SEEK_CLOSEST → currentTime assignment; drift window 140 ms.
//  - ACTION_GET_CONTENT → UIDocumentPickerViewController(asCopy: true); the Kotlin
//    ContentResolver copies go through ProjectIO.copyMediaIntoSandbox (same "<ts>_<name>"
//    and "<ts>_font.ttf" naming).
//  - MediaMetadataRetriever duration → AVAsset.duration (deprecated-but-synchronous accessor,
//    guide precedent).
//  - PixelCopy.request(preview, ...) → a drawHierarchy snapshot of the GLKView read through a
//    1x1 bitmap context (eyedropper).
//  - MediaStore Downloads/Music writes → <Documents>/SaikiMotion (ProjectIO convention; the
//    location string in the toasts mirrors it).
//  - onSaveInstanceState/savedInstanceState: iOS does not restore editor state after a kill;
//    the selected layer only survives within a session (selId is a plain property).
//  - Kotlin `selectedId` / `autoKey` properties renamed selId / autoKeyOn (the TimelineHost /
//    EditHost protocols require methods with those exact names; a stored property with the same
//    name as a method is not a safe Swift pattern).
//  - Dlg is an overlay on the key window (not a presented VC), so the Kotlin
//    `setView(ScrollView(box))` wrappers are dropped — Dlg wraps long content in its own
//    CapScroll already.

import UIKit
import AVFoundation
import CoreMedia
import UniformTypeIdentifiers
import PhotosUI

// Key used to attach EditWatcher targets to their UITextFields (UIControl does NOT retain its
// targets; associating the watcher keeps it alive exactly as long as the field).
private var EditorFieldWatchKey: UInt8 = 0

// Panel ids (Kotlin P_*) and picker request codes (Kotlin R_*), at file scope so closures with
// [weak self] capture lists can reference them without an implicit-self error.
private let P_NONE = 0; private let P_MEDIA = 1; private let P_SHAPES = 2; private let P_EDIT = 3
private let P_XFORM = 4; private let P_FX = 5; private let P_BLEND = 6; private let P_SPEED = 7; private let P_GRAPH = 8
private let R_VIDEO = 51; private let R_IMAGE = 52; private let R_GLB = 53; private let R_FX = 54; private let R_PRESET = 55
private let R_BEAT = 57; private let R_AUDIOFILE = 58; private let R_FONT = 59

/// Kotlin ACTION_GET_CONTENT "*/*" for the .glb picker: any file, GLB files first.
private func glbTypes() -> [UTType] {
    var ts: [UTType] = [.data]
    if let g = UTType(filenameExtension: "glb") { ts.insert(g, at: 0) }
    return ts
}

/// TextWatcher replacement for UITextField editing-changed events.
private final class EditWatcher: NSObject {
    private let f: (String) -> Void
    init(_ f: @escaping (String) -> Void) { self.f = f }
    @objc func change(_ t: UITextField) { f(t.text ?? "") }
}

/// CADisplayLink target that does not retain the view controller (see PORT NOTES above).
private final class DisplayLinkProxy: NSObject {
    weak var vc: EditorViewController?
    @objc func tick(_ link: CADisplayLink) { vc?.doFrame() }
}

/// Sweep-gradient circle that opens the full color picker (Android GradientDrawable SWEEP_GRADIENT).
private final class RainbowCircleView: TapView {
    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let r = min(bounds.width, bounds.height) / 2 - 1
        c.saveGState()
        c.translateBy(x: bounds.width / 2, y: bounds.height / 2)
        let n = 36
        for i in 0..<n {
            let a0 = CGFloat(i) / CGFloat(n) * 2 * .pi
            let a1 = CGFloat(i + 1) / CGFloat(n) * 2 * .pi
            c.setFillColor(UIColor(hue: CGFloat(i) / CGFloat(n), saturation: 1, brightness: 1, alpha: 1).cgColor)
            c.move(to: .zero)
            c.addArc(center: .zero, radius: r, startAngle: a0, endAngle: a1, clockwise: false)
            c.closePath()
            c.fillPath()
        }
        c.restoreGState()
    }
}

/// LinearLayout-with-weights replacement for the editor root. Lays out the fixed-height rows
/// and the two weighted areas (preview 1.0 / timeline 1.15); landscape splits the width
/// 46% / 54% exactly like the Kotlin orientation branch. panelBox height -1 = dynamic
/// (300 pt portrait / 220 pt landscape, like the Kotlin per-orientation LayoutParams).
/// Hidden views and views that were re-parented (the full-screen Effects panel) are skipped.
private final class RootLayout: UIView {
    var top: UIView? = nil
    var previewBox: UIView? = nil
    var tr: UIView? = nil
    var timeline: UIView? = nil
    var toolbarBox: UIView? = nil
    var panelBox: UIView? = nil

    override init(frame: CGRect) { super.init(frame: frame) }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    private func panelH() -> CGFloat { bounds.width > bounds.height ? 220 : 300 }

    private func lay(_ its: [(UIView?, CGFloat, Float)], _ r: CGRect) {
        let vis: [(UIView, CGFloat, Float)] = its.compactMap { it in
            guard let v = it.0, v.superview === self, !v.isHidden else { return nil }
            return (v, it.1, it.2)
        }
        var fixed: CGFloat = 0
        var tw: Float = 0
        for (_, h, w) in vis {
            let hh = h < 0 ? panelH() : h
            if hh > 0 { fixed += hh } else { tw += w }
        }
        let free = max(0, r.height - fixed)
        var y = r.minY
        for (v, h, w) in vis {
            let hh: CGFloat
            if h < 0 { hh = panelH() }
            else if h > 0 { hh = h }
            else { hh = tw > 0 ? free * CGFloat(w / tw) : 0 }
            v.frame = CGRect(x: r.minX, y: y, width: r.width, height: hh)
            y += hh
        }
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        let area = CGRect(x: 0, y: 0, width: bounds.width, height: bounds.height)
        if bounds.width > bounds.height {
            let lw = floor(area.width * 0.46)
            lay([(top, 52, 0), (previewBox, 0, 1), (tr, 48, 0)],
                CGRect(x: 0, y: 0, width: lw, height: area.height))
            lay([(timeline, 0, 1.15), (toolbarBox, 76, 0), (panelBox, -1, 0)],
                CGRect(x: lw, y: 0, width: area.width - lw, height: area.height))
        } else {
            lay([(top, 52, 0), (previewBox, 0, 1), (tr, 48, 0), (timeline, 0, 1.15),
                 (toolbarBox, 76, 0), (panelBox, -1, 0)], area)
        }
    }
}

final class EditorViewController: UIViewController, EditHost, TimelineHost, UIDocumentPickerDelegate, PHPickerViewControllerDelegate {
    private var projectId: String
    private var preview: PreviewView!
    private var overlay: OverlayView!
    private var aspect: AspectLayout!
    private var timeline: TimelineView!
    private var titleView: UILabel!
    private var subView: UILabel!
    private var playIcon: IconView!
    private var markIcon: IconView!
    private var cubeIcon: IconView!
    private var mbToggle: PillToggle!
    private var parentIcon: IconView!
    private var moreIcon: IconView!
    private var gearIcon: IconView!
    private var renderBtn: UIView!
    private var actionBar: UIView!
    private var qualityChip: ChipView!
    private var toolbarBox: UIScrollView!
    private var toolbarRow: UIStackView!
    private var panelBox: UIView!
    private var panelList: UIStackView!
    private var diamondSide: IconView!
    private var xformTab = 0
    private var scaleLinked = true
    private var sepDims = true
    private var moveMode = false

    private var selId = -1                 // PORT NOTE: Kotlin `selectedId` property
    private var panel = 0
    private var fxTab = 0
    private var fxCat = 0                  // kept for parity (unused in Kotlin too)
    private var playing = false
    private var lastTs: Double = 0
    private var autoKeyOn = false          // PORT NOTE: Kotlin `autoKey` property
    private var quality = 1
    private var graphProp = ""
    private var curveClip: Key? = nil
    private var graphKey = 0
    private var selKey = ""
    private var screen: UIView!
    private var rootLayout: RootLayout!    // Kotlin `panelHome` (panelBox's non-full parent)
    private var textTab = 0
    private var players: [Int: AVAudioPlayer] = [:]
    private var startingAudio = Set<Int>()
    private var prepared = Set<Int>()
    private let audioLead = 110
    private var multi: [Int] = []          // LinkedHashSet semantics: ordered + unique
    private var multiMode = false
    private var clipboard: [Layer] = []

    private var expanded = Set<String>()
    private final class Row {
        let slider: RulerSlider
        let d: PropDef
        let layer: Layer
        init(_ slider: RulerSlider, _ d: PropDef, _ layer: Layer) {
            self.slider = slider; self.d = d; self.layer = layer
        }
    }
    private var rows: [Row] = []
    private var undoStack: [String] = []   // Kotlin `undo`
    private var redoStack: [String] = []   // Kotlin `redo`

    private var fxQuery = ""
    private final class FxSnap {
        let id: String
        let tracks: [(String, JObj)]
        let inputs: [String: Int]
        let off: Bool
        init(_ id: String, _ tracks: [(String, JObj)], _ inputs: [String: Int], _ off: Bool) {
            self.id = id; self.tracks = tracks; self.inputs = inputs; self.off = off
        }
    }
    private var fxClip: [FxSnap] = []

    private var pendingPick = 0
    private var kbInset: CGFloat = 0
    private var rootBottom: NSLayoutConstraint? = nil
    private var displayLink: CADisplayLink? = nil
    private var linkProxy: DisplayLinkProxy? = nil

    // ---- autosave architecture (rounds 11/14/19) ----
    private var dirty = false                   // unsaved edits exist
    private var lastEditTs: CFAbsoluteTime = 0  // when the last edit landed
    private var idleSaving = false              // re-entry guard (IDLE_SAVE lesson)

    // ================================================================ init / lifecycle

    init(projectId: String) {
        self.projectId = projectId
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    override func viewDidLoad() {
        super.viewDidLoad()
        Registry.initialize()      // Kotlin: Registry.init(this)
        CrashLog.install()         // R19: signal-safe crash logger, before any UI work
        FreezeWatchdog.start()     // R15/R19: freeze detection (heartbeat-change rule)
        // Kotlin also installs CrashLog here; HomeViewController owns the single install on iOS
        // (NSSetUncaughtExceptionHandler is idempotent anyway) — PORT NOTE.
        Editor.project = Projects.load(projectId) ?? Project(name: "Untitled")
        Editor.sceneIndex = 0
        Editor.time = 0
        selId = -1
        buildUi()
        refreshAll()
        safe("previews") {
            EffectThumbs.generate(self, preview) { [weak self] in
                if let self = self, self.panel == P_FX && self.fxTab == 1 { self.refreshPanel() }
            }
        }
        NotificationCenter.default.addObserver(self, selector: #selector(kbChanged(_:)),
                                               name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(kbChanged(_:)),
                                               name: UIResponder.keyboardWillHideNotification, object: nil)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
        preview.requestDraw()      // Kotlin: preview.onResume() (GLKView has no pause; redraw)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
        playing = false
        stopAudio()
        displayLink?.isPaused = true
        playIcon.set("play", C.TEXT)
        preview.releaseVideos()    // Kotlin: preview.onPause()
        Projects.save(projectId, Editor.project)
        dirty = false              // the explicit save above covers everything
        FreezeWatchdog.setDirty(false)
    }

    // ================================================================ autosave (rounds 11/14/19)

    /// Every edit funnels through pushUndo()/beginEdit(), so this is the one
    /// place that marks the project dirty. Saving is fully decoupled from
    /// editing — see maybeIdleSave().
    private func markDirty() {
        dirty = true
        lastEditTs = CFAbsoluteTimeGetCurrent()
        FreezeWatchdog.setDirty(true)
        CrashLog.note("edit")
    }

    /// Round-19 freeze fix: edits NEVER save synchronously. (The shipped
    /// binary ran the whole project serialization inside refreshTitle() on
    /// the main thread every second edit — the "anything I do freezes" bug.)
    /// Instead the render path — already on the main thread — saves once
    /// after the user has been idle ~10 s. Explicit save paths are untouched.
    private func maybeIdleSave() {
        guard dirty, !idleSaving else { return }
        guard CFAbsoluteTimeGetCurrent() - lastEditTs >= 10.0 else { return }
        idleSaving = true
        CrashLog.note("save")
        Projects.save(projectId, Editor.project)
        dirty = false
        FreezeWatchdog.setDirty(false)
        idleSaving = false
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        applyFullPanelFrame()
    }

    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        // Kotlin onConfigurationChanged → buildUi() + refreshAll(); RootLayout recomputes both
        // orientations itself, so only a relayout pass is needed.
        rootLayout.setNeedsLayout()
        coordinator.animate(alongsideTransition: nil) { [weak self] _ in
            self?.applyFullPanelFrame()
        }
    }

    deinit {
        displayLink?.invalidate()
        NotificationCenter.default.removeObserver(self)
        releaseAudio()             // Kotlin: onDestroy → releaseAudio()
    }

    private func toast(_ s: String) { Snack.show(self, s) }

    private func safe(_ step: String, _ block: () throws -> Void) {
        do { try block() } catch {
            var m = (error as? LocalizedError)?.errorDescription ?? (error as NSError).localizedDescription
            if m.isEmpty { m = String(describing: type(of: error)) }
            toast(step + ": " + m)
        }
    }

    // ================================================================ audio (MediaPlayer → AVAudioPlayer)

    /** Players are created and prepared in the background as soon as an audio layer exists, so Play starts instantly. */
    private func ensureAudio() {
        var ids = Set<Int>()
        for l in Editor.scene.layers {
            guard l.type == .AUDIO else { continue }
            ids.insert(l.id)
            guard let path = l.imagePath, players[l.id] == nil, !startingAudio.contains(l.id) else { continue }
            let id = l.id
            startingAudio.insert(id)
            safeThread("audio-\(id)") { [weak self] in
                let mp = try? AVAudioPlayer(contentsOf: URL(fileURLWithPath: path))
                if let mp = mp { _ = mp.prepareToPlay() }
                DispatchQueue.main.async {
                    guard let self = self else { return }
                    self.startingAudio.remove(id)
                    if let mp = mp {
                        self.players[id] = mp
                        self.prepared.insert(id)
                    }
                }
            }
        }
        for id in Array(players.keys) where !ids.contains(id) {
            players.removeValue(forKey: id)   // AVAudioPlayer is released by ARC (no explicit release)
            prepared.remove(id)
            startingAudio.remove(id)
        }
    }

    private func releaseAudio() {
        players.removeAll()
        prepared.removeAll()
        startingAudio.removeAll()
    }

    private func stopAudio() {
        for mp in players.values { mp.pause() }
    }

    private func startAudio() { ensureAudio(); tickAudio(true) }

    /** Keeps every audio layer locked to the playhead and corrects drift. */
    private func tickAudio(_ restart: Bool = false) {
        let t = Editor.time
        for l in Editor.scene.layers {
            guard let mp = players[l.id], prepared.contains(l.id) else { continue }
            let inside = l.visible && t >= l.start && t <= l.end
            let wantMs = Float(ktInt((t - l.start + l.srcOffset) * 1000)) + Float(audioLead)
            let want = wantMs / 1000
            if inside {
                let v = clamp(l.p("volume", t), 0, 1)
                mp.volume = v
                if !mp.isPlaying {
                    mp.currentTime = Double(want)  // SEEK_CLOSEST parity
                    mp.play()
                } else if restart || abs(mp.currentTime - Double(want)) > 0.14 {
                    mp.currentTime = Double(want)
                }
            } else if mp.isPlaying {
                mp.pause()
            }
        }
    }

    // ================================================================ UI skeleton

    @discardableResult
    private func icon(_ name: String, _ tint: Int32 = C.TEXT, click: @escaping () -> Void = {}) -> IconView {
        let v = IconView(name, tint)
        v.onClick = click
        return v
    }

    private func hRow() -> UIStackView {
        let r = UIStackView()
        r.axis = .horizontal
        r.alignment = .center
        r.spacing = 0
        return r
    }

    private func vStack() -> UIStackView {
        let r = UIStackView()
        r.axis = .vertical
        r.spacing = 0
        r.alignment = .fill
        return r
    }

    private func spacer() -> UIView {
        let v = UIView()
        v.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
        return v
    }

    private func addIcon(_ parent: UIStackView, _ v: IconView, _ w: CGFloat = 44, _ h: CGFloat = 48) {
        parent.addArrangedSubview(wrap(v, w, h, 0, 0, 0, 0))
    }

    private func buildUi() {
        screen = view
        screen.backgroundColor = argbToUIColor(C.BG)

        // ---- top bar
        let top = hRow()
        top.isLayoutMarginsRelativeArrangement = true
        top.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 4, bottom: 0, trailing: 8)
        addIcon(top, icon("back", C.AMBER) { [weak self] in self?.onBack() }, 40)
        let tcol = vStack()
        titleView = UILabel()
        titleView.textColor = argbToUIColor(C.TEXT)
        titleView.font = boldFont(17)
        titleView.numberOfLines = 1
        subView = UILabel()
        subView.textColor = argbToUIColor(C.DIM)
        subView.font = sysFont(11)
        tcol.addArrangedSubview(titleView)
        tcol.addArrangedSubview(subView)
        tcol.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
        top.addArrangedSubview(tcol)
        cubeIcon = icon("cube") { [weak self] in self?.toggle3d() }
        addIcon(top, cubeIcon, 40)
        mbToggle = PillToggle()
        mbToggle.onClick = { [weak self] in
            guard let self = self, let l = self.selected() else { return }
            self.pushUndo()
            l.mblur = !l.mblur
            self.mbToggle.on = l.mblur
            self.refreshPanel(); self.render()
        }
        mbToggle.onLong = { [weak self] in
            guard let self = self, let l = self.selected() else { return }
            self.showMotionBlurSettings(l)
        }
        top.addArrangedSubview(wrap(mbToggle, 52, 40, 0, 0, 0, 0))
        parentIcon = icon("dup") { [weak self] in
            guard let self = self, let l = self.selected() else { return }
            self.showParentPopup(l, self.parentIcon)
        }
        addIcon(top, parentIcon, 40)
        moreIcon = icon("more") { [weak self] in self?.showLayersMenu() }
        addIcon(top, moreIcon, 40)
        gearIcon = icon("gear") { [weak self] in self?.showSceneDialog() }
        addIcon(top, gearIcon, 40)
        renderBtn = wrap(pill("Render", "export", C.GREEN, Int32(bitPattern: 0xFF2B1400)) { [weak self] in
            self?.showRenderDialog()
        }, 104, 38, 0, 0, 0, 0)
        top.addArrangedSubview(renderBtn)

        // ---- preview area
        let previewBox = UIView()
        previewBox.backgroundColor = argbToUIColor(Int32(bitPattern: 0xFF161618))
        aspect = AspectLayout()
        preview = PreviewView()
        overlay = OverlayView(self, self)
        aspect.addSubview(preview)
        aspect.addSubview(overlay)
        previewBox.addSubview(aspect)
        aspect.autoresizingMask = [.flexibleWidth, .flexibleHeight]

        // ---- transport row
        let tr = hRow()
        tr.isLayoutMarginsRelativeArrangement = true
        tr.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 6, bottom: 0, trailing: 6)
        addIcon(tr, icon("fit") { [weak self] in self?.timeline.fitToScene() })
        qualityChip = ChipView("Full")
        qualityChip.onClick = { [weak self] in self?.cycleQuality() }
        tr.addArrangedSubview(wrap(qualityChip, 56, 48, 0, 0, 0, 0))
        markIcon = icon("bookmark") { [weak self] in self?.toggleMarker() }
        markIcon.onLong = { [weak self] in self?.nameMarker() }
        addIcon(tr, markIcon)
        tr.addArrangedSubview(spacer())
        let prev = icon("prev") { [weak self] in self?.stepFrame(-1) }
        prev.onLong = { [weak self] in self?.jump(-1) }
        addIcon(tr, prev, 48)
        playIcon = icon("play") { [weak self] in self?.togglePlay() }
        addIcon(tr, playIcon, 52)
        let next = icon("next") { [weak self] in self?.stepFrame(1) }
        next.onLong = { [weak self] in self?.jump(1) }
        addIcon(tr, next, 48)
        tr.addArrangedSubview(spacer())
        addIcon(tr, icon("layers") { [weak self] in self?.showLayersMenu() })
        addIcon(tr, icon("undo") { [weak self] in self?.doUndo() })
        addIcon(tr, icon("redo") { [weak self] in self?.doRedo() })

        timeline = TimelineView(self, self)

        // The floating action bar over the timeline: trim in / split / trim out / delete.
        // It appears only while a layer is selected, which keeps the main toolbar clean.
        let tlBox = UIView()
        tlBox.addSubview(timeline)
        let abar = UIStackView()
        abar.axis = .horizontal
        abar.alignment = .center
        abar.spacing = 0
        abar.backgroundColor = argbToUIColor(Int32(bitPattern: 0xF01E1E22)).withAlphaComponent(0.94)
        abar.layer.cornerRadius = 26
        abar.layer.borderWidth = 1
        abar.layer.borderColor = argbToUIColor(Int32(bitPattern: 0xFF3A3A42)).cgColor
        abar.isLayoutMarginsRelativeArrangement = true
        abar.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 8, bottom: 0, trailing: 8)
        addIcon(abar, icon("trimin") { [weak self] in self?.trimTo(true) }, 52, 48)
        addIcon(abar, icon("split") { [weak self] in self?.splitAtPlayhead(false) }, 52, 48)
        addIcon(abar, icon("trimout") { [weak self] in self?.trimTo(false) }, 52, 48)
        addIcon(abar, icon("trash", C.RED) { [weak self] in self?.deleteLayer() }, 52, 48)
        actionBar = abar
        actionBar.isHidden = true
        tlBox.addSubview(abar)
        abar.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            abar.centerXAnchor.constraint(equalTo: tlBox.centerXAnchor),
            abar.bottomAnchor.constraint(equalTo: tlBox.bottomAnchor, constant: -8),
            abar.heightAnchor.constraint(equalToConstant: 48)
        ])

        // ---- bottom tool bar
        toolbarBox = UIScrollView()
        toolbarBox.showsHorizontalScrollIndicator = false
        toolbarBox.backgroundColor = argbToUIColor(C.PANEL)
        toolbarRow = hRow()
        toolbarRow.translatesAutoresizingMaskIntoConstraints = false
        toolbarBox.addSubview(toolbarRow)
        NSLayoutConstraint.activate([
            toolbarRow.topAnchor.constraint(equalTo: toolbarBox.contentLayoutGuide.topAnchor),
            toolbarRow.bottomAnchor.constraint(equalTo: toolbarBox.contentLayoutGuide.bottomAnchor),
            toolbarRow.leadingAnchor.constraint(equalTo: toolbarBox.contentLayoutGuide.leadingAnchor),
            toolbarRow.trailingAnchor.constraint(equalTo: toolbarBox.contentLayoutGuide.trailingAnchor),
            toolbarRow.heightAnchor.constraint(equalTo: toolbarBox.frameLayoutGuide.heightAnchor)
        ])

        // ---- property panel (side rail + scroll)
        panelBox = UIView()
        panelBox.backgroundColor = argbToUIColor(C.PANEL)
        let ph = hRow()
        ph.alignment = .fill
        ph.spacing = 0
        let side = UIStackView()
        side.axis = .vertical
        side.alignment = .center
        side.spacing = 0
        side.addArrangedSubview(wrap(icon("close") { [weak self] in self?.closePanel() }, 48, 48, 0, 0, 0, 0))
        side.addArrangedSubview(wrap(icon("plus", C.GREEN) { [weak self] in
            guard let self = self else { return }
            self.fxTab = 1; self.openPanel(P_FX)
        }, 48, 44, 0, 0, 0, 0))
        diamondSide = icon("diamond_f", C.DIM) { [weak self] in self?.keySelected() }
        side.addArrangedSubview(wrap(diamondSide, 48, 44, 0, 0, 0, 0))
        side.addArrangedSubview(wrap(icon("graph", C.DIM) { [weak self] in self?.openPanel(P_GRAPH) }, 48, 44, 0, 0, 0, 0))
        side.addArrangedSubview(wrap(icon("box", C.DIM) { [weak self] in
            guard let self = self else { return }
            self.fxTab = 2; self.openPanel(P_FX)
        }, 48, 44, 0, 0, 0, 0))
        side.addArrangedSubview(wrap(icon("more", C.DIM) { [weak self] in self?.showPanelMenu() }, 48, 44, 0, 0, 0, 0))
        ph.addArrangedSubview(fixedWidth(side, 52))
        let panelSv = UIScrollView()
        panelList = vStack()
        panelList.isLayoutMarginsRelativeArrangement = true
        panelList.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 6, leading: 4, bottom: 16, trailing: 8)
        panelList.translatesAutoresizingMaskIntoConstraints = false
        panelSv.addSubview(panelList)
        NSLayoutConstraint.activate([
            panelList.topAnchor.constraint(equalTo: panelSv.contentLayoutGuide.topAnchor),
            panelList.bottomAnchor.constraint(equalTo: panelSv.contentLayoutGuide.bottomAnchor),
            panelList.leadingAnchor.constraint(equalTo: panelSv.contentLayoutGuide.leadingAnchor),
            panelList.trailingAnchor.constraint(equalTo: panelSv.contentLayoutGuide.trailingAnchor),
            panelList.widthAnchor.constraint(equalTo: panelSv.frameLayoutGuide.widthAnchor)
        ])
        ph.addArrangedSubview(panelSv)
        ph.translatesAutoresizingMaskIntoConstraints = false
        panelBox.addSubview(ph)
        NSLayoutConstraint.activate([
            ph.topAnchor.constraint(equalTo: panelBox.topAnchor),
            ph.bottomAnchor.constraint(equalTo: panelBox.bottomAnchor),
            ph.leadingAnchor.constraint(equalTo: panelBox.leadingAnchor),
            ph.trailingAnchor.constraint(equalTo: panelBox.trailingAnchor)
        ])

        timeline.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        tlBox.clipsToBounds = true

        // ---- root (the Kotlin LinearLayout with orientation branches)
        rootLayout = RootLayout()
        rootLayout.translatesAutoresizingMaskIntoConstraints = false
        rootLayout.top = top
        rootLayout.previewBox = previewBox
        rootLayout.tr = tr
        rootLayout.timeline = tlBox
        rootLayout.toolbarBox = toolbarBox
        rootLayout.panelBox = panelBox
        // The slots must actually live in the hierarchy — RootLayout.lay() only frames
        // views whose superview is itself (placePanel() re-parents panelBox later, so it
        // is appended last here to keep it on top of the weighted stack).
        rootLayout.addSubview(top)
        rootLayout.addSubview(previewBox)
        rootLayout.addSubview(tr)
        rootLayout.addSubview(tlBox)
        rootLayout.addSubview(toolbarBox)
        rootLayout.addSubview(panelBox)
        screen.addSubview(rootLayout)
        rootBottom = rootLayout.bottomAnchor.constraint(equalTo: screen.safeAreaLayoutGuide.bottomAnchor)
        NSLayoutConstraint.activate([
            rootLayout.topAnchor.constraint(equalTo: screen.safeAreaLayoutGuide.topAnchor),
            rootLayout.leadingAnchor.constraint(equalTo: screen.safeAreaLayoutGuide.leadingAnchor),
            rootLayout.trailingAnchor.constraint(equalTo: screen.safeAreaLayoutGuide.trailingAnchor),
            rootBottom!
        ])

        toolbarBox.isHidden = false
        panelBox.isHidden = true
    }

    // ================================================================ small helpers

    private func selected() -> Layer? { Editor.scene.layers.first { $0.id == selId } }

    private func render() {
        FreezeWatchdog.beat()          // main thread is alive (R15/R19)
        maybeIdleSave()                // cheap: two comparisons when clean
        preview.requestDraw()
        overlay.setNeedsDisplay()
        timeline.setNeedsDisplay()
    }

    @discardableResult
    private func pill(_ text: String, _ icon: String? = nil, _ fill: Int32 = C.CARD2, _ tc: Int32 = C.TEXT,
                      click: @escaping () -> Void) -> PillButton {
        let b = PillButton(text, icon, fill, tc)
        b.onClick = click
        return b
    }

    /// Kotlin put(parent, v, hDp, mT, mB): adds with top/bottom margins; h>0 → fixed height.
    @discardableResult
    private func put(_ parent: UIStackView, _ v: UIView, _ h: CGFloat = 0, _ mT: CGFloat = 3, _ mB: CGFloat = 3) -> UIView {
        parent.addArrangedSubview(pad(v, mT, 0, mB, 0))
        if h > 0 { v.heightAnchor.constraint(equalToConstant: h).isActive = true }
        return v
    }

    /// Wraps a view in padding (Android view.setPadding / layout margins).
    private func pad(_ v: UIView, _ t: CGFloat, _ l: CGFloat, _ b: CGFloat, _ r: CGFloat) -> UIView {
        let w = UIView()
        w.translatesAutoresizingMaskIntoConstraints = false
        v.translatesAutoresizingMaskIntoConstraints = false
        w.addSubview(v)
        NSLayoutConstraint.activate([
            v.topAnchor.constraint(equalTo: w.topAnchor, constant: t),
            v.bottomAnchor.constraint(equalTo: w.bottomAnchor, constant: -b),
            v.leadingAnchor.constraint(equalTo: w.leadingAnchor, constant: l),
            v.trailingAnchor.constraint(equalTo: w.trailingAnchor, constant: -r)
        ])
        return w
    }

    /// Wraps a view with explicit size + margins (Android LayoutParams with setMargins).
    private func wrap(_ v: UIView, _ w: CGFloat, _ h: CGFloat, _ l: CGFloat, _ t: CGFloat, _ r: CGFloat, _ b: CGFloat) -> UIView {
        let box = pad(v, t, l, b, r)
        if w > 0 { v.widthAnchor.constraint(equalToConstant: w).isActive = true }
        if h > 0 { v.heightAnchor.constraint(equalToConstant: h).isActive = true }
        return box
    }

    /// Wrapper that pins the child to the edges but fixes the wrapper width (the 52pt side rail).
    private func fixedWidth(_ v: UIView, _ w: CGFloat) -> UIView {
        let box = UIView()
        box.translatesAutoresizingMaskIntoConstraints = false
        v.translatesAutoresizingMaskIntoConstraints = false
        box.addSubview(v)
        NSLayoutConstraint.activate([
            v.topAnchor.constraint(equalTo: box.topAnchor),
            v.bottomAnchor.constraint(equalTo: box.bottomAnchor),
            v.leadingAnchor.constraint(equalTo: box.leadingAnchor),
            v.trailingAnchor.constraint(equalTo: box.trailingAnchor),
        ])
        box.widthAnchor.constraint(equalToConstant: w).isActive = true
        return box
    }

    @discardableResult
    private func text(_ parent: UIStackView, _ t: String, _ color: Int32 = C.DIM,
                      _ size: CGFloat = 13, _ bold: Bool = false) -> UILabel {
        let tv = UILabel()
        tv.text = t
        tv.textColor = argbToUIColor(color)
        tv.font = bold ? boldFont(size) : sysFont(size)
        tv.numberOfLines = 0
        parent.addArrangedSubview(pad(tv, 6, 6, 4, 6))
        return tv
    }

    private func refreshAll() {
        aspect.ratio = CGFloat(Float(Editor.project.w) / Float(Editor.project.h))
        if selected() == nil { selId = -1 }
        safe("title") { refreshTitle() }
        safe("toolbar") { refreshToolbar() }
        safe("panel") { showBottom() }
        safe("panel") { refreshPanel() }
        safe("time") { onTimeChanged() }
        safe("audio") { ensureAudio() }
    }

    private func refreshTitle() {
        let l = selected()
        titleView.text = l?.name ?? Editor.project.name
        let on = l != nil && (l!.is3d || l!.type == .MODEL || l!.type == .CAMERA)
        cubeIcon.set("cube", on ? C.GREEN : C.TEXT)
        let sel = l != nil
        cubeIcon.isHidden = !sel
        mbToggle.isHidden = !sel || l!.type == .AUDIO
        parentIcon.isHidden = !sel
        moreIcon.isHidden = !sel
        gearIcon.isHidden = sel
        renderBtn.isHidden = sel
        if let l = l {
            mbToggle.on = l.mblur
            parentIcon.set("dup", l.parentId >= 0 ? C.GREEN : C.TEXT)
        }
        actionBar.isHidden = !sel
    }

    /** The Effects panel covers the whole screen; every other panel sits under the timeline. */
    private func placePanel(_ full: Bool) {
        let cur = panelBox.superview
        if full {
            if cur !== screen {
                panelBox.removeFromSuperview()
                screen.addSubview(panelBox)
            }
            panelBox.autoresizingMask = []
            screen.bringSubviewToFront(panelBox)
            applyFullPanelFrame()
            rootLayout.setNeedsLayout()
        } else if cur !== rootLayout {
            panelBox.removeFromSuperview()
            panelBox.autoresizingMask = []
            rootLayout.addSubview(panelBox)   // re-appended last — its layout slot
            rootLayout.setNeedsLayout()
        }
    }

    private func applyFullPanelFrame() {
        guard panelBox.superview === screen else { return }
        var f = screen.safeAreaLayoutGuide.layoutFrame
        f.size.height = max(0, f.height - kbInset)
        panelBox.frame = f
    }

    private func showBottom() {
        placePanel(panel == P_FX && fxTab == 1)
        toolbarBox.isHidden = panel != P_NONE
        panelBox.isHidden = panel == P_NONE
        rootLayout.setNeedsLayout()   // visibility changes must re-flow the weighted layout
    }

    private func onTimeChanged() {
        syncRows()
        subView.text = timeline.timecode(Editor.time) + " / " + timeline.timecode(Editor.scene.duration)
        let has = Editor.scene.markers.contains { abs($0 - Editor.time) < 0.02 }
        markIcon.set(has ? "bookmark_f" : "bookmark", has ? C.BLUE : C.TEXT)
        render()
    }

    private func onBack() {
        if panel != P_NONE {
            closePanel()
        } else if selId != -1 {
            onSelect(-1)
        } else if let nav = navigationController {
            nav.popViewController(animated: true)
        } else {
            dismiss(animated: true)
        }
    }

    private func openPanel(_ p: Int) {
        if p != P_MEDIA && p != P_SHAPES && selected() == nil { toast("Select a layer first"); return }
        panel = p
        showBottom(); refreshPanel()
    }

    private func closePanel() { panel = P_NONE; showBottom() }

    // ================================================================ keyboard (adjustResize)

    @objc private func kbChanged(_ n: Notification) {
        guard let info = n.userInfo else { return }
        let show = n.name == UIResponder.keyboardWillShowNotification
        let dur = (info[UIResponder.keyboardAnimationDurationUserInfoKey] as? Double) ?? 0.25
        var endH: CGFloat = 0
        if show, let f = (info[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
            endH = max(0, f.height - view.safeAreaInsets.bottom)
        }
        kbInset = endH
        UIView.animate(withDuration: dur) {
            self.rootBottom?.constant = self.kbInset
            if self.panelBox.superview === self.view {
                var fr = self.view.safeAreaLayoutGuide.layoutFrame
                fr.size.height = max(0, fr.height - self.kbInset)
                self.panelBox.frame = fr
            }
            self.view.layoutIfNeeded()
        }
    }

    // ================================================================ tool bar

    private func refreshToolbar() {
        toolbarRow.arrangedSubviews.forEach { $0.removeFromSuperview() }
        func tool(_ ic: String, _ label: String, _ tint: Int32 = C.TEXT, _ click: @escaping () -> Void) {
            let b = ToolButton(ic, label)
            b.tint = tint
            b.onClick = click
            toolbarRow.addArrangedSubview(wrap(b, 76, 76, 0, 0, 0, 0))
        }
        guard let l = selected() else {
            tool("media", "Media") { [weak self] in self?.openPanel(P_MEDIA) }
            tool("text", "Text") { [weak self] in self?.addLayer(.TEXT) }
            tool("solid", "Solid") { [weak self] in self?.addSolid() }
            tool("adjust", "Adjustment") { [weak self] in self?.addLayer(.ADJUST) }
            tool("audio", "Audio") { [weak self] in self?.pickMedia(R_AUDIOFILE, [.audio], false) }
            tool("nullobj", "Null") { [weak self] in self?.addLayer(.NULL) }
            tool("shape", "Shape") { [weak self] in self?.openPanel(P_SHAPES) }
            tool("camera", "Camera") { [weak self] in self?.addLayer(.CAMERA) }
            tool("particles", "Particles") { [weak self] in self?.addParticles() }
            tool("flare", "Optical Flare") { [weak self] in self?.showFlareLibrary() }
            tool("layers", "Group") { [weak self] in self?.addLayer(.GROUP) }
            tool("cube", "3D Model") { [weak self] in self?.pickFile(R_GLB, glbTypes()) }
            return
        }
        toolbarRow.addArrangedSubview(wrap(icon("back", C.GREEN) { [weak self] in self?.onSelect(-1) }, 44, 76, 0, 0, 0, 0))
        if l.type == .VIDEO { tool("audio", "Extract audio") { [weak self] in self?.extractAudio(l) } }
        tool("edit", "Edit") { [weak self] in self?.openPanel(P_EDIT) }
        tool("move", "Transform") { [weak self] in self?.openPanel(P_XFORM) }
        if l.isRenderable() || l.type == .GROUP {
            tool("sparkle", "Effects") { [weak self] in self?.openPanel(P_FX) }
            tool("drop", "Blending") { [weak self] in self?.openPanel(P_BLEND) }
            tool("speed", "Speed") { [weak self] in self?.openPanel(P_SPEED) }
        }
    }

    // ================================================================ playback (Choreographer → CADisplayLink)

    func doFrame() {
        FreezeWatchdog.beat()          // playback frames count as liveness
        if !playing { return }
        let ts = Double(displayLink?.timestamp ?? 0)
        if lastTs != 0 && ts > lastTs {
            var t = Editor.time + Float(ts - lastTs)
            var wrapped = false
            if t > Editor.scene.duration { t = 0; wrapped = true }
            Editor.time = t
            if wrapped { startAudio() } else { tickAudio() }
            onTimeChanged()
        }
        lastTs = ts
    }

    private func togglePlay() {
        playing = !playing
        playIcon.set(playing ? "pause" : "play", C.TEXT)
        if playing {
            lastTs = 0
            if displayLink == nil {
                let proxy = DisplayLinkProxy()
                proxy.vc = self
                let link = CADisplayLink(target: proxy, selector: #selector(DisplayLinkProxy.tick(_:)))
                link.add(to: .main, forMode: .common)
                linkProxy = proxy
                displayLink = link
            }
            displayLink?.isPaused = false
            startAudio()
        } else {
            displayLink?.isPaused = true
            stopAudio()
        }
    }

    private func stepFrame(_ dir: Int) {
        Editor.time = clamp(Editor.time + Float(dir) / Float(Editor.project.fps), 0, Editor.scene.duration)
        onTimeChanged()
    }

    private func jump(_ dir: Int) {
        var times: [Float] = []
        times.append(contentsOf: Editor.scene.markers)
        if let l = selected() {
            for (_, tr) in l.props { for k in tr.keys { times.append(k.t) } }
        }
        times.sort()
        let now = Editor.time
        let target = dir > 0 ? times.first { $0 > now + 0.02 } : times.last { $0 < now - 0.02 }
        if let target = target { Editor.time = target; onTimeChanged() }
    }

    private func toggleMarker() {
        var ms = Editor.scene.markers
        let ex = ms.first { abs($0 - Editor.time) < 0.02 }
        pushUndo()
        if let ex = ex {
            Editor.scene.setMarkerName(ex, "")
            ms.removeAll { $0 == ex }
        } else {
            ms.append(Editor.time)
        }
        Editor.scene.markers = ms
        onTimeChanged()
    }

    private func nameMarker() {
        var ms = Editor.scene.markers
        var m: Float? = ms.first { abs($0 - Editor.time) < 0.02 }
        if m == nil {
            pushUndo()
            ms.append(Editor.time)
            m = Editor.time
            Editor.scene.markers = ms
            onTimeChanged()
        }
        guard let tm = m else { return }
        let box = vStack()
        box.isLayoutMarginsRelativeArrangement = true
        box.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 4, leading: 4, bottom: 4, trailing: 4)
        text(box, timeline.timecode(tm), C.DIM, 13)
        let et = makeField("")
        et.placeholder = "Marker name"
        et.text = Editor.scene.markerName(tm) ?? ""
        box.addArrangedSubview(wrap(et, 0, 44, 0, 0, 0, 0))
        text(box, "Expressions can reach this marker by name:  marker.key(\"name\")", C.DIM, 12)
        Dlg(self).setTitle("Name marker").setView(box).setPositiveButton("Save") { [weak self] _, _ in
            guard let self = self else { return }
            self.pushUndo()
            Editor.scene.setMarkerName(tm, et.text ?? "")
            self.timeline.setNeedsDisplay()
            self.render()
        }.setNegativeButton("Cancel", nil).show()
    }

    private func cycleQuality() {
        quality = quality == 1 ? 2 : (quality == 2 ? 4 : 1)
        preview.quality = quality
        qualityChip.text = quality == 1 ? "Full" : (quality == 2 ? "1/2" : "1/4")
        qualityChip.setNeedsDisplay()
        render()
    }

    // ================================================================ undo / redo

    private func snapshot() -> String { Editor.project.toJson().toString() }

    private func pushUndo() {
        markDirty()                    // every edit passes through here (R11/R19)
        let s = snapshot()
        if undoStack.last == s { return }
        undoStack.append(s)
        if undoStack.count > 40 { undoStack.removeFirst() }
        redoStack.removeAll()
    }

    private func restore(_ js: String) {
        if let o = try? JObj(json: js) { Editor.project = Project.fromJson(o) }
        if Editor.sceneIndex >= Editor.project.scenes.count { Editor.sceneIndex = Editor.project.scenes.count - 1 }
        Editor.time = clamp(Editor.time, 0, Editor.scene.duration)
        refreshAll()
    }

    private func doUndo() {
        if undoStack.isEmpty { toast("Nothing to undo"); return }
        redoStack.append(snapshot())
        let js = undoStack.removeLast()
        restore(js)
    }

    private func doRedo() {
        if redoStack.isEmpty { toast("Nothing to redo"); return }
        undoStack.append(snapshot())
        let js = redoStack.removeLast()
        restore(js)
    }

    // ================================================================ hosts

    func selectedLayer() -> Layer? { selected() }
    func autoKey() -> Bool { autoKeyOn }
    func beginEdit() { pushUndo() }
    func onEdited() { syncRows(); render() }
    func selectedId() -> Int { selId }
    func isSelected(_ id: Int) -> Bool { id == selId || multi.contains(id) }
    func onSeek(_ t: Float) { Editor.time = t; onTimeChanged() }

    func onSelect(_ id: Int) {
        if multiMode && id >= 0 {
            if let i = multi.firstIndex(of: id) { multi.remove(at: i) } else { multi.append(id) }
            selId = id
            panel = P_NONE
            refreshTitle(); refreshToolbar(); showBottom(); refreshPanel(); render()
            return
        }
        if !multiMode { multi.removeAll() }
        selId = id
        panel = id >= 0 && selected()?.type == .TEXT ? P_EDIT : P_NONE
        refreshTitle(); refreshToolbar(); showBottom(); refreshPanel(); render()
    }

    func onToggleVisible(_ l: Layer) {
        pushUndo()
        l.visible = !l.visible
        render()
    }

    func onTimingChanged() { render() }

    func onReorder(_ l: Layer, _ listIndex: Int) {
        pushUndo()
        var ls = Editor.scene.layers
        ls.removeAll { $0 === l }
        ls.insert(l, at: clamp(listIndex, 0, ls.count))
        Editor.scene.layers = ls
        render()
    }

    func onKeyTap(_ l: Layer, _ key: String, _ idx: Int) {
        selId = l.id
        graphProp = key
        graphKey = idx
        let ks = l.track(key).keys
        if ks.indices.contains(idx) { Editor.time = ks[idx].t }
        panel = P_GRAPH
        refreshTitle(); refreshToolbar(); showBottom(); refreshPanel(); onTimeChanged()
    }

    // ================================================================ layers

    // ---------------------------------------------------------------- optical flares

    private var flareLayer: Layer? = nil
    private var flareBackup: JObj? = nil
    private var flareOverlay: UIView? = nil
    private var flareContent: UIStackView? = nil
    private var flareTabs: TabBar? = nil
    private var flTab = 0
    private var flSel = 0

    /// The "Optical Flare" button: pick a preset from the thumbnails, or Customize.
    private func showFlareLibrary() {
        Flare.loadUser()
        let all = Flare.builtin() + Flare.user
        FlareThumbs.generate(preview, all) { }
        let sv = CapScroll()
        let col = vStack()
        col.isLayoutMarginsRelativeArrangement = true
        col.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 4, leading: 4, bottom: 4, trailing: 4)
        sv.addSubview(col)
        col.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            col.topAnchor.constraint(equalTo: sv.contentLayoutGuide.topAnchor),
            col.bottomAnchor.constraint(equalTo: sv.contentLayoutGuide.bottomAnchor),
            col.leadingAnchor.constraint(equalTo: sv.contentLayoutGuide.leadingAnchor),
            col.trailingAnchor.constraint(equalTo: sv.contentLayoutGuide.trailingAnchor),
            col.widthAnchor.constraint(equalTo: sv.frameLayoutGuide.widthAnchor)
        ])
        var row: UIStackView? = nil
        for (i, f) in all.enumerated() {
            if i % 2 == 0 {
                let r = hRow()
                r.distribution = .fillEqually
                col.addArrangedSubview(r)
                row = r
            }
            let th = FlareThumb(f.sig(), f.name)
            let ff = f
            th.onClick = { [weak self] in
                Dlg.dismissCurrent()
                self?.addFlare(ff.copy(), false)
            }
            put(row!, th, 112, 4, 4)
        }
        text(col, "Scroll down to build your own.", C.DIM, 12)
        put(col, pill("Customize", "edit", C.GREEN, Int32(bitPattern: 0xFF2B1400)) { [weak self] in
            Dlg.dismissCurrent()
            self?.addFlare(Flare.deflt(), true)
        }, 52, 10, 6)
        _ = Dlg(self).setTitle("Optical Flare").setView(sv).setNegativeButton("Close", nil).show()
    }

    private func addFlare(_ f: Flare, _ customize: Bool) {
        let l = addLayer(.FLARE)
        l.name = "Optical Flare \(l.id)"
        l.flare = f
        let asp = Float(Editor.project.w) / Float(Editor.project.h)
        l.track("x").base = -0.45 * asp
        l.track("y").base = 0.3
        if customize { openFlareEditor(l) } else { render(); refreshPanel() }
    }

    private func openFlareEditor(_ l: Layer) {
        if flareOverlay != nil { return }
        if l.flare == nil { l.flare = Flare.deflt() }
        pushUndo()
        flareLayer = l
        let b = JObj().put("flare", l.flare!.toJson())
        for d in Defs.flare { b.put(d.key, Double(l.track(d.key).base)) }
        flareBackup = b
        flTab = 0
        flSel = 0
        Flare.loadUser()
        buildFlareOverlay()
    }

    private func closeFlareEditor(_ save: Bool) {
        if let l = flareLayer, !save, let b = flareBackup {
            if let fo = b.optJSONObject("flare") { l.flare = Flare.fromJson(fo) }
            for d in Defs.flare { l.track(d.key).base = b.optFloat(d.key, d.def) }
        }
        flareOverlay?.removeFromSuperview()
        flareOverlay = nil; flareContent = nil; flareLayer = nil; flareTabs = nil
        render(); refreshPanel()
    }

    private func buildFlareOverlay() {
        let ov = vStack()
        ov.backgroundColor = argbToUIColor(Int32(bitPattern: 0xE6000000))
        let panel = vStack()
        panel.backgroundColor = argbToUIColor(C.PANEL)
        panel.layer.cornerRadius = 16
        panel.layer.masksToBounds = true
        let bar = hRow()
        bar.isLayoutMarginsRelativeArrangement = true
        bar.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 8, bottom: 0, trailing: 8)
        bar.backgroundColor = argbToUIColor(C.PANEL)
        bar.addArrangedSubview(wrap(pill("Cancel") { [weak self] in self?.closeFlareEditor(false) }, 92, 40, 0, 0, 0, 0))
        let tt = UILabel()
        tt.text = "Optical Flare"
        tt.textColor = argbToUIColor(C.TEXT)
        tt.font = boldFont(16)
        tt.textAlignment = .center
        tt.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
        bar.addArrangedSubview(tt)
        bar.addArrangedSubview(wrap(pill("Save", nil, C.GREEN, Int32(bitPattern: 0xFF2B1400)) { [weak self] in self?.closeFlareEditor(true) }, 92, 40, 0, 0, 0, 0))
        let tabs = TabBar(["Presets", "Elements", "Edit", "Global"], flTab) { [weak self] i in
            guard let self = self else { return }
            self.flTab = i
            self.refreshFlare()
        }
        flareTabs = tabs
        let sv = CapScroll()
        let content = vStack()
        content.isLayoutMarginsRelativeArrangement = true
        content.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 4, leading: 8, bottom: 12, trailing: 8)
        sv.addSubview(content)
        content.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            content.topAnchor.constraint(equalTo: sv.contentLayoutGuide.topAnchor),
            content.bottomAnchor.constraint(equalTo: sv.contentLayoutGuide.bottomAnchor),
            content.leadingAnchor.constraint(equalTo: sv.contentLayoutGuide.leadingAnchor),
            content.trailingAnchor.constraint(equalTo: sv.contentLayoutGuide.trailingAnchor),
            content.widthAnchor.constraint(equalTo: sv.frameLayoutGuide.widthAnchor)
        ])
        flareContent = content
        let spacerView = UIView()
        spacerView.setContentHuggingPriority(UILayoutPriority(1), for: .vertical)
        ov.addArrangedSubview(wrap(bar, 0, 52, 0, 0, 0, 0))
        ov.addArrangedSubview(spacerView)
        ov.addArrangedSubview(wrap(tabs, 0, 44, 0, 0, 0, 0))
        ov.addArrangedSubview(sv)
        sv.setContentHuggingPriority(UILayoutPriority(1), for: .vertical)
        flareOverlay = ov
        screen.addSubview(ov)
        ov.frame = screen.safeAreaLayoutGuide.layoutFrame
        ov.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        refreshFlare()
    }

    private func refreshFlare() {
        guard let l = flareLayer, let f = l.flare, let p = flareContent else { return }
        p.arrangedSubviews.forEach { $0.removeFromSuperview() }
        flareTabs?.sel = flTab
        flareTabs?.setNeedsDisplay()
        if flSel >= f.els.count { flSel = max(f.els.count - 1, 0) }
        switch flTab {
        case 0: flarePresets(p, l, f)
        case 1: flareElements(p, l, f)
        case 2: flareEditEl(p, l, f)
        default: flareGlobal(p, l, f)
        }
    }

    private func flarePresets(_ p: UIStackView, _ l: Layer, _ f: Flare) {
        let all = Flare.builtin() + Flare.user
        FlareThumbs.generate(preview, all) { }
        var row: UIStackView? = nil
        for (i, pr) in all.enumerated() {
            if i % 3 == 0 {
                let r = hRow()
                r.distribution = .fillEqually
                p.addArrangedSubview(r)
                row = r
            }
            let th = FlareThumb(pr.sig(), pr.name)
            th.onClick = { [weak self] in
                guard let self = self else { return }
                l.flare = pr.copy()
                self.flSel = 0
                self.refreshFlare(); self.render()
            }
            put(row!, th, 96, 3, 3)
        }
        put(p, pill("Save as my preset", "plus") { [weak self] in
            guard let self = self else { return }
            let et = UITextField(frame: .zero)
            et.placeholder = "Preset name"
            et.text = f.name
            _ = Dlg(self).setTitle("Save preset").setView(et).setPositiveButton("Save") { [weak self] _, _ in
                guard let self = self else { return }
                let c = f.copy()
                let nm = et.text?.trimmingCharacters(in: .whitespaces) ?? ""
                c.name = nm.isEmpty ? "My flare \(Flare.user.count + 1)" : nm
                Flare.user.append(c)
                Flare.saveUser()
                self.refreshFlare()
            }.setNegativeButton("Cancel", nil).show()
        }, 44, 10, 4)
        text(p, "Tap a preset to replace the flare.", C.DIM, 12)
    }

    private func flareElements(_ p: UIStackView, _ l: Layer, _ f: Flare) {
        put(p, pill("Add element", "plus", C.GREEN, Int32(bitPattern: 0xFF2B1400)) { [weak self] in
            guard let self = self else { return }
            _ = Dlg(self).setTitle("Add element").setItems(FlareEl.TYPES) { [weak self] _, w in
                guard let self = self, let ff = self.flareLayer?.flare else { return }
                let e = FlareEl(w)
                switch w {
                case 1, 5: e.size = 0.4; e.thick = 0.1
                case 2: e.size = 1.2; e.stretch = 10; e.thick = 0.04; e.pos = 0
                case 3: e.size = 0.9; e.pos = 0; e.rays = 12
                case 4: e.size = 0.12; e.thick = 1
                case 6: e.size = 0.05
                default: e.pos = 0
                }
                ff.els.append(e)
                self.flSel = ff.els.count - 1
                self.flTab = 2
                self.refreshFlare(); self.render()
            }.show()
        }, 46)
        if f.els.isEmpty { text(p, "No elements. Add a Glow to start.", C.DIM, 13) }
        for (i, e) in f.els.enumerated() {
            let row = hRow()
            row.backgroundColor = argbToUIColor(i == flSel ? Int32(bitPattern: 0xFF2A2A30) : C.CARD)
            row.isLayoutMarginsRelativeArrangement = true
            row.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 4, bottom: 0, trailing: 2)
            let eye = IconView(e.enabled ? "eye" : "eye_off", e.enabled ? Int32(bitPattern: 0xFFFFFFFF) : C.DIM, 20)
            eye.onClick = { [weak self] in e.enabled = !e.enabled; self?.refreshFlare(); self?.render() }
            row.addArrangedSubview(wrap(eye, 40, 48, 0, 0, 0, 0))
            let sw = UIView()
            sw.backgroundColor = argbToUIColor(e.color | Int32(bitPattern: 0xFF000000))
            row.addArrangedSubview(wrap(sw, 10, 26, 0, 0, 0, 0))
            let tv = UILabel()
            tv.text = "  " + e.label() + "  (" + String(format: "%.2f", e.pos) + ")"
            tv.textColor = argbToUIColor(C.TEXT)
            tv.font = sysFont(14)
            tv.numberOfLines = 1
            tv.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
            let tap = TapView()
            tap.addSubview(tv)
            tv.frame = .zero
            tap.onClick = { [weak self] in
                guard let self = self else { return }
                self.flSel = i; self.flTab = 2
                self.refreshFlare()
            }
            row.addArrangedSubview(tap)
            func btn(_ icon: String, _ tint: Int32, _ click: @escaping () -> Void) {
                let b = IconView(icon, tint, 18)
                b.onClick = click
                row.addArrangedSubview(wrap(b, 34, 48, 0, 0, 0, 0))
            }
            btn("chev_up", Int32(bitPattern: 0xFFFFFFFF)) { [weak self] in
                guard let self = self else { return }
                if i > 0 { let e2 = f.els.remove(at: i); f.els.insert(e2, at: i - 1); self.flSel = i - 1; self.refreshFlare(); self.render() }
            }
            btn("chev_down", Int32(bitPattern: 0xFFFFFFFF)) { [weak self] in
                guard let self = self else { return }
                if i < f.els.count - 1 { let e2 = f.els.remove(at: i); f.els.insert(e2, at: i + 1); self.flSel = i + 1; self.refreshFlare(); self.render() }
            }
            btn("dup", Int32(bitPattern: 0xFFFFFFFF)) { [weak self] in
                guard let self = self else { return }
                f.els.insert(e.copy(), at: i + 1)
                self.flSel = i + 1
                self.refreshFlare(); self.render()
            }
            btn("trash", C.RED) { [weak self] in
                guard let self = self else { return }
                f.els.remove(at: i)
                self.refreshFlare(); self.render()
            }
            put(p, row, 0, 3, 3)
        }
        text(p, "Position 0 is the light itself, 1 is the screen center and 2 is the opposite side. Tap an element to edit it.", C.DIM, 12)
    }

    private func flareEditEl(_ p: UIStackView, _ l: Layer, _ f: Flare) {
        if f.els.isEmpty { text(p, "Add an element in the Elements tab first.", C.DIM, 13); return }
        let e = f.els[flSel]
        text(p, "Editing: " + e.label() + "  (" + String(flSel + 1) + " of " + String(f.els.count) + ")", C.GREEN, 14, true)
        p.addArrangedSubview(chipRow(FlareEl.TYPES, e.type) { [weak self] i in
            guard let self = self else { return }
            e.type = i
            self.refreshFlare(); self.render()
        })
        addPlain(p, "Position on axis", -1, 3, e.pos, 2) { e.pos = $0; self.render() }
        addPlain(p, "Size", 0.01, 2, e.size, 3) { e.size = $0; self.render() }
        if e.type == 0 || e.type == 2 || e.type == 1 || e.type == 5 { addPlain(p, "Stretch (width / height)", 0.1, 20, e.stretch, 2) { e.stretch = $0; self.render() } }
        addPlain(p, "Rotation", -180, 180, e.rot, 0) { e.rot = $0; self.render() }
        addPlain(p, "Brightness", 0, 4, e.bright, 2) { e.bright = $0; self.render() }
        addPlain(p, "Softness", 0, 1, e.soft, 2) { e.soft = $0; self.render() }
        if e.type == 1 || e.type == 2 || e.type == 4 || e.type == 5 { addPlain(p, e.type == 4 ? "Outline thickness (1 = filled)" : "Thickness", 0.01, 1, e.thick, 2) { e.thick = $0; self.render() } }
        if e.type == 4 { addPlain(p, "Sides", 3, 12, Float(e.sides), 0) { e.sides = Int($0); self.render() } }
        if e.type == 3 { addPlain(p, "Rays", 2, 32, Float(e.rays), 0) { e.rays = Int($0); self.render() } }
        if e.type == 1 || e.type == 4 || e.type == 5 { addPlain(p, "Rainbow fringe", 0, 1, e.chroma, 2) { e.chroma = $0; self.render() } }
        let fo = SwitchRow()
        fo.label = "Turn with the flare axis"
        fo.on = e.follow
        fo.onToggle = { e.follow = $0; self.render() }
        put(p, fo, 52)
        text(p, "Color", C.GREEN, 13, true)
        addColorRow(p, e.color) { [weak self] c in e.color = c; self?.render() }
    }

    private func flareGlobal(_ p: UIStackView, _ l: Layer, _ f: Flare) {
        text(p, "Whole flare", C.GREEN, 14, true)
        text(p, "Tint (multiplies every element)", C.DIM, 12)
        addColorRow(p, f.tint) { [weak self] c in f.tint = c; self?.render() }
        for d in Defs.flare {
            let tr = l.track(d.key)
            addPlain(p, d.label, d.min, d.max, tr.base, d.dec) { [weak self] v in
                tr.base = v
                self?.render()
            }
            if !tr.keys.isEmpty { text(p, d.label + " is keyframed. Edit it in the layer's Edit panel.", C.AMBER, 11) }
        }
        text(p, "3D and camera", C.GREEN, 14, true)
        addPlain(p, "Size change with distance", 0, 1, f.depthScale, 2) { [weak self] in f.depthScale = $0; self?.render() }
        addPlain(p, "Fade when the light leaves the screen", 0.01, 1.5, f.edgeFade, 2) { [weak self] in f.edgeFade = $0; self?.render() }
        let d3 = SwitchRow()
        d3.label = "3D layer (follows the camera)"
        d3.on = l.is3d
        d3.onToggle = { [weak self] _ in
            self?.toggle3d()
            self?.refreshFlare()
        }
        put(p, d3, 52)
        text(p, "With 3D on, the light is projected through the camera. Drag the light in the preview to place it.", C.DIM, 12)
    }

    // ---------------------------------------------------------------- motion blur settings + parent popup

    private func showMotionBlurSettings(_ l: Layer) {
        let box = vStack()
        box.isLayoutMarginsRelativeArrangement = true
        box.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 4, leading: 4, bottom: 4, trailing: 4)
        let on = SwitchRow()
        on.label = "Motion blur"
        on.on = l.mblur
        on.onToggle = { [weak self] v in
            guard let self = self else { return }
            self.pushUndo()
            l.mblur = v
            self.mbToggle.on = v
            self.render()
        }
        put(box, on, 52)
        let stut = SwitchRow()
        stut.label = "Stuttering"
        stut.on = l.mbStutter
        stut.onToggle = { [weak self] v in self?.pushUndo(); l.mbStutter = v; self?.render() }
        put(box, stut, 52)
        let rgb = SwitchRow()
        rgb.label = "Enable RGB sampling"
        rgb.on = l.mbRgb
        rgb.onToggle = { [weak self] v in self?.pushUndo(); l.mbRgb = v; self?.render() }
        put(box, rgb, 52)
        text(box, "Quality", C.DIM, 13)
        let smp = l.track("mbSamples")
        let q = smp.base <= 5 ? 0 : smp.base <= 10 ? 1 : 2
        box.addArrangedSubview(chipRow(["Low", "Medium", "High"], q) { [weak self] i in
            guard let self = self else { return }
            self.pushUndo()
            smp.keys.removeAll()
            smp.base = [4, 8, 16][i]
            self.render()
        })
        let amt = l.track("mbAmount")
        addPlain(box, "Blur strength", 0, 4, amt.base, 2) { [weak self] v in
            guard let self = self else { return }
            self.pushUndo()
            amt.keys.removeAll()
            amt.base = v
            self.render()
        }
        if l.type == .CAMERA { text(box, "Camera motion blur: every 3D layer below this camera is blurred by the camera's movement.", C.DIM, 12) }
        text(box, "Stuttering snaps the blur samples to whole frames. RGB sampling gives the trails a red-to-blue fringe.", C.DIM, 12)
        let sv = CapScroll()
        sv.addSubview(box)
        box.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            box.topAnchor.constraint(equalTo: sv.contentLayoutGuide.topAnchor),
            box.bottomAnchor.constraint(equalTo: sv.contentLayoutGuide.bottomAnchor),
            box.leadingAnchor.constraint(equalTo: sv.contentLayoutGuide.leadingAnchor),
            box.trailingAnchor.constraint(equalTo: sv.contentLayoutGuide.trailingAnchor),
            box.widthAnchor.constraint(equalTo: sv.frameLayoutGuide.widthAnchor)
        ])
        _ = Dlg(self).setTitle("Motion blur").setView(sv).setPositiveButton("Done", nil).show()
    }

    private func typeIcon(_ t: LayerType) -> String {
        switch t {
        case .SHAPE: return "shape"
        case .TEXT: return "text"
        case .IMAGE, .VIDEO: return "media"
        case .CAMERA: return "camera"
        case .NULL: return "nullobj"
        case .MODEL: return "cube"
        case .PARTICLES: return "particles"
        case .GROUP: return "layers"
        case .ADJUST: return "adjust"
        case .AUDIO: return "audio"
        case .FLARE: return "flare"
        }
    }

    private func showParentPopup(_ l: Layer, _ anchor: UIView) {
        let cands = Editor.scene.layers.filter { $0.id != l.id && !Layer.isDescendant($0, of: l, in: Editor.scene.layers) }
        let col = vStack()
        col.isLayoutMarginsRelativeArrangement = true
        col.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 8, leading: 8, bottom: 8, trailing: 8)
        col.backgroundColor = argbToUIColor(C.CARD)
        col.layer.cornerRadius = 16
        col.layer.borderColor = argbToUIColor(Int32(bitPattern: 0xFF3A3A42)).cgColor
        col.layer.borderWidth = 1
        let sv = CapScroll()
        sv.addSubview(col)
        col.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            col.topAnchor.constraint(equalTo: sv.contentLayoutGuide.topAnchor),
            col.bottomAnchor.constraint(lessThanOrEqualTo: sv.contentLayoutGuide.bottomAnchor),
            col.leadingAnchor.constraint(equalTo: sv.contentLayoutGuide.leadingAnchor),
            col.trailingAnchor.constraint(equalTo: sv.contentLayoutGuide.trailingAnchor),
            col.widthAnchor.constraint(equalToConstant: 240)
        ])
        func item(_ icon: String, _ name: String, _ on: Bool, _ pick: @escaping () -> Void) {
            let row = hRow()
            row.isLayoutMarginsRelativeArrangement = true
            row.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 10, bottom: 0, trailing: 10)
            row.backgroundColor = argbToUIColor(Int32(bitPattern: 0xFF2A2A30))
            row.layer.cornerRadius = 12
            if on { row.layer.borderWidth = 2; row.layer.borderColor = argbToUIColor(C.GREEN).cgColor }
            row.addArrangedSubview(wrap(IconView(icon, on ? C.GREEN : C.TEXT, 20), 32, 44, 0, 0, 0, 0))
            let tv = UILabel()
            tv.text = name
            tv.textColor = argbToUIColor(C.TEXT)
            tv.font = sysFont(15)
            tv.numberOfLines = 1
            tv.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
            row.addArrangedSubview(tv)
            let tap = TapView()
            tap.addSubview(row)
            tap.onClick = pick
            put(col, tap, 46, 3, 3)
        }
        item("close", "None", l.parentId < 0) { [weak self] in
            guard let self = self else { return }
            self.pushUndo()
            l.parentId = -1
            self.refreshTitle(); self.refreshPanel(); self.render()
            Dlg.dismissCurrent()
        }
        for c in cands {
            item(typeIcon(c.type), c.name, l.parentId == c.id) { [weak self] in
                guard let self = self else { return }
                self.pushUndo()
                l.parentId = c.id
                self.refreshTitle(); self.refreshPanel(); self.render()
                Dlg.dismissCurrent()
            }
        }
        _ = Dlg(self).setTitle("Parent").setView(sv).setNegativeButton("Close", nil).show()
    }

    @discardableResult
    private func addLayer(_ type: LayerType) -> Layer {
        pushUndo()
        let p = Editor.project
        let s = Editor.scene
        let id = p.nextId
        p.nextId += 1
        let nm: String
        switch type {
        case .SHAPE: nm = "Shape"
        case .TEXT: nm = "Text"
        case .IMAGE: nm = "Image"
        case .VIDEO: nm = "Video"
        case .CAMERA: nm = "Camera"
        case .NULL: nm = "Null"
        case .MODEL: nm = "Model"
        case .PARTICLES: nm = "Particles"
        case .GROUP: nm = "Group"
        case .ADJUST: nm = "Adjustment"
        case .AUDIO: nm = "Audio"
        case .FLARE: nm = "Optical Flare"
        }
        let l = Layer(id, "\(nm) \(id)", type)
        l.end = s.duration
        if type == .TEXT { l.color = Int32(bitPattern: 0xFFFFFFFF) }
        if type == .MODEL || type == .CAMERA { l.is3d = true }
        s.layers.append(l)
        if type == .NULL { toast("Turn on the 3D cube (top bar) so this Null can drive other layers") }
        if type == .CAMERA { toast("The camera affects layers below it that have the 3D cube on") }
        onSelect(id)
        return l
    }

    private func addParticles() {
        let l = addLayer(.SHAPE)
        l.name = "Particles \(l.id)"
        l.shape = .CIRCLE
        l.fx.append("particles")
        l.track("pShowSrc").base = 0
        expanded.insert("\(l.id):particles")
        fxTab = 0
        panel = P_FX
        showBottom(); refreshPanel()
    }

    private func cloneLayer(_ l: Layer, _ suffix: String) -> Layer {
        let c = Layer(Editor.project.nextId, l.name + suffix, l.type)
        Editor.project.nextId += 1
        c.text = l.text; c.color = l.color; c.color2 = l.color2; c.shape = l.shape; c.imagePath = l.imagePath
        c.bold = l.bold; c.italic = l.italic; c.font = l.font; c.fontPath = l.fontPath
        c.strokeW = l.strokeW; c.strokeColor = l.strokeColor; c.spacing = l.spacing
        c.borderW = l.borderW; c.borderColor = l.borderColor; c.borderPad = l.borderPad
        for an in l.anims { c.anims.append(an.copy()) }
        c.start = l.start; c.end = l.end; c.is3d = l.is3d; c.parentId = l.parentId
        c.blend = l.blend; c.srcDur = l.srcDur; c.visible = l.visible; c.srcOffset = l.srcOffset
        c.mask = l.mask; c.mblur = l.mblur
        c.fx.append(contentsOf: l.fx)
        c.fxOff.formUnion(l.fxOff)
        for (k, v) in l.inputs { c.inputs[k] = v }
        for (k, tr) in l.props {
            let n = c.track(k)
            n.base = tr.base
            n.copyExprFrom(tr)
            for key in tr.keys {
                let nk = Key(key.t, key.v, key.ease)
                nk.x1 = key.x1; nk.y1 = key.y1; nk.x2 = key.x2; nk.y2 = key.y2
                n.keys.append(nk)
            }
        }
        return c
    }

    private func targets() -> [Layer] {
        let m = Editor.scene.layers.filter { multi.contains($0.id) }
        if !m.isEmpty { return m }
        if let s = selected() { return [s] }
        return []
    }

    private func duplicateSelected() {
        let t = targets()
        if t.isEmpty { toast("Select a layer first"); return }
        pushUndo()
        var last = -1
        for l in t {
            let c = cloneLayer(l, " copy")
            Editor.scene.layers.append(c)
            last = c.id
        }
        multi.removeAll()
        multiMode = false
        onSelect(last)
    }

    private func copySelected() {
        let t = targets()
        if t.isEmpty { toast("Select a layer first"); return }
        clipboard.removeAll()
        for l in t { clipboard.append(cloneLayer(l, "")) }
        toast("Copied \(t.count)\(t.count == 1 ? " layer" : " layers")")
    }

    private func pasteLayers() {
        if clipboard.isEmpty { toast("Nothing copied yet"); return }
        pushUndo()
        var last = -1
        for c in clipboard {
            let n = cloneLayer(c, "")
            Editor.scene.layers.append(n)
            last = n.id
        }
        multi.removeAll()
        multiMode = false
        onSelect(last)
    }

    private func selectAll() {
        multi.removeAll()
        for l in Editor.scene.layers { multi.append(l.id) }
        if multi.isEmpty { toast("No layers yet"); return }
        selId = multi.last ?? -1
        refreshTitle(); refreshToolbar(); render()
        toast("All layers selected")
    }

    private func groupSelected(_ asMask: Bool = false) {
        let t = targets().filter { $0.type != .GROUP }
        if t.isEmpty { toast("Select layers first"); return }
        let g = addLayer(.GROUP)
        for l in t { l.parentId = g.id }
        multi.removeAll()
        multiMode = false
        onSelect(g.id)
        toast("Grouped \(t.count) layers")
    }

    private func addSolid() {
        let l = addLayer(.SHAPE)
        l.shape = .RECT
        l.name = "Solid \(l.id)"
        l.color = Int32(bitPattern: 0xFF2A2A33)
        let ar = Float(Editor.project.w) / Float(Editor.project.h)
        l.track("scale").base = min(max(2 * ar, 2) / 0.8 / 0.84 * 1.02, 8)
        refreshPanel(); render()
    }

    private func deleteLayer() {
        let t = targets()
        if t.isEmpty { return }
        pushUndo()
        for l in t {
            Editor.scene.layers.removeAll { $0 === l }
            for o in Editor.scene.layers where o.parentId == l.id { o.parentId = -1 }
        }
        multi.removeAll()
        multiMode = false
        onSelect(-1)
    }

    private func splitLayer(_ l: Layer, _ t: Float) -> Layer? {
        if t <= l.start + 0.04 || t >= l.end - 0.04 || l.type == .GROUP { return nil }
        let c = cloneLayer(l, "")
        c.name = l.name
        c.start = t
        if l.type == .VIDEO || l.type == .AUDIO { c.srcOffset = l.srcOffset + (t - l.start) }
        l.end = t
        var ls = Editor.scene.layers
        if let i = ls.firstIndex(where: { $0 === l }) { ls.insert(c, at: i + 1) }
        Editor.scene.layers = ls
        return c
    }

    /** Splits the selected layers (or every layer under the playhead) at the playhead. */
    private func splitAtPlayhead(_ all: Bool) {
        let t = Editor.time
        let list = all ? Editor.scene.layers : targets()
        if list.isEmpty { toast("Select a layer first"); return }
        pushUndo()
        var last: Layer? = nil
        var n = 0
        for l in list {
            if let c = splitLayer(l, t) { last = c; n += 1 }
        }
        if last == nil { toast("Move the playhead inside the layer to split it"); return }
        multi.removeAll()
        multiMode = false
        toast(n == 1 ? "Layer split" : "Split \(n) layers")
        onSelect(last!.id)
    }

    /** Moves the start or end of the selected layers to the playhead. */
    private func trimTo(_ start: Bool) {
        let list = targets()
        if list.isEmpty { toast("Select a layer first"); return }
        let t = Editor.time
        pushUndo()
        var n = 0
        for l in list {
            if l.type == .GROUP { continue }
            if start && t > l.start + 0.04 && t < l.end {
                if l.type == .VIDEO || l.type == .AUDIO { l.srcOffset += t - l.start }
                l.start = t; n += 1
            } else if !start && t < l.end - 0.04 && t > l.start {
                l.end = t; n += 1
            }
        }
        if n == 0 { toast("Move the playhead inside the layer first") } else { render() }
    }

    private func moveLayer(_ dir: Int) {
        guard let l = selected() else { return }
        pushUndo()
        var ls = Editor.scene.layers
        guard let i = ls.firstIndex(where: { $0 === l }) else { return }
        let j = i + dir
        if j < 0 || j >= ls.count { return }
        ls.remove(at: i)
        ls.insert(l, at: j)
        Editor.scene.layers = ls
        render()
    }

    private func toggle3d() {
        guard let l = selected() else { toast("Select a layer first"); return }
        if l.type == .MODEL || l.type == .CAMERA { toast("This layer is always 3D"); return }
        pushUndo()
        l.is3d = !l.is3d
        refreshTitle(); refreshPanel(); render()
        toast(l.is3d ? "3D on" : "3D off")
    }

    private func showLayersMenu() {
        let labels = ["Select All Layers",
                      multiMode ? "Stop Selecting Multiple" : "Select Multiple Layers",
                      "Group Layers", "Show All Keyframes",
                      "Split at Playhead", "Split All Layers at Playhead", "Copy Layer", "Paste Layer",
                      "Duplicate Layer", "Move Layer Up", "Move Layer Down",
                      overlay.guides ? "Hide Guides" : "Show Guides", "Delete Layer", "Mask Group"]
        let icons = ["layers", "check", "layers", "graph", "split", "split", "dup", "import", "dup",
                     "chev_up", "chev_down", "dots", "trash", "mask"]
        Dlg(self).setTitle("Layers").setIconItems(labels, icons) { [weak self] _, w in
            guard let self = self else { return }
            switch w {
            case 0: self.selectAll()
            case 1:
                self.multiMode = !self.multiMode
                if !self.multiMode { self.multi.removeAll() }
                self.render()
                self.toast(self.multiMode ? "Tap layers to select them" : "Multi select off")
            case 2: self.groupSelected()
            case 3: self.timeline.expandAll()
            case 4: self.splitAtPlayhead(false)
            case 5: self.splitAtPlayhead(true)
            case 6: self.copySelected()
            case 7: self.pasteLayers()
            case 8: self.duplicateSelected()
            case 9: self.moveLayer(1)
            case 10: self.moveLayer(-1)
            case 11:
                self.overlay.guides = !self.overlay.guides
                self.overlay.setNeedsDisplay()
            case 13: self.groupSelected(true)
            default: self.deleteLayer()
            }
        }.show()
    }

    // ---------------------------------------------------------------- expressions, audio, beats

    private func showExpression(_ l: Layer, _ d: PropDef) {
        let tr = l.track(d.key)
        let box = vStack()
        box.isLayoutMarginsRelativeArrangement = true
        box.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 4, leading: 4, bottom: 4, trailing: 4)
        let sw = SwitchRow()
        sw.label = "fx  (expression)"
        sw.on = tr.exprOn && !tr.exprSrc.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        sw.captionOn = "On"; sw.captionOff = "Off"
        var swOn = sw.on
        sw.onToggle = { v in swOn = v }
        put(box, sw, 52)
        text(box, "t = time, v = keyframed value. wiggle(freq, amp), sin, cos, abs, min, max, clamp, pow, sqrt, linear(t, a, b, c, d), noise, floor, round, mix, if(c, a, b), step(a, b), comparisons < > <= >= ==, pi, marker.key(\"name\").", C.DIM, 12)
        let et = makeField(tr.exprSrc)
        et.font = monoFont(14)
        et.placeholder = "v + wiggle(3, 0.1)"
        put(box, et, 44)
        let presets = ["v + wiggle(3, 0.1)", "v * (1 + 0.2 * sin(t * 8))", "v + t * 90", "v + abs(sin(t * 4)) * 0.3", ""]
        box.addArrangedSubview(chipRow(["Wiggle", "Pulse", "Spin", "Bounce", "Clear"], -1) { i in
            et.text = presets[i]
        })
        let names = Editor.scene.markerNames.values.sorted()
        if !names.isEmpty {
            text(box, "Named markers (tap to insert)", C.DIM, 12)
            box.addArrangedSubview(chipRow(names, -1) { i in
                let ins = "marker.key(\"" + names[i] + "\")"
                let s = (et.text ?? "") as NSString
                var pos = 0
                if let r = et.selectedTextRange {
                    pos = et.offset(from: et.beginningOfDocument, to: r.start)
                }
                let p = min(max(0, pos), s.length)
                et.text = s.replacingCharacters(in: NSRange(location: p, length: 0), with: ins)
            })
        }
        Dlg(self).setTitle("Expression: " + d.label).setView(box).setPositiveButton("Apply") { [weak self] _, _ in
            guard let self = self else { return }
            self.pushUndo()
            let src = et.text ?? ""
            if !tr.setExpr(src) {
                self.toast("Expression error")
            } else {
                tr.exprOn = swOn && !src.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                self.refreshPanel(); self.render()
            }
        }.setNegativeButton("Cancel", nil).show()
    }

    private func extractAudio(_ l: Layer) {
        guard let src = l.imagePath else { return }
        toast("Extracting audio...")
        safeThread("extract-audio") { [weak self] in
            let f = Paths.cache.appendingPathComponent("audio_\(nowMs()).m4a")
            if !AudioTools.extractAudio(src, f) {
                DispatchQueue.main.async { self?.toast("This video has no audio track") }
                return
            }
            // PORT NOTE: Android also copied the m4a into MediaStore Music/SaikiMotion; the
            // user-visible copy lands in <Documents>/SaikiMotion on iOS (Files app).
            let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
                .appendingPathComponent("SaikiMotion", isDirectory: true)
            try? FileManager.default.createDirectory(at: docs, withIntermediateDirectories: true)
            let base = self?.beforeLast((l.name as NSString).lastPathComponent, ".") ?? ""
            let music = docs.appendingPathComponent(base + ".m4a")
            try? FileManager.default.removeItem(at: music)
            try? FileManager.default.copyItem(at: f, to: music)
            let mf = Projects.mediaDir().appendingPathComponent("\(nowMs())_" + (self?.alnum(base) ?? "") + ".m4a")
            try? FileManager.default.removeItem(at: mf)
            try? FileManager.default.copyItem(at: f, to: mf)
            try? FileManager.default.removeItem(at: f)
            DispatchQueue.main.async {
                self?.toast("Saved to Documents/SaikiMotion and added as an audio layer")
                self?.addMedia(mf.path, .AUDIO)
            }
        }
    }

    private func beatsFrom(_ path: String, _ offset: Float) {
        if path.isEmpty { toast("Could not analyze audio"); return }
        toast("Analyzing beats...")
        safeThread("beats") { [weak self] in
            let beats = AudioTools.detectBeats(path)
            DispatchQueue.main.async {
                guard let self = self else { return }
                self.pushUndo()
                var ms = Editor.scene.markers
                var n = 0
                for b in beats {
                    let t = offset + b
                    if t <= Editor.scene.duration && !ms.contains(where: { abs($0 - t) < 0.05 }) {
                        ms.append(t); n += 1
                    }
                }
                Editor.scene.markers = ms
                self.render()
                self.toast("Added \(n) beat markers")
            }
        }
    }

    private func snapKeys(_ l: Layer) {
        let ms = Editor.scene.markers
        for (_, tr) in l.props {
            var ch = false
            for k in tr.keys {
                if let m = ms.min(by: { abs($0 - k.t) < abs($1 - k.t) }) {
                    if abs(m - k.t) < 0.35 { k.t = m; ch = true }
                }
            }
            if ch { tr.keys.sort { $0.t < $1.t } }
        }
        toast("Keyframes snapped to markers")
    }

    // ================================================================ importing

    private func pickFile(_ req: Int, _ types: [UTType]) {
        pendingPick = req
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: types, asCopy: true)
        picker.delegate = self
        picker.allowsMultipleSelection = false
        present(picker, animated: true)
    }

    /// Adds media through an options sheet: the photo library first (PHPicker), then Files.
    /// `photos` is enabled for images and videos; audio and models go straight to Files.
    private func pickMedia(_ req: Int, _ types: [UTType], _ photos: Bool = true) {
        guard photos else { pickFile(req, types); return }
        let sheet = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        let photoLabel = req == R_VIDEO ? "Photo Library (video)" : req == R_IMAGE ? "Photo Library" : "Choose from Files"
        if req == R_IMAGE || req == R_VIDEO {
            sheet.addAction(UIAlertAction(title: photoLabel, style: .default) { [weak self] _ in
                self?.pickFromPhotos(req)
            })
            sheet.addAction(UIAlertAction(title: "Choose from Files", style: .default) { [weak self] _ in
                self?.pickFile(req, types)
            })
        } else {
            sheet.addAction(UIAlertAction(title: "Choose from Files", style: .default) { [weak self] _ in
                self?.pickFile(req, types)
            })
        }
        sheet.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        if let pop = sheet.popoverPresentationController { pop.sourceView = view; pop.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.maxY - 60, width: 1, height: 1) }
        present(sheet, animated: true)
    }

    /// PHPickerViewController: photo-library import for image/video (in-place load, no copy needed).
    private func pickFromPhotos(_ req: Int) {
        pendingPick = req
        var config = PHPickerConfiguration()
        config.filter = req == R_VIDEO ? .videos : .images
        config.selectionLimit = 1
        let picker = PHPickerViewController(configuration: config)
        picker.delegate = self
        present(picker, animated: true)
    }

    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        picker.dismiss(animated: true)
        let req = pendingPick
        guard let item = results.first else { return }
        let wantVideo = req == R_VIDEO
        let supported = item.itemProvider.registeredTypeIdentifiers.first { uti in
            let t = UTType(uti)
            return t?.conforms(to: .movie) == true || t?.conforms(to: .image) == true || t?.conforms(to: .audiovisualContent) == true
        }
        guard let uti = supported ?? item.itemProvider.registeredTypeIdentifiers.first else {
            toast("This item is not supported")
            return
        }
        let type = UTType(uti)
        let isVid = (type?.conforms(to: .movie) == true || type?.conforms(to: .audiovisualContent) == true) && wantVideo
        toast("Importing...")
        if isVid, item.itemProvider.hasRepresentationConforming(toTypeIdentifier: UTType.movie.identifier, fileOptions: []) {
            // R12/R14 lesson: the abstract "public.movie" UTI sometimes fails
            // even when a representation exists — try the item's own registered
            // identifiers in order before giving up.
            let utis = [UTType.movie.identifier] + item.itemProvider.registeredTypeIdentifiers.filter { $0 != UTType.movie.identifier }
            loadVideo(utis, at: 0, provider: item.itemProvider)
            return
        }
        item.itemProvider.loadDataRepresentation(forTypeIdentifier: uti) { [weak self] data, _ in
            DispatchQueue.main.async {
                guard let self = self else { return }
                guard let data = data else { self.toast("Could not read the item"); return }
                let ext = (type?.preferredFilenameExtension ?? (req == R_VIDEO ? "mov" : "png")).lowercased()
                let name = String(Int(Date().timeIntervalSince1970 * 1000)) + "_photo." + ext
                let f = Projects.mediaDir().appendingPathComponent(name)
                do { try data.write(to: f, options: .atomic) } catch { self.toast("Import failed"); return }
                // A photo-library "video" without a movie representation falls back to a still.
                self.addMedia(f.path, req == R_VIDEO && !isVid ? .IMAGE : (req == R_VIDEO ? .VIDEO : .IMAGE))
            }
        }
    }

    /// Sequential video load with retry (rounds 12/14): each candidate type
    /// identifier is tried in turn; only when all fail does the user see the
    /// error. All ownership stays with ARC — the round-17 bug was raw
    /// unretained provider/block pointers; that class of bug cannot exist here.
    private func loadVideo(_ utis: [String], at i: Int, provider: NSItemProvider) {
        guard i < utis.count else {
            DispatchQueue.main.async { [weak self] in self?.toast("Could not read the video") }
            return
        }
        CrashLog.note("impv")
        provider.loadFileRepresentation(forTypeIdentifier: utis[i]) { [weak self] url, _ in
            if let url = url { self?.importPickedVideo(url); return }
            self?.loadVideo(utis, at: i + 1, provider: provider)
        }
    }

    /// Videos picked from the library arrive as file URLs that vanish after the callback:
    /// copy them into the sandbox before returning.
    private func importPickedVideo(_ url: URL) {
        safeThread("video-copy") { [weak self] in
            let name = String(Int(Date().timeIntervalSince1970 * 1000)) + "_" + url.lastPathComponent.replacingOccurrences(of: " ", with: "_")
            let f = Projects.mediaDir().appendingPathComponent(name)
            try? FileManager.default.removeItem(at: f)
            var ok = false
            do { try FileManager.default.copyItem(at: url, to: f); ok = true } catch { }
            DispatchQueue.main.async {
                if ok { self?.addMedia(f.path, .VIDEO) } else { self?.toast("Import failed") }
            }
        }
    }

    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let url = urls.first else { return }
        let req = pendingPick
        if req == R_FX || req == R_PRESET {
            do {
                let txt = try String(contentsOf: url, encoding: .utf8)
                if req == R_FX {
                    if let err = Registry.addCustom(txt) {
                        toast(err)
                    } else {
                        toast("Effect imported")
                        EffectThumbs.generate(self, preview) { [weak self] in self?.refreshPanel() }
                        refreshPanel()
                    }
                } else {
                    let o = try JObj(json: txt)
                    _ = try o.getString("name")
                    Registry.savePreset(o)
                    toast("Preset imported")
                    refreshPanel()
                }
            } catch { toast("Could not read file") }
            return
        }
        if req == R_FONT {
            guard let tl = selected() else { return }
            safeThread("font") { [weak self] in
                let p = ProjectIO.copyMediaIntoSandbox(url: url, kind: "font")
                DispatchQueue.main.async {
                    guard let self = self else { return }
                    if let p = p {
                        self.pushUndo()
                        tl.fontPath = p
                        self.refreshPanel(); self.render()
                    } else {
                        self.toast("Could not load the font")
                    }
                }
            }
            return
        }
        if req == R_BEAT {
            safeThread("beat-copy") { [weak self] in
                let f = Paths.cache.appendingPathComponent("beat_src")
                let scoped = url.startAccessingSecurityScopedResource()
                defer { if scoped { url.stopAccessingSecurityScopedResource() } }
                try? FileManager.default.removeItem(at: f)
                var ok = false
                do { try FileManager.default.copyItem(at: url, to: f); ok = true } catch { }
                DispatchQueue.main.async {
                    if ok { self?.beatsFrom(f.path, 0) } else { self?.toast("Could not read audio") }
                }
            }
            return
        }
        toast("Importing...")
        safeThread("import-media") { [weak self] in
            let type: LayerType = req == R_VIDEO ? .VIDEO : (req == R_GLB ? .MODEL : (req == R_AUDIOFILE ? .AUDIO : .IMAGE))
            let p = ProjectIO.copyMediaIntoSandbox(url: url, kind: "")
            DispatchQueue.main.async {
                guard let self = self else { return }
                if let p = p { self.addMedia(p, type) } else { self.toast("Import failed") }
            }
        }
    }

    private func addMedia(_ path: String, _ type: LayerType) {
        let l = addLayer(type)
        l.imagePath = path
        l.name = afterFirst((path as NSString).lastPathComponent, "_")
        if type == .VIDEO || type == .AUDIO {
            // MediaMetadataRetriever.METADATA_KEY_DURATION → AVAsset duration
            let asset = AVURLAsset(url: URL(fileURLWithPath: path))
            let dur = CMTimeGetSeconds(asset.duration)
            if dur.isFinite && dur > 0 {
                l.srcDur = Float(dur)
                let s = Editor.scene
                if l.srcDur > 0.5 { s.duration = max(s.duration, min(600, l.start + l.srcDur)) }
                l.end = min(s.duration, l.start + max(l.srcDur, 0.5))
            }
        }
        refreshTitle(); refreshPanel(); render()
    }

    /// Kotlin exportText wrote into MediaStore Downloads; on iOS the Files-app location is
    /// <Documents>/SaikiMotion (the same convention ProjectIO uses for project exports).
    private func exportText(_ name: String, _ content: String) {
        do {
            let d = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
                .appendingPathComponent("SaikiMotion", isDirectory: true)
            try FileManager.default.createDirectory(at: d, withIntermediateDirectories: true)
            guard let data = content.data(using: .utf8) else { throw NSError(domain: "saiki", code: 1) }
            try data.write(to: d.appendingPathComponent(name))
            toast("Saved to Documents/SaikiMotion/" + name)
        } catch { toast("Export failed") }
    }

    // ================================================================ panels

    private func refreshPanel() {
        panelList.arrangedSubviews.forEach { $0.removeFromSuperview() }
        rows.removeAll()
        if panel == P_NONE { return }
        if panel == P_MEDIA { buildMedia() }
        else if panel == P_SHAPES { buildShapes() }
        else {
            guard let l = selected() else { closePanel(); return }
            switch panel {
            case P_EDIT: buildEdit(l)
            case P_XFORM: buildXform(l)
            case P_FX: buildFx(l)
            case P_BLEND: buildBlend(l)
            case P_SPEED: buildSpeed(l)
            case P_GRAPH: buildGraph(l)
            default: break
            }
        }
        syncRows()
    }

    private func addRow(_ parent: UIStackView, _ l: Layer, _ d: PropDef, _ label: String? = nil) {
        if d.options != nil { addOptionRow(parent, l, d); return }
        let tr = l.track(d.key)
        let s = RulerSlider(frame: .zero)
        s.label = label ?? d.label
        s.lo = d.min; s.hi = d.max; s.dec = d.dec
        s.infinite = d.inf
        s.span = d.span > 0 ? d.span : 1
        s.onExprIcon = { [weak self] in self?.showExpression(l, d) }
        s.value = tr.eval(l.editTime(d.key, Editor.time))
        s.onBegin = { [weak self] in
            guard let self = self else { return }
            self.pushUndo()
            self.selKey = d.key
            self.syncRows(s)
        }
        s.onChange = { [weak self] v in
            guard let self = self else { return }
            tr.set(l.editTime(d.key, Editor.time), v, self.autoKeyOn)
            self.syncRows(s)
            self.render()
        }
        s.onLabelTap = { [weak self] in
            guard let self = self else { return }
            self.selKey = d.key
            self.syncRows()
        }
        s.onLabelLong = { [weak self] in self?.showExpression(l, d) }
        put(parent, s, 60)
        rows.append(Row(s, d, l))
    }

    private func addOptionRow(_ parent: UIStackView, _ l: Layer, _ d: PropDef) {
        let tr = l.track(d.key)
        let opts = d.options ?? []
        if opts.count == 2 {
            let sw = SwitchRow()
            sw.label = d.label
            sw.on = tr.base >= 0.5
            sw.captionOff = opts[0]; sw.captionOn = opts[1]
            sw.onToggle = { [weak self] v in
                guard let self = self else { return }
                self.pushUndo()
                tr.keys.removeAll()
                tr.base = v ? 1 : 0
                self.render()
            }
            put(parent, sw, 52)
            return
        }
        text(parent, d.label, C.TEXT, 14, true)
        parent.addArrangedSubview(chipRow(opts, ktInt(tr.base)) { [weak self] i in
            guard let self = self else { return }
            self.pushUndo()
            tr.keys.removeAll()
            tr.base = Float(i)
            self.refreshPanel()
            self.render()
        })
    }

    private func addPlain(_ parent: UIStackView, _ label: String, _ lo: Float, _ hi: Float, _ v: Float,
                          _ dec: Int, _ onChange: @escaping (Float) -> Void) {
        let s = RulerSlider(frame: .zero)
        s.label = label; s.lo = lo; s.hi = hi; s.value = v; s.dec = dec; s.canKey = false
        s.onBegin = { [weak self] in self?.pushUndo() }
        s.onChange = onChange
        put(parent, s, 60)
    }

    private func syncRows(_ except: RulerSlider? = nil) {
        for r in rows {
            let tr = r.layer.track(r.d.key)
            let t = r.layer.editTime(r.d.key, Editor.time)
            if r.slider !== except { r.slider.value = tr.eval(t) }
            r.slider.hasKey = tr.keyAt(t) != nil
            r.slider.hasAnim = !tr.keys.isEmpty
            r.slider.hasExpr = tr.exprActive()
            r.slider.rowSelected = r.d.key == selKey
            r.slider.setNeedsDisplay()
        }
        diamondSide.set("diamond_f",
                        rows.contains(where: { $0.d.key == selKey && $0.slider.hasKey }) ? C.GREEN
                        : (rows.contains(where: { $0.d.key == selKey }) ? C.TEXT : C.DIM))
    }

    /** Adds or removes a keyframe on the parameter that was tapped last. */
    private func keySelected() {
        guard let r = rows.first(where: { $0.d.key == selKey }) else {
            toast("Tap a parameter first, then tap the keyframe button")
            return
        }
        pushUndo()
        r.layer.track(r.d.key).toggleKey(r.layer.editTime(r.d.key, Editor.time))
        syncRows(); render()
    }

    /** Full color picker: saturation, hue, opacity, hex and an eyedropper that samples the preview. */
    private func showColorPicker(_ initial: Int32, _ onPick: @escaping (Int32) -> Void) {
        let box = vStack()
        box.isLayoutMarginsRelativeArrangement = true
        box.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 4, leading: 4, bottom: 4, trailing: 4)
        let cp = ColorPickerView(frame: .zero)
        cp.setColor(initial)
        put(box, cp, 250, 0, 0)
        let row = hRow()
        row.isLayoutMarginsRelativeArrangement = true
        row.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 10, leading: 0, bottom: 6, trailing: 0)
        let hex = makeField("")
        hex.font = monoFont(14)
        hex.text = String(format: "%08X", UInt32(bitPattern: initial))
        hex.placeholder = "#RRGGBB"
        let sw = UIView()
        sw.backgroundColor = argbToUIColor(initial)
        var lock = false
        cp.onChange = { c in
            sw.backgroundColor = argbToUIColor(c)
            lock = true
            hex.text = String(format: "%08X", UInt32(bitPattern: c))
            lock = false
            onPick(c)
        }
        bind(hex) { s in
            if lock { return }
            var t = s.trimmingCharacters(in: .whitespaces)
            if t.hasPrefix("#") { t.removeFirst() }
            var v: Int32? = nil
            if t.count == 6, let u = UInt64(t, radix: 16) {
                v = Int32(bitPattern: UInt32(0xFF000000) | UInt32(u))
            } else if t.count == 8, let u = UInt64(t, radix: 16) {
                v = Int32(bitPattern: UInt32(u))
            }
            if let v = v {
                cp.setColor(v)
                sw.backgroundColor = argbToUIColor(v)
                onPick(v)
            }
        }
        row.addArrangedSubview(wrap(hex, 0, 40, 0, 0, 0, 0))
        row.addArrangedSubview(wrap(sw, 52, 40, 0, 0, 0, 0))
        box.addArrangedSubview(row)
        var ref: Dlg? = nil
        put(box, pill("Pen: pick a color from the preview", "pipette") { [weak self] in
            ref?.dismiss()
            self?.startEyedropper { c in
                self?.showColorPicker(c, onPick)
                onPick(c)
            }
        }, 44, 6, 6)
        pushUndo()
        ref = Dlg(self).setTitle("Color").setView(box).setPositiveButton("Done", nil).show()
    }

    private func startEyedropper(_ cb: @escaping (Int32) -> Void) {
        toast("Tap the preview to pick a color")
        overlay.pick = { [weak self] x, y in
            guard let self = self else { return }
            let w = Int(self.preview.bounds.width)
            let h = Int(self.preview.bounds.height)
            guard w > 0, h > 0 else { return }
            // PORT NOTE: PixelCopy.request → drawHierarchy snapshot read through a 1x1 context.
            let fmt = UIGraphicsImageRendererFormat()
            fmt.scale = 1
            let r = UIGraphicsImageRenderer(size: CGSize(width: w, height: h), format: fmt)
            let img = r.image { _ in self.preview.drawHierarchy(in: self.preview.bounds, afterScreenUpdates: false) }
            guard img.cgImage != nil else { self.toast("Could not read the preview"); return }
            var px: [UInt8] = [0, 0, 0, 0]
            if let ctx = CGContext(data: &px, width: 1, height: 1, bitsPerComponent: 8, bytesPerRow: 4,
                                   space: CGColorSpaceCreateDeviceRGB(),
                                   bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) {
                ctx.interpolationQuality = .none
                let ix = clamp(Int(x), 0, w - 1)
                let iy = clamp(Int(y), 0, h - 1)
                UIGraphicsPushContext(ctx)
                img.draw(in: CGRect(x: -CGFloat(ix), y: -CGFloat(iy), width: CGFloat(w), height: CGFloat(h)))
                UIGraphicsPopContext()
                cb(argbColor(255, Int(px[0]), Int(px[1]), Int(px[2])))
            } else {
                self.toast("Eyedropper is not available here")
            }
        }
    }

    private func colorRow(_ cur: Int32, _ onPick: @escaping (Int32) -> Void) -> UIView {
        let colors: [Int32] = [Int32(bitPattern: 0xFFFFFFFF), Int32(bitPattern: 0xFF000000),
                               Int32(bitPattern: 0xFFF44336), Int32(bitPattern: 0xFFFF9800),
                               Int32(bitPattern: 0xFFFFEB3B), Int32(bitPattern: 0xFF22C55E),
                               Int32(bitPattern: 0xFF00E5FF), Int32(bitPattern: 0xFF2979FF),
                               Int32(bitPattern: 0xFF7C4DFF), Int32(bitPattern: 0xFFFF4081)]
        let row = hRow()
        let now = TapView()
        now.backgroundColor = argbToUIColor(cur)
        now.onClick = { [weak self] in self?.showColorPicker(cur, onPick) }
        row.addArrangedSubview(wrap(now, 44, 36, 4, 6, 10, 6))
        for col in colors {
            let v = TapView()
            v.backgroundColor = argbToUIColor(col)
            v.onClick = { onPick(col) }
            row.addArrangedSubview(wrap(v, 32, 32, 3, 6, 3, 6))
        }
        let more = RainbowCircleView()
        more.onClick = { [weak self] in self?.showColorPicker(cur, onPick) }
        row.addArrangedSubview(wrap(more, 36, 36, 8, 4, 4, 4))
        let sv = UIScrollView()
        sv.showsHorizontalScrollIndicator = false
        row.translatesAutoresizingMaskIntoConstraints = false
        sv.addSubview(row)
        NSLayoutConstraint.activate([
            row.leadingAnchor.constraint(equalTo: sv.contentLayoutGuide.leadingAnchor),
            row.trailingAnchor.constraint(equalTo: sv.contentLayoutGuide.trailingAnchor),
            row.topAnchor.constraint(equalTo: sv.contentLayoutGuide.topAnchor),
            row.bottomAnchor.constraint(equalTo: sv.contentLayoutGuide.bottomAnchor),
            row.heightAnchor.constraint(equalTo: sv.frameLayoutGuide.heightAnchor)
        ])
        return sv
    }

    private func addColorRow(_ parent: UIStackView, _ cur: Int32, _ onPick: @escaping (Int32) -> Void) {
        parent.addArrangedSubview(wrap(colorRow(cur, onPick), 0, 48, 0, 0, 0, 0))
    }

    private func setColorParam(_ l: Layer, _ cp: ColorParam, _ col: Int32) {
        let vals: [(String, Int)] = [("_r", colorRed(col)), ("_g", colorGreen(col)),
                                     ("_b", colorBlue(col)), ("_a", colorAlpha(col))]
        for (suffix, v) in vals {
            let tr = l.track(cp.key + suffix)
            tr.keys.removeAll()
            tr.base = Float(v) / 255
        }
    }

    private func addColorParam(_ parent: UIStackView, _ l: Layer, _ cp: ColorParam) {
        func cur() -> Int32 {
            argbColor(ktInt(l.p(cp.key + "_a", 0) * 255), ktInt(l.p(cp.key + "_r", 0) * 255),
                      ktInt(l.p(cp.key + "_g", 0) * 255), ktInt(l.p(cp.key + "_b", 0) * 255))
        }
        let row = hRow()
        row.alignment = .fill
        row.backgroundColor = argbToUIColor(C.CARD)
        row.isLayoutMarginsRelativeArrangement = true
        row.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 14, bottom: 0, trailing: 10)
        let tv = UILabel()
        tv.text = cp.label
        tv.textColor = argbToUIColor(C.TEXT)
        tv.font = boldFont(15)
        tv.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
        row.addArrangedSubview(tv)
        let sw = TapView()
        sw.backgroundColor = argbToUIColor(cur())
        sw.onClick = { [weak self] in
            self?.showColorPicker(cur()) { col in
                self?.setColorParam(l, cp, col)
                sw.backgroundColor = argbToUIColor(col)
                self?.render()
            }
        }
        row.addArrangedSubview(wrap(sw, 72, 34, 0, 0, 0, 0))
        put(parent, row, 52)
    }

    // ---------------------------------------------------------------- media + shapes

    private func buildMedia() {
        let p: UIStackView = panelList
        text(p, "Media", C.TEXT, 16, true)
        put(p, pill("Import video", "import") { [weak self] in self?.pickMedia(R_VIDEO, [.movie, .audiovisualContent]) }, 44)
        put(p, pill("Import image", "import") { [weak self] in self?.pickMedia(R_IMAGE, [.image]) }, 44)
        put(p, pill("Import audio", "import") { [weak self] in self?.pickMedia(R_AUDIOFILE, [.audio]) }, 44)
        put(p, pill("Import 3D model (.glb)", "import") { [weak self] in self?.pickFile(R_GLB, glbTypes()) }, 44)
        put(p, pill("Beat markers from an audio file", "graph") { [weak self] in self?.pickFile(R_BEAT, [.audio]) }, 44)
        var files: [URL] = (try? FileManager.default.contentsOfDirectory(
            at: Projects.mediaDir(), includingPropertiesForKeys: [.contentModificationDateKey])) ?? []
        files.sort { a, b in
            let da = (try? a.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate)?.timeIntervalSince1970 ?? 0
            let db = (try? b.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate)?.timeIntervalSince1970 ?? 0
            return da > db
        }
        files = Array(files.prefix(12))
        if !files.isEmpty { text(p, "Recent media", C.DIM, 13) }
        for f in files {
            let ext = f.pathExtension.lowercased()
            let type: LayerType
            if ext == "glb" { type = .MODEL }
            else if ["mp4", "mov", "mkv", "webm", "3gp", "m4v"].contains(ext) { type = .VIDEO }
            else if ["m4a", "mp3", "aac", "wav", "ogg", "flac"].contains(ext) { type = .AUDIO }
            else { type = .IMAGE }
            let ic = type == .VIDEO ? "media" : (type == .MODEL ? "cube" : "media")
            put(p, pill(afterFirst(f.lastPathComponent, "_"), ic) { [weak self] in
                self?.addMedia(f.path, type)
            }, 40)
        }
    }

    private func buildShapes() {
        text(panelList, "Add shape", C.TEXT, 16, true)
        let all: [ShapeKind] = [.RECT, .ROUND, .CIRCLE, .TRIANGLE, .STAR]
        let names = all.map { cap($0.rawValue.lowercased()) }
        panelList.addArrangedSubview(chipRow(names, -1) { [weak self] i in
            guard let self = self else { return }
            let l = self.addLayer(.SHAPE)
            l.shape = all[i]
            self.render()
        })
    }

    // ---------------------------------------------------------------- edit

    private func buildEdit(_ l: Layer) {
        let p: UIStackView = panelList
        switch l.type {
        case .TEXT:
            buildText(p, l)
        case .SHAPE:
            text(p, "Shape", C.TEXT, 16, true)
            let all: [ShapeKind] = [.RECT, .ROUND, .CIRCLE, .TRIANGLE, .STAR]
            let names = all.map { cap($0.rawValue.lowercased()) }
            p.addArrangedSubview(chipRow(names, all.firstIndex(of: l.shape) ?? 0) { [weak self] i in
                guard let self = self else { return }
                self.pushUndo()
                l.shape = all[i]
                self.refreshPanel(); self.render()
            })
            text(p, "Color", C.DIM)
            addColorRow(p, l.color) { [weak self] c in self?.pushUndo(); l.color = c; self?.render() }
        case .GROUP:
            text(p, "Group", C.TEXT, 16, true)
            text(p, "Put layers inside with Parent in their Transform panel. Tap the ^ arrow in the timeline to open or close the group. Groups can have effects, and 3D layers inside a group keep their 3D look.", C.DIM, 12)
            text(p, "Mask", C.GREEN, 13, true)
            text(p, "The top layer inside the group masks the layers beneath it.", C.DIM, 12)
            p.addArrangedSubview(chipRow(["None", "Alpha", "Inverted alpha", "Luma", "Inverted luma"], l.mask) { [weak self] i in
                guard let self = self else { return }
                self.pushUndo()
                l.mask = i
                self.refreshPanel(); self.render()
            })
        case .AUDIO:
            text(p, "Audio", C.TEXT, 16, true)
            text(p, l.name)
            addRow(p, l, Defs.audio[0])
            put(p, pill("Beat markers from this audio", "graph") { [weak self] in
                self?.beatsFrom(l.imagePath ?? "", l.start)
            }, 42)
            text(p, "Plays during preview and is mixed into the render (the first audio layer; AAC or MP3 files work best).", C.DIM, 12)
        case .FLARE:
            text(p, "Optical Flare", C.TEXT, 16, true)
            put(p, pill("Customize", "edit", C.GREEN, Int32(bitPattern: 0xFF2B1400)) { [weak self] in
                self?.openFlareEditor(l)
            }, 48)
            for d in Defs.flare { addRow(p, l, d) }
            text(p, "Move the light with the Transform panel or drag it in the preview. Turn the 3D cube on and it follows a camera and shrinks with distance.", C.DIM, 12)
        case .ADJUST:
            text(p, "Adjustment layer", C.TEXT, 16, true)
            text(p, "Add effects to it in the Effects panel. They apply to everything below it for as long as the layer lasts.")
        case .CAMERA:
            text(p, "Camera", C.TEXT, 16, true)
            addRow(p, l, Defs.camera[0])
            text(p, "Position and rotate it in Transform. It controls every layer whose 3D cube is on.")
        case .NULL:
            text(p, "Null object", C.TEXT, 16, true)
            text(p, "An invisible layer. Turn its 3D cube on, then pick it as Parent in other layers' Transform panel.")
        default:
            text(p, cap(l.type.rawValue.lowercased()), C.TEXT, 16, true)
            text(p, l.name)
            if l.type == .VIDEO {
                text(p, "Length: " + String(format: "%.1f", l.srcDur) + " s. Decoded with the system decoder.")
                put(p, pill("Extract audio", "export") { [weak self] in self?.extractAudio(l) }, 42)
                put(p, pill("Beat markers from this video", "graph") { [weak self] in
                    self?.beatsFrom(l.imagePath ?? "", l.start)
                }, 42)
            }
            if l.type == .MODEL {
                text(p, "Static .glb mesh. Transforms are baked on load and everything is drawn from one GPU buffer per part.")
            }
        }
    }

    private func buildText(_ p: UIStackView, _ l: Layer) {
        text(p, "Text", C.TEXT, 16, true)
        p.addArrangedSubview(chipRow(["Text", "Style", "Animate"], textTab) { [weak self] i in
            guard let self = self else { return }
            self.textTab = i
            self.refreshPanel()
        })
        switch textTab {
        case 0:
            let et = makeField(l.text)
            bind(et) { [weak self] s in
                l.text = s
                self?.render()
            }
            put(p, et, 44)
            text(p, "Alignment", C.GREEN, 13, true)
            p.addArrangedSubview(chipRow(["Left", "Center", "Right"], l.align) { [weak self] i in
                guard let self = self else { return }
                self.pushUndo()
                l.align = i
                self.render()
            })
            text(p, "Letter case", C.GREEN, 13, true)
            p.addArrangedSubview(chipRow(["As typed", "UPPER", "lower"], l.caps) { [weak self] i in
                guard let self = self else { return }
                self.pushUndo()
                l.caps = i
                self.render()
            })
            let sb = SwitchRow()
            sb.label = "Bold"; sb.on = l.bold
            sb.onToggle = { [weak self] v in self?.pushUndo(); l.bold = v; self?.render() }
            put(p, sb, 52)
            let si = SwitchRow()
            si.label = "Italic"; si.on = l.italic
            si.onToggle = { [weak self] v in self?.pushUndo(); l.italic = v; self?.render() }
            put(p, si, 52)
            let su = SwitchRow()
            su.label = "Underline"; su.on = l.underline
            su.onToggle = { [weak self] v in self?.pushUndo(); l.underline = v; self?.render() }
            put(p, su, 52)
            let ss = SwitchRow()
            ss.label = "Strikethrough"; ss.on = l.strike
            ss.onToggle = { [weak self] v in self?.pushUndo(); l.strike = v; self?.render() }
            put(p, ss, 52)
            addRow(p, l, Defs.text[4])
            text(p, "Font", C.GREEN, 13, true)
            let fams = ["sans-serif", "serif", "monospace", "cursive", "casual", "sans-serif-condensed",
                        "sans-serif-light", "sans-serif-medium", "sans-serif-black", "serif-monospace"]
            let names = ["Sans", "Serif", "Mono", "Cursive", "Casual", "Condensed", "Light", "Medium", "Black", "Typewriter"]
            let sel = l.fontPath != nil ? -1 : (fams.firstIndex(of: l.font) ?? -1)
            p.addArrangedSubview(chipRow(names, sel) { [weak self] i in
                guard let self = self else { return }
                self.pushUndo()
                l.font = fams[i]
                l.fontPath = nil
                self.refreshPanel(); self.render()
            })
            put(p, pill(l.fontPath != nil ? "Custom font loaded. Import another" : "Import a font file (.ttf or .otf)",
                        "import") { [weak self] in self?.pickFile(R_FONT, [.data]) }, 42)
            text(p, "Color", C.GREEN, 13, true)
            addColorRow(p, l.color) { [weak self] c in self?.pushUndo(); l.color = c; self?.render() }
            addRow(p, l, Defs.transform[2], "Size")
        case 1:
            text(p, "Stroke", C.GREEN, 13, true)
            addRow(p, l, Defs.text[0])
            addColorRow(p, l.strokeColor) { [weak self] c in self?.pushUndo(); l.strokeColor = c; self?.render() }
            text(p, "Stroke position", C.DIM, 12)
            p.addArrangedSubview(chipRow(["Outside", "Center", "Inside"], l.strokePos) { [weak self] i in
                guard let self = self else { return }
                self.pushUndo()
                l.strokePos = i
                self.render()
            })
            text(p, "Corners", C.DIM, 12)
            p.addArrangedSubview(chipRow(["Round", "Sharp"], l.strokeJoin) { [weak self] i in
                guard let self = self else { return }
                self.pushUndo()
                l.strokeJoin = i
                self.render()
            })
            text(p, "Second stroke (outside the first)", C.GREEN, 13, true)
            addRow(p, l, Defs.text[8])
            addColorRow(p, l.stroke2Color) { [weak self] c in self?.pushUndo(); l.stroke2Color = c; self?.render() }
            text(p, "Border box", C.GREEN, 13, true)
            addRow(p, l, Defs.text[1])
            addRow(p, l, Defs.text[2])
            addRow(p, l, Defs.text[9])
            addColorRow(p, l.borderColor) { [weak self] c in self?.pushUndo(); l.borderColor = c; self?.render() }
            let bd = SwitchRow()
            bd.label = "Dashed border"; bd.on = l.borderDash
            bd.onToggle = { [weak self] v in self?.pushUndo(); l.borderDash = v; self?.render() }
            put(p, bd, 52)
            text(p, "Box fill", C.DIM, 12)
            addColorRow(p, colorAlpha(l.borderFill) == 0 ? Int32(bitPattern: 0xFF000000) : l.borderFill) { [weak self] c in
                self?.pushUndo(); l.borderFill = c; self?.render()
            }
            put(p, pill("No box fill", "close") { [weak self] in
                self?.pushUndo(); l.borderFill = 0; self?.refreshPanel(); self?.render()
            }, 40)
            text(p, "Shadow", C.GREEN, 13, true)
            let sh = SwitchRow()
            sh.label = "Shadow"; sh.on = l.shadowOn
            sh.onToggle = { [weak self] v in
                guard let self = self else { return }
                self.pushUndo()
                l.shadowOn = v
                self.refreshPanel(); self.render()
            }
            put(p, sh, 52)
            if l.shadowOn {
                addColorRow(p, l.shadowColor) { [weak self] c in self?.pushUndo(); l.shadowColor = c; self?.render() }
                addRow(p, l, Defs.text[5])
                addRow(p, l, Defs.text[6])
                addRow(p, l, Defs.text[7])
            }
            text(p, "Spacing", C.GREEN, 13, true)
            addRow(p, l, Defs.text[3])
        default:
            buildTextAnim(p, l)
        }
    }

    private func buildTextAnim(_ p: UIStackView, _ l: Layer) {
        put(p, pill("Add animation", "plus", C.GREEN, Int32(bitPattern: 0xFF2B1400)) { [weak self] in
            guard let self = self else { return }
            Dlg(self).setTitle("Add animation").setItems(TextAnim.TYPES) { [weak self] _, w in
                guard let self = self else { return }
                self.pushUndo()
                let a = TextAnim(w, (w == 8 || w == 10) ? 2 : 0)
                if w == 5 { a.scaleFrom = 0 }
                if w == 6 { a.rotFrom = 90 }
                l.anims.append(a)
                self.expanded.insert("anim:\(l.id):\(l.anims.count - 1)")
                self.refreshPanel(); self.render()
            }.show()
        }, 46)
        if l.anims.isEmpty {
            text(p, "Animations play per letter. Stack several, for example Slide up in plus Fade out. Outline draw animates the stroke from the Style tab.", C.DIM, 12)
        }
        for (i, a) in l.anims.enumerated() {
            let key = "anim:\(l.id):\(i)"
            let isOpen = expanded.contains(key)
            let card = vStack()
            let bar = hRow()
            bar.backgroundColor = argbToUIColor(C.CARD)
            bar.isLayoutMarginsRelativeArrangement = true
            bar.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 14, bottom: 0, trailing: 2)
            let tv = UILabel()
            tv.text = a.name()
            tv.textColor = argbToUIColor(C.TEXT)
            tv.font = boldFont(16)
            tv.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
            bar.addArrangedSubview(tv)
            let chev = IconView(isOpen ? "chev_up" : "chev_down", C.DIM, 20)
            chev.onClick = { [weak self] in
                guard let self = self else { return }
                if self.expanded.contains(key) { self.expanded.remove(key) } else { self.expanded.insert(key) }
                self.refreshPanel()
            }
            bar.addArrangedSubview(wrap(chev, 40, 48, 0, 0, 0, 0))
            let del = IconView("trash", C.RED, 20)
            del.onClick = { [weak self] in
                guard let self = self else { return }
                self.pushUndo()
                l.anims.removeAll { $0 === a }
                self.refreshPanel(); self.render()
            }
            bar.addArrangedSubview(wrap(del, 40, 48, 0, 0, 0, 0))
            card.addArrangedSubview(bar)
            if isOpen {
                card.addArrangedSubview(chipRow(["In", "Out", "Loop"], a.mode) { [weak self] m in
                    guard let self = self else { return }
                    self.pushUndo()
                    a.mode = m
                    self.refreshPanel(); self.render()
                })
                addPlain(card, "Start (s)", 0, 10, a.start, 2) { [weak self] v in a.start = v; self?.render() }
                addPlain(card, "Duration (s)", 0.05, 5, a.dur, 2) { [weak self] v in a.dur = v; self?.render() }
                addPlain(card, "Delay per letter (s)", 0, 0.5, a.stagger, 2) { [weak self] v in a.stagger = v; self?.render() }
                addPlain(card, "Distance", 0, 3, a.distance, 2) { [weak self] v in a.distance = v; self?.render() }
                addPlain(card, "Scale from", 0, 3, a.scaleFrom, 2) { [weak self] v in a.scaleFrom = v; self?.render() }
                addPlain(card, "Rotate from (deg)", -360, 360, a.rotFrom, 0) { [weak self] v in a.rotFrom = v; self?.render() }
                addPlain(card, "Speed (loops)", 0, 10, a.speed, 1) { [weak self] v in a.speed = v; self?.render() }
                text(card, "Easing", C.DIM, 12)
                card.addArrangedSubview(chipRow(["Linear", "Ease out", "Ease in-out", "Bounce", "Custom curve"], a.ease) { [weak self] e in
                    guard let self = self else { return }
                    self.pushUndo()
                    a.ease = e
                    if e == 4 { a.curve.ease = Ease.CUSTOM }
                    self.refreshPanel(); self.render()
                })
                if a.ease == 4 {
                    let gv = GraphView(frame: .zero)
                    gv.key = a.curve
                    gv.onBegin = { [weak self] in self?.pushUndo() }
                    gv.onChange = { [weak self] in self?.render() }
                    put(card, gv, 200)
                }
                let sf = SwitchRow()
                sf.label = "Fade while moving"; sf.on = a.fade
                sf.onToggle = { [weak self] v in self?.pushUndo(); a.fade = v; self?.render() }
                put(card, sf, 52)
            }
            put(p, card, 0, 3, 6)
        }
    }

    // ---------------------------------------------------------------- transform

    private func buildXform(_ l: Layer) {
        let p: UIStackView = panelList
        p.addArrangedSubview(wrap(TabBar(["Attributes", "Anchor & Align"], xformTab) { [weak self] i in
            guard let self = self else { return }
            self.xformTab = i
            self.refreshPanel()
        }, 0, 44, 0, 0, 0, 0))
        if xformTab == 1 { buildAnchorAlign(l); return }
        let threeD = l.is3d || l.type == .MODEL || l.type == .CAMERA
        let s3 = SwitchRow()
        s3.label = "3D layer"; s3.on = threeD
        s3.onToggle = { [weak self] _ in self?.toggle3d() }
        put(p, s3, 52)
        if l.type == .NULL && !l.is3d {
            text(p, "This Null is 2D, so it will not move other layers. Turn 3D on.", C.AMBER)
        }
        groupHeader(p, "Position") { [weak self] in self?.showPositionMenu(l, threeD) }
        if moveMode || !sepDims { addMovePad(p, l) }
        if sepDims { addRow(p, l, Defs.transform[0]); addRow(p, l, Defs.transform[1]) }
        if threeD { addRow(p, l, Defs.pos3d[0]) }
        if l.type != .CAMERA {
            let sh = hRow()
            let stt = UILabel()
            stt.text = "Scale"
            stt.textColor = argbToUIColor(C.TEXT)
            stt.font = boldFont(15)
            stt.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
            sh.addArrangedSubview(stt)
            let chain = IconView(scaleLinked ? "link" : "unlink", Int32(bitPattern: 0xFFFFFFFF), 22)
            chain.onClick = { [weak self] in
                guard let self = self else { return }
                self.scaleLinked = !self.scaleLinked
                self.refreshPanel()
            }
            sh.addArrangedSubview(wrap(chain, 44, 40, 0, 0, 0, 0))
            put(p, sh, 0, 4, 0)
            addRow(p, l, Defs.transform[2], scaleLinked ? "Scale (X and Y together)" : "Scale (all)")
            if !scaleLinked {
                addRow(p, l, Defs.scaleXY[0])
                addRow(p, l, Defs.scaleXY[1])
            } else {
                let lt0 = l.editTime("scaleX", Editor.time)
                if abs(l.p("scaleX", lt0) - 1) > 0.001 || abs(l.p("scaleY", lt0) - 1) > 0.001 {
                    text(p, "X and Y are stretched separately. Tap the chain to edit them.", C.DIM, 12)
                }
            }
        }
        let rotDefs: [PropDef] = threeD ? [Defs.transform[4], Defs.rot3d[0], Defs.rot3d[1]] : [Defs.transform[4]]
        groupHeader(p, "Rotation") { [weak self] in self?.showParamMenu(l, "Rotation", rotDefs) }
        for d in rotDefs { addRow(p, l, d) }
        if l.isRenderable() || l.type == .GROUP {
            groupHeader(p, "Opacity") { [weak self] in self?.showParamMenu(l, "Opacity", [Defs.transform[3]]) }
            addRow(p, l, Defs.transform[3])
        }
        let par = Editor.scene.layers.first { $0.id == l.parentId }
        put(p, pill("Parent: " + (par?.name ?? "None"), "layers") { [weak self] in self?.showParentDialog(l) }, 42)
        let b = hRow()
        b.distribution = .fillEqually
        b.spacing = 4
        for axis in ["rotX", "rotY", "rotZ"] {
            if !threeD && axis != "rotZ" { continue }
            b.addArrangedSubview(wrap(pill("Spin " + String(axis.last ?? "?")) { [weak self] in self?.spin(l, axis) },
                                      0, 40, 0, 0, 0, 0))
        }
        put(p, b, 40)
    }

    private func groupHeader(_ p: UIStackView, _ title: String, _ onMenu: @escaping () -> Void) {
        let h = hRow()
        let t = UILabel()
        t.text = title
        t.textColor = argbToUIColor(C.TEXT)
        t.font = boldFont(15)
        t.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
        h.addArrangedSubview(t)
        let m = IconView("more", C.TEXT, 20)
        m.onClick = onMenu
        h.addArrangedSubview(wrap(m, 44, 40, 0, 0, 0, 0))
        put(p, h, 0, 4, 0)
    }

    /// The three-dot menu used by Scale, Rotation and Opacity.
    private func showParamMenu(_ l: Layer, _ title: String, _ defs: [PropDef]) {
        _ = Dlg(self).setTitle(title).setIconItems(["Reset to default", "Clear keyframes (keep current value)", "Expression..."],
                                                   ["adjust", "close", "box"]) { [weak self] _, w in
            guard let self = self else { return }
            self.pushUndo()
            switch w {
            case 0:
                for d in defs {
                    let tr = l.track(d.key)
                    tr.keys.removeAll(); tr.base = d.def
                    _ = tr.setExpr(""); tr.exprOn = false
                }
            case 1:
                for d in defs {
                    let tr = l.track(d.key)
                    let v = tr.eval(l.editTime(d.key, Editor.time))
                    tr.keys.removeAll(); tr.base = v
                }
            default:
                if defs.count == 1 { self.showExpression(l, defs[0]); return }
                _ = Dlg(self).setTitle("Expression for").setItems(defs.map { $0.label }) { [weak self] _, i in
                    self?.showExpression(l, defs[i])
                }.show()
                return
            }
            self.refreshPanel(); self.render()
        }.show()
    }

    private func addMovePad(_ p: UIStackView, _ l: Layer) {
        let pad = MovePadView()
        let t0 = l.editTime("x", Editor.time)
        pad.px = l.track("x").eval(t0)
        pad.py = l.track("y").eval(t0)
        pad.onBegin = { [weak self] in self?.pushUndo() }
        pad.onMove = { [weak self] dx, dy in
            guard let self = self else { return }
            let t = l.editTime("x", Editor.time)
            let nx = l.track("x").eval(t) + dx
            let ny = l.track("y").eval(t) + dy
            l.track("x").set(t, nx, self.autoKeyOn)
            l.track("y").set(t, ny, self.autoKeyOn)
            pad.px = nx; pad.py = ny
            pad.setNeedsDisplay()
            self.syncRows(); self.render()
        }
        put(p, pad, 150)
    }

    private func showPositionMenu(_ l: Layer, _ threeD: Bool) {
        _ = Dlg(self).setTitle("Position").setIconItems(
            ["Separate dimensions  (" + (sepDims ? "on" : "off") + ")",
             "Move mode  (" + (moveMode ? "on" : "off") + ")",
             "Reset to default",
             "Expression..."],
            ["grid", "move", "adjust", "box"]) { [weak self] _, w in
            guard let self = self else { return }
            switch w {
            case 0: self.sepDims = !self.sepDims
            case 1: self.moveMode = !self.moveMode
            case 2:
                self.pushUndo()
                for k in ["x", "y", "z"] {
                    let tr = l.track(k)
                    tr.keys.removeAll(); tr.base = 0
                    _ = tr.setExpr(""); tr.exprOn = false
                }
            default:
                let names = threeD ? ["Position X", "Position Y", "Position Z"] : ["Position X", "Position Y"]
                _ = Dlg(self).setTitle("Expression for").setItems(names) { [weak self] _, i in
                    self?.showExpression(l, i == 2 ? Defs.pos3d[0] : Defs.transform[i])
                }.show()
                return
            }
            self.refreshPanel()
        }.show()
    }

    // ---------------------------------------------------------------- anchor + align

    private func buildAnchorAlign(_ l: Layer) {
        let p: UIStackView = panelList
        text(p, "Anchor", C.TEXT, 15, true)
        addRow(p, l, Defs.anchor[0])
        addRow(p, l, Defs.anchor[1])
        let lt = l.editTime("anchorX", Editor.time)
        let ax = l.p("anchorX", lt)
        let ay = l.p("anchorY", lt)
        text(p, "Preset Anchor", C.TEXT, 15, true)
        let g = GridPick()
        g.sel = (0...8).first { abs(Float($0 % 3) * 50 - ax) < 0.5 && abs(Float($0 / 3) * 50 - ay) < 0.5 } ?? -1
        g.onPick = { [weak self] i in
            guard let self = self else { return }
            self.pushUndo()
            self.setAnchorKeepVisual(l, Float(i % 3) * 50, Float(i / 3) * 50)
            self.refreshPanel(); self.render()
        }
        put(p, g, 128)
        text(p, "Align to Canvas", C.TEXT, 15, true)
        let rows: [[String]] = [["align_l", "align_hc", "align_r"], ["align_t", "align_vc", "align_b"]]
        for (ri, rowIcons) in rows.enumerated() {
            let h = hRow()
            h.distribution = .fillEqually
            for (ci, ic) in rowIcons.enumerated() {
                let b = IconView(ic, C.TEXT, 24)
                b.backgroundColor = argbToUIColor(C.CARD)
                b.layer.cornerRadius = 10
                b.onClick = { [weak self] in
                    guard let self = self else { return }
                    self.pushUndo()
                    self.alignToCanvas(l, ri * 3 + ci)
                    self.refreshPanel(); self.render()
                }
                h.addArrangedSubview(wrap(b, 0, 52, 3, 3, 3, 3))
            }
            put(p, h)
        }
        text(p, "Align uses the layer's size and rotation. Choosing a preset anchor keeps the layer where it is.", C.DIM, 12)
    }

    /// Offset of the layer centre from its position, in world units, for the current anchor.
    private func anchorOffset(_ l: Layer, _ lt: Float, _ ax: Float, _ ay: Float) -> (Float, Float) {
        let (qw, qh) = Xf.quadSize(l)
        let sc = l.p("scale", lt)
        let ox = -(ax - 50) / 100 * qw * sc * l.p("scaleX", lt)
        let oy = (ay - 50) / 100 * qh * sc * l.p("scaleY", lt)
        let a = Double(l.p("rotZ", lt)) * Double.pi / 180
        let c = Float(cos(a))
        let sn = Float(sin(a))
        return (ox * c - oy * sn, ox * sn + oy * c)
    }

    private func setAnchorKeepVisual(_ l: Layer, _ nx: Float, _ ny: Float) {
        let t = l.editTime("anchorX", Editor.time)
        let oa = anchorOffset(l, t, l.p("anchorX", t), l.p("anchorY", t))
        let na = anchorOffset(l, t, nx, ny)
        l.track("x").set(t, l.p("x", t) + oa.0 - na.0, autoKeyOn)
        l.track("y").set(t, l.p("y", t) + oa.1 - na.1, autoKeyOn)
        l.track("anchorX").set(t, nx, autoKeyOn)
        l.track("anchorY").set(t, ny, autoKeyOn)
    }

    /// which: 0 left, 1 h-centre, 2 right, 3 top, 4 v-centre, 5 bottom.
    private func alignToCanvas(_ l: Layer, _ which: Int) {
        let t = l.editTime("x", Editor.time)
        let (qw, qh) = Xf.quadSize(l)
        let sc = abs(l.p("scale", t))
        let hw = qw * sc * abs(l.p("scaleX", t)) / 2
        let hh = qh * sc * abs(l.p("scaleY", t)) / 2
        let a = Double(l.p("rotZ", t)) * Double.pi / 180
        let c = abs(Float(cos(a)))
        let sn = abs(Float(sin(a)))
        let bw = c * hw + sn * hh
        let bh = sn * hw + c * hh
        let w = Float(Editor.project.w) / Float(Editor.project.h)
        let off = anchorOffset(l, t, l.p("anchorX", t), l.p("anchorY", t))
        switch which {
        case 0: l.track("x").set(t, -w + bw - off.0, autoKeyOn)
        case 1: l.track("x").set(t, -off.0, autoKeyOn)
        case 2: l.track("x").set(t, w - bw - off.0, autoKeyOn)
        case 3: l.track("y").set(t, 1 - bh - off.1, autoKeyOn)
        case 4: l.track("y").set(t, -off.1, autoKeyOn)
        default: l.track("y").set(t, -1 + bh - off.1, autoKeyOn)
        }
    }

    private func spin(_ l: Layer, _ key: String) {
        pushUndo()
        let tr = l.track(key)
        tr.keys.removeAll()
        tr.keys.append(Key(l.start, 0, .LINEAR))
        tr.keys.append(Key(l.end, 360, .LINEAR))
        refreshPanel(); render()
    }

    private func showParentDialog(_ l: Layer) {
        let cands = Editor.scene.layers.filter { $0.id != l.id && $0.parentId != l.id }
        var names = ["None"]
        names += cands.map {
            $0.name + ($0.type == .NULL ? " (Null)" : ($0.type == .GROUP ? " (Group)" : ""))
        }
        Dlg(self).setTitle("Parent").setItems(names) { [weak self] _, w in
            guard let self = self else { return }
            self.pushUndo()
            l.parentId = w == 0 ? -1 : cands[w - 1].id
            self.refreshPanel(); self.render()
        }.show()
    }

    // ---------------------------------------------------------------- blending + speed

    private func buildBlend(_ l: Layer) {
        let p: UIStackView = panelList
        text(p, "Blending", C.TEXT, 16, true)
        addRow(p, l, Defs.transform[3])
        text(p, "Blend mode", C.DIM)
        p.addArrangedSubview(chipRow(["Normal", "Add", "Screen", "Multiply"], l.blend) { [weak self] i in
            guard let self = self else { return }
            self.pushUndo()
            l.blend = i
            self.refreshPanel(); self.render()
        })
        let mb = SwitchRow()
        mb.label = "Motion blur"; mb.on = l.mblur
        mb.onToggle = { [weak self] v in
            guard let self = self else { return }
            self.pushUndo()
            l.mblur = v
            self.refreshPanel(); self.render()
        }
        put(p, mb, 52)
        if l.mblur {
            addRow(p, l, Defs.blur[0])
            addRow(p, l, Defs.blur[1])
            text(p, "Works with particles and every moving or animated layer. More samples is smoother but slower. Video layers are not blurred.", C.DIM, 12)
        }
    }

    private func buildSpeed(_ l: Layer) {
        let p: UIStackView = panelList
        let hasMap = l.props["remapT"]?.keys.isEmpty == false
        let spd = l.speedAt(Editor.time)
        let head = hRow()
        let ht = UILabel()
        ht.text = "Playback Speed"
        ht.textColor = argbToUIColor(C.TEXT)
        ht.font = boldFont(16)
        ht.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
        head.addArrangedSubview(ht)
        let here = UILabel()
        here.text = String(format: "%.2fx here", spd)
        here.textColor = argbToUIColor(C.DIM)
        here.font = sysFont(13)
        head.addArrangedSubview(here)
        put(p, head, 0, 4, 4)
        let fs = FillSlider()
        fs.lo = 0.1
        fs.hi = 4
        fs.value = abs(hasMap ? 1 : l.track("remapSpeed").eval(Editor.time))
        fs.value = clamp(fs.value, 0.1, 4)
        fs.isUserInteractionEnabled = !hasMap
        fs.onBegin = { [weak self] in self?.pushUndo() }
        fs.onChange = { [weak self] v in
            guard let self = self else { return }
            self.ensureRemap(l)
            l.track("remapSpeed").set(Editor.time, v, self.autoKeyOn)
            here.text = String(format: "%.2fx here", v)
            self.render()
        }
        put(p, fs, 46)
        let presets: [Float] = [0.1, 0.25, 0.5, 1, 2, 4]
        let labels = ["0.1x", "0.25x", "0.5x", "1.0x", "2.0x", "4.0x"]
        for rowStart in [0, 3] {
            let rw = hRow()
            rw.distribution = .fillEqually
            rw.spacing = 3
            for k in rowStart..<(rowStart + 3) {
                let on = !hasMap && abs(spd - presets[k]) < 0.01
                let b = pill(labels[k], nil, on ? C.GREEN : C.CARD2, on ? Int32(bitPattern: 0xFF2B1400) : C.TEXT) { [weak self] in
                    guard let self = self, !hasMap else { return }
                    self.pushUndo()
                    self.ensureRemap(l)
                    let tr = l.track("remapSpeed")
                    tr.keys.removeAll()
                    tr.base = presets[k]
                    self.refreshPanel(); self.render()
                }
                rw.addArrangedSubview(wrap(b, 0, 40, 0, 0, 0, 0))
            }
            put(p, rw, 40)
        }
        if hasMap { text(p, "Time Remap keyframes are driving playback. Remove them to use the speed slider.", C.AMBER, 12) }

        text(p, "Time Remap", C.TEXT, 16, true)
        if !hasMap {
            text(p, "Keyframe which moment of the source plays at each point in time.", C.DIM, 12)
            put(p, pill("Add Time Remap keyframes", "plus") { [weak self] in
                guard let self = self else { return }
                self.pushUndo()
                self.ensureRemapKeys(l)
                self.selKey = "remapT"
                self.refreshPanel(); self.render()
            }, 44)
            let q = hRow()
            q.distribution = .fillEqually
            q.spacing = 3
            q.addArrangedSubview(wrap(pill("Freeze frame") { [weak self] in
                guard let self = self else { return }
                self.pushUndo()
                self.freezeFrame(l)
                self.selKey = "remapT"
                self.refreshPanel(); self.render()
            }, 0, 40, 0, 0, 0, 0))
            q.addArrangedSubview(wrap(pill("Reverse") { [weak self] in
                guard let self = self else { return }
                self.pushUndo()
                self.reverseRemap(l)
                self.selKey = "remapT"
                self.refreshPanel(); self.render()
            }, 0, 40, 0, 0, 0, 0))
            put(p, q, 40)
        } else {
            if let rd = Registry.get("remap"), let def = rd.props.first(where: { $0.key == "remapT" }) {
                addRow(p, l, def, "Time Remap (s)")
            }
            let q = hRow()
            q.distribution = .fillEqually
            q.spacing = 3
            q.addArrangedSubview(wrap(pill("Freeze frame") { [weak self] in
                guard let self = self else { return }
                self.pushUndo()
                self.freezeFrame(l)
                self.refreshPanel(); self.render()
            }, 0, 40, 0, 0, 0, 0))
            q.addArrangedSubview(wrap(pill("Reverse") { [weak self] in
                guard let self = self else { return }
                self.pushUndo()
                self.reverseRemap(l)
                self.refreshPanel(); self.render()
            }, 0, 40, 0, 0, 0, 0))
            put(p, q, 40)
            put(p, pill("Remove Time Remap", "trash", C.CARD2, C.RED) { [weak self] in
                guard let self = self else { return }
                self.pushUndo()
                l.track("remapT").keys.removeAll()
                self.refreshPanel(); self.render()
            }, 42)
            text(p, "Tap the name, then the keyframe diamond, to add a keyframe at the playhead.", C.DIM, 12)
        }

        text(p, "Frame Interpolation", C.TEXT, 16, true)
        let itr = l.track("remapInterp")
        p.addArrangedSubview(chipRow(["Off", "Frame Blend", "Optical Flow"], Int(itr.base)) { [weak self] i in
            guard let self = self else { return }
            self.pushUndo()
            self.ensureRemap(l)
            itr.keys.removeAll()
            itr.base = Float(i)
            self.refreshPanel(); self.render()
        })
        switch Int(itr.base) {
        case 1: text(p, "Blends the two source frames around each moment, so slow motion looks smooth instead of stepping.", C.DIM, 12)
        case 2: text(p, "Optical Flow currently uses Frame Blend. It applies to video layers.", C.DIM, 12)
        default: text(p, "Shows the nearest source frame. Slow motion on video can look steppy.", C.DIM, 12)
        }
        if l.type != .VIDEO { text(p, "Frame interpolation only affects video layers.", C.DIM, 12) }
    }

    private func ensureRemap(_ l: Layer) {
        if !l.fx.contains("remap") { l.fx.append("remap") }
        l.fxOff.remove("remap")
    }

    /// Creates the two identity Time Remap keyframes when none exist yet.
    private func ensureRemapKeys(_ l: Layer) {
        ensureRemap(l)
        let tr = l.track("remapT")
        if !tr.keys.isEmpty { return }
        let sp = l.track("remapSpeed").base
        tr.keys.append(Key(l.start, 0, .LINEAR))
        tr.keys.append(Key(l.end, (l.end - l.start) * sp, .LINEAR))
    }

    /// Holds the current source frame for one second, pushing later keyframes back.
    private func freezeFrame(_ l: Layer) {
        ensureRemapKeys(l)
        let tr = l.track("remapT")
        let t = Editor.time
        let v = tr.eval(t)
        let hold: Float = 1
        for k in tr.keys where k.t > t + 0.001 { k.t += hold }
        if !tr.keys.contains(where: { abs($0.t - t) < 0.001 }) { tr.keys.append(Key(t, v, .LINEAR)) }
        tr.keys.append(Key(t + hold, v, .LINEAR))
        tr.keys.sort { $0.t < $1.t }
    }

    /// Plays the layer backwards.
    private func reverseRemap(_ l: Layer) {
        ensureRemap(l)
        let tr = l.track("remapT")
        tr.keys.removeAll()
        tr.keys.append(Key(l.start, l.end - l.start, .LINEAR))
        tr.keys.append(Key(l.end, 0, .LINEAR))
    }

    // ---------------------------------------------------------------- effects

    private func buildFx(_ l: Layer) {
        let p: UIStackView = panelList
        let hdr = hRow()
        let ht = UILabel()
        ht.text = "Effects  ·  " + l.name
        ht.textColor = argbToUIColor(C.TEXT)
        ht.font = boldFont(20)
        ht.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
        hdr.addArrangedSubview(ht)
        hdr.addArrangedSubview(wrap(pill("Close", "close") { [weak self] in self?.closePanel() }, 112, 42, 0, 0, 0, 0))
        put(p, hdr, 0, 6, 8)
        p.addArrangedSubview(chipRow(["Applied", "Browse", "Presets", "Custom"], fxTab) { [weak self] i in
            guard let self = self else { return }
            self.fxTab = i
            self.showBottom(); self.refreshPanel()
        })
        switch fxTab {
        case 0: buildApplied(l)
        case 1: buildBrowse(l)
        case 2: buildPresets(l)
        default: buildCustom(l)
        }
    }

    private func snapFx(_ l: Layer, _ entry: String) -> FxSnap? {
        guard let d = Registry.get(entry) else { return nil }
        var m: [(String, JObj)] = []
        if d.kind == 1 {
            for pd in d.props {
                if let tr = l.props[pd.key] { m.append(("=" + pd.key, tr.toJson())) }
            }
        } else {
            let pre = entry + "__"
            for (k, tr) in l.props where k.hasPrefix(pre) {
                m.append((String(k.dropFirst(pre.count)), tr.toJson()))
            }
        }
        var ins: [String: Int] = [:]
        for (k, v) in l.inputs where k.hasPrefix(entry + ":") {
            ins[String(k.dropFirst(entry.count + 1))] = v
        }
        return FxSnap(d.id, m, ins, l.fxOff.contains(entry))
    }

    private func pasteFx(_ l: Layer, _ snap: FxSnap) {
        guard let d = Registry.byId[snap.id] else { return }
        let entry: String
        if d.kind == 1 {
            entry = d.id
            if !l.fx.contains(entry) { l.fx.append(entry) }
        } else {
            entry = Registry.uniqueEntry(l, d.id)
            l.fx.append(entry)
        }
        if snap.off { l.fxOff.insert(entry) } else { _ = l.fxOff.remove(entry) }
        for (rk, js) in snap.tracks {
            let key = rk.hasPrefix("=") ? String(rk.dropFirst()) : entry + "__" + rk
            l.track(key).load(js)
        }
        for (nm, id) in snap.inputs { l.inputs[entry + ":" + nm] = id }
        expanded.insert("\(l.id):\(entry)")
    }

    private func resetFx(_ l: Layer, _ entry: String) {
        guard let d = Registry.get(entry) else { return }
        for pd in d.props {
            let tr = l.track(l.pkey(entry, pd))
            tr.keys.removeAll()
            tr.base = pd.def
            _ = tr.setExpr("")
            tr.exprOn = false
        }
        for cp in d.colors {
            let ck = l.ckey(entry, cp)
            let vals: [(String, Int)] = [("_r", Int((UInt32(bitPattern: cp.def) >> 16) & 0xFF)),
                                         ("_g", Int((UInt32(bitPattern: cp.def) >> 8) & 0xFF)),
                                         ("_b", Int(UInt32(bitPattern: cp.def) & 0xFF)),
                                         ("_a", Int(UInt32(bitPattern: cp.def) >> 24))]
            for (sf, v) in vals {
                let tr = l.track(ck + sf)
                tr.keys.removeAll()
                tr.base = Float(v) / 255
            }
        }
    }

    private func moveFx(_ l: Layer, _ entry: String, _ dir: Int) {
        guard let idx = l.fx.firstIndex(of: entry) else { return }
        let to = idx + dir
        if to < 0 || to >= l.fx.count { return }
        l.fx.remove(at: idx)
        l.fx.insert(entry, at: to)
    }

    private func removeFx(_ l: Layer, _ entry: String) {
        l.fx.removeAll { $0 == entry }
        _ = l.fxOff.remove(entry)
        let pre = entry + "__"
        if entry.contains("~") {
            for k in Array(l.props.keys) where k.hasPrefix(pre) { l.props.removeValue(forKey: k) }
        }
        for k in Array(l.inputs.keys) where k.hasPrefix(entry + ":") { l.inputs.removeValue(forKey: k) }
    }

    private func fxMenu(_ l: Layer, _ entry: String) {
        guard let d = Registry.get(entry) else { return }
        let idx = l.fx.firstIndex(of: entry) ?? -1
        let labels = ["Copy effect", "Duplicate effect", "Move up", "Move down", "Reset to default", "Remove effect"]
        let icons = ["dup", "dup", "chev_up", "chev_down", "adjust", "trash"]
        Dlg(self).setTitle(d.name).setIconItems(labels, icons) { [weak self] _, w in
            guard let self = self else { return }
            switch w {
            case 0:
                if let sn = self.snapFx(l, entry) { self.fxClip = [sn] }
                self.toast("Effect copied")
            case 1:
                if let sn = self.snapFx(l, entry) {
                    self.pushUndo()
                    self.pasteFx(l, sn)
                    self.refreshPanel(); self.render()
                }
            case 2:
                if idx > 0 {
                    self.pushUndo()
                    self.moveFx(l, entry, -1)
                    self.refreshPanel(); self.render()
                }
            case 3:
                if idx < l.fx.count - 1 {
                    self.pushUndo()
                    self.moveFx(l, entry, 1)
                    self.refreshPanel(); self.render()
                }
            case 4:
                self.pushUndo()
                self.resetFx(l, entry)
                self.refreshPanel(); self.render()
            default:
                self.pushUndo()
                self.removeFx(l, entry)
                self.refreshPanel(); self.render()
            }
        }.show()
    }

    private func fxListMenu(_ l: Layer) {
        let labels = ["Copy all effects",
                      fxClip.isEmpty ? "Paste effects (nothing copied)" : "Paste effects (\(fxClip.count))",
                      "Reset all to default", "Remove all effects"]
        let icons = ["dup", "import", "adjust", "trash"]
        Dlg(self).setTitle("Effects").setIconItems(labels, icons) { [weak self] _, w in
            guard let self = self else { return }
            switch w {
            case 0:
                self.fxClip = l.fx.compactMap { self.snapFx(l, $0) }
                self.toast(self.fxClip.isEmpty ? "No effects to copy" : "Copied \(self.fxClip.count) effects")
            case 1:
                if self.fxClip.isEmpty {
                    self.toast("No effects copied")
                } else {
                    self.pushUndo()
                    for sn in self.fxClip { self.pasteFx(l, sn) }
                    self.refreshPanel(); self.render()
                }
            case 2:
                self.pushUndo()
                for e in l.fx { self.resetFx(l, e) }
                self.refreshPanel(); self.render()
            default:
                self.pushUndo()
                for e in l.fx { self.removeFx(l, e) }
                self.refreshPanel(); self.render()
            }
        }.show()
    }

    private func fxHeader(_ l: Layer, _ d: EffectDef, _ entry: String) -> UIView {
        let key = "\(l.id):\(entry)"
        let isOpen = expanded.contains(key)
        let bar = hRow()
        bar.backgroundColor = argbToUIColor(C.CARD)
        bar.isLayoutMarginsRelativeArrangement = true
        bar.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 14, bottom: 0, trailing: 2)
        bar.addArrangedSubview(wrap(IconView("handle", C.DIM, 20), 36, 48, 0, 0, 0, 0))
        let t = UILabel()
        t.text = entry.contains("~") ? d.name + " " + afterLast(entry, "~") : d.name
        t.textColor = argbToUIColor(C.TEXT)
        t.font = boldFont(16)
        t.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
        bar.addArrangedSubview(t)
        let off = l.fxOff.contains(entry)
        let eye = IconView(off ? "eye_off" : "eye", off ? C.DIM : C.GREEN, 20)
        eye.onClick = { [weak self] in
            guard let self = self else { return }
            self.pushUndo()
            if off { l.fxOff.remove(entry) } else { l.fxOff.insert(entry) }
            self.refreshPanel(); self.render()
        }
        bar.addArrangedSubview(wrap(eye, 40, 48, 0, 0, 0, 0))
        let chev = IconView(isOpen ? "chev_up" : "chev_down", C.DIM, 20)
        chev.onClick = { [weak self] in
            guard let self = self else { return }
            if self.expanded.contains(key) { self.expanded.remove(key) } else { self.expanded.insert(key) }
            self.refreshPanel()
        }
        bar.addArrangedSubview(wrap(chev, 40, 48, 0, 0, 0, 0))
        let more = IconView("more", C.TEXT, 20)
        more.onClick = { [weak self] in self?.fxMenu(l, entry) }
        bar.addArrangedSubview(wrap(more, 40, 48, 0, 0, 0, 0))
        return bar
    }

    private func buildApplied(_ l: Layer) {
        let p: UIStackView = panelList
        let top = hRow()
        let cnt = UILabel()
        cnt.text = "\(l.fx.count)\(l.fx.count == 1 ? " effect" : " effects")"
        cnt.textColor = argbToUIColor(C.DIM)
        cnt.font = sysFont(13)
        cnt.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
        top.addArrangedSubview(cnt)
        let menu = IconView("more", C.TEXT, 22)
        menu.onClick = { [weak self] in self?.fxListMenu(l) }
        top.addArrangedSubview(wrap(menu, 44, 40, 0, 0, 0, 0))
        put(p, top, 40, 6, 2)
        if l.fx.isEmpty { text(p, "No effects yet. Tap Add Effect to browse.") }
        for entry in l.fx {
            guard let d = Registry.get(entry) else { continue }
            let id = d.id
            let c = vStack()
            c.addArrangedSubview(fxHeader(l, d, entry))
            if expanded.contains("\(l.id):\(entry)") {
                text(c, d.desc, C.DIM, 12)
                if let err = Registry.errors[id] { text(c, "Shader error: \(err)", C.RED, 12) }
                for pd in d.props { addRow(c, l, Registry.instProp(l, entry, pd)) }
                for cp in d.colors { addColorParam(c, l, Registry.instColor(l, entry, cp)) }
                if id == "particles" {
                    let pmb = SwitchRow()
                    pmb.label = "Motion blur"; pmb.on = l.mblur
                    pmb.onToggle = { [weak self] v in self?.pushUndo(); l.mblur = v; self?.render() }
                    put(c, pmb, 52)
                    text(c, "Birth color", C.DIM)
                    addColorRow(c, l.color) { [weak self] col in self?.pushUndo(); l.color = col; self?.render() }
                    text(c, "Death color", C.DIM)
                    addColorRow(c, l.color2) { [weak self] col in self?.pushUndo(); l.color2 = col; self?.render() }
                }
                for nm in d.inputs {
                    let rid = l.inputs[entry + ":" + nm]
                    let ref = Editor.scene.layers.first { $0.id == rid }
                    put(c, pill(nm + " layer: " + (ref?.name ?? "None"), "layers") { [weak self] in
                        self?.showInputDialog(l, entry, nm)
                    }, 42)
                }
                if id == "lightsweep" {
                    put(c, pill("Animate sweep") { [weak self] in self?.lightSweepAnim(l) }, 42)
                }
                if id == "tile" {
                    let b = hRow()
                    b.distribution = .fillEqually
                    b.spacing = 4
                    for axis in ["tileX", "tileY"] {
                        b.addArrangedSubview(wrap(pill("Scroll " + String(axis.last ?? "?")) { [weak self] in
                            self?.tileScroll(l, axis)
                        }, 0, 40, 0, 0, 0, 0))
                    }
                    c.addArrangedSubview(b)
                }
            }
            put(p, c, 0, 3, 6)
        }
        put(p, pill("Add Effect", "plus", C.GREEN, Int32(bitPattern: 0xFF2B1400)) { [weak self] in
            guard let self = self else { return }
            self.fxTab = 1
            self.showBottom(); self.refreshPanel()
        }, 48, 10, 10)
    }

    private func lightSweepAnim(_ l: Layer) {
        pushUndo()
        let tr = l.track("lightsweep__centerX")
        tr.keys.removeAll()
        tr.keys.append(Key(l.start, -0.4, .EASE_IN_OUT))
        tr.keys.append(Key(l.end, 1.4, .EASE_IN_OUT))
        refreshPanel(); render()
    }

    private func tileScroll(_ l: Layer, _ key: String) {
        pushUndo()
        let tr = l.track(key)
        let mirror = l.p("tileMirror", Editor.time) >= 0.5
        tr.keys.removeAll()
        tr.keys.append(Key(l.start, 0, .LINEAR))
        tr.keys.append(Key(l.end, mirror ? 2 : 1, .LINEAR))
        refreshPanel(); render()
    }

    private func showInputDialog(_ l: Layer, _ entry: String, _ nm: String) {
        let cands = Editor.scene.layers.filter {
            $0.id != l.id && $0.isRenderable() && $0.type != .VIDEO && $0.type != .MODEL && $0.type != .PARTICLES
        }
        var names = ["None"]
        names += cands.map { $0.name }
        Dlg(self).setTitle(nm + " layer").setItems(names) { [weak self] _, w in
            guard let self = self else { return }
            self.pushUndo()
            if w == 0 {
                l.inputs.removeValue(forKey: entry + ":" + nm)
            } else {
                l.inputs[entry + ":" + nm] = cands[w - 1].id
            }
            self.refreshPanel(); self.render()
        }.show()
    }

    private func fxCategory(_ d: EffectDef) -> String {
        switch d.id {
        case "deepglow", "lightsweep", "contour", "lightleak", "godrays", "starburst", "softfocus", "bokeh": return "Light and glow"
        case "tritone", "duotone", "hueshift", "grayscale", "invert", "rgbsplit", "vignette", "fill",
             "nightvision", "thermal", "oldphoto", "gradientmap", "threshold": return "Color"
        case "etching", "halftone", "zebrafy", "posterize", "filmgrain", "edgelines", "scanlines", "pixelate", "sharpen",
             "ascii", "hexpixel", "sketch", "toon", "emboss", "clay", "matrixrain", "pixelscatter", "crt": return "Stylize"
        case "distortrgb", "kaleido", "bulge", "twirl", "barrel", "wavewarp", "ripple",
             "glassblocks", "droste", "polarwarp", "turbulent", "mirror": return "Distort"
        case "blur", "radialblur", "blurmo": return "Blur"
        case "psykoblobs", "texturefolded", "texturemoire", "starfield", "plasma", "fire", "snow": return "Generate"
        case "sshake", "twitch", "glitchslices", "vhs", "oscillate", "autoshake", "randisp", "streaks", "timeslice": return "Glitch and motion"
        case "chromakey": return "Keying"
        default:
            if d.id.hasPrefix("shake_") { return "Glitch and motion" }
            if d.builtin { return "Transform and time" }
            return Registry.CATEGORIES.contains(d.category) ? d.category : "Custom"
        }
    }

    private func buildBrowse(_ l: Layer) {
        let p: UIStackView = panelList
        let q = makeField(fxQuery)
        q.placeholder = "Search effects"
        let grid = vStack()
        var fill: (() -> Void)! = nil
        fill = { [weak self] in
            guard let self = self else { return }
            grid.arrangedSubviews.forEach { $0.removeFromSuperview() }
            let qs = fxQuery.trimmingCharacters(in: .whitespaces).lowercased()
            let list = Registry.order.filter {
                qs.isEmpty || $0.name.lowercased().contains(qs) || $0.desc.lowercased().contains(qs)
                    || self.fxCategory($0).lowercased().contains(qs)
            }
            let groups = Dictionary(grouping: list, by: { self.fxCategory($0) })
            let catOrder = ["Light and glow", "Color", "Stylize", "Distort", "Blur", "Generate",
                            "Glitch and motion", "Keying", "Transform and time", "Custom"]
            let keys = groups.keys.sorted { a, b in
                let ia = catOrder.firstIndex(of: a) ?? 99
                let ib = catOrder.firstIndex(of: b) ?? 99
                return ia < ib
            }
            if keys.isEmpty { text(grid, "No effects match your search.", C.DIM, 13) }
            let cols = max(2, Int((self.view.bounds.width - 60) / 200))
            for k in keys {
                let items = (groups[k] ?? []).sorted { $0.name < $1.name }
                text(grid, k + "  (" + String(items.count) + ")", C.GREEN, 14, true)
                var i = 0
                while i < items.count {
                    let r = UIStackView()
                    r.axis = .horizontal
                    r.alignment = .fill
                    r.distribution = .fillEqually
                    r.spacing = 8
                    for j in 0..<cols {
                        if i + j >= items.count {
                            r.addArrangedSubview(UIView())
                            continue
                        }
                        let d = items[i + j]
                        let card = EffectCard(d.name, self.fxCategory(d))
                        card.anim = d.previewAnim
                        card.thumbId = d.id
                        card.origId = EffectThumbs.origKey(d.id)
                        card.before = EffectThumbs.cache[EffectThumbs.origKey(d.id)]
                        card.after = EffectThumbs.cache[d.id]
                        card.badge = l.fx.contains(d.id)
                        card.onClick = { [weak self] in self?.showEffectInfo(d, l) }
                        r.addArrangedSubview(wrap(card, 0, 250, 4, 4, 4, 4))
                    }
                    grid.addArrangedSubview(r)
                    i += cols
                }
            }
        }
        bind(q) { [weak self] s in
            self?.fxQuery = s
            fill()
        }
        put(p, q, 44)
        fill()
        p.addArrangedSubview(grid)
        if Registry.order.contains(where: { !EffectThumbs.ready($0.id) }) {
            EffectThumbs.generate(self, preview) { [weak self] in
                if let self = self, self.panel == P_FX && self.fxTab == 1 { self.refreshPanel() }
            }
        }
        if !EffectThumbs.lastError.isEmpty { text(p, "Preview error: " + EffectThumbs.lastError, C.RED, 11) }
        if let glErr = Registry.errors["__gl"] { text(p, "GL error: " + glErr, C.RED, 11) }
    }

    private func showEffectInfo(_ d: EffectDef, _ l: Layer) {
        let box = vStack()
        box.isLayoutMarginsRelativeArrangement = true
        box.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16)
        let card = EffectCard(d.name, d.category)
        card.anim = d.previewAnim
        card.thumbId = d.id
        card.origId = EffectThumbs.origKey(d.id)
        card.before = EffectThumbs.cache[EffectThumbs.origKey(d.id)]
        card.after = EffectThumbs.cache[d.id]
        box.addArrangedSubview(wrap(card, 0, 280, 0, 0, 0, 0))
        var sb = d.desc + "\n\nParameters: "
        sb += d.props.isEmpty ? "none" : d.props.map { $0.label }.joined(separator: ", ")
        if !d.inputs.isEmpty { sb += "\nLayer inputs: " + d.inputs.joined(separator: ", ") }
        if !d.builtin { sb += "\nCustom effect" }
        if let err = Registry.errors[d.id] { sb += "\n\nShader error:\n" + err }
        let info = UILabel()
        info.text = sb
        info.textColor = argbToUIColor(C.TEXT)
        info.font = sysFont(14)
        info.numberOfLines = 0
        box.addArrangedSubview(pad(info, 10, 0, 0, 0))
        var b = Dlg(self).setTitle(d.name).setView(box)
            .setPositiveButton("Add to layer") { [weak self] _, _ in
                guard let self = self else { return }
                self.pushUndo()
                let entry = d.kind == 1 ? d.id : Registry.uniqueEntry(l, d.id)
                if !l.fx.contains(entry) { l.fx.append(entry) }
                l.fxOff.remove(entry)
                self.expanded.insert("\(l.id):\(entry)")
                self.fxTab = 0
                self.showBottom(); self.refreshPanel(); self.render()
            }
            .setNegativeButton("Close", nil)
        if !d.builtin {
            b = b.setNeutralButton("Export") { [weak self] _, _ in
                guard let self = self else { return }
                self.exportText(d.id + ".saikieffect.json", self.prettyJson(Registry.toJson(d)))
            }
        }
        b.show()
    }

    private func buildPresets(_ l: Layer) {
        let p: UIStackView = panelList
        put(p, pill("Save current effects as preset", "plus", C.GREEN, Int32(bitPattern: 0xFF2B1400)) { [weak self] in
            guard let self = self else { return }
            if l.fx.isEmpty { self.toast("Add an effect first"); return }
            let et = self.makeField("My preset")
            Dlg(self).setTitle("Preset name").setView(et).setPositiveButton("Save") { [weak self] _, _ in
                guard let self = self else { return }
                var n = et.text ?? ""
                if n.trimmingCharacters(in: .whitespaces).isEmpty { n = "My preset" }
                Registry.savePreset(Registry.capturePreset(l, n, Editor.time))
                self.refreshPanel()
            }.setNegativeButton("Cancel", nil).show()
        }, 44)
        put(p, pill("Import preset file", "import") { [weak self] in self?.pickFile(R_PRESET, [.json, .data]) }, 44)
        for pr in Registry.presets() {
            text(p, pr.name + (pr.builtin ? "  (built in)" : ""), C.TEXT, 15, true)
            let r = hRow()
            r.distribution = .fillEqually
            r.spacing = 4
            r.addArrangedSubview(wrap(pill("Apply") { [weak self] in
                guard let self = self else { return }
                self.pushUndo()
                Registry.applyPreset(l, pr.json)
                self.fxTab = 0
                self.refreshPanel(); self.render()
            }, 0, 40, 0, 0, 0, 0))
            r.addArrangedSubview(wrap(pill("Export") { [weak self] in
                guard let self = self else { return }
                self.exportText(pr.name + ".saikipreset.json", self.prettyJson(pr.json))
            }, 0, 40, 0, 0, 0, 0))
            if !pr.builtin {
                r.addArrangedSubview(wrap(pill("Delete", nil, C.CARD2, C.RED) { [weak self] in
                    guard let self = self else { return }
                    Registry.deletePreset(pr.name)
                    self.refreshPanel()
                }, 0, 40, 0, 0, 0, 0))
            }
            put(p, r, 40)
        }
    }

    private func buildCustom(_ l: Layer) {
        let p: UIStackView = panelList
        put(p, pill("Open Effect Editor", "edit", C.GREEN, Int32(bitPattern: 0xFF2B1400)) { [weak self] in
            self?.openEffectEditor()
        }, 48)
        let r0 = hRow()
        r0.distribution = .fillEqually
        r0.spacing = 4
        r0.addArrangedSubview(wrap(pill("New effect", "plus") { [weak self] in self?.openEffectEditor(nil, true) }, 0, 42, 0, 0, 0, 0))
        r0.addArrangedSubview(wrap(pill("Import file", "import") { [weak self] in self?.pickFile(R_FX, [.json, .data]) }, 0, 42, 0, 0, 0, 0))
        put(p, r0, 42)
        text(p, "Each effect is a folder with effect.json and effect.glsl. Edit them in the full-screen editor, or put folders in the sdk/ folder of the app. See SDK.md.", C.DIM, 12)
        let custom = Registry.order.filter { !$0.builtin }
        if custom.isEmpty { text(p, "No custom effects yet.") }
        for d in custom {
            text(p, d.name + (d.bundled ? "  (bundled)" : ""), C.TEXT, 15, true)
            text(p, d.desc, C.DIM, 12)
            if Registry.errors[d.id] != nil { text(p, "Shader error. Open the editor and press Run to see the line.", C.RED, 12) }
            let r = hRow()
            r.distribution = .fillEqually
            r.spacing = 4
            r.addArrangedSubview(wrap(pill("Info") { [weak self] in self?.showEffectInfo(d, l) }, 0, 40, 0, 0, 0, 0))
            r.addArrangedSubview(wrap(pill(d.bundled ? "View" : "Edit") { [weak self] in self?.openEffectEditor(d.source) }, 0, 40, 0, 0, 0, 0))
            r.addArrangedSubview(wrap(pill("Export") { [weak self] in
                guard let self = self else { return }
                self.exportText(d.id + ".saikieffect.json", self.prettyJson(Registry.toJson(d)))
            }, 0, 40, 0, 0, 0, 0))
            if !d.bundled {
                r.addArrangedSubview(wrap(pill("Delete", nil, C.CARD2, C.RED) { [weak self] in
                    guard let self = self else { return }
                    Registry.deleteCustom(d.id)
                    EffectThumbs.cache.removeValue(forKey: d.id)
                    self.refreshPanel()
                }, 0, 40, 0, 0, 0, 0))
            }
            put(p, r, 40)
        }
    }

    /// Opens the full-screen SDK IDE (SdkIdeActivity on Android).
    private func openEffectEditor(_ openPath: String? = nil, _ newEffect: Bool = false) {
        let ide = SdkIdeViewController()
        ide.openPath = openPath
        ide.newEffect = newEffect
        ide.onDone = { [weak self] in
            guard let self = self else { return }
            Registry.reloadSdk()
            for k in EffectThumbs.cache.keys where Registry.byId[k]?.builtin == false || k.hasPrefix("__orig:custom:") {
                EffectThumbs.cache.removeValue(forKey: k)
            }
            EffectThumbs.generate(self, preview) { [weak self] in self?.refreshPanel() }
            self.refreshPanel(); self.render()
        }
        let nav = UINavigationController(rootViewController: ide)
        nav.isNavigationBarHidden = true
        nav.modalPresentationStyle = .fullScreen
        present(nav, animated: true)
    }

    private func showCreateEffect() {
        let box = vStack()
        box.isLayoutMarginsRelativeArrangement = true
        box.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16)
        func field(_ hint: String, _ initText: String) -> UITextField {
            let e = makeField(initText)
            e.placeholder = hint
            e.font = sysFont(13)
            box.addArrangedSubview(wrap(e, 0, 40, 0, 4, 0, 4))
            return e
        }
        func area(_ hint: String, _ initText: String, _ lines: Int) -> UITextView {
            let e = UITextView()
            e.text = initText
            e.font = monoFont(13)
            e.textColor = argbToUIColor(C.TEXT)
            e.backgroundColor = argbToUIColor(C.CARD2)
            e.layer.cornerRadius = 8
            e.keyboardAppearance = .dark
            e.heightAnchor.constraint(equalToConstant: CGFloat(lines) * 22 + 16).isActive = true
            box.addArrangedSubview(wrap(e, 0, 0, 0, 4, 0, 4))
            return e
        }
        let name = field("Name", "My Effect")
        let desc = field("Description", "Mixes the image with grayscale.")
        let params = area("Parameters, one per line: name,label,min,max,default", "amount,Amount,0,1,1", 3)
        let code = area("GLSL code",
                        "vec4 effect(vec2 uv) {\n  vec4 c = src(uv);\n  return vec4(mix(c.rgb, vec3(luma(c.rgb)) * c.a, amount), c.a);\n}", 8)
        Dlg(self).setTitle("Create effect").setView(box).setPositiveButton("Create") { [weak self] _, _ in
            guard let self = self else { return }
            do {
                let pa = JArr()
                for line in (params.text ?? "").components(separatedBy: "\n") {
                    let f = line.split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) }
                    if f.count >= 5 {
                        guard let mn = Double(f[2]), let mx = Double(f[3]), let df = Double(f[4]) else {
                            throw NSError(domain: "saiki", code: 10,
                                          userInfo: [NSLocalizedDescriptionKey: "bad number"])
                        }
                        pa.put(JObj().put("name", f[0]).put("label", f[1]).put("min", mn).put("max", mx).put("def", df))
                    }
                }
                let o = JObj().put("name", name.text ?? "").put("description", desc.text ?? "")
                    .put("params", pa).put("code", code.text ?? "")
                if let err = Registry.addCustom(o.toString()) {
                    self.toast(err)
                } else {
                    self.toast("Effect created")
                    EffectThumbs.generate(self, self.preview) { [weak self] in self?.refreshPanel() }
                    self.refreshPanel()
                }
            } catch { self.toast("Check the parameter lines") }
        }.setNegativeButton("Cancel", nil).show()
    }

    // ---------------------------------------------------------------- graph

    private func buildGraph(_ l: Layer) {
        let p: UIStackView = panelList
        text(p, "Graph editor", C.TEXT, 16, true)
        // Kotlin props is a HashMap (unordered); sorted here so the chip row is stable.
        let animated = l.props.filter { $0.value.keys.count >= 2 }.map { $0.key }.sorted()
        if animated.isEmpty {
            text(p, "Add two keyframes to a parameter (tap its name, then the keyframe button) or tap a keyframe in the timeline.")
            return
        }
        if !animated.contains(graphProp) { graphProp = animated[0]; graphKey = 0 }
        p.addArrangedSubview(chipRow(animated.map { Registry.propDef($0)?.label ?? $0 },
                                     animated.firstIndex(of: graphProp) ?? 0) { [weak self] i in
            guard let self = self else { return }
            self.graphProp = animated[i]
            self.graphKey = 0
            self.refreshPanel()
        })
        let tr = l.track(graphProp)
        if tr.keys.count >= 2 {
            graphKey = clamp(graphKey, 0, tr.keys.count - 2)
        }
        let vg = ValueGraphView(frame: .zero)
        vg.track = tr
        vg.t0 = max(0, (tr.keys.first?.t ?? 0) - 0.3)
        vg.t1 = max(vg.t0 + 0.5, (tr.keys.last?.t ?? 1) + 0.3)
        vg.selIdx = graphKey
        vg.onPick = { [weak self] i in
            guard let self = self else { return }
            if tr.keys.count >= 2 { self.graphKey = clamp(i, 0, tr.keys.count - 2) }
            if tr.keys.indices.contains(i) { Editor.time = tr.keys[i].t }
            self.onTimeChanged(); self.refreshPanel()
        }
        put(p, vg, 150)
        text(p, "Segment \(graphKey + 1) of \(max(tr.keys.count - 1, 1)). Tap a dot to choose a keyframe.", C.DIM, 12)
        guard tr.keys.indices.contains(graphKey) else { return }
        let key = tr.keys[graphKey]
        addPlain(p, "Keyframe time (s)", 0, Editor.scene.duration, key.t, 2) { [weak self] v in
            key.t = v
            tr.keys.sort { $0.t < $1.t }
            self?.render()
        }
        if let pd = Registry.propDef(graphProp) {
            addPlain(p, "Keyframe value", pd.min, pd.max, key.v, pd.dec) { [weak self] v in
                key.v = v
                self?.render()
            }
        }
        text(p, "Easing curve to the next keyframe", C.GREEN, 13, true)
        if key.ease == .ELASTIC || key.ease == .WAVE {
            addPlain(p, "Strength", 0, 2, key.amp, 2) { [weak self] v in
                key.amp = v
                self?.render()
                self?.panelList.arrangedSubviews.forEach { ($0 as? GraphView)?.setNeedsDisplay() }
            }
        }
        if key.ease == .ELASTIC || key.ease == .WAVE || key.ease == .STEPS {
            addPlain(p, key.ease == .STEPS ? "Steps" : "Count", 1, 12, Float(key.cn), 0) { [weak self] v in
                key.cn = clamp(Int(v), 1, 12)
                self?.render()
                self?.panelList.arrangedSubviews.forEach { ($0 as? GraphView)?.setNeedsDisplay() }
            }
        }
        let g = GraphView(frame: .zero)
        g.key = key
        g.onBegin = { [weak self] in self?.pushUndo() }
        g.onChange = { [weak self] in self?.render() }
        put(p, g, 220)
        if key.isBezier() && !key.rev { text(p, "Drag the white handles. Pull a handle above the top for overshoot.", C.DIM, 12) }
        let acts = hRow()
        acts.distribution = .fillEqually
        acts.spacing = 3
        acts.addArrangedSubview(wrap(pill("Copy curve") { [weak self] in
            self?.curveClip = Key(0, 0, .CUSTOM)
            self?.curveClip?.copyCurveFrom(key)
            Snack.show("Curve copied")
        }, 0, 40, 0, 0, 0, 0))
        acts.addArrangedSubview(wrap(pill("Paste") { [weak self] in
            guard let self = self, let c = self.curveClip else { Snack.show("No curve copied"); return }
            self.pushUndo()
            key.copyCurveFrom(c)
            self.refreshPanel(); self.render()
        }, 0, 40, 0, 0, 0, 0))
        acts.addArrangedSubview(wrap(pill("Reverse") { [weak self] in
            guard let self = self else { return }
            self.pushUndo()
            key.rev = !key.rev
            self.refreshPanel(); self.render()
        }, 0, 40, 0, 0, 0, 0))
        put(p, acts, 40)
        put(p, pill("Apply this curve to every segment") { [weak self] in
            guard let self = self else { return }
            self.pushUndo()
            for k in tr.keys { k.copyCurveFrom(key) }
            self.render()
        }, 42)
        text(p, "Curve presets", C.TEXT, 14, true)
        let hscroll = UIScrollView()
        hscroll.showsHorizontalScrollIndicator = false
        let row = hRow()
        row.spacing = 3
        hscroll.addSubview(row)
        row.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            row.topAnchor.constraint(equalTo: hscroll.contentLayoutGuide.topAnchor),
            row.bottomAnchor.constraint(equalTo: hscroll.contentLayoutGuide.bottomAnchor),
            row.leadingAnchor.constraint(equalTo: hscroll.contentLayoutGuide.leadingAnchor),
            row.trailingAnchor.constraint(equalTo: hscroll.contentLayoutGuide.trailingAnchor),
            row.heightAnchor.constraint(equalTo: hscroll.frameLayoutGuide.heightAnchor)
        ])
        func bz(_ x1: Float, _ y1: Float, _ x2: Float, _ y2: Float) -> Key {
            let k = Key(0, 0, .CUSTOM)
            k.x1 = x1; k.y1 = y1; k.x2 = x2; k.y2 = y2
            return k
        }
        var builtins: [(String, Key)] = [
            ("Linear", Key(0, 0, .LINEAR)),
            ("Ease In", Key(0, 0, .EASE_IN)),
            ("Ease Out", Key(0, 0, .EASE_OUT)),
            ("Smooth", Key(0, 0, .EASE_IN_OUT)),
            ("Back", bz(0.34, 1.56, 0.64, 1)),
            ("Expo", bz(0.7, 0, 0.84, 0)),
            ("Snap", bz(1, 0, 0, 1))
        ]
        let el = Key(0, 0, .ELASTIC); el.cn = 3
        builtins.append(("Elastic", el))
        builtins.append(("Bounce", Key(0, 0, .BOUNCE)))
        let wv = Key(0, 0, .WAVE); wv.cn = 2
        builtins.append(("Wave", wv))
        let st = Key(0, 0, .STEPS); st.cn = 4
        builtins.append(("Steps", st))
        for (nm, k) in builtins {
            let tv = CurveThumb(k, nm)
            tv.onClick = { [weak self] in
                guard let self = self else { return }
                self.pushUndo()
                key.copyCurveFrom(k)
                self.refreshPanel(); self.render()
            }
            row.addArrangedSubview(wrap(tv, 78, 78, 3, 3, 3, 3))
        }
        put(p, hscroll, 86)
        text(p, "Easing type", C.DIM, 12)
        let types = ["Bezier", "Elastic", "Bounce", "Wave", "Steps"]
        let cur: Int
        switch key.ease {
        case .ELASTIC: cur = 1
        case .BOUNCE: cur = 2
        case .WAVE: cur = 3
        case .STEPS: cur = 4
        default: cur = 0
        }
        p.addArrangedSubview(chipRow(types, cur) { [weak self] i in
            guard let self = self else { return }
            self.pushUndo()
            switch i {
            case 0: if !key.isBezier() { key.preset(.EASE_IN_OUT) }
            case 1: key.ease = .ELASTIC; key.cn = 3; key.amp = 1
            case 2: key.preset(.BOUNCE)
            case 3: key.ease = .WAVE; key.cn = 2; key.amp = 1
            default: key.ease = .STEPS; key.cn = 4
            }
            self.refreshPanel(); self.render()
        })
        let names = ["Linear", "Ease In", "Ease Out", "Ease In-Out", "Bounce", "Back", "Expo", "Snap"]
        p.addArrangedSubview(chipRow(names, -1) { [weak self] i in
            guard let self = self else { return }
            self.pushUndo()
            switch i {
            case 0: key.preset(.LINEAR)
            case 1: key.preset(.EASE_IN)
            case 2: key.preset(.EASE_OUT)
            case 3: key.preset(.EASE_IN_OUT)
            case 4: key.preset(.BOUNCE)
            default:
                let v: [[Float]] = [[0.34, 1.56, 0.64, 1], [0.7, 0, 0.84, 0], [1, 0, 0, 1]]
                let q = v[i - 5]
                key.ease = .CUSTOM
                key.x1 = q[0]; key.y1 = q[1]; key.x2 = q[2]; key.y2 = q[4 - 1]
            }
            self.refreshPanel(); self.render()
        })
        put(p, pill("Copy this curve to every segment") { [weak self] in
            guard let self = self else { return }
            self.pushUndo()
            for k in tr.keys {
                k.ease = key.ease
                k.x1 = key.x1; k.y1 = key.y1; k.x2 = key.x2; k.y2 = key.y2
            }
            self.render()
        }, 42)
        text(p, "Drag the white handles. Pull a handle above the top for overshoot.", C.DIM, 12)
    }

    private func showPanelMenu() {
        guard let l = selected() else { return }
        Dlg(self).setTitle("Layer").setItems(["Clear all keyframes", "Reset transform", "Snap keyframes to beat markers"]) { [weak self] _, which in
            guard let self = self else { return }
            self.pushUndo()
            if which == 2 {
                self.snapKeys(l)
            } else {
                for (k, tr) in l.props {
                    if which == 0 {
                        tr.keys.removeAll()
                        _ = tr.setExpr("")
                        tr.exprOn = false
                    } else if Defs.transform.contains(where: { $0.key == k })
                                || Defs.rot3d.contains(where: { $0.key == k }) || k == "z" {
                        tr.keys.removeAll()
                        tr.base = Registry.propDef(k)?.def ?? 0
                    }
                }
            }
            self.refreshPanel(); self.render()
        }.show()
    }

    // ================================================================ scenes + export

    private func showSceneDialog() {
        let box = vStack()
        box.isLayoutMarginsRelativeArrangement = true
        box.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16)
        let dlg = Dlg(self).setTitle("Scene setup").setView(box).setPositiveButton("Done", nil).create()
        var build: (() -> Void)! = nil
        build = { [weak self] in
            guard let self = self else { return }
            box.arrangedSubviews.forEach { $0.removeFromSuperview() }
            let pr = Editor.project
            let s = Editor.scene
            text(box, Projects.resLabel(pr.w, pr.h) + "  ·  \(pr.w) x \(pr.h)  ·  \(pr.fps) fps", C.DIM)
            text(box, "Guides", C.GREEN, 13, true)
            let gs = SwitchRow()
            gs.label = "Guides"; gs.on = self.overlay.guides
            gs.onToggle = { [weak self] v in
                guard let self = self else { return }
                self.overlay.guides = v
                self.overlay.setNeedsDisplay()
            }
            put(box, gs, 52)
            text(box, "Scenes", C.GREEN, 13, true)
            var sceneNames = pr.scenes.map { $0.name }
            sceneNames.append("New scene")
            box.addArrangedSubview(chipRow(sceneNames, Editor.sceneIndex) { [weak self] i in
                guard let self = self else { return }
                self.pushUndo()
                if i == pr.scenes.count {
                    pr.scenes.append(Scene("Scene \(pr.scenes.count + 1)"))
                    Editor.sceneIndex = pr.scenes.count - 1
                } else {
                    Editor.sceneIndex = i
                }
                Editor.time = 0
                self.selId = -1
                self.panel = P_NONE
                self.refreshAll()
                build()
            })
            if pr.scenes.count > 1 {
                put(box, pill("Delete this scene", nil, C.CARD2, C.RED) { [weak self] in
                    guard let self = self else { return }
                    self.pushUndo()
                    pr.scenes.removeAll { $0 === s }
                    Editor.sceneIndex = 0
                    Editor.time = 0
                    self.selId = -1
                    self.panel = P_NONE
                    self.refreshAll()
                    build()
                }, 40)
            }
            let d = RulerSlider(frame: .zero)
            d.label = "Duration (s)"; d.lo = 1; d.hi = 120; d.value = s.duration; d.dec = 1; d.canKey = false
            d.onChange = { [weak self] v in
                guard let self = self else { return }
                let old = s.duration
                s.duration = max(1, Float(kotlinRound(v * 2)) / 2)
                for l in s.layers where l.end >= old - 0.001 { l.end = s.duration }
                Editor.time = clamp(Editor.time, 0, s.duration)
                self.onTimeChanged()
            }
            put(box, d, 60, 8, 4)
            let f = RulerSlider(frame: .zero)
            f.label = "Scene FOV"; f.lo = 15; f.hi = 90; f.value = s.fov; f.dec = 0; f.canKey = false
            f.onChange = { [weak self] v in s.fov = v; self?.render() }
            put(box, f, 60)
            text(box, "Background", C.GREEN, 13, true)
            box.addArrangedSubview(wrap(self.colorRow(s.bg) { [weak self] c in
                s.bg = c
                self?.render()
            }, 0, 48, 0, 0, 0, 0))
        }
        build()
        dlg.show()
    }

    private func showRenderDialog() {
        if playing { togglePlay() }
        Projects.save(projectId, Editor.project)
        let proj = Editor.project
        RenderUi.settings(self, proj) { [weak self] st in
            guard let self = self else { return }
            RenderUi.show(self, proj, st)
        }
    }

    // ================================================================ private string/number helpers

    /// Attaches a TextWatcher-equivalent target to a UITextField. UIControl does not retain its
    /// targets, so the watcher is associated to the field (lifetime == field lifetime).
    private func bind(_ field: UIControl, _ handler: @escaping (String) -> Void) {
        let w = EditWatcher(handler)
        objc_setAssociatedObject(field, &EditorFieldWatchKey, w, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        field.addTarget(w, action: #selector(EditWatcher.change(_:)), for: .editingChanged)
    }

    private func makeField(_ text: String) -> UITextField {
        let f = UITextField()
        f.text = text
        f.textColor = argbToUIColor(C.TEXT)
        f.font = sysFont(16)
        f.backgroundColor = argbToUIColor(C.CARD2)
        f.layer.cornerRadius = 10
        f.keyboardAppearance = .dark
        f.autocorrectionType = .no
        f.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: 1))
        f.leftViewMode = .always
        f.rightView = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: 1))
        f.rightViewMode = .always
        return f
    }

    private func monoFont(_ size: CGFloat) -> UIFont {
        UIFont(name: "Menlo", size: size) ?? .monospacedSystemFont(ofSize: size, weight: .regular)
    }

    /// Kotlin Float.toInt(): truncate toward zero, NaN → 0, saturate at Int32 bounds.
    private func ktInt(_ v: Float) -> Int {
        if v.isNaN { return 0 }
        if v >= 2147483520 { return Int(Int32.max) }
        if v <= -2147483520 { return Int(Int32.min) }
        return Int(v)
    }

    private func cap(_ s: String) -> String {
        guard let f = s.first else { return s }
        return String(f).uppercased() + String(s.dropFirst())
    }

    /// Kotlin String.substringAfter — returns the whole string when the separator is missing.
    private func afterFirst(_ s: String, _ sep: Character) -> String {
        if let i = s.firstIndex(of: sep) { return String(s[s.index(after: i)...]) }
        return s
    }

    private func afterLast(_ s: String, _ sep: Character) -> String {
        if let i = s.lastIndex(of: sep) { return String(s[s.index(after: i)...]) }
        return s
    }

    private func beforeLast(_ s: String, _ sep: Character) -> String {
        if let i = s.lastIndex(of: sep) { return String(s[..<i]) }
        return s
    }

    /// name.replace(Regex("[^A-Za-z0-9]"), "_")
    private func alnum(_ s: String) -> String {
        String(s.map { c in
            (c.isASCII && c.isLetter) || (c.isASCII && c.isNumber) ? c : "_"
        })
    }

    /// org.json toString(indent) equivalent used for exported effect/preset files
    /// (Core/JSON.swift only ships the compact writer) — PORT NOTE.
    private func prettyJson(_ v: Any, _ indent: Int = 0) -> String {
        let p = String(repeating: " ", count: indent)
        let p2 = String(repeating: " ", count: indent + 2)
        if let o = v as? JObj {
            if o.dict.isEmpty { return "{}" }
            var s = "{\n"
            let ks = o.keys
            for (i, k) in ks.enumerated() {
                s += p2 + "\"" + k + "\": " + prettyJson(o.dict[k]!, indent + 2)
                s += i < ks.count - 1 ? ",\n" : "\n"
            }
            return s + p + "}"
        }
        if let a = v as? JArr {
            if a.items.isEmpty { return "[]" }
            var s = "[\n"
            for (i, item) in a.items.enumerated() {
                s += p2 + prettyJson(item, indent + 2)
                s += i < a.items.count - 1 ? ",\n" : "\n"
            }
            return s + p + "]"
        }
        if let s = v as? String {
            var out = "\""
            for ch in s.unicodeScalars {
                switch ch {
                case "\"": out += "\\\""
                case "\\": out += "\\\\"
                case "\n": out += "\\n"
                case "\r": out += "\\r"
                case "\t": out += "\\t"
                default: out.unicodeScalars.append(ch)
                }
            }
            return out + "\""
        }
        if let b = v as? Bool { return b ? "true" : "false" }
        if let i = v as? Int64 { return String(i) }
        if let i = v as? Int32 { return String(i) }
        if let i = v as? Int { return String(i) }
        if let d = v as? Double { return JSONWriter.numberToString(d) }
        if let f = v as? Float { return JSONWriter.numberToString(Double(f)) }
        return "null"
    }
}
