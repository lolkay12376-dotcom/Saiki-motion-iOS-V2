// Editor.swift — the editor's session state (Core).
//
// Kotlin `object Editor`. The open project, the active scene index and the
// playhead time live here so every module (timeline, preview, graph, audio)
// reads the same source of truth while the EditorActivity is on screen.

import Foundation

enum Editor {
    static var project: Project = Project(name: "Untitled")
    static var sceneIndex: Int = 0
    static var time: Float = 0

    /// The scene `sceneIndex` points at (first scene as a safety net).
    static var scene: Scene {
        get {
            if project.scenes.indices.contains(sceneIndex) { return project.scenes[sceneIndex] }
            return project.scenes.first ?? project.scenes[0]
        }
        set {
            if project.scenes.indices.contains(sceneIndex) {
                project.scenes[sceneIndex] = newValue
            } else if !project.scenes.isEmpty {
                project.scenes[0] = newValue
            }
        }
    }
}
