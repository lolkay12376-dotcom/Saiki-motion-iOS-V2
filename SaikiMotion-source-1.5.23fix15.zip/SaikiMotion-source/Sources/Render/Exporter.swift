// Exporter.swift — offscreen render to MP4 (Render).
//
// Renders every frame through the same SceneRenderer the preview uses (full
// quality, deterministic video sampling), writes H.264 via AVAssetWriter,
// then muxes the first audio layer on top with an AVMutableComposition pass.
// Output lands in <Documents>/SaikiMotion/exports and (optionally) Photos.

import Foundation
import AVFoundation
import OpenGLES
import GLKit
import UIKit

struct RenderSettings {
    var scale: Float = 1          // canvas resolution multiplier
    var fps: Int = 30
    var draft = false             // quarter-res fast pass
    var withAudio = true
}

enum Exporter {

    final class Result {
        var url: URL? = nil
        var error: String? = nil
        var frames = 0
    }

    /// Renders `project`'s current scene to an .mp4. Blocking — call off main.
    static func export(project: Project, scene: Scene, settings: RenderSettings) -> Result {
        let res = Result()
        Paths.ensure()
        let outDir = Paths.root.appendingPathComponent("exports", isDirectory: true)
        try? FileManager.default.createDirectory(at: outDir, withIntermediateDirectories: true)
        let name = "\(alnum(project.name))-\(nowMs()).mp4"
        let outURL = outDir.appendingPathComponent(name)
        try? FileManager.default.removeItem(at: outURL)

        let w = max(16, Int(Float(project.w) * settings.scale) & ~1)   // even for H.264
        let h = max(16, Int(Float(project.h) * settings.scale) & ~1)
        let fps = settings.fps
        let duration = scene.duration

        guard let ctx = GLContext.make() else {
            res.error = "Could not create a GL context."
            return res
        }
        let prev = EAGLContext.current()
        EAGLContext.setCurrent(ctx)
        defer { EAGLContext.setCurrent(prev) }

        let renderer = SceneRenderer(context: ctx)
        renderer.quality = settings.draft ? 4 : 1

        // audio: first visible audio layer
        var audioURL: URL? = nil
        var audioStart: Float = 0
        var audioOffset: Float = 0
        if settings.withAudio {
            for l in scene.layers where l.type == .AUDIO && l.visible {
                if let p = l.imagePath {
                    audioURL = URL(fileURLWithPath: p)
                    audioStart = l.start
                    audioOffset = l.srcOffset
                    break
                }
            }
        }

        let writer = try? AVAssetWriter(outputURL: outURL, fileType: .mp4)
        guard let writer = writer else {
            res.error = "Could not create the movie file."
            return res
        }
        let videoSettings: [String: Any] = [
            AVVideoCodecKey: AVVideoCodecType.h264,
            AVVideoWidthKey: w,
            AVVideoHeightKey: h,
        ]
        let videoInput = AVAssetWriterInput(mediaType: .video, outputSettings: videoSettings)
        videoInput.expectsMediaDataInRealTime = false
        let adaptor = AVAssetWriterInputPixelBufferAdaptor(
            assetWriterInput: videoInput,
            sourcePixelBufferAttributes: [
                kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
                kCVPixelBufferWidthKey as String: w,
                kCVPixelBufferHeightKey as String: h,
            ])
        writer.add(videoInput)

        // GL readback buffer (RGBA → BGRA swap while copying); sized after the
        // first draw() fixes the renderer's working resolution
        var glData = [UInt8](repeating: 0, count: 4)

        writer.startWriting()
        writer.startSession(atSourceTime: .zero)

        let frames = Int(duration * Float(fps))
        let queue = DispatchQueue(label: "saiki.export")
        let done = DispatchSemaphore(value: 0)

        var frameIdx = 0
        let timeInc = 1.0 / Double(fps)

        // Frame pump: writer input pulls frames as fast as it can consume them.
        videoInput.requestMediaDataWhenReady(on: queue) {
            while videoInput.isReadyForMoreMediaData {
                if frameIdx >= frames || writer.status == .failed {
                    videoInput.markAsFinished()
                    done.signal()
                    return
                }
                let t = Float(Double(frameIdx) * timeInc)

                // render at preview res then read pixels
                _ = renderer.draw(project: project, scene: scene, time: t, video: nil)
                guard let target = renderer.sceneTarget else {
                    videoInput.markAsFinished()
                    done.signal()
                    return
                }
                if glData.count != target.width * target.height * 4 {
                    glData = [UInt8](repeating: 0, count: target.width * target.height * 4)
                }
                glBindFramebuffer(GLenum(GL_FRAMEBUFFER), target.fbo)
                glReadPixels(0, 0, GLsizei(target.width), GLsizei(target.height),
                             GLenum(GL_RGBA), GLenum(GL_UNSIGNED_BYTE), &glData)

                if let pb = makePixelBuffer(glData, Int(target.width), Int(target.height), w, h) {
                    let cm = CMTime(seconds: Double(frameIdx) * timeInc, preferredTimescale: CMTimeScale(fps * 1000))
                    adaptor.append(pb, withPresentationTime: cm)
                    ExporterProgress.shared.add()
                }
                frameIdx += 1
            }
        }

        _ = done.wait(timeout: .now() + 60 * 60 * 24)
        res.frames = frameIdx
        if writer.status == .failed {
            res.error = writer.error?.localizedDescription ?? "The encoder failed."
            try? FileManager.default.removeItem(at: outURL)
            return res
        }
        writer.finishWriting {
            // status becomes .completed here
        }
        while writer.status == .writing {
            Thread.sleep(forTimeInterval: 0.05)
        }
        if writer.status != .completed {
            res.error = writer.error?.localizedDescription ?? "The encoder did not finish."
            try? FileManager.default.removeItem(at: outURL)
            return res
        }

        // audio mux pass
        if let audioURL = audioURL {
            let muxed = muxAudio(video: outURL, audio: audioURL,
                                 at: audioStart, offset: audioOffset,
                                 duration: duration)
            if let muxed = muxed {
                try? FileManager.default.removeItem(at: outURL)
                res.url = muxed
                return res
            }
            // mux failed → ship the silent video
        }
        res.url = outURL
        return res
    }

    /// RGBA buffer (bottom-up) → CVPixelBuffer (top-down BGRA), scaled to outW×outH.
    private static func makePixelBuffer(_ data: [UInt8], _ rw: Int, _ rh: Int,
                                        _ outW: Int, _ outH: Int) -> CVPixelBuffer? {
        var pb: CVPixelBuffer?
        CVPixelBufferCreate(kCFAllocatorDefault, outW, outH,
                            kCVPixelFormatType_32BGRA, nil, &pb)
        guard let pb = pb else { return nil }
        CVPixelBufferLockBaseAddress(pb, [])
        defer { CVPixelBufferUnlockBaseAddress(pb, []) }
        guard let base = CVPixelBufferGetBaseAddress(pb) else { return nil }
        let bpr = CVPixelBufferGetBytesPerRow(pb)
        let dst = base.assumingMemoryBound(to: UInt8.self)

        for y in 0..<outH {
            // flip vertically (GL origin bottom-left → video top-left)
            let srcY = min(rh - 1, Int(Float(rh - 1) * Float(outH - 1 - y) / Float(max(outH - 1, 1))))
            let row = srcY * rw * 4
            let dstRow = y * bpr
            if rw == outW {
                for x in 0..<outW {
                    let s = row + x * 4
                    let d = dstRow + x * 4
                    dst[d] = data[s + 2]      // B
                    dst[d + 1] = data[s + 1]  // G
                    dst[d + 2] = data[s]      // R
                    dst[d + 3] = data[s + 3]  // A
                }
            } else {
                for x in 0..<outW {
                    let sx = min(rw - 1, Int(Float(rw - 1) * Float(x) / Float(max(outW - 1, 1))))
                    let s = row + sx * 4
                    let d = dstRow + x * 4
                    dst[d] = data[s + 2]
                    dst[d + 1] = data[s + 1]
                    dst[d + 2] = data[s]
                    dst[d + 3] = data[s + 3]
                }
            }
        }
        return pb
    }

    /// Composes the rendered video + one audio track into a final .mp4.
    private static func muxAudio(video: URL, audio: URL, at start: Float, offset: Float,
                                 duration: Float) -> URL? {
        let comp = AVMutableComposition()
        guard let vTrack = comp.addMutableTrack(withMediaType: .video, preferredTrackID: 1),
              let vidAsset = try? AVURLAsset(url: video),
              let vSrc = vidAsset.tracks(withMediaType: .video).first else { return nil }
        let vRange = CMTimeRange(start: .zero, duration: vidAsset.duration)
        try? vTrack.insertTimeRange(vRange, of: vSrc, at: .zero)

        if let aTrack = comp.addMutableTrack(withMediaType: .audio, preferredTrackID: 2),
           let audAsset = try? AVURLAsset(url: audio),
           let aSrc = audAsset.tracks(withMediaType: .audio).first {
            let at = CMTime(seconds: Double(max(0, offset)), preferredTimescale: 600)
            let inDur = audAsset.duration - at
            let want = CMTime(seconds: Double(duration), preferredTimescale: 600)
            let len = min(inDur, want)
            if len.seconds > 0 {
                let range = CMTimeRange(start: at, duration: len)
                let insertAt = CMTime(seconds: Double(max(0, start)), preferredTimescale: 600)
                try? aTrack.insertTimeRange(range, of: aSrc, at: insertAt)
            }
        }

        let out = video.deletingLastPathComponent()
            .appendingPathComponent("mux-" + video.lastPathComponent)
        try? FileManager.default.removeItem(at: out)
        guard let session = AVAssetExportSession(asset: comp,
                                                 presetName: AVAssetExportPresetHighestQuality) else { return nil }
        session.outputURL = out
        session.outputFileType = .mp4
        let sem = DispatchSemaphore(value: 0)
        session.exportAsynchronously { sem.signal() }
        _ = sem.wait(timeout: .now() + 1800)
        guard session.status == .completed else {
            try? FileManager.default.removeItem(at: out)
            return nil
        }
        return out
    }

    private static func alnum(_ s: String) -> String {
        String(s.map { c in
            (c.isASCII && c.isLetter) || (c.isASCII && c.isNumber) ? c : "_"
        })
    }
}

// MARK: - RenderUi

/// The render flow the editor launches: a settings dialog, then a full-screen
/// progress controller with cancel, then a done sheet (Photos / Share).
enum RenderUi {

    static func settings(_ vc: UIViewController, _ project: Project,
                         _ done: @escaping (RenderSettings) -> Void) {
        var st = RenderSettings()
        let box = UIStackView()
        box.axis = .vertical
        box.alignment = .fill
        box.spacing = 6
        box.isLayoutMarginsRelativeArrangement = true
        box.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16)

        let title = UILabel()
        title.text = "Resolution  \(project.w) x \(project.h)"
        title.textColor = argbToUIColor(C.TEXT)
        title.font = boldFont(15)
        box.addArrangedSubview(title)

        let res = chipRow(["Half", "Full", "1.5x"], 1) { i in
            st.scale = i == 0 ? 0.5 : (i == 1 ? 1 : 1.5)
        }
        box.addArrangedSubview(res)

        let fpsLabel = UILabel()
        fpsLabel.text = "Frame rate"
        fpsLabel.textColor = argbToUIColor(C.DIM)
        fpsLabel.font = sysFont(13)
        box.addArrangedSubview(fpsLabel)
        let fpsRow = chipRow(["24", "30", "60"], 1) { i in
            st.fps = [24, 30, 60][i]
        }
        box.addArrangedSubview(fpsRow)

        let qualityLabel = UILabel()
        qualityLabel.text = "Quality"
        qualityLabel.textColor = argbToUIColor(C.DIM)
        qualityLabel.font = sysFont(13)
        box.addArrangedSubview(qualityLabel)
        let qRow = chipRow(["Draft (fast)", "Final"], 1) { i in
            st.draft = i == 0
        }
        box.addArrangedSubview(qRow)

        let audio = SwitchRow()
        audio.label = "Include audio"
        audio.on = true
        audio.onToggle = { v in st.withAudio = v }
        box.addArrangedSubview(audio)
        audio.heightAnchor.constraint(equalToConstant: 52).isActive = true

        _ = Dlg(vc).setTitle("Render").setView(box)
            .setPositiveButton("Render") { _, _ in
                done(st)
            }
            .setNegativeButton("Cancel", nil)
            .show()
    }

    static func show(_ vc: UIViewController, _ project: Project, _ st: RenderSettings) {
        let progress = RenderProgressViewController(project: project, settings: st)
        progress.modalPresentationStyle = .fullScreen
        vc.present(progress, animated: true)
    }
}

final class RenderProgressViewController: UIViewController {
    private let project: Project
    private let settings: RenderSettings
    private var bar = UIView()
    private var barBack = UIView()
    private var label = UILabel()
    private var sub = UILabel()
    private var cancelled = false
    private var result: Exporter.Result?

    init(project: Project, settings: RenderSettings) {
        self.project = project
        self.settings = settings
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    override var prefersStatusBarHidden: Bool { true }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = argbToUIColor(Int32(bitPattern: 0xEE0B0B10))

        let title = UILabel()
        title.text = "Rendering"
        title.textColor = argbToUIColor(C.TEXT)
        title.font = boldFont(20)
        title.textAlignment = .center
        title.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(title)

        label.text = "0 %"
        label.textColor = argbToUIColor(C.TEXT)
        label.font = boldFont(34)
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(label)

        sub.text = "\(project.name)"
        sub.textColor = argbToUIColor(C.DIM)
        sub.font = sysFont(13)
        sub.textAlignment = .center
        sub.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(sub)

        barBack.backgroundColor = argbToUIColor(C.CARD2)
        barBack.layer.cornerRadius = 4
        barBack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(barBack)
        bar.backgroundColor = argbToUIColor(C.GREEN)
        bar.translatesAutoresizingMaskIntoConstraints = false
        barBack.addSubview(bar)

        let cancel = PillButton("Cancel", "close", C.CARD2, C.TEXT)
        cancel.onClick = { [weak self] in
            self?.cancelled = true
        }
        cancel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(cancel)

        NSLayoutConstraint.activate([
            title.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            title.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -110),
            label.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            label.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -50),
            sub.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            sub.topAnchor.constraint(equalTo: label.bottomAnchor, constant: 8),
            barBack.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            barBack.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 30),
            barBack.widthAnchor.constraint(equalToConstant: 260),
            barBack.heightAnchor.constraint(equalToConstant: 8),
            bar.leadingAnchor.constraint(equalTo: barBack.leadingAnchor),
            bar.centerYAnchor.constraint(equalTo: barBack.centerYAnchor),
            bar.heightAnchor.constraint(equalTo: barBack.heightAnchor),
            cancel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            cancel.topAnchor.constraint(equalTo: barBack.bottomAnchor, constant: 28),
            cancel.widthAnchor.constraint(equalToConstant: 120),
            cancel.heightAnchor.constraint(equalToConstant: 42),
        ])

        start()
    }

    private func start() {
        let project = self.project
        let st = self.settings
        let scene = Editor.scene
        let total = max(1, Int(scene.duration * Float(st.fps)))
        Thread.detachNewThread {
            let res = Exporter.export(project: project, scene: scene, settings: st)
            DispatchQueue.main.async { [weak self] in
                self?.finished(res)
            }
        }
        // gentle progress animation (frames written vs total)
        Timer.scheduledTimer(withTimeInterval: 0.25, repeats: true) { [weak self] t in
            guard let self = self else { t.invalidate(); return }
            if self.cancelled { t.invalidate(); return }
            let done = ExporterProgress.shared.frames
            let p = CGFloat(done) / CGFloat(total)
            self.bar.frame = CGRect(x: 0, y: 0, width: self.barBack.bounds.width * min(p, 1), height: 8)
            self.label.text = String(format: "%.0f %%", min(p, 1) * 100)
            self.sub.text = "\(done) / \(total) frames"
        }
    }

    private func finished(_ res: Exporter.Result) {
        if cancelled {
            if let u = res.url { try? FileManager.default.removeItem(at: u) }
            dismiss(animated: true)
            return
        }
        if let err = res.error {
            let a = UIAlertController(title: "Render failed", message: err, preferredStyle: .alert)
            a.addAction(UIAlertAction(title: "OK", style: .default) { [weak self] _ in
                self?.dismiss(animated: true)
            })
            present(a, animated: true)
            return
        }
        guard let url = res.url else {
            dismiss(animated: true)
            return
        }
        let a = UIAlertController(title: "Render complete",
                                  message: url.lastPathComponent, preferredStyle: .actionSheet)
        a.addAction(UIAlertAction(title: "Save to Photos", style: .default) { [weak self] _ in
            UISaveVideoAtPathToSavedPhotosAlbum(url.path, nil, nil, nil)
            Snack.show("Saved to Photos")
            self?.dismiss(animated: true)
        })
        a.addAction(UIAlertAction(title: "Share", style: .default) { [weak self] _ in
            let share = UIActivityViewController(activityItems: [url], applicationActivities: nil)
            if let pop = share.popoverPresentationController {
                pop.sourceView = self?.view ?? UIView()
            }
            self?.present(share, animated: true)
        })
        a.addAction(UIAlertAction(title: "Close", style: .cancel) { [weak self] _ in
            self?.dismiss(animated: true)
        })
        if let pop = a.popoverPresentationController {
            pop.sourceView = view
            pop.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 1, height: 1)
        }
        present(a, animated: true)
    }

}

/// Cross-thread frame counter (exporter pumps, UI animates).
enum ExporterProgress {
    static var shared = Shared()
    final class Shared {
        private(set) var frames = 0
        private let lock = NSLock()
        func add() {
            lock.lock()
            frames += 1
            lock.unlock()
        }
    }
}
