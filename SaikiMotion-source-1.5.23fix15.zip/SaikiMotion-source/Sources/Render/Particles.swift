// Particles.swift — the deterministic particle field (Render).
//
// State is a pure function of (seed, time): every particle's age is
// `t mod life` offset by a hash of its index, its path is dir + gravity +
// spread jitter. No state survives between frames, so scrubbing and export
// produce identical results.

import Foundation

struct Particle {
    var x: Float
    var y: Float
    var size: Float
    var life: Float   // 0 fresh → 1 dead
}

enum ParticlesSim {

    static func field(count: Int, spread: Float, speed: Float, gravity: Float,
                      life: Float, seed: Float, dirX: Float, dirY: Float,
                      t: Float, ar: Float) -> [Particle] {
        var out: [Particle] = []
        out.reserveCapacity(count)
        let n = max(1, count)
        let time = max(0, t)
        for i in 0..<n {
            let fi = Float(i)
            let h0 = hash(seed * 131.0 + fi)
            let h1 = hash(seed * 977.0 + fi * 7.0)
            let h2 = hash(seed * 3313.0 + fi * 13.0)
            let h3 = hash(seed * 6151.0 + fi * 29.0)

            let ageOffset = h0 * life
            var age = time - ageOffset
            age = age.truncatingRemainder(dividingBy: life)
            if age < 0 { age += life }
            let p = age / max(life, 0.01)

            // birth place in a disc of `spread` radius
            let ang = h1 * 2 * Float.pi
            let rad = sqrt(h2) * spread * 0.5
            let bx = cos(ang) * rad
            let by = sin(ang) * rad

            // velocity: base direction + jitter
            let jx = (h3 - 0.5) * spread * 0.6
            let jy = (hash(seed * 17.0 + fi * 3.0) - 0.5) * spread * 0.6
            let vx = (dirX + jx) * speed
            let vy = (dirY + jy) * speed

            let x = bx + vx * age
            let y = by + vy * age + gravity * age * age * 0.5

            out.append(Particle(x: x / ar, y: y, size: 0.5 + h2, life: p))
        }
        return out
    }

    private static func hash(_ x: Float) -> Float {
        var n = UInt32(truncatingIfNeeded: Int64(x * 8192.0))
        n = n &* 747796405 &+ 2891336453
        n = ((n >> ((n >> 28) + 4)) ^ n) &* 277803737
        n = (n >> 22) ^ n
        return Float(n % 100000) / 100000
    }
}
