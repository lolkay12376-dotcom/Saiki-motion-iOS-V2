// FreezeWatchdog.swift — round 15/19 design, corrected.
//
// What 19 rounds taught us, encoded here:
//   * Liveness = the heartbeat VALUE CHANGES. The round-14 bug ("a poke that
//     gets answered means alive") made real freezes undetectable, because a
//     wedged thread can still have a signal handler that answers pokes while
//     the run loop itself never turns. So: only a monotonic counter.
//   * A freeze is declared ONLY when the heartbeat stopped AND unsaved work
//     is in flight. Never while idling on menus, never during guarded
//     long operations (VDB import, export), never right after backgrounding.
//   * When a real freeze is confirmed: write the report, then abort. A wedged
//     app inside LiveContainer freezes the whole container — a clean kill is
//     strictly better for the user (and the OS log then tells the truth).

import Foundation
import CCrashLog

enum FreezeWatchdog {

    private static let checkInterval: TimeInterval = 2.0
    private static let stuckChecksNeeded = 3        // ~6 s truly stuck
    private static var thread: Thread? = nil
    private static let lock = NSLock()

    // Written only on the main thread; read by the watchdog thread.
    private static var heartbeat: Int64 = 0
    private static var dirty = false                // unsaved work in flight

    // Guarded operations: main thread may legitimately go quiet.
    private static var guarded = 0
    private static var guardLabel = ""

    /// Start the watchdog. Call once after CrashLog.install().
    static func start() {
        lock.lock()
        if thread != nil { lock.unlock(); return }   // idempotent
        let t = Thread(block: run)
        t.name = "freeze-watchdog"
        t.qualityOfService = .utility
        thread = t
        lock.unlock()
        t.start()
    }

    // MARK: main-thread API ------------------------------------------------

    /// Call from the render/frame path and from every edit. Cheap.
    static func beat() { heartbeat &+= 1 }

    /// Unsaved work exists (set by the editor's markDirty()).
    static func setDirty(_ on: Bool) { dirty = on }

    /// Wrap a long main-thread-quiet operation: VDB import, export, share.
    static func runGuarded<T>(_ label: String, _ body: () throws -> T) rethrows -> T {
        lock.lock(); guarded += 1; if guardLabel.isEmpty { guardLabel = label }; lock.unlock()
        defer { lock.lock(); guarded -= 1; if guarded <= 0 { guarded = 0; guardLabel = "" }; lock.unlock() }
        return try body()
    }

    // MARK: watchdog thread -------------------------------------------------

    private static func run() {
        var lastBeat: Int64 = heartbeat
        var lastDirty = false
        var stuck = 0
        var quietTicksWhileClean = 0
        while true {
            Thread.sleep(forTimeInterval: checkInterval)

            // The app can background at any moment: a backgrounded app's main
            // thread is paused by the OS, not frozen. After ~3 quiet checks
            // with no dirty work we simply stop counting — a fresh edit or
            // frame resets everything.
            let beatNow = heartbeat
            let dirtyNow = dirty
            let changed = beatNow != lastBeat

            if changed {
                stuck = 0
                quietTicksWhileClean = 0
            } else if dirtyNow {
                stuck += 1
                if stuck >= stuckChecksNeeded {
                    let detail = "main thread static for \(stuck * Int(checkInterval))s with unsaved work" +
                                 (guarded > 0 ? " (in \(guardLabel))" : "")
                    ccrash_set_watchdog(1, detail)
                    CrashLog.note("freeze")
                    ccrash_report_freeze(detail)
                    abort()          // deliberate: never stay wedged (R15/R19)
                }
            } else {
                // Quiet and clean: normal idle on a menu.
                quietTicksWhileClean += 1
                stuck = 0
                _ = lastDirty
            }
            lastBeat = beatNow
            lastDirty = dirtyNow
        }
    }
}
