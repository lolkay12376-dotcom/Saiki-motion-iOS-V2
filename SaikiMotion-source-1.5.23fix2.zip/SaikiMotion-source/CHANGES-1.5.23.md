# CHANGES-1.5.23.md — the 19 binary rounds, mapped into source

How to read this: every fix from the patched binaries (1.5.8 → 1.5.23) is
either **ported** (now real Swift/C in this tree), **inapplicable** (the bug
was an artifact of binary patching and cannot exist in source), or
**pending** (it lives in files still missing — see MISSING-SOURCE.md).

## Ported into this tree ✅

| Round | Fix | Where now |
|---|---|---|
| R11/R14/R19 | Autosave that never blocks: dirty-flag on every edit, save after ~10 s idle on the main thread, re-entry guard, explicit save paths untouched | `EditorViewController.markDirty()/maybeIdleSave()` |
| R19 | No Swift from signal context — crash signals go to a C logger that writes signal, fault address, all registers (ucontext), an action ring, watchdog state to `Documents/Crash`, then re-raises so iOS still writes its .ips | `Sources/CCrashLog/*`, `CrashLog.swift` |
| R15/R19 | Freeze watchdog with the corrected liveness rule (heartbeat must CHANGE; the round-14 "poke answered = alive" bug is structurally gone); freeze declared only with unsaved work in flight; guarded long ops (VDB import); never on idle/background; log + deliberate abort instead of staying wedged | `FreezeWatchdog.swift`, `beat()` in `render()/doFrame()` |
| R12/R14/R17 | Video import: retry across the item's registered type identifiers (the `public.movie` failure), all ownership under ARC (the round-17 unretained-pointer crash class cannot exist), sandbox copy before the URL expires, still-image fallback | `EditorViewController.loadVideo()/importPickedVideo()` |
| R11 | Video length fallback via `AVURLAsset` duration when metadata is missing | already present in the port (`addMedia` path) |
| R19 | Four languages (EN/ES/ID/JA), persisted choice, immediate relabel | `Localization.swift` (L10n) |
| R19 | Crash-folder count for the Extras tab + version display | `CrashLog.reportCount()`, `AppInfo` |
| R18 | Version identity: both `CFBundleShortVersionString` (1.5.23) and `CFBundleVersion` (23) bump every build, single source of truth | `Info.plist`, `AppInfo.swift` |
| R3 | Blosc VDB decoder + R3 Alembic transcoder sources preserved | `native/blosc/`, `native/abc2glb.c` |

## Inapplicable in source — the bug class is deleted ⛔

| Round | Was | Why it cannot come back |
|---|---|---|
| R10 | tagged-CGColor crash, wrong blend mode, CGRect HFA ABI bug in clear caves | those caves were hand-written assembly; the source clears views with normal UIKit calls |
| R13 | stale x0 vs Swift `self` in x20 passed to objc_msgSend | in Swift the compiler passes `self`; there is no register to get wrong |
| R14 | four absolute link-time addresses (`mov/movk`) unmapped under ASLR | Swift codegen is position-independent; the round-5/18 crash class is gone |
| R16 | the Cycles per-frame readback/copy/12 MB-write cache addon | never ported — its design is deleted (documented in BUILD.md §4) |
| R17 | second memory corruption: `.abc` button writing through a stray register | normal Swift call sites |
| R19 §2 | lineage bug (round 16 rebuilt on round 14, silently dropping round 15) | source tree has no lineage — git history is the lineage |
| all rounds | CODESIGNING "Invalid Page" kills (the current crash) | a clean build signs every page it contains; there is no third party mutating bytes afterwards |

## Pending — needs the missing files 🕐

| Round | Fix | Blocked on |
|---|---|---|
| R3/R4 | `.abc` import + GLB import-time normalization | `GlbModel` (wire `native/abc2glb.c`) |
| R12/R15 | VDB Blosc chunks + `ScaleTranslateMap` 4×4 matrix + bigger Blosc decode window | `VdbVolume` (wire `native/blosc/`) |
| R3 | water export crash: mesh cache keyed by owning EAGLContext | `WaterAssets`/`Exporter` |
| R3 | realistic water shaders (6 Gerstner octaves, dispersion, Jacobian foam — validated GLSL in the round-3 notes) | shader sources live in the binary; re-extract when the engine lands |
| R14 | grid erasure fix, particles/flare/camera as 3D layers, VDB density boost | `SceneRenderer` |
| R4 | Scene Setup (joystick, grid, 3D-only, export-safe camera) | editor-side present in spirit; overlay pieces missing |
| R19 | menu bar, Settings tab, tab contents on the home screen | `HomeViewController` — full spec is in the placeholder file header |

## What the source gives us that the binary never could

- deterministic builds from one command (`xtool build`) — no lineage bugs
- the entire "unrelocated pointer" class eliminated by construction
- readable diff between releases (this file + git log)
- the crash logger, watchdog and autosave cooperate: a crash mid-edit loses
  at most ~10 s of work, and every crash leaves a report in Documents/Crash
