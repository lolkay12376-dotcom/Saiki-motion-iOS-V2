# CHANGES — 1.5.23fix1 (build 24)

First build of the recovered source that compiles clean. The v1.5.23 source
zip failed at the Swift compile step on CI; this is the fix.

## Fixed

1. **CrashLog.swift — Swift compile error (the build killer).**
   `install()` and `note()` wrapped `String.utf8CString` in
   `withUnsafeBufferPointer` and passed the resulting
   `UnsafePointer<UInt8>` to C functions imported as
   `UnsafePointer<CChar>` (Int8). UInt8 ≠ Int8, so both call sites were
   type errors:
   *"cannot convert value of type 'UnsafePointer<UInt8>' to expected
   argument type 'UnsafePointer<CChar>'"*.
   Now the Swift `String` is passed directly — Swift bridges it to
   `const char *` for the duration of each call.

2. **CCrashLog.c:71 — arm64 register dump was reading the wrong memory.**
   On Darwin arm64, `ucontext_t.uc_mcontext` is already a pointer
   (`mcontext64_t`), so the old `_STRUCT_MCONTEXT64 *m = &uc->uc_mcontext;`
   created a pointer-to-pointer. Every crash report would have printed the
   pointer's own bytes as the register values. Fixed by dropping the `&`.
   (This was the warning in the 1.5.23 CI log; it is a real bug, not noise.)

## Version

- `CFBundleShortVersionString`: 1.5.23 → **1.5.23fix1**
- `CFBundleVersion`: 23 → **24** (round-18 rule: both keys change on every
  build so LiveContainer can tell builds apart)
- `AppInfo.version` / `AppInfo.build` kept in lockstep.

## Not changed

- No behavior changes; the freeze watchdog, crash-handler design, and the
  19-round lessons encoded in the code are untouched.
- `project.yml` / `Package.swift` layouts unchanged (versions live in
  Info.plist + AppInfo.swift only).
