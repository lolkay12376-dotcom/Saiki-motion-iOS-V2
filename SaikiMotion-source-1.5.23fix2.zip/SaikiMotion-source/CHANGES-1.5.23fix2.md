# CHANGES — 1.5.23fix2 (build 25)

Second compile fix on the recovered source. The fix1 build got one step
further on CI (the two `UnsafePointer<UInt8>` vs `UnsafePointer<CChar>`
errors from 1.5.23 are gone — that proves the fix1 zip was picked up) and
then hit the next latent error, previously hidden behind the ones we
already fixed.

## Fixed

1. **CrashLog.swift:30 — "a C function pointer cannot be formed from a
   closure that captures context" (the v6 build killer).**
   `NSSetUncaughtExceptionHandler` takes a plain C function pointer
   (`void (*)(NSException *)`). The closure we passed mentioned `note(...)`
   and `crashDir()` from the enclosing `CrashLog` enum, which counts as
   capturing context — C function pointers must be context-free.
   Fix: the handler is now a **top-level function**
   (`saikiUncaughtExceptionHandler`), which has no enclosing context and
   therefore always converts. It calls back into the enum with
   fully-qualified static calls (`CrashLog.note`, `CrashLog.crashDir`) —
   same behavior, compilable shape. This was the ONLY remaining
   closure-to-C-pointer site in the whole compile set (grep-verified).

## Version

- `CFBundleShortVersionString`: 1.5.23fix1 → **1.5.23fix2**
- `CFBundleVersion`: 24 → **25** (round-18 rule: both keys change on every
  build so LiveContainer can tell builds apart)
- `AppInfo.version` / `AppInfo.build` kept in lockstep.

## Workflow (v6 → v7) — robustness fix, found by testing

- **Why:** the v6 pick rule (`sort | tail -n 1`) is case-sensitive. A stale
  lowercase-named zip (e.g. `saiki motion.zip`) sorts AFTER
  `SaikiMotion-source-1.5.23fix2.zip` and would silently win the pick.
- v7 ranks candidates by the **version token in the name**
  (`1.5.23fix2 > 1.5.23fix1 > 1.5.23 > no version`), numbers zero-padded
  (`1.5.10` beats `1.5.9`), ties broken by name. Verified against 7
  scenarios, including spaces, all-caps, and mixed case.
- New optional override: run the workflow manually (Actions →
  "Run workflow") and fill **zip_name** to build one exact zip.
  Leave empty for auto-pick; push runs always auto-pick.
- `project.yml`: unchanged.

## Not changed

- No behavior changes in the app; the exception log still lands in
  `<Documents>/Crash/latest_exception.log`.
