# MISSING-SOURCE.md — the honest gap list

The recovered snapshot (2026-10-19, `SaikiMotion-fixsc.zip`) contains
**3 of ~15 source files**: the editor, the SDK IDE and the UI kit — about
6,600 lines. It is a Kotlin→Swift port in good shape: correct `[weak self]`
capture, main-thread dispatch, sandbox copies, ARC throughout.

Everything below is **referenced but absent**. Each entry lists what the
19 rounds of binary analysis tell us it must contain, so the file can be
hunted for (check old backups, git remotes, cloud drives — the zip's date
suggests more files existed) or rewritten later.

## Model / persistence
| File / type | Evidence | Contents |
|---|---|---|
| `Projects` | editor ×8 | project list, `Projects.load(id:)`, `Projects.save(id, project)` (called from autosave), `Projects.mediaDir()` |
| `ProjectIO` | editor | `copyMediaIntoSandbox(url:kind:)`, project export location |
| `Store` | editor | `Store.toJson(project)` / `Store.fromJson(JObj)` — undo snapshots |
| `JObj` | editor, IDE | JSON object wrapper: `getString`, `toString`, init from string |
| `Layer`, `PropDef`, `Key` | editor | layer model: id, name, type (.MODEL/.CAMERA/.AUDIO…), parentId, props/tracks/keys, fontPath, srcDur, start/end, mblur, is3d |
| `Editor` | editor | static state: project, sceneIndex, time, scene (duration, markers, layers) |
| `Registry` | editor | effect registry: `initialize()`, `addCustom(json)`, `savePreset` |

## Effects engine
| File / type | Evidence | Contents |
|---|---|---|
| `Effects`, `Effect`, `EffectDef` | editor ×30 | effect definitions + instancing, 35 keyframable water params (round-3 notes) |
| `EffectThumbs` | editor | `generate(host, preview, completion)` — effect thumbnails |
| `MediaStore`, `Media`, `MediaPlayer`, `MediaMetadataRetriever` | editor | media assets, import bookkeeping |

## UI (beyond Ui.swift)
| File / type | Evidence | Contents |
|---|---|---|
| `TimelineView` | editor | timeline strip; `TimelineHost` protocol; `timecode()` |
| `PreviewView`, `OverlayView` | editor | GL viewport (`requestDraw`, `releaseVideos`) + overlay |
| `AspectLayout`, `RootLayout` | editor | weighted layout system |
| `Snack` / `Dlg` | editor, IDE | toast + dialog helpers |
| `HomeViewController` | R19 spec | see `Sources/App/HomeViewController.placeholder.swift` header for the full spec: menu bar (Account/Projects/AI/Community/Extras/Settings), Settings language picker (EN/ES/ID/JA via `L10n`), Extras crash count (`CrashLog.reportCount()`), Account version (`AppInfo.displayVersion`) |

## 3D engine (hardest to recover)
| File / type | Evidence (round notes) | Contents |
|---|---|---|
| `SceneRenderer` | R12/R14 | draw loop, `drawVolume`, grid, particles; keep it **free of** per-frame readbacks (R16) |
| `GlbModel` | R3/R4 | `.validate(path:)` → must run the `native/abc2glb.c` transcoder for `.abc`, then the **import-time normalization** (recentre + rescale to max 1.4 units, idempotent) from R4 |
| `VdbVolume` | R12/R15 | OpenVDB parser: must accept Blosc chunks (decoder in `native/blosc/`), must read `ScaleTranslateMap` as a full 4×4 double matrix (R15), no default-write gates |
| `WaterAssets` | R3 | mesh cache keyed by **owning EAGLContext** (the static-cache export crash), rebuild on context change |
| `Exporter` | R3 | renders through a second EAGLContext — that's why the context-keyed caches exist |
| `XfO` | R4 notes | camera/view-projection defaults (unit frustum) |

## C decoders (already in this repo, `native/`)
- `native/blosc/` — c-blosc 1.21.5 decompression path, verified against
  OpenVDB v10's `bloscToStream` (round 12). Wire into `VdbVolume`.
- `native/abc2glb.c` — Alembic/Ogawa → glTF transcoder (round 3). Wire into
  `GlbModel.validate`.

When the engine files land, move these under `Sources/` as a C target the
same way `CCrashLog` is wired, and call them from Swift directly.
