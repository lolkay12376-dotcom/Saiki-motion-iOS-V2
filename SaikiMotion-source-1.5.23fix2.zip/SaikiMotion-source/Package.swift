// swift-tools-version:5.9
// SaikiMotion — SwiftPM package built with xtool.
//
// ⚠️ STRUCTURE MATTERS (verified against xtool's PackLib source):
//   • xtool requires EXACTLY ONE .library product — it represents the app.
//     A .executableTarget product makes xtool's `selectLibrary` fail.
//   • `@main` works inside a library target because SwiftPM compiles
//     targets with -parse-as-library, which makes @main emit the entry
//     symbol. xtool links the library into the final executable.
//   • The library name becomes SaikiMotion.app / CFBundleExecutable.
//
// Build (verified commands):
//   xtool dev build --ipa     → ./xtool/SaikiMotion.ipa (unsigned)
//   Unsigned is correct for LiveContainer: LC signs the app on import
//   (the same workflow as every -unsigned.ipa we ever shipped).
//   (--sign exists but needs `xtool auth` + an Apple ID; not needed for LC.)

import PackageDescription

let package = Package(
    name: "SaikiMotion",
    platforms: [
        .iOS(.v16)          // deployment target = MinimumOSVersion of the app
    ],
    products: [
        // Exactly one library product — xtool wraps it into SaikiMotion.app.
        .library(
            name: "SaikiMotion",
            targets: ["SaikiMotion"]
        ),
    ],
    targets: [
        // Signal-safe crash logger (C). The one place C is mandatory:
        // signal handlers may not touch the Swift runtime.
        .target(
            name: "CCrashLog",
            path: "Sources/CCrashLog"
        ),
        // The app. UIKit + programmatic UI — no storyboards, no xibs.
        .target(
            name: "SaikiMotion",
            dependencies: ["CCrashLog"],
            path: "Sources",
            exclude: [
                "CCrashLog",                          // compiled by its own target above
                "App/EditorViewController.swift",     // ← REMOVE these three exclusions
                "App/SdkIdeViewController.swift",     //   when the missing types are
                "UI/Ui.swift",                        //   recovered (MISSING-SOURCE.md)
            ]
        ),
    ]
)

// NOTE ON THE `exclude` LIST
// --------------------------
// EditorViewController.swift / SdkIdeViewController.swift / Ui.swift reference
// types that are not in this repo yet (Projects, Registry, Layer, …). They are
// excluded so the toolchain smoke-test build compiles with just the placeholder
// home screen. As each missing file is recovered:
//   1. drop it into Sources/…,
//   2. delete its line from `exclude`,
// and the real screens light up. When everything is present, delete the whole
// `exclude` array — but KEEP the "CCrashLog" exclusion (it is a separate target).
