// HomeViewController.placeholder.swift
//
// ⚠️ DELETE THIS FILE when the real HomeViewController.swift is recovered.
//
// Why it exists: the recovered source snapshot (2026-10-19) contains the
// editor, the UI kit and the SDK IDE — but NOT the home screen. This
// placeholder lets the package build and run end-to-end (toolchain smoke
// test) and shows what is still missing, so nobody mistakes a partial build
// for the finished app.
//
// The REAL HomeViewController (per the round-19 spec) must provide:
//   • project list + create/open/delete (Projects model)
//   • bottom menu bar: Account, Projects, AI, Community, Extras, Settings —
//     pinned to the safe area, equal width, localized via L10n.tr()
//   • Settings tab with the language picker (EN/ES/ID/JA, L10n.current)
//   • Extras tab: CrashLog.reportCount() + "in the Crash folder of this app"
//   • Account tab: AppInfo.displayVersion + "Offline notice"
//   • Community tab: the five bundled example effects
//   • opens EditorViewController(projectId:) for each project

import UIKit

final class HomeViewController: UIViewController {

    private let missing: [(String, String)] = [
        ("HomeViewController.swift", "this placeholder stands in for it"),
        ("Projects / ProjectIO / Store / JObj", "project model, persistence, JSON"),
        ("Registry / Effects / Effect / EffectDef / EffectThumbs", "effects engine + thumbnails"),
        ("MediaStore / Media / MediaPlayer", "media layer"),
        ("TimelineView", "timeline strip (TimelineHost protocol is in the editor)"),
        ("PreviewView / OverlayView / AspectLayout / RootLayout", "viewport + custom layout"),
        ("SceneRenderer / GlbModel / VdbVolume / WaterAssets / Exporter / XfO", "3D engine (see native/ for the C decoders)"),
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        title = "SaikiMotion \(AppInfo.displayVersion) — source incomplete"

        let tv = UITextView()
        tv.isEditable = false
        tv.font = .monospacedSystemFont(ofSize: 12, weight: .regular)
        tv.text = ("Toolchain smoke test: OK.\n\n"
                   + "The editor, UI kit and SDK IDE are present.\n"
                   + "Still missing (drop the files into Sources/… and delete this placeholder):\n\n"
                   + missing.map { "  • \($0.0) — \($0.1)" }.joined(separator: "\n")
                   + "\n\nSee MISSING-SOURCE.md in the repo root.\n")
        tv.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(tv)
        NSLayoutConstraint.activate([
            tv.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            tv.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            tv.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            tv.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
        ])
    }
}
