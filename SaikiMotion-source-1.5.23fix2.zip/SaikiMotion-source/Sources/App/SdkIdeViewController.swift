// iOS port of SdkIdeActivity.kt — SaikiMotion
// Full-screen effect SDK IDE: file explorer, tabbed code editor with GLSL/JSON syntax
// highlighting, live preview card, Run (compile + render) and a problems list.
//
// PORT NOTES:
//  - EditText + Spannable syntax colors → UITextView whose attributedText is rebuilt on a
//    180 ms debounce (typing stays responsive; caret moves to the end of the edit).
//  - The Android drawer (explorer panel) is a slide-in overlay on compact widths and a
//    permanent column on iPad-width layouts.
//  - "asset:" sources are read-only views into the app bundle; user files live under
//    App Support/SaikiMotion/sdk (Registry.sdkRoot()).

import UIKit
import Foundation

// MARK: - Syntax highlighting

enum Hl {
    static let rxNumber = try! NSRegularExpression(pattern: "\\b\\d+(\\.\\d+)?([eE][+-]?\\d+)?\\b")
    static let rxKeyword = try! NSRegularExpression(pattern: "\\b(float|int|bool|void|vec2|vec3|vec4|mat2|mat3|mat4|if|else|for|while|return|break|continue|discard|const|uniform|varying|in|out|inout|true|false|precision|highp|mediump|lowp|struct)\\b")
    static let rxBuiltin = try! NSRegularExpression(pattern: "\\b(sin|cos|tan|asin|acos|atan|pow|exp|log|sqrt|abs|sign|floor|ceil|fract|mod|min|max|clamp|mix|step|smoothstep|length|distance|dot|cross|normalize|reflect|texture2D|radians|degrees)\\b")
    static let rxSdk = try! NSRegularExpression(pattern: "\\b(effect|src|srcW|in0|in1|luma|hash11|hash21|vnoise|fbm|rot|hsv2rgb|unpremul|uTime|uRes|uHas0|uHas1)\\b")
    static let rxComment = try! NSRegularExpression(pattern: "//[^\\n]*|/\\*[\\s\\S]*?\\*/")
    static let rxJsonString = try! NSRegularExpression(pattern: "\"(\\\\.|[^\"\\\\])*\"")
    static let rxJsonKey = try! NSRegularExpression(pattern: "\"(\\\\.|[^\"\\\\])*\"(?=\\s*:)")
    static let rxJsonLit = try! NSRegularExpression(pattern: "\\b(true|false|null)\\b")

    static func paint(_ base: NSMutableAttributedString, _ rx: NSRegularExpression, _ hex: UInt32) {
        let s = base.string as NSString
        let whole = NSRange(location: 0, length: s.length)
        for m in rx.matches(in: base.string, range: whole) {
            base.addAttribute(.foregroundColor, value: UIColor(rgb: hex), range: m.range)
        }
    }
}

extension UIColor {
    convenience init(rgb: UInt32) {
        self.init(red: CGFloat((rgb >> 16) & 0xFF) / 255,
                  green: CGFloat((rgb >> 8) & 0xFF) / 255,
                  blue: CGFloat(rgb & 0xFF) / 255, alpha: 1)
    }
}

// MARK: - The IDE

final class SdkIdeViewController: UIViewController, UITextViewDelegate {
    var openPath: String? = nil
    var newEffect = false
    var onDone: (() -> Void)? = nil

    private final class OpenFile {
        let path: String
        let readOnly: Bool
        var text: String
        var saved: String
        var undoStack: [String] = []
        var redoStack: [String] = []
        var dirty: Bool { text != saved }
        init(_ path: String, _ readOnly: Bool, _ text: String) {
            self.path = path; self.readOnly = readOnly; self.text = text; self.saved = text
        }
    }
    private final class Problem {
        let line: Int?
        let text: String
        init(_ line: Int?, _ text: String) { self.line = line; self.text = text }
    }

    private var openFiles: [OpenFile] = []
    private var cur: OpenFile? = nil { didSet { updateTitle() } }
    private var problems: [Problem] = []
    private var loading = false
    private var changed = false

    private var editor: UITextView!
    private var banner: UILabel!
    private var titleView: UILabel!
    private var tabRow: UIStackView!
    private var tabsScroll: UIScrollView!
    private var problemsList: UIStackView!
    private var card: EffectCard!
    private var explorerBox: UIView!
    private var explorerCol: UIStackView!
    private var scrim: UIView!
    private var wide: Bool { view.bounds.width > 900 }
    private var previewOpen = false
    private var previewPane: UIStackView!

    private let mono = UIFont(name: "Menlo", size: 13) ?? UIFont.monospacedSystemFont(ofSize: 13, weight: .regular)
    private var hlWorkItem: DispatchWorkItem? = nil
    private var histWorkItem: DispatchWorkItem? = nil

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    // ---------------------------------------------------------------- lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = argbToUIColor(C.BG)
        buildUi()
        if newEffect {
            let f = Registry.newEffectFolder("My Effect")
            rebuildTree()
            openFile(f.appendingPathComponent("effect.glsl").path)
        } else if let p = openPath {
            rebuildTree()
            openFile(p)
        } else {
            rebuildTree()
            // Open the first user effect when nothing was requested.
            let users = openFiles
            if users.isEmpty {
                let f = Registry.sdkRoot()
                if let fs = try? FileManager.default.contentsOfDirectory(at: f, includingPropertiesForKeys: nil) {
                    for d in fs.sorted(by: { $0.lastPathComponent < $1.lastPathComponent }) {
                        let j = d.appendingPathComponent("effect.json")
                        if FileManager.default.fileExists(atPath: j.path) { openFile(j.path); break }
                    }
                }
            }
        }
        loadCurrentIntoEditor()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        saveAll()
        onDone?()
    }

    // ---------------------------------------------------------------- UI

    private var editorToMid: NSLayoutConstraint? = nil
    private var editorToPreview: NSLayoutConstraint? = nil

    private func buildUi() {
        view.backgroundColor = argbToUIColor(C.BG)

        // top bar
        let bar = buildTopBar()

        // explorer column
        explorerBox = UIView()
        explorerBox.backgroundColor = argbToUIColor(Int32(bitPattern: 0xFF141419))
        let exScroll = CapScroll()
        explorerCol = vStackI()
        explorerCol.isLayoutMarginsRelativeArrangement = true
        explorerCol.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 4, leading: 4, bottom: 12, trailing: 4)
        exScroll.addSubview(explorerCol)
        explorerCol.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            explorerCol.topAnchor.constraint(equalTo: exScroll.contentLayoutGuide.topAnchor),
            explorerCol.bottomAnchor.constraint(equalTo: exScroll.contentLayoutGuide.bottomAnchor),
            explorerCol.leadingAnchor.constraint(equalTo: exScroll.contentLayoutGuide.leadingAnchor),
            explorerCol.trailingAnchor.constraint(equalTo: exScroll.contentLayoutGuide.trailingAnchor),
            explorerCol.widthAnchor.constraint(equalTo: exScroll.frameLayoutGuide.widthAnchor)
        ])
        explorerBox.addSubview(exScroll)
        exScroll.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            exScroll.topAnchor.constraint(equalTo: explorerBox.topAnchor),
            exScroll.bottomAnchor.constraint(equalTo: explorerBox.bottomAnchor),
            exScroll.leadingAnchor.constraint(equalTo: explorerBox.leadingAnchor),
            exScroll.trailingAnchor.constraint(equalTo: explorerBox.trailingAnchor)
        ])

        // scrim for the compact drawer
        scrim = UIView()
        scrim.backgroundColor = UIColor(white: 0, alpha: 0.5)
        scrim.isHidden = true
        scrim.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(closeDrawer)))

        // editor column (stack): tabs, banner, editor, symbol bar, problems
        let editorCol = vStackI()
        tabsScroll = UIScrollView()
        tabsScroll.showsHorizontalScrollIndicator = false
        tabRow = hRowI()
        tabRow.spacing = 4
        tabsScroll.addSubview(tabRow)
        tabRow.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            tabRow.topAnchor.constraint(equalTo: tabsScroll.contentLayoutGuide.topAnchor),
            tabRow.bottomAnchor.constraint(equalTo: tabsScroll.contentLayoutGuide.bottomAnchor),
            tabRow.leadingAnchor.constraint(equalTo: tabsScroll.contentLayoutGuide.leadingAnchor),
            tabRow.trailingAnchor.constraint(equalTo: tabsScroll.contentLayoutGuide.trailingAnchor),
            tabRow.heightAnchor.constraint(equalTo: tabsScroll.frameLayoutGuide.heightAnchor)
        ])
        editorCol.addArrangedSubview(wrapI(tabsScroll, 0, 34, 0, 0, 0, 0))

        banner = UILabel()
        banner.text = "  Read-only: this effect ships inside the app."
        banner.textColor = argbToUIColor(C.AMBER)
        banner.font = sysFont(11)
        banner.backgroundColor = argbToUIColor(Int32(bitPattern: 0xFF26200E))
        banner.isHidden = true
        editorCol.addArrangedSubview(banner)

        editor = UITextView()
        editor.font = mono
        editor.textColor = argbToUIColor(Int32(bitPattern: 0xFFE6E6E6))
        editor.backgroundColor = argbToUIColor(Int32(bitPattern: 0xFF111116))
        editor.tintColor = argbToUIColor(C.GREEN)
        editor.delegate = self
        editor.autocorrectionType = .no
        editor.autocapitalizationType = .none
        editor.spellCheckingType = .no
        editor.layer.cornerRadius = 10
        editor.textContainerInset = UIEdgeInsets(top: 10, left: 8, bottom: 10, right: 8)
        editorCol.addArrangedSubview(editor)

        editorCol.addArrangedSubview(buildSymbolBar())

        let probsScroll = CapScroll()
        problemsList = vStackI()
        problemsList.isLayoutMarginsRelativeArrangement = true
        problemsList.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 4, leading: 8, bottom: 8, trailing: 8)
        probsScroll.addSubview(problemsList)
        problemsList.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            problemsList.topAnchor.constraint(equalTo: probsScroll.contentLayoutGuide.topAnchor),
            problemsList.bottomAnchor.constraint(equalTo: probsScroll.contentLayoutGuide.bottomAnchor),
            problemsList.leadingAnchor.constraint(equalTo: probsScroll.contentLayoutGuide.leadingAnchor),
            problemsList.trailingAnchor.constraint(equalTo: probsScroll.contentLayoutGuide.trailingAnchor),
            problemsList.widthAnchor.constraint(equalTo: probsScroll.frameLayoutGuide.widthAnchor)
        ])
        probsScroll.heightAnchor.constraint(equalToConstant: 110).isActive = true
        editorCol.addArrangedSubview(probsScroll)

        // preview pane
        previewPane = vStackI()
        previewPane.backgroundColor = argbToUIColor(Int32(bitPattern: 0xFF141419))
        previewPane.isHidden = true
        let pvHead = UILabel()
        pvHead.text = "  Preview"
        pvHead.textColor = argbToUIColor(C.TEXT)
        pvHead.font = boldFont(14)
        previewPane.addArrangedSubview(pvHead)
        card = EffectCard("", "")
        card.thumbHeight = 0.75
        previewPane.addArrangedSubview(card)

        // root: top bar + horizontal split
        let root = vStackI()
        root.addArrangedSubview(bar)
        let mid = UIView()
        root.addArrangedSubview(mid)

        [explorerBox, editorCol, previewPane].forEach {
            mid.addSubview($0)
            $0.translatesAutoresizingMaskIntoConstraints = false
        }
        let midConstraints = [
            explorerBox.leadingAnchor.constraint(equalTo: mid.leadingAnchor),
            explorerBox.topAnchor.constraint(equalTo: mid.topAnchor),
            explorerBox.bottomAnchor.constraint(equalTo: mid.bottomAnchor),
            explorerBox.widthAnchor.constraint(equalToConstant: 250),
            editorCol.leadingAnchor.constraint(equalTo: explorerBox.trailingAnchor),
            editorCol.topAnchor.constraint(equalTo: mid.topAnchor),
            editorCol.bottomAnchor.constraint(equalTo: mid.bottomAnchor),
            previewPane.trailingAnchor.constraint(equalTo: mid.trailingAnchor),
            previewPane.topAnchor.constraint(equalTo: mid.topAnchor),
            previewPane.bottomAnchor.constraint(equalTo: mid.bottomAnchor),
            previewPane.widthAnchor.constraint(equalToConstant: 240)
        ]
        NSLayoutConstraint.activate(midConstraints)
        editorToMid = editorCol.trailingAnchor.constraint(equalTo: mid.trailingAnchor)
        editorToPreview = editorCol.trailingAnchor.constraint(equalTo: previewPane.leadingAnchor)
        editorToMid?.isActive = true

        view.addSubview(root)
        root.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            root.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            root.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            root.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            root.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])

        view.addSubview(scrim)
        scrim.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            scrim.topAnchor.constraint(equalTo: view.topAnchor),
            scrim.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            scrim.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrim.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])

        applyLayoutForWidth()
        showProblems()
    }

    private func applyLayoutForWidth() {
        if wide {
            explorerBox.isHidden = false
            scrim.isHidden = true
        } else {
            explorerBox.isHidden = true
        }
    }

    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        coordinator.animate(alongsideTransition: nil) { [weak self] _ in
            self?.applyLayoutForWidth()
        }
    }

    private func buildTopBar() -> UIView {
        let bar = hRowI()
        bar.isLayoutMarginsRelativeArrangement = true
        bar.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 4, bottom: 0, trailing: 8)
        bar.backgroundColor = argbToUIColor(C.PANEL)
        let back = IconView("back", C.AMBER)
        back.onClick = { [weak self] in self?.dismiss(animated: true) }
        bar.addArrangedSubview(wrapI(back, 40, 48, 0, 0, 0, 0))
        let burger = IconView("layers", C.TEXT)
        burger.onClick = { [weak self] in self?.openDrawer() }
        bar.addArrangedSubview(wrapI(burger, 40, 48, 0, 0, 0, 0))
        titleView = UILabel()
        titleView.textColor = argbToUIColor(C.TEXT)
        titleView.font = boldFont(15)
        titleView.numberOfLines = 1
        titleView.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
        bar.addArrangedSubview(titleView)
        bar.addArrangedSubview(spacerI())
        bar.addArrangedSubview(wrapI(pillBtn("New", "plus", C.GREEN, Int32(bitPattern: 0xFF2B1400)) { [weak self] in self?.newFile() }, 84, 38, 0, 0, 6, 0))
        bar.addArrangedSubview(wrapI(pillBtn("Run", "play", C.GREEN, Int32(bitPattern: 0xFF2B1400)) { [weak self] in self?.run() }, 84, 38, 0, 0, 6, 0))
        bar.addArrangedSubview(wrapI(pillBtn("Save", "save") { [weak self] in self?.saveAll(); Snack.show("Saved") }, 84, 38, 0, 0, 6, 0))
        bar.addArrangedSubview(wrapI(pillBtn("?", nil) { [weak self] in self?.showReference() }, 44, 38, 0, 0, 6, 0))
        return bar
    }

    private func pillBtn(_ t: String, _ ic: String?, _ fill: Int32 = C.CARD2, _ tc: Int32 = C.TEXT, _ click: @escaping () -> Void) -> PillButton {
        let b = PillButton(t, ic, fill, tc)
        b.onClick = click
        return b
    }

    /// Quick-insert bar for GLSL building blocks.
    private func buildSymbolBar() -> UIView {
        let sv = UIScrollView()
        sv.showsHorizontalScrollIndicator = false
        sv.backgroundColor = argbToUIColor(C.PANEL)
        let row = hRowI()
        row.spacing = 4
        sv.addSubview(row)
        row.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            row.topAnchor.constraint(equalTo: sv.contentLayoutGuide.topAnchor),
            row.bottomAnchor.constraint(equalTo: sv.contentLayoutGuide.bottomAnchor),
            row.leadingAnchor.constraint(equalTo: sv.contentLayoutGuide.leadingAnchor),
            row.trailingAnchor.constraint(equalTo: sv.contentLayoutGuide.trailingAnchor),
            row.heightAnchor.constraint(equalTo: sv.frameLayoutGuide.heightAnchor)
        ])
        let keys: [(String, String)] = [
            ("src", "src(uv)"), ("srcW", "srcW(uv, 2.0)"), ("uTime", "uTime"), ("uRes", "uRes"),
            ("luma", "luma(c.rgb)"), ("hash", "hash21(p)"), ("fbm", "fbm(p)"), ("rot", "rot(p, a)"),
            ("vec2", "vec2(0.0)"), ("vec3", "vec3(0.0)"), ("vec4", "vec4(0.0)"), ("mix", "mix(a, b, t)"),
            ("clamp", "clamp(x, 0.0, 1.0)"), ("smoothstep", "smoothstep(0.0, 1.0, x)"), ("for", "for (int i = 0; i < 8; i++) { }")
        ]
        for (label, insert) in keys {
            let b = PillButton(label, nil, C.CARD2, C.TEXT)
            b.onClick = { [weak self] in self?.insertText(insert) }
            row.addArrangedSubview(wrapI(b, 0, 30, 4, 4, 4, 4))
        }
        return sv
    }

    // ---------------------------------------------------------------- explorer

    private func openDrawer() {
        guard !wide else { return }
        explorerBox.isHidden = false
        scrim.isHidden = false
    }

    @objc private func closeDrawer() {
        if !wide { explorerBox.isHidden = true; scrim.isHidden = true }
    }

    private func children(_ path: String) -> [URL] {
        var out: [URL] = []
        if path == "bundle:" {
            out.append(URL(fileURLWithPath: "bundle:sdk/examples/scan_wipe"))
            out.append(URL(fileURLWithPath: "bundle:sdk/examples/tint_pulse"))
            return out
        }
        let dir = URL(fileURLWithPath: path)
        guard let fs = try? FileManager.default.contentsOfDirectory(at: dir, includingPropertiesForKeys: nil) else { return [] }
        for f in fs.sorted(by: { $0.lastPathComponent < $1.lastPathComponent }) {
            out.append(f)
        }
        return out
    }

    private func rebuildTree() {
        explorerCol.arrangedSubviews.forEach { $0.removeFromSuperview() }
        let root = Registry.sdkRoot()
        let head = UILabel()
        head.text = "  SDK"
        head.textColor = argbToUIColor(C.DIM)
        head.font = boldFont(12)
        explorerCol.addArrangedSubview(head)
        addChildren(root.path, 0)
        let bHead = UILabel()
        bHead.text = "  Bundled examples (read-only)"
        bHead.textColor = argbToUIColor(C.DIM)
        bHead.font = boldFont(12)
        explorerCol.addArrangedSubview(bHead)
        for ex in ["scan_wipe", "tint_pulse"] {
            treeRow(0, "folder", C.TEXT, "bundle:sdk/examples/\(ex)")
        }
    }

    private func addChildren(_ path: String, _ depth: Int) {
        for c in children(path) {
            var isDir: ObjCBool = false
            FileManager.default.fileExists(atPath: c.path, isDirectory: &isDir)
            let icon = isDir.boolValue ? "folder" : "file"
            treeRow(depth, icon, C.TEXT, c.path)
        }
    }

    private func treeRow(_ depth: Int, _ icon: String, _ tint: Int32, _ path: String) {
        let row = hRowI()
        row.isLayoutMarginsRelativeArrangement = true
        row.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: CGFloat(8 + depth * 14), bottom: 0, trailing: 4)
        let iv = IconView(icon, tint, 18)
        row.addArrangedSubview(wrapI(iv, 22, 34, 0, 0, 4, 0))
        let tv = UILabel()
        let name = URL(fileURLWithPath: path).lastPathComponent
        tv.text = name
        tv.textColor = argbToUIColor(C.TEXT)
        tv.font = sysFont(13)
        tv.numberOfLines = 1
        tv.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
        row.addArrangedSubview(tv)
        let tap = TapView()
        tap.addSubview(row)
        row.frame = .zero
        tap.onClick = { [weak self] in
            self?.onNodeTap(path)
            self?.closeDrawer()
        }
        explorerCol.addArrangedSubview(tap)
    }

    private func onNodeTap(_ path: String) {
        var isDir: ObjCBool = false
        let real = path.hasPrefix("bundle:") ? pathFromBundle(path) : path
        if FileManager.default.fileExists(atPath: real, isDirectory: &isDir), isDir.boolValue { return }
        openFile(path)
    }

    private func pathFromBundle(_ p: String) -> String {
        // "bundle:sdk/examples/x/effect.json" → real bundle URL path or "".
        let rel = String(p.dropFirst("bundle:".count))
        let parts = rel.split(separator: "/").map(String.init)
        guard parts.count >= 3 else { return p }
        let file = parts.last!
        let dir = parts.dropLast().joined(separator: "/")
        if let u = Bundle.main.url(forResource: (file as NSString).deletingPathExtension,
                                   withExtension: (file as NSString).pathExtension, subdirectory: dir) {
            return u.path
        }
        return p
    }

    // ---------------------------------------------------------------- files + tabs

    private func openFile(_ path0: String) {
        var path = path0
        if path.hasPrefix("bundle:") { path = pathFromBundle(path) }
        let readOnly = path0.hasPrefix("bundle:") || path.contains(".app/sdk/") || !path.hasPrefix(Registry.sdkRoot().path)
        if let ex = openFiles.first(where: { $0.path == path0 }) {
            cur = ex
            rebuildTabs()
            loadCurrentIntoEditor()
            return
        }
        guard let txt = try? String(contentsOfFile: path, encoding: .utf8) else {
            Snack.show("Could not open " + URL(fileURLWithPath: path).lastPathComponent)
            return
        }
        let f = OpenFile(path0, readOnly, txt)
        openFiles.append(f)
        cur = f
        rebuildTabs()
        loadCurrentIntoEditor()
    }

    private func rebuildTabs() {
        tabRow.arrangedSubviews.forEach { $0.removeFromSuperview() }
        for f in openFiles {
            let on = f === cur
            let name = URL(fileURLWithPath: f.path.hasPrefix("bundle:") ? String(f.path.dropFirst(7)) : f.path).lastPathComponent
            let b = PillButton(name + (f.dirty ? " *" : ""), nil, on ? C.GREEN : C.CARD2, on ? Int32(bitPattern: 0xFF2B1400) : C.TEXT)
            b.onClick = { [weak self] in
                guard let self = self else { return }
                if self.cur === f { self.closeTab(f) } else {
                    self.saveCurrentText()
                    self.cur = f
                    self.loadCurrentIntoEditor()
                    self.rebuildTabs()
                }
            }
            tabRow.addArrangedSubview(wrapI(b, 0, 28, 4, 3, 4, 3))
        }
    }

    private func closeTab(_ f: OpenFile) {
        saveCurrentText()
        let i = openFiles.firstIndex(where: { $0 === f }) ?? 0
        openFiles.removeAll { $0 === f }
        if cur === f { cur = openFiles.indices.contains(min(i, openFiles.count - 1)) ? openFiles[min(i, openFiles.count - 1)] : nil }
        rebuildTabs()
        loadCurrentIntoEditor()
    }

    private func loadCurrentIntoEditor() {
        loading = true
        if let f = cur {
            banner.isHidden = !f.readOnly
            editor.isEditable = !f.readOnly
            editor.text = f.text
        } else {
            editor.text = ""
            editor.isEditable = false
            banner.isHidden = true
        }
        loading = false
        highlight()
        updateTitle()
    }

    private func updateTitle() {
        guard titleView != nil else { return }
        guard let f = cur else { titleView.text = "Effect Editor"; return }
        let p = f.path.hasPrefix("bundle:") ? String(f.path.dropFirst(7)) : f.path
        let parts = p.split(separator: "/").map(String.init)
        titleView.text = parts.count >= 2 ? parts[parts.count - 2] + " / " + parts.last! : (parts.last ?? "")
    }

    // ---------------------------------------------------------------- editing

    func textViewDidChange(_ t: UITextView) {
        guard !loading, let f = cur else { return }
        f.text = t.text
        scheduleHighlight()
        scheduleHistory()
        rebuildTabs()
    }

    private func insertText(_ text: String) {
        guard let f = cur, !f.readOnly else { return }
        let r = editor.selectedRange
        let s = editor.text as NSString
        let newText = s.replacingCharacters(in: r, with: text)
        editor.text = newText
        f.text = newText
        let caret = r.location + (text as NSString).length
        editor.selectedRange = NSRange(location: caret, length: 0)
        scheduleHighlight()
        rebuildTabs()
    }

    private func scheduleHighlight() {
        hlWorkItem?.cancel()
        let item = DispatchWorkItem { [weak self] in self?.highlight() }
        hlWorkItem = item
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.18, execute: item)
    }

    private func scheduleHistory() {
        histWorkItem?.cancel()
        let item = DispatchWorkItem { [weak self] in
            guard let self = self, let f = self.cur else { return }
            if f.undoStack.isEmpty || f.undoStack.last != f.text {
                f.undoStack.append(f.text)
                if f.undoStack.count > 100 { f.undoStack.removeFirst() }
                f.redoStack.removeAll()
            }
        }
        histWorkItem = item
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: item)
    }

    private func highlight() {
        guard let f = cur else { return }
        let base = NSMutableAttributedString(string: f.text, attributes: [
            .font: mono,
            .foregroundColor: argbToUIColor(Int32(bitPattern: 0xFFE6E6E6))
        ])
        if f.text.count < 60000 {
            let ext = (URL(fileURLWithPath: f.path).pathExtension).lowercased()
            if ext == "json" {
                Hl.paint(base, Hl.rxNumber, 0xF5B301)
                Hl.paint(base, Hl.rxJsonLit, 0xFF79C6)
                Hl.paint(base, Hl.rxJsonString, 0x9AE59A)
                Hl.paint(base, Hl.rxJsonKey, 0x7DD3FC)
            } else if ["glsl", "frag", "vert", "fsh"].contains(ext) {
                Hl.paint(base, Hl.rxNumber, 0xF5B301)
                Hl.paint(base, Hl.rxKeyword, 0xFF79C6)
                Hl.paint(base, Hl.rxBuiltin, 0x7DD3FC)
                Hl.paint(base, Hl.rxSdk, 0xFF8A1F)
                Hl.paint(base, Hl.rxComment, 0x6B8E6B)
            }
        }
        let sel = editor.selectedRange
        editor.attributedText = base
        editor.selectedRange = sel
    }

    // ---------------------------------------------------------------- save / new

    private func saveCurrentText() {
        if let f = cur, !loading { f.text = editor.text }
    }

    private func writeFile(_ f: OpenFile) {
        guard !f.readOnly else { return }
        let path = f.path.hasPrefix("bundle:") ? pathFromBundle(f.path) : f.path
        do {
            try f.text.data(using: .utf8)?.write(to: URL(fileURLWithPath: path), options: .atomic)
            f.saved = f.text
            changed = true
        } catch {
            Snack.show("Could not save " + URL(fileURLWithPath: path).lastPathComponent)
        }
    }

    private func saveAll() {
        saveCurrentText()
        for f in openFiles where f.dirty { writeFile(f) }
        rebuildTabs()
    }

    private func newFile() {
        let et = UITextField(frame: .zero)
        et.placeholder = "New effect name"
        _ = Dlg(self).setTitle("New effect").setView(et).setPositiveButton("Create") { [weak self] _, _ in
            guard let self = self else { return }
            let nm = (et.text ?? "").trimmingCharacters(in: .whitespaces)
            guard !nm.isEmpty else { return }
            let f = Registry.newEffectFolder(nm)
            self.rebuildTree()
            self.openFile(f.appendingPathComponent("effect.glsl").path)
        }.setNegativeButton("Cancel", nil).show()
    }

    // ---------------------------------------------------------------- run + problems

    private func effectFolderOf(_ path: String) -> String? {
        if path.hasPrefix("bundle:") { return path }
        var f: URL? = URL(fileURLWithPath: path).deletingLastPathComponent()
        let rootPath = Registry.sdkRoot().path
        while let cur = f, cur.path.hasPrefix(rootPath) {
            if FileManager.default.fileExists(atPath: cur.appendingPathComponent("effect.json").path) { return cur.path }
            f = cur.deletingLastPathComponent()
        }
        return nil
    }

    private func effectIdOf(_ folder: String) -> String? {
        let j = URL(fileURLWithPath: folder).appendingPathComponent("effect.json")
        if folder.hasPrefix("bundle:") {
            let real = pathFromBundle(folder + "/effect.json")
            guard let o = try? JObj(json: String(contentsOfFile: real, encoding: .utf8)) else { return nil }
            return o.optString("id", "").isEmpty ? nil : o.optString("id", "")
        }
        guard let o = try? JObj(json: String(contentsOfFile: j, encoding: .utf8)) else { return nil }
        return o.optString("id", "").isEmpty ? nil : o.optString("id", "")
    }

    private func run() {
        saveAll()
        Registry.reloadSdk()
        guard let f = cur else {
            problems = [Problem(nil, "Open a file from the explorer, or tap New.")]
            showProblems()
            return
        }
        let folder = effectFolderOf(f.path)
        let id = folder != nil ? effectIdOf(folder!) : nil
        for k in EffectThumbs.cache.keys where k == id || k.hasPrefix("__orig:custom:") {
            EffectThumbs.cache.removeValue(forKey: k)
        }
        let def = id != nil ? Registry.byId[id!] : nil
        if id == nil {
            problems = [Problem(nil, folder == nil ? "This file is not inside an effect folder (a folder with effect.json)." : "effect.json has no id.")]
            showProblems()
            return
        }
        if def == nil {
            let msg = Registry.sdkErrors[URL(fileURLWithPath: folder!).lastPathComponent] ?? "The effect could not be loaded."
            problems = [Problem(nil, "effect.json: " + msg)]
            showProblems()
            return
        }
        card.name = def!.name
        card.category = def!.category
        card.anim = def!.previewAnim
        card.thumbId = id!
        card.origId = EffectThumbs.origKey(id!)
        card.before = nil
        card.after = nil
        problems = []
        showProblems("Rendering...")
        previewOpen = true
        previewPane.isHidden = false
        editorToMid?.isActive = false
        editorToPreview?.isActive = true
        view.setNeedsLayout()
        card.setNeedsDisplay()
        EffectThumbs.generate { [weak self] in
            guard let self = self else { return }
            let d2 = Registry.byId[id!]
            self.card.before = EffectThumbs.cache[EffectThumbs.origKey(id!)]
            self.card.after = EffectThumbs.cache[id!]
            self.card.anim = d2?.previewAnim ?? "swipe"
            self.card.setNeedsDisplay()
            if let raw = Registry.errors[id!], let d2 = d2 {
                self.problems = self.parseErrors(raw, d2)
            } else {
                self.problems = []
            }
            self.showProblems()
        }
    }

    /// Turns a GLSL compiler log into tap-to-jump problems, offset by the prelude line count.
    private func parseErrors(_ raw: String, _ d: EffectDef) -> [Problem] {
        var out: [Problem] = []
        let off = Registry.codeLineOffset(d)
        for line in raw.split(separator: "\n") {
            guard let at = line.range(of: ":") else { continue }
            let head = String(line[line.startIndex..<at.lowerBound])
            let tail = String(line[at.upperBound...]).trimmingCharacters(in: .whitespaces)
            if let c1 = head.last, c1.isNumber, let c2 = head.dropLast().last, c2.isNumber {
                let lnum = Int(String(c2)) ?? 1
                out.append(Problem(lnum - off, "Line \(lnum - off): " + String(tail.prefix(120))))
            } else {
                out.append(Problem(nil, String(line.prefix(140))))
            }
            if out.count > 8 { break }
        }
        if out.isEmpty { out.append(Problem(nil, String(raw.prefix(140)))) }
        return out
    }

    private func showProblems(_ status: String? = nil) {
        problemsList.arrangedSubviews.forEach { $0.removeFromSuperview() }
        if let st = status {
            let l = UILabel()
            l.text = "  " + st
            l.textColor = argbToUIColor(C.DIM)
            l.font = sysFont(12)
            l.numberOfLines = 0
            problemsList.addArrangedSubview(l)
            return
        }
        if problems.isEmpty {
            let l = UILabel()
            l.text = "  No problems. Tap Run to compile and preview the effect."
            l.textColor = argbToUIColor(C.DIM)
            l.font = sysFont(12)
            l.numberOfLines = 0
            problemsList.addArrangedSubview(l)
            return
        }
        for pr in problems {
            let l = UILabel()
            l.text = (pr.line != nil ? "  Line \(pr.line!): " : "  ") + pr.text
            l.textColor = argbToUIColor(C.RED)
            l.font = mono.withSize(11)
            l.numberOfLines = 0
            problemsList.addArrangedSubview(l)
        }
    }

    private func showReference() {
        let msg = """
        vec4 effect(vec2 uv) runs once per pixel. uv goes 0..1 across the layer.

        Available: every param in effect.json (float, same name), every color (vec4),
        src(uv), srcW(uv, pad) - the layer pixel (premultiplied), in0(uv), in1(uv) - layer
        inputs, luma(rgb), hash11(x), hash21(vec2), vnoise(p), fbm(p), rot(p, angle),
        hsv2rgb(vec3), unpremul(c), uTime (seconds), uRes (pixels).

        Files: each effect folder holds effect.json (name, description, category, params,
        colors, inputs, preview) and effect.glsl (the code). User folders live in the SDK
        directory; the bundled examples are read-only.
        """
        _ = Dlg(self).setTitle("Effect SDK reference").setMessage(msg).setPositiveButton("Close", nil).show()
    }
}

// MARK: - private stack helpers (independent of the editor's helpers)

private func vStackI() -> UIStackView {
    let r = UIStackView()
    r.axis = .vertical
    r.spacing = 0
    r.alignment = .fill
    return r
}

private func hRowI() -> UIStackView {
    let r = UIStackView()
    r.axis = .horizontal
    r.alignment = .center
    r.spacing = 0
    return r
}

private func spacerI() -> UIView {
    let v = UIView()
    v.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
    return v
}

private func wrapI(_ v: UIView, _ w: CGFloat, _ h: CGFloat, _ l: CGFloat, _ t: CGFloat, _ r: CGFloat, _ b: CGFloat) -> UIView {
    let box = UIView()
    box.translatesAutoresizingMaskIntoConstraints = false
    v.translatesAutoresizingMaskIntoConstraints = false
    box.addSubview(v)
    NSLayoutConstraint.activate([
        v.topAnchor.constraint(equalTo: box.topAnchor, constant: t),
        v.bottomAnchor.constraint(equalTo: box.bottomAnchor, constant: -b),
        v.leadingAnchor.constraint(equalTo: box.leadingAnchor, constant: l),
        v.trailingAnchor.constraint(equalTo: box.trailingAnchor, constant: -r)
    ])
    if w > 0 { v.widthAnchor.constraint(equalToConstant: w).isActive = true }
    if h > 0 { v.heightAnchor.constraint(equalToConstant: h).isActive = true }
    return box
}
