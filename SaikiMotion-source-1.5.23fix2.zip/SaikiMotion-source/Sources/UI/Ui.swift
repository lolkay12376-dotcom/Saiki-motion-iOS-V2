// iOS port of Ui.kt — SaikiMotion
// Custom UI widgets: color constants, vector icons, icon/chip/pill/tool buttons,
// the scrolling RulerSlider, effect cards, bezier graph editor, switch rows,
// color picker, value graph and the Toast replacement.
//
// PORT NOTE (general): Android Paint/Canvas drawing is ported to draw(_:) + CGContext.
// The current context handed out by UIKit inside draw(_:) is top-left origin with y
// pointing down — identical to Android's Canvas — so all Kotlin coordinates carry over.
// "dp" values are used as points directly (PORTING_GUIDE rule 22).

import UIKit
import Foundation

// MARK: - Colors (object C)

/// Theme constants (ARGB Int32, Android bit layout).
enum C {
    static let BG = Int32(bitPattern: 0xFF0E0E10)
    static let PANEL = Int32(bitPattern: 0xFF111114)
    static let CARD = Int32(bitPattern: 0xFF1C1C21)
    static let CARD2 = Int32(bitPattern: 0xFF26262C)
    static let GREEN = Int32(bitPattern: 0xFFFF8A1F)
    static let AMBER = Int32(bitPattern: 0xFFF5B301)
    static let RED = Int32(bitPattern: 0xFFEF4444)
    static let BLUE = Int32(bitPattern: 0xFF38BDF8)
    static let TEXT = Int32(bitPattern: 0xFFFFFFFF)
    static let DIM = Int32(bitPattern: 0xFF8C8C96)
    static let LINE = Int32(bitPattern: 0xFF2A2A30)
}

// MARK: - Shared UIKit helpers (additions required by the Canvas/Paint port)

/// Key window of the app (iOS 15 scene API).
func appKeyWindow() -> UIWindow? {
    let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
    let windows = scenes.flatMap { $0.windows }
    return windows.first { $0.isKeyWindow } ?? windows.first
}

@inline(__always) func boldFont(_ size: CGFloat) -> UIFont { UIFont.boldSystemFont(ofSize: size) }
@inline(__always) func sysFont(_ size: CGFloat) -> UIFont { UIFont.systemFont(ofSize: size) }

/// Android Paint.measureText equivalent.
func measureText(_ s: String, _ size: CGFloat, _ bold: Bool = false) -> CGFloat {
    if s.isEmpty { return 0 }
    let attr = NSAttributedString(string: s, attributes: [
        .font: bold ? boldFont(size) : sysFont(size)
    ])
    return attr.size().width
}

/// Android Canvas.drawText equivalent: (x, y) is the text BASELINE, returns the text width.
/// `align` mirrors Paint.Align (left/center/right).
@discardableResult
func drawText(_ s: String, _ x: CGFloat, _ y: CGFloat, color: Int32,
              size: CGFloat, bold: Bool = false, align: NSTextAlignment = .left) -> CGFloat {
    if s.isEmpty { return 0 }
    let f = bold ? boldFont(size) : sysFont(size)
    let attr = NSAttributedString(string: s, attributes: [.font: f, .foregroundColor: argbToUIColor(color)])
    let w = attr.size().width
    var px = x
    if align == .center { px -= w / 2 } else if align == .right { px -= w }
    attr.draw(at: CGPoint(x: px, y: y - f.ascender))
    return w
}

func fillRoundRect(_ c: CGContext, _ r: CGRect, _ radius: CGFloat, _ color: Int32) {
    c.setFillColor(argbToUIColor(color).cgColor)
    c.addPath(CGPath(roundedRect: r, cornerWidth: radius, cornerHeight: radius, transform: nil))
    c.fillPath()
}

func strokeRoundRect(_ c: CGContext, _ r: CGRect, _ radius: CGFloat, _ width: CGFloat, _ color: Int32) {
    c.setStrokeColor(argbToUIColor(color).cgColor)
    c.setLineWidth(width)
    c.addPath(CGPath(roundedRect: r, cornerWidth: radius, cornerHeight: radius, transform: nil))
    c.strokePath()
}

func strokeLine(_ c: CGContext, _ x0: CGFloat, _ y0: CGFloat, _ x1: CGFloat, _ y1: CGFloat,
                _ width: CGFloat, _ color: Int32) {
    c.setStrokeColor(argbToUIColor(color).cgColor)
    c.setLineWidth(width)
    c.move(to: CGPoint(x: x0, y: y0))
    c.addLine(to: CGPoint(x: x1, y: y1))
    c.strokePath()
}

func fillCircle(_ c: CGContext, _ x: CGFloat, _ y: CGFloat, _ r: CGFloat, _ color: Int32) {
    c.setFillColor(argbToUIColor(color).cgColor)
    c.fillEllipse(in: CGRect(x: x - r, y: y - r, width: 2 * r, height: 2 * r))
}

func strokeCircle(_ c: CGContext, _ x: CGFloat, _ y: CGFloat, _ r: CGFloat, _ width: CGFloat, _ color: Int32) {
    c.setStrokeColor(argbToUIColor(color).cgColor)
    c.setLineWidth(width)
    c.strokeEllipse(in: CGRect(x: x - r, y: y - r, width: 2 * r, height: 2 * r))
}

func fillRect(_ c: CGContext, _ r: CGRect, _ color: Int32) {
    c.setFillColor(argbToUIColor(color).cgColor)
    c.fill(r)
}

/// PORT NOTE: Android `parent.requestDisallowInterceptTouchEvent(true/false)` — while a drag
/// is active every ancestor UIScrollView's pan gesture is disabled, re-enabled afterwards.
func disallowParentScrollInterception(_ v: UIView, _ disallow: Bool) {
    var p = v.superview
    while let sv = p {
        if let sc = sv as? UIScrollView { sc.panGestureRecognizer.isEnabled = !disallow }
        p = sv.superview
    }
}

/// PORT NOTE: Android's `View.setOnClickListener { ... }` + `isPressed` invalidate behavior
/// packed into one base class. Click = touch-up inside bounds, just like Android.
class TapView: UIControl {
    var onClick: (() -> Void)? = nil

    override var isHighlighted: Bool { didSet { setNeedsDisplay() } }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        isHighlighted = true
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        isHighlighted = false
        if let t = touches.first, bounds.contains(t.location(in: self)) { onClick?() }
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        isHighlighted = false
    }
}

// MARK: - Icons

/// Vector icons drawn with Paths on a 24x24 grid. No emoji or font glyphs are used anywhere in the UI.
enum Icons {
    static func draw(_ c: CGContext, _ name: String, _ cx: CGFloat, _ cy: CGFloat,
                     _ size: CGFloat, _ color: Int32) {
        c.saveGState()
        c.translateBy(x: cx - size / 2, y: cy - size / 2)
        c.scaleBy(x: size / 24, y: size / 24)

        let col = argbToUIColor(color)
        var p = CGMutablePath()

        func strokePaint() {
            c.setStrokeColor(col.cgColor)
            c.setLineWidth(2)
            c.setLineCap(.round)
            c.setLineJoin(.round)
        }
        func fillPaint() { c.setFillColor(col.cgColor) }
        func strokePath() { c.addPath(p); c.strokePath(); p = CGMutablePath() }
        func fillPath() { c.addPath(p); c.fillPath(); p = CGMutablePath() }
        func circleFill(_ x: CGFloat, _ y: CGFloat, _ r: CGFloat) {
            fillPaint(); c.fillEllipse(in: CGRect(x: x - r, y: y - r, width: 2 * r, height: 2 * r))
        }
        func circleStroke(_ x: CGFloat, _ y: CGFloat, _ r: CGFloat) {
            strokePaint(); c.strokeEllipse(in: CGRect(x: x - r, y: y - r, width: 2 * r, height: 2 * r))
        }
        func rrStroke(_ rect: CGRect, _ rad: CGFloat) {
            strokePaint()
            c.addPath(CGPath(roundedRect: rect, cornerWidth: rad, cornerHeight: rad, transform: nil))
            c.strokePath()
        }
        func rrFill(_ rect: CGRect, _ rad: CGFloat) {
            fillPaint()
            c.addPath(CGPath(roundedRect: rect, cornerWidth: rad, cornerHeight: rad, transform: nil))
            c.fillPath()
        }
        func line(_ x0: CGFloat, _ y0: CGFloat, _ x1: CGFloat, _ y1: CGFloat) {
            strokePaint()
            c.move(to: CGPoint(x: x0, y: y0))
            c.addLine(to: CGPoint(x: x1, y: y1))
            c.strokePath()
        }
        func rectFill(_ rect: CGRect) { fillPaint(); c.fill(rect) }
        func mv(_ x: CGFloat, _ y: CGFloat) { p.move(to: CGPoint(x: x, y: y)) }
        func lt(_ x: CGFloat, _ y: CGFloat) { p.addLine(to: CGPoint(x: x, y: y)) }
        func closeP() { p.closeSubpath() }
        func quad(_ cx1: CGFloat, _ cy1: CGFloat, _ x: CGFloat, _ y: CGFloat) {
            p.addQuadCurve(to: CGPoint(x: x, y: y), control: CGPoint(x: cx1, y: cy1))
        }
        func cubic(_ c1x: CGFloat, _ c1y: CGFloat, _ c2x: CGFloat, _ c2y: CGFloat, _ x: CGFloat, _ y: CGFloat) {
            p.addCurve(to: CGPoint(x: x, y: y), control1: CGPoint(x: c1x, y: c1y), control2: CGPoint(x: c2x, y: c2y))
        }

        switch name {
        case "back":
            strokePaint(); mv(15, 5); lt(8, 12); lt(15, 19); strokePath()
        case "cube":
            strokePaint()
            mv(12, 3); lt(20, 7.5); lt(20, 16.5); lt(12, 21); lt(4, 16.5); lt(4, 7.5); closeP()
            mv(4, 7.5); lt(12, 12); lt(20, 7.5)
            mv(12, 12); lt(12, 21)
            strokePath()
        case "dots":
            for i in 0..<3 { for j in 0..<3 { circleFill(6 + CGFloat(i) * 6, 6 + CGFloat(j) * 6, 1.5) } }
        case "dup":
            rrStroke(CGRect(x: 3, y: 3, width: 11, height: 11), 2)
            rrStroke(CGRect(x: 10, y: 10, width: 11, height: 11), 2)
        case "more":
            circleFill(12, 5, 1.8); circleFill(12, 12, 1.8); circleFill(12, 19, 1.8)
        case "grid":
            rrStroke(CGRect(x: 3, y: 3, width: 18, height: 18), 2)
            strokePaint()
            mv(9, 3); lt(9, 21); mv(15, 3); lt(15, 21)
            mv(3, 9); lt(21, 9); mv(3, 15); lt(21, 15)
            strokePath()
        case "bookmark", "bookmark_f":
            if name == "bookmark_f" { fillPaint() } else { strokePaint() }
            mv(6, 3); lt(18, 3); lt(18, 21); lt(12, 16.5); lt(6, 21); closeP()
            if name == "bookmark_f" { fillPath() } else { strokePath() }
        case "prev":
            strokePaint()
            mv(18, 5); lt(8, 12); lt(18, 19); closeP()
            mv(5, 5); lt(5, 19)
            strokePath()
        case "next":
            strokePaint()
            mv(6, 5); lt(16, 12); lt(6, 19); closeP()
            mv(19, 5); lt(19, 19)
            strokePath()
        case "play":
            fillPaint(); mv(7, 4); lt(20, 12); lt(7, 20); closeP(); fillPath()
        case "pause":
            rectFill(CGRect(x: 6, y: 4, width: 4, height: 16))
            rectFill(CGRect(x: 14, y: 4, width: 4, height: 16))
        case "layers":
            fillPaint(); mv(12, 3); lt(22, 9); lt(12, 15); lt(2, 9); closeP(); fillPath()
            strokePaint(); mv(2, 13); lt(12, 19); lt(22, 13); strokePath()
        case "undo", "redo":
            strokePaint()
            if name == "redo" { c.translateBy(x: 24, y: 0); c.scaleBy(x: -1, y: 1) }
            mv(9, 5); lt(4, 10); lt(9, 15)
            mv(4, 10); lt(14, 10)
            cubic(18.5, 10, 21, 12.5, 21, 17)
            strokePath()
        case "eye", "eye_off":
            strokePaint()
            mv(2, 12); quad(12, 3, 22, 12); quad(12, 21, 2, 12); closeP()
            strokePath()
            circleFill(12, 12, 3)
            if name == "eye_off" {
                strokePaint(); mv(4, 4); lt(20, 20); strokePath()
            }
        case "chev_down":
            strokePaint(); mv(6, 9); lt(12, 15); lt(18, 9); strokePath()
        case "chev_up":
            strokePaint(); mv(6, 15); lt(12, 9); lt(18, 15); strokePath()
        case "trash":
            fillPaint(); mv(6, 8); lt(18, 8); lt(17, 21); lt(7, 21); closeP(); fillPath()
            strokePaint()
            mv(4, 6); lt(20, 6)
            mv(9, 6); lt(9, 3); lt(15, 3); lt(15, 6)
            strokePath()
        case "close":
            strokePaint(); mv(5, 5); lt(19, 19); mv(19, 5); lt(5, 19); strokePath()
        case "plus":
            strokePaint(); mv(12, 4); lt(12, 20); mv(4, 12); lt(20, 12); strokePath()
        case "diamond", "diamond_f":
            if name == "diamond_f" { fillPaint() } else { strokePaint() }
            mv(12, 3); lt(21, 12); lt(12, 21); lt(3, 12); closeP()
            if name == "diamond_f" { fillPath() } else { strokePath() }
        case "graph":
            strokePaint(); mv(3, 18); lt(9, 11); lt(13, 15); lt(21, 6); strokePath()
        case "box":
            rrStroke(CGRect(x: 3, y: 3, width: 18, height: 18), 3)
            strokePaint()
            mv(7, 9); lt(11, 12); lt(7, 15)
            mv(13, 16); lt(17, 16)
            strokePath()
        case "handle":
            strokePaint(); mv(4, 9); lt(20, 9); mv(4, 15); lt(20, 15); strokePath()
        case "media":
            rrStroke(CGRect(x: 3, y: 5, width: 18, height: 14), 2)
            strokePaint(); mv(5, 17); lt(10, 11); lt(14, 15); lt(16, 13); lt(19, 17); strokePath()
            circleFill(16.5, 9.5, 1.6)
        case "text":
            strokePaint()
            mv(5, 6); lt(19, 6)
            mv(12, 6); lt(12, 19)
            mv(9, 19); lt(15, 19)
            strokePath()
        case "shape":
            circleStroke(9, 9, 5.5)
            rrStroke(CGRect(x: 11, y: 11, width: 9, height: 9), 1.5)
        case "camera":
            rrStroke(CGRect(x: 3, y: 7, width: 13, height: 10), 2)
            strokePaint(); mv(16, 10); lt(21, 7); lt(21, 17); lt(16, 14); strokePath()
        case "nullobj":
            circleStroke(12, 12, 5)
            strokePaint()
            mv(12, 2); lt(12, 7); mv(12, 17); lt(12, 22)
            mv(2, 12); lt(7, 12); mv(17, 12); lt(22, 12)
            strokePath()
        case "particles":
            circleFill(7, 7, 1.8); circleFill(15, 6, 1.2); circleFill(11, 12, 2.2)
            circleFill(18, 14, 1.6); circleFill(6, 17, 1.4); circleFill(14, 19, 1.8)
        case "edit":
            strokePaint()
            mv(4, 20); lt(5, 15); lt(16, 4); lt(20, 8); lt(9, 19); closeP()
            mv(14, 6); lt(18, 10)
            strokePath()
        case "move":
            strokePaint()
            mv(12, 3); lt(12, 21); mv(3, 12); lt(21, 12)
            mv(9, 6); lt(12, 3); lt(15, 6); mv(9, 18); lt(12, 21); lt(15, 18)
            mv(6, 9); lt(3, 12); lt(6, 15); mv(18, 9); lt(21, 12); lt(18, 15)
            strokePath()
        case "sparkle":
            fillPaint()
            mv(12, 3); lt(14, 10); lt(21, 12); lt(14, 14); lt(12, 21)
            lt(10, 14); lt(3, 12); lt(10, 10); closeP()
            fillPath()
        case "drop":
            strokePaint()
            mv(12, 3)
            cubic(12, 3, 5, 10, 5, 15)
            cubic(5, 19, 8, 21, 12, 21)
            cubic(16, 21, 19, 19, 19, 15)
            cubic(19, 10, 12, 3, 12, 3)
            closeP()
            strokePath()
        case "speed":
            strokePaint()
            mv(5, 5); lt(12, 12); lt(5, 19)
            mv(13, 5); lt(20, 12); lt(13, 19)
            strokePath()
        case "import":
            strokePaint()
            mv(12, 3); lt(12, 15)
            mv(7, 10); lt(12, 15); lt(17, 10)
            mv(4, 19); lt(20, 19)
            strokePath()
        case "export":
            strokePaint()
            mv(12, 15); lt(12, 3)
            mv(7, 8); lt(12, 3); lt(17, 8)
            mv(4, 19); lt(20, 19)
            strokePath()
        case "check":
            strokePaint(); mv(5, 12); lt(10, 17); lt(19, 7); strokePath()
        case "solid":
            rrFill(CGRect(x: 4, y: 4, width: 16, height: 16), 3)
        case "gear":
            circleStroke(12, 12, 3.2)
            circleStroke(12, 12, 7)
            strokePaint()
            for k in 0..<8 {
                let a = CGFloat(k) * .pi / 4
                mv(12 + 7.5 * cos(a), 12 + 7.5 * sin(a))
                lt(12 + 10 * cos(a), 12 + 10 * sin(a))
            }
            strokePath()
        case "adjust":
            line(4, 7, 20, 7); line(4, 12, 20, 12); line(4, 17, 20, 17)
            circleFill(9, 7, 2.4); circleFill(15, 12, 2.4); circleFill(8, 17, 2.4)
        case "audio":
            strokePaint()
            let hs: [CGFloat] = [3, 7, 10, 6, 4]
            for k in 0..<5 {
                let x = 4 + CGFloat(k) * 4
                mv(x, 12 - hs[k]); lt(x, 12 + hs[k])
            }
            strokePath()
        case "split":
            strokePaint()
            mv(12, 3); lt(12, 21)
            mv(8, 8); lt(4, 12); lt(8, 16)
            mv(16, 8); lt(20, 12); lt(16, 16)
            strokePath()
        case "trimin":
            strokePaint()
            mv(4, 4); lt(4, 20)
            mv(8, 12); lt(20, 12)
            mv(16, 8); lt(20, 12); lt(16, 16)
            strokePath()
        case "trimout":
            strokePaint()
            mv(20, 4); lt(20, 20)
            mv(16, 12); lt(4, 12)
            mv(8, 8); lt(4, 12); lt(8, 16)
            strokePath()
        case "pipette":
            circleStroke(17, 7, 3.2)
            strokePaint(); mv(15, 9); lt(5, 19); lt(4, 20); strokePath()
        case "link":
            rrStroke(CGRect(x: 2, y: 8.5, width: 12, height: 7), 3.5)
            rrStroke(CGRect(x: 10, y: 8.5, width: 12, height: 7), 3.5)
        case "unlink":
            rrStroke(CGRect(x: 1.5, y: 8.5, width: 8.5, height: 7), 3.5)
            rrStroke(CGRect(x: 14, y: 8.5, width: 8.5, height: 7), 3.5)
            strokePaint(); mv(9, 18.5); lt(15, 5.5); strokePath()
        case "flare":
            circleStroke(12, 12, 3.2)
            strokePaint()
            mv(12, 2.5); lt(12, 6.5); mv(12, 17.5); lt(12, 21.5)
            mv(2.5, 12); lt(6.5, 12); mv(17.5, 12); lt(21.5, 12)
            mv(5.5, 5.5); lt(8.3, 8.3); mv(15.7, 15.7); lt(18.5, 18.5)
            mv(18.5, 5.5); lt(15.7, 8.3); mv(8.3, 15.7); lt(5.5, 18.5)
            strokePath()
        case "mask":
            rrStroke(CGRect(x: 4, y: 4, width: 16, height: 16), 3)
            circleStroke(12, 12, 4.5)
        case "mask_invert":
            rrFill(CGRect(x: 4, y: 4, width: 16, height: 16), 3)
            c.setFillColor(UIColor.clear.cgColor)
            c.setBlendMode(.clear)
            c.fillEllipse(in: CGRect(x: 7.5, y: 7.5, width: 9, height: 9))
            c.setBlendMode(.normal)
        case "folder":
            fillPaint()
            mv(3, 6); lt(10, 6); lt(12, 8.5); lt(21, 8.5); lt(21, 19); lt(3, 19); closeP(); fillPath()
        case "folder_open":
            strokePaint()
            mv(3, 18); lt(3, 6); lt(10, 6); lt(12, 8.5); lt(20, 8.5); lt(20, 11)
            mv(3, 18); lt(6, 11); lt(22, 11); lt(19, 18); closeP(); strokePath()
        case "file":
            strokePaint()
            mv(6, 3); lt(14, 3); lt(19, 8); lt(19, 21); lt(6, 21); close()
            mv(14, 3); lt(14, 8); lt(19, 8); strokePath()
        case "file_plus":
            strokePaint()
            mv(6, 3); lt(14, 3); lt(19, 8); lt(19, 21); lt(6, 21); close()
            mv(12.5, 12); lt(12.5, 18); mv(9.5, 15); lt(15.5, 15); strokePath()
        case "folder_plus":
            strokePaint()
            mv(3, 18); lt(3, 6); lt(10, 6); lt(12, 8.5); lt(21, 8.5); lt(21, 18); close()
            mv(12, 11.5); lt(12, 16); mv(9.75, 13.75); lt(14.25, 13.75); strokePath()
        case "save":
            strokePaint()
            mv(4, 4); lt(17, 4); lt(20, 7); lt(20, 20); lt(4, 20); close()
            mv(8, 4); lt(8, 9); lt(15, 9); lt(15, 4); mv(8, 20); lt(8, 14); lt(16, 14); lt(16, 20); strokePath()
        case "align_l":
            strokePaint(); mv(4, 3); lt(4, 21); strokePath()
            rectFill(CGRect(x: 7, y: 6, width: 11, height: 4)); rectFill(CGRect(x: 7, y: 14, width: 6, height: 4))
        case "align_hc":
            strokePaint(); mv(12, 3); lt(12, 21); strokePath()
            rectFill(CGRect(x: 5, y: 6, width: 14, height: 4)); rectFill(CGRect(x: 8, y: 14, width: 8, height: 4))
        case "align_r":
            strokePaint(); mv(20, 3); lt(20, 21); strokePath()
            rectFill(CGRect(x: 6, y: 6, width: 11, height: 4)); rectFill(CGRect(x: 11, y: 14, width: 6, height: 4))
        case "align_t":
            strokePaint(); mv(3, 4); lt(21, 4); strokePath()
            rectFill(CGRect(x: 6, y: 7, width: 4, height: 11)); rectFill(CGRect(x: 14, y: 7, width: 4, height: 6))
        case "align_vc":
            strokePaint(); mv(3, 12); lt(21, 12); strokePath()
            rectFill(CGRect(x: 6, y: 5, width: 4, height: 14)); rectFill(CGRect(x: 14, y: 8, width: 4, height: 8))
        case "align_b":
            strokePaint(); mv(3, 20); lt(21, 20); strokePath()
            rectFill(CGRect(x: 6, y: 6, width: 4, height: 11)); rectFill(CGRect(x: 14, y: 11, width: 4, height: 6))
        case "fit":
            strokePaint()
            mv(4, 9); lt(4, 4); lt(9, 4)
            mv(15, 4); lt(20, 4); lt(20, 9)
            mv(20, 15); lt(20, 20); lt(15, 20)
            mv(9, 20); lt(4, 20); lt(4, 15)
            strokePath()
        default:
            break
        }
        c.restoreGState()
    }
}

// MARK: - IconView

/// Plain icon button.
final class IconView: TapView {
    var icon: String
    var tint: Int32
    private let sizePt: CGFloat
    var onLong: (() -> Void)? = nil
    private var longFired = false

    init(_ icon: String, _ tint: Int32 = C.TEXT, _ size: CGFloat = 22) {
        self.icon = icon
        self.tint = tint
        self.sizePt = size
        super.init(frame: .zero)
        // PORT NOTE: Android long-click timeout is 400ms; the recognizer must not
        // cancel the touch stream so normal clicks still work when onLong == nil.
        let lp = UILongPressGestureRecognizer(target: self, action: #selector(longPressed(_:)))
        lp.minimumPressDuration = 0.4
        lp.cancelsTouchesInView = false
        addGestureRecognizer(lp)
    }

    @objc private func longPressed(_ g: UILongPressGestureRecognizer) {
        if g.state == .began && onLong != nil { longFired = true; onLong?() }
    }

    func set(_ name: String, _ color: Int32) {
        icon = name; tint = color; setNeedsDisplay()
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        isHighlighted = false
        if !longFired, let t = touches.first, bounds.contains(t.location(in: self)) { onClick?() }
        longFired = false
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        isHighlighted = false
        longFired = false
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let col: Int32 = isHighlighted
            ? Int32(bitPattern: UInt32(bitPattern: tint) | 0x80000000)
            : tint
        Icons.draw(c, icon, bounds.width / 2, bounds.height / 2, sizePt, col)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - ChipView

/// Small outlined text chip, e.g. the preview quality switch.
final class ChipView: TapView {
    var text: String

    init(_ text: String) {
        self.text = text
        super.init(frame: .zero)
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let w = bounds.width, h = bounds.height
        let r = CGRect(x: 2, y: 6, width: w - 4, height: h - 12)
        strokeRoundRect(c, r, 8, 1.5, Int32(bitPattern: 0xFF4A4A52))
        drawText(text, w / 2, h / 2 + 4.5, color: C.TEXT, size: 13, bold: true, align: .center)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - PillButton

/// Rounded text button, optionally with a leading icon. Used for "Add Effect" etc.
final class PillButton: TapView {
    var text: String
    var icon: String?
    private let fillColor: Int32
    private let textColor: Int32

    init(_ text: String, _ icon: String?, _ fillColor: Int32, _ textColor: Int32) {
        self.text = text
        self.icon = icon
        self.fillColor = fillColor
        self.textColor = textColor
        super.init(frame: .zero)
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let w = bounds.width, h = bounds.height
        var col = argbToUIColor(fillColor)
        if isHighlighted { col = col.withAlphaComponent(170.0 / 255.0) }
        c.setFillColor(col.cgColor)
        c.addPath(CGPath(roundedRect: CGRect(x: 0, y: 0, width: w, height: h), cornerWidth: 12, cornerHeight: 12, transform: nil))
        c.fillPath()
        let tw = measureText(text, 15, true)
        let iw: CGFloat = icon != nil ? 22 + 8 : 0
        var x = (w - tw - iw) / 2
        if let ic = icon {
            Icons.draw(c, ic, x + 11, h / 2, 20, textColor)
            x += iw
        }
        drawText(text, x, h / 2 + 5, color: textColor, size: 15, bold: true, align: .left)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - RulerSlider

/// The scrolling-ruler value control used for every parameter.
/// Drag horizontally to change the value, tap the label to toggle a keyframe.
final class RulerSlider: UIControl {
    var label = ""
    var lo: Float = 0
    var hi: Float = 1
    var value: Float = 0
    var dec = 2
    var hasKey = false
    var hasAnim = false
    var canKey = true
    var onChange: ((Float) -> Void)? = nil
    var onBegin: (() -> Void)? = nil
    var onLabelTap: (() -> Void)? = nil
    var onLabelLong: (() -> Void)? = nil
    var hasExpr = false
    var infinite = false
    var span: Float = 1
    var onExprIcon: (() -> Void)? = nil
    var rowSelected = false

    private var onIcon = false
    private var longFired = false
    private var raw: Float = 0
    private var downX: CGFloat = 0
    private var lastX: CGFloat = 0
    private var dragging = false
    private var onLabel = false
    private var longWork: DispatchWorkItem? = nil

    override init(frame: CGRect) {
        super.init(frame: frame)
    }

    private func fmt(_ v: Float) -> String {
        let q: Float = abs(v) < 0.5 * pow(10, -Float(dec)) ? 0 : v
        return String(format: "%.\(dec)f", q)
    }

    private func labelW() -> CGFloat { bounds.width * 0.36 }
    private func ppu() -> CGFloat {
        (bounds.width - labelW()) / CGFloat((infinite ? span : (hi - lo)) * 0.6)
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let w = bounds.width, h = bounds.height
        fillRoundRect(c, CGRect(x: 0, y: 0, width: w, height: h), 10, C.CARD)
        if rowSelected {
            strokeRoundRect(c, bounds.insetBy(dx: 1, dy: 1), 10, 2, C.GREEN)
        }

        let lw = labelW()
        drawText(label, 14, h / 2 + 5, color: hasExpr ? C.RED : C.TEXT, size: 15, bold: true, align: .left)
        if onExprIcon != nil {
            let ec: Int32 = hasExpr ? C.RED : Int32(bitPattern: 0xFF7A7A84)
            let r = CGRect(x: lw - 38, y: h - 24, width: 32, height: 18)
            strokeRoundRect(c, r, 6, 2, ec)
            drawText("fx", lw - 22, h - 11, color: ec, size: 10, bold: true, align: .center)
        }
        if canKey && (hasKey || hasAnim) {
            Icons.draw(c, hasKey ? "diamond_f" : "diamond", lw - 14, 16, 12,
                       hasKey ? C.GREEN : Int32(bitPattern: 0xFF7A7A84))
        }

        // ruler
        let cxv = lw + (w - lw) / 2
        let ppuVal = ppu()
        c.saveGState()
        c.clip(to: CGRect(x: lw, y: 0, width: w - lw, height: h))
        let range: Float = infinite ? span : hi - lo
        let rawStep: Float = range * 0.1
        let mag: Float = pow(10, Float(floor(log10(Double(rawStep)))))
        let f: Float = rawStep / mag
        let nice: Float = f < 1.5 ? 1 : (f < 3.5 ? 2 : (f < 7.5 ? 5 : 10))
        let major: Float = nice * mag
        let minor: Float = major / 5
        let k0 = Int(ceil(Double((value - Float((cxv - lw) / ppuVal)) / minor)))
        let k1 = Int(floor(Double((value + Float((w - cxv) / ppuVal)) / minor)))
        if k1 >= k0 {
            for k in k0...k1 {
                let v = Float(k) * minor
                if v < lo - 0.0001 || v > hi + 0.0001 { continue }
                let x = cxv + CGFloat(v - value) * ppuVal
                let isMajor = k % 5 == 0
                let top: CGFloat = isMajor ? h - 18 : h - 11
                strokeLine(c, x, top, x, h - 4, 1.2, Int32(bitPattern: 0xFF6B6B75))
                if isMajor {
                    let s = String(format: major >= 1 ? "%.0f" : "%.1f", v)
                    drawText(s, x, h - 22, color: Int32(bitPattern: 0xFF8C8C96), size: 11, align: .center)
                }
            }
        }
        // boundary markers at min and max
        let xl = cxv + CGFloat(lo - value) * ppuVal
        let xh = cxv + CGFloat(hi - value) * ppuVal
        if xl >= lw && xl <= w { strokeLine(c, xl, 8, xl, h - 4, 2, Int32(bitPattern: 0xFFFFFFFF)) }
        if xh >= lw && xh <= w { strokeLine(c, xh, 8, xh, h - 4, 2, Int32(bitPattern: 0xFFFFFFFF)) }
        // centre line
        strokeLine(c, cxv, 30, cxv, h, 2, C.GREEN)
        c.restoreGState()

        // value bubble
        let s = fmt(value)
        let bw = max(44, measureText(s, 15, true) + 20)
        let r = CGRect(x: cxv - bw / 2, y: 6, width: bw, height: 28)
        fillRoundRect(c, r, 8, C.GREEN)
        drawText(s, cxv, 26, color: Int32(bitPattern: 0xFF2B1400), size: 15, bold: true, align: .center)
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        let pt = t.location(in: self)
        downX = pt.x; lastX = pt.x; dragging = false
        onLabel = pt.x < labelW()
        onIcon = onLabel && onExprIcon != nil && pt.x > labelW() - 42 && pt.y > bounds.height * 0.45
        longFired = false
        raw = value
        if !onLabel {
            onBegin?()
            disallowParentScrollInterception(self, true)
        } else if !onIcon {
            // postDelayed(longRun, 450)
            longWork = DispatchWorkItem(block: { [weak self] in
                guard let self = self, !self.dragging else { return }
                self.longFired = true
                self.onLabelLong?()
            })
            if let work = longWork { DispatchQueue.main.asyncAfter(deadline: .now() + 0.45, execute: work) }
        }
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        let x = t.location(in: self).x
        if onLabel { return }
        if abs(x - downX) > 4 { dragging = true }
        let dx = x - lastX
        lastX = x
        raw = raw - Float(dx) / Float(ppu())
        if !infinite { raw = clamp(raw, lo, hi) }
        let v: Float = dec == 0 ? Float(kotlinRound(raw)) : raw
        if v != value { value = v; onChange?(v); setNeedsDisplay() }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else {
            longWork?.cancel(); longWork = nil
            disallowParentScrollInterception(self, false)
            return
        }
        let x = t.location(in: self).x
        longWork?.cancel(); longWork = nil
        if onIcon && abs(x - downX) < 10 { onExprIcon?() }
        else if onLabel && !longFired && abs(x - downX) < 8 { onLabelTap?() }
        disallowParentScrollInterception(self, false)
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        longWork?.cancel(); longWork = nil
        disallowParentScrollInterception(self, false)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - ToolButton

/// Icon above a label; used for the bottom tool bar.
final class ToolButton: TapView {
    var icon: String
    var label: String
    var tint: Int32 = C.TEXT

    init(_ icon: String, _ label: String) {
        self.icon = icon
        self.label = label
        super.init(frame: .zero)
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let w = bounds.width, h = bounds.height
        let col: Int32 = isHighlighted
            ? Int32(bitPattern: UInt32(bitPattern: tint) | 0x80000000)
            : tint
        Icons.draw(c, icon, w / 2, h / 2 - 7, 24, col)
        drawText(label, w / 2, h - 10, color: col, size: 11, align: .center)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - chipRow

/// Horizontal row of selectable pills (Kotlin top-level fun chipRow).
/// Buttons are 92x38 at 3pt side / 4pt vertical margins → the row is 46pt tall.
private final class ChipRowScrollView: UIScrollView {
    override var intrinsicContentSize: CGSize { CGSize(width: UIView.noIntrinsicMetric, height: 46) }
}

func chipRow(_ labels: [String], _ sel: Int, _ onPick: @escaping (Int) -> Void) -> UIView {
    let sv = ChipRowScrollView()
    sv.showsHorizontalScrollIndicator = false
    sv.clipsToBounds = true
    let row = UIView(frame: CGRect(x: 0, y: 0, width: CGFloat(labels.count) * 98 + 3, height: 46))
    for (i, nm) in labels.enumerated() {
        let on = i == sel
        let b = PillButton(nm, nil, on ? C.GREEN : C.CARD2, on ? Int32(bitPattern: 0xFF2B1400) : C.TEXT)
        b.onClick = { onPick(i) }
        b.frame = CGRect(x: 3 + CGFloat(i) * 98, y: 4, width: 92, height: 38)
        row.addSubview(b)
    }
    sv.addSubview(row)
    sv.contentSize = row.frame.size
    return sv
}

// MARK: - EffectCard

/// Effect tile whose icon automatically swipes between the processed and the original anime portrait.
final class EffectCard: TapView {
    var name: String
    var category: String
    var before: UIImage? = nil
    var after: UIImage? = nil
    var badge = false
    var thumbHeight: Float = 0.8
    var anim = "swipe"
    var thumbId: String? = nil
    var origId: String? = nil

    init(_ name: String, _ category: String) {
        self.name = name
        self.category = category
        super.init(frame: .zero)
    }

    /// PORT NOTE: postInvalidateOnAnimation / postInvalidateDelayed replaced with a
    /// scheduled setNeedsDisplay (60fps while swiping, 400ms while "rendering").
    private func scheduleRedraw(_ delay: TimeInterval) {
        DispatchQueue.main.asyncAfter(deadline: .now() + delay) { [weak self] in
            self?.setNeedsDisplay()
        }
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let w = bounds.width
        let th = min(w * CGFloat(thumbHeight), bounds.height - 44)
        fillRoundRect(c, CGRect(x: 0, y: 0, width: w, height: bounds.height), 12, C.CARD)
        // thumbnail area, top corners rounded 12
        c.saveGState()
        let clipPath = UIBezierPath(roundedRect: CGRect(x: 0, y: 0, width: w, height: th),
                                    byRoundingCorners: [.topLeft, .topRight],
                                    cornerRadii: CGSize(width: 12, height: 12)).cgPath
        c.addPath(clipPath)
        c.clip()
        // The card picks its pictures up from the EffectThumbs caches as they arrive;
        // until then the cheap raw() placeholder shows the sample picture.
        if let oid = origId {
            if let gl = EffectThumbs.cache[oid] {
                before = gl
            } else if before == nil {
                before = EffectThumbs.raw(String(oid.dropFirst("__orig:".count)))
            }
        }
        if let tid = thumbId, after == nil {
            after = EffectThumbs.cache[tid]
        }
        let a = after
        let b = before
        if let a = a, let b = b {
            let ph = Float(nowMs() % 3600) / 3600.0
            let u: Float = ph < 0.5 ? ph * 2 : 2 - ph * 2
            drawFit(c, b, 0, w, th)
            switch anim {
            case "fade":
                c.saveGState()
                c.setAlpha(CGFloat(clamp(u, 0, 1)))
                drawFit(c, a, 0, w, th)
                c.restoreGState()
            case "cut":
                if ph >= 0.5 { drawFit(c, a, 0, w, th) }
            case "wipe":
                let ey = th * CGFloat(0.06 + 0.88 * u)
                c.saveGState()
                c.clip(to: CGRect(x: 0, y: 0, width: w, height: ey))
                drawFit(c, a, 0, w, th)
                c.restoreGState()
                strokeLine(c, 0, ey, w, ey, 2, Int32(bitPattern: 0xFFFFFFFF))
            default:
                let ex = w * CGFloat(0.08 + 0.84 * u)
                c.saveGState()
                c.clip(to: CGRect(x: 0, y: 0, width: ex, height: th))
                drawFit(c, a, 0, w, th)
                c.restoreGState()
                strokeLine(c, ex, 0, ex, th, 2, Int32(bitPattern: 0xFFFFFFFF))
                fillCircle(c, ex, th / 2, 9, Int32(bitPattern: 0xFFFFFFFF))
                fillCircle(c, ex, th / 2, 3.5, Int32(bitPattern: 0xFF111114))
            }
            scheduleRedraw(1.0 / 30.0)
        } else if let b = b {
            drawFit(c, b, 0, w, th)
            drawText("Rendering...", w / 2, th - 8, color: Int32(bitPattern: 0xFFFFFFFF), size: 11, align: .center)
            scheduleRedraw(0.3)
        } else {
            fillRect(c, CGRect(x: 0, y: 0, width: w, height: th), C.CARD2)
            drawText("rendering", w / 2, th / 2, color: C.DIM, size: 12, align: .center)
            scheduleRedraw(0.4)
        }
        c.restoreGState()
        drawText(name, 10, th + 22, color: C.TEXT, size: 14, bold: true, align: .left)
        drawText(category, 10, th + 38, color: C.DIM, size: 11, align: .left)
        if badge { fillCircle(c, w - 14, th + 20, 5, C.GREEN) }
    }

    /// Center-crop fit (Android drawBitmap with src center-crop rect + dst rect).
    private func drawFit(_ c: CGContext, _ img: UIImage, _ x: CGFloat, _ w: CGFloat, _ h: CGFloat) {
        guard let cgi = img.cgImage else { return }
        let bw = img.size.width, bh = img.size.height
        guard bw > 0, bh > 0 else { return }
        let s = max(w / bw, h / bh)
        let dw = bw * s, dh = bh * s
        let dx = x + (w - dw) / 2
        let dy = (h - dh) / 2
        c.saveGState()
        c.clip(to: CGRect(x: x, y: 0, width: w, height: h))
        c.draw(cgi, in: CGRect(x: dx, y: dy, width: dw, height: dh))
        c.restoreGState()
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - GraphView

/// Cubic bezier easing editor: drag the two handles.
final class GraphView: UIControl {
    var key: Key? = nil
    var onBegin: (() -> Void)? = nil
    var onChange: (() -> Void)? = nil
    private var drag = 0
    private let pad: CGFloat = 24

    override init(frame: CGRect) {
        super.init(frame: frame)
    }

    private func px(_ x: Float) -> CGFloat { pad + CGFloat(x) * (bounds.width - 2 * pad) }
    private func py(_ y: Float) -> CGFloat { bounds.height - pad - CGFloat(y + 0.5) / 2 * (bounds.height - 2 * pad) }
    private func ux(_ x: CGFloat) -> Float { clamp(Float((x - pad) / (bounds.width - 2 * pad)), 0, 1) }
    private func uy(_ y: CGFloat) -> Float { clamp(Float((bounds.height - pad - y) / (bounds.height - 2 * pad)) * 2 - 0.5, -0.5, 1.5) }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        for i in 0...4 {
            let gx = px(Float(i) / 4)
            strokeLine(c, gx, py(-0.5), gx, py(1.5), 1, Int32(bitPattern: 0xFF2A2A30))
        }
        for i in 0...4 {
            let gy = py(-0.5 + Float(i) * 0.5)
            strokeLine(c, px(0), gy, px(1), gy, 1, Int32(bitPattern: 0xFF2A2A30))
        }
        guard let k = key else {
            drawText("Select a property with 2+ keyframes", bounds.width / 2, bounds.height / 2,
                     color: C.DIM, size: 12, align: .center)
            return
        }
        c.setStrokeColor(argbToUIColor(C.GREEN).cgColor)
        c.setLineWidth(3)
        c.setLineCap(.round)
        c.setLineJoin(.round)
        c.beginPath()
        for i in 0...60 {
            let u = Float(i) / 60
            let x = px(u), y = py(k.curve(u))
            if i == 0 { c.move(to: CGPoint(x: x, y: y)) } else { c.addLine(to: CGPoint(x: x, y: y)) }
        }
        c.strokePath()
        let white = Int32(bitPattern: 0xFFFFFFFF)
        if k.isBezier() && !k.rev {
            strokeLine(c, px(0), py(0), px(k.x1), py(k.y1), 1.5, white)
            strokeLine(c, px(1), py(1), px(k.x2), py(k.y2), 1.5, white)
            fillCircle(c, px(k.x1), py(k.y1), 8, white)
            fillCircle(c, px(k.x2), py(k.y2), 8, white)
        }
        fillCircle(c, px(0), py(0), 4, white)
        fillCircle(c, px(1), py(1), 4, white)
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let k = key, k.isBezier(), !k.rev, let t = touches.first else { return }
        let pt = t.location(in: self)
        let d1 = hypot(pt.x - px(k.x1), pt.y - py(k.y1))
        let d2 = hypot(pt.x - px(k.x2), pt.y - py(k.y2))
        drag = min(d1, d2) > 40 ? 0 : (d1 <= d2 ? 1 : 2)
        if drag != 0 {
            onBegin?()
            disallowParentScrollInterception(self, true)
        }
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let k = key, drag != 0, let t = touches.first else { return }
        let pt = t.location(in: self)
        if k.ease != Ease.CUSTOM { k.ease = Ease.CUSTOM }
        if drag == 1 { k.x1 = ux(pt.x); k.y1 = uy(pt.y) } else { k.x2 = ux(pt.x); k.y2 = uy(pt.y) }
        onChange?()
        setNeedsDisplay()
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        drag = 0
        disallowParentScrollInterception(self, false)
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        drag = 0
        disallowParentScrollInterception(self, false)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - SwitchRow

/// Card with a label and an on/off switch. Used for every two-state setting.
final class SwitchRow: TapView {
    var label = ""
    var captionOn = "On"
    var captionOff = "Off"
    var on = false
    var onToggle: ((Bool) -> Void)? = nil

    override init(frame: CGRect) {
        super.init(frame: frame)
        onClick = { [weak self] in
            guard let self = self else { return }
            self.on = !self.on
            self.onToggle?(self.on)
            self.setNeedsDisplay()
        }
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let w = bounds.width, h = bounds.height
        fillRoundRect(c, CGRect(x: 0, y: 0, width: w, height: h), 10, C.CARD)
        drawText(label, 14, h / 2 + 5, color: C.TEXT, size: 15, bold: true, align: .left)
        let sw: CGFloat = 50
        let sh: CGFloat = 28
        let x1 = w - 14
        let x0 = x1 - sw
        let y0 = (h - sh) / 2
        fillRoundRect(c, CGRect(x: x0, y: y0, width: sw, height: sh), sh / 2, on ? C.GREEN : Int32(bitPattern: 0xFF3A3A44))
        fillCircle(c, on ? x1 - sh / 2 : x0 + sh / 2, y0 + sh / 2, sh / 2 - 3, Int32(bitPattern: 0xFFFFFFFF))
        drawText(on ? captionOn : captionOff, x0 - 10, h / 2 + 4, color: C.DIM, size: 12, align: .right)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - ColorPickerView

/// Saturation / brightness square, hue bar and opacity bar.
final class ColorPickerView: UIControl {
    var onChange: ((Int32) -> Void)? = nil
    private var hue: Float = 0
    private var sat: Float = 1
    private var value: Float = 1
    // PORT NOTE: Kotlin private `alpha` renamed (UIView.alpha collision).
    private var alphaVal: Float = 1
    private var drag = 0
    private let barH: CGFloat = 28
    private let gap: CGFloat = 12

    override init(frame: CGRect) {
        super.init(frame: frame)
    }

    func setColor(_ c: Int32) {
        let hsvn = ColorPickerView.argbToHSV(c)
        hue = hsvn.h; sat = hsvn.s; value = hsvn.v
        alphaVal = Float(colorAlpha(c)) / 255.0
        setNeedsDisplay()
    }

    func color() -> Int32 {
        ColorPickerView.hsvToARGB(hue, sat, value, Int(alphaVal * 255))
    }

    private func sqH() -> CGFloat { bounds.height - 2 * (barH + gap) }

    private static func hsvToARGB(_ h: Float, _ s: Float, _ v: Float, _ a: Int = 255) -> Int32 {
        let u = UIColor(hue: CGFloat(h) / 360, saturation: CGFloat(s), brightness: CGFloat(v), alpha: 1)
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, al: CGFloat = 0
        u.getRed(&r, green: &g, blue: &b, alpha: &al)
        return argbColor(a, Int(r * 255 + 0.5), Int(g * 255 + 0.5), Int(b * 255 + 0.5))
    }

    private static func argbToHSV(_ c: Int32) -> (h: Float, s: Float, v: Float) {
        let u = argbToUIColor(c)
        var h: CGFloat = 0, s: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        if u.getHue(&h, saturation: &s, brightness: &b, alpha: &a) {
            return (Float(h) * 360, Float(s), Float(b))
        }
        return (0, 0, 1)
    }

    private func marker(_ c: CGContext, _ x: CGFloat, _ y: CGFloat) {
        strokeCircle(c, x, y, 9, 3, Int32(bitPattern: 0xFFFFFFFF))
        strokeCircle(c, x, y, 10.5, 1.2, Int32(bitPattern: 0xFF000000))
    }

    private func gradientRoundRect(_ c: CGContext, _ r: CGRect, _ radius: CGFloat,
                                   colors: [CGColor], start: CGPoint, end: CGPoint) {
        guard let g = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors as CFArray, locations: nil) else { return }
        c.saveGState()
        c.addPath(CGPath(roundedRect: r, cornerWidth: radius, cornerHeight: radius, transform: nil))
        c.clip()
        c.drawLinearGradient(g, start: start, end: end, options: [])
        c.restoreGState()
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let w = bounds.width
        let sh = sqH()
        let sq = CGRect(x: 0, y: 0, width: w, height: sh)
        // white → hue (horizontal)
        gradientRoundRect(c, sq, 10,
                          colors: [UIColor.white.cgColor, argbToUIColor(ColorPickerView.hsvToARGB(hue, 1, 1)).cgColor],
                          start: CGPoint(x: 0, y: 0), end: CGPoint(x: w, y: 0))
        // transparent black → black (vertical)
        gradientRoundRect(c, sq, 10,
                          colors: [UIColor.black.withAlphaComponent(0).cgColor, UIColor.black.cgColor],
                          start: CGPoint(x: 0, y: 0), end: CGPoint(x: 0, y: sh))
        marker(c, CGFloat(sat) * w, CGFloat(1 - value) * sh)
        // hue bar
        let hy = sh + gap
        let bar = CGRect(x: 0, y: hy, width: w, height: barH)
        var cols: [CGColor] = []
        for i in 0...6 { cols.append(argbToUIColor(ColorPickerView.hsvToARGB(Float(i) * 60, 1, 1)).cgColor) }
        gradientRoundRect(c, bar, barH / 2, colors: cols,
                          start: CGPoint(x: 0, y: 0), end: CGPoint(x: w, y: 0))
        marker(c, CGFloat(hue / 360) * w, hy + barH / 2)
        // opacity bar
        let ay = hy + barH + gap
        let abar = CGRect(x: 0, y: ay, width: w, height: barH)
        fillRoundRect(c, abar, barH / 2, Int32(bitPattern: 0xFF666666))
        let base = ColorPickerView.hsvToARGB(hue, sat, value)
        gradientRoundRect(c, abar, barH / 2,
                          colors: [argbToUIColor(base & 0x00FFFFFF).cgColor,
                                   argbToUIColor(base | Int32(bitPattern: 0xFF000000)).cgColor],
                          start: CGPoint(x: 0, y: 0), end: CGPoint(x: w, y: 0))
        marker(c, CGFloat(alphaVal) * w, ay + barH / 2)
    }

    private func apply(_ pt: CGPoint) {
        let w = bounds.width
        let sh = sqH()
        let pxv = clamp(Float(pt.x / w), 0, 1)
        if drag == 1 {
            sat = pxv
            value = 1 - clamp(Float(pt.y / sh), 0, 1)
        } else if drag == 2 {
            hue = pxv * 359.9
        } else {
            alphaVal = pxv
        }
        setNeedsDisplay()
        onChange?(color())
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        let pt = t.location(in: self)
        let sh = sqH()
        disallowParentScrollInterception(self, true)
        drag = pt.y < sh ? 1 : (pt.y < sh + gap + barH + gap / 2 ? 2 : 3)
        apply(pt)
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard drag != 0, let t = touches.first else { return }
        apply(t.location(in: self))
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        drag = 0
        disallowParentScrollInterception(self, false)
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        drag = 0
        disallowParentScrollInterception(self, false)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - ValueGraphView

/// Read-only plot of a parameter over time with its keyframes; tap a keyframe to select it.
final class ValueGraphView: UIControl {
    var track: Track? = nil
    var t0: Float = 0
    var t1: Float = 1
    var selIdx = 0
    var speedMode = false
    var onPick: ((Int) -> Void)? = nil
    private let pad: CGFloat = 14

    private func fv(_ tr: Track, _ t: Float) -> Float {
        speedMode ? (tr.eval(t + 0.01) - tr.eval(t - 0.01)) / 0.02 : tr.eval(t)
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
    }

    private func xOf(_ t: Float) -> CGFloat {
        pad + CGFloat((t - t0) / (t1 - t0)) * (bounds.width - 2 * pad)
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        fillRoundRect(c, CGRect(x: 0, y: 0, width: bounds.width, height: bounds.height), 10, C.CARD)
        guard let tr = track else { return }
        var lo = Float.greatestFiniteMagnitude
        var hi = -Float.greatestFiniteMagnitude
        var vs = [Float](repeating: 0, count: 81)
        for i in 0...80 {
            let v = fv(tr, t0 + (t1 - t0) * Float(i) / 80)
            vs[i] = v
            lo = min(lo, v)
            hi = max(hi, v)
        }
        if hi - lo < 1e-4 { hi = lo + 1 }
        func yOf(_ v: Float) -> CGFloat {
            bounds.height - pad - CGFloat((v - lo) / (hi - lo)) * (bounds.height - 2 * pad)
        }
        c.setStrokeColor(argbToUIColor(C.GREEN).cgColor)
        c.setLineWidth(2.5)
        c.setLineCap(.round)
        c.setLineJoin(.round)
        c.beginPath()
        for i in 0...80 {
            let x = xOf(t0 + (t1 - t0) * Float(i) / 80)
            let y = yOf(vs[i])
            if i == 0 { c.move(to: CGPoint(x: x, y: y)) } else { c.addLine(to: CGPoint(x: x, y: y)) }
        }
        c.strokePath()
        // playhead
        let pxv = xOf(Editor.time)
        if pxv >= 0 && pxv <= bounds.width {
            strokeLine(c, pxv, pad, pxv, bounds.height - pad, 1, C.AMBER)
        }
        for (i, k) in tr.keys.enumerated() {
            let col: Int32 = i == selIdx ? C.GREEN : Int32(bitPattern: 0xFFFFFFFF)
            fillCircle(c, xOf(k.t), yOf(fv(tr, k.t)), (i == selIdx ? 8 : 6), col)
        }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let tr = track, let t = touches.first else { return }
        let x = t.location(in: self).x
        var best = -1
        var bd: CGFloat = 32
        for (i, k) in tr.keys.enumerated() {
            let dd = abs(xOf(k.t) - x)
            if dd < bd { bd = dd; best = i }
        }
        if best >= 0 { onPick?(best) }
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - TabBar

/// Two to four text tabs with an accent underline under the selected one.
final class TabBar: TapView {
    private let labels: [String]
    var sel: Int
    private let onPick: (Int) -> Void

    init(_ labels: [String], _ sel: Int, _ onPick: @escaping (Int) -> Void) {
        self.labels = labels
        self.sel = sel
        self.onPick = onPick
        super.init(frame: .zero)
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let w = bounds.width / CGFloat(labels.count)
        for i in 0..<labels.count {
            let on = i == sel
            drawText(labels[i], w * (CGFloat(i) + 0.5), bounds.height / 2 + 5,
                     color: on ? C.GREEN : C.DIM, size: 15, bold: true, align: .center)
            if on {
                strokeLine(c, w * CGFloat(i) + 16, bounds.height - 3, w * CGFloat(i + 1) - 16, bounds.height - 3, 3, C.GREEN)
            }
        }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        let i = clamp(Int(t.location(in: self).x / (bounds.width / CGFloat(labels.count))), 0, labels.count - 1)
        if i != sel { sel = i; setNeedsDisplay(); onPick(i) }
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - MovePadView

/// Drag anywhere inside to move X and Y together (relative movement, like a trackpad).
final class MovePadView: UIControl {
    var px: Float = 0
    var py: Float = 0
    var onBegin: (() -> Void)? = nil
    var onMove: ((Float, Float) -> Void)? = nil
    private var lx: CGFloat = 0
    private var ly: CGFloat = 0

    override init(frame: CGRect) { super.init(frame: frame) }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        fillRoundRect(c, CGRect(x: 0, y: 0, width: bounds.width, height: bounds.height), 12, C.CARD)
        let cx = bounds.width / 2
        let cy = bounds.height / 2
        strokeLine(c, cx, 0, cx, bounds.height, 1, Int32(bitPattern: 0xFF3A3A42))
        strokeLine(c, 0, cy, bounds.width, cy, 1, Int32(bitPattern: 0xFF3A3A42))
        let ox = CGFloat(clamp(px / 3 * 160, Float(-cx + 14), Float(cx - 14)))
        let oy = CGFloat(clamp(-py / 3 * 160, Float(-cy + 14), Float(cy - 14)))
        fillCircle(c, cx + ox, cy + oy, 9, C.GREEN)
        drawText("X " + String(format: "%.2f", px) + "   Y " + String(format: "%.2f", py),
                 12, 20, color: C.DIM, size: 12, align: .left)
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        lx = t.location(in: self).x
        ly = t.location(in: self).y
        disallowParentScrollInterception(self, true)
        onBegin?()
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        let p = t.location(in: self)
        let k: Float = 3 / 160
        onMove?((Float(p.x - lx)) * k, -(Float(p.y - ly)) * k)
        lx = p.x
        ly = p.y
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        disallowParentScrollInterception(self, false)
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        disallowParentScrollInterception(self, false)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - GridPick

/// 3x3 anchor preset picker. Index 0..8, row-major from top-left.
final class GridPick: TapView {
    var sel = -1
    var onPick: ((Int) -> Void)? = nil

    override init(frame: CGRect) { super.init(frame: frame) }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        fillRoundRect(c, CGRect(x: 0, y: 0, width: bounds.width, height: bounds.height), 12, C.CARD)
        let padX: CGFloat = 28
        let padY: CGFloat = 22
        for i in 0..<9 {
            let x = padX + (bounds.width - 2 * padX) * CGFloat(i % 3) / 2
            let y = padY + (bounds.height - 2 * padY) * CGFloat(i / 3) / 2
            fillCircle(c, x, y, i == sel ? 10 : 5, i == sel ? C.GREEN : C.DIM)
        }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        let p = t.location(in: self)
        let col = clamp(Int(p.x / (bounds.width / 3)), 0, 2)
        let row = clamp(Int(p.y / (bounds.height / 3)), 0, 2)
        onPick?(row * 3 + col)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - PillToggle

/// Small pill toggle used in the top bar for motion blur. Tap to switch, long-press for settings.
final class PillToggle: TapView {
    var on = false {
        didSet { setNeedsDisplay() }
    }
    var onClick: (() -> Void)? = nil
    var onLong: (() -> Void)? = nil

    override init(frame: CGRect) {
        super.init(frame: frame)
        let lp = UILongPressGestureRecognizer(target: self, action: #selector(longPressed(_:)))
        lp.minimumPressDuration = 0.4
        lp.cancelsTouchesInView = false
        addGestureRecognizer(lp)
    }

    @objc private func longPressed(_ g: UILongPressGestureRecognizer) {
        if g.state == .began && onLong != nil { onLong?() }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesEnded(touches, with: event)
        onClick?()
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let w: CGFloat = 40
        let h: CGFloat = 22
        let l = (bounds.width - w) / 2
        let t = (bounds.height - h) / 2
        fillRoundRect(c, CGRect(x: l, y: t, width: w, height: h), h / 2, on ? C.GREEN : Int32(bitPattern: 0xFF55555E))
        let cx = on ? l + w - h / 2 : l + h / 2
        fillCircle(c, cx, t + h / 2, h / 2 - 3, Int32(bitPattern: 0xFFFFFFFF))
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - FillSlider

/// Rounded fill slider (drag across the bar). Used for playback speed.
final class FillSlider: UIControl {
    var lo: Float = 0
    var hi: Float = 1
    var value: Float = 0
    var suffix = "x"
    var onBegin: (() -> Void)? = nil
    var onChange: ((Float) -> Void)? = nil
    private var dragging = false

    override init(frame: CGRect) { super.init(frame: frame) }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        fillRoundRect(c, CGRect(x: 0, y: 0, width: bounds.width, height: bounds.height), bounds.height / 2, C.CARD)
        let f = CGFloat(clamp((value - lo) / (hi - lo), 0, 1))
        let fill = isUserInteractionEnabled ? C.GREEN : Int32(bitPattern: 0xFF55555E)
        c.saveGState()
        c.clip(to: CGRect(x: 0, y: 0, width: bounds.width * f, height: bounds.height))
        fillRoundRect(c, CGRect(x: 0, y: 0, width: bounds.width, height: bounds.height), bounds.height / 2, fill)
        c.restoreGState()
        drawText(String(format: "%.2f", value) + suffix, bounds.width / 2, bounds.height / 2 + 5,
                 color: isUserInteractionEnabled ? Int32(bitPattern: 0xFF2B1400) : C.DIM, size: 15, bold: true, align: .center)
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard isUserInteractionEnabled, let t = touches.first else { return }
        dragging = true
        disallowParentScrollInterception(self, true)
        onBegin?()
        setv(t.location(in: self).x)
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard dragging, let t = touches.first else { return }
        setv(t.location(in: self).x)
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        dragging = false
        disallowParentScrollInterception(self, false)
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        dragging = false
        disallowParentScrollInterception(self, false)
    }

    private func setv(_ x: CGFloat) {
        let v = lo + clamp(Float(x / bounds.width), 0, 1) * (hi - lo)
        value = Float(kotlinRound(v * 20)) / 20
        value = clamp(value, lo, hi)
        setNeedsDisplay()
        onChange?(value)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - CurveThumb

/// Small card showing the shape of an easing curve; used as a preset thumbnail.
final class CurveThumb: TapView {
    let key: Key
    let name: String
    var sel = false

    init(_ key: Key, _ name: String) {
        self.key = key
        self.name = name
        super.init(frame: .zero)
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        fillRoundRect(c, CGRect(x: 1, y: 1, width: bounds.width - 2, height: bounds.height - 2), 12, C.CARD)
        if sel {
            c.setStrokeColor(argbToUIColor(C.GREEN).cgColor)
            c.setLineWidth(2)
            let pth = UIBezierPath(roundedRect: CGRect(x: 1, y: 1, width: bounds.width - 2, height: bounds.height - 2), cornerRadius: 12)
            c.addPath(pth.cgPath)
            c.strokePath()
        }
        let px: CGFloat = 14
        let top: CGFloat = 12
        let bot = bounds.height - 24
        c.setStrokeColor(argbToUIColor(sel ? C.GREEN : C.TEXT).cgColor)
        c.setLineWidth(2.5)
        c.setLineCap(.round)
        c.beginPath()
        for i in 0...40 {
            let u = Float(i) / 40
            let y = clamp(key.curve(u), -0.4, 1.4)
            let xx = px + CGFloat(u) * (bounds.width - 2 * px)
            let yy = bot - CGFloat((y + 0.4) / 1.8) * (bot - top)
            if i == 0 { c.move(to: CGPoint(x: xx, y: yy)) } else { c.addLine(to: CGPoint(x: xx, y: yy)) }
        }
        c.strokePath()
        drawText(name, bounds.width / 2, bounds.height - 8, color: sel ? C.GREEN : C.DIM, size: 10, align: .center)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - FlareThumb

/// A card showing a pre-rendered flare; picks the picture up from FlareThumbs once it exists.
final class FlareThumb: TapView {
    let key: String
    let label: String

    init(_ key: String, _ label: String) {
        self.key = key
        self.label = label
        super.init(frame: .zero)
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let w = bounds.width
        let h = bounds.height
        fillRoundRect(c, CGRect(x: 0, y: 0, width: w, height: h), 14, Int32(bitPattern: 0xFF0B0B10))
        let b = FlareThumbs.cache[key]
        let th = h - 26
        if let b = b {
            c.saveGState()
            let clip = UIBezierPath(roundedRect: CGRect(x: 0, y: 0, width: w, height: h), cornerRadius: 14).cgPath
            c.addPath(clip)
            c.clip()
            let s = max(w / b.size.width, (th + 8) / b.size.height)
            let dw = b.size.width * s
            let dh = b.size.height * s
            if let cgi = b.cgImage {
                c.draw(cgi, in: CGRect(x: (w - dw) / 2, y: (th + 8 - dh) / 2, width: dw, height: dh))
            }
            c.restoreGState()
        } else {
            drawText("Rendering...", w / 2, th / 2, color: C.DIM, size: 11, align: .center)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { [weak self] in
                self?.setNeedsDisplay()
            }
        }
        fillRect(c, CGRect(x: 0, y: h - 26, width: w, height: 26), Int32(bitPattern: 0xCC000000))
        drawText(label, w / 2, h - 9, color: Int32(bitPattern: 0xFFFFFFFF), size: 12, bold: true, align: .center)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - Toast

/// android.widget.Toast replacement (PORTING_GUIDE rule 15): a small rounded dark label
/// overlay on the key window that fades out after ~2.2s.
final class Toast {
    private static var current: UILabel? = nil

    private init() {}

    static func show(_ text: String) {
        guard let window = appKeyWindow() else { return }
        if let cur = current { cur.removeFromSuperview(); current = nil }
        let lbl = UILabel()
        lbl.text = text
        lbl.textColor = argbToUIColor(C.TEXT)
        lbl.font = sysFont(14)
        lbl.textAlignment = .center
        lbl.numberOfLines = 0
        lbl.backgroundColor = UIColor(red: 34.0 / 255.0, green: 34.0 / 255.0, blue: 40.0 / 255.0, alpha: 0.96)
        lbl.layer.cornerRadius = 16
        lbl.layer.masksToBounds = true
        let maxW = window.bounds.width - 48
        let sz = lbl.sizeThatFits(CGSize(width: maxW, height: .greatestFiniteMagnitude))
        let w = min(maxW, sz.width + 36)
        let h = sz.height + 24
        lbl.frame = CGRect(x: (window.bounds.width - w) / 2, y: window.bounds.height - 160 - h, width: w, height: h)
        lbl.alpha = 0
        window.addSubview(lbl)
        current = lbl
        UIView.animate(withDuration: 0.15) { lbl.alpha = 1 }
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.05) {
            UIView.animate(withDuration: 0.35, animations: { lbl.alpha = 0 }) { _ in
                lbl.removeFromSuperview()
                if Toast.current === lbl { Toast.current = nil }
            }
        }
    }
}
