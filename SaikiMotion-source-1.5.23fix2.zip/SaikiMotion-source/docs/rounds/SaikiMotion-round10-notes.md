# SaikiMotion — Round 10 fix notes
**Input:** round-9 binary 1.5 (13)
**Output:** `SaikiMotion-1.5.14-unsigned.ipa` — the **create-project / app-load
draw crash fixed**, plus a latent string bug and two ownership leaks repaired.

Good news first: 1.5 (13) fixed the register/stack bugs — the draws now run
correctly — and the crash moved *deeper*, into CoreGraphics itself, which
pinpointed the real problem with surgical precision.

---

## Your crash, decoded (incident 367327C9, slide 0x5868000)

```
-[UIView drawLayer:inContext:]
  → IconView.draw (To-thunk)
    → CAVE_ICN_CLEAR+0x60            ← right after `bl CGContextFillRect`
      → CGContextFillRect → draw_rects
        → CACGContextEvaluator::update_with_color(CGColor*, op)
          → CGTaggedColorGetAlpha → CGTaggedColorGetNumberOfComponents
            → _CGHandleAssert → abort (SIGABRT)
```

The crash registers (x8/x9 = `0x2C02…`) are **tagged-pointer words**: the
"CGColor" my round-9 cave set as the fill colour was a *tagged* color whose
format iOS 18.7's CG refuses to decode. Three of my bugs, all now fixed:

### Bug 1 — the colour (the crash)
My cave built `[UIColor colorWithRed:0 green:0 blue:0 alpha:0]` — an all-zero
colour that UIKit canonicalises to a tagged CGColor constant, which CG's
fill-time evaluator asserts on. The app's own working code (e.g. at
`0x100008c88`) never does this: it passes **non-canonical** colours
(`0xFF888888`), performs the `objc_retainAutoreleasedReturnValue` handshake
after `.CGColor`, and releases the `UIColor`. My cave did none of the three.

### Bug 2 — the blend mode
My cave set `SetBlendMode(ctx, 1)` — that's **kCGBlendModeMultiply** (I
intended `.copy` = 17). Multiply wouldn't even clear the ghost pixels.
The correct erase primitive is **kCGBlendModeClear (16)**: dst := transparent,
colour value irrelevant.

### Bug 3 — the CGRect ABI
`CGRect` is an **HFA** on arm64: `[self bounds]` returns it in **d0-d3** and
`CGContextFillRect` takes it in **d0-d3** — proven by the app's own code
(`bl msgSend(bounds); bl CGRectGetWidth` back-to-back, and every `FillRect`
site loading d0-d3 directly). My round-9 cave passed `x1` = a pointer to a
stack slot msgSend never writes, and read nothing from d0-d3: the fill only
worked by luck because no FP-clobbering call sat between `bounds` and
`FillRect`. The new cave stages the rect through the stack, so it survives
any calls.

### Bonus find — the round-7 "hint fix" broke a correct string
Round 7 changed `0x1000190f4` from `sub x8, x8, #0x20` to `add #0x10`,
believing the Scene-Setup hint snack pointed into garbage. With the string
convention now proven (`w1 = tag | bytes−0x20`, UTF8 read at `w1+0x20`), the
*original* encoding was exactly right — round 7 made the snack display
`"ch to zoom."` mid-word. Restored; the full 59-char hint decodes again.

## The fix — clear caves v3 (relocated, 40 instructions each)

```asm
stp  x29, x30, [sp, #-0x50]!
sub  sp, sp, #0x30
movz w0, #0x0302
movk w0, #0xff01, lsl #16         ; argb 0xFF010302 - opaque, never a
bl   argbToUIColor                ;   UIKit constant -> plain heap CGColor
str  x0, [sp, #0x20]              ; keep the +1 UIColor
ldr  x1, [sel "CGColor"]
bl   objc_msgSend                 ; -> autoreleased CGColor
mov  x29, x29                     ; the autorelease-RV marker
bl   objc_retainAutoreleasedReturnValue   ; -> +1 CGColor (the handshake)
str  x0, [sp, #0x28]
ldr  x0, [sp, #0x20]
bl   objc_release                 ; release the UIColor
mov  x0, ctx
bl   CGContextSaveGState
mov  x0, ctx / ldr x1, [sp, #0x28]
bl   CGContextSetFillColorWithColor
mov  x0, ctx / mov w1, #16
bl   CGContextSetBlendMode        ; .Clear
mov  x0, self / ldr x1, [sel "bounds"]
bl   objc_msgSend                 ; -> rect in d0-d3 (HFA)
stp  d0, d1, [sp, #0x10]          ; stage the rect on the stack
stp  d2, d3, [sp]
mov  x0, ctx
ldp  d0, d1, [sp, #0x10] / ldp d2, d3, [sp]
bl   CGContextFillRect            ; erase: dst := transparent
mov  x0, ctx
bl   CGContextRestoreGState
ldr  x0, [sp, #0x28]
bl   objc_release                 ; release the CGColor
add  sp, sp, #0x30
ldp  x29, x30, [sp], #0x50
adrp <replay>, <page>             ; replay the displaced instruction
b    <resume>
```

Caves relocated to fresh `__PATCH` space (`0x1001e6300` / `0x1001e63c0`),
hooks re-pointed, old slots zeroed. SaveGState/RestoreGState also mean the
fill colour and blend mode no longer leak into the icon drawing that
follows.

## Verification — the emulator now runs the REAL colour code

This round exposed the last weakness in my test rig: round 9 modeled
`argbToUIColor` as "return a constant" — so an invalid colour sailed through.
`scripts/r10_verify.py` now **executes the real `argbToUIColor` bytes** (only
`objc_allocWithZone` / `objc_msgSend` are modeled), decodes and slides the
selrefs exactly like dyld, returns `bounds` in **d0-d3**, reads `FillRect`'s
rect from **d0-d3**, and makes every stub model clobber `d0-d7`:

* **T1 — 1.5.13 deltas reproduced**: components (0,0,0,0) → argb 0 (the
  tagged-colour trigger), blend mode 1, zero releases (leak), the raw
  msgSend result passed to SetFillColorWithColor.
* **T2/T3 — 1.5.14 proven**: real draws from both function entries — argb
  `0xFF010302` with components (1/255, 3/255, 2/255, 1.0), the
  retainAutoreleasedReturnValue handshake, exactly two `objc_release`s
  (UIColor + CGColor), SetFillColorWithColor(ctx, cgcolor),
  SetBlendMode(ctx, 16), **FillRect receiving the exact bounds rect through
  d0-d3**, Save/RestoreGState, SP/registers/replay all correct — including
  d8/d9 which are live across the cave in ToolButton.draw.
* **T4** — VDB snack cave re-verified (full preservation, dedup, string pair).
* **T5/T6** — static checks and the four-slide battery.
* Regressions on the 1.5.14 binary: round-8 slide suite **51/51**, round-7
  suite **21/21** (the round-9 draw checks are superseded by the faithful
  rig; its VDB/static checks are covered inside r10_verify). **135 checks
  total this round.**

## Install & test

1. Delete the old app; sign & install `SaikiMotion-1.5.14-unsigned.ipa`.
   Release-notes last line: **"Round-10 build 1.5 (14): create-project/
   app-load draw crash fixed - clear-rect caves now use a safe colour, Clear
   blend and the correct CGRect ABI."**
2. **Launch** — the home screen must render fully.
3. **Create a project** — this is where it crashed; it must open the editor.
4. Re-open the app (load) — no crash.
5. Icon ghosting: toggle play/pause and the quality selector — the swap
   should now genuinely clear (that's what these caves do, now with the
   right blend mode).
6. Scene Setup: the hint snack should read the full "Scene Setup: joystick
   to orbit, drag to pan, pinch to zoom." sentence.

## Known limits (unchanged)

* Blosc VDBs still need re-export (Zip or none) — reason shown on screen.
* Timeline layer dragging (media left/right in time) still open — needs
  on-device confirmation of the drag gating before a safe patch.
