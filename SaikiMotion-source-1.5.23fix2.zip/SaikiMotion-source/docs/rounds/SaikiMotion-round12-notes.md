# SaikiMotion — Round 12 fix notes
**Input:** round-11 binary 1.5 (15)
**Output:** `SaikiMotion-1.5.16-unsigned.ipa` — **native Blosc VDB decoding** (the
real fix for the invisible cloud), a **video-import type fallback**, and the
**Optical Flare tool now opens the full editor with its options**.

You reported three things still broken on 1.5 (15): the VDB comp stays empty
even with Cycles on, videos won't import, and the flare popup is just a title
and a Close button. All three are addressed at the root this round.

---

## 1 — VDB "comp is empty": the missing Blosc decoder, written and installed

**Root cause (proven, not guessed).** Your cloud imports as a timeline clip
(`addVolumeLayer` adds the layer immediately and shows "Volume imported"),
then the *renderer* lazily parses the file on first draw. `SceneRenderer.drawVolume`
constructs `VdbVolume(path:)`, and if parsing fails the volume is simply never
registered — `b.ne` on `volume.ok` jumps to the error snack and returns.
**Nothing draws, in the GL viewport and in Cycles alike** — exactly your
screenshot.

Why does parsing fail? The app's chunk reader only ever speaks zlib: it reads
each value chunk's 8-byte size framing and calls Apple's
`compression_decode_buffer(..., COMPRESSION_ZLIB)`. It also has two explicit
**Blosc rejection gates** — one right after the grid header (`tbnz w0, #2`),
one inside `readValues` (`tbnz w2, #2`) — both throwing
*"This VDB uses Blosc compression. Re-export it with Zip or no compression."*
Blosc is what Houdini, EmberGen and OpenVDB 10 write by default (OpenVDB 10's
own writer uses **LZ4 + byte-shuffle, one block per chunk**), so stock cloud
packs fail on arrival.

**The fix — a real Blosc decoder, compiled into the app:**

* I ported c-blosc 1.21.5's decompression path (fetched and checked against
  the actual sources, including the subtle bits: the codec lives in **flag
  bits 5-7**, `dont_split` in bit 4, splits of `typesize` sub-streams per
  block, stored-raw blocks where `cbytes == neblock`, and the same Int64
  size framing as ZIP — verified against OpenVDB v10's `bloscToStream`).
* It's written in C (`scripts/r12_bdec.c`: BloscLZ + LZ4 codecs, MEMCPYED
  fast path, byte-unshuffle, multi-block, splits), compiled as a freestanding
  1500-byte position-independent ARM64 blob with no external calls, and
  placed in the `__PATCH` cave.
* **Three hooks**: both Blosc gates are NOPed so Blosc chunks flow into the
  existing size-framing path, and the zlib decode call site now routes
  through a 8-instruction dispatcher: `compression & 4` → the new decoder
  (with a 128 KB scratch page in `__PATCHD`), anything else → tail-jump to
  the real `compression_decode_buffer`. ZIP files behave exactly as before.

Half-float grids, `BLOSC|ACTIVE_MASK` files, multi-grid files and the
"too large" limit are all handled by the app's existing logic — which I
re-verified in disassembly down to the register conventions (`x20` = self,
`x28` = compression, value size from the `_HalfFloat` suffix, active-count
from the leaf mask popcount).

**Verified end to end:**
* 16-buffer corpus of *real* c-blosc data (both codecs, shuffle on/off,
  memcpyed, multi-block, leftover block, half-float, 128 KB worst case):
  **16/16 decode byte-exact through the shipped cave bytes** at three ASLR
  slides, with all callee-saved registers and SP preserved.
* Four generated OpenVDB-layout test files (`test_blosc*.vdb` in the
  download folder) — their leaf chunks were extracted and decoded **through
  the shipped cave under the emulator**: every voxel matches, for LZ4,
  BloscLZ, half-float and active-mask variants.
* Zip passthrough: `compression & 4 == 0` reaches the *real* zlib decoder
  with all six arguments untouched.
* Regressions: the round-10 suite passes **63/63** on the 1.5.16 binary;
  the round-11 suite passes **106/106** of its unchanged checks (its three
  "failures" are exactly this round's new hooks and stamp).

**Install `test_blosc.vdb` on your phone and import it** — it is a known-good
Blosc file, so it separates "the decoder works" from "your specific cloud
file has something else". Then import your cloud again: with Cycles off you
should see the volume raymarched in the viewport; with Cycles on it lights
up with the rest of the scene. If a cloud still fails, tell me the exact
snack text (it names the reason now) or send the file.

## 2 — Video import: request the item's own type, not the abstract one

The photo-library path calls
`itemProvider.loadFileRepresentation(forTypeIdentifier: "public.movie")`.
On iOS 16+ that abstract identifier can come back with **no URL and no
error** for items that only register a concrete type (`public.mpeg-4`,
`public.quicktime-movie`, HEVC variants) — the classic "nothing happens".
(Every failure path that *does* fire shows a snack — "Could not read the
item" / "Could not import: …" — and you saw none, which points here.)

**The fix:** `CAVE_VTYPE` wraps that exact call. Before loading it asks the
provider for `registeredTypeIdentifiers.firstObject` — the item's own
concrete type — and requests *that*; if the array or its first entry is
missing it falls back to the original "public.movie". The completion block,
the progress object and the retain/autorelease handshake are passed through
untouched. Emulation covers all three scenarios at two slides, including the
`retainAutoreleasedReturnValue` marker the runtime requires.

This is the standard fix for this failure mode, but it's the one change this
round I could not reproduce locally — if videos still won't import, tell me
**which picker you use (Photos vs Files) and whether any snack appears**, and
I'll chase the copy/async chain next.

## 3 — Optical Flare: the tool now opens the editor with its options

**What you were seeing.** The Optical Flare tool button opens
`showFlareLibrary` — a preset grid whose every cell is produced by
`FlareThumbs.generate`, an **async offscreen-GL thumbnail renderer**. On your
device that renderer produces nothing, so the popup is chrome only: the
"Optical Flare" title and Close. (I confirmed the title/Close strings are the
library's, loaded from the static pool at `0x1001728f0`.) The double-refresh
I shipped in 1.5 (15) couldn't help — there was never anything to refresh.

The app *does* have a complete editor behind it — `openFlareEditor` builds a
tabbed overlay (Presets / Elements / Edit / Global, ~35 parameters across the
global and per-element sections) — but you could never reach it, and its
default tab (Presets) is *also* thumbnail-dependent.

**The fix, two hooks:**
1. `CAVE_FLIB` replaces `showFlareLibrary`'s entry: if the editor already has
   a flare layer it reopens the editor for it; otherwise it does exactly what
   the library's own "Custom" button did — `Flare.builtin()[0]` →
   `addFlare(open: true)` — creating a flare layer (you'll see the flare in
   the viewport immediately) and opening the full editor. Repeat taps reopen
   the editor; no layer spam.
2. `CAVE_FTAB` changes the editor's initial tab from Presets to **Global** —
   plain sliders and toggles, no thumbnails — so the options are on screen
   the moment it opens. Switch to Elements to add/remove flare elements and
   Edit for per-element parameters.

Emulation covers both paths (existing-layer reopen with the +1 retain the
function consumes; the builtin[0] → addFlare(open) chain with balanced
retain/release; the heap-form array fallback through the app's own
`_getElementSlowPath` with its exact register setup — I verified that ABI
against the function's disassembly).

**Honest limit:** the **Presets tab** still depends on the async GL
thumbnail renderer. If you need the 20 built-in presets as a browsable grid,
that renderer is the next target — say the word and send whether the Presets
tab shows empty cells or nothing at all.

---

## Mach-O surgery (round 12)

| # | site | change |
|---|------|--------|
| 1 | `0x100166db8` | `tbnz w2,#2` (readValues Blosc gate) → `nop` |
| 2 | `0x1001697d4` | `tbnz w0,#2` (init Blosc gate) → `nop` |
| 3 | `0x100166e58` | `bl _compression_decode_buffer` → `bl CAVE_BDEC` |
| 4 | `0x100036310` | `bl objc_msgSend` (loadFileRepresentation) → `bl CAVE_VTYPE` |
| 5 | `0x1000222f8` | `showFlareLibrary` entry → `b CAVE_FLIB` |
| 6 | `0x100028b34` | tab store (0) → `b CAVE_FTAB` (stores 3 = Global) |

New caves, all in free `__PATCH` space (verified zero before use):
`CAVE_BDEC` @ `0x1001e6680` (8 insns), the decoder blob @ `0x1001e66c0`
(1500 bytes, 375 insns, zero relocations, zero adrp — fully
position-independent), `CAVE_VTYPE` @ `0x1001e6cc0` (26), `CAVE_FLIB` @
`0x1001e6dc0` (37), `CAVE_FTAB` @ `0x1001e6ec0` (3). Blosc scratch =
`0x1001e8010`..+128 KB in `__PATCHD` (verified free; covers even a
pathological all-active 32³ internal node). All addressing is adrp-based —
no absolute builds (the round-11 static scan still passes). UPDATES[9]
stamp + `Info.plist` CFBundleVersion 15 → **16**.

### Verification — 202 checks this round
* **Round-12 suite (`r12_verify.py`): 29/29** — corpus decode at 3 slides,
  register/SP preservation, zip passthrough with the real stub, the three
  VTYPE scenarios, the three FLIB scenarios, FTAB, and static checks
  (including "shipped blob == fresh compile" and "scratch page zeroed").
* **End-to-end VDB:** 4 generated Blosc files, leaf chunks decoded through
  the shipped cave, all voxels exact.
* **Round-10 suite on 1.5.16: 63/63.** **Round-11 suite: 106/106** of its
  unchanged checks (3 stamp/region checks differ by design — they now see
  this round's hooks and stamp).
* Shipped-IPA checker: the binary inside the IPA is byte-identical to the
  verified work image; version 1.5 (16); all 5 SDK example folders present.

## Install & test
1. Delete the old app; sign & install `SaikiMotion-1.5.16-unsigned.ipa`
   (AltStore/SideStore/Sideloadly/eSign). Release-notes last line must say
   **"Round-12 build 1.5 (16)"**.
2. **VDB:** import `test_blosc.vdb` first (known good) — a small fog volume
   should appear. Then your cloud: visible with the viewport renderer, and
   with Cycles on it should light up. Try your other cloud files too.
3. **Video:** pick a video from Photos (and one from Files if you use that
   path) — a clip should appear in the timeline within a couple of seconds.
4. **Flare:** tap Optical Flare — a flare layer appears and the editor opens
   on the Global tab with sliders. Elements tab → Add element; tap an
   element → Edit tab with its parameters.
5. If anything still fails: for VDB tell me the snack text (or send the
   file); for video tell me Photos-vs-Files and whether a snack appears.

## Known limits (honest)
* The flare **Presets tab** still needs the async GL thumbnail renderer;
  Global/Elements/Edit are fully usable without it.
* Blosc's rarer configurations — bit-shuffle flag, and the snappy/zstd
  codecs — are rejected cleanly (parse error snack) rather than decoded;
  nothing in Houdini/EmberGen/OpenVDB-10 output uses them.
* Video fix is the one change awaiting on-device confirmation (it targets
  the documented iOS 16+ abstract-UTType failure; your photo import working
  through the same machinery is what narrows the remaining suspects).
* Timeline layer dragging (media left/right in time) is still open.
