# SaikiMotion — Round 13 fix notes
**Input:** round-12 binary 1.5 (16)
**Output:** `SaikiMotion-1.5.17-unsigned.ipa` — the **Scene Setup crash
fixed at the root**, **tool switching (Move / Transform) no longer dead-ends**,
and **VDB volumes now tell you when they parse**.

You sent the crash log (incident A265F86E) — every crash you've sent has been
pinpointed within one round, and this one was fully decoded. It also exposed
why "can't switch to movement and rotation" happens, and that fix is in too.

---

## 1 — Scene Setup crash: my round-4 hook passed a stale register into objc

**Your crash, decoded (slide 0x6760000):**

```
PillToggle tap → IconView.touchesEnded → buildUi closure
  → reabstraction thunk (loads the weakly-captured editor, puts it in x20)
  → toggleSceneSetup → [ON path] → buildSetupOverlay
     (entry hooked by round 4) → my trampoline → CAVE_PAD
       → objc_msgSend(x0, "view") → SIGSEGV at 0x500000008
```

The register dump showed the receiver was `0x1001C30A8` — a **static data
address** (inside `XfO.setupTarget`'s outlined storage), whose first word
`0x4FFFFFFF8` was read as an Objective-C isa and dereferenced. In other
words: the joystick-pad hook was msgSending **a leftover register value**
(`x0` — whatever `swift_bridgeObjectRelease` last returned) instead of the
editor.

The editor at that call site lives in **x20** — the Swift `self` register
(provable three ways in the binary: the thunk loads the weak editor and
moves it to x20 before calling; `toggleSceneSetup` addresses its fields via
x20; `buildSetupOverlay` receives self the same way). My round-4 trampoline
trusted x0. Scene Setup has therefore crashed on its **very first tap in
every build since round 4** — the emulation rig of that era modeled the
input registers too kindly, which is why it passed then.

**The fix (two layers):**
1. The trampoline now passes **x20** to the pad creator.
2. A new guard rejects any receiver that isn't a heap object (nil, or
   anything inside the app image itself) **before** objc_msgSend can touch
   it — so even a future register mistake degrades to "no joystick" instead
   of a crash.

Emulated end-to-end at two ASLR slides **including your crash slide**: the
`view` message now goes to the real editor, the 124×124 joystick is created
and added, every register and the stack come back intact, and feeding the
guard **the exact crashing pointer** from your log produces no message send
at all.

## 2 — "When adding text I can't switch to movement and rotation"

I traced the whole switching machinery: the **Move / Transform** tool button
(and Edit/FX/Blend/Speed/Graph/Expression — they share one handler) does
this when tapped:

```
layer = selected()
if layer == nil → show "Select a layer first" and DO NOTHING
tool = 4; showBottom(); refreshPanel()   → the Move/Rotate/Scale panel
```

So whenever the editor's selection is missing, tapping Move silently
dead-ends behind a transient snack — exactly "I can't switch". Adding a text
layer does select it, but anything that clears the selection afterwards
(deselecting in the timeline, deleting a layer, a stale project file) puts
you in that state with no way forward.

**The fix:** when there's no selection and you tap a panel tool, the app now
**auto-selects the last layer of the current scene** (the same layer the
timeline most recently added — using the exact same project/scene/layer
walking code the app itself uses in `addLayer`/`selected`) and then opens
the panel. You still get the original "Select a layer first" snack when the
scene is genuinely empty.

Emulated through the **real** tool-switch thunk and the **real** `selected()`
bytes with a modeled project (3 layers, stale selection): the selection
becomes the last layer, tool 4 is stored, and the flow reaches the panel
refresh; with an empty scene it falls back to the original snack.

## 3 — VDB: volumes now report when they parse

Round 12 shipped the native Blosc decoder (Houdini/EmberGen clouds), and you
still see nothing — but "still not visible" doesn't tell me *which stage*
fails on your file. This round adds the missing telemetry:

* **If a volume parses OK**, you now get a one-time **"Volume parsed"** snack
  the moment it's drawn. Seeing it but no cloud ⇒ the parse is fine and the
  problem is in drawing/visibility — a completely different investigation.
* **If it fails**, the existing snack names the reason (compression, header,
  too large…).
* **If you see no snack at all**, `drawVolume` isn't even running — the layer
  isn't reaching the renderer.

All three outcomes point at a different fix, so your next report pins it.
The round-12 Blosc hooks were re-verified intact in this build (both Blosc
gates still open, the zlib call still routes through the new decoder).

---

## Mach-O surgery (round 13)

| # | site | change |
|---|------|--------|
| 1 | `0x1001d0780` | setup-overlay trampoline rewritten: passes **x20** (Swift self) instead of stale x0 |
| 2 | `0x1001d071c` | new GUARD cave (was `hlt` filler): nil / in-image receivers never reach objc |
| 3 | `0x100024288` | tool-thunk nil-selection snack path → `b CAVE_TSEL` |
| 4 | `0x1001d0818` | new CAVE_TSEL: auto-select last layer of current scene, then rejoin the tool store |
| 5 | `0x10012f404` | drawVolume first insn after the ok-check → `b CAVE_VOK` |
| 6 | `0x1001d0a00` | new CAVE_VOK: one-time "Volume parsed" snack, replays the displaced load |

State: VOK flag byte at `0x100208028` in `__PATCHD` (was free, verified).
UPDATES[9] stamp + `Info.plist` CFBundleVersion 16 → **17**. No app code
bytes touched except the two single-instruction hooks (#3, #5); the byte
diff vs 1.5.16 is confined to exactly the intended regions (verified, 0
stray bytes).

### Verification — 55 checks this round
* **Scene-setup crash path**: full trampoline→guard→pad flow at two slides —
  correct receiver, joystick created/added, registers (x19–x28, d8/d9), SP
  and resume all exact; the **exact crashing pointer** from your log and nil
  both rejected with zero messages sent.
* **Tool switch**: real thunk + real `selected()` bytes over a modeled
  project at two slides — auto-select + tool store verified; empty-scene
  fallback lands in the original snack with the displaced instruction
  replayed.
* **VOK**: exact "Volume parsed" string pair, once-only flag, replayed load,
  callee-saved registers intact even with a fully clobbering Snack model.
* Static: both hooks decode as branches to the caves, all four new code
  blocks round-trip through the assembler, round-12's Blosc hooks intact,
  stamp/count word, zero stray bytes vs 1.5.16.

## Install & test
1. Delete the old app; sign & install `SaikiMotion-1.5.17-unsigned.ipa`.
   Release-notes last line must say **"Round-13 build 1.5 (17)"**.
2. **Scene Setup**: tap the scene icon — it must open with the grid, axes and
   the bottom-left joystick, no crash. Toggle it off/on a few times.
3. **Text + Move:** add a text layer, then tap **Move/Transform** — the
   Move/Rotate/Scale panel should open (it now auto-selects the newest
   layer when nothing is selected). Try the same after deselecting.
4. **VDB:** import your cloud (Cycles on and off) and note **which snack**
   you get, if any: an error reason, "Volume parsed", or nothing — that
   single observation decides the next round's fix. If you can, also try
   `test_blosc.vdb` from the previous round's download (known-good Blosc).

## Known limits (honest)
* "Volume parsed" fires once per app launch (by design — diagnosis, not
  spam).
* The tool auto-select picks the **last** layer; if you expected a specific
  layer, tap it in the timeline first as before.
* Video import and the flare editor keep their round-12 fixes; you didn't
  mention them this round — tell me if either still misbehaves.
* Timeline layer dragging (media left/right in time) is still open.
