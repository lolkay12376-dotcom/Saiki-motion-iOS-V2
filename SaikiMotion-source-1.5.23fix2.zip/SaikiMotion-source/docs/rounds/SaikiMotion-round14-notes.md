# SaikiMotion — Round 14 fix notes
**Input:** round-13 binary 1.5 (17)
**Output:** `SaikiMotion-1.5.18-unsigned.ipa` — the crash you sent is fixed at the
instruction that caused it, **autosave actually saves** (it silently didn't —
that's why the project was empty), a **crash-time emergency save** catches the
next crash, the **grid is back** (a round-12 bug was erasing it), particles /
optic flare / camera layers are **3D and visible in Scene Setup**, video import
**retries** before failing, VDB clouds get a **density boost** so thin clouds
become visible, and Cycles now does **noise-based progressive rendering with a
disk cache**.

You sent eight problems. Seven are fixed in code this round; the eighth
(.abc) is verified healthy in the binary and has a concrete test below.

---

## 1 — The crash you sent (incident D1478F6E): decoded to the exact instruction

Your log showed `SIGSEGV` on the main thread inside `-[GLKView _display:]` →
`SceneRenderer.draw` → our round-5 stroke renderer, faulting **write** at
`0x10020E000`, with PC = `0x1001D433C` — inside our own `__PATCH` code, at
slide `0x6778000`.

**Root cause (proven by diffing the round-5 binaries):** the stroke renderer's
vertex scratch buffer address (`RSCRATCH`, `__PATCHD+0x26000`) was built in
machine code as a bitmask-`mov` + `movk` pair:

```
mov  x20, #0x1ffffe000
movk x20, #0x20, lsl #16     ; x20 = 0x10020E000 — a LINK-TIME constant
```

The round-5 "slide fix" only rewrote builds that start with `movz` — this pair
starts with the bitmask `mov` form, so it was missed and shipped broken in
**every build since round 5**. With any ASLR slide those instructions compute
an unmapped address; the first stroke drawn through that path writes vertices
there and the app dies. **Four** such builds existed (the vertex base, both
`glBufferData` arguments, and the point-joint emitter). All four are now
`adrp` (position-independent). The crash reproduces on the old bytes and
passes on the new ones in emulation at your exact crash slide — and a
full-binary audit for that instruction class now returns **zero** hits.

This also explains "sometimes": the crash fires the moment a Draw-tool /
rotobrush stroke renders, which is usually right when you toggle Scene Setup
(the overlay redraws the editor view one last time).

## 2 — "The project doesn't save, I leave and it's empty" — the autosave never really ran

Round 11 added an autosave to `refreshTitle()`. Its cave read the project id
from **x20 at the function's entry** — but at entry, `self` is in **x0**, and
2 of the 11 call sites leave garbage in x20. The round-11 emulation had
*assumed* x20 = self, so it passed while saving the project under a **garbage
id** (or skipping entirely). Your project file was last written at creation
time — empty.

**Fixed:** the cave now loads `self` from the x0 it saved on entry and reads
the id through the app's own ivar-offset global (`0x1001c51c8`) — the exact
mechanism `viewWillDisappear` uses (verified against its disassembly). It also
saves on **every 2nd edit** instead of every 4th. Emulation includes the
regression case: x20 = garbage, save still fires with the correct
`(id, project)` pair.

## 3 — "Save even when it's about to crash" — a crash-time emergency save

* `refreshTitle`'s autosave caches the current `(id, project)` pair in
  `__PATCHD` on every save.
* On the first autosave the app installs **signal handlers** for SIGSEGV,
  SIGBUS, SIGABRT, SIGILL and SIGFPE (a new `_signal` import was added to the
  binary's chained fixups for this).
* When a fatal signal fires, the handler runs `Projects.save(cached id,
  cached project)` — the same atomic (temp-file + rename) write the app
  always uses, so even a failed attempt cannot corrupt the last good file —
  then restores the default handler so iOS still produces the crash log.
* The handler is one-shot (a busy flag) and does nothing if no pair was ever
  cached. **Also:** toggling Scene Setup — your known crash trigger — saves
  the project *first*, both directions.

Honest limit: calling Foundation from a signal handler is technically
async-signal-unsafe. In practice it either completes or the process dies as
it would have anyway — the previous autosave file survives either way.

## 4 — "Add a grid in Scene Setup" — it was being erased by a round-12 bug

The grid *code* has been there since round 4. But round 12's Blosc decoder
used a scratch page at `__PATCHD+0x10` — **on top of the round-5 grid/
joystick state** (the stored GL context at `0x1001E8010`, the grid's program
and VBO ids, the saved media directory, the stroke store). The scratch looked
"free" because it's zero in the file — it's live runtime state. **Importing
any Blosc VDB (your Houdini/EmberGen cloud) decoded voxel data straight over
all of it**: the stored context no longer matched, so `r4_frame` bailed out
before drawing — grid gone, joystick gone, strokes garbled.

**Fixed:** the decoder's scratch moved to `0x100209000` (genuinely unused),
and the in-loop shuffle-buffer cap was patched in the *verified* round-12
bytes from 128 KB to 56 KB (shuffled blocks only; unshuffled blocks of any
size still decode). Plus two structural improvements:

* **The grid now draws at the END of `draw()`** instead of the beginning —
  background layers can no longer paint over it.
* Emulation proves a shuffled Blosc block decodes through the moved scratch
  **with S_CTX / S_READY untouched**.

## 5 — Particles and optic flare "don't work on Scene Setup" + "move away far"

Scene Setup shows only 3D layers (the round-4 filter). Particle, Optical
flare and Camera layers were created **2D**, so they vanished in Scene Setup
and floated in screen space instead of holding a fixed 3D position.

* `addLayer` now sets **is3d = 1** for `Particles` and `Optical flare` layer
  types (the cave hooks the non-Model type-name path), and the toolbar's
  Particles button (which creates a Shape-typed particle layer) sets the same
  bit. Camera layers already had it.
* New layers of these types now appear at the scene origin, visible from the
  setup camera (orbit distance 5.5), occlusion-correct (round-11's depth test
  applies to 3D particle layers), and they stay put.
* The flare editor, particles panel and timeline keep working as before —
  the only change is the default 3D bit, which you can still toggle per layer
  with the 3D cube.

## 6 — Video import "failed" — now it retries before giving up

Your report + the code point at `loadFileRepresentation` failing. Round 12
made the request use the item's concrete type; some items still fail with
either that *or* the abstract `public.movie`. **CAVE_VTYPE2** now runs a
retry chain through a real (static, copied-on-demand) Objective-C block:

1. try `registeredTypeIdentifiers.firstObject` (round-12 behaviour);
2. if that comes back nil — try the original `public.movie` (round-11
   behaviour);
3. only then forward the failure to the app's own completion (you see the
   app's error snack, as now).

All four paths (concrete success / retry-then-success / retry-then-fail /
no-registered-types passthrough) are emulation-verified, including the block
literal (isa, flags, invoke, descriptor) and cleanup.

## 7 — VDB "still empty" — thin clouds were invisible even when they parsed

`buildDense` converts voxels to the texture with a **fixed** `density × 255`.
A wispy cloud whose densest voxel is 0.05 becomes at most byte 12 — the
raymarcher accumulates almost nothing: *parsed fine, drawn invisible.*
(Over-dense files had the mirror problem: everything clipped to flat white.)

**Fixed:** a one-pass scan of the decoded leaves computes
`gain = clamp(255 / max(density), 255, 2550)` and the per-voxel multiply now
reads that gain from `__PATCHD` (two-instruction patch inside the loop).
Densest voxel → 255 in every file; wispy clouds get up to 10×; empty volumes
default safely. If your cloud *still* doesn't show after this, the round-13
"Volume parsed" snack question stands — tell me which snack you see.

## 8 — Cycles: noise-based progressive rendering + a cache folder

When Cycles is on and the preview is **idle** (same playhead, unchanged
image — checked with a 256×1 probe strip read *before* any of our drawing),
each frame now:

1. copies the fresh render to a texture,
2. blends `mix(accumulated, current + film-grain dither, 1/N)` — visible
   speckle that settles as N grows, like Blender's progressive sampling,
3. stores the result as the new accumulation,
4. after 24 converged frames, **streams the image to your media folder** as
   `cyc_<time-ms>_<W>x<H>.rgba` (64 KB chunks through the shared scratch
   page; the folder is the same one the app created for imported media,
   visible via the Files app),
5. when you return to a cached time point, the converged image is **loaded
   and displayed instantly**.

Any change — playhead move, content change, camera/sun edit, resize, Cycles
off, Scene Setup on, or an export frame — resets or skips the pass. After 48
idle frames it goes dormant (no battery burn). Exports are never touched.
The whole pass is a freestanding ARM64 blob (4 KB) at `0x1001DC400`,
position-independent (0 absolute builds), verified: gating, program build,
per-frame accumulation, reset-on-change, and clean returns at your crash
slide.

## 9 — .abc import — the transcoder is intact; what to check on device

I re-verified the Alembic pipeline end-to-end in the shipped binary: the
`GlbModel.validate` hook, the round-7 displaced-prologue replay, the Ogawa
walker and the GLB writer are all byte-intact, and the round-5 host tests
(sample_mesh / sample_animated) exercised this exact code. Two things I could
not see from here:

* **HDF5 .abc files** (old Houdini/Blender exports) are rejected — Ogawa
  only, which is every exporter's default since ~2016. If your file is old,
  re-export it (Blender: default Alembic = Ogawa).
* If it imports but the layer looks empty, check whether the layer appears in
  the timeline at all and whether the model shows with **Cycles on** — that
  splits a transcode problem from a draw problem.

`sample_mesh.abc` and `sample_animated.abc` (in the download folder from
round 5) are known-good; importing one on 1.5 (18) tells us in one step
which side your file falls on.

---

## Mach-O surgery (round 14)

| # | site | change |
|---|------|--------|
| 1-4 | `0x1001d401c/24`, `0x1001d4384/9c`, `0x1001d43e0/ec`, `0x1001d4464/6c` | RSCRATCH `mov+movk` → `adrp` + `nop` (×4) |
| 5 | `0x1001e668c/90` | Blosc scratch → `0x100209000` (`adrp` + `nop`) |
| 6 | `0x1001e6790/ac`, `0x1001e6bb4/bc` | shuffle cap `0x20010` → `0xE000` (in the verified blob) |
| 7 | `0x1001e6580` | autosave trampoline → new CAVE_AUTOSAVE2 (`0x1001e7d00`) |
| 8 | `0x1001e6f00` | new CAVE_SIGH (crash-time save + SIG_DFL) |
| 9 | `0x100019038` | toggleSceneSetup entry → CAVE_TOGSAVE (save first) |
| 10 | `0x1000214f8` | addLayer non-Model rawValue call → CAVE_IS3D |
| 11 | `0x100022288` | addParticles refreshPanel call → CAVE_PART3D |
| 12 | `0x1001680f8` | buildDense entry → CAVE_VGAIN |
| 13 | `0x100168594/98` | per-voxel `×255` → `×gain` from `__PATCHD` |
| 14 | `0x100036310` → `0x1001e6cc0` | video load → CAVE_VTYPE2 + CAVE_VTINVOKE + static retry block |
| 15 | `0x1001d0410` | entry-hook `r4_frame` → `nop` |
| 16 | `0x1001d0480` | exit cave: strokes → **grid** → **cycles** |
| 17 | `0x1001dc400` | cycles blob (4052 B, position-independent) |
| 18 | fixups | new `_signal` import (#829) + chain entry at `__PATCHD+8` |

New `__PATCHD` state: gain @ `0x100208030`, crash-save cache `0x100208038+`,
video-retry state + block `0x100208060+`, cycles state `0x1002080c0+`. All in
the verified-free tail; the Blosc scratch shares `0x100209000` (same thread,
never overlapping phases). UPDATES[9] stamp + `Info.plist` 17 → **18**.

### Verification — 162 checks
* **r14_verify.py: 152/152** — every fix above, emulated at slides 0 and
  your crash slide (plus 0x5868000): the old-bytes crash reproduced, the
  new bytes land at slide+scratch; autosave with x20=garbage; handler
  install/cadence/cache; crash-save; toggle-save; is3d routing; VDB gain
  (4 density scenarios incl. dirty registers); all four video-retry paths;
  Blosc decode through the moved scratch with r5 state untouched; exit-cave
  order and args; every hook decodes; fixups roundtrip (830 imports,
  `_signal` @ 829, chain `next=2`, bind at +8); byte-diff vs 1.5.17 confined
  to exactly the intended regions.
* **Cycles blob smoke (T12): 10/10** — gating (off/setup/export), program
  build, per-frame accumulation, reset on time/size change, clean returns.
* **Final absolute-build audit: 0** address builds of the crash class remain
  (only the 2 documented folded bitmasks + the intentional slide-recovery
  constant).

## Install & test
1. Delete the old app first (home screen → long-press → Remove App → Delete
   App); disable AltStore/SideStore auto-refresh for it.
2. Sign & install `SaikiMotion-1.5.18-unsigned.ipa`. The release-notes last
   line must say **"Round-14 build 1.5 (18)"**.
3. **The crash:** draw a stroke with the Draw tool, then toggle Scene Setup
   on and off several times — no crash.
4. **Autosave:** make edits, force-kill the app from the app switcher,
   reopen — the edits are there. (This was the empty-project scenario.)
5. **Grid:** with content in the scene (even a background layer), toggle
   Scene Setup — the grid and axes are visible, joystick works.
6. **Particles/flare:** add each — they appear at the center of the 3D scene
   and stay in Scene Setup.
7. **VDB:** import your cloud again — a thin cloud that parsed before should
   now be visible. If not, note the exact snack text.
8. **Video:** import a video — if the first attempt fails you may see a
   beat of nothing, then the clip appears (the retry). Tell me if it still
   fails *after ~5 seconds*.
9. **Cycles:** turn Cycles on, pause on a frame — you'll see fine grain
   settle over ~1-2 seconds; scrub away and back — the clean image returns
   instantly (cache hit). Check the media folder for `cyc_*.rgba` files.
10. **.abc:** try `sample_mesh.abc` first, then your file; tell me whether
    either shows a layer in the timeline.

## Known limits (honest)
* The crash-time save runs Swift/Foundation from a signal handler — best
  effort by design; the atomic write protects the last good file regardless.
* Particle/flare/camera layers now default to 3D; switch the 3D cube off if
  you want the old 2D screen-space behaviour for a specific layer.
* The Cycles cache lives in the media folder (no subfolder — creating
  directories would need another import; one file per converged time).
* VDB gain normalizes to the densest voxel; a single hot voxel in noisy data
  can still leave the rest dim — if your cloud looks speckled-bright but
  thin, tell me and I'll switch to a percentile.
* Blosc shuffled blocks are capped at 56 KB (unshuffled unlimited); real
  leaf chunks are ≤ 2 KB.
* Timeline layer dragging (media left/right in time) is still open.
