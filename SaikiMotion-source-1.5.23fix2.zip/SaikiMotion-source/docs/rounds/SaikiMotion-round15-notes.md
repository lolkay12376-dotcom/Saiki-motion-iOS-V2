# SaikiMotion — Round 15 fix notes
**Input:** round-14 binary 1.5 (18)
**Output:** `SaikiMotion-1.5.19-unsigned.ipa` — the freeze/crash watchdog round.

You reported: *add one thing → freeze, even deleting freezes; VDB shows "bad node
compression flag"; video import never finishes*. Everything above is addressed,
plus the feature you asked for: **crash/freeze logs written to a Crash folder
inside the app's own folder (visible in Files), and a freeze now deliberately
crashes the app so nothing stays wedged.**

---

## 1 — The VDB "bad node compression flag": root cause found and fixed

Your file's grid uses a **`ScaleTranslateMap`** (a non-uniform voxel size —
different resolution per axis). The parser read it with the
`UniformScaleTranslateMap` layout (6 × Vec3d = **144 bytes**) but a
ScaleTranslateMap is a full 4×4 double matrix (**128 bytes**). Every such file
desynced the stream by 16 bytes, and the next thing the parser read as a
buffer's metadata byte was garbage → *"VDB bad node compression flag"*.

**Fixed:** a new CAVE_STMAP reads all 16 doubles (exactly 128 bytes), extracts
translation from m12..m14 and the voxel scale as the column norms of the 3×3
part (the mathematically correct values), stores them into the same fields the
UniformScaleTranslate path uses, and rejoins the parser exactly where the old
path did. Verified in emulation: 32 f32 reads consumed, translation/scale
extracted correctly, error path intact, and the `b.eq` hook only fires for
ScaleTranslateMap (UniformScaleTranslate/Scale/Translation maps are untouched).

(For reference — verified against the real OpenVDB source this round: ZIP=1,
ACTIVE_MASK=2, BLOSC=4, metadata byte 0-6, half grids via the
`_HalfFloat` type suffix, 4-byte inactive values even for half grids. The app's
parser matched everywhere except this one map.)

## 2 — Freezes: watchdog + logs + honest hardening

**The freeze watchdog (your feature request):**
* A background thread ticks every 2 s. The main thread bumps a **heartbeat**
  every drawn frame and every edit.
* After **16 s** with no heartbeat it **pokes** the main thread with SIGUSR2.
  If the thread answers, it was just idle — marked alive, nothing happens.
* If **3 pokes go unanswered (~6 s — the thread is truly stuck)**, the
  watchdog:
  1. snapshots the main thread's registers **at the stuck point** via
     `thread_get_state` (pc, lr, sp, x0-x28),
  2. writes a **FREEZE log** into `<app folder>/Crash/`,
  3. runs the emergency project save (the round-14 crash-time save),
  4. **kills the app** — "when it freezes it needs to crash to prevent further
     problems", exactly as you asked. Restart is clean, work is saved.

**Crash logs (upgraded from round 14):** the old `signal()` handlers became
`sigaction(SA_SIGINFO)` handlers for SIGSEGV/SIGBUS/SIGABRT/SIGILL/SIGFPE.
They write a **CRASH log** using raw `open/write/close` syscalls (safe inside
a signal handler): signal, fault address, saved registers, the raw ucontext
mcontext dump, and everything below. Then the emergency save runs, the default
handler is restored, and iOS still produces its own crash report.

**Every log includes:**
* the app build stamp, tick counter, heartbeat value,
* the **last 24 actions** (edits, video import attempts/results/timeouts,
  scene-setup toggles, layer adds, VDB errors),
* the **last VDB error text** (captured live from the parser's error snack),
* the video-import state.

**Why this also matters:** the "add/delete → freeze" report can now be
diagnosed from the freeze log's stuck-PC — the next report you send will show
*exactly* which function the main thread was inside. (This round's own audit
cleared the round-14 suspects: the autosave call convention matches
`viewWillDisappear` byte-for-byte, and the is3d write `[x25+0x69]` is the same
register+offset the app's own Model/Water path uses.)

**Hardening shipped now:**
* autosave runs on every **4th** edit instead of every 2nd (the emergency save
  and toggle-save protect the data between autosaves),
* the autosave now **retains properly** (an emulation bug in my patch would
  have skipped the retain — caught and fixed before shipping).

## 3 — Video import: copied file + hard timeout

Two failure modes are now covered:
1. **The disappearing file.** `loadFileRepresentation` hands the app a
   *temporary* URL that is deleted the moment the completion block returns.
   If the app's pipeline reads it later, it reads a deleted file and the
   import dies silently — the "importing…" spinner forever. The completion now
   **copies the picked file into the app's media folder** (`imp_NN.ext`) and
   hands the app a **stable NSURL** to the copy. If the copy fails, the
   original URL is forwarded exactly as before.
2. **The never-called completion.** The watchdog enforces a **12-second
   timeout**: it builds a real `NSError` and invokes the app's own completion
   with it, so the spinner always resolves (and the timeout is recorded in
   the logs). The round-12/14 retry chain (concrete type → `public.movie`)
   still runs underneath.

## 4 — Mach-O surgery (round 15)

| # | site | change |
|---|------|--------|
| 1 | `0x1001dd400` | watchdog C blob (7120 B, position-independent, 0 absolute builds) |
| 2 | `0x1001e3c00/0x1001e3d40/0x1001e3de0/0x1001e3e00` | CAVE_STMAP + crash/usr2 stubs + STMap trampoline |
| 3 | `0x10016671c`, `0x100166740` | ScaleTranslateMap `b.eq`/helper hooks → STMAP path |
| 4 | `0x1001e7d4c-70` | autosave: every-4th cadence + edit-tick + `r15_install` |
| 5 | `0x1001d0480` | exit cave: + heartbeat, then strokes/grid/cycles |
| 6 | `0x1001e7800` / `0x1001e7a80` | VTYPE2 rewritten (+attempt marks); VTINVOKE → C logic |
| 7 | `0x1001e7100/300/480` | TOGSAVE / IS3D / PART3D + action-ring hooks |
| 8 | `0x1001e5180` | VDB-error cave also captures the error text |
| 9 | fixups | 12 new imports (#830-841: sigaction, pthread_create/self/kill/mach_thread_np, thread_get_state, open, write, close, mkdir, sel_registerName, objc_getClass) bound into the verified-free `__PATCHD+0x9a0` window |
| 10 | `__PATCHD 0x100217000` | watchdog state block (heartbeat, ring, snapshots, staging) |
| 11 | stamp + Info.plist | 18 → **19** |

## Verification — 71/71 checks (r15_verify.py, unicorn at the user's crash slide)
* fixups: 842 imports, names/libs correct, chain +0→+8→+0x9a0…+0x9f8, roundtrip.
* STMAP: 32 reads = 128 bytes; trans/scale correct; error path; conditional
  hook fires only for ScaleTranslateMap.
* crash stub/body: log opened+written, header/stamp/fault-addr/PC present,
  emergency save with the cached (id, project, retained) triple, SIG_DFL
  restored, x3 saved.
* SIGUSR2: responded flag, pc/lr/sp/x28 snapshot from the ucontext.
* video: retry args (provider/sel/type/block), tried flag, success path
  invokes the app's block, state=ok, pending cleared.
* exit cave: heartbeat increments, strokes/grid/cycles all called.
* autosave: save on the 4th edit only, with correct args incl. the retained
  object; install + edit-tick called once; counter advances.
* VDB error capture: text + length recorded, snack still shown.
* install: 6 sigactions with the right stubs (captured at call time) and
  SA_SIGINFO|SA_RESTART, watchdog thread created, main thread ids recorded,
  idempotent.
* blob entries decode; every bl targets its intended C entry; state page and
  GOT slots untouched in the file; stamp + count word.

## Install & test
1. **Delete the old app first** (home screen → long-press → Remove App →
   Delete App); disable AltStore/SideStore auto-refresh for it.
2. Sign & install `SaikiMotion-1.5.19-unsigned.ipa`. The release-notes last
   line must say **"Round-15 build 1.5 (19)"**.
3. **The Crash folder:** open the Files app → On My iPhone → SaikiMotion →
   **Crash** (created automatically after your first autosave / media import).
   Every crash or freeze drops a readable `*.log` there — send me those files.
4. **Freeze test:** do whatever triggered the freeze before (add a layer,
   delete, etc.). If it truly freezes, within ~25 s the app will close by
   itself and a `freeze_*.log` will be in the Crash folder — send it to me
   and the stuck-PC inside tells us exactly what to fix next.
5. **VDB:** import your cloud again — the "bad node compression flag" error
   should be gone (it was the non-uniform-scale map). If a *different* error
   appears, send me its text — every error is now also recorded in the logs.
6. **Video:** import a video. Either it appears (copied into the media folder
   as `imp_NN`), or within ~12 s you get a visible failure instead of an
   eternal spinner — and the log tells us which attempt failed.
7. Note: if the app is *idle but healthy* (you just stare at it), the
   watchdog pings the main thread first and does nothing — it only acts when
   the thread genuinely stops responding.
