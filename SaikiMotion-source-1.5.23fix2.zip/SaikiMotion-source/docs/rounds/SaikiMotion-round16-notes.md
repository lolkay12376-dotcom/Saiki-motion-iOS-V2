# SaikiMotion — Round 16 fix notes
**Input:** round-15 binary 1.5 (19) — byte-identical to the shipped 1.5.19
**Output:** `SaikiMotion-1.5.20-unsigned.ipa` — **the freeze is gone, big VDB
clouds import without crashing the phone, there is a dedicated
"Import Alembic (.abc)..." button, and Scene Setup now shows every layer.**

You reported four things; all four are addressed this round.

---

## 1 — "Whenever I do anything, after a few moments the app freezes and
LiveContainer freezes" — the round-14 Cycles add-on, removed

Round 14 added a "progressive refinement + disk cache" pass that ran on every
preview frame from the draw-exit cave whenever Cycles was on. On paper it was
a film-grain effect with a cache; on a phone it was a freeze machine:

* **Every frame** it issued a 256×1 `glReadPixels` probe — on a tile-based
  mobile GPU each readback forces a full pipeline flush, so the preview
  thread stalled dozens of times per second while you interacted.
* While a frame was "idle" (you stopped touching it for ~0.4 s) it copied the
  **whole screen twice per frame** through two `glCopyTexImage2D` passes.
* At every converged playhead position it **read the entire framebuffer back
  and wrote ~12 MB to your media folder** (`cyc_<ms>_<W>x<H>.rgba` — 211
  chunked glReadPixels + fwrite calls on the render thread), and read + re-
  uploaded the same 12 MB every time you scrubbed back onto a cached time.
* It wrote **one such file per millisecond-position of the playhead** —
  a few minutes of scrubbing with Cycles on = **gigabytes** of `cyc_*.rgba`
  files filling the disk.

That is exactly your symptom: "a few moments" after you stop doing anything
(≈24 idle frames), a multi-second synchronous 12 MB write lands on the UI
thread — and because the app runs inside LiveContainer's process, the whole
container freezes with it. The disk full of cache files also aggravated the
VDB crash (§2).

**The fix:** the exit cave's `bl r14_cyc_frame` (0x1001d04b4) is now a `nop`.
The app's own Cycles renderer is untouched — only my round-14 noise/cache
add-on is disabled. Verified in emulation at three ASLR slides: strokes and
the Scene-Setup grid still run from the exit cave, the Cycles blob is **never
entered**, and the caller's registers come back exactly as before.

**About the files already on your phone:** deleting the old app before
installing (step 1 below, mandatory anyway) wipes the app sandbox — including
every `cyc_*.rgba` file. Nothing else is needed to clean them up.

## 2 — "Import VDB crashes my phone" — the leaf decoder had no budget

What happens on import: the layer is added immediately, then the renderer
**lazily parses the file on first draw, on the main thread**. The parser
decodes **every leaf** of the grid into a Swift `[Float]` — 512 voxels, 2 KB
per leaf, plus object overhead. A real Houdini/EmberGen cloud has 100,000 –
2,000,000 leaves:

| cloud | leaves | decoded [Float] data | on-device result |
|---|---|---|---|
| small test cloud | ~1–8 K | 2–16 MB | fine |
| typical stock cloud | ~100 K | 200 MB+ | **jetsam kill** ("crashes my phone") |
| dense 1000³ cloud | ~2 M | 4 GB | instant kill |

Even before the memory wall, minutes of chunk-decode on the main thread gets
the app killed by the watchdog. The dense texture the renderer actually uses
only samples ~129³ points — decoding every leaf is pure waste.

**The fix — budget + geometric decimation** (CAVE_VCAP, hooked at
`readOneLeaf`'s entry 0x10016757c):

* leaves 1–8192 decode at **full detail** (4M voxels, 16 MB);
* past that, the keep-rate halves, then quarters, then… (stride = next power
  of two of `seen/8192`), so a 400K-leaf cloud decodes ~1/64 of its tail;
* a **hard cap of 16M decoded voxels (64 MB)** drops everything beyond it;
* dropped leaves return the shared **empty-array singleton** — which
  `buildDense` and the round-14 gain cave already handle (density 0, skip),
  so nothing downstream sees a difference;
* the counters reset at the tree-walker's entry (CAVE_VRST, 0x1001678e8), so
  every import starts fresh.

Because the dropped leaves are spread through the file (not a corner of the
volume) and the round-14 **gain normalization** keys on the densest voxel,
the cloud keeps its shape and brightness — it is just sampled more coarsely.
Both leaf paths (masked and unmasked) route through the same function, so
both are covered.

Verified: keep/drop decision at 14 boundary cases (including the exact 8192nd
leaf, each stride change, and the 16M cap), argument/SP/error-register
preservation on both paths, the counters' arithmetic, the walker reset, and
an end-to-end run where a dropped leaf lands in the caller's
`leaf.values` slot as the empty singleton.

## 3 — "Add import .abc button" — done

Alembic import has worked since round 3 **through** "Import Model (.glb)"
(the picker accepts `.abc`; the `GlbModel.validate` hook sniffs the Ogawa
magic and transcodes to GLB) — but nothing in the UI ever told you that.

The environment section now has a fourth button, between
"Import Volume (.vdb)..." and "Create Water Plane":

> **Import Alembic (.abc)...**  (cube icon, same tint as the other imports)

It is built by CAVE_ABCBTN — a transcription of the exact PillButton
construction the app uses for its own buttons (same closure box, same
`initWithFrame:` super-init, same title/icon/tint ivar writes, same
`addArrangedSubview` + height constraint), hooked at the start of the
Create-Water-Plane block (0x1000267e4) so it lands in the same stack view.
Its tap closure (CAVE_ABCFN) calls the app's own environment-import
dispatcher with the model-import tag — the same call "Import Model (.glb)"
makes — so picking any `.abc` file transcodes and imports it exactly as
before.

This was the hardest cave of the round and it caught **two real bugs before
shipping** (both register-lifetime mistakes that only an ABI-faithful
emulation exposes — the same class as the round-15 crash): the first draft
held the button pointer and the icon-slot pointer in caller-saved registers
across calls; the shipped version keeps them in x21/x23/x24, which I proved
dead at the hook point by walking the water-button block that follows.
The emulator (every modeled call trashes x0–x17/d0–d7) verifies the full
construction: title "Import Alembic (.abc)..." (24 chars), "cube" icon,
tint, handler pair, super-init, pad(4,0,4,0), add-to-stack, height
constraint = the live d8, `setActive(1)`, and — critically — that
x19/x20/x22/x25/x26/x27/x28/d8 all survive, the displaced `mov x0, x25`
replays, and the **real water-button instructions then execute cleanly on
top of the cave's leftovers** (T7b).

## 4 — "I can't toggle to objects in 3D" — two causes, both fixed

* **The freeze (§1)** made every toggle unresponsive a few moments into any
  session — including the Scene-Setup toggle and the eye buttons. With the
  Cycles pass gone, the UI stays responsive.
* **The 3D-only filter**: since round 4, Scene Setup hid every layer that
  wasn't 3D (my design decision, not yours). A project of 2D media/text
  layers showed an empty stage — "no objects in 3D". The filter's skip
  branch (0x1001d02e0) is now a `nop`, so **Scene Setup shows every layer**:
  3D content in the scene as before, 2D layers in screen space — exactly
  how After Effects' 3D comp view behaves. The eye toggles now visibly work
  in the 3D view, exports are unchanged (the filter only ever ran with Scene
  Setup on, on the preview context), and the grid/joystick/camera are
  untouched.

---

## Mach-O surgery (round 16)

| # | site | change |
|---|------|--------|
| 1 | `0x1001d04b4` | `bl r14_cyc_frame` → `nop` (Cycles cache pass disabled) |
| 2 | `0x10016757c` | `readOneLeaf` entry → `b CAVE_VCAP` (0x1001e71c0, 27 insns) |
| 3 | `0x1001678e8` | tree-walker entry → `b CAVE_VRST` (0x1001e7180, 4 insns) |
| 4 | `0x1000267e4` | water-button block start → `b CAVE_ABCBTN` (0x1001e7b40, 108 insns) |
| 5 | `0x1001d02e0` | CAVE_3D skip branch → `nop` (Scene Setup shows all layers) |
| 6 | `0x1001e73c0` | new CAVE_ABCFN tap closure (5 insns) |
| 7 | `0x1001e73e0` | "Import Alembic (.abc)..." literal (32 B) |
| 8 | `0x1e43cc` / `0x1c4b68` | UPDATES[9] stamp → "Round-16 build 1.5 (20)…" (109 B) |
| 9 | `Info.plist` | CFBundleVersion 19 → 20 |

New `__PATCHD` state: leaf counters at `0x100217000/8` (verified free —
after the Blosc scratch, zero in the file). All five patch sites are one
instruction each; every new cave is adrp-based (a full `__PATCH` scan shows
**0** absolute image-range builds, before and after) and contains **zero**
indirect branches (the round-15 `blr x8` bug class is structurally
impossible in them).

### Verification — 183 checks (r16_verify.py)
* **T1–T5 VDB budget:** keep path resumes into the real `readOneLeaf` body
  with args/SP intact; drop path returns the empty-`[Float]` singleton with
  SP and the error register untouched; 14 decimation/cap boundary cases
  exact; walker reset zeroes both counters and replays its prologue; an
  end-to-end caller stores the singleton into `leaf.values`.
* **T6–T7b .abc button:** the closure calls the app's dispatcher with
  (box, "glb", 53); the construction cave produces the exact title/icon/
  tint/handler/super-init/pad/add/constraint/activate sequence, preserves
  every live register, replays the displaced instruction — and the real
  water-button code then runs to completion on the cave's leftovers.
* **T8 filter:** setup on + non-3D layer now draws (was: skipped); setup
  off unchanged; x0/x1 restored through the cave frame.
* **T9 cycles:** exit cave reaches the draw epilogue, strokes + grid run,
  **cycles never runs**, caller registers restored.
* **T10 regressions:** autosave + the round-15 signal installer, the
  crash-time save, the VDB gain hook, the Blosc dispatch, both readOneLeaf
  callers, RSCRATCH adrps and CAVE_IS3D all byte-identical/behavioral.
* **T11/T12 static:** all five hook words decode; 144 new cave words round-
  trip; stamp/count; **byte-diff vs 1.5.19 confined to exactly the intended
  regions — zero stray bytes**.
* Final gates on the shipped IPA: binary sha256-identical to the verified
  work image, version 1.5 (20), all five patch sites + the button literal
  verified inside `SaikiMotion-1.5.20-unsigned.ipa`.

## Install & test
1. **Delete the old app first** (home screen → long-press → Remove App →
   Delete App); disable AltStore/SideStore auto-refresh for it. This also
   wipes the `cyc_*.rgba` files the round-14 build wrote.
2. Sign & install `SaikiMotion-1.5.20-unsigned.ipa` with your usual tool
   (SideStore / AltStore / Sideloadly / eSign). The release-notes last line
   must say **"Round-16 build 1.5 (20): freeze fixed, VDB big clouds safe,
   .abc import button, Scene Setup shows all layers."**
3. **The freeze:** with Cycles on, edit and pause — the app must stay
   responsive and the container with it; scrub the timeline — no
   multi-second stalls; check the media folder — no new `cyc_*.rgba` files.
4. **VDB:** import your biggest cloud — it should parse (the "Volume
   parsed" snack) and render instead of killing the app; very large clouds
   now import slightly coarse rather than crashing.
5. **.abc:** environment panel → **Import Alembic (.abc)...** → pick
   `sample_mesh.abc` (known-good, in the download folder) or your own
   Ogawa-flavour `.abc` — a model layer appears.
6. **Scene Setup:** toggle it on with a 2D-heavy project — your media/text
   layers are now visible (screen-space, AE-style) along with the 3D
   content; the eye toggles hide/show them live.
7. If anything still misbehaves, send the snack text / crash log as before.

## Known limits (honest)
* The Cycles **film-grain** effect and its converged-frame cache are gone
  (they were the freeze). Cycles rendering itself is unchanged. If you want
  the grain back as a cheap, safe effect, that's a future round.
* VDB decimation: clouds past 8,192 leaves are sampled progressively
  coarser (up to 1/64 at ~400K leaves) and hard-capped at 64 MB of decoded
  voxels. Shape and brightness are preserved; fine interior detail in
  gigantic clouds is thinned.
* 2D layers in Scene Setup draw in screen space over the 3D view (After
  Effects behaviour); they do not orbit with the camera.
* The crash-time emergency save still runs Foundation from a signal
  handler — best-effort by design; the atomic write protects the last good
  file either way.
* Timeline layer dragging (media left/right in time) is still open.
