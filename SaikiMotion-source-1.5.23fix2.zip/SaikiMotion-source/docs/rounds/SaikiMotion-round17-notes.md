# SaikiMotion — Round 17 fix notes
**Input:** round-16 binary 1.5 (20) — byte-identical to the shipped 1.5.20
**Output:** `SaikiMotion-1.5.21-unsigned.ipa` — **the video-import crash and
the stuck "Importing…" are fixed, the .abc button no longer corrupts memory,
and the freezes that followed both are gone.**

You sent two crash logs this round; both decoded to bugs introduced by my own
earlier patches, and both are fixed at the root this round.

---

## 1 — Decoding your logs

**Log 1 — `-[NSURL isCancelled]: unrecognized selector sent to instance`**
The exception's stack, symbolized against the binary's own symbol table:
frame "WelcomeViewController.UPDATES + 114200" = **0x1001E7AC8 — the
instruction right after `blr x8` inside CAVE_VTINVOKE**, my round-14
video-import completion block. So: PhotosUI delivered the
`loadFileRepresentation` completion on its background queue → my block →
`blr x8` → UIKitCore code running with the picker's NSURL where a task
object belongs → `isCancelled` sent to an NSURL → crash.

**Log 2 — SIGSEGV in `objc_msgSend+172` during touch delivery**
(`setTranslatesAutoresizingMaskIntoConstraints:` on a garbage object, called
from the environment-panel build path, 9 seconds after launch.) That is the
aftermath of **two** different memory corruptions — see §2 and §3.

## 2 — "Import video says importing and never imports" + the crash:
the video-import hook never owned anything (since round 12)

The hook chain (round 12, rebuilt round 14): the app's
`picker(_:didFinishPicking:)` calls
`[provider loadFileRepresentationForTypeIdentifier:completionHandler:]` at
0x100036310; that `bl` was redirected to my trampoline (0x1001e6cc0) so the
load could be retried with the item's registered type identifier instead of
the abstract "public.movie". The round-14 implementation of that idea stored

* the item provider,
* the original type string, and
* the app's completion block

as **raw, unretained pointers in a single global state block**, then re-issued
the load with its own static block. Three fatal consequences:

1. **The app's completion block is freed while the load is in flight.**
   The app creates the block with `_Block_copy` (+1), passes it to the call,
   and does `bl _Block_release` on it **right after the call returns**
   (0x100036344 — visible in the app's own code). In the unpatched app that
   is safe because Foundation's `loadFileRepresentation` copies the
   completion for the duration of the load. Under my hook, Foundation copied
   *my* block instead — nothing retained the app's — so the moment the
   picker delegate returned, the block was deallocated. When the load later
   completed, my invoke cave did `ldr x8, [freed+0x10]; blr x8` — reading an
   "invoke pointer" out of whatever reused the memory. 32-byte heap slots get
   reused constantly; when the reuser was another block whose invoke lives in
   UIKitCore, UIKit code ran with `(self, NSURL, error)` as its arguments —
   your `-[NSURL isCancelled]` crash, byte-for-byte the exception stack. When
   the reuser was anything else, the `blr` jumped to a non-code address —
   SIGSEGV. And when the wild call "survived", it scribbled through live
   objects — **that is the heap corruption behind "crashes and freezes on
   everything"**: a corrupted object dies at the next message send, e.g.
   during touch delivery (your log 2).
2. **The retry used the app's original type string — also freed.** On a
   first-load failure the cave re-called `loadFileRepresentation` with the
   stored "public.movie" NSString, which the autorelease pool had long since
   popped. A provider asked to match a dead identifier never delivers —
   **the app's "Importing" progress spins forever**.
3. **One global state block.** Picking a second item (or re-importing while
   the first was in flight) overwrote the first item's state: the wrong
   completion ran, or none did — more hangs and corruption.

### The fix — CAVE_VTYPE3 + CAVE_VTINVOKE3 (ownership-correct rewrite)

Same trampoline, same hook site, new caves (at the old caves' addresses,
0x1001e7800 / 0x1001e79a0, dead r14 code zeroed):

* a **4-slot table** in `__PATCHD` (0x100217040, runtime-initialized only —
  the file stays zero): per slot the provider, the completion
  (`_Block_copy`), and the original type (`objc_retain`) are all **properly
  retained**, plus the selector, a tried-flag, and the slot's **own block
  literal** (`__NSConcreteStackBlock` isa, invoke = CAVE_VTINVOKE3,
  descriptor {0, 40}, capture = the slot pointer — Foundation's `Block_copy`
  of the literal carries the capture to the heap copy, which is how the
  invoke knows its slot). Concurrent imports each get their own state;
* the app's completion is invoked **while provably alive and while the temp
  URL is still valid** (synchronously inside the load's completion, on the
  same queue the load used — the app's own `importPickedVideo` already hops
  to the main thread for UI itself, which round-12's disassembly shows);
* a first failure retries **once** with the retained original type; the
  second failure forwards `(nil, error)` — the app always gets its
  completion, so the "Importing" HUD always resolves (success or error
  snack);
* after the app's completion returns, all three references are released and
  the slot is cleared (provider first, completion last, so the allocator's
  both-zero scan can never see a half-cleared slot);
* **no free slot → passthrough**: the app's original call is issued
  untouched (pre-hook behaviour — Foundation then owns the completion
  correctly). Saturation degrades to "no type fallback", never to danger;
* the cave **returns nil**. The app retain+releases the call's return value
  (`x24`) but never reads it — r12/r14 used to `retainAutoreleasedReturnValue`
  the void call's leftover x0, i.e. retained garbage; nil is strictly safer
  and the app's real tail instructions (`mov x29,x29; bl RARV; mov x24,x0;
  …; objc_release(x24)`) are verified on it (T8).

## 3 — The environment-panel crash: my round-16 ".abc" button cave
overwrote the new button's **isa**

Your log 2's reliable frames: a layout helper `objc_msgSend`ing
`setTranslatesAutoresizingMaskIntoConstraints:` on a garbage object, called from
the environment-panel construction — with the faulting address pattern of a
corrupted class pointer. The cause was mine: CAVE_ABCBTN read the
TapView.onClick handler ivar offset from **page 0x1001c5000+0x70** — a
one-digit typo for the app's own **0x1001c9000+0x70**
(`_$s11SaikiMotion7TapViewC7onClickyycSgvpWvd`, file value **8**; the app's
own `pill(…click:)` factory at 0x100072094 reads exactly that slot).

`[0x1001c5070]` is unrelated Dlg data whose value is 0 — so on device the
cave stored the (function, box) handler pair at **btn+0 / btn+8 — over the
button's isa and flags**. Every environment-panel open manufactured a
button whose class pointer was a code address; the next message send to it
walked code bytes as a class and crashed exactly like your log. (The
round-16 emulator missed it because r16_verify *pre-loaded the wrong slot*
with a guessed offset of 0x40 — garbage in, garbage out. This round's
regression re-run preloads the real slot with the real value 8.)

**The fix: one instruction** — the `adrp` at 0x1001e7c1c retargeted from
page 0x1001c5000 to 0x1001c9000. The handler pair now lands at btn+8, the
button's isa is untouched, and the cave otherwise behaves exactly as
verified in round 16.

## 4 — Why everything froze

Both bugs corrupt memory rather than crash cleanly, so the damage surfaced
later, anywhere: touch delivery, panel builds, the timeline. With the
video chain owning its references and the .abc button writing to the right
ivar, the corruption sources are gone. The round-16 freeze fix (Cycles
cache pass) is untouched and still in place.

---

## Mach-O surgery (round 17)

| # | site | change |
|---|------|--------|
| 1 | 0x1001e7800 | dead r14 C_VTYPE2 → **CAVE_VTYPE3** (94 insns) |
| 2 | 0x1001e79a0 | dead r14 C_VTINVOKE → **CAVE_VTINVOKE3** (44 insns) |
| 3 | 0x1001e7a50–0x1001e7b20 | dead r14 tail zeroed |
| 4 | 0x1001e7c1c | `adrp x8, 0x1001c5000` → `adrp x8, 0x1001c9000` (the .abc fix) |
| 5 | 0x1e43cc / 0x1c4b68 | UPDATES[9] stamp → "Round-17 build 1.5 (21)…" (109 B) |
| 6 | `Info.plist` | CFBundleVersion 20 → 21 |

Unchanged: the 0x100036310 hook and its trampoline (still `b 0x1001e7800`),
every other round's caves and hooks. New runtime state: 4 slots + 4 block
literals + descriptor at 0x100217040–0x100217190 (file-zero; past the
Blosc scratch which ends at 0x100217000, past the round-16 leaf counters).
All new code is adrp-based (zero absolute image builds), calls only the six
imported runtime stubs (objc_msgSend / retain / release /
retainAutoreleasedReturnValue / _Block_copy / _Block_release), and contains
exactly **one** indirect branch — the completion `blr x8` on a pointer that
is retained in the slot and guarded by a nil-check.

## Verification — 317 suite checks + 27 final-gate checks (344 total)

**r17_verify.py — 131 checks**, at 3 ASLR slides, with a new
refcount/autorelease-pool ownership model (every modeled call clobbers
caller-saved registers, r15-hardening):

* **T0 repro on the 1.5.20 binary**: after the app's release + pool drain,
  the old invoke cave `blr`s into the fake-NSURL the freed block's memory
  became and the emulation faults exactly like your crash; the old retry is
  shown issuing the load with the dead type identifier (the stuck
  "Importing").
* **T1–T5**: happy path (concrete type → url forwarded, everything
  released, slot cleared, literal/descriptor exact); retry with the
  **live** retained type; double failure → `(nil, error)`; no-registered-
  types → single load, tried pre-set; **the torture test** — app release +
  full pool drain before the completion fires, and the completion still
  delivers on a live block (the core regression).
* **T6–T7**: two concurrent imports (per-slot literals, no crosstalk);
  saturation → clean passthrough with Foundation owning the block.
* **T8–T9**: the app's real post-call instructions on our nil return;
  x19–x28/d8–d15 preserved through both caves.
* **T10–T12 statics**: both caves decode; adrp pages and bl targets exact;
  exactly one guarded indirect branch; dead tail and state region zero;
  trampoline unchanged; stamp; **byte-diff vs the shipped 1.5.20 confined
  to [0x1e7800,0x1e7b20) + the one adrp word + the stamp — zero stray
  bytes**; the .abc cave now reads [0x1001c9070] (=8).

**r17_r16regress.py — 186 checks**: the complete round-16 suite re-run on
this binary with the handler-slot preload **corrected** — VDB budget,
.abc button construction (handler pair at btn+8, **isa untouched** — the
crash-fix proof), Scene-Setup filter, Cycles nop, autosave/signal,
Blosc/VGAIN hooks, plus the r16 byte-diff vs 1.5.19.

Final gates on the shipped IPA: binary sha256-identical to the verified
work image, CFBundleVersion 21, trampoline + adrp fix + stamp verified
inside `SaikiMotion-1.5.21-unsigned.ipa` — plus a fresh emulation of the
**shipped bytes** (VTINVOKE3 forwarding + slot clearing at two ASLR
slides) and a bundle-level diff proving only SaikiMotion + Info.plist
changed vs 1.5.20.

## Install & test

1. **Delete the old app first** (mandatory, as always — it also clears any
   half-imported media from the corrupted sessions). Disable auto-refresh
   for it.
2. Sign & install `SaikiMotion-1.5.21-unsigned.ipa` (SideStore / AltStore /
   Sideloadly / eSign). The release-notes last line must say **"Round-17
   build 1.5 (21): video import crash + stuck import fixed, .abc button
   corruption fixed, stable again."**
3. **Video import** (the main test): import a video — it should finish and
   appear (or show its error snack), never hang at "Importing…". Then
   import a second video while the first is still importing — both should
   land. Try a multi-select pick if you have one.
4. **Environment panel**: open it — no crash. The "Import Alembic
   (.abc)…" button should appear and open the model picker as before.
5. **General stability**: edit, scrub, toggle Scene Setup, open/close
   panels for a few minutes — no freezes, no random crashes, and
   LiveContainer should stay responsive throughout.
6. If anything still misbehaves, send the snack text / crash log as before.

## Known limits (honest)

* The type-fallback chain still makes at most two load attempts
  (registered type, then the app's original); an item whose provider never
  delivers at all (e.g. an iCloud item stuck pending) will surface an
  error snack rather than hang — that is the app's own behaviour for such
  items.
* A slot is occupied until its load completes; four concurrently stalled
  loads (not failed — failed ones always clean up) would make the next
  import use the passthrough path (no type fallback, still safe).
* Everything from earlier rounds' "known limits" that this round didn't
  touch still applies (timeline layer dragging, screen-space 2D layers in
  Scene Setup, best-effort crash-time save).
