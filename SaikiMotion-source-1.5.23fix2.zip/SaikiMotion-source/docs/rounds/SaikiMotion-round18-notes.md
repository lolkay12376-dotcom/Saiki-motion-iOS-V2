# SaikiMotion — Round 18 fix notes
**Input:** round-17 binary 1.5 (21) — byte-identical to the shipped 1.5.21
**Output:** `SaikiMotion-1.5.22-unsigned.ipa` — **the "why does it still crash /
why am I on an old version" round. The crash log you sent proves your phone is
not running the new builds at all — and this round fixes the reason.**

---

## 1 — What your crash log actually showed (the big discovery)

Your `Crash.ips.ips` (Nov 1, LiveContainer, 2.45 s after launch, during touch
delivery): SIGSEGV reading `0x1001e8068`, PC inside our patch region
`0x1001D4FEC`. I decoded the exact instructions the CPU executed from the
log's embedded byte stream:

```
mov  x20, #0x8468
movk x20, #0x1e, lsl #16
movk x20, #1, lsl #32     ; x20 = 0x1001E8468 — an UNSLID link-time address
sub  x8, x20, #0x400
ldr  x8, [x8]             ; read at 0x1001E8068 -> unmapped -> crash
```

That absolute `mov/movk` pointer build is the **round-5 crash class** — and it
exists in **exactly one build we ever shipped: 1.5.8** (round 5). Every build
since 1.5.9 contains the position-independent `adrp` fix at that exact
instruction (I verified all fourteen builds byte-by-byte).

**So the binary that crashed on your phone is 1.5.8.** Your phone has been
running the round-5 build this whole time — which also explains why the
problems you kept reporting (freezes on add/delete, video stuck at
"importing", VDB errors) matched the *original* app's behavior: that is what
1.5.8 still contains.

## 2 — Why the phone never updated (and why you saw "1.5.19")

Two of my mistakes, compounding since round 5:

1. **The version label never changed.** `CFBundleShortVersionString` has been
   the string **"1.5" in every single build** — the original app's value,
   untouched. I only bumped `CFBundleVersion` (8, 9, … 21), which is not what
   LiveContainer shows or compares. With "1.5" == "1.5" on every import, the
   app list keeps showing an old version and an update is indistinguishable
   from what's installed — the old binary stays.
2. **The binary UUID never changed either.** Every build since round 5 shares
   the same `LC_UUID` (`41652dc4-…`), so no crash log could ever tell which
   build it came from (that's why this took a byte-level decode of the log's
   instruction stream to untangle).

The "why you have me 1.5.19": the version you see in LiveContainer is
whatever the *stuck old copy* reports — the number was meaningless. Each
build number is one fix round (1.5.19 = round 15, 1.5.21 = round 17).

## 3 — What 1.5.22 changes

| # | what | detail |
|---|------|--------|
| 1 | **Real version labels** | `CFBundleShortVersionString` "1.5" → **"1.5.22"**, `CFBundleVersion` → **"22"**. LiveContainer now shows and compares a real, increasing version — installs can't be confused with the old copy anymore. |
| 2 | **Fresh LC_UUID** | `FAF72BE1-21B1-57F5-B758-72DDE08E6351`. Any future crash log identifies the exact build — no more guessing. |
| 3 | **State collision fix (found this round)** | The round-16 VDB leaf counters (`0x100217000/8`) were sitting **on top of** the round-15 watchdog's heartbeat/last-alive fields, and the round-17 video slots (`0x100217040-0x100217190`) were sitting **on top of** the watchdog's action ring. Once 1.5.22 actually runs, a big VDB import would have corrupted the freeze-watchdog's state (false "freeze" kills), and video imports would have scribbled over the diagnostics ring. Both relocated: counters → `0x1002171F8/0x100217200` (dead space inside the watchdog page), video slots/literals/descriptor → `0x100217E00-0x100217F50` (the free `__PATCHD` tail). |
| 4 | Stamp | UPDATES[9] last line → "Round-18 build 1.5.22: install/update fixed (old builds were stuck), watchdog state fixed, launch crash fixed." |

The launch-crash instruction itself has been fixed since 1.5.9 — it crashes
only on the stuck 1.5.8 copy. Nothing else in the binary changed: the byte
diff vs the shipped 1.5.21 is confined to **eleven words** (5 counter offsets
+ 6 slot-base immediates), the stamp, the UUID, and the Info.plist.

## 4 — Mach-O surgery (round 18)

| # | site | change |
|---|------|--------|
| 1 | `0x1001e7184` | `stp xzr, xzr, [x9]` → `stp xzr, xzr, [x9, #0x1f8]` (VRST counter reset) |
| 2 | `0x1001e71c4/cc/d0/d8` | VCAP counter loads/stores → offsets `#0x1f8`/`#0x200` |
| 3 | `0x1001e7800` | CAVE_VTYPE3 regenerated (slot base `#0xE00`, literals `#0xEA0`, descriptor `#0xF40`) |
| 4 | `0x1001e79a0` | CAVE_VTINVOKE3 regenerated (same three immediates) |
| 5 | `0x1e43cc` / `0x1c4b68` | stamp + count word |
| 6 | `0xd68` | fresh LC_UUID |
| 7 | `Info.plist` | both version fields → 1.5.22 / 22 |

Hook words, cave lengths, the trampoline, the .abc cave, the r16 nops — all
unchanged (verified). An address audit proves the four caves now touch only
the new state addresses, none of the watchdog's fields.

## 5 — Verification — 317 suite checks + gates

* **r18_verify.py — 131/131** (the full round-17 ownership suite re-run on
  1.5.22 at 3 ASLR slides, state constants relocated): happy path, retry,
  double-failure, no-types passthrough, the pool-drain torture test, two
  concurrent imports, slot saturation, register preservation, statics,
  byte-diff vs 1.5.21 confined to the eleven words + stamp + UUID.
* **r18_r16regress.py — 186/186** (the full round-16 suite re-run): VDB
  budget keep/drop at the boundary cases through the **new** counter
  addresses, walker reset, .abc button construction (isa untouched),
  Scene-Setup filter, Cycles never runs, autosave/signal/crash-save,
  Blosc/VGAIN hooks, RSCRATCH adrp, statics, byte-diff. (One stale check in
  the r17 suite — "IS3D unchanged vs 1.5.19" — compared against a
  pre-round-16 baseline and failed even on the shipped 1.5.21; corrected to
  compare against 1.5.21, which is the meaningful guard for this round.)
* **Packaging gates:** shipped-binary sha256 identical to the verified work
  image, both version fields correct inside the IPA, stamp + count verified,
  fresh UUID verified inside the IPA, all state regions zero in the file,
  hook words unchanged.

## 6 — Install & test (the verification step matters this time!)

1. **Delete the old SaikiMotion inside LiveContainer first** (long-press its
   icon in LC's app list → delete). This is the stuck 1.5.8 copy — it must
   go. Also delete any duplicate SaikiMotion entries if you see more than
   one.
2. Install `SaikiMotion-1.5.22-unsigned.ipa` as usual.
3. **Verify you are actually running it (this is the important step):**
   * LiveContainer's app list must show version **1.5.22**;
   * in the app, the release-notes (UPDATES) last line must say
     **"Round-18 build 1.5.22: install/update fixed (old builds were stuck),
     watchdog state fixed, launch crash fixed."**
   If either shows something older, the old copy is still installed — delete
   it and install again.
4. Remember you are jumping **fourteen rounds of fixes at once** (1.5.8 →
   1.5.22): freeze watchdog + Crash-folder logs, VDB big-cloud budget,
   .abc import button, Scene-Setup shows all layers, video-import ownership
   fix, autosave, grid, particles/flare 3D — everything is on your device for
   the first time. Quick smoke test: open a project, import a video, import
   your biggest VDB cloud, open the environment panel (the "Import Alembic
   (.abc)…" button), toggle Scene Setup.
5. If anything misbehaves: the Crash folder (Files app → On My iPhone →
   SaikiMotion → Crash) now gets readable logs, and any system crash log
   will carry the new UUID — send them and I can see exactly which build and
   which code path.

## 7 — Known limits (honest)

* The 12-second video-import hard timeout from round 15 became inert when
  round 17 rebuilt the video chain on per-import slots (the watchdog's
  timeout state is no longer wired to it). The two-attempt load chain still
  guarantees the completion fires for any provider that answers; a provider
  that never answers at all would leave the spinner up. If you ever see
  that, tell me — the fix is one cave call.
* Everything from earlier rounds' known limits still applies.
* Until you confirm the release-notes line shows Round-18, we cannot trust
  that any on-device behavior corresponds to the new code.
