# SaikiMotion — Round 19 fix notes
**Input:** the shipped 1.5.22 binary (round 18) — same bytes you were running
**Output:** `SaikiMotion-1.5.23-unsigned.ipa` — **the freeze root-cause round.**

---

## 1 — What your new crash log proved (finally, from the real build)

Your crash log's UUID (`faf72be1-…`) matches 1.5.22, so for the first time we
saw the ACTUAL failure, and it names the culprit exactly:

```
touch → TimelineView.up → EditorViewController.onSelect(-1)
     → refreshTitle hook → CAVE_AUTOSAVE2
     → Projects.save  (full JSON serialize, on the MAIN THREAD, every 2nd edit)
     → [a crash signal arrives mid-save]
     → the round-14 "emergency save" SIGNAL HANDLER runs
     → it calls Projects.save AGAIN from signal context
        with STALE UNRETAINED pointers
     → main thread wedged in String.append for 30+ seconds
     → iOS watchdog kill (0x8BADF00D)
```

Two separate killers, both real, both now gone:

* **KILLER 1 — the edit-time synchronous save.** Every 2nd `refreshTitle()`
  (which fires on selection changes, deletes, effect edits — "I do anything
  and it freezes") ran the ENTIRE project serialization on the main thread.
* **KILLER 2 — the signal-handler Swift save.** Any crash signal landed in a
  handler that called Swift code with freed pointers → permanent wedge
  instead of a clean crash. This is also why "it crashes even when it's not
  meant to".

## 2 — The lineage bug (why nothing I described ever shipped)

Byte-comparing every round binary showed round 15's output was 3,212,536
bytes, but rounds 16-18 are all 3,180,315 bytes — **round 16 was accidentally
built on the round-14 binary**, silently discarding ALL of round 15 (freeze
watchdog, crash logs, VDB ScaleTranslateMap fix, video timeout, every-4th
autosave). 1.5.20/21/22 were patches on the round-14 state. You were right:
the fixes I listed were not in the builds you installed. Round 19 is built
directly on the true shipped bytes and re-ports what was lost.

## 3 — What 1.5.23 changes

| # | what | detail |
|---|------|--------|
| 1 | **The freeze fix** | Edits no longer save. They mark the project dirty and stamp the frame counter. The render-loop hook saves ONLY when you've been idle ~10 s AND on the main thread (IDLE_SAVE cave with re-entry guard). Deleting, adding effects, selecting — nothing blocks the UI anymore. The app's own 6 save paths (new/rename/close/…) are untouched. |
| 2 | **The signal-handler save is deleted** | Crash signals now go to a raw-syscall C logger that writes a readable report (signal, fault address, ALL registers from the ucontext, the action ring, watchdog state) to Documents/Crash, restores the default disposition, and lets iOS produce its own log. No Swift from signal context, ever again. |
| 3 | **Freeze watchdog, corrected** | A 2 s interval timer checks the per-frame heartbeat. Liveness = heartbeat CHANGE (the old "poke answered = alive" bug that made real freezes undetectable is gone). A freeze is declared ONLY when rendering stopped WITH unsaved work in flight — never while idling on menus, never during VDB imports, never when you simply background the app. Then: log + kill, so nothing stays wedged. |
| 4 | **VDB fixes re-ported + upgraded** | The lost round-15 ScaleTranslateMap fix is back (non-uniform voxel grids stopped failing with "bad node compression flag"). The Blosc scratch moved into the verified-free 126 KB window and the decode cap went 56 KB → ~127 KB, so big Blosc clouds decode instead of erroring. |
| 5 | **Menu bar (from your image)** | Bottom bar on the main menu: **Account, Projects, AI, Community, Extras, Settings** — pinned to the safe area, equal-width, localized. |
| 6 | **Settings + 4 languages** | Settings tab → **English / Español / Bahasa Indonesia / 日本語**. Choice is saved (NSUserDefaults) and the bar labels update immediately; the sheets (titles, messages, Cancel, counts) are localized too. |
| 7 | **Real info in the tabs** | Projects shows the actual on-device project count; Extras shows the crash-log file count and where to find them; Account shows version + offline notice; Community lists the five bundled example effects. |
| 8 | **Self-register fix** | Discovered while verifying: Swift methods receive `self` in **x20** (the old round-14 cave read x0, which is actually refreshTitle's argument) — the editor cache and welcome stash now use the correct register, so the idle save reads the real project name. |
| 9 | **Version + UUID** | 1.5.23 / 23, fresh UUID `18ff7b4c-6eff-4f7e-a970-9c9ad0524cb4` so any future crash log identifies this exact build. |

## 4 — Verification (89 checks, all green)

* **53 structural checks** (r19_verify.py): blob byte-exact; correct Darwin
  syscall numbers (sigaction=46, setitimer=83 — verified against xnu's
  syscalls.master; Darwin SIGBUS=10; uc_mcontext at +0xB0 — verified against
  the xnu headers); all 6 hook sites branch exactly where intended;
  AUTOSAVE2 contains no save call and no signal() loop; IDLE_SAVE never
  touches the stale cache; fixups parse with 832 imports and the new
  sel_registerName/objc_getClass slots chain correctly; the byte-diff vs
  1.5.22 is confined to the intended regions; state page has no collisions
  with the round-16 VDB counters or round-17 video slots.
* **36 emulator checks** (r19_emu.py, unicorn at 3 ASLR slides): AUTOSAVE2
  marks dirty and never saves; EXIT_CAVE heartbeats and only dispatches the
  idle save when idle+dirty; IDLE_SAVE performs exactly one save with
  retain/release symmetry and clears its flags; the watchdog declares a
  freeze only with unsaved work, never when idle-clean, never during VDB
  imports, never while rendering, never prematurely.

## 5 — Install & what to look for

1. Delete the old SaikiMotion inside LiveContainer first, then install
   `SaikiMotion-1.5.23-unsigned.ipa` (sign as usual).
2. Verify: LiveContainer shows **1.5.23**; in-app release notes say
   **"Round-19 build 1.5.23"**.
3. The main menu now has the bottom bar. Open **Settings → pick a language**.
4. Edit something, delete something, add an effect — the app should stay
   responsive. The idle autosave happens ~10 s after your last edit.
5. If anything ever crashes or freezes now: readable logs land in
   **Files → On My iPhone → SaikiMotion → Crash** (the Extras tab shows the
   count). Send me those files — with the register dump they name the exact
   faulting code path.

## 6 — Known limits (honest)

* The language switch localizes the new menu bar, tab sheets and settings
  (the parts this patch owns). The app's original screens are English-only —
  the original app ships no translation tables, so translating them would
  mean rewriting every hardcoded string in the binary.
* The AI/Community/Account tabs show real, honest information (capabilities,
  examples, counts) — they don't fake cloud features the app doesn't have.
* Crash logs from the watchdog only start after the first project opens
  (that's when the logger installs).
* Everything from earlier rounds' known limits still applies, except the
  video-import timeout, which is now covered by the round-17 ownership fix.
