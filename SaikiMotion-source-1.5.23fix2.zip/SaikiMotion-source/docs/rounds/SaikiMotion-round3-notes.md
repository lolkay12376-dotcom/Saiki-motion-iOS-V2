# SaikiMotion — Round 3 fix notes
**Input:** rounds 1+2 binary (VDB import, icons, parameter panel fixes)
**Output:** `SaikiMotion-fixed-unsigned.ipa` — round 3: water export crash, realistic
water, flare editor robustness, and `.abc` (Alembic) 3D model import.

Test files: `sample_mesh.abc` (static cube), `sample_animated.abc` (2-sample), plus the
existing `test_smoke.vdb`.

---

## Fix 1 — Export crash with a water layer

**Symptom:** exporting any project containing a water plane crashed the app.

**Root cause:** `WaterAssets.mesh()` caches its grid VBO/IBO in **static** storage
(`0x1001c9ab0/ab4/ab8`), but the `Exporter` renders through a **second EAGLContext**
created with `initWithAPI:` and **no shared sharegroup** (0x10008b39c). GL buffer
names are per-context: on the export context the cached names resolve to *empty*
buffers, so `glDrawElements` (0x10012f278) dereferences a null vertex fetch and the
app dies. (The grid index buffer is `UInt16`, capped at 96/128 segments — not the
overflow.)

**Fix:** the cache check at `0x10016b9f4` now routes through a cave in the new
`__PATCH` segment that compares `[EAGLContext currentContext]` with the context that
built the mesh (stored in the free slot `0x1001c9ac0`). On a context change the mesh
is rebuilt *in the current context*, and it self-heals back after the export
finishes.

## Fix 2 — Realistic water

The old shaders (2241 B vertex / 4023 B fragment, `0x100191df0` / `0x1001926c0`)
were replaced with rewritten versions hosted in `__PATCH` (same uniforms, same
varyings, so all 35 keyframable parameters keep working):

* **Vertex:** 6 Gerstner octaves (the 2 user trains + cross ripple + 4 derived
  detail octaves that inherit amplitude/length so every slider still responds),
  deep-water dispersion `c = sqrt(g/k)`, per-octave steepness clamping
  (`Q·k·A ≤ 0.98`, no self-intersection), exact analytic normals, and a
  **Jacobian folding metric** for `vFoam` — foam now appears exactly where waves
  pinch, like real breaking water.
* **Fragment:** volumetric Beer–Lambert absorption along the view path
  (per-channel `exp(-sigma·d)`, in-scattering adds the shallow colour back),
  chromatic refractive dispersion (RGB-split sampling of the behind-buffer),
  Schlick Fresnel (F0 = 0.02), dual-lobe sun specular + anisotropic glitter,
  crest-based fake subsurface scattering, cellular bubble foam, layered caustics,
  and underwater-camera handling.
* Validated as strict GLSL ES 1.00 with glslangValidator.

## Fix 3 — Optical flare editor robustness

The flare editor's 90 force-unwrapped view references (`ldr x0,[..]; cbz x0, brk`
around `setNeedsDisplay`) were made nil-safe: 61 branch retargets skip the
`objc_msgSend` (a no-op on `nil`), 29 replicated caves keep the shared register
setup alive when the first view is missing. If a view is torn down mid-edit, the
editor now skips its redraw instead of trapping — the sliders, presets and element
lists all keep working.

## Fix 4 — `.abc` (Alembic/Ogawa) model import

`Import Model (.glb)` now also accepts Alembic archives (the picker already allows
any file — `UTType.data`). `GlbModel.validate(path:)`'s entry (`0x1000a66ec`) is
hooked: for a `.abc` path containing an Ogawa archive the injected freestanding-C
transcoder (`abc2glb.c`, zig `-target aarch64-ios`, zero relocations, ~12.5 KB in
`__PATCH`) walks the archive (top object → child objects → `.geom` compound →
`P` / `.faceIndices` / `.faceCounts`, first sample), computes smooth normals,
and writes a real glTF 2.0 **GLB** (JSON + BIN chunks, POSITION/NORMAL/indices
accessors, min/max) next to the original — rewriting the path in place
(`.abc` → `.glb`, same length). The stock GLB importer then takes over, so models
import with the same materials pipeline as `.glb`. HDF5-flavoured Alembic files
are rejected gracefully (import error, no crash).

Verified against generated Ogawa archives: static mesh, 2-sample animated mesh
(sample 0 selected), nested multi-mesh (xform + 2 meshes), and a 70,000-vertex
mesh (32-bit indices).

## Mach-O surgery

| Piece | Detail |
|---|---|
| `__PATCH` (RX) @ `0x1001cc000` | caves + water shaders + abc transcoder |
| `__PATCHD` (RW) @ `0x1001d8000` | one chained-fixups GOT slot |
| chained fixups | rebuilt blob (byte-identical roundtrip verified) with a new `fwrite` import from libSystem (ordinal 3, import #829) + `__PATCHD` page-start table |
| `__LINKEDIT` | extended to cover the new blob at EOF |

In-place `__TEXT` edits: mesh-cache branch (0x10016b9f4), water shader
adrp/add + count immediates (0x10011c6a8–c4), validate entry (0x1000a66ec),
90 flare sites. Everything else — symbols, stubs, sections, prior rounds'
patches — verified unchanged.

---

## Install & test
1. Sign `SaikiMotion-fixed-unsigned.ipa` as before (AltStore / SideStore /
   Sideloadly / eSign).
2. **Export crash:** add a water plane (Environment → Create Water Plane), export
   the project — it should complete instead of crashing, and the preview water
   should come back after the export finishes.
3. **Water look:** Wave 1/2 height, length, speed, direction, Choppiness,
   Refraction, Reflection, Caustics, Crest Foam, Smoothness — all the same
   sliders, dramatically richer result (absorption depth follows Depth Blend).
4. **Flare:** open the Optical Flare editor and hammer the sliders / presets —
   no traps even if a view goes away mid-edit.
5. **ABC:** `Import Model (.glb)...` and pick a `.abc` (try `sample_mesh.abc`).
   It imports as a lit, normal-mapped model like any `.glb`.

### Known limits
* `.abc` import reads the first animation sample (static frame), not the whole
  animation curve.
* Alembic archives written in the legacy **HDF5** flavour show the standard
  import error — re-export as Ogawa (the default in Blender/Maya/Houdini since
  ~2015).
* Water still renders on the OpenGL ES path; 16-bit grid indices cap the plane at
  128 segments (unchanged).
