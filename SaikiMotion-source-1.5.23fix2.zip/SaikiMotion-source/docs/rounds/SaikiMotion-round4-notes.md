# SaikiMotion — Round 4 fix notes
**Input:** rounds 1+2 binary (VDB import, icons, parameter panel fixes)
**Output:** `SaikiMotion-fixed-unsigned.ipa` — round 4: import visibility,
Scene Setup completion (joystick + grid + 3D-only + export-safe camera),
round-3 water-mesh correction, and an updated first-load What's-New list.
App version bumped to **1.4 (4)**.

---

## Fix 1 — Empty viewport after importing .glb / .vdb / .abc

**Symptom:** after importing any 3D model the viewport showed nothing.

**Root cause:** with no camera layer in the project, `XfO.viewProj`'s default
camera sits at `(0, 0, cot(fov/2))` looking at the origin — a frustum built
for the unit-sized 2D media plane (vertical half-height exactly 1.0 at z=0).
Imported models are drawn at **raw file coordinates** (`GlbModel` does no
centering or scaling; layer defaults are x=y=z=0, scale=1), so any real-world
GLB/Alembic export (typically tens to hundreds of units, often offset from
the origin) lands entirely outside the ±1 frustum — or wraps the camera
inside the mesh — and the viewport appears empty.

**Fix (import-time normalization):** the round-3 `GlbModel.validate(path:)`
hook now runs `r4_hook` (injected freestanding C, ~20 KB in `__PATCH`):
1. `.abc` files are transcoded to `.glb` exactly as in round 3.
2. **Every** `.glb` (freshly transcoded or picked directly) is then
   normalized **in place inside the app sandbox**: all `VEC3`/`float32`
   `POSITION` accessors (identified by their glTF-required `min`/`max`) are
   recentered on the mesh bounding-box centre and rescaled so the largest
   dimension is 1.4 units — comfortably inside the default camera.
   - File size never changes (only BIN-chunk vertex data is rewritten).
   - Idempotent: re-importing a normalized file is a no-op (guards on
     k≈1 and centre≈0), so re-opening saved projects is stable.
   - Exotic files are left untouched and still import the old way:
     sparse accessors, morph targets (`"targets"`), normalized accessors,
     interleaved bufferViews (`byteStride` ≠ 12), non-`VEC3` positions.
   - The original file in Photos/Files is never modified — only the
     sandbox copy made by `copyMediaIntoSandbox`.
3. VDB volumes were already positioned at the origin with a unit-cube
   raymarch shell (radius = the layer's `Spread` param, default 1.0), so
   they were in-frustum once the scene's other content stopped hiding the
   problem; with models normalized to the same scale everything composes.

Verified on the host build of the same C: a 100×50×200-unit model offset by
(1000, −500, 250) normalizes to a centred ±0.7 box; unit cubes stay visible;
`.abc` samples transcode *and* normalize in one pass; second passes are no-ops.

## Fix 2 — Round-3 regression: water never rendered (and the export crash it "fixed")

The round-3 mesh-context cave had an **inverted branch**: on an
`EAGLContext` mismatch it jumped to the *cached-mesh* path instead of the
*rebuild* path (an off-by-one in the cave's branch target). Since the owner
slot starts empty, `ctx != owner` was always true on the first call, the
mesh never built, and water rendered nothing — while the export crash
disappeared only because nothing was ever drawn.

**Fix:** the cave at `__PATCH+0x0` is rewritten with the correct control
flow (emulation-verified for all four cases):

| current ctx vs owner | cached mesh? | behaviour |
|---|---|---|
| differs | — | **rebuild in the current context** (the intended r3 fix) |
| same | none | build |
| same | present | use cache |

Water now renders in the editor again, and exporting with a water layer
rebuilds the water mesh on the exporter's own GL context instead of
dereferencing foreign buffer names.

## Fix 3 — Scene Setup completed

The app already had a half-wired scene-setup mode (title-bar **scene** icon →
`toggleSceneSetup`, orbit camera state `XfO.setupYaw/Pitch/Dist/Target`,
pan + pinch gestures, a setup bar). Round 4 finishes it:

* **Joystick:** a `MovePadView` (a complete but previously *never
  instantiated* joystick view class found dormant in the binary) is created
  with the setup overlay — 124×124 pt at the bottom-left — and removed when
  setup mode is toggled off. The per-frame hook polls its `px/py` ivars
  (0.12 dead-zone) and orbits the setup camera (±0.03 rad/frame, pitch
  clamped to ±77°). No Swift closure interop needed.
* **Ground grid:** the same per-frame hook draws a 21×21-line grid on the
  y=0 plane (±10 units) with red X and blue Z axis lines, using an injected
  GLES2 shader + VBO built lazily on first use, blended (α 0.16 grid /
  0.55 axes), depth-test off, drawn before the scene so content overlays it.
  The grid uses the exact setup-camera math from `XfO.viewProj`'s setup
  branch (50° fov, 0.2–2000 range, same eye formula) so it aligns with the
  scene.
* **Only 3D content:** `drawOne` now filters layers through the app's own
  `XfO.is3d` (type ∈ {CAMERA, MODEL, WATER, VOLUME} **or** the layer's 3D
  flag — so 3D-converted media counts) while setup mode is on. 2D layers
  are hidden in the setup viewport; the timeline, panels and keyframing
  keep working unchanged.
* **The free camera never touches the render:** `viewProj`'s
  `setupView` check now also requires the current `EAGLContext` to be the
  preview's context (cached on first sight). The exporter renders through
  its own context, so exports always use the project camera even while
  scene setup is active. The grid/joystick hook is gated the same way, so
  neither ever leaks into an export.
* **Toggle hint updated:** the snack now reads "Scene Setup: joystick to
  orbit, drag to pan, pinch to zoom."

Timeline editing, parameters and keyframing are untouched by setup mode (the
mode only changes the camera and layer visibility of the live preview).

## Fix 4 — First-load What's-New list updated

`WelcomeViewController.UPDATES` (10 static strings shown on the welcome
screen) is rebuilt in `__PATCH` and its `__DATA` pointer table rewritten,
describing this round: import visibility, water fix, the Scene Setup stage,
joystick, 3D-only filtering, the export-safe viewer camera and the Alembic
import. App version bumped to 1.4 (4) in Info.plist.

---

## Mach-O surgery (round-4 layout)

| Piece | Detail |
|---|---|
| `__PATCH` (RX) @ `0x1001cc000`, 48 KB | caves, water shaders, r4 code + literals |
| `__PATCHD` (RW) @ `0x1001d8000`, 32 KB | fwrite GOT bind (page 0) + our state (context cache, pad pointer, grid program/VBO/locations, line vertices) |
| chained fixups | rebuilt blob (roundtrip-verified) with the round-3 `fwrite` import (ordinal 3, import #828); `__PATCHD` page-starts `[0, 0xFFFF]` |

In-place `__TEXT` edits: mesh-cache branch (0x10016b9f4), water shader
counts/pointers (0x10011c6a8–c4), validate entry (0x1000a66ec),
viewProj setupView load (0x10011b510), drawOne entry (0x10011e888),
renderInto retain (0x100122d30), buildSetupOverlay entry (0x10002f6bc),
toggle-off release (0x100019130), snack count (0x1000190fc), plus the 90
flare nil-safety sites from round 3. Everything outside these sites is
byte-identical to the round-1+2 base (verified by full-image diff).

`__DATA` edits: the 10-entry UPDATES string table (0x1001c4ad8) and the
snack text (in-place, same buffer).

### Injection details
* `round4.c` (zig `-target aarch64-ios`, freestanding, one TU, zero external
  relocations): Alembic→GLB transcoder (round 3), GLB normalizer, grid
  renderer, joystick poll, pad create/remove. All OS services via the host
  struct (file I/O) or absolute-address function pointers (GL/objc stubs).
* New caves: `CAVE_VP` (viewProj export gate), `CAVE_3D` (drawOne filter
  with full argument save/restore and a clean early-`ret`), `CAVE_FRAME`
  (per-frame hook; reads the viewport size from renderInto's stack frame),
  `CAVE_PAD` / `CAVE_PADOFF` (joystick lifecycle, tail-calling the original
  `objc_release`).

### Verification performed
* 43/43 structural checks (segments, fixups roundtrip + fwrite import, every
  patch site, displaced instructions, UPDATES table, snack, full-image
  regression diff vs the round-2 base).
* 11/11 Unicorn emulations of the hand-assembled cave logic (mesh cache
  ×4, viewProj gate ×4, drawOne filter ×2, trampoline small-string path).
* Full arm64 emulation of `r4_frame` with fake GL/objc: joystick orbit math
  exact (yaw 0.65→0.635, pitch −0.35→−0.341), shader compile/link sequence,
  VBO upload, three `glDrawArrays(LINES, …)` calls with counts 84/2/2, and a
  verified perspective×lookAt matrix for the setup camera.
* Full arm64 emulation of `r4_pad_create`/`r4_pad_remove`: correct
  view→bounds→alloc→initWithFrame:(14, 696, 124, 124)→addSubview sequence
  and clean teardown.
* Host-build tests of the normalizer/transcoder against generated GLBs
  (raw-scale, small, offset), both round-3 Alembic samples, and idempotence.

---

## Install & test
1. Sign `SaikiMotion-fixed-unsigned.ipa` as before (AltStore / SideStore /
   Sideloadly / eSign).
2. **Imports:** import a `.glb`, a `.abc` and a `.vdb` — each should appear
   centred in the viewport at a sensible size (largest dimension ≈ 1.4
   units). Re-opening the project keeps them in place.
3. **Water:** a water plane should render in the editor again, and
   exporting with water should complete without crashing.
4. **Scene Setup:** tap the *scene* icon in the top bar:
   - the ground grid + red/blue axes appear, with only 3D layers visible;
   - the on-screen joystick (bottom-left) orbits the camera;
   - drag pans, pinch zooms (0.5–120);
   - the timeline and parameter panels still work;
   - toggle it off and export — the render is framed by the project camera,
     never the setup camera.
5. **What's New:** the welcome screen lists this round's changes.

### Known limits
* `.abc` import still reads the first animation sample (static frame).
* HDF5-flavour Alembic files are rejected with the standard import error.
* GLB normalization is accessor-space: glTF files that place meshes via
  node transforms on top of large raw coordinates will center per-accessor
  (still far better than raw, but not node-aware).
* Sparse/morph-target/interleaved GLBs are intentionally skipped by the
  normalizer (imported as before).
* The grid fades nothing with distance (fixed 21×21 lines, ±10 units).
