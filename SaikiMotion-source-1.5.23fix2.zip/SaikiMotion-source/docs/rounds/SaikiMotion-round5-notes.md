# SaikiMotion — Round 5 fix notes
**Input:** rounds 1–4 binary (VDB import, icon/UI fixes, water + flare + .abc, import
visibility + Scene Setup)
**Output:** `SaikiMotion-1.5.9-unsigned.ipa` — round 5: **RotoBrush + Draw tool**,
**FBX import**, **ZIP import**, a full-app bug sweep, and a Scene Setup reachability fix.
App version bumped to **1.5 (5)**; **re-released as 1.5 (6)** with a launch fix (see
"Launch fix" below — builds 5 and the round-3/4 IPAs aborted at load with
`Symbol not found: fwrite`), **1.5 (7)** with the tap-crash ABI fix (see
"ABI fix" below — build 6 crashed on the first button tap), **1.5 (8)** with
the on-screen build stamp, and **1.5 (9)** with the drawOne cave rewrite (see
"Viewport fix (5.5)" below — build 8 dismissed the welcome fine but crashed
the moment the editor rendered, which still looked like "the orange button
crashes").

Test files: `sample_cube.fbx` (binary FBX, plain arrays), `sample_cube_compressed.fbx`
(zlib-compressed arrays), `sample_model.zip` (deflated zip containing an FBX),
`sample_gltf_bundle.zip` (gltf + bin + texture), plus the earlier `.abc`/`.vdb` samples.

---

## Feature 1 — RotoBrush & Draw (paint on screen)

A **pencil button** (`edit` icon) now floats at the top-right of the viewport overlay.
Tap it to enter the Draw tool; tap again to leave (strokes are saved on exit).

While active, a compact toolbar appears down the right edge:

| Button | Icon | Action |
|---|---|---|
| Mode | `mask` | toggle **Draw** ⇄ **Mask (rotobrush)** |
| Colours | `drop` ×4 | white / red / green / blue brush colour |
| Size | `box` | cycle thin (4pt) / medium (10pt) / thick (22pt) |
| Undo | `redo` | remove the last stroke |
| Clear | `back` | wipe all strokes |

* **Draw mode** paints colour strokes (source-over) composited over the final image.
* **Mask mode** is the rotobrush: strokes punch through the footage
  (`blend(ZERO, ONE_MINUS_SRC_ALPHA)` hold-out matte), so you can cut objects out
  frame by frame.
* **Rotoscoping:** every stroke is time-tagged with the playhead when drawn and is
  visible from that moment onward — scrub the timeline, draw again, and each drawing
  appears from its own time. Because strokes render inside `SceneRenderer.draw()`
  after all layers (not in the group compositor), they appear **identically in the
  live preview and in the export**.
* While the tool is active the viewport's 3D manipulation (rotate/pinch/gizmo) is
  suspended and the selection gizmo is hidden, so the canvas is clean; the timeline,
  panels and keyframing keep working. Thumbnails are never touched (renders below
  256 px are skipped), and strokes are hidden in Scene Setup mode.

### How it is wired
* **Capture:** the three `OverlayView` touch handlers (`touchesBegan/Moved/Ended`,
  specialised Swift bodies at `0x1000d0c74/0x1000d1420/0x1000d1dd0`) branch into
  caves that call `r5_ov_began/moved/ended(set, self)`. When the tool is off the
  original code runs untouched; when on, the cave extracts the touch via the app's
  own `Set<UITouch>.first` generic (`0x10001117c`), converts it with
  `locationInView:`, records the point normalised to the overlay, and returns —
  swallowing the event so nothing is dragged. `OverlayView.drawRect` is suppressed
  while drawing (gizmo hidden).
* **Rendering:** the end of `draw()` (single exit at `0x10011ae70`) jumps to a cave
  that passes the **frame time from `s8`** plus the render size, and calls
  `r5_strokes_frame`. Strokes are triangle-ribbon segments plus round point-sprite
  joints drawn with a dedicated GLES2 program; the program is cached per
  `EAGLContext` (owner-tracking like the round-3 water fix) so the exporter's second
  context rebuilds it instead of crashing.
* **UI:** `EditorViewController.viewDidLayoutSubviews` (`0x100017194`) calls
  `r5_on_layout(self)`, which reads the `overlay` ivar (`+0x20`), creates the
  `IconView`+`TapView` pairs (alloc + `initWithFrame:` + direct ivar writes for the
  icon's Swift small-string `icon@0x18`, `tint@0x28`, `sizePt@0x30`), and repositions
  them on every layout pass — so rotation is handled. `TapView.touchesEnded`
  (`0x10015ccc0`) dispatches only for our buttons; every other TapView in the app
  behaves exactly as before.
* **Persistence:** `copyMediaIntoSandbox`'s single epilogue (`0x1000d877c`) hands the
  returned sandbox path to `r5_capture_dir`, which caches the media directory. Strokes
  are saved to `<media dir>/roto_<projectId>.bin` (project id read from the editor's
  `projectId` ivar) whenever a stroke finishes, the tool is switched off, or the store
  changes; they are loaded back when the editor opens.

## Feature 2 — FBX import

`Import Model (.glb)` now also accepts **binary FBX 7.x** files (Blender, Maya, 3ds Max
default). The `GlbModel.validate` hook detects the `Kaydara FBX Binary` magic,
walks the node tree, and extracts every `Geometry` of type `Mesh`:

* `Vertices` (`d`/`f` arrays — **including zlib-compressed arrays**, decoded through
  the app's already-imported `compression_decode_buffer` with Apple's raw-DEFLATE
  `COMPRESSION_ZLIB`, after skipping the 2-byte zlib header) and
  `PolygonVertexIndex` (negative last index = polygon end; fan-triangulated).
* Smooth normals, glTF 2.0 GLB output and the min/max accessors come from the same
  shared builder as the Alembic importer, so FBX models flow through the identical
  materials pipeline, then get the round-4 normalisation (auto-centre + auto-scale).
* Output is written to `<name>.glb` — the same length as `<name>.fbx`, so the Swift
  path is rewritten in place exactly like `.abc`.

## Feature 3 — Models through ZIP

A picked `.zip` is opened (EOCD + central-directory parse, 256 entries), the best
model entry is chosen by rank `.glb > .gltf > .fbx > .abc` (skipping directories,
`__MACOSX/` and dotfiles), and extracted (stored or deflate):

* `.glb` → written straight out.
* `.fbx` / `.abc` → staged as a sibling `<name>.fbx`/`<name>.abc` (same length as the
  zip path) and transcoded by the FBX/Alembic importers.
* `.gltf` → **packed into a real GLB**: the external `.bin` is loaded from the archive
  first (so all existing bufferViews stay valid), then textures are appended as new
  bufferViews with their `mimeType`, and the JSON's `uri` fields are rewritten
  (`images[].uri` → `bufferView`, `buffers[].uri` → `byteLength`). Data-URI images
  are left untouched. A referenced `.bin` missing from the zip rejects the import
  with the standard import error instead of producing a broken model.
* Output lands at `<name>.glb` (same length as `<name>.zip`) and is normalised like
  any other import.

## Bug sweep (whole app)

* **Force-unwrap traps:** all 1,048 `cbz → brk` trap sites were censused. The only
  teardown-crash class was the flare editor (90 sites, fixed in round 3); the strict
  ivar-load + immediate-call shape finds no further dangerous sites, and there are
  zero weak-reference force-unwraps. No new traps patched — by design, since the
  remaining ones guard array bounds and internal invariants.
* **Static GL caches:** every `glGen*` call site was resolved to its function and
  checked for static-storage caching. The only cross-context cache was
  `WaterAssets` (fixed in round 3; re-verified here). Everything else uses
  per-`SceneRenderer` instance state, which is context-safe by construction.
* **Fixed (found by this sweep): Scene Setup grid/joystick reachability.** Round 4
  hung its per-frame hook inside `renderInto` — the *group* compositing path — so a
  scene containing **only** 3D layers (no groups) never drew the grid or polled the
  joystick, which is precisely the Scene Setup use case. Round 5 moves the hook to
  the top of `draw()` itself (right after `glClear`, `0x100119c64`), which runs for
  every preview and export frame of every scene.
* All prior patch sites re-verified by assertion during the rebuild, plus a
  full-image diff against the round-2 base (only the intended sites differ).

---

## Mach-O surgery (round-5 layout)

| Piece | Detail |
|---|---|
| `__PATCH` (RX) @ `0x1001cc000`, 112 KB | caves (rounds 3+4 + 7 new), water shaders, round-5 C code + literals |
| `__PATCHD` (RW) @ `0x1001e8000`, 192 KB | fwrite GOT bind (page 0) + grid/joystick state + roto state (toolbar pointers, stroke store 96 × 384-pt records, save/load paths) |
| chained fixups | rebuilt blob (roundtrip-verified) with the `fwrite` import (ordinal 3, import #829); `__PATCHD` = 12 pages |

In-place `__TEXT` edits: everything from rounds 3+4 **except** the round-4
`renderInto` hook (retired — the grid moved to `draw()`), plus the seven new sites:
`draw()` start (`0x100119c64`), `draw()` end (`0x10011ae70`), the three OverlayView
touch bodies, `OverlayView.drawRect` (`0x1000d0c08`), `viewDidLayoutSubviews`
(`0x100017194`), `TapView.touchesEnded` (`0x10015ccc0`) and
`copyMediaIntoSandbox`'s epilogue (`0x1000d877c`).

### Injection details
* `round5_full.c` (zig `-target aarch64-ios-none -O ReleaseFast`, freestanding, one
  TU, zero external relocations): round-3 Alembic transcoder + round-4 grid/joystick/
  normalizer + round-5 FBX parser, ZIP reader, glTF packer and roto engine. Only
  reloc types BRANCH26/PAGE21/PAGEOFF12 appear (the two SUBTRACTOR annotations are
  paired duplicates of adrp/add sites and are skipped).
* New caves: `CAVE_GRID`, `CAVE_STROKE`, `CAVE_OV_BEG/MOV/END`, `CAVE_OV_DRAW`,
  `CAVE_LAYOUT`, `CAVE_TAP`, `CAVE_DIR`.

### Verification performed
* **27/27 host tests** (native build of the same C): FBX plain + zlib + multi-mesh,
  zip→FBX/GLB(stored)/gltf+bin+png/abc/mixed ranking, gltf JSON surgery (image →
  `bufferView:2`, uri removal, mime), GLB validity + idempotence, stroke
  store/split/save/load round-trip, Swift small/large-string decoding.
* **82/82 binary checks + Unicorn emulations**: segments/fixups roundtrip, all 15
  patch sites → caves, displaced-instruction copies, UPDATES table, full-image
  regression diff vs the round-2 base; swallow + passthrough control flow with
  register/SP preservation for every new cave; a complete arm64 emulation of
  `r5_strokes_frame` with stubbed GL/objc (program build, `uPt`/`uColor` plumbing,
  `(TRIANGLES, 24)` + `(POINTS, 5)` for a 5-point draw stroke, `(18)`+`(4)` for a
  mask stroke, `SRC_ALPHA` vs `ZERO` blend per mode, per-context caching); the
  round-3/4 water-mesh cave re-verified for all three cache cases.
* IPA repackaged and re-opened: binary hash matches the verified image, version
  1.5 (7); import #828 verified as `_fwrite` (libSystem ordinal 3) and all seven
  rewritten cave headers verified inside the shipped IPA; 130/130 checks pass.

---

## Launch fix (5.1) — "Symbol not found: fwrite"

The chained-fixups import the caves use for file output was registered under the
C spelling `fwrite`. Mach-O symbol names carry a leading underscore, and
libSystem.B.dylib exports `_fwrite` — not `fwrite` — so dyld aborted the load:

```
dlopen(.../SaikiMotion.app/SaikiMotion): Symbol not found: fwrite
  Referenced from: .../SaikiMotion  Expected in: /usr/lib/libSystem.B.dylib
```

The import entry itself was healthy (ordinal 3 = libSystem, non-weak, correct
name offset; the GOT bind in `__PATCHD` page 0 references it) — only the name
string lacked the `_`. Fixed in place: the name now reads `_fwrite` (the `_`
lives in a padding byte just before the old string, and the entry's name offset
moved back one byte, so no sizes or offsets changed). All three stage-2
generators and the verify suites were corrected too, and the verification now
enforces the dyld-level invariants that would have caught this: every import
name is underscore-prefixed, the raw bytes at the name offset match, and the GOT
bind's import index is inside the imports table.

---

## ABI fix (5.2) — crash on every tap (welcome-screen Close button first)

**Symptom:** with the app finally launching, tapping any button crashed
instantly — first seen on the orange **Close** button of the first-load welcome
screen.

**Root cause:** the round-5 (and one round-3) caves call C helpers and then
resume the original Swift code, but a C call may clobber every caller-saved
register (`x0–x17`, `d0–d7`). The patched Swift bodies *read* those registers
at entry, so the C return value in `w0` replaced live arguments:

| Cave | Hooked body | Destroyed register | Consequence |
|---|---|---|---|
| CAVE_TAP | `TapView.touchesEnded` | `x0` = touches Set (read by `mov x21,x0`) | `Set<UITouch>.first` ran on the return value 0 → **crash on every TapView tap** |
| CAVE_OV_BEG/MOV/END | `OverlayView.touches*` | `x0` (Set), `x1` (event) | crash on any viewport touch with the draw tool off |
| CAVE_LAYOUT | `EditorViewController.viewDidLayoutSubviews` | `x0` = self | crash as soon as the editor lays out |
| CAVE_DIR | `copyMediaIntoSandbox` epilogue | `x0/x1` = returned Swift String | imports returned a garbage path |
| CAVE_MESH (r3) | water mesh-cache branch | `w8` = mesh count, read after an `objc_msgSend` | undefined cache decision |

**Fix:** all seven caves rewritten in `__PATCH` (entry addresses unchanged, so
no `__TEXT` edits): every live argument register is now pushed around the C
call and restored before the displaced prologue runs; the MESH cave saves the
count across its `objc_msgSend` (and keeps all three cache decisions:
ctx differs / count 0 / cached). The TAP displaced instruction is copied
verbatim (`stp d11,d10,[sp,#-0x50]!` — SIMD, pre-index; a look-alike integer or
post-index encoding would corrupt the frame).

**Why the emulations missed it:** the fake C functions were `mov w0,#res; ret`
— they never clobbered anything. The suite now models a *real* C call (the
fakes trash `x0–x4, x8–x17, d0–d7` via a Unicorn hook) and asserts that the
touches Set, event, self, the returned String and `w8` all survive to the
landing site, on both swallow and passthrough paths — 12 new checks for this
bug class, 130/130 total.

---

## Build stamp (5.3) — version 1.5 (8)

The 1.5 (7) build (the ABI fix above) was produced but **never reached the
device** — the delivery was cut off, so the crash kept reproducing on the
build that was actually installed (1.5 (6), which still destroys `x0` on every
tap). 1.5 (8) is the same binary plus one addition:

* the **last line of the release-notes screen now shows the build number** —
  it reads *"Round-5 build 1.5 (8): RotoBrush + Draw, FBX and ZIP import,
  full stability sweep."*

**How to use it:** after installing, open the app and look at the last line of
the first-load release notes (the screen with the orange Close button).
If it does **not** say **1.5 (8)**, the fixed build is not the one running —
re-sign and re-install `SaikiMotion-1.5.8-unsigned.ipa` (delete the old app
first if the version does not change). With 1.5 (8) on the device, tapping
the orange Close button — or any other button — must no longer crash.

Everything else in the binary is unchanged from the verified 1.5 (7) state:
130/130 static + emulation checks pass, `_fwrite` import intact, the shipped
IPA byte-identical to the verified image.

---

## Viewport fix (5.5) — crash the instant anything rendered (build 1.5 (8))

**Symptom:** with the orange Close button finally working, tapping it dismissed
the first-load welcome — and the app crashed the moment the editor underneath
started drawing. To the user this still looked exactly like "tapping the orange
button crashes", because the crash fired within the same instant as the tap.

**Root cause (two defects in the same cave, found by full-image static audit +
Unicorn emulation):**

1. **Corrupted layer pointer on EVERY `drawOne` call.** The round-4 CAVE_3D
   (the Scene-Setup "3D layers only" filter, hooked at `drawOne`'s entry) saved
   `x0–x7` at `[sp..0x38]` and then emitted its eight FP saves as
   `stp d0,d1,[sp]` … `stp d6,d7,[sp]` — **all four pairs at offset 0**, i.e.
   on top of the just-saved `x0/x1` (the generator had ORed the *register
   number* into the encoding's Rt2 field instead of the imm7 *offset*).
   On the restore the cave therefore loaded **d6/d7's raw bits into x0/x1**
   (and d6/d7 into d0–d7). `drawOne` reads `x0` as the layer at its third
   instruction (`ldrb w8,[x0,#0x68]`) and `s0/s1` as the frame times — so
   every single layer draw in preview and export ran on a garbage pointer.
   This bug has been latent in every build since round 4; it was only reachable
   once 1.5 (8) let the user get past the welcome screen.
2. **Skip path returned into itself.** The cave's not-3D early-exit ended in
   `add sp,sp,#0xd0; ret` — but the cave had never saved LR, and the preceding
   `bl is3d` had overwritten it with an address inside the cave: the `ret`
   jumped back to the cave's own `cbz x0` in an **infinite loop with SP
   drifting +0xd0 per iteration** until it walked off the stack. (Scene Setup
   with a 2D layer present.)
3. **Wrong `is3d` argument.** The filter loaded its argument from `[sp+8]`
   (drawOne's `x1`) instead of `[sp]` (`x0` — the layer; `is3d` reads the
   layer's 3D flag at `[x0+0x69]` and compares its type at `[x0+0x28]` with
   the same "CAMERA" constant `drawOne` uses).

**Fix:** the cave at `0x1001D0280` is fully rewritten (same entry address, no
`__TEXT` edits): `x29/x30` are saved first (the same pattern as the 5.2 cave
fix), the argument frame is laid out `x0–x7` at `[sp..0x38]`, `d0–d7` at
`[sp+0x40..0x78]`, LR is restored before the skip-path `ret`, and `is3d`
receives `[sp]` (the layer). All 40 words are round-tripped through capstone,
and the emulation suite grew four new scenarios (setup off / setup on + 3D
layer / setup on + 2D layer / export context) that stub BOTH callees as real
C calls clobbering `x0–x17/d0–d7` and assert the layer pointer, `x1–x7`,
`d0–d7`, SP and the is3d argument all survive — the exact assertions that fail
on the old bytes. The generator's FP-encoding helpers are fixed too
(`enc_stp_d`/`enc_ldp_d`), so a regeneration cannot reintroduce this.

## Redelivery (5.4) — why "still crashes" happened, and the 3-step check

The 1.5 (7)/(8) builds (the orange-Close crash fix) were produced during a session
that was cut off **before the file was delivered** — the installed app was still
1.5 (6), which destroys `x0` on every `TapView` tap. The orange Close button is a
`PillButton`, which **inherits `TapView.touchesEnded`** — exactly the patched body —
so on build 6 it crashed the moment it was tapped. Builds 7/8 fixed the tap itself
(see "ABI fix") but carried the latent drawOne defect above until 1.5 (9).

**Install without stale-build traps:**

1. **Delete the app first** (home screen → long-press → Remove App → Delete App).
   Sideloading over an existing install can silently keep the old binary, and
   AltStore/SideStore *auto-refresh* restores the previously cached IPA — disable
   auto-refresh for this app or install manually after deleting.
2. Sideload **`SaikiMotion-1.5.9-unsigned.ipa`** (the only IPA in the delivery — the
   filename now carries the build).
3. Open the app. On the release-notes screen (the one with the orange Close
   button) the **last line must read "Round-5 build 1.5 (9): …"**. If it says
   anything else, the fixed build is not the one running — delete and re-install.
   Then tap the orange Close button.

If a build that verifiably says **1.5 (9)** still crashes: capture the crash log
(Settings → Privacy & Security → Analytics & Improvements → Analytics Data → the
latest `SaikiMotion-….ips` entry) — it names the exact faulting address, which
pinpoints the bug in one step.

## Slide fix (5.6) — the REAL tap-crash root cause, proven by the crash log (build 1.5 (9))

The user's next crash report finally included the **crash log itself**
(`bug_type 309`, incident `07BC6DE7`, iPhone 12 mini, iOS 18.7.8, **LiveContainer
3.8.11**), and it pinned the fault byte-for-byte:

* `EXC_BAD_ACCESS / KERN_INVALID_ADDRESS`, faulting **read** at `0x1001E8068`
  — "not in any region";
* PC = image base `0x108778000` + `0x1D4FEC` = **`r5_on_tap + 0x2C`**, inside
  our `__PATCH` code, reached from `-[UIGestureDelayedEventComponentDispatcher
  sendDelayedTouches]` → `TapView.touchesEnded`;
* `x20 = 0x1001E8468` — our `R_NSTROKE` anchor, as a raw constant.

**Root cause — position-dependent injected code.** The app image is loaded at
a random ASLR slide (here `0x8778000`; every sideload does this too, not just
LiveContainer). But the round-4/5 C sources materialise *every* fixed address
— `__PATCHD` state, app selrefs, app `__TEXT` functions, app globals — as an
absolute link-time constant:

```
mov  x20, #0x8468
movk x20, #0x1e, lsl #16      ; x20 = 0x1001E8468  (link-time address!)
movk x20, #1,  lsl #32
sub  x8,  x20, #0x400         ; x8  = 0x1001E8068  (R_BTN_TAP slot)
ldr  x8,  [x8]                ; <<< SIGSEGV: link-time address, unmapped
```

Under any nonzero slide those constants point at unmapped memory, so **every
injected feature crashed the moment it ran** — the Close-button tap (via
`CAVE_TAP → r5_on_tap`) was simply the first one hit after launch. This one
defect explains every "still crashes" report since round 4; the earlier ABI
and drawOne fixes were real but this bug fired before either of them could
matter. (The hand-written caves were always adrp-based and fine; only the
compiled C was broken.)

**Fix — make every constant build position-independent.** A new scanner
(`scripts/slidefix_patch.py`) tracks per-register `movz/movk` builds across
the whole `__PATCH` segment (correctly handling builds the compiler
*interleaves* between registers), and rewrites each address-valued build
slot-in-place:

```
adrp x20, <page of target>    ; PC-relative — correct at ANY slide
add  x20, x20, #<page offset>
nop
```

64 builds rewritten (state anchors, selrefs, `objc_msgSend`/GL stubs, method
addresses, app globals). Two `0x100002600` builds are deliberately **skipped**
— that value is a folded charset bitmask used with `tst`, not an address
(whitelist: `__PATCHD`-range values + literals present in the compiled C).
Data pools were scanned too: zero absolute pointers anywhere in
`__PATCH`/`__PATCHD`.

**Verification:**

* `slidefix_emu.py` (Unicorn): the **old binary at the exact crash-log slide
  reproduces the field crash exactly** (same PC, same fault address, same
  access type); the fixed binary passes r5_on_tap passthrough, the full
  CAVE_TAP flow (displaced `stp d11,d10` + return into `touchesEnded`), the
  toolbar match path (which runs the creation code with the formerly
  interleaved builds), and the touch hooks — each at four slides including
  `0x8778000`. All pass.
* The 159-check round-5 suite passes on the fixed binary; the shipped-IPA
  checker confirms the seven ABI caves and byte-identity with the work image.
* A final scan of the shipped binary: **0** remaining absolute address builds,
  data side clean, stamp present.

Build 1.5 (9) therefore contains: round 5 features + fwrite import fix +
tap-cave ABI fix + drawOne/CAVE_3D fix (5.5) + **this slide fix (5.6)**.
The release-notes last line now reads *"Round-5 build 1.5 (9):
position-independent hooks — ASLR / LiveContainer crash fixed."*

## Install & test
1. Sign `SaikiMotion-1.5.9-unsigned.ipa` as before (AltStore / SideStore /
   Sideloadly / eSign) — after deleting the old install (see "Redelivery").
2. **RotoBrush/Draw:** tap the pencil at the viewport's top-right:
   - draw with a finger (colour drops, size box, undo arrow, clear back);
   - switch to Mask and paint over footage — it cuts through;
   - scrub the timeline and draw again — each stroke appears from its own time;
   - export — the strokes are baked in exactly as previewed;
   - leave and re-open the project — strokes reload.
3. **FBX:** `Import Model (.glb)` and pick `sample_cube.fbx` (or a real export from
   Blender/Maya — binary FBX 7.x).
4. **ZIP:** pick `sample_model.zip` or `sample_gltf_bundle.zip`; the best model
   inside imports automatically.
5. **Scene Setup on a pure-3D scene:** the grid + joystick now appear (previously
   they needed a 2D/group layer to be present).

### Known limits
* FBX: binary 7.x only — ASCII FBX and FBX 6.x show the standard import error;
  normals are recomputed (smooth), node transforms are not applied per-mesh
  (the global normaliser re-centres/rescales the whole model).
* ZIP: zip64 archives and encrypted entries are rejected; `.gltf` picked **directly**
  (not inside a zip) is not converted — bundle it in a zip with its `.bin`/textures.
* Roto: strokes persist per project in the media sandbox once any media has been
  imported (the directory is captured from the import flow); a project that has
  never imported any media keeps strokes for the session only. The store holds 96
  stroke records (long strokes auto-split into continuation records). Stroke width
  is stored relative to the viewport, so a rotated/resized device shows the same
  relative weight.
