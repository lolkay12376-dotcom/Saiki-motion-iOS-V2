# SaikiMotion — Round 6 fix notes
**Input:** round-5 binary 1.5 (9) (RotoBrush + Draw, FBX/ZIP import, ABI + drawOne +
ASLR/slide fixes)
**Output:** `SaikiMotion-1.5.10-unsigned.ipa` — **the parameter-panel cramming is actually
fixed this time**, plus a full accounting of the crash logs you sent.

---

## Fix 1 — The parameter panel cramming (the one that has been there "since the beginning")

**Symptom (every build so far, portrait and landscape, normal and Full mode):** the bottom
panel shows only the 52 pt icon rail on the left plus a ~12 pt sliver — parameter values
render as clipped fragments (".0", ".6", ".5") at x≈56–68 pt — while ~85 % of the panel is
empty black space. Round 2's "fix" (re-pinning the 4th edge constraint) changed nothing:
pixel-measuring your two screenshots (Oct 30 and Nov 1) shows the layout is byte-for-byte
identical before and after it.

**How it was found this time.** The whole panel-construction region of
`EditorViewController.buildUi` (0x100015658–0x100015d14) was executed in a Unicorn
emulation with a modelled objc/Swift runtime (chained fixups applied, every
`objc_msgSend` dispatched, anchors/constraints recorded). That produces the exact view
hierarchy and the exact set of activated constraints — no guessing from static reading:

```
panelBox  (framed by RootLayout.lay: full screen width × 348 pt in portrait)
└── hStack (UIStackView, horizontal, TAMIC off)
    ├── wrap(tabStack)  width == 52
    └── panelSv (UIScrollView, TAMIC off)
        └── panelList (UIStackView, vertical)   ← TAMIC still ON — THE BUG
            └── parameter rows (added later via addArrangedSubview)

activated: 4 wrap constraints + wrap.width==52
           5 scroll constraints (top/bottom/lead/trail == contentLayoutGuide,
                                 width == frameLayoutGuide)
           4 panel pins (hStack top/bottom/leading, panelSv.trailing == panelBox.trailing)
```

**Root cause.** `panelList` is inserted with a plain `[panelSv addSubview:panelList]`
while `translatesAutoresizingMaskIntoConstraints` is still **YES** (the app turns it off for
`panelSv`, for `hStack`, for the wrapper, and for the track-list stack — but forgot it
here). A zero-frame view added that way gets implicit **required** constraints
(width = 0, height = 0) that conflict with the five explicit scroll constraints. Auto
Layout breaks the explicit width tie, and every parameter row collapses to the stack's
own directional margins (leading 4 + trailing 8 = exactly the 12 pt sliver measured on
your screenshots). Round 2 pinned a different edge — which is why it did nothing.

**The fix (one instruction).** The call at 0x100015700–0x100015710 is
`[panelList setAlignment:0]` — a no-op, because `.fill` (0) is already the default and
nothing ever changes it. Its selector load is redirected to the neighbouring slot:

```
0x100015704:  ldr x1, [x8, #0x168]   setAlignment:            (old, 0xF940B501)
           →  ldr x1, [x8, #0x468]   setTranslatesAutoresizingMaskIntoConstraints:  (new, 0xF9423501)
```

x0 (= panelList) and x2 (= 0/NO) were already set up by the surrounding code, and the
call happens **before** `addSubview:` — exactly the right order. Same binary size, no
new code, no cave.

**Verified:**
* emulation re-run on the patched binary: `panelList.tamic` is now **NO**, alignment
  untouched, margins (6,4,16,8) preserved, hierarchy and all 13 constraints and the
  4/5/4 activations byte-identical to 1.5.9 — and the same emulation on the 1.5.9 bytes
  reproduces `tamic == True` (the bug);
* the full round-5 verification suite re-run on the 1.5.10 binary: **159/159 pass**
  (segments/fixups/`_fwrite` import, all 14 hook sites, displaced instructions, UPDATES
  table, regression diff vs the round-2 base with the one new site allow-listed, every
  cave control-flow emulation, the full GL emulation of the stroke renderer, the
  round-4 mesh/viewProj and CAVE_3D drawOne checks);
* a dedicated 19-check round-6 suite (static instruction/selref/stamp checks + the
  emulation proof above);
* shipped-IPA checker: the binary inside the IPA is byte-identical to the verified work
  image, the fix and the stamp are in the shipped bytes, and the byte-diff vs 1.5.9 is
  confined to exactly the one instruction + the stamp string + its table entry.

**What you should see now:** the tab rail on the left and parameter rows that span the
full remaining width — labels, sliders and values readable — with all rows scrollable;
same in landscape and in the Full-panel mode.

## Fix 2 — the crash logs you sent: both are the already-fixed ASLR/slide bug

Two different crash logs arrived with this report:

| log | incident | captured | runtime | signature |
|---|---|---|---|---|
| pasted in the message | `07BC6DE7…` | 11:46:57 | 13 s | PC = `r5_on_tap+0x2C`, faulting read at link-time `0x1001E8068` |
| uploaded `Crash.ips.ips` | `0A7516DC…` | 16:02:18 | **2 s** | PC = `r5_on_tap+0x2C` (slide `0x35C8000`), same fault at `0x1001E8068`, x20 = raw `0x1001E8468` |

Both are the round-5 "position-dependent injected code" crash, and **both were captured
before 1.5 (9) was built at 17:01** — 1.5.9 is the build that rewrote all 64 absolute
constant builds to adrp/add sequences. Verified again on the 1.5.10 bytes:

* the crash site `0x1001D4FEC` (`ldr x8,[x8]`) is now preceded by
  `adrp x20,… ; add x20,… ; nop` — correct at any ASLR slide;
* a fresh scan of the whole `__PATCH` segment with the round-5 verified build-tracker:
  **0** address-valued `movz/movk` builds remain (only the two whitelisted
  `0x100002600` charset bitmasks, which are not addresses);
* your 17:27 screenshot shows the editor running with a project open — that is the
  fixed build working on device.

Why it looked like "sometimes when I create a project it crashes": on the broken builds
**every** tap ran the broken hook — including the "+" / create-project button (a
TapView), which is exactly the path the logs show (`sendDelayedTouches` →
`TapView.touchesEnded`). When sideloading tools auto-refresh or restore a cached older
IPA over the new one (see "Redelivery" in the round-5 notes), the crash appears to come
and go. 1.5.10 keeps the slide fix — nothing about it changed except the two intended
patch regions above.

If a build that verifiably says **1.5 (10)** still crashes: send the *new* crash log
(Settings → Privacy & Security → Analytics & Improvements → Analytics Data → the latest
`SaikiMotion-…ips`), and it will pin the faulting address the same way.

---

## Mach-O surgery (round-6)

Everything is inherited unchanged from 1.5 (9) (`__PATCH` 112 KB RX / `__PATCHD` 192 KB
RW, chained-fixups blob with the `_fwrite` import, all 14 in-place `__TEXT` hook sites).
Round 6 adds exactly:

| # | address | before | after | effect |
|---|---|---|---|---|
| 1 | `0x100015704` | `ldr x1,[x8,#0x168]` (setAlignment:) | `ldr x1,[x8,#0x468]` (setTranslatesAutoresizingMaskIntoConstraints:) | the panel's content stack gets TAMIC=NO — rows get the full width |
| 2 | UPDATES[9] string + length | "Round-5 build 1.5 (9): position-independent hooks…" | "Round-6 build 1.5 (10): parameter panel fixed - full-width rows, no more cramming." | on-device build verification |

`Info.plist`: CFBundleVersion 9 → **10** (CFBundleShortVersionString stays 1.5).

## Install & test
1. **Delete the app first** (home screen → long-press → Remove App → Delete App), and
   disable AltStore/SideStore auto-refresh for it so a cached old IPA can't come back.
2. Sign and install `SaikiMotion-1.5.10-unsigned.ipa` (AltStore / SideStore /
   Sideloadly / eSign).
3. Open the app → release-notes screen → the **last line must say "Round-6 build
   1.5 (10)"** — if it says anything else, the old build is still installed.
4. Tap Close, open/create a project, tap a layer:
   - the bottom parameter panel should now span the full width with readable rows
     (this was the cramming);
   - tap the "Full" pill — the expanded panel should also be full width;
   - rotate to landscape — same;
   - creating projects, tapping buttons, drawing with the pencil tool — no crashes.
