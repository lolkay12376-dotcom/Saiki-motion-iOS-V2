# SaikiMotion — Round 7 fix notes
**Input:** round-6 binary 1.5 (10)
**Output:** `SaikiMotion-1.5.11-unsigned.ipa` — the **import crash fixed**, **VDB failures
now explained on screen**, **Ultra Glow** (researched replacement for Deep Glow),
**3 new effects**, icon ghosting/invisibility fixes, and a full accounting of every
issue in your report.

---

## Fix 1 — Importing .glb (and .abc/.fbx/.zip) crashed the app  **[root cause found]**

**Symptom:** importing any GLB crashes; VDBs import (they never go through this path).

**Root cause (proven by disassembly + emulation):** the round-3 hook on
`GlbModel.validate` (entry `0x1000a66ec`) redirects into a cave at `0x1001cc100`,
but the cave **never replays the instruction it displaced** — validate's frame push
`stp x28, x27, [sp, #-0x60]!`. The cave's own pushes/pops are balanced, so execution
resumed at the second prologue instruction with **sp 0x60 too high**: every stack
store of the rest of the prologue landed *above* sp — inside the caller's frame,
clobbering the caller's saved registers — and the epilogue popped from the wrong
place, adding 0x60 to sp on return. Stack corruption → SIGSEGV shortly after.

This hook shipped in round 3 but **never ran on a device until 1.5 (9)** — earlier
builds crashed on load or on first tap before an import could happen — which is why
it only surfaced now.

**Fix:** the cave tail now replays the displaced push before resuming:
```
0x1001cc19c:  stp x28, x27, [sp, #-0x60]!     ; was: b 0x1000a66f0
0x1001cc1a0:  b     0x1000a66f0                ; was: padding
```
**Verified by emulation:** PC reaches the resume, SP is exactly `entry − 0x60`,
x28/x27 land in the right slots, the String (x0/x1) survives — and the same
emulation on the 1.5.10 bytes reproduces the imbalance.

## Fix 2 — "VDB imports but the viewport is empty": the failure is now VISIBLE

**What I found:** the whole pipeline was audited —
* the parser (after the round-1 fixes) handles every realistic variant I could
  generate: v222–225, ZIP / uncompressed / ACTIVE_MASK, `_HalfFloat` grids (the
  fp16→fp32 decoder is present and correct), multi-grid files (density + velocity),
  non-"density" grid names, all three transform map types, inactive-value flags
  2/3/5 — **15/15 variants parse and produce voxels** (script:
  `scripts/r7_vdb_battery.py`, faithful model `scripts/emulate_parser.py`);
* the "valid" flag is set correctly on the success path (`mov w22,#1` at
  `0x100169c74`);
* the 3D-texture upload is a correct RGBA slice-atlas (`glTexImage2D`, w=nx,
  h=ny·nz);
* the volume program is built in `initGLBody`.

**So when a VDB shows nothing, the parse threw and `drawVolume` skips the layer
*silently* — the error string is stored in the volume (`+0x18`) but nothing ever
shows it.** The two realistic throw paths are Blosc compression (Houdini and many
stock cloud packs write Blosc by default — the friendly "re-export with Zip"
message exists but was invisible) and exotic grid types.

**Fix:** the skip branch in `drawVolume` (`0x10012f400`) now routes through a cave
that shows the stored error **once per volume** via `Snack.show` (dedup slot in
`__PATCHD`). You will now see e.g.
*"This VDB uses Blosc compression. Re-export it with Zip or no compression."*
instead of a black viewport. (Implementing the Blosc decoder itself remains open —
see Known limits.)

## Fix 3 — Scene Setup

Every path was audited statically and under emulation: the joystick creation
(`MovePadView` is a proper UIControl with `init(frame:)`, nil-safe closures),
the app's own `buildSetupOverlay` (**emulated end-to-end with the round-6 objc
model — completes cleanly**, the setup bar builds correctly), `r4_frame`'s grid
code (GL calls all use valid stubs; shader compile failures cannot crash),
`CAVE_3D` (re-verified by the 159-check suite), the gesture handlers, and
`viewProj`'s setup branch. No crash site was found in any of them.

Two hardening changes shipped anyway:
* **CAVE_VP rewritten** — it previously saved only x0/x1 across an
  `objc_msgSend` that may clobber all caller-saved registers; the live `s0`
  (read by the normal path) can theoretically be destroyed on the
  setup-on/export-context path. The cave now saves/restores x0/x1 and d0/d1 and
  its control flow is emulation-verified for all four context/flag combinations.
* **The setup hint snack was showing garbage text** (a round-4 pointer
  miscalcibration: it displayed a mid-word fragment with embedded NULs from the
  *original* app's own buggy string slice). The pointer now targets the intended
  "Scene Setup: joystick to orbit, drag to pan, pinch to zoom." text.

If a build that verifiably says **1.5 (11)** still crashes in Scene Setup, capture
the crash log (Settings → Privacy & Security → Analytics Data → latest
`SaikiMotion-…ips`) — it will pin the faulting address exactly like the round-5
log did.

## Fix 4 — Play/pause and quality icons overlapping; invisible-until-clicked icons

**Root cause (overlap):** the swapped-in icon/text is drawn as *vector glyphs over
a layer whose previous pixels are not cleared* — the new pause glyph composites on
top of the stale play glyph. (The original app's icons went through a cached
full-rect `UIImage` blit that masked this; the round-2 direct-draw patch — and the
original `ToolButton` text path — expose it.)

**Root cause (invisible icons):** tints without an alpha byte render fully
transparent (`argbToUIColor` has no alpha-0 fallback), so an icon whose tint lost
its `0xFF` alpha byte is invisible until a state change (press/selection) forces
the alpha bit on.

**Fix:**
* `IconView.draw` and `ToolButton.draw` now begin with an explicit **clear-rect**:
  `SaveGState → SetFillColor(transparent) → SetBlendMode(copy) → FillRect(bounds)
  → RestoreGState` (all through the app's own stubs). Harmless when the context is
  already clean; removes ghosts when it isn't.
* Both draws now **force the alpha byte** on the tint when it is entirely absent
  (`tbnz #31 → tst #0xff000000 → orr #0xff000000`), leaving deliberate
  semi-transparent tints untouched.

This covers the play/pause toggle, the Full/1/2 quality selector, and the
graph/expression icon class of bugs.

## Feature 1 — Ultra Glow (the Deep Glow replacement)  *researched*

**Why the old one was "not even a good glow":** the effect runs an iterating
separable blur + composite, but **the blur had no bright-pass at all** — it blurred
the *whole image*, which produces haze, not glow. Worse, the shader reference sites
carry the app's `-0x20` string-pointer quirk; the blur and composite sources begin
with fragments of *the previous shader's text* followed by NUL padding (the GL layer
passes an explicit length, so the junk is part of the source) — these two programs
have very likely been failing to compile since 1.0, leaving the effect running on
program-0 fallback.

**The new shaders** (following the industry standard for single-chain bloom —
COD:AW / Jimenez 2014, UE4's bloom, adapted to the existing two-program,
multi-iteration driver):
* **Blur pass:** per-tap **soft-knee bright-pass** (`smoothstep(0.03, 0.38, luma)`
  — low enough that accumulated glow survives repeated passes) + the classic
  9-tap linear-sampled Gaussian **plus two wider halo lobes** (5.9× and 8.4× the
  step) for a long, physically-plausible falloff. Because the driver re-runs the
  pass with growing radius, the compounding chain now behaves like a poor man's
  mip pyramid.
* **Composite pass:** 3×3 tent **plus a 4-tap diagonal wide-halo**, exposure shaped
  as `1.45×` with the soft shoulder `1−exp(−g·1.25)` (keeps colour through the
  mid range), the original's tint mix and banding dither retained, alpha logic
  unchanged (those conventions are proven correct on device).

Both sources live in `__PATCH` with a 32-byte **NUL prelude** — exactly the
proven-safe pattern the round-3 water shaders use — and the `buildSafe` reference
sites are redirected to them.

## Feature 2 — Three new effects (via the app's own SDK)

The app has a file-based effect SDK (`sdk/examples/<name>/effect.json` +
`effect.glsl`, loaded by `Registry.loadSdk()` from a hardcoded folder list).
Three new effects ship in the bundle, wired in by extending the loader's loop
with three extra entries backed by a table in `__PATCH` (count +3 with an
out-of-bounds remap — emulation-verified: the loop now iterates the original
entries plus `chroma_lens`, `film_grain`, `crt_tv` in order):

| Effect | Category | What it does |
|---|---|---|
| **Chromatic Aberration** | Color | Lens-style radial RGB split that grows toward the edges; Amount + Softness |
| **Film Grain** | Color | Animated film-stock grain weighted to the shadows; mono/colour, size, speed |
| **CRT TV** | Glitch and motion | Barrel warp, scanlines, phosphor triads, static, flicker, tube vignette |

They appear in the FX browser next to the bundled examples and are keyframable
like any other effect.

---

## Mach-O surgery (round-7 layout)

Everything inherited unchanged from 1.5 (10). Round 7 adds:

| # | site | change |
|---|---|---|
| 1 | `0x1001cc19c/1a0` | validate cave replays the displaced `stp x28,x27,[sp,#-0x60]!` |
| 2 | `0x1000190f4` | snack pointer: `sub #0x20` → `add #0x10` (correct hint text) |
| 3 | `0x10015cdf8` / `0x10015e7d8` | IconView.draw / ToolButton.draw → clear-rect caves |
| 4 | `0x10015ce1c` / `0x10015e828` | IconView / ToolButton tint → alpha-force caves |
| 5 | `0x1001d0200` (rewrite) | CAVE_VP saves x0/x1 + d0/d1 across the objc call |
| 6 | `0x10012f400` | drawVolume invalid-skip → error-snack cave (once per volume) |
| 7 | `0x10011c5a0-5d4` | Ultra Glow blur/composite count+pointer redirects |
| 8 | `0x1000f6e0c` / `0x1000f6e84` | Registry.loadSdk loop extension (count +3, element remap) |

New `__PATCH` content (free space `0x1001e5000-0x1001e6100`): the six caves above,
the two Ultra Glow shader sources (1177 + 1828 bytes, NUL preludes), the SDK
path-string table. State in `__PATCHD`: VDB-snack dedup slot `0x100208000`,
SDK array capture slot `0x100208008`. UPDATES[9] stamp and `Info.plist`
CFBundleVersion 10 → **11**.

### Verification performed
* Round-6 regression suite on the 1.5.11 binary: **158/159** — the single
  "failure" is the regression-diff check listing exactly the ten intended
  `__TEXT` edit sites (audited range-by-range; nothing outside them changed).
* New round-7 suite (**21/21**): validate-hook stack balance + register survival;
  SDK loop extension (5-iteration emulation proving the remap feeds
  chroma_lens/film_grain/crt_tv); CAVE_VP all four context/flag paths with
  x0/x1/d0/d1/SP survival; every cave round-tripped through capstone.
* VDB parser battery: 15/15 variants still parse (no parser bytes touched).
* Shipped-IPA checker: binary inside the IPA is byte-identical to the verified
  work image; version 1.5 (11); the three SDK folders present in
  `Payload/SaikiMotion.app/sdk/examples/`.

## Install & test
1. Delete the old app first (home screen → long-press → Remove App → Delete App);
   disable AltStore/SideStore auto-refresh for it.
2. Sign & install `SaikiMotion-1.5.11-unsigned.ipa`. The release-notes last line
   must say **"Round-7 build 1.5 (11)"**.
3. **Imports:** import a `.glb` — it must import and render centred (no crash).
   `.abc`/`.fbx`/`.zip` imports go through the same fixed hook.
4. **VDB:** import a VDB and scrub the timeline inside the layer's range — if the
   file can't render you now get a snack explaining why (e.g. Blosc → re-export
   with Zip or no compression).
5. **Glow:** add Deep Glow to a layer with bright highlights — you should see a
   true glow now: only bright areas bloom, with a wide soft halo. Raise Exposure
   for a hotter core, use Tint for colour.
6. **New effects:** FX browser → *Chromatic Aberration*, *Film Grain*, *CRT TV*.
7. **Icons:** play/pause and the quality pill should swap cleanly with no
   ghosting; the graph/expression icon should be visible without tapping it.

### Known limits (honest)
* **Blosc VDBs still need re-export** (Houdini default) — but the reason now
  shows on screen instead of a silent black viewport. A native Blosc (blosclz +
  shuffle) decoder is the largest remaining feature; the file-level transcoder
  design is sketched in the round-7 work dir.
* **Timeline layer dragging** (move media left/right in time) is not fixed this
  round: the drag machinery (`TimelineView.move` at `0x100149d18`, gated by a
  mode check at `0x100149dbc` and the `dragTrack` ivar) was analysed but the
  gating condition needs on-device confirmation — a blind patch risks breaking
  playhead scrubbing. Pointers for the next round are in the notes above.
* The scene-setup crash was not reproduced statically or under emulation after
  exhaustive auditing; hardening shipped, and a crash log will pin it if it
  persists on 1.5 (11).
