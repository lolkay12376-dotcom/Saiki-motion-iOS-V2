# SaikiMotion — Round 8 fix notes
**Input:** round-7 binary 1.5 (11)
**Output:** `SaikiMotion-1.5.12-unsigned.ipa` — the **launch crash fixed** (root cause
proven from your crash log down to the byte), plus a new **slide-aware emulation
harness** so this entire bug class can never slip through again.

---

## The crash you sent (incident 02E7FD15) — fully symbolicated

```
HomeViewController.viewDidLoad
  → Registry.initialize
    → Registry.loadSdk                       (round-7 SDK loop extension)
      → Registry.loadBundleFolder(String)
        → String.append → _StringGuts.append → memmove
          → SIGSEGV reading 0x1001E5F20      (KERN_INVALID_ADDRESS, unmapped)
```

That address is the smoking gun: `0x1001E5F20` lands inside the round-7
`__PATCH` free space — our own SDK string table. Two bugs, both mine, both
now fixed:

### Bug 1 — ASLR slide (the crash you saw)
The three SDK folder names live in `__PATCH` as Swift String structs whose
object word held the **raw link-time pointer**. `__PATCH` has **no dyld
chained-fixup coverage**, so the loader never adds the ASLR slide: at
runtime the mapped copy sits at `slide + vmaddr` (your device used slide
`0x4F1C000`, image base `0x104F1C000`), while the String guts still point
at the unmapped link-time address. First String operation → memmove from
unmapped memory → SIGSEGV in `viewDidLoad`, i.e. instantly at launch.

This is the same bug class as the round-5 "slidefix" crash. Why did the
round-5 scanner not catch it when I re-ran it conceptually? Its data-side
check tested the **whole qword** against `[0x100000000, 0x100218000)` —
but a Swift string object word is `0x8000000000000000 | pointer`, and the
immortality tag pushes it outside that range. The new audit masks the tag
bits first (T9a below).

### Bug 2 — String encoding (a silent failure waiting behind bug 1)
A large *immortal* Swift String is not "pointer at the bytes". It is:

```
w0 = 0xD000000000000000 | count
w1 = 0x8000000000000000 | (utf8_bytes − 0x20)     ← UTF8 is read at w1+0x20
```

Proof in the app's own code (`0x1000f688c`): `add x8,#0x5a0 ; sub x8,x8,#0x20 ;
orr x8,x8,#0x8000000000000000` — and every UPDATES entry's pointer targets
`string − 0x20`. Your crash confirms it: the faulting read for the *first*
folder (`chroma_lens`, w1 `0x1001e5f00`) happened at `0x1001E5F20` = **w1+0x20**.

Round 7 stored `w1 = tag | bytes` (no `−0x20`). So even with the slide fixed,
the runtime would have read each string **0x20 too early** — chroma_lens would
have loaded as `".../film_grai"`, crt_tv as padding garbage — and all three new
effects would have silently failed to appear. The crash masked a worse bug.

## The fix (2 regions of the binary, 42 bytes total)

1. **Table re-encoded** (`0x1001e6000`): each `w1` now points at
   `bytes − 0x20`. The round-7 layout already spaces the strings exactly
   32 bytes apart (like the app's own merged literals), so the "headers"
   land on the previous string / the zero gap — never read for immortal
   strings, exactly like `bundle:sdk/examples/scan_wipe`'s own storage.
2. **CAVE_SDK_P2 rewritten** (`0x1001e6080`, 24 instructions): after
   loading `(w0, w1)` from our table it now applies the runtime slide:

```asm
ldp  x22, x27, [x12]          ; our (count/flags, object) pair
adrp x13, 0x1001e6000         ; x13 = runtime page  (PC-relative, auto-slid)
add  x27, x27, x13
movz x14, #1, lsl #32         ; x14 = 0x1001E6000   (link-time page, a VALUE)
movk x14, #0x1e, lsl #16
movk x14, #0x6000
sub  x27, x27, x14            ; x27 = tag | (bytes−0x20+slide)
```

`x13/x14` are dead at the hook point (verified: no references in the whole
of `loadSdk` or the caves). The constant build is a subtracted *value*, so
the code stays position-independent.

---

## "Use a virtual machine to test the app"

An iOS VM isn't possible in this environment (iOS only runs on Apple
hardware; there is no iOS simulator for Linux). What I *could* do — and
did — is fix the actual weakness that let this ship: **every previous
emulation mapped the binary at its link-time address (slide 0)**, which is
precisely the one memory layout the device never uses.

`scripts/r8_verify.py` is a new slide-aware ARM64 emulator harness
(unicorn): it maps the image at a **nonzero ASLR slide** and leaves the
unslid range **unmapped**, i.e. faithful to the iPhone. Under it:

* **T1 — crash reproduced on the 1.5.11 bytes**: the String built from the
  round-7 table faults reading **exactly 0x1001E5F20 — the same FAR as
  your crash log**. Diagnosis confirmed, not guessed.
* **T2–T4 — the fix verified**: all three SDK folders decode to the exact
  bytes `bundle:sdk/examples/{chroma_lens,film_grain,crt_tv}` inside the
  slid mapping, with the immortality tag intact; the full 5-iteration
  loop (2 bundled + 3 SDK) works; the loop epilogue hands
  `loadBundleFolder` precisely `(w0, w1)`; a faithful
  `swift_bridgeObjectRetain` model (retains only ObjC-tagged words) proves
  the retain path never touches memory.
* **T5–T8 — every round-7 fix regression-tested at slide**: GLB validate
  hook stack balance, CAVE_VP's four paths with register preservation,
  the VDB error-snack dedup, and the Ultra Glow shader redirects (they
  land on the slid NUL preludes with the source text at +0x20).
* **T9 — audits**: (a) masked data scan of all of `__PATCH`/`__PATCHD` —
  exactly the three SDK object words remain, all slide-corrected by the
  cave, nothing else pointer-shaped; (b) movz/movk address-build scan of
  `__PATCH` — only the intentional slide constant (a subtracted value);
  the two app-range builds are the round-5 `tst`-only charset bitmasks;
  (c) all 13 hook/redirect sites decode to PC-relative forms.
* **T10 — slide battery**: the loop passes at slides 0x1000, 0x8778000,
  0x2A000000 and 0x4F1C000. Any future ASLR layout behaves the same.

Result: **51/51**. The round-7 suite re-run against the 1.5.12 binary
(with its String fixture updated to the correct `w1+0x20` convention):
**21/21**. Byte-diff 1.5.11 → 1.5.12: 42 bytes in exactly two regions
(the table qwords and the cave); the release-notes stamp and
`CFBundleVersion 11 → 12` on top.

## Install & test

1. Delete the old app first (home screen → long-press → Remove App →
   Delete App); disable AltStore/SideStore auto-refresh for it.
2. Sign & install `SaikiMotion-1.5.12-unsigned.ipa`. The release-notes
   last line must say **"Round-8 build 1.5 (12): launch crash fixed -
   SDK string table is now ASLR-slide-safe."**
3. **Launch** — it must reach the home screen (this was the crash).
4. **FX browser** → *Chromatic Aberration*, *Film Grain*, *CRT TV* must
   now actually appear (the encoding bug would have silently kept all
   three off even without the crash). Add one to a layer and check its
   parameters.
5. Re-check the round-7 list while you're there: `.glb` import, a VDB
   (errors now surface as a snack), Deep Glow (bright-pass bloom), the
   play/pause + quality icons swapping cleanly.

## Known limits (unchanged from round 7)

* **Blosc VDBs** still need re-export (Zip or none) — the reason now
  shows on screen.
* **Timeline layer dragging** (move media left/right in time) is still
  open — the drag machinery needs on-device confirmation of its gating
  condition before a safe patch.
* If **Scene Setup** still crashes on 1.5 (12), capture the log — with
  today's slide-audit clean (no unslid readers of `__PATCH`/`__PATCHD`
  remain anywhere in the binary) a persistent crash there would be a new,
  different root cause and the log will pin it.
