# SaikiMotion — Round 9 fix notes
**Input:** round-8 binary 1.5 (12)
**Output:** `SaikiMotion-1.5.13-unsigned.ipa` — the **welcome-screen draw crash
fixed** (root cause proven from your crash stack down to the instruction), plus
a rebuild of every round-7 "clear-rect" hook that shared the same bug class.

Good news first: **1.5 (12) fixed the launch crash** — the app got all the way
to rendering its first screen. The new crash happened while *drawing* it.

---

## Your crash, decoded

```
-[__NSCFType bounds]: unrecognized selector sent to instance 0x10993e580
frame 6: ToolButton.draw To-thunk + 24      (0x108c981c)
frame 5: 0x1001e50c8 + slide 0x8778000  =  CAVE_TBN_CLEAR + 0x48
         — the instruction right after `bl objc_msgSend` in MY round-7
           ToolButton clear-rect cave (the `bounds` send)
```

The round-7 cave assumed `x19 = the button, x20 = the CGContext`. Disassembly
of the real functions proves the opposite for ToolButton:

```
ToolButton.draw:  bl UIGraphicsGetCurrentContext; mov x19, x0   ← x19 = CTX
                  (Swift self convention: x20 = SELF)
IconView.draw:    mov x19, x20 (self); … mov x20, x0 (ctx)      ← the swap
```

So the cave sent `bounds` to **the CGContext** — and a CGContext *is* an
`__NSCFType` when you msgSend it. That is your crash, byte for byte.

While fixing it, the audit found **two more bugs in the same caves** that would
have crashed right behind it:

1. **No epilogue.** The caves pushed `x29/x30` and never popped — SP leaked
   0x10 per draw, and both functions end in post-index `ldp …, [sp], #0x60`
   epilogues, so the shifted pops would load `x29/x30` from the wrong slots
   and `ret` to garbage. (Yes — the same class of mistake as round 7's Fix 1.
   The clear caves predate that lesson.)
2. **The `bounds` CGRect was never captured.** A 32-byte struct returns via
   `x8` on arm64 (indirect result register). The round-7 cave read nothing and
   passed msgSend's stale `x1` — the *selector pointer* — to
   `CGContextFillRect` as the rectangle. In emulation the old test modeled
   msgSend as `ret`, so the garbage was invisible.

## The fix

Both clear caves rebuilt in place (30 instructions each, same hook sites):

```asm
stp  x29, x30, [sp, #-0x50]!
sub  sp, sp, #0x20                 ; 32-byte CGRect out-slot
mov  w0, #0
bl   argbToUIColor                 ; transparent UIColor
…   [color CGColor] via objc_msgSend
bl   CGContextSaveGState(ctx)      ; ctx = x19 (ToolButton) / x20 (IconView)
bl   CGContextSetFillColorWithColor(ctx, color)
bl   CGContextSetBlendMode(ctx, .copy)
mov  x8, sp                        ; x8 = CGRect return slot  (the missing ABI)
…   [self bounds] via objc_msgSend → writes the rect to [sp]
bl   CGContextFillRect(ctx, sp)
bl   CGContextRestoreGState(ctx)
add  sp, sp, #0x20
ldp  x29, x30, [sp], #0x50         ; the missing epilogue
adrp x21/x8, …                     ; replay the displaced instruction
b    <resume>
```

Why this is safe at these hook points: the instruction just before them is a
`bl` (the ctx getter + retain), so **every caller-saved register is already
dead**, and `x19/x20` survive the cave's calls by being callee-saved.

Also rebuilt: the **VDB error-snack cave** (round 7) saved only `x0/x1/x2`
across `Snack.show`, which clobbers `x0-x17 + d0-d7`. It now saves and
restores all of them (the emulation caught that my first version of *this*
cave had colliding `stp` offsets — stride 8 instead of 16 — which is exactly
the kind of bug the new test rig exists to catch, and it never left this
machine). The `Snack.show` ABI was re-verified against the app's own 77 call
sites: `(x0 = count/flags, x1 = object word)` — the cave's load order was
already right.

CAVE_VP (scene-setup context detection) was audited against the original
binary and is correct: the only registers live across its hook are
`x0/x1/d0/d1`, exactly what it saves.

## Verification (slide-aware emulator, per your "test it like a VM" request)

`scripts/r9_verify.py` — **60/60**:

* **T1 — reproduce 1.5.12**: running the *real* `ToolButton.draw` from its
  entry with modeled stubs, the round-8 bytes send `bounds` to the CTX, hand
  `FillRect` the stale selector pointer as the rect, and leak 0x10 of SP —
  all three bugs demonstrated, matching your stack.
* **T2/T3 — the fix**: both draws run entry→resume with correct receivers
  (`bounds` to SELF), all five CG calls getting the CTX, `FillRect` getting
  the exact modeled CGRect, SP exactly `entry-0x60`, `x19/x20/x21` (and
  `x8` for IconView) correct, `x18/x22-x28/d8-d11` untouched.
* **T4 — VDB cave**: full `x0-x17 + d0-d7` preservation across a
  clobber-everything `Snack.show`, exact Swift-String pair, once-per-volume
  dedup, empty-error and second-volume paths.
* **T5/T6** — static decode checks and the four-slide battery.
* Regressions on the 1.5.13 binary: the round-8 slide suite **51/51** and the
  round-7 suite **21/21** (132 checks total this round).

The emulation now also models the parts I previously faked: real selref
fixups (decoded + slid like dyld does) and the `x8` struct-return rule.

## Install & test

1. Delete the old app; sign & install `SaikiMotion-1.5.13-unsigned.ipa`.
   Release-notes last line: **"Round-9 build 1.5 (13): welcome-screen draw
   crash fixed - icon clear-rect caves rebuilt (registers, stack, rect ABI)."**
2. **Launch** — the welcome screen must fully render (buttons, icons, the
   update list).
3. Play/pause + quality selector: icons should swap cleanly with no ghosting
   (that's what these caves are for — now actually working).
4. Everything from 1.5 (12): FX browser shows Chromatic Aberration / Film
   Grain / CRT TV; `.glb` imports; VDB errors surface as a snack.

## Known limits (unchanged)

* Blosc VDBs still need re-export (Zip or none) — reason shown on screen.
* Timeline layer dragging (media left/right in time) still open.
* If anything still crashes, send the log — this round's stack decode took
  minutes and pinned the fault to one instruction; the same will work for
  whatever's next.
