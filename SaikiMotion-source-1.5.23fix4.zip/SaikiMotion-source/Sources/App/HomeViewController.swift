// HomeViewController.swift — the real home screen (round-19 §7 spec).
//
// Bottom menu bar: Account, Projects, AI, Community, Extras, Settings —
// pinned to the safe area, equal width, localized via L10n.tr() and
// re-rendered the moment the language changes.
//   • Projects — list + create/open/delete, opens the project screen
//   • Settings — the EN/ES/ID/JA picker (L10n.current)
//   • Extras — CrashLog.reportCount() + the Crash folder hint
//   • Account — AppInfo.displayVersion + the offline notice
//   • Community — the five bundled example effects (the real SDK defs)
//   • AI — an informational note (no AI backend ships in the source build)
//
// (Replaces HomeViewController.placeholder.swift, now deleted.)

import UIKit

final class HomeViewController: UIViewController {

    private enum Tab: Int, CaseIterable {
        case account, projects, ai, community, extras, settings

        var titleKey: String {
            switch self {
            case .account: return "Account"
            case .projects: return "Projects"
            case .ai: return "AI"
            case .community: return "Community"
            case .extras: return "Extras"
            case .settings: return "Settings"
            }
        }
    }

    private var current: UIViewController?
    private let content = UIView()
    private var barButtons: [UIButton] = []
    private var selectedTab: Tab = .projects

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        CrashLog.note("home")

        buildBar()
        buildContent()
        show(.projects)

        NotificationCenter.default.addObserver(self, selector: #selector(languageChanged),
                                               name: StoreNotification.languageChanged, object: nil)
    }

    // MARK: chrome ---------------------------------------------------------

    private func buildBar() {
        let stack = UIStackView()
        stack.axis = .horizontal
        stack.distribution = .fillEqually
        stack.backgroundColor = UIColor.secondarySystemBackground.withAlphaComponent(0.6)
        stack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stack)

        for tab in Tab.allCases {
            let b = UIButton(type: .system)
            b.tag = tab.rawValue
            b.setTitle(L10n.tr(tab.titleKey), for: .normal)
            b.titleLabel?.font = .systemFont(ofSize: 10, weight: .medium)
            b.addTarget(self, action: #selector(barTapped(_:)), for: .touchUpInside)
            b.translatesAutoresizingMaskIntoConstraints = false
            stack.addArrangedSubview(b)
            barButtons.append(b)
        }

        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            stack.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            stack.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            stack.heightAnchor.constraint(equalToConstant: 49),
        ])
    }

    private func buildContent() {
        content.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(content)
        NSLayoutConstraint.activate([
            content.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            content.bottomAnchor.constraint(equalTo: barButtons[0].topAnchor),
            content.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            content.trailingAnchor.constraint(equalTo: view.trailingAnchor),
        ])
    }

    @objc private func barTapped(_ sender: UIButton) {
        if let tab = Tab(rawValue: sender.tag) { show(tab) }
    }

    @objc private func languageChanged() {
        for (i, b) in barButtons.enumerated() {
            if let tab = Tab(rawValue: i) { b.setTitle(L10n.tr(tab.titleKey), for: .normal) }
        }
        show(selectedTab)
    }

    private func show(_ tab: Tab) {
        selectedTab = tab
        navigationItem.title = L10n.tr(tab.titleKey)
        for (i, b) in barButtons.enumerated() {
            let on = i == tab.rawValue
            b.tintColor = on ? .systemYellow : .systemBlue
            b.titleLabel?.font = .systemFont(ofSize: 10, weight: on ? .bold : .medium)
        }

        if let old = current {
            old.willMove(toParent: nil)
            old.view.removeFromSuperview()
            old.removeFromParent()
        }

        let vc = makeTab(tab)
        addChild(vc)
        content.addSubview(vc.view)
        vc.view.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            vc.view.topAnchor.constraint(equalTo: content.topAnchor),
            vc.view.bottomAnchor.constraint(equalTo: content.bottomAnchor),
            vc.view.leadingAnchor.constraint(equalTo: content.leadingAnchor),
            vc.view.trailingAnchor.constraint(equalTo: content.trailingAnchor),
        ])
        vc.didMove(toParent: self)
        current = vc
    }

    private func makeTab(_ tab: Tab) -> UIViewController {
        switch tab {
        case .account: return AccountTab()
        case .projects: return ProjectsTab()
        case .ai: return AiTab()
        case .community: return EffectsGalleryViewController(mode: .browse)
        case .extras: return ExtrasTab()
        case .settings: return SettingsTab()
        }
    }
}

// MARK: - Account -----------------------------------------------------------

private final class AccountTab: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground

        let stack = UIStackView()
        stack.axis = .vertical
        stack.alignment = .center
        stack.spacing = 10
        stack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stack)

        let title = UILabel()
        title.text = "SaikiMotion"
        title.font = .systemFont(ofSize: 26, weight: .bold)

        let version = UILabel()
        version.text = "\(L10n.tr("Version")): \(AppInfo.displayVersion) (source build)"
        version.font = .systemFont(ofSize: 14)
        version.textColor = .secondaryLabel

        let bundle = UILabel()
        bundle.text = AppInfo.bundleId
        bundle.font = .monospacedSystemFont(ofSize: 11, weight: .regular)
        bundle.textColor = .tertiaryLabel

        let offline = UILabel()
        offline.text = L10n.tr("Offline notice")
        offline.font = .systemFont(ofSize: 13)
        offline.textColor = .secondaryLabel
        offline.textAlignment = .center
        offline.numberOfLines = 2

        stack.addArrangedSubview(title)
        stack.addArrangedSubview(version)
        stack.addArrangedSubview(bundle)
        stack.addArrangedSubview(offline)

        NSLayoutConstraint.activate([
            stack.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stack.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 32),
        ])
    }
}

// MARK: - Projects ----------------------------------------------------------

private final class ProjectsTab: UIViewController {

    private var projects: [Project] = []
    private let table = UITableView(frame: .zero, style: .insetGrouped)

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground

        navigationItem.title = L10n.tr("Projects")
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            barButtonSystemItem: .add, target: self, action: #selector(newProject))

        table.dataSource = self
        table.delegate = self
        table.register(SubtitleCell.self, forCellReuseIdentifier: "project")
        table.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(table)
        NSLayoutConstraint.activate([
            table.topAnchor.constraint(equalTo: view.topAnchor),
            table.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            table.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            table.trailingAnchor.constraint(equalTo: view.trailingAnchor),
        ])

        NotificationCenter.default.addObserver(self, selector: #selector(reload),
                                               name: StoreNotification.projectsChanged, object: nil)
        reload()
    }

    @objc private func reload() {
        projects = Projects.list()
        table.reloadData()
    }

    @objc private func newProject() {
        let alert = UIAlertController(title: L10n.tr("New Project"), message: nil,
                                      preferredStyle: .alert)
        alert.addTextField { tf in tf.placeholder = L10n.tr("New Project") }
        alert.addAction(UIAlertAction(title: L10n.tr("Cancel"), style: .cancel))
        alert.addAction(UIAlertAction(title: L10n.tr("OK"), style: .default) { [weak self] _ in
            let name = alert.textFields?.first?.text?.trimmingCharacters(in: .whitespaces) ?? ""
            guard !name.isEmpty else { return }
            var project = Project(name: name)
            Projects.save(&project)
            self?.reload()
            self?.open(project)
        })
        present(alert, animated: true)
    }

    private func open(_ project: Project) {
        CrashLog.note("open_project")
        navigationController?.pushViewController(EditorViewController(projectId: project.id),
                                                 animated: true)
    }
}

extension ProjectsTab: UITableViewDataSource, UITableViewDelegate {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        projects.isEmpty ? 1 : projects.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "project", for: indexPath)
        if projects.isEmpty {
            cell.textLabel?.text = L10n.tr("New Project")
            cell.detailTextLabel?.text = "tap + to create one"
            cell.selectionStyle = .none
            return cell
        }
        guard let p = projects[safe: indexPath.row] else { return cell }
        cell.textLabel?.text = p.name
        cell.detailTextLabel?.text = Projects.resLabel(p)
        cell.accessoryType = .disclosureIndicator
        cell.selectionStyle = .default
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if let p = projects[safe: indexPath.row] { open(p) }
    }

    func tableView(_ tableView: UITableView,
                   trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        guard projects.indices.contains(indexPath.row) else { return nil }
        let action = UIContextualAction(style: .destructive, title: L10n.tr("Delete")) { [weak self] _, _, done in
            guard let self = self, let p = self.projects[safe: indexPath.row] else { done(false); return }
            Projects.delete(p.id)
            self.reload()
            done(true)
        }
        return UISwipeActionsConfiguration(actions: [action])
    }
}

// MARK: - AI ------------------------------------------------------------------

private final class AiTab: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground

        let label = UILabel()
        label.numberOfLines = 0
        label.textAlignment = .center
        label.font = .systemFont(ofSize: 14)
        label.textColor = .secondaryLabel
        label.text = "AI tools are offline in this build — the keyframe\n"
            + "expressions (wiggle, noise, markers) cover the motion side.\n"
            + "Everything else in the editor works fully offline."
        label.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(label)
        NSLayoutConstraint.activate([
            label.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            label.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            label.leadingAnchor.constraint(greaterThanOrEqualTo: view.leadingAnchor, constant: 24),
            label.trailingAnchor.constraint(lessThanOrEqualTo: view.trailingAnchor, constant: -24),
        ])
    }
}

// MARK: - Extras ---------------------------------------------------------------

private final class ExtrasTab: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground

        let stack = UIStackView()
        stack.axis = .vertical
        stack.alignment = .center
        stack.spacing = 10
        stack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stack)

        let count = UILabel()
        count.text = "\(L10n.tr("Crash reports")): \(CrashLog.reportCount())"
        count.font = .systemFont(ofSize: 17, weight: .semibold)

        let where = UILabel()
        where.text = L10n.tr("in the Crash folder of this app")
        where.font = .systemFont(ofSize: 13)
        where.textColor = .secondaryLabel
        where.textAlignment = .center
        where.numberOfLines = 2

        let version = UILabel()
        version.text = "\(L10n.tr("Version")): \(AppInfo.displayVersion)"
        version.font = .systemFont(ofSize: 12)
        version.textColor = .tertiaryLabel

        stack.addArrangedSubview(count)
        stack.addArrangedSubview(where)
        stack.addArrangedSubview(version)

        NSLayoutConstraint.activate([
            stack.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stack.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 28),
        ])
    }
}

// MARK: - Settings ---------------------------------------------------------------

private final class SettingsTab: UIViewController {

    private let table = UITableView(frame: .zero, style: .insetGrouped)

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        navigationItem.title = L10n.tr("Settings")

        table.dataSource = self
        table.delegate = self
        table.register(UITableViewCell.self, forCellReuseIdentifier: "lang")
        table.isScrollEnabled = false
        table.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(table)
        NSLayoutConstraint.activate([
            table.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            table.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            table.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            table.heightAnchor.constraint(equalToConstant: CGFloat(L10n.languages.count * 48 + 60)),
        ])
    }
}

extension SettingsTab: UITableViewDataSource, UITableViewDelegate {

    func numberOfSections(in tableView: UITableView) -> Int { 1 }

    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        L10n.tr("Language")
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        L10n.languages.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "lang", for: indexPath)
        if let lang = L10n.languages[safe: indexPath.row] {
            cell.textLabel?.text = lang.label
            cell.accessoryType = lang.code == L10n.current ? .checkmark : .none
        }
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        guard let lang = L10n.languages[safe: indexPath.row] else { return }
        L10n.current = lang.code
        StoreNotification.post(.languageChanged)
        tableView.reloadData()
    }
}
