// TimelineView.swift — the real timeline (UI).
//
// Ruler + playhead + one row per layer (top of the list draws on top), with
// nested children under groups, keyframe diamonds under animated parameters
// and touch editing: tap to select, scrub the ruler / drag the playhead,
// drag a bar to slide it, drag its edges to trim, tap the eye to toggle
// visibility, tap a diamond to jump into the graph editor, drag in the
// gutter to reorder.

import UIKit

// MARK: - host protocols (the editor implements both)

protocol EditHost: AnyObject {
    func selectedLayer() -> Layer?
    func selectedId() -> Int
    func isSelected(_ id: Int) -> Bool
    func onSelect(_ id: Int)
    func beginEdit()
    func onEdited()
    func autoKey() -> Bool
}

protocol TimelineHost: AnyObject {
    func selectedLayer() -> Layer?
    func autoKey() -> Bool
    func beginEdit()
    func onEdited()
    func onSeek(_ t: Float)
    func onSelect(_ id: Int)
    func onToggleVisible(_ l: Layer)
    func onTimingChanged()
    func onReorder(_ l: Layer, _ listIndex: Int)
    func onKeyTap(_ l: Layer, _ key: String, _ idx: Int)
}

// MARK: - the view

final class TimelineView: UIView {

    private weak var editHost: EditHost?
    private weak var tlHost: TimelineHost?

    private let gutterW: CGFloat = 148
    private let rowH: CGFloat = 34
    private let rulerH: CGFloat = 26
    private var pxPer: CGFloat = 60          // pixels per second
    private var scrollX: CGFloat = 0
    private var expandedGroups: Set<Int> = []
    private var expandedKeys: Set<Int> = []

    private var dragMode = 0                 // 0 none 1 scrub 2 move 3 trim-in 4 trim-out 5 reorder 6 pan
    private var dragLayer: Layer? = nil
    private var dragStart = CGPoint.zero
    private var dragStartT: Float = 0
    private var dragStartEnd: Float = 0
    private var dragReorderIdx = -1

    init(_ edit: EditHost, _ timeline: TimelineHost) {
        super.init(frame: .zero)
        editHost = edit
        tlHost = timeline
        backgroundColor = argbToUIColor(Int32(bitPattern: 0xFF101014))
        contentMode = .redraw
        isMultipleTouchEnabled = false
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    // MARK: - public surface

    func timecode(_ t: Float) -> String {
        let m = Int(t) / 60
        let s = Int(t) % 60
        let f = Int((t - Float(Int(t))) * Float(Editor.project.fps))
        return String(format: "%d:%02d.%02d", m, s, f)
    }

    /// Zooms so the whole scene fits the visible width.
    func fitToScene() {
        let w = bounds.width - gutterW - 16
        if w > 10, Editor.scene.duration > 0.1 {
            pxPer = w / CGFloat(Editor.scene.duration)
            scrollX = 0
            setNeedsDisplay()
        }
    }

    /// Expands every group and every keyframe row (the "Show All Keyframes" menu).
    func expandAll() {
        expandedGroups = Set(Editor.scene.layers.map { $0.id })
        expandedKeys = Set(Editor.scene.layers.map { $0.id })
        setNeedsDisplay()
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        if pxPer < 4 || !bounds.isEmpty {
            ensureSaneZoom()
        }
    }

    private func ensureSaneZoom() {
        let w = bounds.width - gutterW - 16
        if w > 10, Editor.scene.duration > 0.1 {
            let fit = w / CGFloat(Editor.scene.duration)
            if pxPer < 4 || pxPer > 4000 { pxPer = fit }
            pxPer = max(pxPer, min(fit, 12))
        }
        scrollX = clamp(scrollX, 0, maxScroll())
        setNeedsDisplay()
    }

    private func maxScroll() -> CGFloat {
        let contentW = CGFloat(Editor.scene.duration + 2) * pxPer
        return max(0, contentW - (bounds.width - gutterW) + 16)
    }

    // MARK: - layout model

    private struct Row {
        let layer: Layer
        let depth: Int
        let isKeys: Bool
        let keyName: String
    }

    private var rows: [Row] = []

    private func rebuildRows() {
        rows = []
        var stack: [(Layer, Int)] = Editor.scene.layers.reversed().map { ($0, 0) }
        while let (l, d) = stack.popLast() {
            rows.append(Row(layer: l, depth: d, isKeys: false, keyName: ""))
            let animated = l.props.filter { $0.value.keys.count >= 1 }.map { $0.key }.sorted()
            if expandedKeys.contains(l.id) {
                for k in animated {
                    rows.append(Row(layer: l, depth: d + 1, isKeys: true, keyName: k))
                }
            }
            if expandedGroups.contains(l.id) || d == 0 {
                let children = Editor.scene.layers.filter { $0.parentId == l.id }
                for c in children.reversed() {
                    stack.append((c, min(d + 1, 6)))
                }
            }
        }
    }

    // MARK: - geometry

    private func xOf(_ t: Float) -> CGFloat {
        gutterW + CGFloat(t) * pxPer - scrollX
    }

    private func tOf(_ x: CGFloat) -> Float {
        Float((x - gutterW + scrollX) / max(pxPer, 0.001))
    }

    private func rowAt(_ y: CGFloat) -> Int? {
        let i = Int((y - rulerH) / rowH)
        guard y >= rulerH, rows.indices.contains(i) else { return nil }
        return i
    }

    // MARK: - drawing

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        rebuildRows()

        let w = bounds.width
        let h = bounds.height

        // gutter background
        fillRect(c, CGRect(x: 0, y: 0, width: gutterW, height: h), Int32(bitPattern: 0xFF0C0C0F))
        strokeLine(c, gutterW, 0, gutterW, h, 1, C.LINE)

        // ruler
        fillRect(c, CGRect(x: gutterW, y: 0, width: w - gutterW, height: rulerH), Int32(bitPattern: 0xFF16161B))
        let step: Float = niceStep()
        var t: Float = 0
        while xOf(t) < w + 40 {
            let x = xOf(t)
            if x >= gutterW - 1 {
                strokeLine(c, x, rulerH - 10, x, rulerH, 1, Int32(bitPattern: 0xFF5A5A64))
                drawText(timecode(t), x + 3, rulerH - 11, color: C.DIM, size: 9, align: .left)
            }
            t += step
        }

        // rows
        for (i, row) in rows.enumerated() {
            let y = rulerH + CGFloat(i) * rowH
            if y > h { break }
            drawRow(c, row, i, y)
        }

        // markers
        for m in Editor.scene.markers {
            let x = xOf(m)
            if x >= gutterW, x <= w {
                strokeLine(c, x, rulerH, x, h, 1, Int32(bitPattern: 0x8038BDF8))
            }
        }

        // playhead
        let px = xOf(Editor.time)
        if px >= gutterW - 1 {
            strokeLine(c, px, 0, px, h, 1.5, C.GREEN)
            fillRect(c, CGRect(x: px - 26, y: 0, width: 52, height: 14), C.GREEN)
            drawText(timecode(Editor.time), px, 7, color: Int32(bitPattern: 0xFF2B1400), size: 9,
                     bold: true, align: .center)
        }

        // reorder hint
        if dragMode == 5, dragReorderIdx >= 0, rows.indices.contains(dragReorderIdx) {
            let y = rulerH + CGFloat(dragReorderIdx) * rowH
            strokeLine(c, gutterW, y, w, y, 2, C.AMBER)
        }
    }

    private func niceStep() -> Float {
        let target: Float = 80 / Float(max(pxPer, 0.001))
        let steps: [Float] = [0.1, 0.25, 0.5, 1, 2, 5, 10, 15, 30, 60, 120]
        for s in steps where s >= target { return s }
        return 300
    }

    private func drawRow(_ c: CGContext, _ row: Row, _ idx: Int, _ y: CGFloat) {
        let l = row.layer
        let sel = editHost?.isSelected(l.id) ?? false

        if row.isKeys {
            // keyframe strip for one parameter
            drawText(Registry.propDef(row.keyName)?.label ?? row.keyName,
                     gutterW - 14 - CGFloat(row.depth) * 12, y + rowH / 2 + 3,
                     color: C.DIM, size: 9, align: .right)
            if let tr = l.props[row.keyName] {
                for (ki, k) in tr.keys.enumerated() {
                    let x = xOf(k.t)
                    if x < gutterW - 4 || x > bounds.width + 4 { continue }
                    let on = abs(k.t - Editor.time) < 0.02
                    drawDiamond(c, x, y + rowH / 2, 4.5,
                                on ? C.GREEN : C.TEXT)
                    _ = ki
                }
            }
            strokeLine(c, gutterW, y + rowH, bounds.width, y + rowH, 0.5, Int32(bitPattern: 0xFF1A1A20))
            return
        }

        // gutter: eye + expander + name
        let eyeX: CGFloat = 10 + CGFloat(row.depth) * 12
        Icons.draw(c, l.visible ? "eye" : "eye_off", eyeX, y + rowH / 2, 13,
                   l.visible ? Int32(bitPattern: 0xFF9A9AA4) : C.DIM)
        var textX = eyeX + 16
        let children = Editor.scene.layers.filter { $0.parentId == l.id }
        if !children.isEmpty {
            let open = expandedGroups.contains(l.id)
            Icons.draw(c, open ? "chev_down" : "chev_up", eyeX + 18, y + rowH / 2, 11, C.DIM)
            textX = eyeX + 34
        }
        Icons.draw(c, typeIcon(l), textX + 7, y + rowH / 2, 12, sel ? C.GREEN : C.TEXT)
        drawText(l.name, textX + 18, y + rowH / 2 + 3.5,
                 color: sel ? C.GREEN : C.TEXT, size: 11, bold: sel, align: .left)

        // track area
        let x0 = xOf(l.start)
        let x1 = xOf(l.end)
        let barY = y + 5
        let barH = rowH - 10
        if sel {
            fillRect(c, CGRect(x: gutterW, y: y, width: bounds.width - gutterW, height: rowH),
                     Int32(bitPattern: 0xFF1E1E16))
        }
        if x1 >= gutterW && x0 <= bounds.width {
            var bx0 = max(x0, gutterW + 1)
            let bx1 = min(x1, bounds.width - 1)
            if x1 > bounds.width { bx0 = min(bx0, bounds.width - 4) }
            if bx1 > bx0 {
                let barCol = l.visible ? (sel ? Int32(bitPattern: 0xFF3A4E2B) : Int32(bitPattern: 0xFF26262E))
                    : Int32(bitPattern: 0xFF1A1A20)
                fillRoundRect(c, CGRect(x: bx0, y: barY, width: bx1 - bx0, height: barH), 6, barCol)
                strokeRoundRect(c, CGRect(x: bx0, y: barY, width: bx1 - bx0, height: barH), 6, 1,
                                sel ? C.GREEN : Int32(bitPattern: 0xFF3A3A44))
                drawText(l.type == .AUDIO ? "♪" : l.name,
                         (bx0 + bx1) / 2, y + rowH / 2 + 3,
                         color: l.visible ? C.TEXT : C.DIM, size: 10, align: .center)
            }
        }
        strokeLine(c, gutterW, y + rowH, bounds.width, y + rowH, 0.5, Int32(bitPattern: 0xFF1A1A20))
    }

    private func drawDiamond(_ c: CGContext, _ x: CGFloat, _ y: CGFloat, _ r: CGFloat, _ col: Int32) {
        let p = CGMutablePath()
        p.move(to: CGPoint(x: x, y: y - r))
        p.addLine(to: CGPoint(x: x + r, y: y))
        p.addLine(to: CGPoint(x: x, y: y + r))
        p.addLine(to: CGPoint(x: x - r, y: y))
        p.closeSubpath()
        c.addPath(p)
        c.setFillColor(argbToUIColor(col).cgColor)
        c.fillPath()
    }

    private func typeIcon(_ l: Layer) -> String {
        switch l.type {
        case .SHAPE: return "shape"
        case .TEXT: return "text"
        case .IMAGE, .VIDEO: return "media"
        case .CAMERA: return "camera"
        case .NULL: return "nullobj"
        case .MODEL: return "cube"
        case .PARTICLES: return "particles"
        case .GROUP: return "layers"
        case .ADJUST: return "adjust"
        case .AUDIO: return "audio"
        case .FLARE: return "flare"
        }
    }

    // MARK: - touches

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        let p = t.location(in: self)

        // ruler / playhead → scrub
        if p.y < rulerH && p.x >= gutterW - 8 {
            dragMode = 1
            dragStart = p
            seek(to: tOf(p.x))
            return
        }

        guard let idx = rowAt(p.y) else {
            dragMode = 6
            dragStart = p
            return
        }
        let row = rows[idx]
        let l = row.layer

        // gutter interactions
        if p.x < gutterW {
            let eyeX = 10 + CGFloat(row.depth) * 12
            if p.x < eyeX + 24 {
                tlHost?.onToggleVisible(l)
                setNeedsDisplay()
                return
            }
            let children = Editor.scene.layers.filter { $0.parentId == l.id }
            if !children.isEmpty && p.x < eyeX + 40 {
                if expandedGroups.contains(l.id) {
                    expandedGroups.remove(l.id)
                } else {
                    expandedGroups.insert(l.id)
                }
                setNeedsDisplay()
                return
            }
            if row.isKeys {
                // gutter tap on a key row selects the layer
                tlHost?.onSelect(l.id)
                setNeedsDisplay()
                return
            }
            // drag to reorder
            tlHost?.beginEdit()
            dragMode = 5
            dragLayer = l
            dragReorderIdx = idx
            dragStart = p
            return
        }

        if row.isKeys {
            // tap a keyframe diamond
            if let tr = l.props[row.keyName] {
                for (ki, k) in tr.keys.enumerated() {
                    if abs(xOf(k.t) - p.x) < 12 {
                        tlHost?.onKeyTap(l, row.keyName, ki)
                        setNeedsDisplay()
                        return
                    }
                }
            }
            tlHost?.onSelect(l.id)
            setNeedsDisplay()
            return
        }

        // track area
        let x0 = xOf(l.start)
        let x1 = xOf(l.end)
        tlHost?.onSelect(l.id)
        if abs(p.x - x0) < 14 && l.type != .GROUP {
            tlHost?.beginEdit()
            dragMode = 3
            dragLayer = l
            dragStartT = l.start
            dragStartEnd = l.end
        } else if abs(p.x - x1) < 14 && l.type != .GROUP {
            tlHost?.beginEdit()
            dragMode = 4
            dragLayer = l
            dragStartT = l.start
            dragStartEnd = l.end
        } else if p.x > x0 - 6 && p.x < x1 + 6 {
            tlHost?.beginEdit()
            dragMode = 2
            dragLayer = l
            dragStartT = l.start
            dragStartEnd = l.end
            dragStart = p
        } else {
            dragMode = 6
            dragStart = p
        }
        setNeedsDisplay()
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        let p = t.location(in: self)
        let dx = p.x - dragStart.x

        switch dragMode {
        case 1: // scrub
            seek(to: tOf(p.x))
        case 2: // slide the layer
            guard let l = dragLayer else { return }
            let dt = Float(dx / max(pxPer, 0.001))
            let len = dragStartEnd - dragStartT
            l.start = max(0, dragStartT + dt)
            l.end = l.start + len
            tlHost?.onTimingChanged()
            setNeedsDisplay()
        case 3: // trim in
            guard let l = dragLayer else { return }
            let dt = Float(dx / max(pxPer, 0.001))
            l.start = clamp(dragStartT + dt, 0, dragStartEnd - 0.1)
            tlHost?.onTimingChanged()
            setNeedsDisplay()
        case 4: // trim out
            guard let l = dragLayer else { return }
            let dt = Float(dx / max(pxPer, 0.001))
            l.end = max(dragStartEnd + dt, l.start + 0.1)
            tlHost?.onTimingChanged()
            setNeedsDisplay()
        case 5: // reorder preview
            if let idx = rowAt(p.y) {
                dragReorderIdx = idx
                setNeedsDisplay()
            }
        case 6: // pan
            scrollX = clamp(scrollX - dx, 0, maxScroll())
            dragStart = p
            setNeedsDisplay()
        default:
            break
        }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if dragMode == 5, let l = dragLayer, let idx = rowAt(max(dragStart.y, 0)) {
            _ = idx
            if let y = touches.first?.location(in: self).y, let target = rowAt(y) {
                let targetLayer = rows[target].layer
                if targetLayer !== l {
                    // compute the list index the editor expects (index among
                    // scene.layers of the row's layer)
                    let listIdx = Editor.scene.layers.firstIndex { $0 === targetLayer } ?? 0
                    tlHost?.onReorder(l, listIdx)
                }
            }
        }
        dragMode = 0
        dragLayer = nil
        setNeedsDisplay()
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        dragMode = 0
        dragLayer = nil
        setNeedsDisplay()
    }

    private func seek(to t: Float) {
        let clamped = clamp(t, 0, Editor.scene.duration)
        tlHost?.onSeek(clamped)
        setNeedsDisplay()
    }
}
