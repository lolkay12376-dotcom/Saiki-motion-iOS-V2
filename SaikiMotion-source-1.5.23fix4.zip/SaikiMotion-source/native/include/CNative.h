#ifndef CNATIVE_H
#define CNATIVE_H

/* Umbrella for the SaikiMotion native decoders module.
 * Linked as a static framework; imported from Swift as `import CNative`. */

#include "../blosc/blosc.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Alembic/Ogawa → GLB transcode (bridge.c). Writes "<stem>.glb" beside the
 * source and copies that path into out_glb_path. Returns 1 on success. */
int saiki_abc_to_glb(const char* src_path, char* out_glb_path, unsigned long out_cap);

#ifdef __cplusplus
}
#endif

#endif /* CNATIVE_H */
