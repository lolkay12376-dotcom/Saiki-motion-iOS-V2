// Store.swift — the persistence protocol every saved model adopts.
//
// `Store` = "this type round-trips through JObj". The editor's undo stack
// snapshots whole projects as JSON strings; presets and exported effects go
// through the same door.

import Foundation

protocol Store: AnyObject {
    func toJson() -> JObj
    static func fromJson(_ o: JObj) -> Self
}

/// Change notification used by list screens. Posts on the main thread.
enum StoreNotification {
    static let projectsChanged = Notification.Name("store.projectsChanged")
    static let languageChanged = Notification.Name("store.languageChanged")

    static func post(_ name: Notification.Name) {
        NotificationCenter.default.post(name: name, object: nil)
    }
}
