// GlbModel.swift — the GLB (binary glTF) loader (Render).
//
// One GPU buffer per primitive, VEC3 positions + normals + VEC2 uvs, indices
// as UNSIGNED_SHORT/INT. On load (round-4 rule) every mesh is normalized:
// re-centred on its bounding-box centre and rescaled so the largest
// dimension is 1.4 world units, so any model lands inside the default
// camera. `.abc` paths are transcoded first through the native decoder and
// the produced .glb is what loads.

import Foundation
import OpenGLES
import GLKit

final class GlbModel {

    struct Prim {
        var count: GLsizei = 0
        var vbo: GLuint = 0
        var ibo: GLuint = 0
        var indexed = false
        var indexType: GLenum = GLenum(GL_UNSIGNED_SHORT)
        var color: [Float] = [0.78, 0.8, 0.86, 1]
    }

    var prims: [Prim] = []

    // MARK: - loading

    /// Loads (and caches) a model. `.abc` inputs are transcoded once; the
    /// stored path is rewritten to the sibling .glb.
    static func load(_ path: String) -> GlbModel? {
        var p = path
        if p.lowercased().hasSuffix(".abc") {
            p = transcodeAbc(p) ?? p
        }
        guard p.lowercased().hasSuffix(".glb") else { return nil }
        if let m = cache[p] { return m }
        guard let data = FileManager.default.contents(atPath: p) else { return nil }
        guard let m = parse(data) else { return nil }
        cache[p] = m
        return m
    }

    private static var cache: [String: GlbModel] = [:]

    /// Runs the native Ogawa decoder; returns the new .glb path.
    static func transcodeAbc(_ path: String) -> String? {
        var out = [CChar](repeating: 0, count: 1100)
        let ok = path.withCString { cstr in
            saiki_abc_to_glb(cstr, &out, 1100)
        }
        guard ok == 1 else { return nil }
        let glb = String(cString: out)
        return FileManager.default.fileExists(atPath: glb) ? glb : nil
    }

    /// The round-4 import normalization, applied to the in-sandbox copy.
    static func validate(path: String) -> String {
        if path.lowercased().hasSuffix(".abc"), let glb = transcodeAbc(path) {
            return glb
        }
        return path
    }

    // MARK: - GLB parsing

    private static func parse(_ data: Data) -> GlbModel? {
        let bytes = [UInt8](data)
        guard bytes.count > 12 else { return nil }
        guard bytes[0] == 0x67, bytes[1] == 0x6C, bytes[2] == 0x54, bytes[3] == 0x66 else { return nil } // "glTF"
        let total = u32(bytes, 4)
        guard Int(total) <= bytes.count else { return nil }
        guard bytes[8] == 0x4A, bytes[9] == 0x53, bytes[10] == 0x4F, bytes[11] == 0x4E else { return nil } // "JSON"

        let jsonLen = Int(u32(bytes, 12))
        guard jsonLen > 0, 20 + jsonLen <= bytes.count else { return nil }
        let jsonText = String(bytes: bytes[20..<(20 + jsonLen)], encoding: .utf8) ?? ""
        guard let json = JObj.parse(jsonText) else { return nil }

        var binStart = 20 + jsonLen
        // pad to 4
        if binStart % 4 != 0 { binStart += 4 - (binStart % 4) }
        guard binStart + 8 <= bytes.count else { return nil }
        let binLen = Int(u32(bytes, binStart))
        let binOff = binStart + 8
        guard binOff + binLen <= bytes.count else { return nil }
        let bin = Array(bytes[binOff..<(binOff + binLen)])

        let m = GlbModel()

        guard let meshes = json.optJSONArray("meshes"), meshes.count > 0 else { return nil }
        guard let accessors = json.optJSONArray("accessors"),
              let bufferViews = json.optJSONArray("bufferViews") else { return nil }

        // global bounds for normalization
        var allPts: [Float] = []

        for mi in 0..<meshes.count {
            guard let mesh = meshes.optJSONObject(mi) else { continue }
            guard let primsJ = mesh.optJSONArray("primitives") else { continue }
            for pi in 0..<primsJ.count {
                guard let primJ = primsJ.optJSONObject(pi) else { continue }
                guard let posAcc = primJ.optJSONObject("attributes")?.optInt("POSITION", -1),
                      posAcc >= 0, posAcc < accessors.count else { continue }
                guard let pa = accessors.optJSONObject(posAcc) else { continue }
                let posView = pa.optInt("bufferView", -1)
                guard posView >= 0, posView < bufferViews.count else { continue }
                guard let pv = bufferViews.optJSONObject(posView) else { continue }

                let byteOff = pv.optInt("byteOffset") + pa.optInt("byteOffset")
                let posCount = pa.optInt("count")
                var positions = [Float](repeating: 0, count: posCount * 3)
                readVec3(bin, pv.optInt("byteStride", 12), byteOff, posCount, into: &positions)
                allPts.append(contentsOf: positions)

                // normals (optional)
                var normals: [Float] = []
                if let nAcc = primJ.optJSONObject("attributes")?.optInt("NORMAL", -1), nAcc >= 0, nAcc < accessors.count,
                   let na = accessors.optJSONObject(nAcc), let nv = bufferViews.optJSONObject(na.optInt("bufferView", -1)) {
                    let nOff = nv.optInt("byteOffset") + na.optInt("byteOffset")
                    var nBuf = [Float](repeating: 0, count: na.optInt("count") * 3)
                    readVec3(bin, nv.optInt("byteStride", 12), nOff, na.optInt("count"), into: &nBuf)
                    normals = nBuf
                }

                // uvs (optional; flat fills)
                var uvs = [Float](repeating: 0, count: posCount * 2)
                if let tAcc = primJ.optJSONObject("attributes")?.optInt("TEXCOORD_0", -1), tAcc >= 0, tAcc < accessors.count,
                   let ta = accessors.optJSONObject(tAcc), let tv = bufferViews.optJSONObject(ta.optInt("bufferView", -1)) {
                    let tOff = tv.optInt("byteOffset") + ta.optInt("byteOffset")
                    let tCount = min(ta.optInt("count"), posCount)
                    let stride = tv.optInt("byteStride", 8)
                    for i in 0..<tCount {
                        let base = tOff + i * stride
                        if base + 7 < bin.count {
                            uvs[i * 2] = f32(bin, base)
                            uvs[i * 2 + 1] = f32(bin, base + 4)
                        }
                    }
                }

                // indices
                var indices: [UInt32] = []
                var indexed = false
                var indexType = GLenum(GL_UNSIGNED_SHORT)
                if let iAcc = primJ.optInt("indices", -1), iAcc >= 0, iAcc < accessors.count,
                   let ia = accessors.optJSONObject(iAcc), let iv = bufferViews.optJSONObject(ia.optInt("bufferView", -1)) {
                    let iOff = iv.optInt("byteOffset") + ia.optInt("byteOffset")
                    let iCount = ia.optInt("count")
                    let comp = ia.optInt("componentType", 5123)
                    if comp == 5125 { // UNSIGNED_INT
                        indexType = GLenum(GL_UNSIGNED_INT)
                        for i in 0..<iCount {
                            let base = iOff + i * 4
                            if base + 3 < bin.count { indices.append(u32(bin, base)) }
                        }
                        indexed = !indices.isEmpty
                    } else { // UNSIGNED_SHORT default
                        for i in 0..<iCount {
                            let base = iOff + i * 2
                            if base + 1 < bin.count { indices.append(UInt32(u16(bin, base))) }
                        }
                        indexed = !indices.isEmpty
                    }
                }
                if !indexed {
                    indices = (0..<UInt32(posCount)).map { $0 }
                }

                // interleave: pos(3) normal(3) uv(2)
                var verts = [Float]()
                verts.reserveCapacity(posCount * 8)
                for i in 0..<posCount {
                    verts.append(positions[i * 3])
                    verts.append(positions[i * 3 + 1])
                    verts.append(positions[i * 3 + 2])
                    if normals.count >= (i + 1) * 3 {
                        verts.append(normals[i * 3]); verts.append(normals[i * 3 + 1]); verts.append(normals[i * 3 + 2])
                    } else {
                        verts.append(0); verts.append(1); verts.append(0)
                    }
                    verts.append(uvs[i * 2]); verts.append(uvs[i * 2 + 1])
                }

                var prim = Prim()
                prim.count = GLsizei(indices.count)
                prim.indexed = indexed
                prim.indexType = indexType
                // base color from material if present
                if let matIdx = primJ.optInt("material", -1), matIdx >= 0,
                   let mats = json.optJSONArray("materials"), let mat = mats.optJSONObject(matIdx),
                   let pbr = mat.optJSONObject("pbrMetallicRoughness"),
                   let baseCol = pbr.optJSONArray("baseColorFactor"), baseCol.count >= 3 {
                    prim.color = [baseCol.optFloat(0), baseCol.optFloat(1), baseCol.optFloat(2), 1]
                }

                var vbo = GLuint(0)
                glGenBuffers(1, &vbo)
                glBindBuffer(GLenum(GL_ARRAY_BUFFER), vbo)
                verts.withUnsafeBufferPointer { ptr in
                    glBufferData(GLenum(GL_ARRAY_BUFFER), MemoryLayout<Float>.size * verts.count,
                                 ptr.baseAddress, GL_STATIC_DRAW)
                }
                prim.vbo = vbo

                var ibo = GLuint(0)
                glGenBuffers(1, &ibo)
                glBindBuffer(GLenum(GL_ELEMENT_ARRAY_BUFFER), ibo)
                indices.withUnsafeBufferPointer { ptr in
                    glBufferData(GLenum(GL_ELEMENT_ARRAY_BUFFER), MemoryLayout<UInt32>.size * indices.count,
                                 ptr.baseAddress, GL_STATIC_DRAW)
                }
                prim.ibo = ibo

                m.prims.append(prim)
            }
        }

        guard !m.prims.isEmpty else { return nil }

        // round-4 normalization: recentre + rescale to 1.4 units.
        // (positions live on the GPU already; apply as a model-space transform)
        var minX = Float.greatestFiniteMagnitude, minY = minX, minZ = minX
        var maxX = -Float.greatestFiniteMagnitude, maxY = maxX, maxZ = maxX
        var i = 0
        while i + 2 < allPts.count {
            minX = min(minX, allPts[i]); minY = min(minY, allPts[i + 1]); minZ = min(minZ, allPts[i + 2])
            maxX = max(maxX, allPts[i]); maxY = max(maxY, allPts[i + 1]); maxZ = max(maxZ, allPts[i + 2])
            i += 3
        }
        let cx = (minX + maxX) / 2, cy = (minY + maxY) / 2, cz = (minZ + maxZ) / 2
        let span = max(maxX - minX, max(maxY - minY, maxZ - minZ))
        let s = span > 0.0001 ? 1.4 / span : 1
        m.normalize = [s, -cx * s, -cy * s, -cz * s]   // scale + centre offset

        return m
    }

    /// normalization: [scale, offX, offY, offZ]
    var normalize: [Float] = [1, 0, 0, 0]

    private static func readVec3(_ bin: [UInt8], _ stride: Int, _ off: Int, _ count: Int, into out: inout [Float]) {
        for i in 0..<count {
            let base = off + i * max(stride, 12)
            if base + 11 < bin.count {
                out[i * 3] = f32(bin, base)
                out[i * 3 + 1] = f32(bin, base + 4)
                out[i * 3 + 2] = f32(bin, base + 8)
            }
        }
    }

    private static func u16(_ b: [UInt8], _ o: Int) -> UInt16 {
        UInt16(b[o]) | (UInt16(b[o + 1]) << 8)
    }

    private static func u32(_ b: [UInt8], _ o: Int) -> UInt32 {
        UInt32(b[o]) | (UInt32(b[o + 1]) << 8) | (UInt32(b[o + 2]) << 16) | (UInt32(b[o + 3]) << 24)
    }

    private static func f32(_ b: [UInt8], _ o: Int) -> Float {
        Float(bitPattern: u32(b, o))
    }

    // MARK: - drawing

    /// Draws with `program` (expects attributes aPos, aNormal, aUv).
    func draw(_ program: GLProgram) {
        program.use()
        for prim in prims {
            glBindBuffer(GLenum(GL_ARRAY_BUFFER), prim.vbo)
            glBindBuffer(GLenum(GL_ELEMENT_ARRAY_BUFFER), prim.ibo)
            let stride = GLsizei(MemoryLayout<Float>.size * 8)
            let aPos = glGetAttribLocation(program.handle, "aPos")
            let aNormal = glGetAttribLocation(program.handle, "aNormal")
            let aUv = glGetAttribLocation(program.handle, "aUv")
            if aPos >= 0 {
                glEnableVertexAttribArray(GLuint(aPos))
                glVertexAttribPointer(GLuint(aPos), 3, GLenum(GL_FLOAT), GLboolean(GL_FALSE), stride, nil)
            }
            if aNormal >= 0 {
                glEnableVertexAttribArray(GLuint(aNormal))
                glVertexAttribPointer(GLuint(aNormal), 3, GLenum(GL_FLOAT), GLboolean(GL_FALSE), stride,
                                      UnsafeRawPointer(bitPattern: MemoryLayout<Float>.size * 3))
            }
            if aUv >= 0 {
                glEnableVertexAttribArray(GLuint(aUv))
                glVertexAttribPointer(GLuint(aUv), 2, GLenum(GL_FLOAT), GLboolean(GL_FALSE), stride,
                                      UnsafeRawPointer(bitPattern: MemoryLayout<Float>.size * 6))
            }
            program.setVec4("uColor", prim.color[0], prim.color[1], prim.color[2], prim.color[3])
            glDrawElements(GLenum(GL_TRIANGLES), prim.count, prim.indexType, nil)
            if aPos >= 0 { glDisableVertexAttribArray(GLuint(aPos)) }
            if aNormal >= 0 { glDisableVertexAttribArray(GLuint(aNormal)) }
            if aUv >= 0 { glDisableVertexAttribArray(GLuint(aUv)) }
        }
    }
}
