// TextRaster.swift — text layers → UIImage (Render).
//
// All UIKit text styling (families, custom .ttf/.otf, stroke, second stroke,
// border box with fill, shadow, letter case/spacing) plus the per-letter
// animation stack (slide/fade/scale/rotate/typewriter/bounce/outline draw).
// Output is cached by a signature of style + quantized time so dragging the
// playhead doesn't re-raster the same frame twice.

import UIKit
import CoreText

enum TextRaster {

    private static var customFonts: [String: String] = [:]   // path → postscript name

    // MARK: - fonts

    private static func familyName(_ of: String) -> String {
        switch of {
        case "serif": return "Georgia"
        case "monospace", "serif-monospace": return "Menlo"
        case "cursive": return "Snell Roundhand"
        case "casual": return "Chalkboard SE"
        case "sans-serif-condensed": return "Avenir Next Condensed"
        case "sans-serif-light": return "Helvetica Neue"
        case "sans-serif-medium": return "Helvetica Neue Medium"
        case "sans-serif-black": return "HelveticaNeue-CondensedBlack"
        default: return "Helvetica Neue"
        }
    }

    /// Registers a font file once; returns its PostScript name.
    private static func registerFont(_ path: String) -> String? {
        if let n = customFonts[path] { return n }
        guard let data = FileManager.default.contents(atPath: path) else { return nil }
        guard let provider = CGDataProvider(data: data as CFData),
              let cg = CGFont(provider) else { return nil }
        var error: Unmanaged<CFError>? = nil
        if !CTFontManagerRegisterGraphicsFont(cg, &error) {
            // already registered is fine
            if let e = error?.takeUnretainedValue(),
               (e as NSError).code != 105 { return nil }
        }
        let name = cg.postScriptName as String? ?? "CustomFont"
        customFonts[path] = name
        return name
    }

    static func font(_ l: Layer, _ px: CGFloat) -> UIFont {
        if let path = l.fontPath, let name = registerFont(path) {
            var f = UIFont(name: name, size: px)
            if f == nil { f = UIFont(name: name, size: px) }
            if let f = f { return f }
        }
        let fam = familyName(l.font)
        var f = UIFont(name: fam, size: px)
        if f == nil { f = UIFont.systemFont(ofSize: px) }
        if l.bold && !(f?.fontName.lowercased().contains("bold") ?? false) {
            f = f?.bold()
        }
        if l.italic {
            let desc = f?.fontDescriptor.withSymbolicTraits(.traitItalic)
            if let d = desc { f = UIFont(descriptor: d, size: px) }
        }
        return f ?? .systemFont(ofSize: px)
    }

    private static func transformed(_ s: String, _ caps: Int) -> String {
        if caps == 1 { return s.uppercased() }
        if caps == 2 { return s.lowercased() }
        return s
    }

    // MARK: - measurement

    /// (width, height) in em-units (relative to font size 1) of the layer's
    /// text — drives quadSize.
    static func measure(_ l: Layer) -> (Float, Float) {
        let text = transformed(l.text.isEmpty ? " " : l.text, l.caps)
        let px: CGFloat = 512
        let f = font(l, px)
        let attr: [NSAttributedString.Key: Any] = [
            .font: f,
            .kern: CGFloat(l.spacing) * px,
        ]
        let str = NSAttributedString(string: text, attributes: attr)
        let b = str.boundingRect(with: CGSize(width: 10000, height: px * 3),
                                 options: [.usesLineFragmentOrigin],
                                 context: nil)
        let w = Float(max(b.width, px * 0.3)) / Float(px)
        let h = Float(max(b.height, px * 0.6)) / Float(px)
        return (w, h)
    }

    // MARK: - raster

    /// Renders the text layer at time `t` into a UIImage (transparent
    /// background, premultiplied alpha).
    static func raster(_ l: Layer, _ t: Float) -> UIImage {
        let text = transformed(l.text.isEmpty ? " " : l.text, l.caps)
        let px: CGFloat = 256
        let f = font(l, px)

        var attrs: [NSAttributedString.Key: Any] = [
            .font: f,
            .kern: CGFloat(l.spacing) * px,
            .foregroundColor: argbToUIColor(l.color),
        ]
        if l.underline { attrs[.underlineStyle] = NSUnderlineStyle.single.rawValue }
        if l.strike { attrs[.strikethroughStyle] = NSUnderlineStyle.single.rawValue }
        // UIKit stroke: negative width keeps the fill; strokePos 0 outside / 1 center / 2 inside
        if l.strokeW > 0.001 {
            let w = CGFloat(l.strokeW) * px * (l.strokePos == 2 ? 0.5 : 1.0)
            attrs[.strokeWidth] = (l.strokePos == 0 ? -w : w)
            attrs[.strokeColor] = argbToUIColor(l.strokeColor)
        }

        // per-letter anims (none → plain string)
        let hasAnims = !l.anims.isEmpty

        let measureStr = NSAttributedString(string: text, attributes: attrs)
        let pad: CGFloat = px * (0.35 + CGFloat(l.borderW + l.borderPad) + (l.shadowOn ? 0.2 : 0))
        let tb = measureStr.boundingRect(with: CGSize(width: 10000, height: px * 4),
                                         options: [.usesLineFragmentOrigin], context: nil)
        let borderPadPx = CGFloat(l.borderPad) * px
        let borderWPx = CGFloat(l.borderW) * px
        let w = ceil(tb.width) + pad * 2
        let h = ceil(tb.height) + pad * 2
        let size = CGSize(width: max(w, 8), height: max(h, 8))

        // time slice for anims (cached per 1/30 s)
        let ts = hasAnims ? Float(Int(t * 30)) / 30 : 0
        let key = "\(text)|\(l.color)|\(UInt32(bitPattern: l.strokeColor))|\(l.strokeW)|\(l.font)|\(l.fontPath ?? "")|\(l.bold)\(l.italic)\(l.underline)\(l.strike)|\(l.spacing)|\(l.align)|\(l.caps)|\(l.strokePos)|\(l.stroke2W)|\(UInt32(bitPattern: l.stroke2Color))|\(l.borderW)|\(UInt32(bitPattern: l.borderColor))|\(UInt32(bitPattern: l.borderFill))|\(l.borderPad)|\(l.borderDash)|\(l.shadowOn)|\(UInt32(bitPattern: l.shadowColor))|\(l.anims.count)|\(ts)"
        let ck = String(key.hashValue) + "-" + String(format: "%.0f-%.0f", size.width, size.height)
        if let img = cache[ck] { return img }
        trimCache()

        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 1
        fmt.opaque = false
        let r = UIGraphicsImageRenderer(size: size, format: fmt)
        let img = r.image { ctx in
            let c = ctx.cgContext
            let originY = pad   // first line's top
            let lineW = tb.width

            // border box behind the text
            if l.borderW > 0.001 || colorAlpha(l.borderFill) > 0 {
                let bx = pad - borderPadPx - borderWPx / 2
                let by = pad - borderPadPx - borderWPx / 2
                let bw = lineW + (borderPadPx + borderWPx / 2) * 2
                let bh = tb.height + (borderPadPx + borderWPx / 2) * 2
                let box = CGRect(x: bx, y: by, width: bw, height: bh)
                let path = UIBezierPath(roundedRect: box, cornerRadius: CGFloat(l.p("borderRadius", t)) * px)
                c.saveGState()
                c.addPath(path.cgPath)
                if colorAlpha(l.borderFill) > 0 {
                    c.setFillColor(argbToUIColor(l.borderFill).cgColor)
                    c.fillPath()
                    c.addPath(path.cgPath)
                }
                if l.borderW > 0.001 {
                    c.setStrokeColor(argbToUIColor(l.borderColor).cgColor)
                    c.setLineWidth(borderWPx)
                    if l.borderDash {
                        c.setLineDash(phase: 0, lengths: [borderWPx * 3, borderWPx * 2])
                    }
                    c.strokePath()
                }
                c.restoreGState()
            }

            // shadow for the whole text block
            if l.shadowOn {
                c.saveGState()
                c.setShadow(offset: CGSize(width: CGFloat(l.p("shadowX", t)) * px,
                                           height: -CGFloat(l.p("shadowY", t)) * px),
                            blur: CGFloat(l.p("shadowBlur", t)) * px,
                            color: argbToUIColor(l.shadowColor).cgColor)
                drawTextBlock(c, text, attrs, f, l, t, pad, originY, lineW, hasAnims, px)
                c.restoreGState()
            } else {
                drawTextBlock(c, text, attrs, f, l, t, pad, originY, lineW, hasAnims, px)
            }

            // second stroke pass (outside the first): stroke-only overdraw
            if l.stroke2W > 0.001 {
                var s2: [NSAttributedString.Key: Any] = attrs
                s2[.foregroundColor] = UIColor.clear
                s2[.strokeWidth] = -CGFloat(l.stroke2W) * px * 2 - abs((attrs[.strokeWidth] as? CGFloat) ?? 0)
                s2[.strokeColor] = argbToUIColor(l.stroke2Color)
                drawTextBlock(c, text, s2, f, l, t, pad, originY, lineW, hasAnims, px, strokeOnly: true)
            }
        }
        cache[ck] = img
        return img
    }

    /// Draws the text (per-letter when animated).
    private static func drawTextBlock(_ c: CGContext, _ text: String,
                                      _ attrs: [NSAttributedString.Key: Any], _ f: UIFont,
                                      _ l: Layer, _ t: Float,
                                      _ pad: CGFloat, _ originY: CGFloat, _ lineW: CGFloat,
                                      _ animated: Bool, _ px: CGFloat, strokeOnly: Bool = false) {
        if !animated {
            let str = NSAttributedString(string: text, attributes: attrs)
            let x: CGFloat
            switch l.align {
            case 0: x = pad
            case 2: x = pad + lineW - str.size().width
            default: x = pad + (lineW - str.size().width) / 2
            }
            str.draw(at: CGPoint(x: x, y: originY))
            return
        }

        // per-letter: measure each glyph, advance manually, apply anims
        let chars = Array(text)
        var x: CGFloat = pad
        let totalW = lineW
        if l.align == 1 { x = pad + (totalW - measurePlain(text, attrs)) / 2 }
        if l.align == 2 { x = pad + (totalW - measurePlain(text, attrs)) }

        for (i, ch) in chars.enumerated() {
            let s = String(ch)
            let glyph = NSAttributedString(string: s, attributes: attrs)
            let gs = glyph.size()
            let delay = CGFloat(i) * CGFloat(l.anims.reduce(0) { max($0, $1.stagger) })
            var alpha: CGFloat = 1
            var scale: CGFloat = 1
            var rot: CGFloat = 0
            var dx: CGFloat = 0
            var dy: CGFloat = 0

            for a in l.anims {
                let lt = CGFloat(t) - CGFloat(a.start) - delay
                let p = clamp(Float(lt / max(a.dur, 0.05)), 0, 1)
                let e = animEase(a, p)
                switch a.type {
                case 0: dy += (1 - e) * CGFloat(a.distance) * px          // slide up in
                case 1: dy -= (1 - e) * CGFloat(a.distance) * px          // slide down in
                case 2: alpha *= CGFloat(a.fade ? e : (p >= 1 ? 1 : 0.15 + 0.85 * e))   // fade in
                case 3: scale *= CGFloat(a.scaleFrom + (1 - a.scaleFrom) * e)           // scale in
                case 4: alpha *= p >= 1 ? 1 : (e > 0.5 ? 1 : 0)                        // typewriter
                case 5: scale *= CGFloat(a.scaleFrom + (1 - a.scaleFrom) * bounceOut(p)) // pop
                case 6: rot += (1 - e) * CGFloat(a.rotFrom) * .pi / 180  // rotate in
                case 7: dy -= e * CGFloat(a.distance) * px               // slide up out
                case 8: alpha *= 1 - e                                    // fade out
                case 9: dy += e * CGFloat(a.distance) * px               // slide down out
                case 10: scale *= CGFloat(a.scaleFrom + (1 - a.scaleFrom) * bounceOut(p))
                case 11: alpha *= e                                       // outline draw
                default: break
                }
            }

            let cx = x + gs.width / 2
            let cy = originY + gs.height / 2
            c.saveGState()
            c.translateBy(x: cx + dx, y: cy + dy)
            c.rotate(by: rot)
            c.scaleBy(x: scale, y: scale)
            if strokeOnly {
                // draw only where the glyph is (alpha stencil) — cheap trick:
                // draw glyph with clear text over the already-drawn stroke
                glyph.draw(at: CGPoint(x: -gs.width / 2, y: -gs.height / 2))
            } else {
                c.setAlpha(clamp(alpha, 0, 1))
                glyph.draw(at: CGPoint(x: -gs.width / 2, y: -gs.height / 2))
            }
            c.restoreGState()

            x += gs.width + (attrs[.kern] as? CGFloat ?? 0)
        }
    }

    private static func measurePlain(_ s: String, _ attrs: [NSAttributedString.Key: Any]) -> CGFloat {
        NSAttributedString(string: s, attributes: attrs).size().width
    }

    private static func animEase(_ a: TextAnim, _ p: Float) -> Float {
        switch a.ease {
        case 0: return p
        case 1: return Track.bezier(p, 0, 0, 0.58, 1)
        case 2: return Track.bezier(p, 0.42, 0, 0.58, 1)
        case 3: return Track.bounceOut(p)
        case 4: return Track.bezier(p, a.curve.x1, a.curve.y1, a.curve.x2, a.curve.y2)
        default: return p
        }
    }

    private static func bounceOut(_ u: Float) -> Float { Track.bounceOut(u) }

    // MARK: - cache

    private static var cache: [String: UIImage] = [:]
    private static var cacheOrder: [String] = []

    private static func trimCache() {
        if cache.count > 48 {
            let drop = cacheOrder.prefix(cache.count - 32)
            for k in drop { cache.removeValue(forKey: k) }
            cacheOrder.removeFirst(min(drop.count, cacheOrder.count))
        }
    }

    /// Called when a project closes.
    static func clearCache() {
        cache.removeAll()
        cacheOrder.removeAll()
    }
}
