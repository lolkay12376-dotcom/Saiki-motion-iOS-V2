// VideoFrames.swift — video layer frame sampling (Render).
//
// AVAssetImageGenerator at 1/10 s buckets: the preview asks for the frame at
// the playhead; a serial background queue generates it asynchronously while
// the previous texture keeps showing (no main-thread stalls — the R12/R14
// lesson). The exporter uses the synchronous mode on its own thread.

import Foundation
import AVFoundation
import OpenGLES
import GLKit

enum VideoFrames {

    private static var assets: [String: AVURLAsset] = [:]

    static func asset(_ path: String) -> AVURLAsset {
        if let a = assets[path] { return a }
        let a = AVURLAsset(url: URL(fileURLWithPath: path))
        assets[path] = a
        return a
    }

    static func videoSize(_ path: String) -> (Int, Int)? {
        guard let track = asset(path).tracks(withMediaType: .video).first else { return nil }
        let s = track.naturalSize.applying(track.preferredTransform)
        return (abs(Int(s.width)), abs(Int(s.height)))
    }

    static func duration(_ path: String) -> Float {
        Float(CMTimeGetSeconds(asset(path).duration))
    }

    // MARK: - sampler

    final class Sampler {
        let path: String
        let synchronous: Bool
        /// Async mode: fired on the main thread after a fresh frame uploads.
        var onUploaded: (() -> Void)? = nil
        private var generator: AVAssetImageGenerator?
        private let queue: DispatchQueue?
        private var pendingBucket = -1
        private var tex: GLuint = 0
        private var bucket = -1
        private(set) var size = (1, 1)

        init(path: String, synchronous: Bool = false) {
            self.path = path
            self.synchronous = synchronous
            let asset = VideoFrames.asset(path)
            let g = AVAssetImageGenerator(asset: asset)
            g.appliesPreferredTrackTransform = true
            g.requestedTimeToleranceBefore = CMTime(seconds: 0.05, preferredTimescale: 600)
            g.requestedTimeToleranceAfter = CMTime(seconds: 0.05, preferredTimescale: 600)
            g.isToneMapped = false
            generator = g
            if synchronous {
                queue = nil
            } else {
                queue = DispatchQueue(label: "saiki.video.\(path.hashValue)")
            }
            if let s = VideoFrames.videoSize(path) { size = s }
        }

        deinit {
            if tex != 0 {
                // Textures belong to the GL context/thread; the renderer's
                // cache trims on its own thread, so a leaked id here is
                // preferable to deleting on the wrong context.
            }
        }

        /// The frame at `srcTime` (seconds into the source) as a texture id.
        /// Async mode: returns the last generated frame while refreshing.
        func texture(at srcTime: Float) -> GLuint {
            let b = Int(max(0, srcTime) * 10)
            if b == bucket, tex != 0 { return tex }
            if synchronous {
                generate(srcTime, bucket: b)
                return tex
            }
            if b == pendingBucket { return tex }
            pendingBucket = b
            let q = queue
            let gen = generator
            if let q = q, let gen = gen {
                q.async { [weak self] in
                    guard let self = self else { return }
                    self.generate(srcTime, bucket: b)
                }
            }
            return tex
        }

        private func generate(_ t: Float, bucket b: Int) {
            guard let gen = generator else { return }
            let cm = CMTime(seconds: Double(max(0, t)), preferredTimescale: 600)
            guard let img = try? gen.copyCGImage(at: cm, actualTime: nil) else { return }
            let ui = UIImage(cgImage: img)
            // upload on the GL thread
            let doUpload = { [weak self] in
                guard let self = self else { return }
                if let newTex = Gl.upload(ui) {
                    if self.tex != 0 { Gl.delete(self.tex) }
                    self.tex = newTex
                    self.bucket = b
                    self.pendingBucket = -1
                }
            }
            if synchronous {
                doUpload()
            } else {
                DispatchQueue.main.async {
                    doUpload()
                    self.onUploaded?()
                }
            }
        }

        var current: GLuint { tex }
    }
}
