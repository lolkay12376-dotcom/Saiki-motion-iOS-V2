# SaikiMotion (source build)

SaikiMotion is a layer-based motion editor for iOS: keyframes with a graph
editor and expressions, a 70+ effect GLSL engine with a full SDK, text with
per-letter animations, optical flares, particles, 3D models, video/audio,
time remapping, motion blur and MP4 export. This repository builds it from
source with **GitHub Actions** — no Mac, no Xcode.

**This is the complete Batch 2/3 build (v1.5.23fix8)** — the editor, UI kit
and SDK IDE are in, plus the GLES renderer, 3D/VDB pipeline and exporter.

## How to build (the only thing you need to do)

1. Upload `SaikiMotion-source-1.5.23fix8.zip` to this repository
   (web UI → *Add file → Upload files* → drop the zip → commit).
2. Open the **Actions** tab → **Build SaikiMotion** → *Run workflow* (or
   just push — it runs on every push to main).
3. When the run turns green, download the **unsigned IPA** artifact.
4. In **LiveContainer**: delete the old SaikiMotion entry first, then
   import the IPA (LC signs it on import).

Both version keys change on every build (`1.5.23fix8` / `31`), so
LiveContainer can always tell builds apart. If several Saiki zips are in
the repo, the workflow picks the one with the highest version in its name
(`fix8` beats `fix7` beats `1.5.23`); you can also pick one manually via
the `zip_name` input on the *Run workflow* screen.

If a build fails, the log ends with a **BUILD FAILED — ERROR SUMMARY**
block — copy that block (not the whole log) into the chat.

## Layout

| Path | What it is |
| --- | --- |
| `project.yml` | XcodeGen spec — the "project file". Builds `SaikiMotion.xcodeproj` on the runner |
| `.github/workflows/build.yml` | The CI build (v7): unzip → xcodegen → xcodebuild → unsigned IPA |
| `Sources/App/` | `EditorViewController` (the editor screen), `SdkIdeViewController` (the SDK IDE), home + effects browser |
| `Sources/UI/` | UI kit (widgets, icons, pickers), preview, overlay, aspect layout, timeline |
| `Sources/Model/` | Project/Scene/Layer model, keyframe tracks + expressions, flares, persistence |
| `Sources/Effects/` | Effect defs, the ~75-effect GLSL catalog, Registry, thumbnail renderer |
| `Sources/Render/` | GLES compositor, text raster, particles, GLB loader, VDB volumes, water kit, video frames, MP4 exporter |
| `Sources/Core/` | org.json-style JObj/JArr, shared utils, dialogs, editor state |
| `Sources/CCrashLog/` | Signal-safe crash logger (C) |
| `native/` | Recovered C decoders: c-blosc 1.21.5 (VDB Blosc grids) and abc2glb (Alembic → GLB) |
| `Resources/sdk/examples/` | The five bundled SDK example effects (read-only in the IDE) |
| `Info.plist` | Bundle metadata — versions live here and in `AppInfo.swift` |

## Version history (short)

| Version | What landed |
| --- | --- |
| 1.5.23 (25) | Smoke-test shell — build pipeline proven end to end |
| fix1 (25) | Pointer-type compile fixes in the crash logger |
| fix2 (26) | Uncaught-exception handler as a top-level C function |
| fix3 (26) | Batch 1: project store, effects registry, media, home screen, interim detail screen |
| fix4 (27) | Batch 2+3: the full editor (4,200 lines), UI kit, SDK IDE, real timeline, GLES compositor with the 70+-effect GLSL engine, keyframes/expressions/graph editor, flares, particles, text animations, 3D (GLB/ABC), VDB volumes (Blosc + zlib), motion blur, MP4 export with audio, render settings UI |
| **fix5 (28)** | First full-source compile fixes: `where`/`open` reserved words as identifiers, C-style `u` integer-suffix literals, self-contained CNative umbrella header (relative include broke the Swift module), C warnings silenced |
| **fix6 (29)** | **Round 2 of full-source compile fixes (70 errors): optional unwraps (Projects.load, Registry examples), PillToggle stored-property override, throwing `getString`, layer-tree `isDescendant` helper, `JArr.optFloat`, Notification.Name extension for store events, identity-based `Layer: Hashable`, marker name→time map for expressions, GL constant `GLenum` conversions, self-contained texture upload, CFError/UIFont-bold/CGFloat fixes in TextRaster, `String(contentsOf:)` URL overload |
| **fix7 (30)** | Round 3: per-letter text-animation loop rebuilt on a strict Float→CGFloat boundary — every per-anim expression now computes in Float (`animEase`/`TextAnim` fields) and converts once at the assignment, which clears all 8 remaining TextRaster errors including the type-check timeout on the rotate-in case |
| **fix8 (31)** | Round 4 (9 errors, 5 files): graph/curve thumbnails call `Track.easeAt` (the Kotlin `Key.curve()` moved there), the noise-hash one-liner split into two statements (the compound `UInt32(bitPattern:) &* &+` expression tripped the solver), `import Compression` + `Int(got)` for the VDB zlib/Blosc path, `import UIKit` for Xf/VideoFrames, and the non-existent `AVAssetImageGenerator.isToneMapped` dropped (SDR is the default) |

The old per-round notes (BUILD.md, CHANGES-*.md, MISSING-SOURCE.md) were
folded into this file — one README, nothing else to close.

## Notes

- The app is **unsigned by design** (LiveContainer signs on import).
- The GLSL effect SDK works on-device: *Custom → Open Effect Editor*, or
  drop effect folders into `Documents/SaikiMotion/sdk/`.
- VDB grids decode with the bundled c-blosc (round-12 work: Houdini /
  EmberGen / OpenVDB 10 files); `.abc` files transcode to GLB on import.
