// Localization.swift — round 19 §6: Settings + four languages
// (English / Español / Bahasa Indonesia / 日本語).
//
// Language choice persists in NSUserDefaults ("app.language") and applies
// immediately: menu bar labels re-render from tr() on the next refresh.
//
// Status: the strings below cover the home screen (menu bar, Settings sheet,
// tab contents) and shared editor strings. The editor's domain strings are
// swept in a later pass — every toast()/alert already routes through tr()
// where it matters most (Cancel/OK/counts), and tr() falls back to the key
// (usually the English text) when a translation is missing.

import Foundation

enum L10n {

    static let languages: [(code: String, label: String)] = [
        ("en", "English"),
        ("es", "Español"),
        ("id", "Bahasa Indonesia"),
        ("ja", "日本語"),
    ]

    static var current: String {
        get {
            let v = UserDefaults.standard.string(forKey: "app.language") ?? "en"
            return languages.contains { $0.code == v } ? v : "en"
        }
        set {
            let v = languages.contains { $0.code == newValue } ? newValue : "en"
            UserDefaults.standard.set(v, forKey: "app.language")
        }
    }

    /// Translate a key. Keys are the English text; missing translations
    /// fall back to the key itself, so untranslated strings still render.
    static func tr(_ key: String) -> String {
        table[current]?[key] ?? table["en"]?[key] ?? key
    }

    // MARK: - string tables -------------------------------------------------

    private static let table: [String: [String: String]] = [
        "en": [
            "Account": "Account",
            "Projects": "Projects",
            "AI": "AI",
            "Community": "Community",
            "Extras": "Extras",
            "Settings": "Settings",
            "Language": "Language",
            "Cancel": "Cancel",
            "OK": "OK",
            "Delete": "Delete",
            "Import": "Import",
            "Export": "Export",
            "Close": "Close",
            "Version": "Version",
            "Offline notice": "Works offline. No account needed.",
            "Crash reports": "Crash reports",
            "in the Crash folder of this app": "in the Crash folder of this app",
            "Example effects": "Example effects",
            "New Project": "New Project",
            "projects": "projects",
        ],
        "es": [
            "Account": "Cuenta",
            "Projects": "Proyectos",
            "AI": "IA",
            "Community": "Comunidad",
            "Extras": "Extras",
            "Settings": "Ajustes",
            "Language": "Idioma",
            "Cancel": "Cancelar",
            "OK": "Aceptar",
            "Delete": "Eliminar",
            "Import": "Importar",
            "Export": "Exportar",
            "Close": "Cerrar",
            "Version": "Versión",
            "Offline notice": "Funciona sin conexión. No necesita cuenta.",
            "Crash reports": "Informes de fallos",
            "in the Crash folder of this app": "en la carpeta Crash de esta app",
            "Example effects": "Efectos de ejemplo",
            "New Project": "Nuevo proyecto",
            "projects": "proyectos",
        ],
        "id": [
            "Account": "Akun",
            "Projects": "Proyek",
            "AI": "AI",
            "Community": "Komunitas",
            "Extras": "Ekstra",
            "Settings": "Pengaturan",
            "Language": "Bahasa",
            "Cancel": "Batal",
            "OK": "OK",
            "Delete": "Hapus",
            "Import": "Impor",
            "Export": "Ekspor",
            "Close": "Tutup",
            "Version": "Versi",
            "Offline notice": "Berjalan luring. Tanpa akun.",
            "Crash reports": "Laporan kerusakan",
            "in the Crash folder of this app": "di folder Crash aplikasi ini",
            "Example effects": "Contoh efek",
            "New Project": "Proyek Baru",
            "projects": "proyek",
        ],
        "ja": [
            "Account": "アカウント",
            "Projects": "プロジェクト",
            "AI": "AI",
            "Community": "コミュニティ",
            "Extras": "その他",
            "Settings": "設定",
            "Language": "言語",
            "Cancel": "キャンセル",
            "OK": "OK",
            "Delete": "削除",
            "Import": "読み込む",
            "Export": "書き出す",
            "Close": "閉じる",
            "Version": "バージョン",
            "Offline notice": "オフラインで動作します。アカウント不要です。",
            "Crash reports": "クラッシュレポート",
            "in the Crash folder of this app": "このAppのCrashフォルダ内",
            "Example effects": "サンプルエフェクト",
            "New Project": "新規プロジェクト",
            "projects": "件のプロジェクト",
        ],
    ]
}
