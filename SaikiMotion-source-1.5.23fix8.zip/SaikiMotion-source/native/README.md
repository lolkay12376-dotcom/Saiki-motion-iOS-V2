# native/ — C decoders recovered from the binary rounds

These compiled into the shipped app's `__PATCH` segment from round 3/12
onward. In source form they become ordinary C targets (wire them the same
way `Sources/CCrashLog` is wired: a C target + a Swift target dependency).

## blosc/ — c-blosc 1.21.5 decompression (round 12)

The app's VDB parser originally spoke zlib only and explicitly rejected
Blosc-compressed grids ("This VDB uses Blosc compression…"). Blosc is what
Houdini, EmberGen and OpenVDB 10 write by default, so stock cloud packs
failed on arrival.

Files: the decompression path of c-blosc 1.21.5 — `blosc.c`, `blosclz.c`,
`shuffle.c`, `shuffle-generic.c`, `fastcopy.c` + headers. Verified against
OpenVDB v10's `bloscToStream`: codec lives in flag bits 5-7, `dont_split`
in bit 4, splits of `typesize` sub-streams per block, stored-raw blocks
where `cbytes == neblock`, Int64 size framing identical to ZIP.

**Integration (when `VdbVolume.swift` is recovered):** expose
`blosc_decompress` / the round-12 entry shape to Swift, delete both Blosc
rejection gates in the parser, route `compression & 4` chunks to Blosc and
everything else to zlib. Round 19 also moved the Blosc scratch into a
verified-free window and raised the decode cap 56 KB → ~127 KB; in source,
just allocate the scratch with malloc — no cave, no windows.

## abc2glb.c — Alembic/Ogawa → glTF (round 3)

Walks an Ogawa `.abc` archive (top object → child objects → `.geom`
compound → `P` / `.faceIndices` / `.faceCounts`, first sample) and writes a
`.glb` the app's own GLB loader accepts. Zero relocations, ~12.5 KB.

**Integration (when `GlbModel.swift` is recovered):** call it at the top of
`validate(path:)` for `.abc` paths, then apply the round-4 import-time
normalization to **every** GLB (transcoded or picked):

  * all VEC3/float32 POSITION accessors (identified by glTF-required
    min/max): recentre on the bounding-box centre, rescale so the largest
    dimension is 1.4 units — comfortably inside the default camera;
  * in place inside the sandbox copy only — the Photos/Files original is
    never touched;
  * idempotent (guards: k≈1 and centre≈0), so re-opening projects is stable;
  * leave exotic files alone: sparse accessors, morph targets, normalized
    accessors, interleaved bufferViews (byteStride ≠ 12), non-VEC3.

The round-4 host-side verifier for this logic is preserved at
`work/round4/round4.c` in the patch archive (not part of the app).
