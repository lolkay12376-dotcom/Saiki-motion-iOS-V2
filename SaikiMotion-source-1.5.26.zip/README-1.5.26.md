# SaikiMotion 1.5.26 (build 41)

Same build recipe as 1.5.25: `xcodegen generate` → `xcodebuild -project SaikiMotion.xcodeproj -scheme SaikiMotion -configuration Release -destination generic/platform=iOS CODE_SIGNING_ALLOWED=NO`. Your CI workflow (`.github/workflows/build.yml`, unchanged) already does this.

## Why your last CI run failed (and why this one won't)

The failure log you sent had 12 Swift errors, all in code added on top of 1.5.25
(particle presets, loop expressions). This source ships those features done
correctly, so you can **replace your whole repo content with this zip** and build.
The errors and how they're avoided here:

| # | Error in your log | Fix in 1.5.26 |
|---|---|---|
| 1–2 | `Anim.swift:719/721: passing 'Expr.Ctx' to an inout parameter requires '&'` | `Expr.loop()` takes `Ctx` **by value** (no inout), so no `&` is ever needed. `loopOut`/`loopIn` are real expression functions now. |
| 3 | `Layer.swift:232: cannot convert 'Int' to 'Float'` (`fps: Editor.project.fps`) | Not present; the particle sim is pure time-based. Anywhere fps meets a Float, it is written `Float(Editor.project.fps)` (as `timecode`/`stepFrame` already do). |
| 4 | `Particles.swift:74: missing argument label 't:'` | No `legacyField`; the deterministic `ParticlesSim.field` is the only path (scrub- and export-stable). |
| 5–11 | `ParticularPresets.swift: cannot convert 'JObj' to '(String, JObj)'` (7×) | `ParticularPresets.all` is properly typed `[(String, JObj)]` — `make()` returns the tuple. |
| 12 | `SceneRenderer.swift:650: cannot convert 'Int' to 'Float'` | Same as #3. |

If you'd rather patch your own tree instead of replacing it, the mechanical
fixes are: add `&` to the two `loop(ctx, …)` calls; wrap both
`fps: Editor.project.fps` in `Float(…)`; write `legacyField(p, t: t)`; and make
`make(...)` return `(name, json)` instead of a bare `JObj` (or wrap each element
as `(name, make(...))` in the array). Replacing with this zip is safer.

## What's new / fixed in 1.5.26

- **Particle presets** — the Particles toolbar tool now opens a sheet:
  Rain, Snow, Fire, Sparks, Fireworks, Dust, Bokeh, or a blank layer to tune
  yourself. Each preset sets count/spread/speed/gravity/life/direction/size
  and the two gradient colors.
- **loopOut / loopIn expressions** — `loopOut(2)` cycles your keyframes every
  2 s; `loopIn(2)` ping-pongs them. With no argument the span of the last
  key is used: `loopOut()`. `loopOut(2, 1)` forces ping-pong. Documented in
  the expression dialog (new "Loop" chip).
- **Orange theme is back** — accent `#FF8A1F`, dark accent `#D97706`, warm
  near-black text on fills. Every hardcoded green accent was swept (play pill,
  selected-row wash, render overlay glow/ring, SDK IDE highlight). Layer-type
  clip colors stay per-type (AM style); the green-screen key color stays green
  (it's content, not theme).
- **Transport fixed** — the prev/play/next group is now edge-pinned inside its
  pill; in 1.5.25 the pill had no width so the buttons spilled over their
  neighbours (the overlap you saw).
- **Timeline sidebar** — only the eye and the `^` arrow remain, packed tight;
  the gutter shrank 148 → 128 pt. The `^` expands/folds both children and
  keyframe rows (in 1.5.25 nothing toggled keyframe rows per-layer).
- **Playhead follows playback** — during play the view pages to keep the
  playhead visible and snaps back on loop-around.
- **Dashed selection gizmo** restored (6/4 pt dash, round caps).
- **Chibis breathe** — slow 2.4 s sleep-breathing pulse instead of a frozen
  static image.
- Version: **1.5.26 (41)** in Info.plist and AppInfo (both must always change —
  LiveContainer compares build numbers).

## Files touched

`Sources/Model/Anim.swift` (loop expressions, Ctx carries keySpan + value sampler),
`Sources/Effects/ParticularPresets.swift` (new), `Sources/App/Editor/EditorLayers.swift`
(preset-aware addParticles + sheet), `Sources/App/EditorViewController.swift`
(transport pin, preset sheet hook, playhead follow), `Sources/UI/TimelineView.swift`
(sidebar, gutter, followPlayhead), `Sources/UI/Theme.swift`, `Sources/UI/RenderOverlay.swift`,
`Sources/App/SdkIdeViewController.swift` (orange sweep), `Sources/UI/OverlayView.swift`
(dashed gizmo), `Sources/UI/Chibi.swift` (breathing), `Sources/App/Editor/EditorDialogs.swift`
(expression help + Loop chip), `Info.plist`, `Sources/Support/AppInfo.swift`.

## Known next steps (not in this build)

Graph editor / viewport polish and the deeper export-dialog rework are still
open; the APK reference run (Waydroid on desktop Linux, redroid or a headless
AVD on a server) is still the recommended way to compare behaviour against the
Android original before the next UI pass.
