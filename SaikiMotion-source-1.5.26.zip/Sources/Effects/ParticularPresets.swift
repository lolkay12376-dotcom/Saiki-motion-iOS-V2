// ParticularPresets.swift — ready-made particle looks (Effects).
//
// Seven one-tap presets for the "particles" effect, tuned against
// ParticlesSim.field and the PropDef ranges in Builtins.swift. Each entry is
// a (name, JObj) pair: the JObj holds plain track bases (pCount, pSpread, …)
// plus the two layer colors, so apply(_:_) can push it onto any fresh
// particle layer. The preset list drives the sheet shown by the Particles
// toolbar tool.

import Foundation

enum ParticularPresets {

    /// (name, config) pairs in menu order.
    static var all: [(String, JObj)] {
        return [
            make("Rain", Int32(bitPattern: 0xFFC7DBFF), Int32(bitPattern: 0xFFA8C4EE),
                 count: 260, spread: 2.6, speed: 1.4, gravity: 1.6,
                 life: 2.2, dirX: 0.12, dirY: 0.9, size: 0.028, seed: 7),
            make("Snow", Int32(bitPattern: 0xFFFFFFFF), Int32(bitPattern: 0xFFE8F0FF),
                 count: 200, spread: 2.8, speed: 0.25, gravity: 0.12,
                 life: 6, dirX: 0, dirY: 0.35, size: 0.05, seed: 21),
            make("Fire", Int32(bitPattern: 0xFFFFD24A), Int32(bitPattern: 0xFFD1350A),
                 count: 180, spread: 0.7, speed: 0.5, gravity: -0.55,
                 life: 1.1, dirX: 0, dirY: -0.8, size: 0.09, seed: 3),
            make("Sparks", Int32(bitPattern: 0xFFFFF3C4), Int32(bitPattern: 0xFFFF6A05),
                 count: 140, spread: 1.6, speed: 1.9, gravity: 0.9,
                 life: 1.4, dirX: 0, dirY: -0.9, size: 0.035, seed: 11),
            make("Fireworks", Int32(bitPattern: 0xFFFFF2B3), Int32(bitPattern: 0xFFFF8F1F),
                 count: 320, spread: 2.2, speed: 1.5, gravity: 0.45,
                 life: 2.6, dirX: 0, dirY: 0, size: 0.045, seed: 5),
            make("Dust", Int32(bitPattern: 0xFFF7F3E2), Int32(bitPattern: 0xFFEFE8CF),
                 count: 90, spread: 2.9, speed: 0.12, gravity: -0.03,
                 life: 8, dirX: 0, dirY: 0.05, size: 0.06, seed: 33),
            make("Bokeh", Int32(bitPattern: 0xFFEBD9A8), Int32(bitPattern: 0xFFFCF4DC),
                 count: 40, spread: 2.4, speed: 0.08, gravity: -0.02,
                 life: 9, dirX: 0, dirY: 0.03, size: 0.14, seed: 17),
        ]
    }

    /// Writes a preset onto a layer: numeric keys become track bases,
    /// color/color2 become the layer's gradient ends.
    static func apply(_ l: Layer, _ json: JObj) {
        for k in json.keys {
            switch k {
            case "color", "color2":
                // exact whole numbers by construction; guard anyway so a
                // hand-edited preset can never trap
                if let u = UInt32(exactly: json.optDouble(k).rounded()) {
                    if k == "color" { l.color = Int32(bitPattern: u) }
                    else { l.color2 = Int32(bitPattern: u) }
                }
            default: l.track(k).base = json.optFloat(k)
            }
        }
    }

    /// Builds one (name, config) entry. Colors are ARGB Int32 stored as
    /// doubles (exact up to 2^53, well past the 32 bits we need).
    private static func make(_ name: String, _ c1: Int32, _ c2: Int32,
                             count: Int, spread: Float, speed: Float, gravity: Float,
                             life: Float, dirX: Float, dirY: Float, size: Float,
                             seed: Int) -> (String, JObj) {
        let o = JObj()
        o.put("pCount", Double(count))
        o.put("pSpread", Double(spread))
        o.put("pSpeed", Double(speed))
        o.put("pGravity", Double(gravity))
        o.put("pLife", Double(life))
        o.put("pSeed", Double(seed))
        o.put("pDirX", Double(dirX))
        o.put("pDirY", Double(dirY))
        o.put("pSize", Double(size))
        o.put("pShowSrc", 0)
        o.put("color", Double(UInt32(bitPattern: c1)))
        o.put("color2", Double(UInt32(bitPattern: c2)))
        return (name, o)
    }
}
