// GraphEditor.swift — curve editors: GraphView (bezier), ValueGraphView, CurveThumb.

import UIKit
import Foundation

// MARK: - GraphView

/// Cubic bezier easing editor: drag the two handles.
final class GraphView: UIControl {
    var key: Key? = nil
    var onBegin: (() -> Void)? = nil
    var onChange: (() -> Void)? = nil
    private var drag = 0
    private let pad: CGFloat = 24

    override init(frame: CGRect) {
        super.init(frame: frame)
    }

    private func px(_ x: Float) -> CGFloat { pad + CGFloat(x) * (bounds.width - 2 * pad) }
    private func py(_ y: Float) -> CGFloat { bounds.height - pad - CGFloat(y + 0.5) / 2 * (bounds.height - 2 * pad) }
    private func ux(_ x: CGFloat) -> Float { clamp(Float((x - pad) / (bounds.width - 2 * pad)), 0, 1) }
    private func uy(_ y: CGFloat) -> Float { clamp(Float((bounds.height - pad - y) / (bounds.height - 2 * pad)) * 2 - 0.5, -0.5, 1.5) }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        for i in 0...4 {
            let gx = px(Float(i) / 4)
            strokeLine(c, gx, py(-0.5), gx, py(1.5), 1, Int32(bitPattern: 0xFF2A2A30))
        }
        for i in 0...4 {
            let gy = py(-0.5 + Float(i) * 0.5)
            strokeLine(c, px(0), gy, px(1), gy, 1, Int32(bitPattern: 0xFF2A2A30))
        }
        guard let k = key else {
            drawText("Select a property with 2+ keyframes", bounds.width / 2, bounds.height / 2,
                     color: C.DIM, size: 12, align: .center)
            return
        }
        // reference style: white curve, green handles, green endpoints
        c.setStrokeColor(argbToUIColor(C.TEXT).cgColor)
        c.setLineWidth(3)
        c.setLineCap(.round)
        c.setLineJoin(.round)
        c.beginPath()
        for i in 0...60 {
            let u = Float(i) / 60
            let x = px(u), y = py(Track.easeAt(k, u))
            if i == 0 { c.move(to: CGPoint(x: x, y: y)) } else { c.addLine(to: CGPoint(x: x, y: y)) }
        }
        c.strokePath()
        if k.isBezier() && !k.rev {
            strokeLine(c, px(0), py(0), px(k.x1), py(k.y1), 1.5, C.GREEN)
            strokeLine(c, px(1), py(1), px(k.x2), py(k.y2), 1.5, C.GREEN)
            // white ring + green core — clearly grabbable
            for (hx, hy) in [(k.x1, k.y1), (k.x2, k.y2)] {
                fillCircle(c, px(hx), py(hy), 8, C.GREEN)
                strokeCircle(c, px(hx), py(hy), 8, 2, C.TEXT)
            }
        }
        // endpoint dots: small green rings at (0,0) and (1,1)
        strokeCircle(c, px(0), py(0), 4.5, 2, C.GREEN)
        strokeCircle(c, px(1), py(1), 4.5, 2, C.GREEN)
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let k = key, k.isBezier(), !k.rev, let t = touches.first else { return }
        let pt = t.location(in: self)
        let d1 = hypot(pt.x - px(k.x1), pt.y - py(k.y1))
        let d2 = hypot(pt.x - px(k.x2), pt.y - py(k.y2))
        drag = min(d1, d2) > 40 ? 0 : (d1 <= d2 ? 1 : 2)
        if drag != 0 {
            onBegin?()
            disallowParentScrollInterception(self, true)
        }
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let k = key, drag != 0, let t = touches.first else { return }
        let pt = t.location(in: self)
        if k.ease != Ease.CUSTOM { k.ease = Ease.CUSTOM }
        if drag == 1 { k.x1 = ux(pt.x); k.y1 = uy(pt.y) } else { k.x2 = ux(pt.x); k.y2 = uy(pt.y) }
        onChange?()
        setNeedsDisplay()
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        drag = 0
        disallowParentScrollInterception(self, false)
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        drag = 0
        disallowParentScrollInterception(self, false)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - ValueGraphView

/// Read-only plot of a parameter over time with its keyframes; tap a keyframe to select it.
final class ValueGraphView: UIControl {
    var track: Track? = nil
    var t0: Float = 0
    var t1: Float = 1
    var selIdx = 0
    var speedMode = false
    var onPick: ((Int) -> Void)? = nil
    private let pad: CGFloat = 14

    private func fv(_ tr: Track, _ t: Float) -> Float {
        speedMode ? (tr.eval(t + 0.01) - tr.eval(t - 0.01)) / 0.02 : tr.eval(t)
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
    }

    private func xOf(_ t: Float) -> CGFloat {
        pad + CGFloat((t - t0) / (t1 - t0)) * (bounds.width - 2 * pad)
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        fillRoundRect(c, CGRect(x: 0, y: 0, width: bounds.width, height: bounds.height), 10, C.CARD)
        guard let tr = track else { return }
        var lo = Float.greatestFiniteMagnitude
        var hi = -Float.greatestFiniteMagnitude
        var vs = [Float](repeating: 0, count: 81)
        for i in 0...80 {
            let v = fv(tr, t0 + (t1 - t0) * Float(i) / 80)
            vs[i] = v
            lo = min(lo, v)
            hi = max(hi, v)
        }
        if hi - lo < 1e-4 { hi = lo + 1 }
        func yOf(_ v: Float) -> CGFloat {
            bounds.height - pad - CGFloat((v - lo) / (hi - lo)) * (bounds.height - 2 * pad)
        }
        c.setStrokeColor(argbToUIColor(C.TEXT).cgColor)
        c.setLineWidth(2.5)
        c.setLineCap(.round)
        c.setLineJoin(.round)
        c.beginPath()
        for i in 0...80 {
            let x = xOf(t0 + (t1 - t0) * Float(i) / 80)
            let y = yOf(vs[i])
            if i == 0 { c.move(to: CGPoint(x: x, y: y)) } else { c.addLine(to: CGPoint(x: x, y: y)) }
        }
        c.strokePath()
        // playhead
        let pxv = xOf(Editor.time)
        if pxv >= 0 && pxv <= bounds.width {
            strokeLine(c, pxv, pad, pxv, bounds.height - pad, 1, C.GREEN)
        }
        for (i, k) in tr.keys.enumerated() {
            let on = i == selIdx
            let col: Int32 = on ? C.GREEN : C.TEXT
            if on {
                strokeCircle(c, xOf(k.t), yOf(fv(tr, k.t)), 8, 2, C.GREEN)
            }
            fillCircle(c, xOf(k.t), yOf(fv(tr, k.t)), on ? 5.5 : 4.5, col)
        }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let tr = track, let t = touches.first else { return }
        let x = t.location(in: self).x
        var best = -1
        var bd: CGFloat = 32
        for (i, k) in tr.keys.enumerated() {
            let dd = abs(xOf(k.t) - x)
            if dd < bd { bd = dd; best = i }
        }
        if best >= 0 { onPick?(best) }
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - CurveThumb

/// Small card showing the shape of an easing curve; used as a preset thumbnail.
final class CurveThumb: TapView {
    let key: Key
    let name: String
    var sel = false

    init(_ key: Key, _ name: String) {
        self.key = key
        self.name = name
        super.init(frame: .zero)
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        fillRoundRect(c, CGRect(x: 1, y: 1, width: bounds.width - 2, height: bounds.height - 2), 12, C.CARD)
        if sel {
            c.setStrokeColor(argbToUIColor(C.GREEN).cgColor)
            c.setLineWidth(2)
            let pth = UIBezierPath(roundedRect: CGRect(x: 1, y: 1, width: bounds.width - 2, height: bounds.height - 2), cornerRadius: 12)
            c.addPath(pth.cgPath)
            c.strokePath()
        }
        let px: CGFloat = 14
        let top: CGFloat = 12
        let bot = bounds.height - 24
        c.setStrokeColor(argbToUIColor(sel ? C.GREEN : C.TEXT).cgColor)
        c.setLineWidth(2.5)
        c.setLineCap(.round)
        c.beginPath()
        for i in 0...40 {
            let u = Float(i) / 40
            let y = clamp(Track.easeAt(key, u), -0.4, 1.4)
            let xx = px + CGFloat(u) * (bounds.width - 2 * px)
            let yy = bot - CGFloat((y + 0.4) / 1.8) * (bot - top)
            if i == 0 { c.move(to: CGPoint(x: xx, y: yy)) } else { c.addLine(to: CGPoint(x: xx, y: yy)) }
        }
        c.strokePath()
        drawText(name, bounds.width / 2, bounds.height - 8, color: sel ? C.GREEN : C.DIM, size: 10, align: .center)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}
