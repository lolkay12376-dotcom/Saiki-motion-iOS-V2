// TimelineView.swift — the real timeline (UI).
//
// Ruler + playhead + one row per layer (top of the list draws on top), with
// nested children under groups, keyframe diamonds under animated parameters
// and touch editing: tap to select, scrub the ruler / drag the playhead,
// drag a bar to slide it, drag its edges to trim, tap the eye to toggle
// visibility, tap a diamond to jump into the graph editor, drag in the
// gutter to reorder, pinch anywhere to zoom.
//
// Reference style: numbered second labels with dense sub-ticks, a slim
// accent playhead with a rounded timecode pill on top, rounded clip bars
// (groups get a light outline + folder icon), and an empty-scene hint so a
// fresh project doesn't stare back as a black void.

import UIKit

// MARK: - host protocols (the editor implements both)

protocol EditHost: AnyObject {
    func selectedLayer() -> Layer?
    func selectedId() -> Int
    func isSelected(_ id: Int) -> Bool
    func onSelect(_ id: Int)
    func beginEdit()
    func onEdited()
    func autoKey() -> Bool
}

protocol TimelineHost: AnyObject {
    func selectedLayer() -> Layer?
    func autoKey() -> Bool
    func beginEdit()
    func onEdited()
    func onSeek(_ t: Float)
    func onSelect(_ id: Int)
    func onToggleVisible(_ l: Layer)
    func onTimingChanged()
    func onReorder(_ l: Layer, _ listIndex: Int)
    func onKeyTap(_ l: Layer, _ key: String, _ idx: Int)
}

// MARK: - clip colors (per layer type, AM-style)

enum TlColors {
    /// Pill fill for a layer type (visible state).
    static func fill(_ t: LayerType) -> Int32 {
        switch t {
        case .VIDEO: return Int32(bitPattern: 0xFF2E6FB8)
        case .IMAGE: return Int32(bitPattern: 0xFF7A55C9)
        case .AUDIO: return Int32(bitPattern: 0xFF1FA396)
        case .TEXT: return Int32(bitPattern: 0xFF3AA84E)
        case .SHAPE: return Int32(bitPattern: 0xFFB8862B)
        case .MODEL: return Int32(bitPattern: 0xFFB84B4B)
        case .CAMERA: return Int32(bitPattern: 0xFF4B7FB8)
        case .PARTICLES: return Int32(bitPattern: 0xFF8B5CC9)
        case .FLARE: return Int32(bitPattern: 0xFFC9A43B)
        case .NULL: return Int32(bitPattern: 0xFF5E6B7E)
        case .GROUP: return Int32(bitPattern: 0xFF44515F)
        case .ADJUST: return Int32(bitPattern: 0xFF6B7E5E)
        }
    }
}

// MARK: - the view

final class TimelineView: UIView {

    private weak var editHost: EditHost?
    private weak var tlHost: TimelineHost?

    private let gutterW: CGFloat = 148
    private let rowH: CGFloat = 38
    private let rulerH: CGFloat = 30
    private var pxPer: CGFloat = 60          // pixels per second
    private var scrollX: CGFloat = 0
    private var expandedGroups: Set<Int> = []
    private var expandedKeys: Set<Int> = []

    private var dragMode = 0                 // 0 none 1 scrub 2 move 3 trim-in 4 trim-out 5 reorder 6 pan
    private var dragLayer: Layer? = nil
    private var dragStart = CGPoint.zero
    private var dragStartT: Float = 0
    private var dragStartEnd: Float = 0
    private var dragReorderIdx = -1

    init(_ edit: EditHost, _ timeline: TimelineHost) {
        super.init(frame: .zero)
        editHost = edit
        tlHost = timeline
        backgroundColor = argbToUIColor(Int32(bitPattern: 0xFF101014))
        contentMode = .redraw
        isMultipleTouchEnabled = true
        let pinch = UIPinchGestureRecognizer(target: self, action: #selector(pinchZoom(_:)))
        pinch.cancelsTouchesInView = true
        addGestureRecognizer(pinch)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    // MARK: - public surface

    func timecode(_ t: Float) -> String {
        let m = Int(t) / 60
        let s = Int(t) % 60
        let f = Int((t - Float(Int(t))) * Float(Editor.project.fps))
        return String(format: "%d:%02d.%02d", m, s, f)
    }

    /// Zooms so the whole scene fits the visible width.
    func fitToScene() {
        let w = bounds.width - gutterW - 16
        if w > 10, Editor.scene.duration > 0.1 {
            pxPer = w / CGFloat(Editor.scene.duration)
            scrollX = 0
            setNeedsDisplay()
        }
    }

    /// Expands every group and every keyframe row (the "Show All Keyframes" menu).
    func expandAll() {
        expandedGroups = Set(Editor.scene.layers.map { $0.id })
        expandedKeys = Set(Editor.scene.layers.map { $0.id })
        setNeedsDisplay()
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        if pxPer < 4 || !bounds.isEmpty {
            ensureSaneZoom()
        }
    }

    private func ensureSaneZoom() {
        let w = bounds.width - gutterW - 16
        if w > 10, Editor.scene.duration > 0.1 {
            let fit = w / CGFloat(Editor.scene.duration)
            if pxPer < 4 || pxPer > 4000 { pxPer = fit }
            pxPer = max(pxPer, min(fit, 12))
        }
        scrollX = clamp(scrollX, 0, maxScroll())
        setNeedsDisplay()
    }

    private func maxScroll() -> CGFloat {
        let contentW = CGFloat(Editor.scene.duration + 2) * pxPer
        return max(0, contentW - (bounds.width - gutterW) + 16)
    }

    // MARK: - layout model

    private struct Row {
        let layer: Layer
        let depth: Int
        let isKeys: Bool
        let keyName: String
    }

    private var rows: [Row] = []

    private func rebuildRows() {
        rows = []
        var stack: [(Layer, Int)] = Editor.scene.layers.reversed().map { ($0, 0) }
        var visited = Set<ObjectIdentifier>()   // cycle guard: hand-edited JSON can loop parents
        while let (l, d) = stack.popLast() {
            let id = ObjectIdentifier(l)
            if visited.contains(id) { continue }
            visited.insert(id)
            rows.append(Row(layer: l, depth: d, isKeys: false, keyName: ""))
            let animated = l.props.filter { $0.value.keys.count >= 1 }.map { $0.key }.sorted()
            if expandedKeys.contains(l.id) {
                for k in animated {
                    rows.append(Row(layer: l, depth: d + 1, isKeys: true, keyName: k))
                }
            }
            if expandedGroups.contains(l.id) || d == 0 {
                let children = Editor.scene.layers.filter { $0.parentId == l.id }
                for c in children.reversed() {
                    stack.append((c, min(d + 1, 6)))
                }
            }
        }
    }

    // MARK: - geometry

    private func xOf(_ t: Float) -> CGFloat {
        gutterW + CGFloat(t) * pxPer - scrollX
    }

    private func tOf(_ x: CGFloat) -> Float {
        Float((x - gutterW + scrollX) / max(pxPer, 0.001))
    }

    private func rowAt(_ y: CGFloat) -> Int? {
        let i = Int((y - rulerH) / rowH)
        guard y >= rulerH, rows.indices.contains(i) else { return nil }
        return i
    }

    // MARK: - drawing

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        rebuildRows()

        let w = bounds.width
        let h = bounds.height

        // gutter background
        fillRect(c, CGRect(x: 0, y: 0, width: gutterW, height: h), Int32(bitPattern: 0xFF0C0C0F))
        strokeLine(c, gutterW, 0, gutterW, h, 1, C.LINE)

        // ruler (reference style: bright numbered labels + dense minor ticks)
        fillRect(c, CGRect(x: gutterW, y: 0, width: w - gutterW, height: rulerH), Int32(bitPattern: 0xFF16161B))
        strokeLine(c, gutterW, rulerH - 0.5, w, rulerH - 0.5, 1, Int32(bitPattern: 0xFF2A2A30))
        let step: Float = niceStep()
        let minor: Float = step / 5
        var t: Float = 0
        var labelXs: [CGFloat] = []
        let pxPlay = xOf(Editor.time)
        while xOf(t) < w + 40 {
            let x = xOf(t)
            if x >= gutterW - 1 {
                strokeLine(c, x, rulerH - 14, x, rulerH, 1, Int32(bitPattern: 0xFF6B6B76))
                // skip labels that the playhead pill would cover
                if abs(x - pxPlay) > 36 {
                    drawText(timecode(t), x + 3, rulerH - 4, color: Int32(bitPattern: 0xFFB9B9C4), size: 10, align: .left)
                    labelXs.append(x)
                }
                // minor ticks
                for k in 1..<5 {
                    let mx = xOf(t + minor * Float(k))
                    if mx > gutterW, mx < w {
                        strokeLine(c, mx, rulerH - 7, mx, rulerH, 1, Int32(bitPattern: 0xFF3A3A42))
                    }
                }
            }
            t += step
        }

        // scene duration end marker
        let dx = xOf(Editor.scene.duration)
        if dx >= gutterW, dx <= w {
            strokeLine(c, dx, rulerH, dx, h, 1, Int32(bitPattern: 0x66FFFFFF))
        }

        // rows
        for (i, row) in rows.enumerated() {
            let y = rulerH + CGFloat(i) * rowH
            if y > h { break }
            drawRow(c, row, i, y)
        }

        // empty-scene hint: a fresh project shouldn't read as a dead void
        if rows.isEmpty {
            let ghost = Int32(bitPattern: 0xFF232329)
            let gy = rulerH + 14
            fillRoundRect(c, CGRect(x: gutterW + 10, y: gy, width: w - gutterW - 20, height: rowH - 12), 5, ghost)
            drawText("Tap Media below to add your first layer", (gutterW + w) / 2, gy + (rowH - 12) / 2 + 3,
                     color: C.DIM, size: 11, align: .center)
        }

        // markers
        for m in Editor.scene.markers {
            let x = xOf(m)
            if x >= gutterW, x <= w {
                strokeLine(c, x, rulerH, x, h, 1, Int32(bitPattern: 0x8038BDF8))
                // tiny bookmark flag in the ruler
                let p = CGMutablePath()
                p.move(to: CGPoint(x: x - 4, y: 2))
                p.addLine(to: CGPoint(x: x + 4, y: 2))
                p.addLine(to: CGPoint(x: x + 4, y: 10))
                p.addLine(to: CGPoint(x: x, y: 7))
                p.addLine(to: CGPoint(x: x - 4, y: 10))
                p.closeSubpath()
                c.addPath(p)
                c.setFillColor(argbToUIColor(Int32(bitPattern: 0xB338BDF8)).cgColor)
                c.fillPath()
            }
        }

        // playhead: slim accent line + rounded timecode pill on the ruler
        if pxPlay >= gutterW - 1 {
            strokeLine(c, pxPlay, 0, pxPlay, h, 2, C.GREEN)
            let pillW: CGFloat = 56
            let pillH: CGFloat = 17
            let pillX = clamp(pxPlay - pillW / 2, gutterW + 2, max(gutterW + 2, w - pillW - 2))
            fillRoundRect(c, CGRect(x: pillX, y: 1, width: pillW, height: pillH), pillH / 2, C.GREEN)
            drawText(timecode(Editor.time), pillX + pillW / 2, 13, color: C.ONDARK, size: 9.5,
                     bold: true, align: .center)
        }

        // reorder hint
        if dragMode == 5, dragReorderIdx >= 0, rows.indices.contains(dragReorderIdx) {
            let y = rulerH + CGFloat(dragReorderIdx) * rowH
            strokeLine(c, gutterW, y, w, y, 2, C.GREEN)
        }
    }

    private func niceStep() -> Float {
        let target: Float = 80 / Float(max(pxPer, 0.001))
        let steps: [Float] = [0.1, 0.25, 0.5, 1, 2, 5, 10, 15, 30, 60, 120]
        for s in steps where s >= target { return s }
        return 300
    }

    private func drawRow(_ c: CGContext, _ row: Row, _ idx: Int, _ y: CGFloat) {
        let l = row.layer
        let sel = editHost?.isSelected(l.id) ?? false

        if row.isKeys {
            // keyframe strip for one parameter
            drawText(Registry.propDef(row.keyName)?.label ?? row.keyName,
                     gutterW - 14 - CGFloat(row.depth) * 12, y + rowH / 2 + 3,
                     color: C.DIM, size: 9, align: .right)
            if let tr = l.props[row.keyName] {
                for (ki, k) in tr.keys.enumerated() {
                    let x = xOf(k.t)
                    if x < gutterW - 4 || x > bounds.width + 4 { continue }
                    let on = abs(k.t - Editor.time) < 0.02
                    drawDiamond(c, x, y + rowH / 2, 4.5,
                                on ? C.GREEN : C.TEXT)
                    _ = ki
                }
            }
            strokeLine(c, gutterW, y + rowH, bounds.width, y + rowH, 0.5, Int32(bitPattern: 0xFF1A1A20))
            return
        }

        // selected-row wash (warm accent tint, reference style)
        if sel {
            fillRect(c, CGRect(x: 0, y: y, width: bounds.width, height: rowH),
                     Int32(bitPattern: 0xFF2A1F12))
        }

        // gutter: eye + expander + name
        let eyeX: CGFloat = 10 + CGFloat(row.depth) * 12
        Icons.draw(c, l.visible ? "eye" : "eye_off", eyeX, y + rowH / 2, 13,
                   l.visible ? Int32(bitPattern: 0xFF9A9AA4) : C.DIM)
        var textX = eyeX + 16
        let children = Editor.scene.layers.filter { $0.parentId == l.id }
        if !children.isEmpty {
            let isOpen = expandedGroups.contains(l.id)
            Icons.draw(c, isOpen ? "chev_down" : "chev_up", eyeX + 18, y + rowH / 2, 11, C.DIM)
            textX = eyeX + 34
        }
        Icons.draw(c, typeIcon(l), textX + 7, y + rowH / 2, 12, sel ? C.GREEN : C.TEXT)
        drawText(l.name, textX + 18, y + rowH / 2 + 4,
                 color: sel ? C.GREEN : C.TEXT, size: 11, bold: sel, align: .left)

        // track area: rounded clip bar colored by type; groups get the
        // reference treatment — darker fill + light 1px outline
        let x0 = xOf(l.start)
        let x1 = xOf(l.end)
        let barY = y + 6
        let barH = rowH - 12
        if x1 >= gutterW && x0 <= bounds.width {
            var bx0 = max(x0, gutterW + 1)
            let bx1 = min(x1, bounds.width - 1)
            if x1 > bounds.width { bx0 = min(bx0, bounds.width - 4) }
            if bx1 > bx0 {
                let base = TlColors.fill(l.type)
                let body = l.visible ? (sel ? brighten(base, 0.22) : base)
                                     : Int32(bitPattern: 0xFF1F1F26)
                fillRoundRect(c, CGRect(x: bx0, y: barY, width: bx1 - bx0, height: barH),
                              min(5, barH / 2), body)
                if l.type == .GROUP {
                    strokeRoundRect(c, CGRect(x: bx0 + 0.5, y: barY + 0.5, width: bx1 - bx0 - 1, height: barH - 1),
                                    min(5, barH / 2), 1, Int32(bitPattern: 0x80FFFFFF))
                }
                if sel {
                    strokeRoundRect(c, CGRect(x: bx0 - 1, y: barY - 1, width: bx1 - bx0 + 2, height: barH + 2),
                                    min(5, barH / 2) + 1, 2, C.GREEN)
                    // trim grips
                    strokeLine(c, bx0 + 5, barY + 6, bx0 + 5, barY + barH - 6, 2, Int32(bitPattern: 0xCCFFFFFF))
                    strokeLine(c, bx1 - 5, barY + 6, bx1 - 5, barY + barH - 6, 2, Int32(bitPattern: 0xCCFFFFFF))
                }
                if l.type == .AUDIO {
                    // little waveform ticks inside the bar
                    let n = Int((bx1 - bx0) / 7)
                    for k in 0..<max(1, n) {
                        let gx = bx0 + 5 + CGFloat(k) * 7
                        if gx > bx1 - 5 { break }
                        let amp: CGFloat = 3 + 4 * CGFloat(abs(sin(Double(k) * 1.7)))
                        strokeLine(c, gx, y + rowH / 2 - amp, gx, y + rowH / 2 + amp, 1.5,
                                   Int32(bitPattern: 0x66FFFFFF))
                    }
                } else if bx1 - bx0 > 60 {
                    drawText(l.name, (bx0 + bx1) / 2, y + rowH / 2 + 4,
                             color: l.visible ? C.TEXT : C.DIM, size: 10, align: .center)
                }
            }
        }
        strokeLine(c, gutterW, y + rowH, bounds.width, y + rowH, 0.5, Int32(bitPattern: 0xFF1A1A20))
    }

    /// Lightens an ARGB color toward white by `f` (0...1).
    private func brighten(_ col: Int32, _ f: CGFloat) -> Int32 {
        let a = Int((UInt32(bitPattern: col) >> 24) & 0xFF)
        let r = Int((UInt32(bitPattern: col) >> 16) & 0xFF)
        let g = Int((UInt32(bitPattern: col) >> 8) & 0xFF)
        let b = Int(UInt32(bitPattern: col) & 0xFF)
        func up(_ v: Int) -> Int { min(255, v + Int(CGFloat(255 - v) * f)) }
        return argbColor(a, up(r), up(g), up(b))
    }

    private func drawDiamond(_ c: CGContext, _ x: CGFloat, _ y: CGFloat, _ r: CGFloat, _ col: Int32) {
        let p = CGMutablePath()
        p.move(to: CGPoint(x: x, y: y - r))
        p.addLine(to: CGPoint(x: x + r, y: y))
        p.addLine(to: CGPoint(x: x, y: y + r))
        p.addLine(to: CGPoint(x: x - r, y: y))
        p.closeSubpath()
        c.addPath(p)
        c.setFillColor(argbToUIColor(col).cgColor)
        c.fillPath()
    }

    private func typeIcon(_ l: Layer) -> String {
        switch l.type {
        case .SHAPE: return "shape"
        case .TEXT: return "text"
        case .IMAGE, .VIDEO: return "media"
        case .CAMERA: return "camera"
        case .NULL: return "nullobj"
        case .MODEL: return "cube"
        case .PARTICLES: return "particles"
        case .GROUP: return "folder"
        case .ADJUST: return "adjust"
        case .AUDIO: return "audio"
        case .FLARE: return "flare"
        }
    }

    // MARK: - zoom

    @objc private func pinchZoom(_ g: UIPinchGestureRecognizer) {
        if g.state == .began {
            dragMode = 0
            dragLayer = nil
        }
        guard g.state == .changed else { return }
        let anchor = tOf(g.location(in: self).x)
        pxPer = clamp(pxPer * CGFloat(g.scale), 4, 4000)
        g.scale = 1
        // keep the time under the fingers fixed
        scrollX = clamp(gutterW + CGFloat(anchor) * pxPer - g.location(in: self).x, 0, maxScroll())
        setNeedsDisplay()
    }

    // MARK: - touches

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        let p = t.location(in: self)

        // ruler / playhead → scrub
        if p.y < rulerH && p.x >= gutterW - 8 {
            dragMode = 1
            dragStart = p
            seek(to: tOf(p.x))
            return
        }

        guard let idx = rowAt(p.y) else {
            dragMode = 6
            dragStart = p
            return
        }
        let row = rows[idx]
        let l = row.layer

        // gutter interactions
        if p.x < gutterW {
            let eyeX = 10 + CGFloat(row.depth) * 12
            if p.x < eyeX + 24 {
                tlHost?.onToggleVisible(l)
                setNeedsDisplay()
                return
            }
            let children = Editor.scene.layers.filter { $0.parentId == l.id }
            if !children.isEmpty && p.x < eyeX + 40 {
                if expandedGroups.contains(l.id) {
                    expandedGroups.remove(l.id)
                } else {
                    expandedGroups.insert(l.id)
                }
                setNeedsDisplay()
                return
            }
            if row.isKeys {
                // gutter tap on a key row selects the layer
                tlHost?.onSelect(l.id)
                setNeedsDisplay()
                return
            }
            // drag to reorder
            tlHost?.beginEdit()
            dragMode = 5
            dragLayer = l
            dragReorderIdx = idx
            dragStart = p
            return
        }

        if row.isKeys {
            // tap a keyframe diamond
            if let tr = l.props[row.keyName] {
                for (ki, k) in tr.keys.enumerated() {
                    if abs(xOf(k.t) - p.x) < 12 {
                        tlHost?.onKeyTap(l, row.keyName, ki)
                        setNeedsDisplay()
                        return
                    }
                }
            }
            tlHost?.onSelect(l.id)
            setNeedsDisplay()
            return
        }

        // track area
        let x0 = xOf(l.start)
        let x1 = xOf(l.end)
        tlHost?.onSelect(l.id)
        if abs(p.x - x0) < 14 && l.type != .GROUP {
            tlHost?.beginEdit()
            dragMode = 3
            dragLayer = l
            dragStartT = l.start
            dragStartEnd = l.end
        } else if abs(p.x - x1) < 14 && l.type != .GROUP {
            tlHost?.beginEdit()
            dragMode = 4
            dragLayer = l
            dragStartT = l.start
            dragStartEnd = l.end
        } else if p.x > x0 - 6 && p.x < x1 + 6 {
            tlHost?.beginEdit()
            dragMode = 2
            dragLayer = l
            dragStartT = l.start
            dragStartEnd = l.end
            dragStart = p
        } else {
            dragMode = 6
            dragStart = p
        }
        setNeedsDisplay()
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        let p = t.location(in: self)
        let dx = p.x - dragStart.x

        switch dragMode {
        case 1: // scrub
            seek(to: tOf(p.x))
        case 2: // slide the layer
            guard let l = dragLayer else { return }
            let dt = Float(dx / max(pxPer, 0.001))
            let len = dragStartEnd - dragStartT
            l.start = max(0, dragStartT + dt)
            l.end = l.start + len
            tlHost?.onTimingChanged()
            setNeedsDisplay()
        case 3: // trim in
            guard let l = dragLayer else { return }
            let dt = Float(dx / max(pxPer, 0.001))
            l.start = clamp(dragStartT + dt, 0, dragStartEnd - 0.1)
            tlHost?.onTimingChanged()
            setNeedsDisplay()
        case 4: // trim out
            guard let l = dragLayer else { return }
            let dt = Float(dx / max(pxPer, 0.001))
            l.end = max(dragStartEnd + dt, l.start + 0.1)
            tlHost?.onTimingChanged()
            setNeedsDisplay()
        case 5: // reorder preview
            if let idx = rowAt(p.y) {
                dragReorderIdx = idx
                setNeedsDisplay()
            }
        case 6: // pan
            scrollX = clamp(scrollX - dx, 0, maxScroll())
            dragStart = p
            setNeedsDisplay()
        default:
            break
        }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if dragMode == 5, let l = dragLayer, let idx = rowAt(max(dragStart.y, 0)) {
            _ = idx
            if let y = touches.first?.location(in: self).y, let target = rowAt(y) {
                let targetLayer = rows[target].layer
                if targetLayer !== l {
                    // compute the list index the editor expects (index among
                    // scene.layers of the row's layer)
                    let listIdx = Editor.scene.layers.firstIndex { $0 === targetLayer } ?? 0
                    tlHost?.onReorder(l, listIdx)
                }
            }
        }
        dragMode = 0
        dragLayer = nil
        setNeedsDisplay()
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        dragMode = 0
        dragLayer = nil
        setNeedsDisplay()
    }

    private func seek(to t: Float) {
        let clamped = clamp(t, 0, Editor.scene.duration)
        tlHost?.onSeek(clamped)
        setNeedsDisplay()
    }
}
