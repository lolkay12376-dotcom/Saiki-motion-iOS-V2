// Particles.swift — the deterministic particle field (Render).
//
// R21 emitter model (feature parity with the reference editors): a real
// emitter — particles are BORN at a staggered rate (particles/sec) inside an
// emitter box (size X/Y), fly along a direction cone (angle ± spread in
// degrees) with velocity, gravity and turbulence, and die after `life`
// seconds. State is still a pure function of (seed, time): every particle's
// birth phase is a hash of its index, so scrubbing and export produce
// identical results with zero state between frames.
//
// Legacy projects: layers that animated the old Direction X/Y tracks keep
// the old vector model so nothing breaks.

import Foundation

struct Particle {
    var x: Float
    var y: Float
    var size: Float
    var life: Float   // 0 fresh → 1 dead
}

enum ParticlesSim {

    /// The full parameter set of the emitter (read from the layer's tracks).
    struct Params {
        var rate: Float = 60        // particles per second
        var maxCount: Int = 400     // hard cap (GPU buffer safety)
        var angleDeg: Float = 90    // direction, degrees (90 = up)
        var spreadDeg: Float = 25   // cone half-angle, degrees
        var emX: Float = 0.3        // emitter box width (world units)
        var emY: Float = 0.3        // emitter box height
        var speed: Float = 0.6      // velocity
        var gravity: Float = 0.3
        var life: Float = 3
        var seed: Float = 0
        var turb: Float = 0         // turbulence amount
        var turbSpd: Float = 1      // turbulence speed
        var legacy: Bool = false    // old projects: use dirX/dirY + disc birth
        var dirX: Float = 0
        var dirY: Float = -0.4
    }

    static func field(_ p: Params, t: Float) -> [Particle] {
        let life = max(0.05, p.life)
        let rate = max(1, p.rate)
        // steady-state population: rate × lifetime, capped
        let n = max(1, min(p.maxCount, Int((rate * life).rounded(.up))))
        let cycle = Float(n) / rate          // births repeat over this span
        let time = max(0, t)

        var out: [Particle] = []
        out.reserveCapacity(n)

        for i in 0..<n {
            let fi = Float(i)
            let h0 = hash(p.seed * 131.0 + fi)
            let h1 = hash(p.seed * 977.0 + fi * 7.0)
            let h2 = hash(p.seed * 3313.0 + fi * 13.0)
            let h3 = hash(p.seed * 6151.0 + fi * 29.0)
            let h4 = hash(p.seed * 7919.0 + fi * 3.0)

            // staggered, looping births: age wraps over `cycle`, so the field
            // is already full at t = 0 and stays population-stable forever
            let birth = (fi + h0 * 0.98) * (cycle / Float(n))
            var age = (time - birth).truncatingRemainder(dividingBy: cycle)
            if age < 0 { age += cycle }
            if age > life { continue }        // dead this instant
            let lf = age / life               // 0 fresh → 1 about to die

            // birth place: emitter box (legacy: the old spread-radius disc,
            // with the exact old math — emX carries the old Spread value)
            let bx: Float, by: Float
            if p.legacy {
                let ang = h1 * 2 * Float.pi
                let rad = sqrt(h2) * p.emX * 0.5
                bx = cos(ang) * rad
                by = sin(ang) * rad
            } else {
                bx = (h1 - 0.5) * p.emX
                by = (h2 - 0.5) * p.emY
            }

            // velocity: direction cone (legacy: base vector + spread jitter)
            let vx: Float, vy: Float
            if p.legacy {
                vx = (p.dirX + (h3 - 0.5) * p.emX * 0.6) * p.speed
                vy = (p.dirY + (h4 - 0.5) * p.emX * 0.6) * p.speed
            } else {
                let a = (p.angleDeg + (h3 - 0.5) * 2 * p.spreadDeg) * Float.pi / 180
                let v = p.speed * (0.75 + h4 * 0.5)   // per-particle speed variance
                vx = cos(a) * v
                vy = sin(a) * v
            }

            var x = bx + vx * age
            var y = by + vy * age + p.gravity * age * age * 0.5

            // turbulence: two incommensurate sines per particle read as a
            // wandering drift that grows with age (never before birth)
            if p.turb > 0.001 {
                let ph1 = h1 * 41.0, ph2 = h2 * 47.0
                let w = min(age, 3.0) * p.turbSpd
                x += p.turb * (sin(w * 2.1 + ph1) + 0.5 * sin(w * 5.3 + ph2)) * 0.22 * w
                y += p.turb * (cos(w * 1.7 + ph2) + 0.5 * sin(w * 4.1 + ph1)) * 0.22 * w
            }

            // size: variance + a gentle birth-to-death swell
            let sizeVar = 0.5 + h2 * 0.9
            out.append(Particle(x: x, y: y, size: sizeVar * (0.8 + 0.4 * lf), life: lf))
        }
        return out
    }

    private static func hash(_ x: Float) -> Float {
        var n = UInt32(truncatingIfNeeded: Int64(x * 8192.0))
        n = n &* 747796405 &+ 2891336453
        n = ((n >> ((n >> 28) + 4)) ^ n) &* 277803737
        n = (n >> 22) ^ n
        return Float(n % 100000) / 100000
    }
}
