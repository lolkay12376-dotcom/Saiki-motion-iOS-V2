// FreezeWatchdog.swift — round 20 redesign.
//
// WHAT ACTUALLY SHIPPED WRONG IN 1.5.25 (the "crashes every time" reports):
// the heartbeat only ticked from render() (an edit) and doFrame() (playback
// only). A perfectly healthy user who edited something and then just LOOKED
// AT THE PREVIEW for 6 seconds produced zero beats while `dirty` was still
// true — and the watchdog aborted a healthy app. Every. Single. Time.
// (The 10 s idle save never ran either, because maybeIdleSave() was only
// called from render(), which never came.)
//
// Round-20 design:
//   * Liveness is probed by a repeating Timer ON THE MAIN RUN LOOP in
//     .common modes. A healthy-but-idle main thread spins its run loop, the
//     timer fires, the heartbeat advances. A genuinely wedged main thread
//     stops firing it — real freezes are still caught.
//   * Backgrounding pauses the main run loop by design: notifications arm a
//     grace window during which stuck counting is suspended and reset.
//   * 3 checks → 5 checks (~10 s) before aborting; a real 10 s hang is still
//     killed, a slow device hiccup no longer is.
//   * `idleTick` runs on the same main-loop timer so the editor's idle save
//     actually happens ~10 s after the last edit with no further edits.

import Foundation
import UIKit
import CCrashLog

enum FreezeWatchdog {

    private static let checkInterval: TimeInterval = 2.0
    private static let stuckChecksNeeded = 5        // ~10 s truly stuck
    private static var thread: Thread? = nil
    private static let lock = NSLock()

    // Written only on the main thread; read by the watchdog thread.
    private static var heartbeat: Int64 = 0
    private static var dirty = false                // unsaved work in flight

    // Guarded operations: main thread may legitimately go quiet.
    private static var guarded = 0
    private static var guardLabel = ""

    /// Runs on the main-run-loop heartbeat (every ~1 s, main thread only).
    /// The editor hooks its idle save here.
    static var idleTick: (() -> Void)? = nil

    private static var heartbeatTimer: Timer? = nil

    /// Start the watchdog. Call once after CrashLog.install().
    static func start() {
        lock.lock()
        if thread != nil { lock.unlock(); return }   // idempotent
        let t = Thread(block: run)
        t.name = "freeze-watchdog"
        t.qualityOfService = .utility
        thread = t
        lock.unlock()
        t.start()

        // True liveness probe: a repeating main-run-loop timer. It fires
        // while the main thread is healthy (even when the app is doing
        // nothing else) and stops firing the moment it is wedged.
        DispatchQueue.main.async {
            let timer = Timer(timeInterval: 1.0, repeats: true) { _ in
                heartbeat &+= 1
                idleTick?()
            }
            RunLoop.main.add(timer, forMode: .common)
            heartbeatTimer = timer
        }

        // Backgrounding suspends the main run loop — that is NOT a freeze.
        let nc = NotificationCenter.default
        nc.addObserver(forName: UIApplication.didEnterBackgroundNotification, object: nil,
                       queue: nil) { _ in suspendWhileBackgrounded() }
        nc.addObserver(forName: UIApplication.willEnterForegroundNotification, object: nil,
                       queue: nil) { _ in resumeFromBackground() }
        nc.addObserver(forName: UIApplication.didBecomeActiveNotification, object: nil,
                       queue: nil) { _ in resumeFromBackground() }
    }

    private static var backgroundedAt: CFAbsoluteTime = 0
    private static var backgrounded = false

    private static func suspendWhileBackgrounded() {
        lock.lock()
        backgrounded = true
        stuckReset = true
        lock.unlock()
    }

    private static func resumeFromBackground() {
        lock.lock()
        backgrounded = false
        backgroundedAt = CFAbsoluteTimeGetCurrent()   // fresh grace window
        stuckReset = true
        lock.unlock()
    }

    /// True while backgrounded (main run loop suspended by design) or within
    /// 4 s of coming back to the foreground.
    private static var inGrace: Bool {
        backgrounded || (backgroundedAt != 0 && CFAbsoluteTimeGetCurrent() - backgroundedAt < 4.0)
    }

    // MARK: main-thread API ------------------------------------------------

    /// Explicit beat (edits / render frames still count, cheap).
    static func beat() { heartbeat &+= 1 }

    /// Unsaved work exists (set by the editor's markDirty()).
    static func setDirty(_ on: Bool) { dirty = on }

    /// Wrap a long main-thread-quiet operation: VDB import, export, share.
    static func runGuarded<T>(_ label: String, _ body: () throws -> T) rethrows -> T {
        lock.lock(); guarded += 1; if guardLabel.isEmpty { guardLabel = label }; lock.unlock()
        defer { lock.lock(); guarded -= 1; if guarded <= 0 { guarded = 0; guardLabel = "" }; lock.unlock() }
        return try body()
    }

    // MARK: watchdog thread -------------------------------------------------

    private static var stuckReset = true

    private static func run() {
        var lastBeat: Int64 = heartbeat
        var stuck = 0
        while true {
            Thread.sleep(forTimeInterval: checkInterval)

            lock.lock()
            let beatNow = heartbeat
            let grace = inGrace
            let reset = stuckReset
            stuckReset = false
            let dirtyNow = dirty
            let guardedNow = guarded
            let label = guardLabel
            lock.unlock()

            if grace || reset {
                stuck = 0
            } else if beatNow != lastBeat {
                stuck = 0
            } else if dirtyNow {
                stuck += 1
                if stuck >= stuckChecksNeeded {
                    let detail = "main thread static for \(stuck * Int(checkInterval))s with unsaved work" +
                                 (guardedNow > 0 ? " (in \(label))" : "")
                    ccrash_set_watchdog(1, detail)
                    CrashLog.note("freeze")
                    ccrash_report_freeze(detail)
                    abort()          // deliberate: never stay wedged (R15/R19)
                }
            } else {
                // Quiet and clean: normal idle on a menu.
                stuck = 0
            }
            lastBeat = beatNow
        }
    }
}
