// OverlayView.swift — selection, handles, guides, eyedropper (UI).
//
// Sits transparently over the preview. Draws the selected layer's world
// quad (same math the renderer uses), corner scale handles, a rotate handle
// and optional thirds guides. Touch: tap selects the top-most hit layer,
// drag moves (auto-key aware), corner handles scale, the rotate handle
// spins, and while `pick` is set a tap reports the preview pixel instead.

import UIKit

final class OverlayView: UIView {

    weak var editHost: EditHost?
    weak var timelineHost: TimelineHost?

    /// True while the Scene dialog's guides toggle is on.
    var guides = false {
        didSet { setNeedsDisplay() }
    }

    /// Eyedropper: preview-pixel coordinates (top-left origin).
    var pick: ((Float, Float) -> Void)? = nil

    private var dragMode = 0          // 0 none, 1 move, 2 scale, 3 rotate
    private var dragLayer: Layer? = nil
    private var dragStart = CGPoint.zero
    private var startDist: Float = 0
    private var startScale: Float = 1
    private var startRot: Float = 0
    private var startCenter = CGPoint.zero

    init(_ edit: EditHost, _ timeline: TimelineHost) {
        super.init(frame: .zero)
        editHost = edit
        timelineHost = timeline
        backgroundColor = .clear
        isOpaque = false
        contentMode = .redraw
        isMultipleTouchEnabled = false
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    // MARK: - geometry

    private var worldAr: Float {
        Float(Editor.project.w) / Float(max(Editor.project.h, 1))
    }

    /// world (x, y) → view point
    private func toScreen(_ x: Float, _ y: Float) -> CGPoint {
        let nx = (x / worldAr + 1) / 2
        let ny = (1 - y) / 2
        return CGPoint(x: CGFloat(nx) * bounds.width, y: CGFloat(ny) * bounds.height)
    }

    /// view point → world (x, y)
    private func toWorld(_ p: CGPoint) -> (Float, Float) {
        let nx = Float(p.x / max(bounds.width, 1))
        let ny = Float(p.y / max(bounds.height, 1))
        return (nx * 2 * worldAr - worldAr, 1 - ny * 2)
    }

    private func screenQuad(_ l: Layer) -> [CGPoint] {
        Xf.quadCorners(l, Editor.time).map { toScreen($0.0, $0.1) }
    }

    // MARK: - drawing

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }

        // The viewport itself must read as "alive" even when the scene is
        // empty (the R20 report: pure black on black = "viewport don't
        // work"). Reference style: a subtle dark grid + a hairline canvas
        // border, like the original editor.
        strokeLine(c, 0.5, 0.5, bounds.width - 0.5, 0.5, 1, Int32(bitPattern: 0xFF2E2E36))
        strokeLine(c, 0.5, bounds.height - 0.5, bounds.width - 0.5, bounds.height - 0.5, 1, Int32(bitPattern: 0xFF2E2E36))
        strokeLine(c, 0.5, 0.5, 0.5, bounds.height - 0.5, 1, Int32(bitPattern: 0xFF2E2E36))
        strokeLine(c, bounds.width - 0.5, 0.5, bounds.width - 0.5, bounds.height - 0.5, 1, Int32(bitPattern: 0xFF2E2E36))
        let noLayers = Editor.scene.layers.allSatisfy { !$0.visible }
        if noLayers && pick == nil {
            let grid = Int32(bitPattern: 0xFF1E1E24)
            let cell: CGFloat = 36
            var x = cell
            while x < bounds.width {
                strokeLine(c, x, 0, x, bounds.height, 1, grid)
                x += cell
            }
            var y = cell
            while y < bounds.height {
                strokeLine(c, 0, y, bounds.width, y, 1, grid)
                y += cell
            }
            // slightly brighter center cross — the "home" of the canvas
            let cross = Int32(bitPattern: 0xFF2A2A33)
            strokeLine(c, bounds.width / 2 - 10, bounds.height / 2, bounds.width / 2 + 10, bounds.height / 2, 1, cross)
            strokeLine(c, bounds.width / 2, bounds.height / 2 - 10, bounds.width / 2, bounds.height / 2 + 10, 1, cross)
        }

        if guides {
            let col = Int32(bitPattern: 0x66FFFFFF)
            for i in 1..<3 {
                let x = bounds.width * CGFloat(i) / 3
                strokeLine(c, x, 0, x, bounds.height, 1, col)
                let y = bounds.height * CGFloat(i) / 3
                strokeLine(c, 0, y, bounds.width, y, 1, col)
            }
            strokeLine(c, bounds.width / 2, 0, bounds.width / 2, bounds.height, 1, col)
            strokeLine(c, 0, bounds.height / 2, bounds.width, bounds.height / 2, 1, col)
        }

        if pick != nil {
            // eyedropper crosshair
            let col = Int32(bitPattern: 0xFFFFFFFF)
            strokeLine(c, bounds.width / 2 - 14, bounds.height / 2, bounds.width / 2 + 14, bounds.height / 2, 1.5, col)
            strokeLine(c, bounds.width / 2, bounds.height / 2 - 14, bounds.width / 2, bounds.height / 2 + 14, 1.5, col)
        }

        guard let l = editHost?.selectedLayer() else { return }
        let q = screenQuad(l)

        // selection box — the classic dotted gizmo: a dashed accent outline
        // (round caps read as dots at a glance) with a faint solid hairline
        // underneath so the box stays visible against any background.
        let sel = C.GREEN
        for i in 0..<4 {
            let a = q[i], b = q[(i + 1) % 4]
            strokeLine(c, a.x, a.y, b.x, b.y, 1, Int32(bitPattern: 0x66000000) | (sel & 0x00FFFFFF))
            c.saveGState()
            c.setLineDash(phase: 0, lengths: [3.5, 4.5])
            c.setLineCap(.round)
            strokeLine(c, a.x, a.y, b.x, b.y, 1.8, sel)
            c.restoreGState()
        }
        // corner handles (skip for camera/null/audio/adjust): white dot with
        // an accent center, exactly like the reference gizmo
        if l.isRenderable() || l.type == .GROUP {
            for p in q {
                fillCircle(c, p.x, p.y, 7, Int32(bitPattern: 0xFFFFFFFF))
                fillCircle(c, p.x, p.y, 3.5, sel)
            }
            // rotate handle above the top edge midpoint
            let mid = CGPoint(x: (q[0].x + q[1].x) / 2, y: (q[0].y + q[1].y) / 2)
            let dx = (q[1].x - q[0].x), dy = (q[1].y - q[0].y)
            let len = max(sqrt(dx * dx + dy * dy), 0.001)
            let nx = -dy / len, ny = dx / len
            let hp = CGPoint(x: mid.x + nx * 26, y: mid.y + ny * 26)
            c.saveGState()
            c.setLineDash(phase: 0, lengths: [3.5, 4.5])
            c.setLineCap(.round)
            strokeLine(c, mid.x, mid.y, hp.x, hp.y, 1.8, sel)
            c.restoreGState()
            fillCircle(c, hp.x, hp.y, 6, sel)
        }
    }

    // MARK: - touches

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        let p = t.location(in: self)

        if pick != nil {
            pick?(Float(p.x), Float(p.y))
            pick = nil
            setNeedsDisplay()
            return
        }

        guard let l = editHost?.selectedLayer() else {
            // tap-select: top-most hit layer (reverse draw order)
            let w = toWorld(p)
            for layer in Editor.scene.layers.reversed() {
                guard layer.visible, layer.isRenderable() || layer.type == .GROUP || layer.type == .CAMERA
                        || layer.type == .NULL || layer.type == .ADJUST else { continue }
                guard Editor.time >= layer.start - 0.001 && Editor.time <= layer.end + 0.001 else { continue }
                if Xf.hit(layer, w.0, w.1, Editor.time) {
                    editHost?.onSelect(layer.id)
                    setNeedsDisplay()
                    return
                }
            }
            editHost?.onSelect(-1)
            setNeedsDisplay()
            return
        }

        let q = screenQuad(l)

        // rotate handle?
        if l.isRenderable() || l.type == .GROUP {
            let mid = CGPoint(x: (q[0].x + q[1].x) / 2, y: (q[0].y + q[1].y) / 2)
            let dx = (q[1].x - q[0].x), dy = (q[1].y - q[0].y)
            let len = max(sqrt(dx * dx + dy * dy), 0.001)
            let hp = CGPoint(x: mid.x - dy / len * 26, y: mid.y + dx / len * 26)
            if distance(p, hp) < 22 {
                beginDrag(3, l, p)
                let w = toWorld(p)
                startRot = l.p("rotZ", l.editTime("rotZ", Editor.time))
                _ = w
                let lt = l.editTime("x", Editor.time)
                startCenter = toScreen(l.p("x", lt), l.p("y", lt))
                return
            }
            // corner handle?
            for c in q where distance(p, c) < 24 {
                beginDrag(2, l, p)
                let wc = toWorld(c)
                let wl = toWorld(toScreen(l.p("x", Editor.time), l.p("y", Editor.time)))
                startDist = max(0.02, hypot(wc.0 - wl.0, wc.1 - wl.1))
                startScale = abs(l.p("scale", Editor.time))
                return
            }
        }

        // inside the quad → move
        let w = toWorld(p)
        if Xf.hit(l, w.0, w.1, Editor.time) {
            beginDrag(1, l, p)
        } else {
            // tap outside: re-select whatever is under the finger
            for layer in Editor.scene.layers.reversed() {
                guard layer.visible, Editor.time >= layer.start - 0.001 && Editor.time <= layer.end + 0.001 else { continue }
                if Xf.hit(layer, w.0, w.1, Editor.time) {
                    editHost?.onSelect(layer.id)
                    setNeedsDisplay()
                    return
                }
            }
            editHost?.onSelect(-1)
        }
        setNeedsDisplay()
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first, let l = dragLayer, dragMode != 0 else { return }
        let p = t.location(in: self)
        let autoKey = editHost?.autoKey() ?? false

        switch dragMode {
        case 1: // move — dx/dy in world units
            let w0 = toWorld(dragStart)
            let w1 = toWorld(p)
            let lt = l.editTime("x", Editor.time)
            let nx = l.p("x", lt) + (w1.0 - w0.0)
            let ny = l.p("y", lt) + (w1.1 - w0.1)
            l.track("x").set(lt, nx, autoKey)
            l.track("y").set(lt, ny, autoKey)
            dragStart = p
            editHost?.onEdited()
        case 2: // scale by distance from center
            let wc = toWorld(p)
            let wl = toWorld(startCenter)
            let d = max(0.02, hypot(wc.0 - wl.0, wc.1 - wl.1))
            let lt = l.editTime("scale", Editor.time)
            l.track("scale").set(lt, startScale * d / startDist, autoKey)
            editHost?.onEdited()
        case 3: // rotate around the layer center
            let wc = toWorld(p)
            let wl = toWorld(startCenter)
            let a0 = atan2(dragStartWorld.y - wl.1, dragStartWorld.x - wl.0)
            let a1 = atan2(wc.1 - wl.1, wc.0 - wl.0)
            let delta = (a1 - a0) * 180 / Float.pi
            let lt = l.editTime("rotZ", Editor.time)
            l.track("rotZ").set(lt, startRot + delta, autoKey)
        default:
            break
        }
        setNeedsDisplay()
    }

    private var dragStartWorld = (x: Float(0), y: Float(0))

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        dragMode = 0
        dragLayer = nil
        setNeedsDisplay()
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        dragMode = 0
        dragLayer = nil
        setNeedsDisplay()
    }

    private func beginDrag(_ mode: Int, _ l: Layer, _ p: CGPoint) {
        editHost?.beginEdit()
        dragMode = mode
        dragLayer = l
        dragStart = p
        dragStartWorld = toWorld(p)
    }

    private func distance(_ a: CGPoint, _ b: CGPoint) -> CGFloat {
        hypot(a.x - b.x, a.y - b.y)
    }
}
