// RenderOverlay.swift — the render flow UI: the settings dialog and the
// full-screen animated progress screen.
//
// The progress screen brings back the classic "rendering" moment, better:
// a spinning dashed ring that fills green with progress, a pulsing glow,
// the big percentage, frames + ETA, and a shimmering progress bar — all
// drawn with one CADisplayLink so it stays smooth while the encoder runs.

import UIKit
import Foundation

// MARK: - RenderUi

/// The render flow the editor launches: a settings dialog, then a full-screen
/// progress controller with cancel, then a done sheet (Photos / Share).
enum RenderUi {

    static func settings(_ vc: UIViewController, _ project: Project,
                         _ done: @escaping (RenderSettings) -> Void) {
        var st = RenderSettings()
        let box = UIStackView()
        box.axis = .vertical
        box.alignment = .fill
        box.spacing = 6
        box.isLayoutMarginsRelativeArrangement = true
        box.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16)

        let title = UILabel()
        title.text = "Resolution  \(project.w) x \(project.h)"
        title.textColor = argbToUIColor(C.TEXT)
        title.font = boldFont(15)
        box.addArrangedSubview(title)

        let res = chipRow(["Half", "Full", "1.5x"], 1) { i in
            st.scale = i == 0 ? 0.5 : (i == 1 ? 1 : 1.5)
        }
        box.addArrangedSubview(res)

        let fpsLabel = UILabel()
        fpsLabel.text = "Frame rate"
        fpsLabel.textColor = argbToUIColor(C.DIM)
        fpsLabel.font = sysFont(13)
        box.addArrangedSubview(fpsLabel)
        let fpsRow = chipRow(["24", "30", "60"], 1) { i in
            st.fps = [24, 30, 60][i]
        }
        box.addArrangedSubview(fpsRow)

        let qualityLabel = UILabel()
        qualityLabel.text = "Quality"
        qualityLabel.textColor = argbToUIColor(C.DIM)
        qualityLabel.font = sysFont(13)
        box.addArrangedSubview(qualityLabel)
        let qRow = chipRow(["Draft (fast)", "Final"], 1) { i in
            st.draft = i == 0
        }
        box.addArrangedSubview(qRow)

        let audio = SwitchRow()
        audio.label = "Include audio"
        audio.on = true
        audio.onToggle = { v in st.withAudio = v }
        box.addArrangedSubview(audio)
        audio.heightAnchor.constraint(equalToConstant: 52).isActive = true

        _ = Dlg(vc).setTitle("Render").setView(box)
            .setPositiveButton("Render") { _, _ in
                done(st)
            }
            .setNegativeButton("Cancel", nil)
            .show()
    }

    static func show(_ vc: UIViewController, _ project: Project, _ st: RenderSettings) {
        let progress = RenderProgressViewController(project: project, settings: st)
        progress.modalPresentationStyle = .fullScreen
        vc.present(progress, animated: true)
    }
}

// MARK: - the animated ring

/// The spinning progress ring: a dashed circle that rotates continuously and
/// fills with a green arc as the render advances, with a soft pulsing glow.
final class RenderRingView: UIView {

    var progress: CGFloat = 0 { didSet { setNeedsDisplay() } }

    private var spin: CGFloat = 0
    private weak var link: CADisplayLink?

    func startAnimating() {
        guard link == nil else { return }
        let l = CADisplayLink(target: self, selector: #selector(tick(_:)))
        l.add(to: .main, forMode: .common)
        link = l
    }

    func stopAnimating() {
        link?.invalidate()
        link = nil
    }

    deinit { link?.invalidate() }

    @objc private func tick(_ l: CADisplayLink) {
        spin += CGFloat(l.targetTimestamp - l.timestamp) * 1.4   // rad/s
        setNeedsDisplay()
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let side = min(bounds.width, bounds.height)
        let r = side / 2 - 10
        let cx = bounds.width / 2
        let cy = bounds.height / 2
        let t = CFAbsoluteTimeGetCurrent()

        // pulsing glow behind the ring
        let pulse = 0.5 + 0.5 * sin(t * 2.2)
        let glowR = r * (0.72 + 0.08 * pulse)
        let glow = argbToUIColor(Int32(bitPattern: 0x26FF8A1F)).cgColor
        if let gr = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(),
                               colors: [glow, UIColor.clear.cgColor] as CFArray, locations: nil) {
            // a CGGradient cannot be a fill color — draw it radially instead:
            // warm orange core fading out to the ring's edge
            c.saveGState()
            c.drawRadialGradient(gr,
                                 startCenter: CGPoint(x: cx, y: cy), startRadius: 0,
                                 endCenter: CGPoint(x: cx, y: cy), endRadius: glowR,
                                 options: [.drawsBeforeStartLocation, .drawsAfterEndLocation])
            c.restoreGState()
        }

        // track
        c.setStrokeColor(argbToUIColor(Int32(bitPattern: 0xFF2A2A30)).cgColor)
        c.setLineWidth(7)
        c.strokeEllipse(in: CGRect(x: cx - r, y: cy - r, width: 2 * r, height: 2 * r))

        // spinning dashed ring
        c.saveGState()
        c.translateBy(x: cx, y: cy)
        c.rotate(by: spin)
        c.setStrokeColor(argbToUIColor(C.GREEN_DARK).cgColor)
        c.setLineWidth(3)
        c.setLineCap(.round)
        c.setLineDash(phase: 0, lengths: [2, 10])
        c.strokeEllipse(in: CGRect(x: -r + 7, y: -r + 7, width: 2 * (r - 7), height: 2 * (r - 7)))
        c.restoreGState()

        // progress arc
        let p = clamp(progress, 0, 1)
        if p > 0.001 {
            c.setStrokeColor(argbToUIColor(C.GREEN).cgColor)
            c.setLineWidth(7)
            c.setLineCap(.round)
            c.saveGState()
            c.translateBy(x: cx, y: cy)
            c.rotate(by: -.pi / 2)
            c.addArc(center: .zero, radius: r, startAngle: 0, endAngle: 2 * .pi * p, clockwise: false)
            c.strokePath()
            c.restoreGState()
        }
        // (the percentage lives in the screen's title line — the sleeping
        // chibi animation occupies the ring's center now)
    }
}

// MARK: - the sleeping chibi (the classic render animation)

/// The bundled sleeping-chibi frames (render_f0…f6) cycled at ~7 fps — the
/// original app's render screen animation, brought back. The ring draws
/// around it like a halo.
final class ChibiFramesView: UIView {

    private let iv = UIImageView()
    private var frames: [UIImage] = []
    private var link: CADisplayLink?
    private var idx = 0
    private var acc: CGFloat = 0
    private let fps: CGFloat = 7

    override init(frame: CGRect) {
        super.init(frame: frame)
        iv.contentMode = .scaleAspectFit
        addSubview(iv)
        isUserInteractionEnabled = false
        for i in 0...6 {
            var img = UIImage(named: "render_f\(i)")
            if img == nil, let u = Bundle.main.url(forResource: "render_f\(i)", withExtension: "png") {
                img = UIImage(contentsOfFile: u.path)
            }
            if let img = img { frames.append(img) }
        }
        iv.image = frames.first
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    override func layoutSubviews() {
        super.layoutSubviews()
        iv.frame = bounds
    }

    func startAnimating() {
        guard link == nil, frames.count > 1 else { return }
        let l = CADisplayLink(target: self, selector: #selector(tick(_:)))
        l.add(to: .main, forMode: .common)
        link = l
    }

    func stopAnimating() {
        link?.invalidate()
        link = nil
    }

    deinit { link?.invalidate() }

    @objc private func tick(_ l: CADisplayLink) {
        acc += CGFloat(l.targetTimestamp - l.timestamp)
        let step: CGFloat = 1 / fps
        while acc >= step {
            acc -= step
            idx = (idx + 1) % frames.count
            iv.image = frames[idx]
        }
    }
}

// MARK: - the shimmering bar

/// Slim progress bar with a moving light band (the classic "encoding" shimmer).
final class RenderBarView: UIView {

    var progress: CGFloat = 0 { didSet { setNeedsDisplay() } }
    private var phase: CGFloat = 0
    private weak var link: CADisplayLink?

    func startAnimating() {
        guard link == nil else { return }
        let l = CADisplayLink(target: self, selector: #selector(tick(_:)))
        l.add(to: .main, forMode: .common)
        link = l
    }

    func stopAnimating() {
        link?.invalidate()
        link = nil
    }

    deinit { link?.invalidate() }

    @objc private func tick(_ l: CADisplayLink) {
        phase += CGFloat(l.targetTimestamp - l.timestamp) * 0.9
        setNeedsDisplay()
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let h = bounds.height
        fillRoundRect(c, bounds, h / 2, C.CARD2)
        let p = clamp(progress, 0, 1)
        if p > 0.001 {
            c.saveGState()
            c.clip(to: CGRect(x: 0, y: 0, width: bounds.width * p, height: h))
            fillRoundRect(c, bounds, h / 2, C.GREEN)
            // moving highlight band
            let bandW: CGFloat = 42
            let x = fmod(phase * 160, CGFloat(bounds.width + bandW)) - bandW
            let g = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(),
                               colors: [UIColor.clear.cgColor, UIColor(white: 1, alpha: 0.55).cgColor,
                                        UIColor.clear.cgColor] as CFArray, locations: nil)
            if let g = g {
                c.setBlendMode(.plusLighter)
                c.saveGState()
                c.clip(to: CGRect(x: x, y: 0, width: bandW, height: h))
                c.drawLinearGradient(g, start: .zero, end: CGPoint(x: bandW, y: 0), options: [])
                c.restoreGState()
            }
            c.restoreGState()
        }
    }
}

// MARK: - the progress screen

final class RenderProgressViewController: UIViewController {
    private let project: Project
    private let settings: RenderSettings
    private var ring = RenderRingView()
    private var chibi = ChibiFramesView()
    private var bar = RenderBarView()
    private var titleL = UILabel()
    private var sub = UILabel()
    private var etaL = UILabel()
    private var cancelB = PillButton("Cancel", "close", C.CARD2, C.TEXT)
    private var cancelled = false
    private var startedAt = Date()
    private var timer: Timer?
    private var result: Exporter.Result?

    init(project: Project, settings: RenderSettings) {
        self.project = project
        self.settings = settings
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    override var prefersStatusBarHidden: Bool { true }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = argbToUIColor(Int32(bitPattern: 0xEE0B0B10))

        titleL.text = "Rendering"
        titleL.textColor = argbToUIColor(C.TEXT)
        titleL.font = boldFont(20)
        titleL.textAlignment = .center
        titleL.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(titleL)

        ring.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(ring)

        // the sleeping chibi inside the ring — the classic render animation
        chibi.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(chibi)
        NSLayoutConstraint.activate([
            chibi.centerXAnchor.constraint(equalTo: ring.centerXAnchor),
            chibi.centerYAnchor.constraint(equalTo: ring.centerYAnchor, constant: 10),
            chibi.widthAnchor.constraint(equalToConstant: 104),
            chibi.heightAnchor.constraint(equalToConstant: 104),
        ])

        sub.text = project.name
        sub.textColor = argbToUIColor(C.DIM)
        sub.font = sysFont(13)
        sub.textAlignment = .center
        sub.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(sub)

        bar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(bar)

        etaL.text = " "
        etaL.textColor = argbToUIColor(C.DIM)
        etaL.font = sysFont(12)
        etaL.textAlignment = .center
        etaL.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(etaL)

        cancelB.onClick = { [weak self] in
            guard let self = self else { return }
            self.cancelled = true
            self.etaL.text = "Cancelling…"
            self.cancelB.isUserInteractionEnabled = false
        }
        cancelB.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(cancelB)

        NSLayoutConstraint.activate([
            titleL.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            titleL.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -190),
            ring.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            ring.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -40),
            ring.widthAnchor.constraint(equalToConstant: 168),
            ring.heightAnchor.constraint(equalToConstant: 168),
            sub.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            sub.topAnchor.constraint(equalTo: ring.bottomAnchor, constant: 22),
            bar.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            bar.topAnchor.constraint(equalTo: sub.bottomAnchor, constant: 18),
            bar.widthAnchor.constraint(equalToConstant: 260),
            bar.heightAnchor.constraint(equalToConstant: 8),
            etaL.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            etaL.topAnchor.constraint(equalTo: bar.bottomAnchor, constant: 10),
            cancelB.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            cancelB.topAnchor.constraint(equalTo: etaL.bottomAnchor, constant: 22),
            cancelB.widthAnchor.constraint(equalToConstant: 132),
            cancelB.heightAnchor.constraint(equalToConstant: 42),
        ])

        ring.startAnimating()
        chibi.startAnimating()
        bar.startAnimating()
        start()
    }

    private func start() {
        let project = self.project
        let st = self.settings
        let scene = Editor.scene
        let total = max(1, Int(scene.duration * Float(st.fps)))
        startedAt = Date()
        Thread.detachNewThread {
            let res = Exporter.export(project: project, scene: scene, settings: st)
            DispatchQueue.main.async { [weak self] in
                self?.finished(res)
            }
        }
        timer = Timer.scheduledTimer(withTimeInterval: 0.2, repeats: true) { [weak self] t in
            guard let self = self else { t.invalidate(); return }
            if self.cancelled { t.invalidate(); return }
            let done = ExporterProgress.shared.frames
            let p = CGFloat(done) / CGFloat(total)
            self.ring.progress = p
            self.bar.progress = p
            self.titleL.text = String(format: "Rendering — %.0f%%", min(p, 1) * 100)
            let elapsed = Date().timeIntervalSince(self.startedAt)
            if done > 6, p > 0.01 {
                let eta = elapsed / Double(done) * Double(max(0, total - done))
                self.etaL.text = "\(done) / \(total) frames  ·  ~\(Int(eta)) s left"
            } else {
                self.etaL.text = "\(done) / \(total) frames"
            }
        }
    }

    private func finished(_ res: Exporter.Result) {
        ring.stopAnimating()
        chibi.stopAnimating()
        bar.stopAnimating()
        timer?.invalidate()
        if cancelled {
            if let u = res.url { try? FileManager.default.removeItem(at: u) }
            dismiss(animated: true)
            return
        }
        if let err = res.error {
            let a = UIAlertController(title: "Render failed", message: err, preferredStyle: .alert)
            a.addAction(UIAlertAction(title: "OK", style: .default) { [weak self] _ in
                self?.dismiss(animated: true)
            })
            present(a, animated: true)
            return
        }
        guard let url = res.url else {
            dismiss(animated: true)
            return
        }
        let a = UIAlertController(title: "Render complete",
                                  message: url.lastPathComponent, preferredStyle: .actionSheet)
        a.addAction(UIAlertAction(title: "Save to Photos", style: .default) { [weak self] _ in
            UISaveVideoAtPathToSavedPhotosAlbum(url.path, nil, nil, nil)
            Snack.show("Saved to Photos")
            self?.dismiss(animated: true)
        })
        a.addAction(UIAlertAction(title: "Share", style: .default) { [weak self] _ in
            let share = UIActivityViewController(activityItems: [url], applicationActivities: nil)
            if let pop = share.popoverPresentationController {
                pop.sourceView = self?.view ?? UIView()
            }
            self?.present(share, animated: true)
        })
        a.addAction(UIAlertAction(title: "Close", style: .cancel) { [weak self] _ in
            self?.dismiss(animated: true)
        })
        if let pop = a.popoverPresentationController {
            pop.sourceView = view
            pop.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 1, height: 1)
        }
        present(a, animated: true)
    }

}

/// Cross-thread frame counter (exporter pumps, UI animates).
enum ExporterProgress {
    static var shared = Shared()
    final class Shared {
        private(set) var frames = 0
        private let lock = NSLock()
        func add() {
            lock.lock()
            frames += 1
            lock.unlock()
        }
    }
}
