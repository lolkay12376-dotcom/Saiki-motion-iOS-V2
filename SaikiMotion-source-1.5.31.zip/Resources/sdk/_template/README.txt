Copy this folder, give it a new name, change "id" in effect.json (letters, digits and _ only, must be unique)
and edit effect.glsl. Folders that start with an underscore are ignored by the loader.
See SDK.md in the project root for the full reference.
