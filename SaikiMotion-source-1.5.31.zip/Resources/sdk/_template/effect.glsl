// vec4 effect(vec2 uv) runs once for every pixel. uv goes 0..1 across the layer.
// Every param in effect.json is a float with the same name. Every color is a vec4.
// src(uv) is the layer's pixel (premultiplied alpha). uTime is seconds, uRes is the size in pixels.
vec4 effect(vec2 uv) {
  vec4 c = src(uv);
  vec3 gray = vec3(luma(c.rgb)) * c.a;
  return vec4(mix(c.rgb, gray, amount), c.a);
}
