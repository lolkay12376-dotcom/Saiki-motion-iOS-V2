// Registry.swift — the effect catalog (Effects).
//
// Owns every EffectDef the app knows: the built-in GLSL engine, the five
// bundled SDK examples (Resources/sdk/examples, read-only in the IDE) and
// the user's own effects under <Documents>/SaikiMotion/sdk — plus presets.
// Shader programs compile lazily per effect id; compile problems land in
// `errors` (id → message) which the editor and the SDK IDE both display.

import Foundation
import OpenGLES

struct Preset {
    let name: String
    let builtin: Bool
    let json: JObj
}

enum Registry {

    static let CATEGORIES = ["Light and glow", "Color", "Stylize", "Distort", "Blur",
                             "Generate", "Glitch and motion", "Keying",
                             "Transform and time", "Custom"]

    /// Display order (defs).
    private(set) static var order: [EffectDef] = []

    /// Fast id lookup.
    private(set) static var byId: [String: EffectDef] = [:]

    /// Shader-compile problems, id → log. "__gl" = GL context trouble.
    private(set) static var errors: [String: String] = [:]

    /// Folder-name-keyed scan problems for the SDK IDE.
    static var sdkErrors: [String: String] = [:]

    private static var initialized = false

    // MARK: - loading

    /// Kotlin Registry.init(context). Idempotent — the catalog loads ONCE.
    /// (It used to rescan the disk on every call, which stalled the main
    /// thread each time a tab was switched or the language changed.)
    static func initialize() {
        guard !initialized else { return }
        reloadSdk()
    }

    static func reloadSdk() {
        synchronized()
        order = []
        byId = [:]
        sdkErrors = [:]
        errors = [:]

        // 1 — the GLSL engine's built-ins
        for d in Builtins.all() {
            byId[d.id] = d
            order.append(d)
        }

        // 2 — the bundled SDK examples (same files the IDE shows read-only)
        for id in Builtins.exampleIds {
            guard let d = Builtins.exampleById(id) else { continue }
            d.builtin = true
            d.bundled = true
            byId[d.id] = d
            order.append(d)
        }

        // 3 — user effects: <sdkRoot>/<folder>/{effect.json, effect.glsl}
        let root = sdkRoot()
        if let folders = try? FileManager.default.contentsOfDirectory(atPath: root.path) {
            for folder in folders.sorted() where !folder.hasPrefix("_") {
                let dir = root.appendingPathComponent(folder, isDirectory: true)
                var isDir: ObjCBool = false
                guard FileManager.default.fileExists(atPath: dir.path, isDirectory: &isDir), isDir.boolValue else { continue }
                let jsonURL = dir.appendingPathComponent("effect.json")
                guard let text = try? String(contentsOf: jsonURL, encoding: .utf8) else { continue }
                guard let o = JObj.parse(text) else {
                    sdkErrors[folder] = "effect.json is not valid JSON."
                    continue
                }
                var def = EffectDef.fromJson(o, source: dir.path)
                guard let d = def else {
                    sdkErrors[folder] = "effect.json has no name."
                    continue
                }
                // the code may live in effect.json ("code") or effect.glsl
                if d.glsl.isEmpty {
                    d.glsl = (try? String(contentsOf: dir.appendingPathComponent("effect.glsl"), encoding: .utf8)) ?? ""
                }
                if d.glsl.isEmpty {
                    sdkErrors[folder] = "effect.glsl is empty or missing."
                    continue
                }
                def = nil
                byId[d.id] = d
                order.append(d)
            }
        }

        initialized = true

        // Warm the shader check off the main thread (compile errors surface
        // into `errors` for the browser + IDE).
        DispatchQueue.global(qos: .utility).async {
            for d in order {
                _ = validateProgram(for: d)
            }
        }
    }

    private static var lock = NSLock()
    private static func synchronized() {
        lock.lock()
        defer { lock.unlock() }
    }

    /// The SDK folder (created on demand — dropping files in is a feature).
    static func sdkRoot() -> URL {
        let url = Paths.root.appendingPathComponent("sdk", isDirectory: true)
        try? FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
        return url
    }

    /// Creates a new effect folder with a working starting point (the zip's
    /// newEffectFolder: id "my_<name>", one Amount param, grayscale template).
    static func newEffectFolder(_ name: String) -> URL {
        let root = sdkRoot()
        let base = safeName(name)
        var id = "my_\(base)"
        var n = 2
        while byId[id] != nil || FileManager.default.fileExists(atPath: root.appendingPathComponent(id).path) {
            id = "my_\(base)_\(n)"
            n += 1
        }
        let dir = root.appendingPathComponent(id, isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let json = JObj()
            .put("id", id)
            .put("name", name.isEmpty ? "My Effect" : name)
            .put("description", "Describe what this effect does.")
            .put("category", "Custom")
        let params = JArr()
        params.put(JObj().put("name", "amount").put("label", "Amount")
            .put("min", 0.0).put("max", 1.0).put("def", 1.0).put("dec", 2))
        json.put("params", params)
        json.put("colors", JArr())
        json.put("inputs", JArr())
        json.put("shader", "effect.glsl")
        json.put("preview", JObj().put("image", "portrait").put("time", 0.7).put("animation", "swipe"))
        try? json.toString(2).write(to: dir.appendingPathComponent("effect.json"), atomically: true, encoding: .utf8)
        try? Registry.templateGlsl
            .write(to: dir.appendingPathComponent("effect.glsl"), atomically: true, encoding: .utf8)
        return dir
    }

    /// The starter effect.glsl handed to new effects (zip TEMPLATE_GLSL).
    static let templateGlsl = """
// vec4 effect(vec2 uv) runs once for every pixel. uv goes 0..1 across the layer.
// Every param in effect.json is a float with the same name. Every color is a vec4.
// src(uv) is the layer's pixel (premultiplied alpha). uTime is seconds, uRes is the size in pixels.
vec4 effect(vec2 uv) {
  vec4 c = src(uv);
  vec3 gray = vec3(luma(c.rgb)) * c.a;
  return vec4(mix(c.rgb, gray, amount), c.a);
}
"""

    /// Slug for effect ids: lowercase, [a-z0-9_] only (zip safeName).
    static func safeName(_ s: String) -> String {
        let slug = s.lowercased().map { c -> Character in
            (c.isLetter && c.isASCII && c.isLowercase) || (c.isNumber && c.isASCII) || c == "_" ? c : "_"
        }
        let t = String(slug).trimmingCharacters(in: CharacterSet(charactersIn: "_"))
        return t.isEmpty ? "effect" : t
    }

    // MARK: - lookup

    /// Entry-id resolution: "blur~2" → the blur def.
    static func get(_ entry: String) -> EffectDef? {
        var id = entry
        if let r = id.range(of: "~") { id = String(id[..<r.lowerBound]) }
        return byId[id]
    }

    /// A fresh entry id for stacking the same effect twice: "blur", "blur~2"…
    static func uniqueEntry(_ l: Layer, _ id: String) -> String {
        if !l.fx.contains(id) { return id }
        var n = 2
        while l.fx.contains("\(id)~\(n)") { n += 1 }
        return "\(id)~\(n)"
    }

    /// Instance-scoped parameter (key carries the entry prefix).
    static func instProp(_ l: Layer, _ entry: String, _ pd: PropDef) -> PropDef {
        let d = get(entry)
        let single = (d?.kind ?? 0) == 1
        return PropDef(single ? pd.key : entry + "__" + pd.key, pd.label,
                       pd.min, pd.max, pd.def, pd.dec, pd.options, pd.inf, pd.span)
    }

    /// Instance-scoped color parameter.
    static func instColor(_ l: Layer, _ entry: String, _ cp: ColorParam) -> ColorParam {
        let d = get(entry)
        let single = (d?.kind ?? 0) == 1
        return ColorParam(single ? cp.key : entry + "__" + cp.key, cp.label, cp.def)
    }

    /// Reverse lookup: a track key → its PropDef (graph editor labels).
    static func propDef(_ key: String) -> PropDef? {
        for d in order {
            for p in d.props where p.key == key { return p }
            if !key.hasPrefix(d.id + "__") { continue }
            let sub = String(key.dropFirst(d.id.count + 2))
            for p in d.props where p.key == sub { return p }
        }
        // plain transform keys
        for p in Defs.transform + Defs.scaleXY + Defs.pos3d + Defs.rot3d + Defs.anchor
            + Defs.text + Defs.audio + Defs.camera + Defs.flare + Defs.blur where p.key == key {
            return p
        }
        return nil
    }

    // MARK: - shaders

    /// Records a shader problem (thread-safe).
    static func noteError(_ id: String, _ msg: String) {
        lock.lock()
        errors[id] = msg.count > 400 ? String(msg.prefix(400)) : msg
        lock.unlock()
    }

    /// Compile-checks an effect's shader on a throwaway GL context so UIs can
    /// show problems. GL programs are context-bound, so real rendering keeps
    /// its own per-context cache (SceneRenderer.effectProgram).
    @discardableResult
    static func validateProgram(for d: EffectDef) -> Bool {
        lock.lock()
        if checked.contains(d.id) { return errors[d.id] == nil }
        checked.insert(d.id)
        lock.unlock()
        let (src, _) = Gl.effectShaderSource(d)
        guard let ctx = GLContext.make() else {
            noteError("__gl", "Could not create a GL context on this device.")
            return false
        }
        let prev = EAGLContext.current()
        EAGLContext.setCurrent(ctx)
        defer {
            EAGLContext.setCurrent(prev)
            // ctx is released by ARC once no FBO keeps it alive
        }
        if GLProgram(vertex: GLProgram.defaultVertex, fragment: src) == nil {
            noteError(d.id, Gl.lastShaderLog)
            return false
        }
        return true
    }

    private static var checked = Set<String>()

    /// Lines of prelude the compiler counts before the user's code.
    static func codeLineOffset(_ d: EffectDef) -> Int {
        Gl.effectShaderSource(d).1
    }

    // MARK: - custom effects

    /// Imports an effect from JSON text (file picker or Create dialog).
    /// Returns an error string, or nil on success.
    @discardableResult
    static func addCustom(_ txt: String) -> String? {
        guard let o = JObj.parse(txt) else { return "Not valid JSON." }
        guard let d = EffectDef.fromJson(o, source: nil) else { return "The effect needs a name." }
        if d.glsl.isEmpty, let code = o.optJSONArray("code") {
            // multi-line code arrays: join
            var s = ""
            for i in 0..<code.count { s += code.optString(i) + "\n" }
            d.glsl = s
        }
        if d.glsl.isEmpty { return "The effect has no GLSL code." }
        let dir = sdkRoot().appendingPathComponent(d.id, isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        try? d.toJson().toString(4).write(to: dir.appendingPathComponent("effect.json"), atomically: true, encoding: .utf8)
        try? d.glsl.write(to: dir.appendingPathComponent("effect.glsl"), atomically: true, encoding: .utf8)
        reloadSdk()
        return nil
    }

    /// Deletes a user effect folder by id (bundled/built-ins are refused).
    static func deleteCustom(_ id: String) {
        guard let d = byId[id], !d.builtin, !d.bundled, let src = d.source else { return }
        try? FileManager.default.removeItem(at: URL(fileURLWithPath: src))
        lock.lock()
        checked.remove(id)
        errors.removeValue(forKey: id)
        lock.unlock()
        reloadSdk()
    }

    /// effect.json representation for export.
    static func toJson(_ d: EffectDef) -> JObj {
        d.toJson()
    }

    // MARK: - presets

    private static var presetList: [Preset] = []
    private static var presetsLoaded = false

    private static func presetsFile() -> URL {
        Paths.root.appendingPathComponent("presets.json")
    }

    private static func loadPresets() {
        presetsLoaded = true
        presetList = []
        guard let o = JObj.readDictionary(presetsFile()), let a = o.optJSONArray("presets") else { return }
        for i in 0..<a.count {
            guard let po = a.optJSONObject(i) else { continue }
            if let fx = po.optJSONObject("fx") {
                presetList.append(Preset(name: po.optString("name", "Preset"),
                                         builtin: po.optBool("builtin"),
                                         json: fx))
            }
        }
    }

    static func presets() -> [Preset] {
        if !presetsLoaded { loadPresets() }
        return presetList
    }

    static func savePreset(_ o: JObj) {
        if !presetsLoaded { loadPresets() }
        let name = o.optString("name", "Preset")
        presetList.removeAll { $0.name == name }
        presetList.append(Preset(name: name, builtin: false, json: o))
        persistPresets()
    }

    static func deletePreset(_ name: String) {
        if !presetsLoaded { loadPresets() }
        presetList.removeAll { $0.name == name && !$0.builtin }
        persistPresets()
    }

    private static func persistPresets() {
        let a = JArr()
        for p in presetList {
            a.put(JObj().put("name", p.name).put("builtin", p.builtin).put("fx", p.json))
        }
        try? JObj().put("presets", a).toString(4).write(to: presetsFile(), atomically: true, encoding: .utf8)
    }

    /// Snapshots a layer's effects (params at time t) as a preset payload.
    static func capturePreset(_ l: Layer, _ name: String, _ t: Float) -> JObj {
        let fxArr = JArr()
        for entry in l.fx {
            guard let d = get(entry) else { continue }
            let eo = JObj().put("id", d.id)
            let tracks = JObj()
            let single = d.kind == 1
            for pd in d.props {
                let k = single ? pd.key : entry + "__" + pd.key
                if let tr = l.props[k] { tracks.put(pd.key, tr.toJson()) }
            }
            for cp in d.colors {
                let base = single ? cp.key : entry + "__" + cp.key
                let co = JObj()
                for sfx in ["_r", "_g", "_b", "_a"] {
                    if let tr = l.props[base + sfx] { co.put(sfx, tr.toJson()) }
                }
                tracks.put(cp.key, co)
            }
            eo.put("tracks", tracks)
            let ins = JObj()
            for (k, v) in l.inputs where k.hasPrefix(entry + ":") {
                ins.put(String(k.dropFirst(entry.count + 1)), Int64(v))
            }
            eo.put("inputs", ins)
            if l.fxOff.contains(entry) { eo.put("off", true) }
            fxArr.put(eo)
        }
        return JObj().put("name", name).put("fx", fxArr)
    }

    /// Applies a preset payload to a layer (replaces its effect stack).
    static func applyPreset(_ l: Layer, _ json: JObj) {
        guard let fxArr = json.optJSONArray("fx") else { return }
        l.fx = []
        l.fxOff = []
        for i in 0..<fxArr.count {
            guard let eo = fxArr.optJSONObject(i) else { continue }
            guard let d = byId[eo.optString("id")] else { continue }
            let entry = d.kind == 1 ? d.id : uniqueEntry(l, d.id)
            l.fx.append(entry)
            if eo.optBool("off") { l.fxOff.insert(entry) }
            let single = d.kind == 1
            if let tracks = eo.optJSONObject("tracks") {
                for pd in d.props {
                    if let to = tracks.optJSONObject(pd.key) {
                        let tr = l.track(single ? pd.key : entry + "__" + pd.key)
                        tr.load(to)
                    }
                }
                for cp in d.colors {
                    if let co = tracks.optJSONObject(cp.key) {
                        let base = single ? cp.key : entry + "__" + cp.key
                        for sfx in ["_r", "_g", "_b", "_a"] {
                            if let to = co.optJSONObject(sfx) {
                                l.track(base + sfx).load(to)
                            }
                        }
                    }
                }
            }
            if let ins = eo.optJSONObject("inputs") {
                for nm in ins.keys { l.inputs[entry + ":" + nm] = ins.optInt(nm) }
            }
        }
    }
}
