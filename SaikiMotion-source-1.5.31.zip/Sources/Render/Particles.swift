// Particles.swift — the particle simulation (Render), a port of Particles.kt.
//
// Stateless particle simulation modelled on CC Particle World style controls.
// Every particle is a closed-form function of its index and age, so scrubbing
// and export are exact. Vertex layout (11 floats): centre xyz, corner xy
// (already scaled), uv, premultiplied rgba.

import Foundation

enum Particles {
    static let MAX = 3000
    static let FLOATS = 11
    private static let CS: [Float] = [-1, -1, 1, -1, 1, 1, -1, -1, 1, 1, -1, 1]
    private static let US: [Float] = [0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0]

    private static func rnd(_ i: Int, _ k: Int, _ seed: Float) -> Float {
        // Kotlin: h = i*374761393 + k*668265263 + (seed*1000).toInt()*2147483 (Int32 wrap)
        let s = seed * 1000
        let si: Int
        if s.isNaN {
            si = 0
        } else if s >= 2147483647 {
            si = 2147483647
        } else if s <= -2147483648 {
            si = Int(Int32.min)
        } else {
            si = Int(s)
        }
        var h = Int32(truncatingIfNeeded: i &* 374761393 &+ k &* 668265263 &+ si &* 2147483)
        let h13 = Int32(bitPattern: UInt32(bitPattern: h) >> 13)      // ushr 13
        h = (h ^ h13) &* 1274126177
        let h16 = Int32(bitPattern: UInt32(bitPattern: h) >> 16)      // ushr 16
        h = h ^ h16
        return Float(h & 0xFFFFFF) / 16777216
    }

    /// Builds the visible particle vertices at local time `lt`.
    /// Returns the particle count; the array holds count*6 vertices.
    static func build(_ l: Layer, _ lt: Float, _ out: inout [Float]) -> Int {
        let t = lt - l.start
        if !t.isFinite || t < 0 { return 0 }
        let rate = l.p("pBirthRate", lt) * 60
        let lon = max(0.05, l.p("pLongevity", lt))
        guard rate.isFinite, rate > 0, rate < 1e9 else { return 0 }
        let iMax = Int(floor(t * rate))
        var iMin = max(0, Int(ceil((t - lon) * rate)))
        if iMax - iMin >= MAX { iMin = iMax - MAX + 1 }
        let px = l.p("pProdX", lt), py = l.p("pProdY", lt), pz = l.p("pProdZ", lt)
        let rx = l.p("pRadX", lt), ry = l.p("pRadY", lt), rz = l.p("pRadZ", lt)
        let anim = Int(l.p("pAnim", lt))
        let vel = l.p("pVelocity", lt)
        let dirA = l.p("pDirection", lt) * Float.pi / 180
        let spread = l.p("pSpread", lt)
        let grav = l.p("pGravity", lt)
        var res = l.p("pResist", lt)
        let extra = l.p("pExtra", lt)
        let bs = l.p("pBirthSize", lt), ds = l.p("pDeathSize", lt), sv = l.p("pSizeVar", lt)
        let maxOp = l.p("pOpacity", lt)
        let fade = Int(l.p("pFade", lt))
        let seed = l.p("pSeed", lt)
        if anim == 3 { res *= 3 }
        let c1 = UInt32(bitPattern: l.color)
        let c2 = UInt32(bitPattern: l.color2)
        var n = 0
        if iMin > iMax { return 0 }
        for i in iMin...iMax {
            let age = t - Float(i) / rate
            if age < 0 || age >= lon { continue }
            let u = age / lon
            let x0 = px + (rnd(i, 1, seed) * 2 - 1) * rx
            let y0 = py + (rnd(i, 2, seed) * 2 - 1) * ry
            let z0 = pz + (rnd(i, 3, seed) * 2 - 1) * rz
            // direction
            let phi = rnd(i, 4, seed) * 2 * Float.pi
            let cz = rnd(i, 5, seed) * 2 - 1
            let sr = sqrt(max(0, 1 - cz * cz))
            var dx = sr * cos(phi), dy = sr * sin(phi), dz = cz
            let ax = cos(dirA), ay = sin(dirA)
            switch anim {
            case 1:
                let k = spread / 90
                dx = ax + dx * k; dy = ay + dy * k; dz *= k
            case 2:
                let ca = 1 - rnd(i, 6, seed) * (1 - cos(spread * Float.pi / 180))
                let sa = sqrt(max(0, 1 - ca * ca))
                // basis: axis (ax,ay,0), side (-ay,ax,0), up (0,0,1)
                dx = ax * ca + (-ay * cos(phi)) * sa
                dy = ay * ca + (ax * cos(phi)) * sa
                dz = sin(phi) * sa
            case 4:
                dx = -sin(phi); dy = cos(phi); dz = 0.3
            default:
                break
            }
            let len = max(sqrt(dx * dx + dy * dy + dz * dz), 1e-5)
            dx /= len; dy /= len; dz /= len
            let speed = vel * (anim == 3 ? 0.4 : 1) * (1 + (rnd(i, 7, seed) - 0.5) * extra)
            let travel = res < 0.001 ? age : (1 - exp(-res * age)) / res
            var x = x0 + dx * speed * travel
            var y = y0 + dy * speed * travel - 0.5 * grav * age * age
            let z = z0 + dz * speed * travel
            if anim == 4 {
                let a = age * 2.5
                let rx2 = x - px
                let ry2 = y - py
                x = px + rx2 * cos(a) - ry2 * sin(a)
                y = py + rx2 * sin(a) + ry2 * cos(a)
            }
            let sz = (bs + (ds - bs) * u) * (1 + (rnd(i, 8, seed) - 0.5) * 2 * sv) * 0.08
            let op = maxOp * (fade == 0 ? (1 - u) : (fade == 1 ? sin(Float.pi * u) : 1))
            let r = lerp((c1 >> 16) & 255, (c2 >> 16) & 255, u) / 255
            let g = lerp((c1 >> 8) & 255, (c2 >> 8) & 255, u) / 255
            let b = lerp(c1 & 255, c2 & 255, u) / 255
            let o = n * 6 * FLOATS
            if o + 6 * FLOATS > out.count { break }
            for v in 0..<6 {
                let q = o + v * FLOATS
                out[q] = x; out[q + 1] = y; out[q + 2] = z
                out[q + 3] = CS[v * 2] * sz; out[q + 4] = CS[v * 2 + 1] * sz
                out[q + 5] = US[v * 2]; out[q + 6] = US[v * 2 + 1]
                out[q + 7] = r * op; out[q + 8] = g * op; out[q + 9] = b * op; out[q + 10] = op
            }
            n += 1
        }
        return n
    }

    private static func lerp(_ a: UInt32, _ b: UInt32, _ u: Float) -> Float {
        Float(a) + (Float(b) - Float(a)) * min(1, max(0, u))
    }
}
