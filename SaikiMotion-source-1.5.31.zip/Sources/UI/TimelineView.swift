// TimelineView.swift — the timeline (UI), a port of the Kotlin TimelineView.
//
// Timeline with a centred playhead: the playhead line never moves; dragging
// the tape scrubs time instead. Top row = front-most layer. The chevron
// expands a layer into its keyframe rows (or a group into its content);
// long-press a layer (or grab the handle on the right edge) then drag up or
// down to reorder it. Pinch anywhere to zoom; drag vertically when the rows
// overflow to scroll them.
//
// Row anatomy (left column 74pt): eye at 27%, chevron at 74%. The layer bar
// is a rounded pill coloured per type with the layer name, duration and fx
// count drawn inside it; image/video bars tile their thumbnail, audio bars
// show a waveform. The selected layer gets a white outline with trim handles
// on both ends; dragging those handles trims, dragging the bar moves it.

import UIKit
import AVFoundation

// MARK: - host protocols (the editor implements both)

protocol EditHost: AnyObject {
    func selectedLayer() -> Layer?
    func selectedId() -> Int
    func isSelected(_ id: Int) -> Bool
    func onSelect(_ id: Int)
    func beginEdit()
    func onEdited()
    func autoKey() -> Bool
}

protocol TimelineHost: AnyObject {
    func selectedLayer() -> Layer?
    func autoKey() -> Bool
    func beginEdit()
    func onEdited()
    func onSeek(_ t: Float)
    func onSelect(_ id: Int)
    func onToggleVisible(_ l: Layer)
    func onTimingChanged()
    func onReorder(_ l: Layer, _ listIndex: Int)
    func onKeyTap(_ l: Layer, _ key: String, _ idx: Int)
}

// MARK: - the view

/// CADisplayLink target that does not retain the timeline (same pattern as
/// the editor's playback link).
private final class TlAnimProxy: NSObject {
    weak var tl: TimelineView?
    @objc func tick(_ link: CADisplayLink) { tl?.animTick() }
}

final class TimelineView: UIView {

    private weak var editHost: EditHost?
    private weak var tlHost: TimelineHost?

    // layout constants (zip values, dp == pt)
    private let rulerH: CGFloat = 36
    private let rowH: CGFloat = 34
    private let paramH: CGFloat = 24
    private let leftCol: CGFloat = 74
    private var pxPer: CGFloat = 80            // pixels per second

    private var scrollY: CGFloat = 0
    private var openIds: Set<Int> = []            // expanded layer ids

    // MARK: rows

    private final class TRow {
        let kind: Int                          // 0 layer, 1 group header, 2 param, 3 empty note
        let layer: Layer
        let depth: Int
        let label: String
        let key: String
        var top: CGFloat = 0
        var h: CGFloat = 0
        init(_ kind: Int, _ layer: Layer, _ depth: Int, _ label: String = "", _ key: String = "") {
            self.kind = kind; self.layer = layer; self.depth = depth
            self.label = label; self.key = key
        }
    }
    private var trows: [TRow] = []
    private var totalH: CGFloat = 0

    // MARK: gesture state (modes mirror the Kotlin `mode` int)

    private var mode = 0        // 0 none, 1 scrub, 2 pending tap, 3 trim start, 4 trim end,
                                // 5 move bar, 6 vscroll, 7 reorder, 8 key drag
    private var downX: CGFloat = 0
    private var downY: CGFloat = 0
    private var lastX: CGFloat = 0
    private var lastY: CGFloat = 0
    private var moved = false
    private var tapLayer: Layer? = nil
    private var tapEye: Layer? = nil
    private var tapChev: Layer? = nil
    private var tapKey: (Layer, String, Int)? = nil
    private var dragLayer: Layer? = nil
    private var dragY: CGFloat = 0
    private var dragKey: Key? = nil
    private var dragTrack: Track? = nil
    private var keyBegun = false
    private var dragGrab: CGFloat = 0
    private var pinchActive = false

    // reorder slide animation
    private var offCur: [Int: CGFloat] = [:]
    private var offTgt: [Int: CGFloat] = [:]
    private var animLink: CADisplayLink? = nil
    private var animProxy: TlAnimProxy? = nil

    private var longPress: Timer? = nil

    init(_ edit: EditHost, _ timeline: TimelineHost) {
        super.init(frame: .zero)
        editHost = edit
        tlHost = timeline
        backgroundColor = argbToUIColor(C.BG)
        contentMode = .redraw
        isMultipleTouchEnabled = true
        let pinch = UIPinchGestureRecognizer(target: self, action: #selector(pinchZoom(_:)))
        pinch.cancelsTouchesInView = false
        addGestureRecognizer(pinch)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    deinit {
        animLink?.invalidate()
        longPress?.invalidate()
    }

    // MARK: - public surface

    func timecode(_ t: Float) -> String {
        let fps = max(1, Editor.project.fps)
        let total = Int((t * Float(fps)).rounded())
        return String(format: "%02d:%02d:%02d", total / fps / 60, (total / fps) % 60, total % fps)
    }

    /// Zooms so the whole scene fits the visible width.
    func fitToScene() {
        let usable = bounds.width - leftCol - 24
        if usable > 0, Editor.scene.duration > 0.001 {
            pxPer = clamp(usable / CGFloat(Editor.scene.duration), 10, 900)
        }
        setNeedsDisplay()
    }

    /// Opens every layer and group, or closes them all if everything is already open.
    func expandAll() {
        let ls = Editor.scene.layers
        if ls.contains(where: { !openIds.contains($0.id) }) {
            ls.forEach { openIds.insert($0.id) }
        } else {
            openIds.removeAll()
        }
        setNeedsDisplay()
    }

    // MARK: - geometry

    private func cx() -> CGFloat { bounds.width / 2 }
    private func tx(_ t: Float) -> CGFloat { cx() + CGFloat(t - Editor.time) * pxPer }
    private func xt(_ x: CGFloat) -> Float { Editor.time + Float((x - cx()) / max(pxPer, 0.001)) }

    // MARK: - thumbnails

    private var thumbs: [Int: UIImage] = [:]
    private var loading: Set<Int> = []
    private let thumbQueue = DispatchQueue(label: "saiki.tlthumbs", attributes: .concurrent)

    private func thumb(_ l: Layer) -> UIImage? {
        if l.type != .IMAGE && l.type != .VIDEO { return nil }
        if let t = thumbs[l.id] { return t }
        guard let p = l.imagePath else { return nil }
        if !loading.contains(l.id) {
            loading.insert(l.id)
            let id = l.id
            let isVideo = l.type == .VIDEO
            thumbQueue.async { [weak self] in
                let img: UIImage? = {
                    if isVideo {
                        let url = URL(fileURLWithPath: p)
                        let asset = AVURLAsset(url: url)
                        let gen = AVAssetImageGenerator(asset: asset)
                        gen.appliesPreferredTrackTransform = true
                        if let cg = try? gen.copyCGImage(at: CMTime(value: 0, timescale: 600), actualTime: nil) {
                            let f = UIImage(cgImage: cg)
                            let h: CGFloat = 80
                            let w = max(1, h * f.size.width / max(f.size.height, 1))
                            let r = UIGraphicsImageRendererFormat()
                            r.scale = 1
                            return UIGraphicsImageRenderer(size: CGSize(width: w, height: h), format: r).image { _ in
                                f.draw(in: CGRect(x: 0, y: 0, width: w, height: h))
                            }
                        }
                        return nil
                    }
                    guard let f = UIImage(contentsOfFile: p) else { return nil }
                    var h = f.size.height
                    var ss: CGFloat = 1
                    while h / ss > 160 { ss *= 2 }
                    let w = max(1, f.size.width / ss)
                    h = f.size.height / ss
                    let r = UIGraphicsImageRendererFormat()
                    r.scale = 1
                    return UIGraphicsImageRenderer(size: CGSize(width: w, height: h), format: r).image { _ in
                        f.draw(in: CGRect(x: 0, y: 0, width: w, height: h))
                    }
                }()
                DispatchQueue.main.async { [weak self] in
                    self?.loading.remove(id)
                    if let img = img { self?.thumbs[id] = img; self?.setNeedsDisplay() }
                }
            }
        }
        return nil
    }

    // MARK: - rows

    private func groupOf(_ l: Layer, _ k: String) -> String {
        if Defs.transform.contains(where: { $0.key == k }) ||
            Defs.pos3d.contains(where: { $0.key == k }) ||
            Defs.rot3d.contains(where: { $0.key == k }) { return "Transform" }
        if k == "camFov" || k == "fov" { return "Camera" }
        for id in l.fx {
            if let e = Registry.get(id), e.props.contains(where: { l.pkey(id, $0) == k }) {
                if let i = id.firstIndex(of: "~") {
                    return e.name + " " + String(id[id.index(after: i)...])
                }
                return e.name
            }
        }
        return "Other"
    }

    private func build() {
        trows = []
        let ls = Editor.scene.layers

        func emit(_ l: Layer, _ depth: Int) {
            trows.append(TRow(0, l, depth))
            if !openIds.contains(l.id) || depth > 4 { return }
            if l.type == .GROUP {
                for c in ls.reversed() where c.parentId == l.id { emit(c, depth + 1) }
            } else {
                var groups: [String: [String]] = [:]
                var order: [String] = []
                for (k, tr) in l.props where !tr.keys.isEmpty {
                    let g = groupOf(l, k)
                    if groups[g] == nil { groups[g] = []; order.append(g) }
                    groups[g]?.append(k)
                }
                if groups.isEmpty { trows.append(TRow(3, l, depth + 1, "No keyframes yet")) }
                for g in order {
                    trows.append(TRow(1, l, depth + 1, g))
                    for k in groups[g] ?? [] {
                        trows.append(TRow(2, l, depth + 2,
                                          Registry.propDef(k)?.label ?? k, k))
                    }
                }
            }
        }

        for l in ls.reversed() {
            let par = ls.first { $0.id == l.parentId }
            if par == nil || par?.type != .GROUP { emit(l, 0) }
        }
        var y: CGFloat = 0
        for row in trows {
            row.top = y
            row.h = row.kind == 0 ? rowH : paramH
            y += row.h
        }
        totalH = y
    }

    /// Start and end shown for a layer; groups span their children.
    private func extent(_ l: Layer) -> (Float, Float) {
        if l.type != .GROUP { return (l.start, l.end) }
        let kids = Editor.scene.layers.filter { $0.parentId == l.id }
        if kids.isEmpty { return (0, Editor.scene.duration) }
        var lo: Float = .infinity
        var hi: Float = -.infinity
        for k in kids {
            let e = extent(k)
            lo = min(lo, e.0)
            hi = max(hi, e.1)
        }
        return (lo, hi)
    }

    private func fitDuration() {
        var mx: Float = 0
        for l in Editor.scene.layers where l.type != .GROUP { mx = max(mx, l.end) }
        if mx > Editor.scene.duration + 0.001 { Editor.scene.duration = min(mx, 600) }
    }

    private func rowFor(_ l: Layer) -> TRow? { trows.first { $0.kind == 0 && $0.layer === l } }

    private func rowAt(_ y: CGFloat) -> TRow? {
        if y < rulerH { return nil }
        for row in trows {
            let t = rulerH + row.top - scrollY
            if y >= t && y < t + row.h { return row }
        }
        return nil
    }

    /// True for the top layer of a group that has its mask turned on.
    private func isMaskLayer(_ l: Layer) -> Bool {
        guard let g = Editor.scene.layers.first(where: { $0.id == l.parentId }) else { return false }
        if g.type != .GROUP || g.mask == 0 { return false }
        return Editor.scene.layers.last(where: { $0.parentId == g.id })?.id == l.id
    }

    private func siblings(_ l: Layer) -> [TRow] {
        trows.filter { $0.kind == 0 && $0.layer.parentId == l.parentId }
    }

    // MARK: - drawing

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        draw0(c)
    }

    private func draw0(_ c: CGContext) {
        let w = bounds.width
        let h = bounds.height
        let scene = Editor.scene
        build()
        fillRect(c, CGRect(x: 0, y: 0, width: w, height: h), C.BG)

        // ruler
        let steps: [Float] = [0.1, 0.2, 0.5, 1, 2, 5, 10, 30, 60]
        var step: Float = 60
        for s in steps where s * Float(pxPer) >= 56 { step = s; break }
        var t = (xt(0) / step).rounded(.down) * step
        let t1 = xt(w)
        while t <= t1 {
            if t >= -0.0001 {
                let x = tx(t)
                strokeLine(c, x, rulerH - 14, x, rulerH, 1, Int32(bitPattern: 0xFF55555E))
                let lbl = step >= 1 ? String(Int(t.rounded())) : String(format: "%.1f", t)
                drawText(lbl, x, rulerH - 18, color: C.DIM, size: 11, align: .center)
            }
            for k in 1..<5 {
                let mt = t + step * Float(k) / 5
                if mt >= 0 && CGFloat(step) * pxPer / 5 > 7 {
                    strokeLine(c, tx(mt), rulerH - 6, tx(mt), rulerH, 1, Int32(bitPattern: 0xFF55555E))
                }
            }
            t += step
        }
        // scene duration bar across the top of the ruler
        strokeLine(c, max(tx(0), 0), 1.5, min(tx(scene.duration), w), 1.5, 3, C.GREEN)
        // markers
        for m in scene.markers {
            let x = tx(m)
            let p = CGMutablePath()
            p.move(to: CGPoint(x: x - 6, y: rulerH - 12))
            p.addLine(to: CGPoint(x: x + 6, y: rulerH - 12))
            p.addLine(to: CGPoint(x: x, y: rulerH))
            p.closeSubpath()
            c.addPath(p)
            c.setFillColor(argbToUIColor(C.BLUE).cgColor)
            c.fillPath()
            strokeLine(c, x, rulerH, x, h, 1, Int32(bitPattern: 0xFF55555E))
            if let mnm = scene.markerName(m) {
                drawText(mnm, x + 8, rulerH - 14, color: C.BLUE, size: 10, bold: true)
            }
        }

        // rows
        advanceOffsets()
        c.saveGState()
        c.clip(to: CGRect(x: 0, y: rulerH, width: w, height: h - rulerH))
        let sel = editHost?.selectedId() ?? -1
        for row in trows {
            if row.layer === dragLayer && row.kind == 0 { continue }
            let off = row.kind == 0 ? (offCur[row.layer.id] ?? 0) : 0
            let top = rulerH + row.top - scrollY + off
            if top > h || top + row.h < rulerH { continue }
            drawRow(c, row, top, sel)
        }
        if let dl = dragLayer {
            if let row = rowFor(dl) {
                let top = clamp(dragY - dragGrab, rulerH, h - rowH)
                fillRect(c, CGRect(x: 0, y: top - 2, width: w, height: rowH + 4),
                         Int32(bitPattern: 0x66000000))
                drawRow(c, row, top, sel)
            }
        }
        c.restoreGState()

        // playhead — centred, never moves
        let px = cx()
        strokeLine(c, px, 0, px, h, 2, C.GREEN)
        let tc = timecode(Editor.time)
        let bw = measureText(tc, 12, bold: true) + 18
        fillRoundRect(c, CGRect(x: px - bw / 2, y: 4, width: bw, height: 20), 10, C.GREEN)
        drawText(tc, px, 19, color: Int32(bitPattern: 0xFF2B1400), size: 12, bold: true, align: .center)
    }

    private func drawRow(_ c: CGContext, _ row: TRow, _ top: CGFloat, _ sel: Int) {
        let w = bounds.width
        let l = row.layer
        let indent = CGFloat(row.depth) * 10
        switch row.kind {
        case 0:
            let ext = extent(l)
            let x0 = tx(ext.0)
            let x1 = tx(ext.1)
            let r = CGRect(x: x0, y: top + 4, width: x1 - x0, height: rowH - 8)
            let fill: Int32
            switch l.type {
            case .SHAPE: fill = Int32(bitPattern: 0xFF2F6BFF)
            case .TEXT: fill = Int32(bitPattern: 0xFFD9822B)
            case .IMAGE: fill = Int32(bitPattern: 0xFF1FA67A)
            case .VIDEO: fill = Int32(bitPattern: 0xFF8B5CF6)
            case .CAMERA: fill = Int32(bitPattern: 0xFF6B7280)
            case .NULL: fill = Int32(bitPattern: 0xFF9CA3AF)
            case .MODEL: fill = Int32(bitPattern: 0xFFEC4899)
            case .PARTICLES: fill = Int32(bitPattern: 0xFFCA8A04)
            case .GROUP: fill = Int32(bitPattern: 0xFF4B4B55)
            case .ADJUST: fill = Int32(bitPattern: 0xFF0EA5E9)
            case .AUDIO: fill = Int32(bitPattern: 0xFF64748B)
            case .FLARE: fill = Int32(bitPattern: 0xFFF59E0B)
            }
            let barCol = l.visible ? fill : argbColor(90, Int((UInt32(bitPattern: fill) >> 16) & 0xFF),
                                                      Int((UInt32(bitPattern: fill) >> 8) & 0xFF),
                                                      Int(UInt32(bitPattern: fill) & 0xFF))
            fillRoundRect(c, r, 7, barCol)
            if let tb = thumb(l), l.visible, let cg = tb.cgImage {
                c.saveGState()
                c.clip(to: r)
                let th = r.height
                let tw = th * tb.size.width / max(tb.size.height, 1)
                var x = max(r.minX, 0)
                let endx = min(r.maxX, w)
                while x < endx {
                    c.draw(cg, in: CGRect(x: x, y: r.minY, width: tw, height: th))
                    x += tw
                }
                c.restoreGState()
                fillRoundRect(c, r, 7, Int32(bitPattern: 0x77000000))
            }
            if l.type == .AUDIO {
                let origin = tx(l.start)
                var x = max(r.minX, leftCol)
                let ex = min(r.maxX, w)
                let mid = r.midY
                while x < ex {
                    let idx = Int((x - origin) / 3)
                    let hsh = (UInt64(truncatingIfNeeded: idx) &* 2654435761) >> 7 & 255
                    let hh = CGFloat((0.2 + 0.8 * Float(hsh) / 255) * Float(r.height) * 0.45)
                    strokeLine(c, x, mid - hh, x, mid + hh, 1.5,
                               Int32(bitPattern: 0xAAFFFFFF))
                    x += 3
                }
            }
            if !l.fx.isEmpty {
                fillRect(c, CGRect(x: r.minX + 6, y: r.maxY - 6, width: r.width - 12, height: 3),
                         Int32(bitPattern: 0x33FFFFFF))
            }
            if l.type != .GROUP {
                var seen = Set<Int>()
                for tr in l.props.values {
                    for k in tr.keys {
                        let kx = tx(k.t)
                        if kx < x0 || kx > x1 || !seen.insert(Int((k.t * 100).rounded())).inserted { continue }
                        diamond(c, kx, r.midY, 4.5, Int32(bitPattern: 0xFFFFFFFF))
                    }
                }
            }
            // name inside the bar
            c.saveGState()
            c.clip(to: CGRect(x: max(r.minX + 8, leftCol), y: r.minY,
                              width: max(0, r.maxX - 8 - max(r.minX + 8, leftCol)), height: r.height))
            var nm: String
            if l.type == .GROUP {
                nm = l.name
                if l.mask != 0 { nm += "  (mask" + (l.mask == 2 || l.mask == 4 ? ", inverted" : "") + ")" }
            } else {
                nm = (isMaskLayer(l) ? "[mask] " : "") + l.name
                nm += "  " + String(format: "%.1fs", l.end - l.start)
                if !l.fx.isEmpty { nm += "  fx" + String(l.fx.count) }
            }
            drawText(nm, max(r.minX, leftCol) + 8 + indent, top + rowH / 2 + 4,
                     color: Int32(bitPattern: 0xFFFFFFFF), size: 11, bold: true)
            c.restoreGState()
            // selection outline + trim handles
            if l.id == sel && l.type != .GROUP {
                strokeRoundRect(c, r, 7, 2, Int32(bitPattern: 0xFFFFFFFF))
                for side in 0...1 {
                    let hx = side == 0 ? r.minX : r.maxX
                    let hr = CGRect(x: hx - 9, y: r.minY - 1, width: 18, height: r.height + 2)
                    fillRoundRect(c, hr, 6, Int32(bitPattern: 0xFFFFFFFF))
                    let cy = r.midY
                    let dir: CGFloat = side == 0 ? -1 : 1
                    let p = CGMutablePath()
                    p.move(to: CGPoint(x: hx + dir * 3, y: cy - 4))
                    p.addLine(to: CGPoint(x: hx + dir * 3, y: cy + 4))
                    p.addLine(to: CGPoint(x: hx - dir * 2, y: cy))
                    p.closeSubpath()
                    c.addPath(p)
                    c.setFillColor(argbToUIColor(Int32(bitPattern: 0xFF222222)).cgColor)
                    c.fillPath()
                }
            } else if editHost?.isSelected(l.id) ?? false {
                strokeRoundRect(c, r, 7, 2, Int32(bitPattern: 0xFFFFFFFF))
            }
            // left column (over the tape)
            fillRect(c, CGRect(x: 0, y: top, width: leftCol, height: rowH), C.BG)
            let cy = top + rowH / 2
            Icons.draw(c, l.visible ? "eye" : "eye_off", leftCol * 0.27, cy, 19,
                       l.visible ? C.TEXT : Int32(bitPattern: 0xFF666670))
            Icons.draw(c, "chev_up", leftCol * 0.74, cy, 19,
                       openIds.contains(l.id) ? C.AMBER : Int32(bitPattern: 0xFF777782))
            // right edge handle (over the tape)
            fillRect(c, CGRect(x: w - 30, y: top, width: 30, height: rowH), C.BG)
            Icons.draw(c, "handle", w - 16, cy, 16, C.DIM)
        case 1:
            fillRect(c, CGRect(x: 0, y: top, width: w, height: row.h), Int32(bitPattern: 0xFF14141A))
            drawText(row.label, leftCol + 8 + indent, top + row.h / 2 + 4,
                     color: C.GREEN, size: 11, bold: true)
        case 2:
            fillRect(c, CGRect(x: 0, y: top, width: w, height: row.h), Int32(bitPattern: 0xFF101015))
            if let tr = l.props[row.key] {
                for k in tr.keys {
                    let on = abs(k.t - Editor.time) < 0.03
                    diamond(c, tx(k.t), top + row.h / 2, 5, on ? C.GREEN : Int32(bitPattern: 0xFFFFFFFF))
                }
            }
            fillRect(c, CGRect(x: leftCol, y: top, width: 150, height: row.h),
                     Int32(bitPattern: 0xCC0E0E10))
            drawText(row.label, leftCol + 8 + indent, top + row.h / 2 + 4, color: C.DIM, size: 11)
        default:
            drawText(row.label, leftCol + 8 + indent, top + row.h / 2 + 4, color: C.DIM, size: 11)
        }
    }

    private func diamond(_ c: CGContext, _ x: CGFloat, _ y: CGFloat, _ s: CGFloat, _ col: Int32) {
        let p = CGMutablePath()
        p.move(to: CGPoint(x: x, y: y - s))
        p.addLine(to: CGPoint(x: x + s, y: y))
        p.addLine(to: CGPoint(x: x, y: y + s))
        p.addLine(to: CGPoint(x: x - s, y: y))
        p.closeSubpath()
        c.addPath(p)
        c.setFillColor(argbToUIColor(col).cgColor)
        c.fillPath()
    }

    // MARK: - keyframe drag

    /// Drags a keyframe along the timeline; snaps to beat markers and frames.
    private func moveKey(_ x: Float) {
        guard let k = dragKey, let tr = dragTrack else { return }
        let fps = Float(max(1, Editor.project.fps))
        var t = xt(CGFloat(x))
        var bestM: Float? = nil
        var bd: Float = .infinity
        for m in Editor.scene.markers {
            let d = abs(m - t)
            if d < bd { bd = d; bestM = m }
        }
        if let m = bestM, bd < 8 / Float(pxPer) { t = m } else { t = (t * fps).rounded() / fps }
        t = clamp(t, 0, Editor.scene.duration)
        if tr.keys.contains(where: { $0 !== k && abs($0.t - t) < 0.5 / fps }) { return }
        k.t = t
        tr.keys.sort { $0.t < $1.t }
        tlHost?.onTimingChanged()
        setNeedsDisplay()
    }

    // MARK: - reorder animation

    /// Smoothly slides the rows that the dragged layer passes over.
    private func advanceOffsets() {
        offTgt.removeAll()
        if let dl = dragLayer {
            let sib = siblings(dl)
            let src = sib.firstIndex { $0.layer === dl } ?? 0
            let tgt = targetIndex(sib)
            for (i, s) in sib.enumerated() where s.layer !== dl {
                if tgt < src && i >= tgt && i < src { offTgt[s.layer.id] = rowH }
                else if tgt > src && i > src && i <= tgt { offTgt[s.layer.id] = -rowH }
                else { offTgt[s.layer.id] = 0 }
            }
        }
        var busy = false
        var ids = Set(offCur.keys)
        ids.formUnion(offTgt.keys)
        for id in ids {
            let cur = offCur[id] ?? 0
            let tg = offTgt[id] ?? 0
            let nv = cur + (tg - cur) * 0.32
            if abs(tg - nv) < 0.5 {
                if tg == 0 { offCur.removeValue(forKey: id) } else { offCur[id] = tg }
            } else {
                offCur[id] = nv
                busy = true
            }
        }
        if busy || dragLayer != nil { ensureAnim() }
    }

    private func targetIndex(_ sib: [TRow]) -> Int {
        guard let dl = dragLayer, !sib.isEmpty else { return 0 }
        let center = dragY - dragGrab + rowH / 2
        var best = sib.firstIndex { $0.layer === dl } ?? 0
        var bd = CGFloat.greatestFiniteMagnitude
        for (i, s) in sib.enumerated() {
            let cc = rulerH + s.top - scrollY + rowH / 2
            let dd = abs(cc - center)
            if dd < bd { bd = dd; best = i }
        }
        return best
    }

    private func ensureAnim() {
        if animLink == nil {
            let proxy = TlAnimProxy()
            proxy.tl = self
            animProxy = proxy
            animLink = CADisplayLink(target: proxy, selector: #selector(TlAnimProxy.tick(_:)))
            animLink?.add(to: .main, forMode: .common)
        }
        animLink?.isPaused = false
    }

    @objc private func animTick() {
        if dragLayer == nil && offCur.isEmpty {
            animLink?.isPaused = true
            setNeedsDisplay()          // one final clean frame
            return
        }
        setNeedsDisplay()
    }

    // MARK: - zoom

    @objc private func pinchZoom(_ g: UIPinchGestureRecognizer) {
        switch g.state {
        case .began:
            pinchActive = true
            longPress?.invalidate()
            if mode != 7 { mode = 0 }
        case .changed:
            guard pinchActive else { return }
            pxPer = clamp(pxPer * g.scale, 10, 900)
            g.scale = 1
            setNeedsDisplay()
        default:
            pinchActive = false
        }
    }

    // MARK: - touches

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first, !pinchActive, (event?.allTouches?.count ?? 1) <= 1 else { return }
        let p = t.location(in: self)
        downX = p.x; downY = p.y; lastX = p.x; lastY = p.y; moved = false
        tapLayer = nil; tapEye = nil; tapChev = nil; tapKey = nil
        disallowParentScrollInterception(self, true)

        let row = rowAt(p.y)
        mode = 1
        if let row = row, row.kind == 0 {
            let l = row.layer
            if p.x > bounds.width - 30 {
                dragLayer = l; mode = 7; openIds.remove(l.id)
                dragGrab = downY - (rulerH + row.top - scrollY)
                dragY = downY
                haptic()
            } else if p.x < leftCol * 0.5 {
                tapEye = l; mode = 0
            } else if p.x < leftCol {
                tapChev = l; mode = 0
            } else {
                let ext = extent(l)
                let x0 = tx(ext.0)
                let x1 = tx(ext.1)
                let hit: CGFloat = 22
                let selId = editHost?.selectedId() ?? -1
                let isSel = l.id == selId && l.type != .GROUP
                if isSel && abs(p.x - x0) < hit {
                    tlHost?.beginEdit(); mode = 3
                } else if isSel && abs(p.x - x1) < hit {
                    tlHost?.beginEdit(); mode = 4
                } else if l.id == selId && p.x >= x0 && p.x <= x1 {
                    tlHost?.beginEdit(); mode = 5
                } else {
                    mode = 2
                }
                tapLayer = l
                longPress?.invalidate()
                longPress = Timer.scheduledTimer(withTimeInterval: 0.42, repeats: false) { [weak self] _ in
                    self?.beginReorder()
                }
            }
        } else if let row = row, row.kind == 2 {
            let tr = row.layer.props[row.key]
            var hitIdx = -1
            if let tr = tr {
                for (i, k) in tr.keys.enumerated() where abs(p.x - tx(k.t)) < 20 { hitIdx = i }
            }
            tapLayer = row.layer
            mode = 2
            if hitIdx >= 0, let tr = tr {
                tapKey = (row.layer, row.key, hitIdx)
                dragKey = tr.keys[hitIdx]
                dragTrack = tr
                mode = 8
            }
        } else if p.y > rulerH {
            tapLayer = row?.layer
            mode = 2
        }
    }

    private func beginReorder() {
        guard let l = tapLayer else { return }
        if mode == 2 || mode == 5 || mode == 3 || mode == 4 {
            dragLayer = l
            mode = 7
            openIds.remove(l.id)
            haptic()
            dragGrab = rowFor(l).map { downY - (rulerH + $0.top - scrollY) } ?? rowH / 2
            dragY = downY
            setNeedsDisplay()
        }
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first, !pinchActive else { return }
        let p = t.location(in: self)
        let dx = p.x - lastX
        let dy = p.y - lastY
        if abs(p.x - downX) > 8 || abs(p.y - downY) > 8 {
            moved = true
            if mode != 7 { longPress?.invalidate() }
        }
        switch mode {
        case 7:
            dragY = p.y
            setNeedsDisplay()
        case 8:
            if moved {
                if !keyBegun { tlHost?.beginEdit(); keyBegun = true }
                moveKey(Float(p.x))
            }
        case 1, 2:
            if mode == 2 && moved && abs(p.y - downY) > abs(p.x - downX) * 1.5 &&
                totalH > bounds.height - rulerH - 1 {
                mode = 6
            } else if moved {
                mode = 1
                tlHost?.onSeek(clamp(Editor.time - Float(dx / pxPer), 0, Editor.scene.duration))
            }
        case 6:
            scrollY = clamp(scrollY - dy, 0, max(0, totalH + 8 - (bounds.height - rulerH)))
            setNeedsDisplay()
        case 3, 4, 5:
            if let l = Editor.scene.layers.first(where: { $0.id == (editHost?.selectedId() ?? -1) }), moved {
                let fps = Float(max(1, Editor.project.fps))
                switch mode {
                case 3:
                    let ns = clamp((xt(p.x) * fps).rounded() / fps, 0, max(0, l.end - 0.1))
                    if l.type == .VIDEO || l.type == .AUDIO { l.srcOffset += ns - l.start }
                    l.start = ns
                case 4:
                    var ne = max((xt(p.x) * fps).rounded() / fps, l.start + 0.1)
                    if (l.type == .VIDEO || l.type == .AUDIO) && l.srcDur > 0 {
                        ne = min(ne, l.start + l.srcDur - l.srcOffset)
                    }
                    l.end = max(ne, l.start + 0.1)
                    fitDuration()
                default:
                    if l.type == .GROUP {
                        let kids = Editor.scene.layers.filter { $0.parentId == l.id }
                        if !kids.isEmpty {
                            let lo = -(kids.map { $0.start }.min() ?? 0)
                            let dt = max(Float(dx / pxPer), lo)
                            for k in kids { k.start += dt; k.end += dt }
                            fitDuration()
                        }
                    } else {
                        let len = l.end - l.start
                        let ns = max(l.start + Float(dx / pxPer), 0)
                        l.start = ns
                        l.end = ns + len
                        fitDuration()
                    }
                }
                tlHost?.onTimingChanged()
                setNeedsDisplay()
            }
        default:
            break
        }
        lastX = p.x; lastY = p.y
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        longPress?.invalidate()
        disallowParentScrollInterception(self, false)
        if mode == 7 {
            if let dl = dragLayer {
                let sib = siblings(dl)
                let ti = targetIndex(sib)
                if let tl = sib[safe: ti]?.layer, tl !== dl {
                    let listIdx = Editor.scene.layers.firstIndex { $0 === tl } ?? 0
                    tlHost?.onReorder(dl, listIdx)
                }
            }
            dragLayer = nil
            offCur.removeAll()
            offTgt.removeAll()
            setNeedsDisplay()
        } else if !moved {
            if let eye = tapEye {
                tlHost?.onToggleVisible(eye)
            } else if let chev = tapChev {
                if !openIds.remove(chev.id) { openIds.insert(chev.id) }
                setNeedsDisplay()
            } else if let key = tapKey {
                tlHost?.onKeyTap(key.0, key.1, key.2)
            } else if let tl = tapLayer {
                tlHost?.onSelect(tl.id)
            } else if mode == 2 {
                tlHost?.onSelect(-1)
            }
        }
        dragKey = nil; dragTrack = nil; keyBegun = false
        mode = 0
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        longPress?.invalidate()
        disallowParentScrollInterception(self, false)
        dragLayer = nil
        offCur.removeAll()
        offTgt.removeAll()
        mode = 0
    }

    private func haptic() {
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
    }
}
