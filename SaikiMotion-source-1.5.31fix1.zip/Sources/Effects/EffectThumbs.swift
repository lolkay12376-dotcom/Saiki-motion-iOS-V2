// EffectThumbs.swift — before/after thumbnails for the effect browser (Effects).
//
// A port of the zip's EffectThumbs.kt: every effect renders ONCE on its
// category's bundled sample photo (mountain / woman / greenscreen / ramen /
// apple / portrait) with the real shader at default parameter values, on a
// background GL context, 192x256 (the card shape). `__orig:<image>` holds
// the untouched sample; `<id>` holds the processed result. The cards pick
// them up asynchronously; raw() gives the cheap uncropped placeholder.

import UIKit
import OpenGLES
import GLKit
import Foundation

enum EffectThumbs {

    static var cache: [String: UIImage] = [:]
    static var lastError = ""

    private static let queue = DispatchQueue(label: "saiki.thumbs", qos: .userInitiated)
    private static var generating = false

    static let W = 192
    static let H = 256

    /// Premium color/light effects preview on the mountain shot.
    private static let premiumColor: Set<String> = ["tritone", "duotone", "hueshift", "lightleak", "vignette"]

    static func origKey(_ id: String) -> String { "__orig:" + imgKey(id) }

    static func ready(_ id: String) -> Bool {
        cache[id] != nil && cache[origKey(id)] != nil
    }

    /// Which sample picture an effect is previewed on, chosen by its
    /// category (mirrors the zip's imgKey):
    ///   fill → apple, blurmo → ramen, premium color → mountain,
    ///   Glitch and motion / Transform and time → ramen, Keying → greenscreen,
    ///   Color / Stylize / Blur → woman, everything else → mountain.
    static func imgKey(_ id: String) -> String {
        if let d = Registry.byId[id], let pi = d.previewImage { return pi }
        if id == "fill" { return "apple" }
        if id == "blurmo" { return "ramen" }
        if premiumColor.contains(id) { return "mountain" }
        guard let d = Registry.byId[id] else { return "mountain" }
        switch fxCategory(d) {
        case "Glitch and motion", "Transform and time": return "ramen"
        case "Keying": return "greenscreen"
        case "Color", "Stylize", "Blur": return "woman"
        default: return "mountain"
        }
    }

    /// The fxCategory mapping used for thumbnails (the editor's browse tab
    /// owns the full one with the iOS-added effects; the sample choice only
    /// needs the base categories).
    private static func fxCategory(_ d: EffectDef) -> String {
        switch d.id {
        case "deepglow", "lightsweep", "contour", "lightleak": return "Light and glow"
        case "tritone", "duotone", "hueshift", "grayscale", "invert", "rgbsplit", "vignette", "fill": return "Color"
        case "etching", "halftone", "zebrafy", "posterize", "filmgrain", "edgelines", "scanlines",
             "pixelate", "sharpen": return "Stylize"
        case "distortrgb", "kaleido", "bulge", "twirl", "barrel", "wavewarp", "ripple": return "Distort"
        case "blur", "radialblur", "blurmo": return "Blur"
        case "psykoblobs", "texturefolded", "texturemoire": return "Generate"
        case "sshake", "twitch", "glitchslices", "oscillate", "autoshake", "randisp", "streaks", "timeslice": return "Glitch and motion"
        case "chromakey": return "Keying"
        default:
            if d.id.hasPrefix("shake_") { return "Glitch and motion" }
            if d.builtin { return "Transform and time" }
            return Registry.CATEGORIES.contains(d.category) ? d.category : "Custom"
        }
    }

    static func isOrig(_ id: String) -> Bool { id.hasPrefix("__orig") }

    // MARK: - sample images

    private static var sampleCache: [String: UIImage] = [:]
    private static let sampleMutex = NSLock()

    /// The known sample-picture keys (custom:<id> handled separately).
    private static let sampleKeys: Set<String> = ["mountain", "woman", "greenscreen",
                                                  "ramen", "apple", "portrait"]

    /// The bundled sample photo for an effect id / image key / "__orig:<key>",
    /// center-cropped to the card shape.
    static func raw(_ id: String) -> UIImage? {
        var key = id
        if key.hasPrefix("__orig:") { key = String(key.dropFirst("__orig:".count)) }
        if !sampleKeys.contains(key) { key = imgKey(key) }
        if key.hasPrefix("custom:") {
            let fid = String(key.dropFirst("custom:".count))
            if let d = Registry.byId[fid], let pp = d.source,
               let img = UIImage(contentsOfFile: pp + "/preview.jpg") {
                return cropped(img)
            }
            return nil
        }
        sampleMutex.lock()
        defer { sampleMutex.unlock() }
        if let img = sampleCache[key] { return img }
        guard let img = sampleImage(key) else { return nil }
        let out = cropped(img)
        sampleCache[key] = out
        return out
    }

    private static func sampleImage(_ key: String) -> UIImage? {
        let file: String
        switch key {
        case "mountain": file = "fx_mountain.jpg"
        case "woman": file = "fx_woman.jpg"
        case "greenscreen": file = "fx_greenscreen.jpg"
        case "ramen": file = "fx_ramen.jpg"
        case "apple": file = "fx_apple.png"
        default: file = "anime_portrait.jpg"
        }
        let ext = (file as NSString).pathExtension
        let base = (file as NSString).deletingPathExtension
        guard let u = Bundle.main.url(forResource: base, withExtension: ext),
              let img = UIImage(contentsOfFile: u.path) else { return nil }
        return img
    }

    /// Center-crop to W:H (3:4) then scale down to the card size.
    private static func cropped(_ b: UIImage) -> UIImage {
        let want = CGFloat(W) / CGFloat(H)
        let a = b.size.width / max(b.size.height, 0.001)
        var cw = b.size.width
        var ch = b.size.height
        if a > want { cw = b.size.height * want } else { ch = b.size.width / want }
        let rect = CGRect(x: (b.size.width - cw) / 2, y: (b.size.height - ch) / 2, width: cw, height: ch)
        guard let cg = b.cgImage?.cropping(to: CGRect(
            x: rect.origin.x * b.scale, y: rect.origin.y * b.scale,
            width: rect.width * b.scale, height: rect.height * b.scale)) else {
            return b
        }
        return UIImage(cgImage: cg)
    }

    // MARK: - generation

    /// Editor spelling: (vc, preview, done).
    static func generate(_ vc: UIViewController, _ preview: PreviewView?,
                         _ done: @escaping () -> Void) {
        generate(done)
    }

    /// SDK IDE spelling: (done).
    static func generate(_ done: @escaping () -> Void) {
        queue.async {
            runGeneration()
            DispatchQueue.main.async(execute: done)
        }
    }

    /// Renders every catalog entry that is not cached yet.
    private static func runGeneration() {
        guard !generating else { return }
        generating = true
        defer { generating = false }

        guard let ctx = GLContext.make() else {
            lastError = "GL unavailable"
            return
        }
        let prev = EAGLContext.current()
        EAGLContext.setCurrent(ctx)
        defer { EAGLContext.setCurrent(prev) }

        let target = Gl.Target(W, H)
        guard let quad = GLProgram(vertex: GLProgram.defaultVertex, fragment: """
precision mediump float;
varying vec2 vUv;
uniform sampler2D uTex;
uniform float uFlipY;
void main() {
    vec2 p = vec2(vUv.x, mix(vUv.y, 1.0 - vUv.y, uFlipY));
    gl_FragColor = texture2D(uTex, p);
}
""") else {
            lastError = "quad shader failed"
            return
        }

        // snapshot the catalog: a concurrent reload must not mutate the
        // array while this background queue iterates it
        let defs = Registry.order
        for def in defs {
            let key = def.id
            if cache[key] != nil && cache[origKey(key)] != nil { continue }

            // the untouched sample ("before")
            let origId = origKey(key)
            guard let sampleImg = raw(key), let srcTex = Gl.upload(sampleImg) else {
                lastError = "sample image missing"
                continue
            }

            // 1 — draw the sample into the target
            target.bind()
            glDisable(GLenum(GL_BLEND))
            glViewport(0, 0, GLsizei(W), GLsizei(H))
            quad.use()
            quad.setFloat("uFlipY", 1)
            quad.setTexture("uTex", srcTex, 0)
            Gl.drawQuad(quad)
            let before = target.readImage()

            // 2 — pass-through defs (transform-level effects) show the sample
            if def.kind == 1 {
                cacheMutex.lock()
                if let b = before {
                    cache[origId] = b
                    cache[key] = b
                }
                cacheMutex.unlock()
                Gl.delete(srcTex)
                continue
            }

            // 3 — apply the effect with default parameter values
            let (src, _) = Gl.effectShaderSource(def)
            guard let prog = GLProgram(vertex: GLProgram.defaultVertex, fragment: src) else {
                Registry.noteError(def.id, Gl.lastShaderLog)
                Gl.delete(srcTex)
                continue
            }
            let t = def.id == "swing" ? 0.45 : def.previewTime
            prog.use()
            prog.setTexture("uTex", target.tex, 0)
            prog.setVec2("uRes", Float(W), Float(H))
            prog.setFloat("uTime", t)
            prog.setFloat("uHas0", 0)
            prog.setFloat("uHas1", 0)
            for pd in def.props {
                prog.setFloat(pd.key, pd.def)
            }
            for cp in def.colors {
                let d = UInt32(bitPattern: cp.def)
                prog.setVec4(cp.key,
                             Float((d >> 16) & 0xFF) / 255,
                             Float((d >> 8) & 0xFF) / 255,
                             Float(d & 0xFF) / 255,
                             Float((d >> 24) & 0xFF) / 255)
            }
            Gl.drawQuad(prog)
            let after = target.readImage()

            cacheMutex.lock()
            if let b = before { cache[origId] = b }
            if let a = after { cache[key] = a }
            cacheMutex.unlock()

            Gl.delete(srcTex)
        }
    }

    private static let cacheMutex = NSLock()

    /// Drops cached thumbs (effect edited / deleted).
    static func invalidate() {
        cacheMutex.lock()
        cache.removeAll()
        cacheMutex.unlock()
        sampleMutex.lock()
        sampleCache.removeAll()
        sampleMutex.unlock()
    }
}
