// OverlayView.swift — selection, handles, guides, eyedropper (UI).
//
// A port of the zip's OverlayView.kt: the selected layer's world quad drawn
// as a DASHED outline (8dp dash / 5dp gap, 1.6dp green), white SQUARE
// handles at the four corners and four edge midpoints, a rotate handle on a
// stem sticking OUT from the top edge midpoint (36dp, direction =
// normalize(topMid − center)), a white filled circle with a green ring at
// the stem tip, and a green ring with a white dot at the centre.
//
// Touch: tap selects the top-most hit layer, drag moves (auto-key aware),
// corner/edge handles scale, the rotate handle spins, pinch scales, and
// while `pick` is set a tap reports the preview pixel instead.

import UIKit

final class OverlayView: UIView {

    weak var editHost: EditHost?
    weak var timelineHost: TimelineHost?

    /// True while the Scene dialog's guides toggle is on.
    var guides = false {
        didSet { setNeedsDisplay() }
    }

    /// Eyedropper: preview-pixel coordinates (top-left origin).
    var pick: ((Float, Float) -> Void)? = nil

    private var mode = 0               // 0 none, 1 move, 2 scale, 3 rotate
    private var lastP = CGPoint.zero
    private var startDist: CGFloat = 1
    private var startScale: Float = 1
    private var startRot: Float = 0
    private var startAng: CGFloat = 0
    private var skip = false

    // projected handle points (zip hx/hy): 0-3 corners, 4-7 edge mids, 8 centre
    private var hx = [CGPoint](repeating: .zero, count: 9)
    private var rotP = CGPoint.zero

    init(_ edit: EditHost, _ timeline: TimelineHost) {
        super.init(frame: .zero)
        editHost = edit
        timelineHost = timeline
        backgroundColor = .clear
        isOpaque = false
        contentMode = .redraw
        isMultipleTouchEnabled = true
        let pinch = UIPinchGestureRecognizer(target: self, action: #selector(pinchScale(_:)))
        addGestureRecognizer(pinch)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    // MARK: - geometry

    private var worldAr: Float {
        Float(Editor.project.w) / Float(max(Editor.project.h, 1))
    }

    /// world (x, y) → view point
    private func toScreen(_ x: Float, _ y: Float) -> CGPoint {
        let nx = (x / worldAr + 1) / 2
        let ny = (1 - y) / 2
        return CGPoint(x: CGFloat(nx) * bounds.width, y: CGFloat(ny) * bounds.height)
    }

    /// view point → world (x, y)
    private func toWorld(_ p: CGPoint) -> (Float, Float) {
        let nx = Float(p.x / max(bounds.width, 1))
        let ny = Float(p.y / max(bounds.height, 1))
        return (nx * 2 * worldAr - worldAr, 1 - ny * 2)
    }

    private func screenQuad(_ l: Layer) -> [CGPoint] {
        Xf.quadCorners(l, Editor.time).map { toScreen($0.0, $0.1) }
    }

    /// Projects the 9 handle points of the selected layer (zip project()).
    private func project() -> Bool {
        guard let l = editHost?.selectedLayer() else { return false }
        if bounds.width == 0 || bounds.height == 0 || l.type == .AUDIO { return false }
        let q = screenQuad(l)
        guard q.count == 4 else { return false }
        // corners 0-3
        for i in 0..<4 { hx[i] = q[i] }
        // edge midpoints 4-7 (top, right, bottom, left)
        hx[4] = CGPoint(x: (q[0].x + q[1].x) / 2, y: (q[0].y + q[1].y) / 2)
        hx[5] = CGPoint(x: (q[1].x + q[2].x) / 2, y: (q[1].y + q[2].y) / 2)
        hx[6] = CGPoint(x: (q[2].x + q[3].x) / 2, y: (q[2].y + q[3].y) / 2)
        hx[7] = CGPoint(x: (q[3].x + q[0].x) / 2, y: (q[3].y + q[0].y) / 2)
        // centre 8
        hx[8] = CGPoint(x: (q[0].x + q[2].x) / 2, y: (q[0].y + q[2].y) / 2)
        // rotate handle: from the top edge midpoint, OUTWARD along
        // (topMid − centre), 36dp (zip rotX/rotY)
        let dx = hx[4].x - hx[8].x
        let dy = hx[4].y - hx[8].y
        let len = max(sqrt(dx * dx + dy * dy), 1)
        rotP = CGPoint(x: hx[4].x + dx / len * 36, y: hx[4].y + dy / len * 36)
        return true
    }

    // MARK: - drawing

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }

        if guides {
            let col = Int32(bitPattern: 0x55FFFFFF)
            let w = bounds.width
            let h = bounds.height
            strokeLine(c, w / 3, 0, w / 3, h, 1, col)
            strokeLine(c, 2 * w / 3, 0, 2 * w / 3, h, 1, col)
            strokeLine(c, 0, h / 3, w, h / 3, 1, col)
            strokeLine(c, 0, 2 * h / 3, w, 2 * h / 3, 1, col)
            strokeLine(c, w / 2, 0, w / 2, h, 1, col)
            strokeLine(c, 0, h / 2, w, h / 2, 1, col)
        }

        if pick != nil {
            // eyedropper crosshair
            let col = Int32(bitPattern: 0xFFFFFFFF)
            strokeLine(c, bounds.width / 2 - 14, bounds.height / 2, bounds.width / 2 + 14, bounds.height / 2, 1.5, col)
            strokeLine(c, bounds.width / 2, bounds.height / 2 - 14, bounds.width / 2, bounds.height / 2 + 14, 1.5, col)
        }

        guard project() else { return }
        let l = editHost?.selectedLayer()
        let sel = C.GREEN

        // dashed outline (zip: DashPathEffect(8dp, 5dp), 1.6dp stroke)
        c.setStrokeColor(argbToUIColor(sel).cgColor)
        c.setLineWidth(1.6)
        c.setLineDash(phase: 0, lengths: [8, 5])
        c.move(to: hx[0]); c.addLine(to: hx[1]); c.addLine(to: hx[2]); c.addLine(to: hx[3]); c.closePath()
        c.strokePath()
        c.setLineDash(phase: 0, lengths: [])

        if l?.isRenderable() == true || l?.type == .GROUP {
            // rotate stem + tip
            strokeLine(c, hx[4].x, hx[4].y, rotP.x, rotP.y, 1.6, sel)
            fillCircle(c, rotP.x, rotP.y, 7, Int32(bitPattern: 0xFFFFFFFF))
            strokeCircle(c, rotP.x, rotP.y, 3.5, 1.6, sel)
            // white square handles at corners + edge midpoints (9dp squares)
            let hs: CGFloat = 4.5
            for i in 0..<8 {
                fillRect(c, CGRect(x: hx[i].x - hs, y: hx[i].y - hs, width: hs * 2, height: hs * 2),
                         Int32(bitPattern: 0xFFFFFFFF))
            }
            // centre: green ring + white dot
            strokeCircle(c, hx[8].x, hx[8].y, 7, 1.6, sel)
            fillCircle(c, hx[8].x, hx[8].y, 1.8, Int32(bitPattern: 0xFFFFFFFF))
        }
    }

    // MARK: - pinch (zip: scales the selected layer)

    @objc private func pinchScale(_ g: UIPinchGestureRecognizer) {
        guard let l = editHost?.selectedLayer() else { return }
        if g.state == .began {
            editHost?.beginEdit()
        }
        let lt = l.editTime("scale", Editor.time)
        let tr = l.track("scale")
        let v = tr.eval(lt) * Float(g.scale)
        tr.set(lt, min(max(v, 0.05), 8), editHost?.autoKey() ?? false)
        g.scale = 1
        setNeedsDisplay()
        if g.state == .began || g.state == .changed { editHost?.onEdited() }
    }

    // MARK: - touches (zip onTouchEvent)

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        let p = t.location(in: self)

        if pick != nil {
            pick?(Float(p.x), Float(p.y))
            pick = nil
            setNeedsDisplay()
            return
        }

        guard let l = editHost?.selectedLayer() else {
            // tap-select: top-most hit layer (reverse draw order)
            let w = toWorld(p)
            for layer in Editor.scene.layers.reversed() {
                guard layer.visible, layer.isRenderable() || layer.type == .GROUP || layer.type == .CAMERA
                        || layer.type == .NULL || layer.type == .ADJUST else { continue }
                guard Editor.time >= layer.start - 0.001 && Editor.time <= layer.end + 0.001 else { continue }
                if Xf.hit(layer, w.0, w.1, Editor.time) {
                    editHost?.onSelect(layer.id)
                    setNeedsDisplay()
                    return
                }
            }
            editHost?.onSelect(-1)
            setNeedsDisplay()
            return
        }

        guard project() else { return }
        editHost?.beginEdit()
        skip = false
        let lt = l.editTime("rotZ", Editor.time)
        let slop: CGFloat = 26
        mode = 1
        if l.isRenderable() || l.type == .GROUP {
            if distance(p, rotP) < slop {
                mode = 3
                startAng = atan2(p.y - hx[8].y, p.x - hx[8].x) * 180 / .pi
                startRot = l.p("rotZ", lt)
            } else {
                for i in 0..<8 {
                    if distance(p, hx[i]) < slop {
                        mode = 2
                        startDist = max(distance(p, hx[8]), 1)
                        startScale = l.p("scale", l.editTime("scale", Editor.time))
                        break
                    }
                }
            }
        }
        lastP = p
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first, let l = editHost?.selectedLayer(), mode != 0 else { return }
        let p = t.location(in: self)
        if skip { lastP = p; skip = false; return }
        let ak = editHost?.autoKey() ?? false

        switch mode {
        case 1: // move — dx/dy in world units
            let lt = l.editTime("x", Editor.time)
            let k = 2 / Float(max(bounds.height, 1))
            let tx = l.track("x")
            let ty = l.track("y")
            tx.set(lt, tx.eval(lt) + Float(p.x - lastP.x) * k, ak)
            ty.set(lt, ty.eval(lt) - Float(p.y - lastP.y) * k, ak)
        case 2: // scale by distance from centre
            let dist = distance(p, hx[8])
            let lt = l.editTime("scale", Editor.time)
            l.track("scale").set(lt, min(max(startScale * Float(dist / startDist), 0.05), 8), ak)
        case 3: // rotate around the layer centre (zip math)
            let ang = atan2(p.y - hx[8].y, p.x - hx[8].x) * 180 / .pi
            var v = startRot - Float(ang - startAng)
            while v > 360 { v -= 720 }
            while v < -360 { v += 720 }
            let lt = l.editTime("rotZ", Editor.time)
            l.track("rotZ").set(lt, min(max(v, -360), 360), ak)
        default:
            break
        }
        lastP = p
        editHost?.onEdited()
        setNeedsDisplay()
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        // tap outside any handle → reselect whatever is under the finger
        if mode == 1, let t = touches.first {
            let p = t.location(in: self)
            let w = toWorld(p)
            if let l = editHost?.selectedLayer(), !Xf.hit(l, w.0, w.1, Editor.time) {
                for layer in Editor.scene.layers.reversed() {
                    guard layer.visible, Editor.time >= layer.start - 0.001 && Editor.time <= layer.end + 0.001 else { continue }
                    if Xf.hit(layer, w.0, w.1, Editor.time) {
                        editHost?.onSelect(layer.id)
                        break
                    }
                }
            }
        }
        mode = 0
        setNeedsDisplay()
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        mode = 0
        setNeedsDisplay()
    }

    private func distance(_ a: CGPoint, _ b: CGPoint) -> CGFloat {
        hypot(a.x - b.x, a.y - b.y)
    }
}
