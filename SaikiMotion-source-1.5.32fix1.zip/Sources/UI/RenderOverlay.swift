// RenderOverlay.swift — the render flow UI: the settings dialog and the
// full-screen render overlay with the looping sleeping-chibi animation.
//
// A port of the zip's RenderUi.kt: the settings dialog lists output size /
// quality / bit rate / frame rate; the overlay is a black full-screen with
// the chibi animation (render_f0.. frames cycling at 140 ms), the big
// "Rendering" title, a status line ("Rendering 42%  ·  keep the app open"),
// a slim progress bar and pill buttons (Cancel, then Save to Photos/Close).

import UIKit
import Foundation

// MARK: - RenderUi

/// The render flow the editor launches: a settings dialog, then a full-screen
/// progress controller with cancel, then Save to Photos / Close.
enum RenderUi {

    static func autoMbps(_ w: Int, _ h: Int, _ fps: Int) -> Int {
        Int(min(max(Int64(w) * Int64(h) * Int64(fps) / 9 / 1_000_000, 2), 100))
    }

    static func settings(_ vc: UIViewController, _ project: Project,
                         _ done: @escaping (RenderSettings) -> Void) {
        var st = RenderSettings()
        let scales: [Float] = [1, 0.75, 0.5]
        let rates = [0, 8, 16, 32, 64]
        let fpsList = [0, 24, 30, 60]
        var qi = 0
        var bi = 0
        var fi = 0

        let box = UIStackView()
        box.axis = .vertical
        box.alignment = .fill
        box.spacing = 2
        box.isLayoutMarginsRelativeArrangement = true
        box.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 4, leading: 4, bottom: 4, trailing: 4)

        func line(_ t: String, _ color: Int32, _ size: CGFloat, _ bold: Bool = false) {
            let l = UILabel()
            l.text = t
            l.textColor = argbToUIColor(color)
            l.font = bold ? boldFont(size) : sysFont(size)
            l.numberOfLines = 1
            l.adjustsFontSizeToFitWidth = true
            l.minimumScaleFactor = 0.7
            box.addArrangedSubview(l)
        }

        func build() {
            box.arrangedSubviews.forEach { $0.removeFromSuperview() }
            st.scale = scales[qi]
            st.mbps = rates[bi]
            st.fps = fpsList[fi]
            let w = Int(Float(project.w) * st.scale / 2) * 2
            let h = Int(Float(project.h) * st.scale / 2) * 2
            let fps = st.fps > 0 ? st.fps : project.fps
            var dur: Float = 0
            for sc in project.scenes { dur += sc.duration }
            let mbps = st.mbps > 0 ? st.mbps : autoMbps(w, h, fps)
            line("Output", C.GREEN, 13, true)
            line("\(w) x \(h)  ·  \(fps) fps  ·  " + String(format: "%.1f", dur) + " s", C.TEXT, 16)
            line("\(mbps) Mbps  ·  about " + String(format: "%.0f", Float(mbps) * dur / 8) + " MB", C.DIM, 13)
            line("Quality", C.GREEN, 13, true)
            box.addArrangedSubview(chipRow(["Full size", "3/4 size", "1/2 size"], qi) { i in qi = i; build() })
            line("Bit rate", C.GREEN, 13, true)
            box.addArrangedSubview(chipRow(["Auto", "8 Mbps", "16 Mbps", "32 Mbps", "64 Mbps"], bi) { i in bi = i; build() })
            line("Frame rate", C.GREEN, 13, true)
            box.addArrangedSubview(chipRow(["Project (\(project.fps))", "24", "30", "60"], fi) { i in fi = i; build() })
        }
        build()

        _ = Dlg(vc).setTitle("Render settings").setView(box)
            .setPositiveButton("Render") { _, _ in
                done(st)
            }
            .setNegativeButton("Cancel", nil)
            .show()
    }

    static func show(_ vc: UIViewController, _ project: Project, _ st: RenderSettings) {
        let progress = RenderProgressViewController(project: project, settings: st)
        progress.modalPresentationStyle = .fullScreen
        vc.present(progress, animated: true)
    }
}

// MARK: - the slim progress bar

final class RenderBarView: UIView {

    var progress: CGFloat = 0 { didSet { setNeedsDisplay() } }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let h = bounds.height
        fillRoundRect(c, bounds, h / 2, C.CARD2)
        let p = min(max(progress, 0), 1)
        if p > 0.001 {
            fillRoundRect(c, CGRect(x: 0, y: 0, width: bounds.width * p, height: h), h / 2, C.GREEN)
        }
    }
}

// MARK: - the render overlay (sleeping chibi)

final class RenderProgressViewController: UIViewController {
    private let project: Project
    private let settings: RenderSettings
    private let img = UIImageView()
    private let titleL = UILabel()
    private let status = UILabel()
    private let bar = RenderBarView()
    private var cancelB: PillButton? = nil
    private var actions = UIStackView()
    private var frames: [UIImage] = []
    private var frameIdx = 0
    private var animTimer: Timer? = nil
    private var pollTimer: Timer? = nil
    private var cancelled = false
    private var finished = false
    private var result: Exporter.Result? = nil

    init(project: Project, settings: RenderSettings) {
        self.project = project
        self.settings = settings
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    override var prefersStatusBarHidden: Bool { true }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.black

        let col = UIStackView()
        col.axis = .vertical
        col.alignment = .center
        col.spacing = 0
        col.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(col)

        img.contentMode = .scaleAspectFit
        img.widthAnchor.constraint(equalToConstant: 260).isActive = true
        img.heightAnchor.constraint(equalToConstant: 260).isActive = true
        col.addArrangedSubview(img)

        titleL.text = "Rendering"
        titleL.textColor = argbToUIColor(Int32(bitPattern: 0xFFFFFFFF))
        titleL.font = boldFont(26)
        titleL.textAlignment = .center
        col.setCustomSpacing(12, after: img)
        col.addArrangedSubview(titleL)

        status.text = "Starting..."
        status.textColor = argbToUIColor(C.DIM)
        status.font = sysFont(15)
        status.textAlignment = .center
        status.numberOfLines = 2
        col.setCustomSpacing(4, after: titleL)
        col.addArrangedSubview(status)

        bar.heightAnchor.constraint(equalToConstant: 10).isActive = true
        col.setCustomSpacing(16, after: status)
        col.addArrangedSubview(bar)

        actions.axis = .vertical
        actions.alignment = .fill
        actions.spacing = 8
        col.setCustomSpacing(24, after: bar)
        col.addArrangedSubview(actions)

        NSLayoutConstraint.activate([
            col.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            col.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            col.leadingAnchor.constraint(greaterThanOrEqualTo: view.leadingAnchor, constant: 32),
            view.trailingAnchor.constraint(greaterThanOrEqualTo: col.trailingAnchor, constant: 32),
            bar.widthAnchor.constraint(equalToConstant: 280),
            actions.widthAnchor.constraint(equalToConstant: 280),
        ])

        // the sleeping-chibi frames: render_f0.. until missing (zip: 140 ms loop)
        var i = 0
        while i < 64 {
            var f: UIImage? = UIImage(named: "render_f\(i)")
            if f == nil, let u = Bundle.main.url(forResource: "render_f\(i)", withExtension: "png") {
                f = UIImage(contentsOfFile: u.path)
            }
            if let f = f { frames.append(f); i += 1 } else { break }
        }
        if !frames.isEmpty { img.image = frames[0] }
        animTimer = Timer.scheduledTimer(withTimeInterval: 0.14, repeats: true) { [weak self] _ in
            guard let self = self, !self.frames.isEmpty else { return }
            self.frameIdx = (self.frameIdx + 1) % self.frames.count
            self.img.image = self.frames[self.frameIdx]
        }

        addButton("Cancel", C.CARD2, C.TEXT) { [weak self] in
            guard let self = self else { return }
            self.cancelled = true
            self.status.text = "Cancelling..."
            self.cancelB?.isUserInteractionEnabled = false
        }
        start()
    }

    @discardableResult
    private func addButton(_ text: String, _ fill: Int32, _ tc: Int32,
                           _ click: @escaping () -> Void) -> PillButton {
        let b = PillButton(text, nil, fill, tc)
        b.onClick = click
        b.heightAnchor.constraint(equalToConstant: 50).isActive = true
        actions.addArrangedSubview(b)
        if text == "Cancel" { cancelB = b }
        return b
    }

    private func start() {
        let project = self.project
        let st = self.settings
        let scene = Editor.scene
        let total = max(1, Int(scene.duration * Float(st.fps > 0 ? st.fps : project.fps)))
        Thread.detachNewThread {
            let res = Exporter.export(project: project, scene: scene, settings: st)
            DispatchQueue.main.async { [weak self] in
                self?.finished(res)
            }
        }
        pollTimer = Timer.scheduledTimer(withTimeInterval: 0.2, repeats: true) { [weak self] t in
            guard let self = self else { t.invalidate(); return }
            if self.finished { t.invalidate(); return }
            let done = ExporterProgress.shared.frames
            let pct = min(Int(Double(done) / Double(total) * 100), 100)
            self.bar.progress = CGFloat(done) / CGFloat(total)
            self.status.text = "Rendering \(pct)%  ·  keep the app open"
        }
    }

    private func finished(_ res: Exporter.Result) {
        guard !finished else { return }
        finished = true
        animTimer?.invalidate()
        pollTimer?.invalidate()
        actions.arrangedSubviews.forEach { $0.removeFromSuperview() }
        bar.isHidden = true
        result = res
        if cancelled {
            if let u = res.url { try? FileManager.default.removeItem(at: u) }
            dismiss(animated: true)
            return
        }
        if let err = res.error {
            titleL.text = "Render failed"
            status.text = err
            addButton("Close", C.GREEN, Int32(bitPattern: 0xFF2B1400)) { [weak self] in
                self?.dismiss(animated: true)
            }
            return
        }
        guard let url = res.url else {
            dismiss(animated: true)
            return
        }
        titleL.text = "Render complete"
        let sz = (try? FileManager.default.attributesOfItem(atPath: url.path))?[.size] as? Int ?? 0
        let mb = Float(sz) / 1048576
        status.text = String(format: "%.1f MB", mb)
        addButton("Save to Photos", C.GREEN, Int32(bitPattern: 0xFF2B1400)) { [weak self] in
            guard let self = self else { return }
            self.status.text = "Saving..."
            let u = url
            Thread.detachNewThread {
                UISaveVideoAtPathToSavedPhotosAlbum(u.path, nil, nil, nil)
                DispatchQueue.main.async { [weak self] in
                    self?.status.text = "Saved to Photos"
                    self?.actions.arrangedSubviews.forEach { $0.removeFromSuperview() }
                }
            }
        }
        addButton("Close", C.CARD2, C.TEXT) { [weak self] in
            self?.dismiss(animated: true)
        }
    }
}

/// Cross-thread frame counter (exporter pumps, UI animates).
enum ExporterProgress {
    static var shared = Shared()
    final class Shared {
        private(set) var frames = 0
        private let lock = NSLock()
        func add() {
            lock.lock()
            frames += 1
            lock.unlock()
        }
    }
}
