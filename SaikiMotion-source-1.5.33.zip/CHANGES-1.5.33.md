# SaikiMotion 1.5.33 (build 44) — "make it actually work"

This release fixes the four report blockers: the green editor, the green /
dead viewport, the crash on open / add, and effect previews that never
rendered. Root causes were found in the render core, not in the editor UI.

## The viewport was green / empty

`PreviewView.draw(_:)` ended with `glBindFramebuffer(GL_FRAMEBUFFER, 0)` —
an Android/GLSurfaceView idiom. iOS has **no default framebuffer**; GLKView
renders into its own FBO. Binding 0 unbound the drawable, so the clear and
the present pass drew into nothing and GLKView presented its uninitialized
storage — solid green on Apple GPUs. The present pass now rebinds the
view's own `framebuffer`.

## Nothing rendered (preview AND thumbnails)

`Gl.quadVBO` was one static VBO shared by every EAGL context. GL buffer
names only exist in the context that created them: whichever of the
preview / thumbnail generator / shader validator touched it first won, and
every other context silently drew nothing. `drawQuad` now keeps a
per-context VBO cache.

## The crash (SIGSEGV, same PC every run)

Two real memory bugs, both fixed:

1. `Gl.upload` / `Gl.Target.readImage` handed `CGContext(data: &array)` a
   pointer that is only valid for the duration of the call, while CoreGraphics
   kept writing through it afterwards. Undefined behavior in Release (-O);
   it detonated on image upload / readback — i.e. right after opening a
   project or adding media. All pixel copies now live inside one
   `withUnsafeMutableBytes` scope.
2. `EffectThumbs.cache` (and `Registry.order/byId/errors`) were read on the
   main thread while the background thumbnail queue wrote them — a Swift
   Dictionary data race that corrupts the map. All cross-thread access now
   goes through locked accessors, and the catalog rebuild holds the lock.

## Effect previews never showed the effect

`runGeneration` drew the sample, called `readImage()` (which leaves
framebuffer 0 bound), then ran the effect "into" the same texture it was
sampling (feedback loop = undefined). The effect pass went nowhere. It now
pings-pongs between two targets and rebinds before every draw. Readbacks
are flipped upright (glReadPixels is bottom-up).

## The editor was green

`C.GREEN` was changed to actual green in the rebuild. The original app's
own `Ui.swift` defines `GREEN = 0xFFFF8A1F` — the orange accent. Restored
(plus ONDARK/GREEN_DARK to match).

## New sample photos for effect previews

The two supplied photos (redwood forest, portrait) ship as
`Resources/img/fx_sample_forest.jpg` / `fx_sample_portrait.jpg` and join the
sample pool every effect renders against. The rebuild had also regressed
here: it generated synthetic gradient "samples" and never used the real
photos the original app shipped (`anime_portrait`, `fx_mountain`,
`fx_ramen`, `fx_woman` — all still bundled, all unreferenced). The pool is
now six real photos; each effect picks its variant by a **stable** djb2
hash, so your two photos take ~23 of ~79 cards and the rest keep the
originals — some replaced, not all. (Swift's `hashValue` is reseeded per
launch, which used to reshuffle cards and mismatch placeholder vs render.)

## Also fixed

- `shapeProg`: the fragment shader's `uQuadSize` was never set (the code
  set `uQuad`) — every shape except plain RECT was invisible.
- Effect layer inputs (Set Matte etc.): the referenced layer rendered into
  `layerA`, clobbering the effect chain's ping-pong buffer, and the input
  target stayed empty. Inputs now render into the input target.
- Video layers: frame textures were uploaded on the main thread with no
  guarantee the GL context was current — frames silently never appeared.
  Decoded frames now hand off to the GL thread and upload inside the draw
  call. The exporter's samplers are synchronous so exports are never a
  decode behind.
- `buildPrograms`: one failed shader no longer wedges the others forever;
  each program builds (and retries) independently.
- Performance: text layers no longer re-upload their texture every frame
  (16-entry cache), image textures use true LRU eviction, the shader
  validator reuses ONE GL context instead of creating ~100, video asset
  cache is capped.
