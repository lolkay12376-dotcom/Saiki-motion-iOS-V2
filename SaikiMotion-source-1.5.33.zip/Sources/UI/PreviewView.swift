// PreviewView.swift — the GL preview surface (UI).
//
// A GLKView with its own GLES context that renders the scene through
// SceneRenderer every time the editor asks (requestDraw). It also serves as
// the VideoSource: video layers get their frames from per-layer async
// samplers, and an arriving frame schedules the next draw.
//
// PORT NOTE (the green viewport bug): the Kotlin original ended its frame
// with glBindFramebuffer(GL_FRAMEBUFFER, 0) because on Android/GLSurfaceView
// FBO 0 IS the window. On iOS there is NO default framebuffer — GLKView
// renders into its own framebuffer object. Binding 0 unbound the drawable,
// so the clear and the present pass drew into nothing and GLKView presented
// its UNINITIALIZED drawable: solid green. The present pass now rebinds
// this view's own `framebuffer` before drawing.

import UIKit
import OpenGLES
import GLKit

final class PreviewView: GLKView, VideoSource {

    var quality = 1 {
        didSet { setNeedsDisplay() }
    }

    private var renderer: SceneRenderer?
    private var samplers: [Int: VideoFrames.Sampler] = [:]

    init() {
        // GLContext.make tries GLES3 then GLES2. GLES2 exists on every iOS
        // device; if both somehow failed, GLKView cannot exist at all — but
        // that hardware does not exist, and one explicit trap beats a silent
        // green screen.
        let ctx = GLContext.make()
        super.init(frame: .zero, context: ctx ?? EAGLContext(api: .openGLES2)!)
        drawableColorFormat = .RGBA8888
        drawableDepthFormat = .formatNone
        drawableStencilFormat = .formatNone
        drawableMultisample = .multisampleNone
        enableSetNeedsDisplay = true
        isOpaque = true
        backgroundColor = UIColor.black
        contentMode = .redraw
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    /// Kotlin: preview.onResume() — GLKView has no pause; redraw instead.
    func requestDraw() {
        setNeedsDisplay()
    }

    /// Kotlin: preview.onPause() — drop the async video samplers.
    func releaseVideos() {
        samplers.removeAll()
    }

    override func draw(_ rect: CGRect) {
        guard let ctx = context as? EAGLContext else { return }
        EAGLContext.setCurrent(ctx)
        if renderer == nil {
            renderer = SceneRenderer(context: ctx)
        }
        guard let renderer = renderer else { return }
        renderer.quality = quality
        let tex = renderer.draw(project: Editor.project, scene: Editor.scene,
                                time: Editor.time, video: self)

        // present: blit the scene texture into THIS view's drawable.
        // GLKView bound its framebuffer before calling draw(_:) — but the
        // renderer rebound its own offscreen targets above, so rebind ours
        // (NOT 0 — iOS has no default framebuffer).
        glBindFramebuffer(GLenum(GL_FRAMEBUFFER), framebuffer)
        glViewport(0, 0, GLsizei(drawableWidth), GLsizei(drawableHeight))
        glDisable(GLenum(GL_BLEND))
        glClearColor(0, 0, 0, 1)
        glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
        renderer.present(tex)
    }

    // MARK: - VideoSource

    /// Called from inside SceneRenderer.draw (GL context current on this
    /// thread) — the only place where creating/uploading textures is legal.
    func videoTexture(layerId: Int, path: String, srcTime: Float) -> GLuint {
        if let s = samplers[layerId] {
            return s.texture(at: srcTime)
        }
        let s = VideoFrames.Sampler(path: path)
        s.onUploaded = { [weak self] in
            self?.setNeedsDisplay()
        }
        samplers[layerId] = s
        return s.texture(at: srcTime)
    }

    func videoFrameArrived() -> Bool {
        false
    }
}
