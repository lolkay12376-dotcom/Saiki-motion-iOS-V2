# SaikiMotion 1.5.33fix1 (build 45) — "the 1.5.33 source did not compile"

The 1.5.33 source never produced a binary: the CI xcodebuild failed with
three Swift errors in two files. Whole-module optimization type-checks the
entire module before failing, so these were the only three errors — no
others are hiding behind them. All three are fixed here; no behavior beyond
what 1.5.33 intended has changed.

## 1. PreviewView.swift:73 — `cannot find 'framebuffer' in scope`

```swift
glBindFramebuffer(GLenum(GL_FRAMEBUFFER), framebuffer)
```

GLKView has **no public `framebuffer` property** (its FBO name is private).
The green-viewport fix in 1.5.33 was written against an API that does not
exist. Replaced with the public API that does exactly this — bind the
view's framebuffer to the current context:

```swift
bindDrawable()
```

The `glViewport` / clear / `present(tex)` calls after it are unchanged.
This still fixes the original green-viewport bug: `bindDrawable()` rebinds
the view's own framebuffer, never FBO 0 (which does not exist on iOS).

## 2 & 3. SdkIdeViewController.swift:686-687 — optional `String?` not unwrapped

```swift
let id = folder != nil ? effectIdOf(folder!) : nil   // String?
EffectThumbs.removeThumbs(matching: id)               // takes String
EffectThumbs.removeThumbs(matching: "custom:" + id)   // String + String?
```

`effectIdOf(_:)` returns `String?` (nil when the folder has no readable
effect.json / no id), but `removeThumbs(matching:)` takes a plain `String`.
Both calls are now inside a guard so they only run when an id exists —
when there is no id there is no cached thumbnail to invalidate, and the
function goes on to report the missing-id problem as before:

```swift
if let id = id {
    EffectThumbs.removeThumbs(matching: id)
    EffectThumbs.removeThumbs(matching: "custom:" + id)
}
```

## Version

`1.5.33fix1` / build 45 (AppInfo.swift and Info.plist, both keys — the
round-18 rule). The rest of the 1.5.33 changes are untouched.
