// EditorDialogs.swift — dialogs: motion blur, parent popup, expressions, scene setup, render launcher, panel menu.

import UIKit
import AVFoundation

extension EditorViewController {
        // ---------------------------------------------------------------- motion blur settings + parent popup

        func showMotionBlurSettings(_ l: Layer) {
            let box = vStack()
            box.isLayoutMarginsRelativeArrangement = true
            box.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 4, leading: 4, bottom: 4, trailing: 4)
            let on = SwitchRow()
            on.label = "Motion blur"
            on.on = l.mblur
            on.onToggle = { [weak self] v in
                guard let self = self else { return }
                self.pushUndo()
                l.mblur = v
                self.mbToggle.on = v
                self.render()
            }
            put(box, on, 52)
            let stut = SwitchRow()
            stut.label = "Stuttering"
            stut.on = l.mbStutter
            stut.onToggle = { [weak self] v in self?.pushUndo(); l.mbStutter = v; self?.render() }
            put(box, stut, 52)
            let rgb = SwitchRow()
            rgb.label = "Enable RGB sampling"
            rgb.on = l.mbRgb
            rgb.onToggle = { [weak self] v in self?.pushUndo(); l.mbRgb = v; self?.render() }
            put(box, rgb, 52)
            text(box, "Quality", C.DIM, 13)
            let smp = l.track("mbSamples")
            let q = smp.base <= 5 ? 0 : smp.base <= 10 ? 1 : 2
            box.addArrangedSubview(chipRow(["Low", "Medium", "High"], q) { [weak self] i in
                guard let self = self else { return }
                self.pushUndo()
                smp.keys.removeAll()
                smp.base = [4, 8, 16][i]
                self.render()
            })
            let amt = l.track("mbAmount")
            addPlain(box, "Blur strength", 0, 4, amt.base, 2) { [weak self] v in
                guard let self = self else { return }
                self.pushUndo()
                amt.keys.removeAll()
                amt.base = v
                self.render()
            }
            if l.type == .CAMERA { text(box, "Camera motion blur: every 3D layer below this camera is blurred by the camera's movement.", C.DIM, 12) }
            text(box, "Stuttering snaps the blur samples to whole frames. RGB sampling gives the trails a red-to-blue fringe.", C.DIM, 12)
            let sv = CapScroll()
            sv.addSubview(box)
            box.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                box.topAnchor.constraint(equalTo: sv.contentLayoutGuide.topAnchor),
                box.bottomAnchor.constraint(equalTo: sv.contentLayoutGuide.bottomAnchor),
                box.leadingAnchor.constraint(equalTo: sv.contentLayoutGuide.leadingAnchor),
                box.trailingAnchor.constraint(equalTo: sv.contentLayoutGuide.trailingAnchor),
                box.widthAnchor.constraint(equalTo: sv.frameLayoutGuide.widthAnchor)
            ])
            _ = Dlg(self).setTitle("Motion blur").setView(sv).setPositiveButton("Done", nil).show()
        }

        func typeIcon(_ t: LayerType) -> String {
            switch t {
            case .SHAPE: return "shape"
            case .TEXT: return "text"
            case .IMAGE, .VIDEO: return "media"
            case .CAMERA: return "camera"
            case .NULL: return "nullobj"
            case .MODEL: return "cube"
            case .PARTICLES: return "particles"
            case .GROUP: return "layers"
            case .ADJUST: return "adjust"
            case .AUDIO: return "audio"
            case .FLARE: return "flare"
            }
        }

        func showParentPopup(_ l: Layer, _ anchor: UIView) {
            let cands = Editor.scene.layers.filter { $0.id != l.id && !Layer.isDescendant($0, of: l, in: Editor.scene.layers) }
            let col = vStack()
            col.isLayoutMarginsRelativeArrangement = true
            col.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 8, leading: 8, bottom: 8, trailing: 8)
            col.backgroundColor = argbToUIColor(C.CARD)
            col.layer.cornerRadius = 16
            col.layer.borderColor = argbToUIColor(Int32(bitPattern: 0xFF3A3A42)).cgColor
            col.layer.borderWidth = 1
            let sv = CapScroll()
            sv.addSubview(col)
            col.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                col.topAnchor.constraint(equalTo: sv.contentLayoutGuide.topAnchor),
                col.bottomAnchor.constraint(lessThanOrEqualTo: sv.contentLayoutGuide.bottomAnchor),
                col.leadingAnchor.constraint(equalTo: sv.contentLayoutGuide.leadingAnchor),
                col.trailingAnchor.constraint(equalTo: sv.contentLayoutGuide.trailingAnchor),
                col.widthAnchor.constraint(equalToConstant: 240)
            ])
            func item(_ icon: String, _ name: String, _ on: Bool, _ pick: @escaping () -> Void) {
                let row = hRow()
                row.isLayoutMarginsRelativeArrangement = true
                row.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 10, bottom: 0, trailing: 10)
                row.backgroundColor = argbToUIColor(Int32(bitPattern: 0xFF2A2A30))
                row.layer.cornerRadius = 12
                if on { row.layer.borderWidth = 2; row.layer.borderColor = argbToUIColor(C.GREEN).cgColor }
                row.addArrangedSubview(wrap(IconView(icon, on ? C.GREEN : C.TEXT, 20), 32, 44, 0, 0, 0, 0))
                let tv = UILabel()
                tv.text = name
                tv.textColor = argbToUIColor(C.TEXT)
                tv.font = sysFont(15)
                tv.numberOfLines = 1
                tv.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
                row.addArrangedSubview(tv)
                let tap = TapView()
                tap.addSubview(row)
                tap.onClick = pick
                put(col, tap, 46, 3, 3)
            }
            item("close", "None", l.parentId < 0) { [weak self] in
                guard let self = self else { return }
                self.pushUndo()
                l.parentId = -1
                self.refreshTitle(); self.refreshPanel(); self.render()
                Dlg.dismissCurrent()
            }
            for c in cands {
                item(typeIcon(c.type), c.name, l.parentId == c.id) { [weak self] in
                    guard let self = self else { return }
                    self.pushUndo()
                    l.parentId = c.id
                    self.refreshTitle(); self.refreshPanel(); self.render()
                    Dlg.dismissCurrent()
                }
            }
            _ = Dlg(self).setTitle("Parent").setView(sv).setNegativeButton("Close", nil).show()
        }

        // ---------------------------------------------------------------- expressions, audio, beats

        func showExpression(_ l: Layer, _ d: PropDef) {
            let tr = l.track(d.key)
            let box = vStack()
            box.isLayoutMarginsRelativeArrangement = true
            box.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 4, leading: 4, bottom: 4, trailing: 4)
            let sw = SwitchRow()
            sw.label = "fx  (expression)"
            sw.on = tr.exprOn && !tr.exprSrc.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            sw.captionOn = "On"; sw.captionOff = "Off"
            var swOn = sw.on
            sw.onToggle = { v in swOn = v }
            put(box, sw, 52)
            text(box, "t = time, v = keyframed value. wiggle(freq, amp), sin, cos, abs, min, max, clamp, pow, sqrt, linear(t, a, b, c, d), noise, floor, round, mix, if(c, a, b), step(a, b), comparisons < > <= >= ==, pi, marker.key(\"name\").", C.DIM, 12)
            let et = makeField(tr.exprSrc)
            et.font = monoFont(14)
            et.placeholder = "v + wiggle(3, 0.1)"
            put(box, et, 44)
            let presets = ["v + wiggle(3, 0.1)", "v * (1 + 0.2 * sin(t * 8))", "v + t * 90", "v + abs(sin(t * 4)) * 0.3", ""]
            box.addArrangedSubview(chipRow(["Wiggle", "Pulse", "Spin", "Bounce", "Clear"], -1) { i in
                et.text = presets[i]
            })
            let names = Editor.scene.markerNames.values.sorted()
            if !names.isEmpty {
                text(box, "Named markers (tap to insert)", C.DIM, 12)
                box.addArrangedSubview(chipRow(names, -1) { i in
                    let ins = "marker.key(\"" + names[i] + "\")"
                    let s = (et.text ?? "") as NSString
                    var pos = 0
                    if let r = et.selectedTextRange {
                        pos = et.offset(from: et.beginningOfDocument, to: r.start)
                    }
                    let p = min(max(0, pos), s.length)
                    et.text = s.replacingCharacters(in: NSRange(location: p, length: 0), with: ins)
                })
            }
            Dlg(self).setTitle("Expression: " + d.label).setView(box).setPositiveButton("Apply") { [weak self] _, _ in
                guard let self = self else { return }
                self.pushUndo()
                let src = et.text ?? ""
                if !tr.setExpr(src) {
                    self.toast("Expression error")
                } else {
                    tr.exprOn = swOn && !src.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                    self.refreshPanel(); self.render()
                }
            }.setNegativeButton("Cancel", nil).show()
        }

        func snapKeys(_ l: Layer) {
            let ms = Editor.scene.markers
            for (_, tr) in l.props {
                var ch = false
                for k in tr.keys {
                    if let m = ms.min(by: { abs($0 - k.t) < abs($1 - k.t) }) {
                        if abs(m - k.t) < 0.35 { k.t = m; ch = true }
                    }
                }
                if ch { tr.keys.sort { $0.t < $1.t } }
            }
            toast("Keyframes snapped to markers")
        }

        func showPanelMenu() {
            guard let l = selected() else { return }
            Dlg(self).setTitle("Layer").setItems(["Clear all keyframes", "Reset transform", "Snap keyframes to beat markers"]) { [weak self] _, which in
                guard let self = self else { return }
                self.pushUndo()
                if which == 2 {
                    self.snapKeys(l)
                } else {
                    for (k, tr) in l.props {
                        if which == 0 {
                            tr.keys.removeAll()
                            _ = tr.setExpr("")
                            tr.exprOn = false
                        } else if Defs.transform.contains(where: { $0.key == k })
                                    || Defs.rot3d.contains(where: { $0.key == k }) || k == "z" {
                            tr.keys.removeAll()
                            tr.base = Registry.propDef(k)?.def ?? 0
                        }
                    }
                }
                self.refreshPanel(); self.render()
            }.show()
        }

        // ================================================================ scenes + export

        func showSceneDialog() {
            let box = vStack()
            box.isLayoutMarginsRelativeArrangement = true
            box.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16)
            let dlg = Dlg(self).setTitle("Scene setup").setView(box).create()
            var applyName: (() -> Void)? = nil
            var build: (() -> Void)! = nil
            build = { [weak self] in
                guard let self = self else { return }
                box.arrangedSubviews.forEach { $0.removeFromSuperview() }
                let pr = Editor.project
                let s = Editor.scene

                // ---- project identity
                text(box, "Project name", C.GREEN, 13, true)
                let nameF = self.makeField(pr.name)
                nameF.returnKeyType = .done
                put(box, nameF, 44, 0, 0)
                applyName = {
                    let nm = (nameF.text ?? "").trimmingCharacters(in: .whitespaces)
                    if !nm.isEmpty, nm != pr.name {
                        self.pushUndo()
                        pr.name = nm
                        self.refreshTitle()
                    }
                }

                // ---- canvas + frame rate
                text(box, "Canvas", C.GREEN, 13, true)
                text(box, "\(pr.w) x \(pr.h)  ·  \(Projects.resLabel(pr.w, pr.h))", C.DIM, 12)
                var res = 0
                let hd = max(pr.w, pr.h)
                if hd >= 2000 { res = 2 } else if hd >= 1000 { res = 1 }
                var aspect = 0
                let r = Double(pr.w) / Double(max(pr.h, 1))
                if r > 1.2 { aspect = 0 } else if r < 0.83 { aspect = 1 } else { aspect = 2 }
                func applyDims(_ resIdx: Int, _ aspIdx: Int) {
                    let base = [720, 1080, 1440][resIdx]
                    let (w, h): (Int, Int)
                    switch aspIdx {
                    case 0: (w, h) = (base * 16 / 9, base)
                    case 1: (w, h) = (base, base * 16 / 9)
                    default: (w, h) = (base, base)
                    }
                    guard w != pr.w || h != pr.h else { return }
                    self.pushUndo()
                    pr.w = w
                    pr.h = h
                    self.refreshAll()
                    build()
                }
                let resPick = res
                let aspPick = aspect
                box.addArrangedSubview(chipRow(["720p", "1080p", "1440p"], res) { i in applyDims(i, aspPick) })
                box.addArrangedSubview(chipRow(["16:9", "9:16", "1:1"], aspect) { i in applyDims(resPick, i) })
                let fpsPick = pr.fps >= 50 ? 2 : (pr.fps >= 30 ? 1 : 0)
                text(box, "Frame rate", C.GREEN, 13, true)
                box.addArrangedSubview(chipRow(["24 fps", "30 fps", "60 fps"], fpsPick) { [weak self] i in
                    guard let self = self else { return }
                    self.pushUndo()
                    pr.fps = [24, 30, 60][i]
                    self.onTimeChanged()
                    build()
                })

                // ---- scene setup mode
                text(box, "Scene Setup mode", C.GREEN, 13, true)
                let ss = SwitchRow()
                ss.label = "Orbit with an editing camera"
                ss.captionOn = "On"; ss.captionOff = "Off"
                ss.on = self.sceneSetupOn
                ss.onToggle = { [weak self] v in
                    guard let self = self else { return }
                    self.sceneSetupOn = v
                    self.sceneSetupBtn.set("camera", v ? C.GREEN : C.TEXT)
                }
                put(box, ss, 52)
                text(box, "Drag the preview to orbit the 3D scene and pinch to dolly. Your camera layers are not touched.", C.DIM, 12)

                // ---- guides
                text(box, "Guides", C.GREEN, 13, true)
                let gs = SwitchRow()
                gs.label = "Guides"; gs.on = self.overlay.guides
                gs.onToggle = { [weak self] v in
                    guard let self = self else { return }
                    self.overlay.guides = v
                    self.overlay.setNeedsDisplay()
                }
                put(box, gs, 52)

                // ---- scenes
                text(box, "Scenes", C.GREEN, 13, true)
                var sceneNames = pr.scenes.map { $0.name }
                sceneNames.append("New scene")
                box.addArrangedSubview(chipRow(sceneNames, Editor.sceneIndex) { [weak self] i in
                    guard let self = self else { return }
                    self.pushUndo()
                    if i == pr.scenes.count {
                        pr.scenes.append(Scene("Scene \(pr.scenes.count + 1)"))
                        Editor.sceneIndex = pr.scenes.count - 1
                    } else {
                        Editor.sceneIndex = i
                    }
                    Editor.time = 0
                    self.selId = -1
                    self.panel = P_NONE
                    self.refreshAll()
                    build()
                })
                if pr.scenes.count > 1 {
                    put(box, pill("Delete this scene", nil, C.CARD2, C.RED) { [weak self] in
                        guard let self = self else { return }
                        self.pushUndo()
                        pr.scenes.removeAll { $0 === s }
                        Editor.sceneIndex = 0
                        Editor.time = 0
                        self.selId = -1
                        self.panel = P_NONE
                        self.refreshAll()
                        build()
                    }, 40)
                }
                let d = RulerSlider(frame: .zero)
                d.label = "Duration (s)"; d.lo = 1; d.hi = 120; d.value = s.duration; d.dec = 1; d.canKey = false
                d.onChange = { [weak self] v in
                    guard let self = self else { return }
                    let old = s.duration
                    s.duration = max(1, Float(kotlinRound(v * 2)) / 2)
                    for l in s.layers where l.end >= old - 0.001 { l.end = s.duration }
                    Editor.time = clamp(Editor.time, 0, s.duration)
                    self.onTimeChanged()
                }
                put(box, d, 60, 8, 4)
                let f = RulerSlider(frame: .zero)
                f.label = "Scene FOV"; f.lo = 15; f.hi = 90; f.value = s.fov; f.dec = 0; f.canKey = false
                f.onChange = { [weak self] v in s.fov = v; self?.render() }
                put(box, f, 60)
                text(box, "Background", C.GREEN, 13, true)
                box.addArrangedSubview(wrap(self.colorRow(s.bg) { [weak self] c in
                    s.bg = c
                    self?.render()
                }, 0, 48, 0, 0, 0, 0))
            }
            build()
            dlg.setPositiveButton("Done") { [weak self] _, _ in
                _ = self
                applyName?()
            }.show()
        }

        func showRenderDialog() {
            if playing { togglePlay() }
            Projects.save(projectId, Editor.project)
            let proj = Editor.project
            RenderUi.settings(self, proj) { [weak self] st in
                guard let self = self else { return }
                RenderUi.show(self, proj, st)
            }
        }
}
