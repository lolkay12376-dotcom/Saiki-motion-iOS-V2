// EffectThumbs.swift — before/after thumbnails for the effect browser (Effects).
//
// Renders every effect in the catalog against real sample photos on a
// background GL context, offscreen, then hands UIImages to `cache` — the
// cards pick them up asynchronously. `__orig:<id>` holds the untouched
// sample; `<id>` holds the processed result. Shader problems land in
// Registry.errors with the same pass, so the browser and the SDK IDE show
// one consistent story.
//
// SAMPLES: six real photos, each effect picks one by a STABLE hash (djb2 —
// Swift's hashValue is reseeded every launch, which used to reshuffle the
// cards and mismatch the placeholder vs the rendered thumb):
//   0 — fx_sample_forest.jpg   (the user's redwood-forest photo)
//   1 — fx_sample_portrait.jpg (the user's portrait photo)
//   2 — fx_sample_anime.jpg    (the original app's anime portrait)
//   3 — fx_mountain.jpg        (original)
//   4 — fx_ramen.jpg           (original)
//   5 — fx_woman.jpg           (original)
// (The rebuild had regressed to synthetic gradient "samples" — the shipped
// app always used real photos here.)
//
// PIPELINE FIXES (why previews never showed before): the pass that applies
// the effect used to draw back into the SAME texture it sampled (feedback —
// undefined) right after readImage() had left framebuffer 0 bound (iOS has
// no default framebuffer — the draw went nowhere). It now ping-pongs
// between two targets and rebinds before every draw.

import UIKit
import OpenGLES
import GLKit
import Foundation

enum EffectThumbs {

    static var cache: [String: UIImage] = [:]
    static var lastError = ""

    /// cache is written by the background generation queue — every access
    /// from another thread MUST go through these (a raw Swift Dictionary
    /// read racing a write corrupts the map and crashes; that race ran on
    /// every card redraw while previews generated).
    private static let cacheMutex = NSLock()

    static func thumb(_ id: String) -> UIImage? {
        cacheMutex.lock()
        defer { cacheMutex.unlock() }
        return cache[id]
    }

    static func setThumb(_ id: String, _ img: UIImage?) {
        cacheMutex.lock()
        defer { cacheMutex.unlock() }
        if let img = img { cache[id] = img } else { cache.removeValue(forKey: id) }
    }

    static func removeThumbs(matching id: String) {
        cacheMutex.lock()
        defer { cacheMutex.unlock() }
        cache.removeValue(forKey: id)
        cache.removeValue(forKey: origKey(id))
    }

    /// IDs of custom (non-builtin) thumbs currently cached.
    static func customThumbIds() -> [String] {
        cacheMutex.lock()
        defer { cacheMutex.unlock() }
        return cache.keys.filter { $0.hasPrefix("__orig:custom:") || Registry.byId[$0]?.builtin == false }
    }

    private static let queue = DispatchQueue(label: "saiki.thumbs", qos: .userInitiated)
    private static var generating = false


    static let sampleCount = 6

    static func origKey(_ id: String) -> String { "__orig:" + id }

    static func ready(_ id: String) -> Bool {
        cacheMutex.lock()
        defer { cacheMutex.unlock() }
        return cache[id] != nil
    }

    /// Stable, launch-independent hash (djb2) → 0..sampleCount-1.
    static func sampleIndex(for id: String) -> Int {
        var h: UInt64 = 5381
        for u in id.unicodeScalars { h = (h &* 33) &+ UInt64(u.value) }
        return Int(h % UInt64(sampleCount))
    }

    /// The raw sample image for an effect id (same variant the generation
    /// pass used for it, so before/after cards match).
    static func raw(_ id: String) -> UIImage? {
        sample(String(sampleIndex(for: id)))
    }

    /// Editor spelling: (vc, preview, done).
    static func generate(_ vc: UIViewController, _ preview: PreviewView?,
                         _ done: @escaping () -> Void) {
        generate(done)
    }

    /// SDK IDE spelling: (done).
    static func generate(_ done: @escaping () -> Void) {
        queue.async {
            runGeneration()
            DispatchQueue.main.async(execute: done)
        }
    }

    /// Renders the whole catalog (skips ids already cached).
    private static func runGeneration() {
        guard !generating else { return }
        generating = true
        defer { generating = false }

        guard let ctx = GLContext.make() else {
            lastError = "GL unavailable"
            return
        }
        let prev = EAGLContext.current()
        EAGLContext.setCurrent(ctx)
        defer { EAGLContext.setCurrent(prev) }

        let size = 256
        // ping-pong pair: sample lands in src, effect reads src and writes dst
        let srcTarget = Gl.Target(size, size)
        let dstTarget = Gl.Target(size, size)
        guard let quad = GLProgram(vertex: GLProgram.defaultVertex, fragment: """
precision mediump float;
varying vec2 vUv;
uniform sampler2D uTex;
uniform float uFlipY;
uniform mat3 uMat;
uniform vec2 uQuad;
uniform float uAspect;
void main() {
    vec2 p = vec2(vUv.x, mix(vUv.y, 1.0 - vUv.y, uFlipY));
    vec2 w = (uMat * vec3((vUv - 0.5) * uQuad, 1.0)).xy;
    gl_Position = vec4(w.x / uAspect, w.y, 0.0, 1.0);
    gl_FragColor = texture2D(uTex, p);
}
""") else {
            lastError = "quad shader failed"
            return
        }

        // sample textures (one per variant)
        var sampleTex: [GLuint] = []
        for i in 0..<sampleCount {
            if let t = Gl.upload(sample(String(i))) {
                sampleTex.append(t)
            } else {
                sampleTex.append(0)
            }
        }
        guard sampleTex.contains(where: { $0 != 0 }) else {
            lastError = "sample upload failed"
            return
        }

        // locked catalog snapshot: a concurrent reload on the main thread
        // must never expose a half-rebuilt array to this queue
        let defs = Registry.catalog()
        for def in defs {
            let key = def.id
            if ready(key) { continue }   // locked read (main thread may delete thumbs concurrently)
            // pass-through defs (remap, particles, transform) show the raw sample
            let passThrough = def.kind == 1 || def.glsl.contains("return src(uv);") && def.props.isEmpty
            if passThrough && def.id != "tile" {
                let img = sample(String(sampleIndex(for: key)))
                cacheMutex.lock()
                cache[key] = img
                cache[origKey(def.id)] = img
                cacheMutex.unlock()
                continue
            }

            let (src, _) = Gl.effectShaderSource(def)
            guard let prog = GLProgram(vertex: GLProgram.defaultVertex, fragment: src) else {
                Registry.noteError(def.id, Gl.lastShaderLog)
                continue
            }

            let which = sampleIndex(for: def.id) % max(1, sampleTex.count)
            var inTex = sampleTex[which]
            if inTex == 0 { inTex = sampleTex.first { $0 != 0 } ?? 0 }
            guard inTex != 0 else { continue }

            // 1 — draw the sample into the SOURCE target
            srcTarget.bind()
            glDisable(GLenum(GL_BLEND))
            glViewport(0, 0, GLsizei(size), GLsizei(size))
            quad.use()
            quad.setFloat("uFlipY", 1)
            quad.setMat3("uMat", [1, 0, 0, 0, 1, 0, 0, 0, 1])
            quad.setVec2("uQuad", 2, 2)
            quad.setFloat("uAspect", 1)
            quad.setTexture("uTex", inTex, 0)
            Gl.drawQuad(quad)

            let before = srcTarget.readImage()

            // 2 — apply the effect into the DESTINATION target (reads src,
            //     writes dst — never the same texture)
            dstTarget.bind()
            glDisable(GLenum(GL_BLEND))
            glViewport(0, 0, GLsizei(size), GLsizei(size))
            prog.use()
            prog.setTexture("uTex", srcTarget.tex, 0)
            prog.setVec2("uRes", Float(size), Float(size))
            prog.setFloat("uTime", 1.7)
            prog.setFloat("uHas0", 0)
            prog.setFloat("uHas1", 0)
            for pd in def.props {
                prog.setFloat(pd.key, pd.def)
            }
            for cp in def.colors {
                let d = UInt32(bitPattern: cp.def)
                prog.setVec4(cp.key,
                             Float((d >> 16) & 0xFF) / 255,
                             Float((d >> 8) & 0xFF) / 255,
                             Float(d & 0xFF) / 255,
                             Float((d >> 24) & 0xFF) / 255)
            }
            Gl.drawQuad(prog)

            let after = dstTarget.readImage()

            cacheMutex.lock()
            if let b = before { cache[origKey(def.id)] = b }
            if let a = after { cache[def.id] = a }
            cacheMutex.unlock()
        }

        // free the sample textures and targets while this context is still
        // current (the old code's scope-exit order could run these with the
        // context already unbound — a silent leak per generation). The names
        // are zeroed so the objects' deinit cannot double-delete them later.
        for t in sampleTex where t != 0 { Gl.delete(t) }
        Gl.delete(srcTarget.tex); srcTarget.tex = 0
        glDeleteFramebuffers(1, [srcTarget.fbo]); srcTarget.fbo = 0
        Gl.delete(dstTarget.tex); dstTarget.tex = 0
        glDeleteFramebuffers(1, [dstTarget.fbo]); dstTarget.fbo = 0
    }

    // MARK: - sample images
    //
    // Deterministic cards on every install: two real photos shipped in the
    // bundle (the redwood forest and the portrait), plus two generated
    // scenes with strong highlights/shadows (good for glow / keying / color
    // effects). Effects pick their variant by stable hash, so the mix is
    // stable but varied.

    private static var sampleImages: [String: UIImage] = [:]
    private static let sampleLock = NSLock()

    static func sample(_ variant: String) -> UIImage {
        sampleLock.lock()
        if let img = sampleImages[variant] {
            sampleLock.unlock()
            return img
        }
        sampleLock.unlock()
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 1
        let v = Int(variant.last?.wholeNumberValue ?? 0) % sampleCount
        // the photo pool — the two user-supplied photos first, then the
        // sample photos the original app shipped (all square 384px jpgs
        // in Resources/img, copied to the app bundle root)
        let pool = ["fx_sample_forest", "fx_sample_portrait", "fx_sample_anime",
                    "fx_mountain", "fx_ramen", "fx_woman"]
        let name = pool[v]
        var img: UIImage
        if let bundled = UIImage(named: name) ?? UIImage(contentsOfFile:
            (Bundle.main.resourcePath ?? "").appending("/\(name).jpg")) {
            img = bundled
        } else {
            img = generated(v: v, n: 384, fmt: fmt)   // graceful fallback
        }
        sampleLock.lock()
        sampleImages[variant] = img
        sampleLock.unlock()
        return img
    }

    private static func generated(v: Int, n: Int, fmt: UIGraphicsImageRendererFormat) -> UIImage {
        let r = UIGraphicsImageRenderer(size: CGSize(width: n, height: n), format: fmt)
        return r.image { ctx in
            let c = ctx.cgContext
            if v == 2 {
                // dusk hills
                let sky = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(),
                                     colors: [UIColor(red: 1.0, green: 0.62, blue: 0.35, alpha: 1).cgColor,
                                              UIColor(red: 0.23, green: 0.16, blue: 0.42, alpha: 1).cgColor] as CFArray,
                                     locations: [0, 1])!
                c.drawLinearGradient(sky, start: .zero, end: CGPoint(x: 0, y: CGFloat(n)), options: [])
                c.setFillColor(UIColor(red: 1, green: 0.9, blue: 0.6, alpha: 1).cgColor)
                c.fillEllipse(in: CGRect(x: CGFloat(n) * 0.62, y: CGFloat(n) * 0.22, width: 46, height: 46))
                c.setFillColor(UIColor(red: 0.12, green: 0.1, blue: 0.2, alpha: 1).cgColor)
                c.move(to: CGPoint(x: 0, y: CGFloat(n) * 0.72))
                c.addLine(to: CGPoint(x: CGFloat(n) * 0.35, y: CGFloat(n) * 0.5))
                c.addLine(to: CGPoint(x: CGFloat(n) * 0.62, y: CGFloat(n) * 0.76))
                c.addLine(to: CGPoint(x: CGFloat(n), y: CGFloat(n) * 0.6))
                c.addLine(to: CGPoint(x: CGFloat(n), y: CGFloat(n)))
                c.addLine(to: CGPoint(x: 0, y: CGFloat(n)))
                c.closePath()
                c.fillPath()
                c.setFillColor(UIColor.black.withAlphaComponent(0.35).cgColor)
                c.fill(CGRect(x: 0, y: CGFloat(n) * 0.86, width: CGFloat(n), height: CGFloat(n) * 0.14))
            } else {
                // still life blocks
                let g = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(),
                                   colors: [UIColor(red: 0.1, green: 0.12, blue: 0.16, alpha: 1).cgColor,
                                            UIColor(red: 0.24, green: 0.28, blue: 0.34, alpha: 1).cgColor] as CFArray,
                                   locations: [0, 1])!
                c.drawLinearGradient(g, start: .zero, end: CGPoint(x: CGFloat(n), y: CGFloat(n)), options: [])
                let cols: [UIColor] = [UIColor(red: 0.95, green: 0.3, blue: 0.32, alpha: 1),
                                       UIColor(red: 0.98, green: 0.75, blue: 0.2, alpha: 1),
                                       UIColor(red: 0.25, green: 0.65, blue: 0.9, alpha: 1),
                                       UIColor(red: 0.4, green: 0.85, blue: 0.55, alpha: 1)]
                let rects = [CGRect(x: 30, y: 60, width: 110, height: 110),
                             CGRect(x: 160, y: 40, width: 90, height: 140),
                             CGRect(x: 80, y: 170, width: 160, height: 100),
                             CGRect(x: 210, y: 180, width: 70, height: 70)]
                for (i, rc) in rects.enumerated() {
                    c.setFillColor(cols[i % cols.count].cgColor)
                    c.fill(rc)
                }
            }
        }
    }

    /// Sample image by any hashable seed (stable within one run).
    static func sampleAt(_ seed: Int) -> UIImage {
        sample(String(abs(seed) % sampleCount))
    }

    /// Drops cached thumbs (effect edited / deleted).
    static func invalidate() {
        cacheMutex.lock()
        cache.removeAll()
        cacheMutex.unlock()
    }
}
