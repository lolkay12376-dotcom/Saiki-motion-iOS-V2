// VideoFrames.swift — video layer frame sampling (Render).
//
// AVAssetImageGenerator at 1/10 s buckets: the preview asks for the frame at
// the playhead; a serial background queue decodes it asynchronously while
// the previous texture keeps showing (no main-thread stalls — the R12/R14
// lesson).
//
// THREADING RULE (the "video layers never appear" fix): decoding happens on
// the sampler's queue, but the GL upload happens ONLY inside
// SceneRenderer.draw — i.e. on the thread that owns the current EAGLContext.
// The old code uploaded on the main thread from a DispatchWorkItem where no
// context was guaranteed to be current, so glGenTextures returned 0 and the
// frame was silently dropped, forever.

import Foundation
import AVFoundation
import OpenGLES
import GLKit
import UIKit

enum VideoFrames {

    private static var assets: [String: AVURLAsset] = [:]
    private static let assetsLock = NSLock()

    static func asset(_ path: String) -> AVURLAsset {
        assetsLock.lock()
        defer { assetsLock.unlock() }
        if let a = assets[path] { return a }
        let a = AVURLAsset(url: URL(fileURLWithPath: path))
        if assets.count > 12, let first = assets.keys.first {
            assets.removeValue(forKey: first)
        }
        assets[path] = a
        return a
    }

    static func videoSize(_ path: String) -> (Int, Int)? {
        guard let track = asset(path).tracks(withMediaType: .video).first else { return nil }
        let s = track.naturalSize.applying(track.preferredTransform)
        return (abs(Int(s.width)), abs(Int(s.height)))
    }

    static func duration(_ path: String) -> Float {
        Float(CMTimeGetSeconds(asset(path).duration))
    }

    // MARK: - sampler

    final class Sampler {
        let path: String
        let synchronous: Bool
        /// Async mode: fired on the GL thread after a fresh frame uploads.
        var onUploaded: (() -> Void)? = nil
        private var generator: AVAssetImageGenerator?
        private let queue: DispatchQueue?
        private var pendingBucket = -1
        private var tex: GLuint = 0
        private var bucket = -1
        private(set) var size = (1, 1)

        /// The freshly decoded frame (+ its bucket), handed from the decode
        /// queue to the GL thread. Guarded by `lock`.
        private var pendingImage: UIImage? = nil
        private var pendingBucketImg = -1
        private let lock = NSLock()

        init(path: String, synchronous: Bool = false) {
            self.path = path
            self.synchronous = synchronous
            let asset = VideoFrames.asset(path)
            let g = AVAssetImageGenerator(asset: asset)
            g.appliesPreferredTrackTransform = true
            g.requestedTimeToleranceBefore = CMTime(seconds: 0.05, preferredTimescale: 600)
            g.requestedTimeToleranceAfter = CMTime(seconds: 0.05, preferredTimescale: 600)
            generator = g
            if synchronous {
                queue = nil
            } else {
                queue = DispatchQueue(label: "saiki.video.\(path.hashValue)")
            }
            if let s = VideoFrames.videoSize(path) { size = s }
        }

        deinit {
            // Textures belong to the GL context/thread that created them;
            // deleting here would run on the wrong thread. A leaked id per
            // sampler is preferable to a cross-context delete.
        }

        /// The frame at `srcTime` (seconds into the source) as a texture id.
        /// MUST be called with the GL context current (from the renderer).
        /// Async mode: returns the last uploaded frame while a fresh one
        /// decodes; the upload of the decoded image happens right here, on
        /// the GL thread.
        func texture(at srcTime: Float) -> GLuint {
            let b = Int(max(0, srcTime) * 10)
            // 1 — a decoded frame may be waiting: upload it HERE, where the
            // GL context is current. This is the whole point of the handoff.
            drainPending()
            if b == bucket, tex != 0 { return tex }
            if synchronous {
                generate(srcTime, bucket: b)
                return tex
            }
            if b == pendingBucket { return tex }
            pendingBucket = b
            let q = queue
            let gen = generator
            if let q = q, let gen = gen {
                q.async { [weak self] in
                    guard let self = self else { return }
                    self.generate(srcTime, bucket: b)
                }
            }
            return tex
        }

        private func generate(_ t: Float, bucket b: Int) {
            guard let gen = generator else { return }
            let cm = CMTime(seconds: Double(max(0, t)), preferredTimescale: 600)
            guard let img = try? gen.copyCGImage(at: cm, actualTime: nil) else { return }
            if synchronous {
                // Exporter thread owns its GL context and calls us directly.
                uploadAndSwap(UIImage(cgImage: img), bucket: b)
            } else {
                // Hand the decoded frame to the GL thread; it uploads on the
                // next texture(at:) call (context guaranteed current).
                lock.lock()
                pendingImage = UIImage(cgImage: img)
                pendingBucketImg = b
                lock.unlock()
                let cb = onUploaded
                DispatchQueue.main.async {
                    cb?()   // triggers setNeedsDisplay → draw → texture(at:)
                }
            }
        }

        /// GL-thread side of the handoff. Called only from texture(at:) —
        /// i.e. inside SceneRenderer.draw with the context current.
        private func drainPending() {
            lock.lock()
            let img = pendingImage
            let b = pendingBucketImg
            pendingImage = nil
            pendingBucketImg = -1
            lock.unlock()
            if let img = img, b >= 0 {
                uploadAndSwap(img, bucket: b)
            }
        }

        private func uploadAndSwap(_ ui: UIImage, bucket b: Int) {
            if let newTex = Gl.upload(ui) {
                if tex != 0 { Gl.delete(tex) }
                tex = newTex
                self.bucket = b
                pendingBucket = -1
            }
        }

        var current: GLuint {
            drainPending()
            return tex
        }
    }
}
