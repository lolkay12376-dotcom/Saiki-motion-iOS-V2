// AppInfo.swift — version identity (round 18's lesson).
//
// In every binary build we shipped, CFBundleShortVersionString stayed "1.5",
// so LiveContainer's app list could never tell one build from the next — the
// phone kept "updating" onto itself and we chased ghosts for three rounds.
// In source form the rule is: ONE place defines the version, and Info.plist
// reads from the build; both CFBundleShortVersionString and CFBundleVersion
// change on every release.

import Foundation

enum AppInfo {
    /// Marketing version. Keep in lockstep with Info.plist.
    static let version = "1.5.33fix1"
    /// Build number. Bump on EVERY build (this is what LC compares).
    static let build = 45
    /// Bundle identifier of the side-loaded app.
    static let bundleId = "com.saiki.motion.app"

    /// Display string for the Account/About tab.
    static var displayVersion: String { "\(version) (\(build))" }
}
