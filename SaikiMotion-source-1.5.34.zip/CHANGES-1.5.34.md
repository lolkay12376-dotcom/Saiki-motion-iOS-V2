# SaikiMotion 1.5.34 (build 46) — "the freeze, and what 1.5.33 destroyed"

## What happened (honest changelog)

1.5.33 was built from a stale copy of the source instead of the current repo,
so every change that existed only in the repo — the reworked timeline look
(MM:SS:FF timecodes, integer-second ruler labels, clip badges), the renamed
Particle World effect and its built-in `ParticularPresets.swift` — was wiped
when that zip was pushed. This release rebuilds those from the last working
build's screenshots, fixes a freeze that 1.5.33 itself introduced, and keeps
the orange accent. **Going forward the repo is always the base — nothing in
it gets overwritten by a delivery.**

## The freeze (introduced in 1.5.33, fixed here)

`Registry.validateProgram(for:)` took the Registry lock and returned early
on the "already checked" path **without unlocking**. After any SDK reload
(opening the effect editor and returning, importing or deleting an effect,
pressing Run in the IDE), that path fired for every already-validated
effect, the lock stayed held forever, and the next main-thread
`def()`/`catalog()` call blocked for good — the FreezeWatchdog then killed
the app ~6 seconds later. That is the "app freezes then dies" of the last
build. The lock is now always released before the early return.

## Timeline — the fork's look, restored

- Timecodes are **MM:SS:FF** everywhere (playhead pill `00:01:12`, top bar
  `00:01:12 / 00:05:00`) — was `0:00.00`.
- Ruler labels are plain **integer seconds** ("1", "2", "3") when the grid
  step is whole seconds; full MM:SS:FF when zoomed out to sub-second steps.
- A thin **orange accent line runs along the top edge** of the timeline.
- Clip pills carry the layer **name + duration + "fxN" badge**
  (e.g. `Particles 1  5.0s  [fx1]`), left-aligned like the fork drew them.
- Selection ring is **white** (visible on every pill color); the right trim
  grip is an **"=" drag-stretch affordance**, the left one a vertical bar.
- Selected-row wash is a warm dark tint that matches the orange accent
  (was a green-tinted wash from the green era).
- Group expander chevron points up while expanded, down while collapsed.
- The play button is white while paused and orange while playing, and the
  play group's pill is warm-tinted instead of green-tinted.

## Particle World + built-in presets (the fork's feature, rebuilt)

- The "Particles" effect is renamed **"Particle World"** (display name only —
  the id stays `particles`, so saved projects are unaffected).
- New `Sources/Effects/ParticularPresets.swift`: ten built-in one-tap
  particle set-ups in **Effects > Presets** — Snow, Rain, Fire Embers,
  Sparks, Bubbles, Starfield, Confetti, Fireflies, Smoke, Magic Dust.
  They live only in code (never written to presets.json, no Delete button);
  a user preset saved with the same name takes over that slot.

## What is NOT in this release (being honest)

The fork also carried functional edits to `Anim.swift`, `Layer.swift` and
`Particles.swift` (visible only as compile errors in the CI logs). Those
files' exact contents were never delivered here and could not be
reconstructed from screenshots. **If the repo's git history still has the
fork's commits, that code is recoverable — restore it and these fixes will
be merged into it instead.**

## Also

- Everything from 1.5.33 / 1.5.33fix1 is retained: the green-viewport fix
  (`bindDrawable()`), the CG pixel-copy memory-safety fixes, per-context GL
  VBO cache, thread-safe thumbnail/registry access, real sample photos,
  visible shapes (`uQuadSize`), working video layers, the orange accent.
