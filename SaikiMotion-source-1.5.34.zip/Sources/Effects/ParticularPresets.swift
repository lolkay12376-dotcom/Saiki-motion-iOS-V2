// ParticularPresets.swift — built-in Particle World presets.
//
// 1.5.34 — RESTORED FEATURE. The repo's fork carried a file with this name
// (ten built-in particle presets, visible in the Effects > Presets tab); it
// was wiped when 1.5.33 was delivered from a stale tree. This is a fresh
// implementation with the same purpose: one-tap, ready-made particle set-ups
// for the "Particle World" effect, listed FIRST in the Presets tab with the
// "(built in)" tag. They live only in code — never written to presets.json —
// and cannot collide with user presets (saving a user preset with the same
// name no longer removes the built-in).
//
// Every preset targets the single-instance "particles" effect (kind 1) and
// stores static parameter tracks in the exact shape Registry.applyPreset
// consumes: {"fx":[{"id":"particles","tracks":{<key>:{"base":<v>},...,
// <color>:{"_r":...,"_g":...,"_b":...,"_a":...}}}]}.

import Foundation

enum ParticularPresets {

    /// The built-in preset list (order = display order in the Presets tab).
    static let all: [Preset] = build()

    // MARK: - helpers

    /// A static-value track (the shape Track.load reads).
    private static func track(_ v: Double) -> JObj {
        JObj().put("base", v)
    }

    /// A color track group from an 0xAARRGGBB literal (components are 0...1).
    private static func color(_ argb: UInt64) -> JObj {
        JObj()
            .put("_r", track(Double((argb >> 16) & 0xFF) / 255.0))
            .put("_g", track(Double((argb >> 8) & 0xFF) / 255.0))
            .put("_b", track(Double(argb & 0xFF) / 255.0))
            .put("_a", track(Double((argb >> 24) & 0xFF) / 255.0))
    }

    /// One Particle World preset: static values for every parameter, so the
    /// effect is fully defined no matter what the layer carried before.
    private static func preset(_ name: String,
                               count: Double, size: Double, spread: Double,
                               speed: Double, gravity: Double, life: Double,
                               seed: Double, dirX: Double, dirY: Double,
                               showSrc: Double,
                               birth: UInt64, death: UInt64) -> Preset {
        let tracks = JObj()
            .put("pCount", track(count))
            .put("pSize", track(size))
            .put("pSpread", track(spread))
            .put("pSpeed", track(speed))
            .put("pGravity", track(gravity))
            .put("pLife", track(life))
            .put("pSeed", track(seed))
            .put("pDirX", track(dirX))
            .put("pDirY", track(dirY))
            .put("pShowSrc", track(showSrc))
            .put("pColA", color(birth))
            .put("pColB", color(death))
        let fx = JArr().put(JObj().put("id", "particles").put("tracks", tracks))
        return Preset(name: name, builtin: true, json: JObj().put("name", name).put("fx", fx))
    }

    // MARK: - the presets

    private static func build() -> [Preset] {
        var out: [Preset] = []
        //                    name        count size  spread speed grav life seed dirX  dirY  src  birth       death
        out.append(preset("Snow",        count: 220, size: 0.012, spread: 2.0, speed: 0.18, gravity:  0.12, life: 7,   seed: 7,  dirX:  0.05, dirY: -0.40, showSrc: 0, birth: 0xFFFFFFFF, death: 0xFFB8C8E4))
        out.append(preset("Rain",        count: 320, size: 0.008, spread: 1.6, speed: 1.40, gravity:  0.50, life: 3,   seed: 11, dirX:  0.00, dirY: -1.00, showSrc: 0, birth: 0xFFD8E8F8, death: 0xFF7A9EC4))
        out.append(preset("Fire Embers", count: 140, size: 0.020, spread: 0.8, speed: 0.50, gravity: -0.35, life: 2.5, seed: 3,  dirX:  0.10, dirY:  0.60, showSrc: 0, birth: 0xFFFFD24A, death: 0xFFFF3D0A))
        out.append(preset("Sparks",      count: 90,  size: 0.015, spread: 1.2, speed: 1.80, gravity: -0.80, life: 1.2, seed: 5,  dirX:  0.00, dirY:  0.80, showSrc: 0, birth: 0xFFFFFFFF, death: 0xFFFF8A1F))
        out.append(preset("Bubbles",     count: 80,  size: 0.030, spread: 1.8, speed: 0.35, gravity: -0.15, life: 6,   seed: 9,  dirX:  0.08, dirY:  0.70, showSrc: 0, birth: 0xFFD8F2FF, death: 0xFF60A8D8))
        out.append(preset("Starfield",   count: 260, size: 0.008, spread: 3.0, speed: 0.02, gravity:  0.00, life: 10,  seed: 42, dirX:  0.00, dirY:  0.00, showSrc: 0, birth: 0xFFFFFFFF, death: 0xFF9AA8C8))
        out.append(preset("Confetti",    count: 160, size: 0.020, spread: 2.6, speed: 1.00, gravity:  0.70, life: 4,   seed: 21, dirX:  0.00, dirY: -0.60, showSrc: 0, birth: 0xFFFF6EB0, death: 0xFF5AD0E0))
        out.append(preset("Fireflies",   count: 40,  size: 0.025, spread: 2.8, speed: 0.12, gravity:  0.00, life: 9,   seed: 17, dirX:  0.30, dirY:  0.20, showSrc: 0, birth: 0xFFE2FF9A, death: 0xFF3A5A10))
        out.append(preset("Smoke",       count: 60,  size: 0.060, spread: 1.0, speed: 0.30, gravity: -0.25, life: 6,   seed: 13, dirX:  0.12, dirY:  0.50, showSrc: 0, birth: 0xFFC8C8D0, death: 0xFF28282E))
        out.append(preset("Magic Dust",  count: 180, size: 0.010, spread: 2.4, speed: 0.25, gravity: -0.10, life: 5,   seed: 29, dirX: -0.10, dirY:  0.30, showSrc: 0, birth: 0xFFE8C0FF, death: 0xFF7A55C9))
        return out
    }
}
