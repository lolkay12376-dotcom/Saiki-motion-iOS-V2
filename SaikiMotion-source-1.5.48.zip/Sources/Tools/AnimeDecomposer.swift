// AnimeDecomposer.swift — on-device anime character decomposition (Tools tab).
//
// Splits a character illustration into editable, auto-grouped parts: face skin,
// eyes, eyelids, eyebrows, mouth, hair (optionally strand by strand), neck, arms,
// legs, clothes, accessories and line art. Everything runs on the phone — no
// network, no model download.
//
//   1. cut-out           plain-colour flood fill and/or Apple's on-device subject
//                        mask (iOS 17), holes filled, soft edge
//   2. line art          thin dark strokes found by local contrast; thick dark
//                        areas (black hair, dark clothes) stay fills
//   3. colour regions    edge-preserving denoise → k-means in Lab → majority filter
//                        → connected pieces → tiny pieces merged into neighbours
//   4. understanding     face found from the biggest skin region, chin from the
//                        width profile; eyes / mouth / brows from position inside
//                        the face; hair from the head box + colour palette;
//                        neck, arms, legs, clothes from what is left
//   5. layers            disjoint cropped RGBA bitmaps (composite == source) with a
//                        little hidden "underlap" so moving a part never shows a hole
//   6. groups            Head / Hair / Body / Clothes / Accessories / Line art
//
// Pure data in, pure data out: the view controller owns all UI.

import UIKit
import Foundation
import Vision
import CoreVideo

// MARK: - public types ------------------------------------------------------------

struct DecomposeOptions {
    // quality preset 0 Fast · 1 Balanced · 2 High · 3 Ultra — sets resolution + effort
    var quality = 2
    var maxSide = 1600               // working resolution (longest side)
    var detail = 6                   // 1...10 — how many colour regions (more = finer parts)
    var smoothing = 1                // 0...3 majority-filter passes
    var lineSensitivity = 2          // 1...3 — how readily thin dark strokes count as line art
    var lineMode = 0                 // 0 merge into parts · 1 one "Line art" layer · 2 line art per part
    var removeBackground = true
    var keepBackground = false
    var splitFace = true             // eyes, eyelids, eyebrows, mouth as their own layers
    var hairStrands = true           // hair pieces become separate layers
    var strandLimit = 24             // 4...60
    var splitBody = true             // neck, arms, legs separate
    var splitClothes = true          // garments separate
    var autoGroup = true             // Head / Hair / Body / Clothes … groups
    var useAI = false                // ISNet anime model for the cut-out when installed
    var fillGaps = true              // hidden underlap so parts can move without holes

    static func preset(_ q: Int) -> (maxSide: Int, detail: Int) {
        switch q {
        case 0: return (1024, 4)
        case 1: return (1400, 5)
        case 3: return (2304, 9)
        default: return (1600, 6)
        }
    }
}

struct DecomposedLayer {
    var name: String
    var x: Int
    var y: Int
    var w: Int
    var h: Int
    var rgba: [UInt8]                // w*h*4, un-premultiplied, cropped to the box
    var visible = true
    var area: Int
    var group = ""                   // "" = ungrouped
    var order = 0                    // stacking hint, low = bottom
}

struct DecomposeResult {
    var width: Int
    var height: Int
    var layers: [DecomposedLayer]
}


final class CancelToken {
    private let lock = NSLock()
    private var flag = false
    func cancel() { lock.lock(); flag = true; lock.unlock() }
    var isCancelled: Bool { lock.lock(); defer { lock.unlock() }; return flag }
}

// MARK: - engine --------------------------------------------------------------------

enum AnimeDecomposer {

    // MARK: pixels in / out

    /// Draws the image into an un-premultiplied RGBA buffer, longest side <= maxSide
    /// (never upscaled). Orientation is applied.
    static func loadPixels(_ image: UIImage, maxSide: Int) -> (w: Int, h: Int, rgba: [UInt8])? {
        let sw = image.size.width * image.scale
        let sh = image.size.height * image.scale
        guard sw > 0, sh > 0 else { return nil }
        let k = min(1, CGFloat(maxSide) / max(sw, sh))
        let w = max(1, Int((sw * k).rounded()))
        let h = max(1, Int((sh * k).rounded()))
        var buf = [UInt8](repeating: 0, count: w * h * 4)
        var ok = false
        buf.withUnsafeMutableBytes { raw in
            guard let base = raw.baseAddress,
                  let ctx = CGContext(data: base, width: w, height: h, bitsPerComponent: 8,
                                      bytesPerRow: w * 4,
                                      space: CGColorSpace(name: CGColorSpace.sRGB) ?? CGColorSpaceCreateDeviceRGB(),
                                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)
            else { return }
            ctx.interpolationQuality = .high
            ctx.translateBy(x: 0, y: CGFloat(h))
            ctx.scaleBy(x: 1, y: -1)
            UIGraphicsPushContext(ctx)
            image.draw(in: CGRect(x: 0, y: 0, width: w, height: h))
            UIGraphicsPopContext()
            ok = true
        }
        guard ok else { return nil }
        // un-premultiply
        var i = 0
        let total = w * h * 4
        while i < total {
            let a = Int(buf[i + 3])
            if a > 0 && a < 255 {
                buf[i] = UInt8(min(255, Int(buf[i]) * 255 / a))
                buf[i + 1] = UInt8(min(255, Int(buf[i + 1]) * 255 / a))
                buf[i + 2] = UInt8(min(255, Int(buf[i + 2]) * 255 / a))
            }
            i += 4
        }
        return (w, h, buf)
    }

    /// RGBA (un-premultiplied) → UIImage.
    static func image(from rgba: [UInt8], width w: Int, height h: Int) -> UIImage? {
        guard w > 0, h > 0, rgba.count >= w * h * 4 else { return nil }
        let data = Data(rgba) as CFData
        guard let provider = CGDataProvider(data: data),
              let cg = CGImage(width: w, height: h, bitsPerComponent: 8, bitsPerPixel: 32,
                               bytesPerRow: w * 4,
                               space: CGColorSpace(name: CGColorSpace.sRGB) ?? CGColorSpaceCreateDeviceRGB(),
                               bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.last.rawValue),
                               provider: provider, decode: nil, shouldInterpolate: true,
                               intent: .defaultIntent)
        else { return nil }
        return UIImage(cgImage: cg, scale: 1, orientation: .up)
    }

    /// One layer placed on a full, transparent canvas.
    static func fullCanvas(_ layer: DecomposedLayer, width w: Int, height h: Int) -> [UInt8] {
        var out = [UInt8](repeating: 0, count: w * h * 4)
        for row in 0..<layer.h {
            let dy = layer.y + row
            if dy < 0 || dy >= h { continue }
            for col in 0..<layer.w {
                let dx = layer.x + col
                if dx < 0 || dx >= w { continue }
                let s = (row * layer.w + col) * 4
                let d = (dy * w + dx) * 4
                out[d] = layer.rgba[s]; out[d + 1] = layer.rgba[s + 1]
                out[d + 2] = layer.rgba[s + 2]; out[d + 3] = layer.rgba[s + 3]
            }
        }
        return out
    }

    /// Visible layers painted bottom → top ("over" with straight alpha).
    static func composite(_ layers: [DecomposedLayer], width w: Int, height h: Int) -> [UInt8] {
        var out = [UInt8](repeating: 0, count: w * h * 4)
        for layer in layers where layer.visible {
            for row in 0..<layer.h {
                let dy = layer.y + row
                if dy < 0 || dy >= h { continue }
                for col in 0..<layer.w {
                    let dx = layer.x + col
                    if dx < 0 || dx >= w { continue }
                    let s = (row * layer.w + col) * 4
                    let sa = Int(layer.rgba[s + 3])
                    if sa == 0 { continue }
                    let d = (dy * w + dx) * 4
                    let da = Int(out[d + 3])
                    if sa == 255 || da == 0 {
                        out[d] = layer.rgba[s]; out[d + 1] = layer.rgba[s + 1]
                        out[d + 2] = layer.rgba[s + 2]; out[d + 3] = UInt8(sa)
                    } else {
                        let fs = Float(sa) / 255, fd = Float(da) / 255
                        let oa = fs + fd * (1 - fs)
                        for c in 0..<3 {
                            let v = (Float(layer.rgba[s + c]) * fs + Float(out[d + c]) * fd * (1 - fs)) / oa
                            out[d + c] = UInt8(max(0, min(255, v)))
                        }
                        out[d + 3] = UInt8(max(0, min(255, oa * 255)))
                    }
                }
            }
        }
        return out
    }

    // MARK: colour

    private static let lin: [Float] = (0..<256).map { i -> Float in
        let c = Float(i) / 255
        return c <= 0.04045 ? c / 12.92 : powf((c + 0.055) / 1.055, 2.4)
    }

    @inline(__always) private static func labF(_ t: Float) -> Float {
        t > 0.008856 ? cbrtf(t) : (7.787 * t + 16.0 / 116.0)
    }

    private static func toLab(_ src: UnsafePointer<UInt8>, _ n: Int,
                              _ L: UnsafeMutablePointer<Float>,
                              _ A: UnsafeMutablePointer<Float>,
                              _ B: UnsafeMutablePointer<Float>) {
        lin.withUnsafeBufferPointer { lut in
            for i in 0..<n {
                let r = lut[Int(src[i * 4])]
                let g = lut[Int(src[i * 4 + 1])]
                let b = lut[Int(src[i * 4 + 2])]
                let x = (0.4124 * r + 0.3576 * g + 0.1805 * b) / 0.95047
                let y = 0.2126 * r + 0.7152 * g + 0.0722 * b
                let z = (0.0193 * r + 0.1192 * g + 0.9505 * b) / 1.08883
                let fx = labF(x), fy = labF(y), fz = labF(z)
                L[i] = 116 * fy - 16
                A[i] = 500 * (fx - fy)
                B[i] = 200 * (fy - fz)
            }
        }
    }

    // MARK: connected components

    private static func components(_ mask: UnsafePointer<UInt8>, _ w: Int, _ h: Int, eight: Bool)
        -> (ids: [Int32], areas: [Int], boxes: [(Int, Int, Int, Int)]) {
        let n = w * h
        var ids = [Int32](repeating: -1, count: n)
        var areas: [Int] = []
        var boxes: [(Int, Int, Int, Int)] = []
        var stack: [Int32] = []
        for s in 0..<n where mask[s] != 0 && ids[s] < 0 {
            let cid = Int32(areas.count)
            ids[s] = cid
            stack.append(Int32(s))
            var area = 0
            var bx0 = w, by0 = h, bx1 = -1, by1 = -1
            while let cur32 = stack.popLast() {
                let cur = Int(cur32)
                let x = cur % w, y = cur / w
                area += 1
                if x < bx0 { bx0 = x }
                if x > bx1 { bx1 = x }
                if y < by0 { by0 = y }
                if y > by1 { by1 = y }
                for dy in -1...1 {
                    for dx in -1...1 {
                        if dx == 0 && dy == 0 { continue }
                        if !eight && dx != 0 && dy != 0 { continue }
                        let nx = x + dx, ny = y + dy
                        if nx < 0 || ny < 0 || nx >= w || ny >= h { continue }
                        let j = ny * w + nx
                        if mask[j] != 0 && ids[j] < 0 {
                            ids[j] = cid
                            stack.append(Int32(j))
                        }
                    }
                }
            }
            areas.append(area)
            boxes.append((bx0, by0, bx1, by1))
        }
        return (ids, areas, boxes)
    }

    // MARK: - helpers --------------------------------------------------------------

    private enum Part { case none, face, eyes, eyebrows, mouth, hair, body, cloth, acc }

    private struct Reg {
        var area = 0
        var l: Float = 0, a: Float = 0, b: Float = 0          // mean Lab
        var r: Float = 0, g: Float = 0, bl: Float = 0         // mean RGB
        var x0 = Int.max, y0 = Int.max, x1 = -1, y1 = -1
        var cx: Float = 0, cy: Float = 0
        var part: Part = .none
        var skin = false
    }

    private struct LDef {
        var name: String
        var group: String
        var order: Int
    }

    private static func skinTone(_ r: Float, _ g: Float, _ b: Float) -> Bool {
        let cb = 128 - 0.168736 * r - 0.331264 * g + 0.5 * b
        let cr = 128 + 0.5 * r - 0.418688 * g - 0.081312 * b
        return cb >= 70 && cb <= 130 && cr >= 131 && cr <= 180
            && r >= 120 && r >= g && g >= b * 0.85 && (r - b) >= 12
    }

    private static func labDist(_ l1: Float, _ a1: Float, _ b1: Float,
                                _ l2: Float, _ a2: Float, _ b2: Float) -> Float {
        let x = l1 - l2, y = a1 - a2, z = b1 - b2
        return sqrtf(x * x + y * y + z * z)
    }

    /// Integral image of a 0/1 mask (Int32), (w+1)*(h+1).
    private static func integral(_ m: [UInt8], _ w: Int, _ h: Int) -> [Int32] {
        let w1 = w + 1
        var out = [Int32](repeating: 0, count: (w + 1) * (h + 1))
        for y in 0..<h {
            var row: Int32 = 0
            for x in 0..<w {
                row += Int32(m[y * w + x])
                out[(y + 1) * w1 + x + 1] = out[y * w1 + x + 1] + row
            }
        }
        return out
    }

    /// Morphological opening with a (2t+1) square: what survives is "thick".
    private static func opening(_ m: [UInt8], _ w: Int, _ h: Int, _ t: Int) -> [UInt8] {
        let n = w * h
        let w1 = w + 1
        var integ = integral(m, w, h)
        var eroded = [UInt8](repeating: 0, count: n)
        for y in 0..<h {
            let ya = max(0, y - t), yb = min(h - 1, y + t)
            for x in 0..<w where m[y * w + x] != 0 {
                let xa = max(0, x - t), xb = min(w - 1, x + t)
                let s = integ[(yb + 1) * w1 + xb + 1] - integ[ya * w1 + xb + 1]
                    - integ[(yb + 1) * w1 + xa] + integ[ya * w1 + xa]
                if Int(s) == (xb - xa + 1) * (yb - ya + 1) { eroded[y * w + x] = 1 }
            }
        }
        integ = integral(eroded, w, h)
        var out = [UInt8](repeating: 0, count: n)
        for y in 0..<h {
            let ya = max(0, y - t), yb = min(h - 1, y + t)
            for x in 0..<w {
                let xa = max(0, x - t), xb = min(w - 1, x + t)
                let s = integ[(yb + 1) * w1 + xb + 1] - integ[ya * w1 + xb + 1]
                    - integ[(yb + 1) * w1 + xa] + integ[ya * w1 + xa]
                if s > 0 { out[y * w + x] = 1 }
            }
        }
        return out
    }

    // MARK: - 1 cut-out ---------------------------------------------------------------

    /// Apple's on-device subject mask (iOS 17+). nil when unavailable or implausible.
    private static func visionMask(_ px: [UInt8], _ w: Int, _ h: Int) -> [UInt8]? {
        guard #available(iOS 17.0, *) else { return nil }
        guard let cg = image(from: px, width: w, height: h)?.cgImage else { return nil }
        let req = VNGenerateForegroundInstanceMaskRequest()
        let handler = VNImageRequestHandler(cgImage: cg, options: [:])
        do {
            try handler.perform([req])
            guard let obs = req.results?.first else { return nil }
            let pb = try obs.generateScaledMaskForImage(forInstances: obs.allInstances, from: handler)
            CVPixelBufferLockBaseAddress(pb, .readOnly)
            defer { CVPixelBufferUnlockBaseAddress(pb, .readOnly) }
            let pw = CVPixelBufferGetWidth(pb), ph = CVPixelBufferGetHeight(pb)
            guard let base = CVPixelBufferGetBaseAddress(pb), pw > 0, ph > 0 else { return nil }
            let bpr = CVPixelBufferGetBytesPerRow(pb)
            let isFloat = CVPixelBufferGetPixelFormatType(pb) == kCVPixelFormatType_OneComponent32Float
            var out = [UInt8](repeating: 0, count: w * h)
            var count = 0
            for y in 0..<h {
                let sy = min(ph - 1, y * ph / h)
                let row = UnsafeRawPointer(base).advanced(by: sy * bpr)
                for x in 0..<w {
                    let sx = min(pw - 1, x * pw / w)
                    var on = false
                    if isFloat {
                        on = row.load(fromByteOffset: sx * 4, as: Float.self) > 0.5
                    } else {
                        on = row.load(fromByteOffset: sx, as: UInt8.self) > 127
                    }
                    if on { out[y * w + x] = 1; count += 1 }
                }
            }
            let frac = Float(count) / Float(w * h)
            if frac < 0.004 || frac > 0.985 { return nil }
            return out
        } catch {
            return nil
        }
    }

    private static func foreground(_ px: [UInt8], _ L: [Float], _ A: [Float], _ B: [Float],
                                   _ w: Int, _ h: Int, removeBg: Bool, useAI: Bool)
        -> (mask: [UInt8], alpha: [UInt8]) {
        let n = w * h
        var mask = [UInt8](repeating: 1, count: n)
        var alpha = [UInt8](repeating: 255, count: n)

        // images that already carry transparency: trust the alpha channel
        var transparent = 0
        for i in 0..<n where px[i * 4 + 3] < 250 { transparent += 1 }
        if transparent > n / 100 {
            for i in 0..<n {
                alpha[i] = px[i * 4 + 3]
                mask[i] = px[i * 4 + 3] > 24 ? 1 : 0
            }
            return (mask, alpha)
        }
        guard removeBg, w > 8, h > 8 else { return (mask, alpha) }

        // background colour = median of the border ring
        var bl: [Float] = [], ba: [Float] = [], bb: [Float] = []
        func take(_ i: Int) { bl.append(L[i]); ba.append(A[i]); bb.append(B[i]) }
        for x in 0..<w { take(x); take(w + x); take((h - 1) * w + x); take((h - 2) * w + x) }
        for y in 2..<(h - 2) { take(y * w); take(y * w + 1); take(y * w + w - 1); take(y * w + w - 2) }
        let ring = bl.count
        bl.sort(); ba.sort(); bb.sort()
        let mL = bl[ring / 2], mA = ba[ring / 2], mB = bb[ring / 2]
        func dBg(_ i: Int) -> Float { labDist(L[i], A[i], B[i], mL, mA, mB) }
        func dPair(_ i: Int, _ j: Int) -> Float { labDist(L[i], A[i], B[i], L[j], A[j], B[j]) }

        var near = 0
        for x in 0..<w {
            if dBg(x) < 12 { near += 1 }
            if dBg((h - 1) * w + x) < 12 { near += 1 }
        }
        for y in 0..<h {
            if dBg(y * w) < 12 { near += 1 }
            if dBg(y * w + w - 1) < 12 { near += 1 }
        }
        let plain = Float(near) / Float(2 * (w + h)) > 0.80

        // flood fill from the border through background-like pixels
        func flood() -> [UInt8] {
            var seen = [UInt8](repeating: 0, count: n)
            var stack: [Int32] = []
            stack.reserveCapacity(n / 4)
            func seed(_ i: Int) {
                if seen[i] == 0 && dBg(i) < 12 { seen[i] = 1; stack.append(Int32(i)) }
            }
            for x in 0..<w { seed(x); seed((h - 1) * w + x) }
            for y in 0..<h { seed(y * w); seed(y * w + w - 1) }
            while let cur32 = stack.popLast() {
                let i = Int(cur32)
                let x = i % w, y = i / w
                var k = 0
                while k < 4 {
                    var nx = x, ny = y
                    if k == 0 { nx -= 1 } else if k == 1 { nx += 1 } else if k == 2 { ny -= 1 } else { ny += 1 }
                    k += 1
                    if nx < 0 || ny < 0 || nx >= w || ny >= h { continue }
                    let j = ny * w + nx
                    if seen[j] != 0 { continue }
                    let d = dBg(j)
                    if d < 12 || (d < 26 && dPair(i, j) < 2.0) {
                        seen[j] = 1
                        stack.append(Int32(j))
                    }
                }
            }
            // keep the anti-aliased fringe
            var give: [Int] = []
            for y in 1..<(h - 1) {
                for x in 1..<(w - 1) {
                    let i = y * w + x
                    if seen[i] == 0 { continue }
                    if (seen[i - 1] == 0 || seen[i + 1] == 0 || seen[i - w] == 0 || seen[i + w] == 0) && dBg(i) > 4 {
                        give.append(i)
                    }
                }
            }
            for i in give { seen[i] = 0 }
            var out = [UInt8](repeating: 1, count: n)
            for i in 0..<n where seen[i] != 0 { out[i] = 0 }
            return out
        }

        let ml = useAI ? AnimeSegModel.mask(px, w, h) : nil
        var vm = ml == nil ? visionMask(px, w, h) : nil
        var fgm: [UInt8]
        if let m = ml {
            fgm = m.mask
        } else if plain {
            fgm = flood()
            // gaps between arm and body etc.: flat background-coloured areas that the
            // subject mask also calls background
            if let v = vm {
                var bgLike = [UInt8](repeating: 0, count: n)
                for i in 0..<n where fgm[i] != 0 && dBg(i) < 9 { bgLike[i] = 1 }
                let comps = components(bgLike, w, h, eight: false)
                let minA = max(40, n / 20000)
                var vis = [Int](repeating: 0, count: comps.areas.count)
                for i in 0..<n {
                    let id = Int(comps.ids[i])
                    if id >= 0 && v[i] != 0 { vis[id] += 1 }
                }
                for i in 0..<n {
                    let id = Int(comps.ids[i])
                    if id >= 0 && comps.areas[id] >= minA && Float(vis[id]) < 0.12 * Float(comps.areas[id]) { fgm[i] = 0 }
                }
            }
        } else if let v = vm {
            fgm = v
        } else {
            fgm = flood()
        }
        vm = nil

        // fill small holes, drop dust
        var inv = [UInt8](repeating: 0, count: n)
        for i in 0..<n where fgm[i] == 0 { inv[i] = 1 }
        let holes = components(inv, w, h, eight: false)
        let holeMax = max(16, n / 20000)
        for i in 0..<n {
            let id = Int(holes.ids[i])
            if id < 0 { continue }
            let b = holes.boxes[id]
            let touches = b.0 <= 0 || b.1 <= 0 || b.2 >= w - 1 || b.3 >= h - 1
            if !touches && holes.areas[id] < holeMax { fgm[i] = 1 }
        }
        let comps = components(fgm, w, h, eight: false)
        let keep = max(6, n / 50000)
        var kept = 0
        for i in 0..<n where fgm[i] != 0 {
            let id = Int(comps.ids[i])
            if id >= 0 && comps.areas[id] < keep { fgm[i] = 0 } else { kept += 1 }
        }
        if kept == 0 { return (mask, alpha) }      // never return an empty figure
        mask = fgm
        if let m = ml { for i in 0..<n where mask[i] != 0 { alpha[i] = max(m.alpha[i], 1) } }

        // soft edge on flat backgrounds
        if plain && ml == nil {
            for y in 1..<(h - 1) {
                for x in 1..<(w - 1) {
                    let i = y * w + x
                    if mask[i] == 0 { continue }
                    if mask[i - 1] == 0 || mask[i + 1] == 0 || mask[i - w] == 0 || mask[i + w] == 0 {
                        let t = max(0, min(1, (dBg(i) - 3) / 17))
                        alpha[i] = UInt8(max(40, min(255, t * 255)))
                    }
                }
            }
        }
        return (mask, alpha)
    }

    // MARK: - 2 denoise + line art -------------------------------------------------------

    private static func denoise(_ L: inout [Float], _ A: inout [Float], _ B: inout [Float],
                                _ fg: [UInt8], _ w: Int, _ h: Int, passes: Int) {
        if passes <= 0 { return }
        let n = w * h
        for _ in 0..<passes {
            var nl = L, na = A, nb = B
            for y in 1..<(h - 1) {
                for x in 1..<(w - 1) {
                    let i = y * w + x
                    if fg[i] == 0 { continue }
                    var sl: Float = 0, sa: Float = 0, sb: Float = 0, c: Float = 0
                    for dy in -1...1 {
                        for dx in -1...1 {
                            let j = i + dy * w + dx
                            if labDist(L[i], A[i], B[i], L[j], A[j], B[j]) < 7 {
                                sl += L[j]; sa += A[j]; sb += B[j]; c += 1
                            }
                        }
                    }
                    if c > 0 { nl[i] = sl / c; na[i] = sa / c; nb[i] = sb / c }
                }
            }
            L = nl; A = na; B = nb
        }
        _ = n
    }

    private static func lineMask(_ L: [Float], _ fg: [UInt8], _ w: Int, _ h: Int, sens: Int) -> [UInt8] {
        let n = w * h
        let w1 = w + 1
        var integ = [Int32](repeating: 0, count: (w + 1) * (h + 1))
        for y in 0..<h {
            var row: Int32 = 0
            for x in 0..<w {
                row += Int32(max(0, min(100, L[y * w + x])))
                integ[(y + 1) * w1 + x + 1] = integ[y * w1 + x + 1] + row
            }
        }
        let r = max(3, max(w, h) / 320)
        let contrast: Float = sens <= 1 ? 16 : (sens == 2 ? 12 : 9)
        var cand = [UInt8](repeating: 0, count: n)
        var candCount = 0
        var fgCount = 0
        for y in 0..<h {
            let ya = max(0, y - r), yb = min(h - 1, y + r)
            for x in 0..<w {
                let i = y * w + x
                if fg[i] == 0 { continue }
                fgCount += 1
                let xa = max(0, x - r), xb = min(w - 1, x + r)
                let s = integ[(yb + 1) * w1 + xb + 1] - integ[ya * w1 + xb + 1]
                    - integ[(yb + 1) * w1 + xa] + integ[ya * w1 + xa]
                let mean = Float(s) / Float((xb - xa + 1) * (yb - ya + 1))
                let l = L[i]
                if l < 30 || (l < 66 && l < mean - contrast) { cand[i] = 1; candCount += 1 }
            }
        }
        integ = []
        if candCount == 0 { return cand }
        // thick dark areas (black hair, dark clothes) are fills, not strokes
        let core = opening(cand, w, h, max(2, r * 2 / 3))
        // …and so are dense dark areas that are only broken up by a few highlights
        let dens = integral(cand, w, h)
        let dr = r + 1
        var out = cand
        var lines = 0
        for y in 0..<h {
            let ya = max(0, y - dr), yb = min(h - 1, y + dr)
            for x in 0..<w {
                let i = y * w + x
                if cand[i] == 0 { continue }
                var fill = core[i] != 0
                if !fill {
                    let xa = max(0, x - dr), xb = min(w - 1, x + dr)
                    let s = dens[(yb + 1) * w1 + xb + 1] - dens[ya * w1 + xb + 1]
                        - dens[(yb + 1) * w1 + xa] + dens[ya * w1 + xa]
                    fill = Float(s) >= 0.62 * Float((xb - xa + 1) * (yb - ya + 1))
                }
                if fill { out[i] = 0 } else { lines += 1 }
            }
        }
        if lines > fgCount * 3 / 10 { return [UInt8](repeating: 0, count: n) }
        return out
    }

    // MARK: - 3 colour regions --------------------------------------------------------------

    private static func cluster(_ L: [Float], _ A: [Float], _ B: [Float], _ elig: [UInt8], _ n: Int,
                                k0: Int, samples: Int, iters: Int, token: CancelToken) -> [Int16]? {
        var total = 0
        for i in 0..<n where elig[i] != 0 { total += 1 }
        if total == 0 { return nil }
        let step = max(1, total / samples)
        var pts: [Int32] = []
        var c = 0
        for i in 0..<n where elig[i] != 0 {
            if c % step == 0 { pts.append(Int32(i)) }
            c += 1
        }
        let m = pts.count
        let k = max(2, min(k0, m))
        let wa: Float = 1.3
        var fl = [Float](repeating: 0, count: m)
        var fa = [Float](repeating: 0, count: m)
        var fb = [Float](repeating: 0, count: m)
        for j in 0..<m {
            let p = Int(pts[j])
            fl[j] = L[p]; fa[j] = A[p] * wa; fb[j] = B[p] * wa
        }
        var seed: UInt64 = 0x9E3779B97F4A7C15
        func rnd() -> Float {
            seed = seed &* 6364136223846793005 &+ 1442695040888963407
            return Float((seed >> 40) & 0xFFFFFF) / Float(0x1000000)
        }
        var cL: [Float] = [], cA: [Float] = [], cB: [Float] = []
        let first = min(m - 1, Int(rnd() * Float(m)))
        cL.append(fl[first]); cA.append(fa[first]); cB.append(fb[first])
        var dmin = [Float](repeating: Float.greatestFiniteMagnitude, count: m)
        while cL.count < k {
            let li = cL.count - 1
            var sum: Double = 0
            for j in 0..<m {
                let dl = fl[j] - cL[li], da = fa[j] - cA[li], db = fb[j] - cB[li]
                let d = dl * dl + da * da + db * db
                if d < dmin[j] { dmin[j] = d }
                sum += Double(dmin[j])
            }
            if sum <= 0 { break }
            var target = Double(rnd()) * sum
            var pick = m - 1
            for j in 0..<m {
                target -= Double(dmin[j])
                if target <= 0 { pick = j; break }
            }
            cL.append(fl[pick]); cA.append(fa[pick]); cB.append(fb[pick])
        }
        let kk = cL.count
        var cnt = [Int](repeating: 0, count: kk)
        for _ in 0..<iters {
            var sL = [Double](repeating: 0, count: kk)
            var sA = [Double](repeating: 0, count: kk)
            var sB = [Double](repeating: 0, count: kk)
            cnt = [Int](repeating: 0, count: kk)
            for j in 0..<m {
                var best = 0
                var bd = Float.greatestFiniteMagnitude
                for q in 0..<kk {
                    let dl = fl[j] - cL[q], da = fa[j] - cA[q], db = fb[j] - cB[q]
                    let d = dl * dl + da * da + db * db
                    if d < bd { bd = d; best = q }
                }
                sL[best] += Double(fl[j]); sA[best] += Double(fa[j]); sB[best] += Double(fb[j])
                cnt[best] += 1
            }
            for q in 0..<kk where cnt[q] > 0 {
                cL[q] = Float(sL[q] / Double(cnt[q]))
                cA[q] = Float(sA[q] / Double(cnt[q]))
                cB[q] = Float(sB[q] / Double(cnt[q]))
            }
            if token.isCancelled { return nil }
        }
        // merge centroids that are nearly the same colour
        var par = Array(0..<kk)
        func root(_ x: Int) -> Int { var r = x; while par[r] != r { r = par[r] }; return r }
        for p in 0..<kk {
            for q in (p + 1)..<kk where q < kk {
                let dl = cL[p] - cL[q], da = cA[p] - cA[q], db = cB[p] - cB[q]
                if sqrtf(dl * dl + da * da + db * db) < 6.5 {
                    let rp = root(p), rq = root(q)
                    if rp != rq { par[rq] = rp }
                }
            }
        }
        var newId = [Int](repeating: -1, count: kk)
        var mL: [Float] = [], mA: [Float] = [], mB: [Float] = [], mC: [Float] = []
        for p in 0..<kk {
            let r = root(p)
            if newId[r] < 0 {
                newId[r] = mL.count
                mL.append(0); mA.append(0); mB.append(0); mC.append(0)
            }
            let id = newId[r]
            let wgt = Float(max(1, cnt[p]))
            mL[id] += cL[p] * wgt; mA[id] += cA[p] * wgt; mB[id] += cB[p] * wgt; mC[id] += wgt
        }
        let m2 = mL.count
        for q in 0..<m2 { mL[q] /= mC[q]; mA[q] /= mC[q]; mB[q] /= mC[q] }

        var out = [Int16](repeating: -1, count: n)
        for i in 0..<n where elig[i] != 0 {
            let l = L[i], a = A[i] * wa, b = B[i] * wa
            var best = 0
            var bd = Float.greatestFiniteMagnitude
            for q in 0..<m2 {
                let dl = l - mL[q], da = a - mA[q], db = b - mB[q]
                let d = dl * dl + da * da + db * db
                if d < bd { bd = d; best = q }
            }
            out[i] = Int16(best)
            if i & 0x3FFFF == 0 && token.isCancelled { return nil }
        }
        return out
    }

    private static func majority(_ cl: inout [Int16], _ w: Int, _ h: Int, passes: Int) {
        if passes <= 0 { return }
        var tmp = cl
        var nb = [Int16](repeating: -1, count: 8)
        for _ in 0..<passes {
            for y in 1..<(h - 1) {
                for x in 1..<(w - 1) {
                    let i = y * w + x
                    let c = cl[i]
                    if c < 0 { continue }
                    nb[0] = cl[i - w - 1]; nb[1] = cl[i - w]; nb[2] = cl[i - w + 1]
                    nb[3] = cl[i - 1];                          nb[4] = cl[i + 1]
                    nb[5] = cl[i + w - 1]; nb[6] = cl[i + w]; nb[7] = cl[i + w + 1]
                    var same = 0
                    for v in nb where v == c { same += 1 }
                    if same >= 3 { tmp[i] = c; continue }
                    var best = c
                    var bc = 0
                    for v in nb where v >= 0 {
                        var k = 0
                        for u in nb where u == v { k += 1 }
                        if k > bc { bc = k; best = v }
                    }
                    tmp[i] = bc >= 5 ? best : c
                }
            }
            cl = tmp
        }
    }

    /// 4-connected pieces of equal cluster id.
    private static func pieces(_ cl: [Int16], _ w: Int, _ h: Int) -> (ids: [Int32], count: Int) {
        let n = w * h
        var ids = [Int32](repeating: -1, count: n)
        var count: Int32 = 0
        var stack: [Int32] = []
        for s in 0..<n where cl[s] >= 0 && ids[s] < 0 {
            let c = cl[s]
            ids[s] = count
            stack.append(Int32(s))
            while let cur = stack.popLast() {
                let i = Int(cur)
                let x = i % w, y = i / w
                if x > 0 { let j = i - 1; if ids[j] < 0 && cl[j] == c { ids[j] = count; stack.append(Int32(j)) } }
                if x < w - 1 { let j = i + 1; if ids[j] < 0 && cl[j] == c { ids[j] = count; stack.append(Int32(j)) } }
                if y > 0 { let j = i - w; if ids[j] < 0 && cl[j] == c { ids[j] = count; stack.append(Int32(j)) } }
                if y < h - 1 { let j = i + w; if ids[j] < 0 && cl[j] == c { ids[j] = count; stack.append(Int32(j)) } }
            }
            count += 1
        }
        return (ids, Int(count))
    }

    private static func edgeList(_ map: [Int32], _ w: Int, _ h: Int, _ count: Int) -> [[(Int32, Int32)]] {
        var edges = [UInt64: Int32]()
        for y in 0..<h {
            for x in 0..<w {
                let i = y * w + x
                let p = map[i]
                if p < 0 { continue }
                if x + 1 < w {
                    let q = map[i + 1]
                    if q >= 0 && q != p {
                        let a = UInt64(min(p, q)), b = UInt64(max(p, q))
                        edges[(a << 32) | b, default: 0] += 1
                    }
                }
                if y + 1 < h {
                    let q = map[i + w]
                    if q >= 0 && q != p {
                        let a = UInt64(min(p, q)), b = UInt64(max(p, q))
                        edges[(a << 32) | b, default: 0] += 1
                    }
                }
            }
        }
        var adj = [[(Int32, Int32)]](repeating: [], count: count)
        for (key, c) in edges {
            let a = Int(key >> 32), b = Int(key & 0xFFFFFFFF)
            adj[a].append((Int32(b), c))
            adj[b].append((Int32(a), c))
        }
        return adj
    }

    // MARK: - hair locks ---------------------------------------------------------------
    /// Splits the hair mask into locks. Pieces = same-colour regions; tiny ones merge into the
    /// neighbour they share most border with; too many -> smallest merge away; too few ->
    /// the biggest lock is cut lengthwise (side-by-side strands) until `target` is reached.
    private static func hairLocks(_ hm: [UInt8], _ reg: [Int32], _ line: [UInt8], _ near: [Int32],
                                  _ w: Int, _ h: Int, minLock: Int, target: Int,
                                  token: CancelToken) -> (map: [Int16], count: Int) {
        let n = w * h
        var cid = [Int32](repeating: -1, count: n)
        var C = 0
        var stack: [Int32] = []
        var cArea: [Int] = [], cSX: [Double] = [], cSY: [Double] = []
        for s0 in 0..<n where hm[s0] != 0 && cid[s0] < 0 {
            let rg = reg[s0]
            cid[s0] = Int32(C); stack.append(Int32(s0))
            var a = 0; var sx = 0.0; var sy = 0.0
            while let cur = stack.popLast() {
                let i = Int(cur); let x = i % w, y = i / w
                a += 1; sx += Double(x); sy += Double(y)
                if x > 0 { let j = i - 1; if hm[j] != 0 && cid[j] < 0 && reg[j] == rg { cid[j] = Int32(C); stack.append(Int32(j)) } }
                if x < w - 1 { let j = i + 1; if hm[j] != 0 && cid[j] < 0 && reg[j] == rg { cid[j] = Int32(C); stack.append(Int32(j)) } }
                if y > 0 { let j = i - w; if hm[j] != 0 && cid[j] < 0 && reg[j] == rg { cid[j] = Int32(C); stack.append(Int32(j)) } }
                if y < h - 1 { let j = i + w; if hm[j] != 0 && cid[j] < 0 && reg[j] == rg { cid[j] = Int32(C); stack.append(Int32(j)) } }
            }
            cArea.append(a); cSX.append(sx); cSY.append(sy)
            C += 1
        }
        if C == 0 || token.isCancelled { return ([], 0) }
        var full = cid
        for i in 0..<n where cid[i] < 0 && line[i] != 0 && near[i] >= 0 {
            let c = cid[Int(near[i])]
            if c >= 0 { full[i] = c }
        }
        let adjArr = edgeList(full, w, h, C)
        full = []
        var adj = [[Int: Int32]](repeating: [:], count: C)
        for a in 0..<C { for (q, c) in adjArr[a] { adj[a][Int(q)] = c } }
        var parent = Array(0..<C)
        func find(_ x: Int) -> Int {
            var r = x
            while parent[r] != r { r = parent[r] }
            var c = x
            while parent[c] != r { let nx = parent[c]; parent[c] = r; c = nx }
            return r
        }
        var alive = Set(0..<C)
        func merge(_ a: Int, into b: Int) {
            parent[a] = b
            cArea[b] += cArea[a]; cSX[b] += cSX[a]; cSY[b] += cSY[a]
            for (q, c) in adj[a] where q != b {
                adj[b][q, default: 0] += c
                adj[q][b, default: 0] += c
                adj[q].removeValue(forKey: a)
            }
            adj[b].removeValue(forKey: a)
            adj[a] = [:]
            alive.remove(a)
        }
        func bestFor(_ a: Int) -> Int? {
            var best = -1
            var bs: Int32 = -1
            for (q, c) in adj[a] where q != a {
                if c > bs || (c == bs && best >= 0 && cArea[q] > cArea[best]) { bs = c; best = q }
            }
            if best >= 0 { return best }
            let ax = cSX[a] / Double(cArea[a]), ay = cSY[a] / Double(cArea[a])
            var bd = Double.greatestFiniteMagnitude
            for q in alive where q != a {
                let dx = cSX[q] / Double(cArea[q]) - ax, dy = cSY[q] / Double(cArea[q]) - ay
                let d = dx * dx + dy * dy
                if d < bd { bd = d; best = q }
            }
            return best >= 0 ? best : nil
        }
        let small = alive.sorted { cArea[$0] < cArea[$1] }
        for a in small where alive.contains(a) && cArea[a] < minLock && alive.count > 1 {
            if let b = bestFor(a) { merge(a, into: b) }
        }
        while alive.count > target {
            guard let a = alive.min(by: { cArea[$0] < cArea[$1] }), let b = bestFor(a) else { break }
            merge(a, into: b)
        }
        if token.isCancelled { return ([], 0) }
        let live = alive.sorted()
        var newId = [Int](repeating: -1, count: C)
        for (k, a) in live.enumerated() { newId[a] = k }
        var K = live.count
        var lock = [Int16](repeating: -1, count: n)
        for i in 0..<n where cid[i] >= 0 { lock[i] = Int16(newId[find(Int(cid[i]))]) }
        cid = []
        var area = [Int](repeating: 0, count: K)
        var bx0 = [Int](repeating: w, count: K), by0 = [Int](repeating: h, count: K)
        var bx1 = [Int](repeating: -1, count: K), by1 = [Int](repeating: -1, count: K)
        for i in 0..<n where lock[i] >= 0 {
            let k = Int(lock[i]); let x = i % w, y = i / w
            area[k] += 1
            if x < bx0[k] { bx0[k] = x }; if x > bx1[k] { bx1[k] = x }
            if y < by0[k] { by0[k] = y }; if y > by1[k] { by1[k] = y }
        }
        var frozen = [Bool](repeating: false, count: K)
        var tries = 0
        while K < target && K < 200 && tries < 400 {
            tries += 1
            if token.isCancelled { break }
            var g = -1; var ga = 0
            for k in 0..<K where !frozen[k] && area[k] >= 2 * minLock && area[k] > ga { ga = area[k]; g = k }
            if g < 0 { break }
            var xs: [Int32] = []
            var mx = 0.0, my = 0.0
            let gl = Int16(g)
            for y in by0[g]...by1[g] {
                for x in bx0[g]...bx1[g] where lock[y * w + x] == gl {
                    xs.append(Int32(y * w + x)); mx += Double(x); my += Double(y)
                }
            }
            let m = xs.count
            if m < 2 { frozen[g] = true; continue }
            mx /= Double(m); my /= Double(m)
            var sxx = 0.0, sxy = 0.0, syy = 0.0
            for p in xs {
                let dx = Double(Int(p) % w) - mx, dy = Double(Int(p) / w) - my
                sxx += dx * dx; sxy += dx * dy; syy += dy * dy
            }
            let th = 0.5 * atan2(2 * sxy, sxx - syy)
            let ct = cos(th), sn = sin(th)
            var pu = [Float](repeating: 0, count: m), pv = [Float](repeating: 0, count: m)
            var vv = 0.0
            for (j, p) in xs.enumerated() {
                let dx = Double(Int(p) % w) - mx, dy = Double(Int(p) / w) - my
                let u = dx * ct + dy * sn, v = -dx * sn + dy * ct
                pu[j] = Float(u * 0.35); pv[j] = Float(v); vv += v * v
            }
            let sv = Float(sqrt(vv / Double(m)))
            var c0u: Float = 0, c0v: Float = -sv, c1u: Float = 0, c1v: Float = sv
            var asg = [UInt8](repeating: 0, count: m)
            for _ in 0..<8 {
                var s0u: Float = 0, s0v: Float = 0, n0 = 0, s1u: Float = 0, s1v: Float = 0, n1 = 0
                for j in 0..<m {
                    let d0 = (pu[j] - c0u) * (pu[j] - c0u) + (pv[j] - c0v) * (pv[j] - c0v)
                    let d1 = (pu[j] - c1u) * (pu[j] - c1u) + (pv[j] - c1v) * (pv[j] - c1v)
                    if d0 <= d1 { asg[j] = 0; s0u += pu[j]; s0v += pv[j]; n0 += 1 }
                    else { asg[j] = 1; s1u += pu[j]; s1v += pv[j]; n1 += 1 }
                }
                if n0 > 0 { c0u = s0u / Float(n0); c0v = s0v / Float(n0) }
                if n1 > 0 { c1u = s1u / Float(n1); c1v = s1v / Float(n1) }
            }
            var n1c = 0
            for a in asg where a == 1 { n1c += 1 }
            if n1c < minLock || m - n1c < minLock { frozen[g] = true; continue }
            let nk = K
            K += 1
            var ob = (w, h, -1, -1), nb = (w, h, -1, -1)
            for (j, p) in xs.enumerated() {
                let x = Int(p) % w, y = Int(p) / w
                if asg[j] == 1 {
                    lock[Int(p)] = Int16(nk)
                    if x < nb.0 { nb.0 = x }; if y < nb.1 { nb.1 = y }; if x > nb.2 { nb.2 = x }; if y > nb.3 { nb.3 = y }
                } else {
                    if x < ob.0 { ob.0 = x }; if y < ob.1 { ob.1 = y }; if x > ob.2 { ob.2 = x }; if y > ob.3 { ob.3 = y }
                }
            }
            area[g] = m - n1c; bx0[g] = ob.0; by0[g] = ob.1; bx1[g] = ob.2; by1[g] = ob.3
            area.append(n1c); bx0.append(nb.0); by0.append(nb.1); bx1.append(nb.2); by1.append(nb.3)
            frozen.append(false)
        }
        return (lock, K)
    }

    // MARK: - pipeline ------------------------------------------------------------------------

    static func run(rgba: [UInt8], width w: Int, height h: Int, options o: DecomposeOptions,
                    token: CancelToken, progress: @escaping (Double, String) -> Void)
        -> DecomposeResult? {
        let n = w * h
        guard n > 0, rgba.count >= n * 4, w >= 16, h >= 16 else { return nil }
        let px = rgba

        progress(0.03, "Reading image")
        var L = [Float](repeating: 0, count: n)
        var A = [Float](repeating: 0, count: n)
        var B = [Float](repeating: 0, count: n)
        px.withUnsafeBufferPointer { src in
            L.withUnsafeMutableBufferPointer { lp in
                A.withUnsafeMutableBufferPointer { ap in
                    B.withUnsafeMutableBufferPointer { bp in
                        toLab(src.baseAddress!, n, lp.baseAddress!, ap.baseAddress!, bp.baseAddress!)
                    }
                }
            }
        }
        if token.isCancelled { return nil }

        // 1 — cut-out
        progress(0.08, "Cutting out the character")
        let cut = foreground(px, L, A, B, w, h, removeBg: o.removeBackground, useAI: o.useAI)
        let fg = cut.mask
        let fa = cut.alpha
        var fgCount = 0
        var fx0 = w, fy0 = h, fx1 = -1, fy1 = -1
        for y in 0..<h {
            for x in 0..<w where fg[y * w + x] != 0 {
                fgCount += 1
                if x < fx0 { fx0 = x }
                if x > fx1 { fx1 = x }
                if y < fy0 { fy0 = y }
                if y > fy1 { fy1 = y }
            }
        }
        if fgCount < 64 { return nil }
        let figW = fx1 - fx0 + 1, figH = fy1 - fy0 + 1
        if token.isCancelled { return nil }

        // 2 — denoise, line art
        progress(0.16, "Cleaning the image")
        denoise(&L, &A, &B, fg, w, h, passes: o.quality >= 3 ? 3 : (o.quality == 0 ? 0 : 1))
        if token.isCancelled { return nil }
        progress(0.22, "Tracing line art")
        let line = lineMask(L, fg, w, h, sens: o.lineSensitivity)
        var elig = [UInt8](repeating: 0, count: n)
        for i in 0..<n where fg[i] != 0 && line[i] == 0 { elig[i] = 1 }
        if token.isCancelled { return nil }

        // 3 — colour regions
        progress(0.30, "Finding colour regions")
        let kWanted = 8 + o.detail * 3
        let samples = o.quality == 0 ? 50_000 : (o.quality >= 3 ? 160_000 : 100_000)
        guard var cl = cluster(L, A, B, elig, n, k0: kWanted, samples: samples,
                               iters: o.quality == 0 ? 6 : 10, token: token) else { return nil }
        progress(0.46, "Smoothing edges")
        majority(&cl, w, h, passes: o.smoothing)
        if token.isCancelled { return nil }

        progress(0.52, "Splitting into pieces")
        let pc = pieces(cl, w, h)
        cl = []
        let pid = pc.ids
        let P = pc.count
        if P == 0 { return nil }

        // nearest region pixel for every line pixel
        var near = [Int32](repeating: -1, count: n)
        do {
            var frontier: [Int32] = []
            for y in 0..<h {
                for x in 0..<w {
                    let i = y * w + x
                    if line[i] == 0 { continue }
                    var found: Int32 = -1
                    for dy in -1...1 {
                        for dx in -1...1 {
                            if found >= 0 { break }
                            let nx = x + dx, ny = y + dy
                            if nx < 0 || ny < 0 || nx >= w || ny >= h { continue }
                            let j = ny * w + nx
                            if pid[j] >= 0 { found = Int32(j) }
                        }
                    }
                    if found >= 0 { near[i] = found; frontier.append(Int32(i)) }
                }
            }
            while !frontier.isEmpty {
                var next: [Int32] = []
                for f in frontier {
                    let i = Int(f)
                    let x = i % w, y = i / w
                    for dy in -1...1 {
                        for dx in -1...1 {
                            let nx = x + dx, ny = y + dy
                            if nx < 0 || ny < 0 || nx >= w || ny >= h { continue }
                            let j = ny * w + nx
                            if line[j] != 0 && near[j] < 0 {
                                near[j] = near[i]
                                next.append(Int32(j))
                            }
                        }
                    }
                }
                frontier = next
            }
        }
        if token.isCancelled { return nil }

        // piece graph (lines are see-through) and merging of tiny pieces
        var pf = [Int32](repeating: -1, count: n)
        for i in 0..<n {
            if pid[i] >= 0 { pf[i] = pid[i] }
            else if near[i] >= 0 { pf[i] = pid[Int(near[i])] }
        }
        var pArea = [Int](repeating: 0, count: P)
        var pL = [Float](repeating: 0, count: P)
        var pA = [Float](repeating: 0, count: P)
        var pB = [Float](repeating: 0, count: P)
        for i in 0..<n {
            let p = Int(pid[i])
            if p < 0 { continue }
            pArea[p] += 1; pL[p] += L[i]; pA[p] += A[i]; pB[p] += B[i]
        }
        let adj = edgeList(pf, w, h, P)
        var parent = [Int32](repeating: 0, count: P)
        for p in 0..<P { parent[p] = Int32(p) }
        func find(_ x: Int32) -> Int32 {
            var r = x
            while parent[Int(r)] != r { r = parent[Int(r)] }
            var c = x
            while parent[Int(c)] != r { let nx = parent[Int(c)]; parent[Int(c)] = r; c = nx }
            return r
        }
        let minArea = max(6, n / (60000 + o.detail * 15000))
        let byArea = (0..<P).sorted { pArea[$0] < pArea[$1] }
        for p in byArea {
            let rp = find(Int32(p))
            if pArea[Int(rp)] >= minArea { continue }
            var best: Int32 = -1
            var bestScore: Float = -1
            let fp = Float(max(1, pArea[Int(rp)]))
            for (q, c) in adj[p] {
                let rq = find(q)
                if rq == rp { continue }
                let fq = Float(max(1, pArea[Int(rq)]))
                let d = labDist(pL[Int(rp)] / fp, pA[Int(rp)] / fp, pB[Int(rp)] / fp,
                                pL[Int(rq)] / fq, pA[Int(rq)] / fq, pB[Int(rq)] / fq)
                let score = Float(c) / (1 + d / 8)
                if score > bestScore { bestScore = score; best = rq }
            }
            if best >= 0 {
                parent[Int(rp)] = best
                pArea[Int(best)] += pArea[Int(rp)]
                pL[Int(best)] += pL[Int(rp)]; pA[Int(best)] += pA[Int(rp)]; pB[Int(best)] += pB[Int(rp)]
            }
        }
        if token.isCancelled { return nil }

        // compact region ids
        var regOfRoot = [Int32](repeating: -1, count: P)
        var regOfPiece = [Int32](repeating: -1, count: P)
        var R = 0
        for p in 0..<P {
            let r = Int(find(Int32(p)))
            if regOfRoot[r] < 0 { regOfRoot[r] = Int32(R); R += 1 }
            regOfPiece[p] = regOfRoot[r]
        }
        var reg = [Int32](repeating: -1, count: n)       // region of region pixels
        var regF = [Int32](repeating: -1, count: n)      // …filled under line pixels
        for i in 0..<n {
            if pid[i] >= 0 { reg[i] = regOfPiece[Int(pid[i])]; regF[i] = reg[i] }
        }
        for i in 0..<n where line[i] != 0 {
            if near[i] >= 0 { regF[i] = reg[Int(near[i])] }
        }
        pf = []

        // region statistics
        var regs = [Reg](repeating: Reg(), count: R)
        var sumR = [Float](repeating: 0, count: R), sumG = [Float](repeating: 0, count: R)
        var sumBl = [Float](repeating: 0, count: R)
        var sumL = [Float](repeating: 0, count: R), sumA = [Float](repeating: 0, count: R)
        var sumB = [Float](repeating: 0, count: R)
        var sumX = [Double](repeating: 0, count: R), sumY = [Double](repeating: 0, count: R)
        for y in 0..<h {
            for x in 0..<w {
                let i = y * w + x
                let r = Int(reg[i])
                if r < 0 { continue }
                regs[r].area += 1
                sumR[r] += Float(px[i * 4]); sumG[r] += Float(px[i * 4 + 1]); sumBl[r] += Float(px[i * 4 + 2])
                sumL[r] += L[i]; sumA[r] += A[i]; sumB[r] += B[i]
                sumX[r] += Double(x); sumY[r] += Double(y)
                if x < regs[r].x0 { regs[r].x0 = x }
                if x > regs[r].x1 { regs[r].x1 = x }
                if y < regs[r].y0 { regs[r].y0 = y }
                if y > regs[r].y1 { regs[r].y1 = y }
            }
        }
        for r in 0..<R where regs[r].area > 0 {
            let f = Float(regs[r].area)
            regs[r].r = sumR[r] / f; regs[r].g = sumG[r] / f; regs[r].bl = sumBl[r] / f
            regs[r].l = sumL[r] / f; regs[r].a = sumA[r] / f; regs[r].b = sumB[r] / f
            regs[r].cx = Float(sumX[r] / Double(regs[r].area))
            regs[r].cy = Float(sumY[r] / Double(regs[r].area))
            regs[r].skin = skinTone(regs[r].r, regs[r].g, regs[r].bl)
        }
        let radjRaw = edgeList(regF, w, h, R)
        L = []; A = []; B = []
        if token.isCancelled { return nil }

        // 4 — understanding
        progress(0.66, "Finding face, hair and body")
        let fgc = fgCount
        let figTop = Float(fy0), figHf = Float(figH)

        var faceMain = -1
        var bestArea = 0
        for r in 0..<R where regs[r].skin && regs[r].cy < figTop + 0.6 * figHf && regs[r].area > bestArea {
            bestArea = regs[r].area; faceMain = r
        }

        var inSkin = [Bool](repeating: false, count: R)
        var faceX0 = 0, faceX1 = 0, ty = 0, chin = 0
        var faceFound = false
        if faceMain >= 0 {
            // skin regions connected to the face
            var queue = [faceMain]
            inSkin[faceMain] = true
            while let r = queue.popLast() {
                for (q, _) in radjRaw[r] where regs[Int(q)].skin && !inSkin[Int(q)] {
                    inSkin[Int(q)] = true
                    queue.append(Int(q))
                }
            }
            let m = regs[faceMain]
            let mw = m.x1 - m.x0 + 1
            let rx0 = max(0, m.x0 - mw / 4), rx1 = min(w - 1, m.x1 + mw / 4)
            ty = m.y0
            let yEnd = max(ty, min(h - 1, ty + Int(0.6 * figHf)))
            var rowMin = [Int](repeating: w, count: h)
            var rowMax = [Int](repeating: -1, count: h)
            for y in ty...yEnd {
                for x in rx0...rx1 {
                    let rr = Int(reg[y * w + x])
                    if rr >= 0 && inSkin[rr] {
                        if x < rowMin[y] { rowMin[y] = x }
                        if x > rowMax[y] { rowMax[y] = x }
                    }
                }
            }
            var runMax = 0, yMaxRow = ty
            var chinRow = -1
            for y in ty...yEnd {
                let e = rowMax[y] >= 0 ? rowMax[y] - rowMin[y] + 1 : 0
                if e > runMax { runMax = e; yMaxRow = y }
                else if runMax > 0 && Float(e) < 0.62 * Float(runMax) && y > yMaxRow + runMax / 6 {
                    chinRow = y; break
                }
            }
            if chinRow < 0 { chinRow = min(fy1, ty + Int(1.15 * Float(runMax))) }
            chin = min(fy1, max(ty + 8, chinRow))
            faceX0 = w; faceX1 = -1
            for y in ty...min(chin, yEnd) where rowMax[y] >= 0 {
                if rowMin[y] < faceX0 { faceX0 = rowMin[y] }
                if rowMax[y] > faceX1 { faceX1 = rowMax[y] }
            }
            faceFound = faceX1 - faceX0 >= 12 && chin - ty >= 12
        }

        for r in 0..<R { regs[r].part = .none }
        var defs: [LDef] = []
        var defIndex: [String: Int] = [:]
        func def(_ name: String, _ group: String, _ order: Int) -> Int {
            if let i = defIndex[name] { return i }
            defs.append(LDef(name: name, group: group, order: order))
            defIndex[name] = defs.count - 1
            return defs.count - 1
        }
        var regLayer = [Int](repeating: -1, count: R)

        let fW = Float(faceX1 - faceX0 + 1), fH = Float(chin - ty + 1)
        let fcx = Float(faceX0 + faceX1) * 0.5
        let tyF = Float(ty), chinF = Float(chin)
        let fx0F = Float(faceX0), fx1F = Float(faceX1)

        func inHeadBox(_ r: Int) -> Bool {
            let c = regs[r]
            let okX = c.cx >= fx0F - 0.9 * fW && c.cx <= fx1F + 0.9 * fW
            return okX && c.cy <= chinF + 0.2 * fH
        }
        func inInterior(_ r: Int) -> Bool {
            let c = regs[r]
            let okX = Float(c.x0) >= fx0F - 0.05 * fW && Float(c.x1) <= fx1F + 0.05 * fW
            let okY = Float(c.y0) >= tyF - 0.05 * fH && Float(c.y1) <= chinF + 0.05 * fH
            return okX && okY
        }

        var palette: [(Float, Float, Float)] = []
        func paletteDist(_ r: Int) -> Float {
            var best = Float.greatestFiniteMagnitude
            for p in palette { best = min(best, labDist(regs[r].l, regs[r].a, regs[r].b, p.0, p.1, p.2)) }
            return best
        }

        if faceFound {
            // skin: face vs everything else
            for r in 0..<R where regs[r].skin {
                let c = regs[r]
                if inSkin[r] {
                    let inside = c.cy <= chinF && c.cx >= fx0F - 0.12 * fW && c.cx <= fx1F + 0.12 * fW
                    regs[r].part = inside ? .face : .body
                } else {
                    regs[r].part = (inInterior(r) && c.cy <= chinF) ? .face : .body
                }
            }
            // hair seeds: non-skin regions in the head box that are not inside the face
            var seeds: [Int] = []
            for r in 0..<R where regs[r].part == .none && !inInterior(r) && inHeadBox(r) && regs[r].area >= minArea * 2 {
                regs[r].part = .hair
                seeds.append(r)
            }
            seeds.sort { regs[$0].area > regs[$1].area }
            for r in seeds where palette.count < 6 {
                if palette.isEmpty || paletteDist(r) > 14 { palette.append((regs[r].l, regs[r].a, regs[r].b)) }
            }
            if palette.isEmpty {
                for r in 0..<R where regs[r].part == .none && inHeadBox(r) { regs[r].part = .hair }
            }
            // inside the face: bangs, eyes, brows, mouth
            for r in 0..<R where regs[r].part == .none && inInterior(r) {
                let c = regs[r]
                var touchesHair = false
                for (q, _) in radjRaw[r] where regs[Int(q)].part == .hair { touchesHair = true }
                if touchesHair && !palette.isEmpty && paletteDist(r) < 22 { regs[r].part = .hair; continue }
                let relY = (c.cy - tyF) / max(1, fH)
                let aspect = Float(c.x1 - c.x0 + 1) / Float(max(1, c.y1 - c.y0 + 1))
                if relY > 0.62 && abs(c.cx - fcx) < 0.3 * fW { regs[r].part = .mouth }
                else if c.a > 12 && c.l > 60 && relY > 0.45 { regs[r].part = .face }          // blush
                else if aspect > 2.6 && relY < 0.4 { regs[r].part = .eyebrows }
                else { regs[r].part = .eyes }
            }
            // hair that continues below the head (long hair, tails)
            for _ in 0..<6 {
                var changed = false
                for r in 0..<R where regs[r].part == .none && !regs[r].skin {
                    if regs[r].cy > figTop + 0.92 * figHf { continue }
                    var touches = 0
                    for (q, cnt) in radjRaw[r] where regs[Int(q)].part == .hair { touches += Int(cnt) }
                    if touches == 0 || palette.isEmpty { continue }
                    let tol: Float = regs[r].cy > chinF + 0.5 * fH ? 11 : 16
                    if paletteDist(r) < tol { regs[r].part = .hair; changed = true }
                }
                if !changed { break }
            }
            // shading that sits on skin
            for r in 0..<R where regs[r].part == .none && regs[r].area < fgc / 60 && regs[r].l > 35 {
                var tot = 0, skinB = 0, bestCnt = 0
                var bestPart = Part.none
                for (q, cnt) in radjRaw[r] {
                    tot += Int(cnt)
                    let pq = regs[Int(q)].part
                    if pq == .face || pq == .body {
                        skinB += Int(cnt)
                        if Int(cnt) > bestCnt { bestCnt = Int(cnt); bestPart = pq }
                    }
                }
                if tot > 0 && skinB * 10 >= tot * 6 { regs[r].part = bestPart }
            }
            // what is left: accessories near the head, otherwise clothes
            for r in 0..<R where regs[r].part == .none {
                regs[r].part = (inHeadBox(r) && regs[r].area < fgc / 40) ? .acc : .cloth
            }
        } else {
            for r in 0..<R {
                if regs[r].skin { regs[r].part = .body }
                else if regs[r].cy < figTop + 0.3 * figHf { regs[r].part = .hair }
                else { regs[r].part = .cloth }
            }
        }
        if token.isCancelled { return nil }

        // 5 — layers
        progress(0.76, "Building layers")
        let faceLayer = faceFound ? def("Head", "Head", 30) : -1
        let splitFace = o.splitFace && faceFound
        var counters: [String: Int] = [:]
        func numbered(_ base: String) -> String {
            counters[base, default: 0] += 1
            let c = counters[base] ?? 1
            return c == 1 ? base : "\(base) \(c)"
        }

        // face parts
        for r in 0..<R {
            switch regs[r].part {
            case .face: regLayer[r] = faceLayer
            case .eyes: regLayer[r] = splitFace ? def("Eyes", "Head", 40) : faceLayer
            case .eyebrows: regLayer[r] = splitFace ? def("Eyebrows", "Head", 42) : faceLayer
            case .mouth: regLayer[r] = splitFace ? def("Mouth", "Head", 43) : faceLayer
            default: break
            }
        }

        // hair
        let hairRegs = (0..<R).filter { regs[$0].part == .hair }.sorted { regs[$0].area > regs[$1].area }
        var hairPix: [Int16] = []
        var hairLayerOf: [Int] = []
        if o.hairStrands {
            var hm = [UInt8](repeating: 0, count: n)
            var hairPx = 0
            for i in 0..<n {
                let r = Int(reg[i])
                if r >= 0 && regs[r].part == .hair { hm[i] = 1; hairPx += 1 }
            }
            let target = max(1, o.strandLimit)
            let minLock = max(minArea * 3, hairPx / (target * 10))
            let res = hairLocks(hm, reg, line, near, w, h, minLock: minLock, target: target, token: token)
            hm = []
            if token.isCancelled { return nil }
            if res.count > 0 {
                var sx = [Double](repeating: 0, count: res.count)
                var sy = [Double](repeating: 0, count: res.count)
                var ar = [Int](repeating: 0, count: res.count)
                for i in 0..<n {
                    let k = Int(res.map[i])
                    if k >= 0 { ar[k] += 1; sx[k] += Double(i % w); sy[k] += Double(i / w) }
                }
                let ord = (0..<res.count).filter { ar[$0] > 0 }.sorted { ar[$0] > ar[$1] }
                hairLayerOf = [Int](repeating: -1, count: res.count)
                for k in ord {
                    let cx = Float(sx[k] / Double(ar[k])), cy = Float(sy[k] / Double(ar[k]))
                    var base = "Hair strand"
                    if faceFound {
                        if cy < tyF { base = "Hair top" }
                        else if cx < fx0F { base = "Hair left" }
                        else if cx > fx1F { base = "Hair right" }
                        else if cy > chinF { base = "Hair back" }
                        else { base = "Bangs" }
                    }
                    hairLayerOf[k] = def(numbered(base), "Hair", 50)
                }
                hairPix = res.map
            }
            for r in hairRegs { regLayer[r] = def("Hair", "Hair", 50) }
        } else if !hairRegs.isEmpty {
            var pal: [(Float, Float, Float)] = []
            var palLayer: [Int] = []
            for r in hairRegs {
                var bi = -1
                var bd: Float = 16
                for (i, p) in pal.enumerated() {
                    let d = labDist(regs[r].l, regs[r].a, regs[r].b, p.0, p.1, p.2)
                    if d < bd { bd = d; bi = i }
                }
                if bi < 0 {
                    var nm = "Hair"
                    if !pal.isEmpty {
                        nm = regs[r].l > pal[0].0 + 6 ? numbered("Hair highlight") : numbered("Hair shadow")
                    }
                    pal.append((regs[r].l, regs[r].a, regs[r].b))
                    palLayer.append(def(nm, "Hair", 50))
                    bi = pal.count - 1
                }
                regLayer[r] = palLayer[bi]
            }
        }

        // clothes: same-coloured touching regions form one garment
        let clothRegs = (0..<R).filter { regs[$0].part == .cloth }
        if !clothRegs.isEmpty {
            if !o.splitClothes {
                let d = def("Clothes", "Clothes", 25)
                for r in clothRegs { regLayer[r] = d }
            } else {
                var cp = [Int](repeating: 0, count: R)
                for r in 0..<R { cp[r] = r }
                func croot(_ x: Int) -> Int { var r = x; while cp[r] != r { r = cp[r] }; return r }
                for r in clothRegs {
                    for (q, _) in radjRaw[r] where regs[Int(q)].part == .cloth {
                        let d = labDist(regs[r].l, regs[r].a, regs[r].b,
                                        regs[Int(q)].l, regs[Int(q)].a, regs[Int(q)].b)
                        if d < 26 {
                            let a = croot(r), b = croot(Int(q))
                            if a != b { cp[b] = a }
                        }
                    }
                }
                var compArea: [Int: Int] = [:]
                for r in clothRegs { compArea[croot(r), default: 0] += regs[r].area }
                let comps = compArea.keys.sorted { (compArea[$0] ?? 0) > (compArea[$1] ?? 0) }
                var kept: [Int] = []
                for c in comps where kept.count < 8 && (compArea[c] ?? 0) >= fgc / 150 { kept.append(c) }
                if kept.isEmpty, let f = comps.first { kept.append(f) }
                var rootOf: [Int: Int] = [:]
                var members: [Int: [Int]] = [:]
                for r in clothRegs { let c = croot(r); rootOf[r] = c; members[c, default: []].append(r) }
                var compLayer: [Int: Int] = [:]
                for c in kept {
                    var sy: Double = 0, cnt: Double = 0
                    for r in members[c] ?? [] { sy += Double(regs[r].cy) * Double(regs[r].area); cnt += Double(regs[r].area) }
                    let rel = (Float(sy / max(1, cnt)) - figTop) / max(1, figHf)
                    let base = rel > 0.86 ? "Footwear" : (rel > 0.6 ? "Clothes bottom" : "Clothes top")
                    compLayer[c] = def(numbered(base), "Clothes", 25)
                }
                for r in clothRegs {
                    let c = rootOf[r] ?? r
                    if let d = compLayer[c] { regLayer[r] = d; continue }
                    var bi = kept[0]
                    var bd = Float.greatestFiniteMagnitude
                    for k in kept {
                        var best = Float.greatestFiniteMagnitude
                        for q in members[k] ?? [] {
                            let dx = regs[q].cx - regs[r].cx, dy = regs[q].cy - regs[r].cy
                            best = min(best, dx * dx + dy * dy)
                        }
                        if best < bd { bd = best; bi = k }
                    }
                    regLayer[r] = compLayer[bi] ?? 0
                }
            }
        }

        // accessories
        for r in 0..<R where regs[r].part == .acc { regLayer[r] = def("Accessories", "Accessories", 60) }

        // per-pixel layer map
        var layerOf = [Int16](repeating: -1, count: n)
        var pending = [UInt8](repeating: 0, count: n)       // skin that still needs neck / arm / leg naming
        let neckX0 = fx0F + 0.05 * fW, neckX1 = fx1F - 0.05 * fW
        var neck = [UInt8](repeating: 0, count: n)
        for y in 0..<h {
            for x in 0..<w {
                let i = y * w + x
                let r = Int(reg[i])
                if r < 0 { continue }
                let part = regs[r].part
                if part == .body || (part == .face && faceFound && y > chin) {
                    pending[i] = 1
                    if faceFound && y > chin && y <= chin + Int(0.55 * fH)
                        && Float(x) >= neckX0 && Float(x) <= neckX1 { neck[i] = 1 }
                } else if regLayer[r] >= 0 {
                    var ll = regLayer[r]
                    if !hairPix.isEmpty && hairPix[i] >= 0 { ll = hairLayerOf[Int(hairPix[i])] }
                    layerOf[i] = Int16(ll)
                }
            }
        }
        // body skin
        do {
            var anyPending = false
            for i in 0..<n where pending[i] != 0 { anyPending = true; break }
            if anyPending {
                if !o.splitBody {
                    let d = def("Body skin", "Body", 20)
                    for i in 0..<n where pending[i] != 0 { layerOf[i] = Int16(d) }
                } else {
                    let base = def("Body skin", "Body", 20)
                    var neckLayer = -1
                    var rest = [UInt8](repeating: 0, count: n)
                    var neckCount = 0
                    for i in 0..<n where pending[i] != 0 {
                        if neck[i] != 0 { neckCount += 1 } else { rest[i] = 1 }
                    }
                    if neckCount > 20 {
                        neckLayer = def("Neck", "Body", 21)
                        for i in 0..<n where neck[i] != 0 { layerOf[i] = Int16(neckLayer) }
                    }
                    let comps = components(rest, w, h, eight: true)
                    let order = (0..<comps.areas.count).sorted { comps.areas[$0] > comps.areas[$1] }
                    var compLayer = [Int](repeating: base, count: comps.areas.count)
                    var made = 0
                    let cxFig = Float(fx0 + fx1) * 0.5
                    let fullBody = faceFound && (chinF - tyF) < 0.30 * figHf
                    for c in order where made < 8 && comps.areas[c] >= max(40, fgc / 150) {
                        let b = comps.boxes[c]
                        let cx = Float(b.0 + b.2) * 0.5, cy = Float(b.1 + b.3) * 0.5
                        let rel = (cy - figTop) / max(1, figHf)
                        let bw = Float(b.2 - b.0 + 1)
                        var nm: String
                        if rel > 0.62 && fullBody && comps.areas[c] >= fgc / 80 && Float(b.3 - b.1 + 1) >= 0.10 * figHf {
                            nm = bw > 0.5 * Float(figW) ? "Legs" : (cx < cxFig ? "Leg L" : "Leg R")
                        } else if abs(cx - cxFig) < 0.12 * Float(figW) && bw < 0.3 * Float(figW) {
                            nm = "Torso skin"
                        } else {
                            nm = cx < cxFig ? "Arm L" : "Arm R"
                        }
                        compLayer[c] = def(numbered(nm), "Body", 20)
                        made += 1
                    }
                    for i in 0..<n where rest[i] != 0 {
                        let id = Int(comps.ids[i])
                        layerOf[i] = Int16(id >= 0 ? compLayer[id] : base)
                    }
                }
            }
        }

        // line pixels
        var compKind: [UInt8] = []
        var lineComps: (ids: [Int32], areas: [Int], boxes: [(Int, Int, Int, Int)])? = nil
        var eyesY = tyF + 0.5 * fH
        if faceFound {
            var sy: Float = 0, sa: Float = 0
            for r in 0..<R where regs[r].part == .eyes { sy += regs[r].cy * Float(regs[r].area); sa += Float(regs[r].area) }
            if sa > 0 { eyesY = sy / sa }
            let lc = components(line, w, h, eight: true)
            lineComps = lc
            compKind = [UInt8](repeating: 0, count: lc.areas.count)
            for c in 0..<lc.areas.count {
                let b = lc.boxes[c]
                let okX = Float(b.0) >= fx0F + 0.05 * fW && Float(b.2) <= fx1F - 0.05 * fW
                let okY = Float(b.1) >= tyF - 0.05 * fH && Float(b.3) <= chinF - 0.02 * fH
                if !(okX && okY && lc.areas[c] < fgc / 25) { continue }
                let cx = Float(b.0 + b.2) * 0.5, cy = Float(b.1 + b.3) * 0.5
                if cy > chinF - 0.34 * fH && abs(cx - fcx) < 0.3 * fW { compKind[c] = 3 }       // mouth
                else if abs(cy - eyesY) <= 0.14 * fH { compKind[c] = 1 }                          // eyelids
                else if cy < eyesY - 0.14 * fH { compKind[c] = 2 }                               // eyebrows
                else { compKind[c] = 4 }                                                         // nose etc.
            }
        }
        for i in 0..<n where line[i] != 0 {
            let nr = Int(near[i])
            let nearLayer: Int = nr >= 0 ? Int(layerOf[nr]) : -1
            var target = -1
            var facial = false
            if let lc = lineComps, splitFace || faceFound {
                let id = Int(lc.ids[i])
                let kind = id >= 0 && id < compKind.count ? compKind[id] : 0
                if kind != 0 {
                    facial = true
                    if !splitFace { target = faceLayer }
                    else if kind == 1 { target = def("Eyelids", "Head", 41) }
                    else if kind == 2 { target = def("Eyebrows", "Head", 42) }
                    else if kind == 3 { target = def("Mouth", "Head", 43) }
                    else { target = def("Head lines", "Head", 71) }
                }
            }
            if o.hairStrands && !hairPix.isEmpty && target < 0 && nearLayer >= 0 && o.lineMode != 1 {
                let rr0 = Int(regF[i])
                if rr0 >= 0 && regs[rr0].part == .hair { target = nearLayer }
            }
            if target < 0 {
                if o.lineMode == 0 {
                    target = nearLayer >= 0 ? nearLayer : def("Line art", o.autoGroup ? "Line art" : "", 70)
                } else if o.lineMode == 1 {
                    target = def("Line art", "Line art", 70)
                } else {
                    let rr = Int(regF[i])
                    var nm = "Line art", grp = "Line art"
                    if rr >= 0 {
                        switch regs[rr].part {
                        case .hair: nm = "Hair lines"; grp = "Hair"
                        case .face, .eyes, .eyebrows, .mouth: nm = "Head lines"; grp = "Head"
                        case .body: nm = "Body lines"; grp = "Body"
                        case .cloth: nm = "Clothes lines"; grp = "Clothes"
                        case .acc: nm = "Accessory lines"; grp = "Accessories"
                        case .none: break
                        }
                    }
                    target = def(nm, grp, 70)
                }
            }
            layerOf[i] = Int16(target)
            _ = facial
        }

        // background + stragglers
        var bgLayer = -1
        if o.keepBackground {
            var any = false
            for i in 0..<n where fg[i] == 0 && px[i * 4 + 3] > 8 { any = true; break }
            if any { bgLayer = def("Background", "Background", 0) }
        }
        var strayLayer = -1
        for i in 0..<n {
            if fg[i] != 0 {
                if layerOf[i] < 0 {
                    if strayLayer < 0 { strayLayer = def("Details", "", 65) }
                    layerOf[i] = Int16(strayLayer)
                }
            } else if bgLayer >= 0 && px[i * 4 + 3] > 8 {
                layerOf[i] = Int16(bgLayer)
            }
        }

        // 6 — bitmaps
        progress(0.88, "Cutting layers")
        let count = defs.count
        var x0 = [Int](repeating: w, count: count)
        var y0 = [Int](repeating: h, count: count)
        var x1 = [Int](repeating: -1, count: count)
        var y1 = [Int](repeating: -1, count: count)
        var ar = [Int](repeating: 0, count: count)
        for y in 0..<h {
            for x in 0..<w {
                let l = Int(layerOf[y * w + x])
                if l < 0 { continue }
                ar[l] += 1
                if x < x0[l] { x0[l] = x }
                if x > x1[l] { x1[l] = x }
                if y < y0[l] { y0[l] = y }
                if y > y1[l] { y1[l] = y }
            }
        }
        let ids = (0..<count).filter { ar[$0] >= 1 && x1[$0] >= 0 }.sorted {
            defs[$0].order != defs[$1].order ? defs[$0].order < defs[$1].order : $0 < $1
        }
        var rank = [Int](repeating: 0, count: count)
        for (k, d) in ids.enumerated() { rank[d] = k }
        let baseD = o.fillGaps ? min(14, max(3, max(figW, figH) / 90)) : 0
        var layers: [DecomposedLayer] = []
        for d in ids {
            if token.isCancelled { return nil }
            var D = 0
            if o.fillGaps && defs[d].order < 65 && d != bgLayer {
                D = baseD
                if d == faceLayer && faceFound { D = max(D, Int(0.15 * fW)) }
            }
            let ex0 = max(0, x0[d] - D), ey0 = max(0, y0[d] - D)
            let ex1 = min(w - 1, x1[d] + D), ey1 = min(h - 1, y1[d] + D)
            let lw = ex1 - ex0 + 1, lh = ey1 - ey0 + 1
            var buf = [UInt8](repeating: 0, count: lw * lh * 4)
            var st = [UInt8](repeating: 0, count: lw * lh)     // 1 filled · 2 pending
            let d16 = Int16(d)
            for yy in 0..<lh {
                let y = ey0 + yy
                for xx in 0..<lw {
                    let i = y * w + ex0 + xx
                    if layerOf[i] != d16 { continue }
                    let o4 = (yy * lw + xx) * 4
                    buf[o4] = px[i * 4]; buf[o4 + 1] = px[i * 4 + 1]; buf[o4 + 2] = px[i * 4 + 2]
                    buf[o4 + 3] = d == bgLayer ? px[i * 4 + 3] : fa[i]
                    st[yy * lw + xx] = 1
                }
            }
            if D > 0 {
                // hidden underlap: only below fully opaque pixels of layers stacked above this one,
                // only inside the figure, colour = average of the already-filled neighbours (no streaks)
                func elig(_ xx: Int, _ yy: Int) -> Bool {
                    let i = (ey0 + yy) * w + ex0 + xx
                    let l = Int(layerOf[i])
                    return l >= 0 && l != d && l != bgLayer && fg[i] != 0 && fa[i] == 255 && rank[l] > rank[d]
                }
                var frontier: [Int32] = []
                for yy in 0..<lh {
                    for xx in 0..<lw where st[yy * lw + xx] == 1 {
                        if (xx > 0 && st[yy * lw + xx - 1] == 0 && elig(xx - 1, yy))
                            || (xx < lw - 1 && st[yy * lw + xx + 1] == 0 && elig(xx + 1, yy))
                            || (yy > 0 && st[(yy - 1) * lw + xx] == 0 && elig(xx, yy - 1))
                            || (yy < lh - 1 && st[(yy + 1) * lw + xx] == 0 && elig(xx, yy + 1)) {
                            frontier.append(Int32(yy * lw + xx))
                        }
                    }
                }
                var step = 0
                while !frontier.isEmpty && step < D {
                    var next: [Int32] = []
                    for f in frontier {
                        let fx = Int(f) % lw, fy = Int(f) / lw
                        var k = 0
                        while k < 4 {
                            var nx = fx, ny = fy
                            if k == 0 { nx -= 1 } else if k == 1 { nx += 1 } else if k == 2 { ny -= 1 } else { ny += 1 }
                            k += 1
                            if nx < 0 || ny < 0 || nx >= lw || ny >= lh { continue }
                            let j = ny * lw + nx
                            if st[j] == 0 && elig(nx, ny) { st[j] = 2; next.append(Int32(j)) }
                        }
                    }
                    for j32 in next {
                        let j = Int(j32)
                        let jx = j % lw, jy = j / lw
                        var sr = 0, sg = 0, sb = 0, c = 0
                        for dy in -1...1 {
                            for dx in -1...1 {
                                if dx == 0 && dy == 0 { continue }
                                let nx = jx + dx, ny = jy + dy
                                if nx < 0 || ny < 0 || nx >= lw || ny >= lh { continue }
                                let q = ny * lw + nx
                                if st[q] == 1 { sr += Int(buf[q * 4]); sg += Int(buf[q * 4 + 1]); sb += Int(buf[q * 4 + 2]); c += 1 }
                            }
                        }
                        if c > 0 {
                            buf[j * 4] = UInt8(sr / c); buf[j * 4 + 1] = UInt8(sg / c); buf[j * 4 + 2] = UInt8(sb / c)
                            buf[j * 4 + 3] = 255
                        }
                    }
                    for j32 in next { st[Int(j32)] = 1 }
                    frontier = next
                    step += 1
                }
            }
            layers.append(DecomposedLayer(name: defs[d].name, x: ex0, y: ey0, w: lw, h: lh,
                                          rgba: buf, visible: true, area: ar[d],
                                          group: o.autoGroup ? defs[d].group : "", order: defs[d].order))
        }
        if layers.isEmpty { return nil }
        progress(1.0, "Done")
        return DecomposeResult(width: w, height: h, layers: layers)
    }
}
