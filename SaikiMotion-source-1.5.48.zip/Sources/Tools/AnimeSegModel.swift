// AnimeSegModel.swift — optional on-device AI cut-out (ISNet anime segmentation, Core ML).
//
// Looks for a model whose file name contains "isnet" or "anime" (.mlmodelc / .mlpackage /
// .mlmodel) inside the app bundle (e.g. Resources/img/ISNetAnime.mlpackage) or the app's
// Documents folder (Files app). Compiled once, cached, runs on the Neural Engine.
// No model found → returns nil and the classic cut-out is used.

import UIKit
import CoreML
import Vision
import CoreVideo
#if canImport(OnnxRuntimeBindings)
import OnnxRuntimeBindings
#endif

enum AnimeSegModel {
    private static var cached: VNCoreMLModel?
    private static var tried = false
    private static let lock = NSLock()

    static var isAvailable: Bool { load() != nil }

    private static func candidates() -> [URL] {
        let fm = FileManager.default
        var out: [URL] = []
        let docs = fm.urls(for: .documentDirectory, in: .userDomainMask).first
        var roots: [URL] = [Bundle.main.bundleURL]
        if let d = docs { roots.append(d) }
        for root in roots {
            guard let en = fm.enumerator(at: root, includingPropertiesForKeys: nil,
                                         options: [.skipsHiddenFiles]) else { continue }
            for case let u as URL in en {
                let ext = u.pathExtension.lowercased()
                guard ["mlmodelc", "mlpackage", "mlmodel"].contains(ext) else { continue }
                let nm = u.lastPathComponent.lowercased()
                if nm.contains("isnet") || nm.contains("anime") { out.append(u) }
                if ext == "mlpackage" || ext == "mlmodelc" { en.skipDescendants() }
            }
        }
        return out
    }

    private static func compiledURL(_ src: URL) -> URL? {
        if src.pathExtension.lowercased() == "mlmodelc" { return src }
        let fm = FileManager.default
        guard let support = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask).first else { return nil }
        let dir = support.appendingPathComponent("AnimeSeg", isDirectory: true)
        try? fm.createDirectory(at: dir, withIntermediateDirectories: true)
        let dest = dir.appendingPathComponent(src.deletingPathExtension().lastPathComponent + ".mlmodelc")
        let srcDate = (try? src.resourceValues(forKeys: [.contentModificationDateKey]))?.contentModificationDate ?? .distantPast
        let dstDate = (try? dest.resourceValues(forKeys: [.contentModificationDateKey]))?.contentModificationDate
        if let d = dstDate, d >= srcDate, fm.fileExists(atPath: dest.path) { return dest }
        guard let tmp = try? MLModel.compileModel(at: src) else { return nil }
        try? fm.removeItem(at: dest)
        do { try fm.moveItem(at: tmp, to: dest) } catch { return tmp }
        return dest
    }

    private static func load() -> VNCoreMLModel? {
        lock.lock(); defer { lock.unlock() }
        if tried { return cached }
        tried = true
        for c in candidates() {
            guard let url = compiledURL(c) else { continue }
            let cfg = MLModelConfiguration()
            cfg.computeUnits = .all
            if let m = try? MLModel(contentsOf: url, configuration: cfg),
               let v = try? VNCoreMLModel(for: m) { cached = v; break }
        }
        return cached
    }

    /// Foreground mask (>0.5) and soft alpha at the working resolution, or nil.
    static func mask(_ px: [UInt8], _ w: Int, _ h: Int) -> (mask: [UInt8], alpha: [UInt8])? {
        if let r = onnxMask(px, w, h) { return r }
        return coreMLMask(px, w, h)
    }

    // MARK: ONNX (the model file straight from Hugging Face — no conversion)

    static let onnxName = "isnetis.onnx"
    static let onnxRemote = "https://huggingface.co/skytnt/anime-seg/resolve/main/isnetis.onnx"

    static var runtimeLinked: Bool {
        #if canImport(OnnxRuntimeBindings)
        return true
        #else
        return false
        #endif
    }

    static var onnxURL: URL? {
        let fm = FileManager.default
        var dirs: [URL] = []
        if let a = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask).first {
            dirs.append(a.appendingPathComponent("AnimeSeg", isDirectory: true))
        }
        if let d = fm.urls(for: .documentDirectory, in: .userDomainMask).first { dirs.append(d) }
        for d in dirs {
            let exact = d.appendingPathComponent(onnxName)
            if fm.fileExists(atPath: exact.path) { return exact }
            if let list = try? fm.contentsOfDirectory(at: d, includingPropertiesForKeys: nil) {
                for u in list where u.pathExtension.lowercased() == "onnx" {
                    let nm = u.lastPathComponent.lowercased()
                    if nm.contains("isnet") || nm.contains("anime") { return u }
                }
            }
        }
        return nil
    }

    static var onnxInstalled: Bool { onnxURL != nil }
    static var lastError: String?

    /// Loads the model for real; false = the file is missing/corrupt or the runtime isn't linked.
    static func verify() -> Bool {
        #if canImport(OnnxRuntimeBindings)
        lock.lock(); ortFailed = false; ortSession = nil; lock.unlock()
        return session() != nil
        #else
        return false
        #endif
    }

    static func removeModel() {
        if let u = onnxURL { try? FileManager.default.removeItem(at: u) }
        #if canImport(OnnxRuntimeBindings)
        lock.lock(); ortSession = nil; ortFailed = false; lock.unlock()
        #endif
    }

    /// One-tap download into Application Support/AnimeSeg (176 MB, needs internet once).
    static func download(progress: @escaping (Double) -> Void, done: @escaping (Bool) -> Void) {
        guard let remote = URL(string: onnxRemote) else { done(false); return }
        let d = Downloader(progress: progress, done: done)
        let session = URLSession(configuration: .default, delegate: d, delegateQueue: .main)
        d.session = session
        session.downloadTask(with: remote).resume()
    }

    private final class Downloader: NSObject, URLSessionDownloadDelegate {
        var session: URLSession?
        let progress: (Double) -> Void
        let done: (Bool) -> Void
        init(progress: @escaping (Double) -> Void, done: @escaping (Bool) -> Void) {
            self.progress = progress; self.done = done
        }
        func urlSession(_ s: URLSession, downloadTask: URLSessionDownloadTask, didWriteData b: Int64,
                        totalBytesWritten t: Int64, totalBytesExpectedToWrite e: Int64) {
            if e > 0 { progress(Double(t) / Double(e)) }
        }
        func urlSession(_ s: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo loc: URL) {
            let fm = FileManager.default
            var ok = false
            if let code = (downloadTask.response as? HTTPURLResponse)?.statusCode, code == 200,
               let a = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask).first {
                let dir = a.appendingPathComponent("AnimeSeg", isDirectory: true)
                try? fm.createDirectory(at: dir, withIntermediateDirectories: true)
                let dest = dir.appendingPathComponent(AnimeSegModel.onnxName)
                try? fm.removeItem(at: dest)
                let size = ((try? fm.attributesOfItem(atPath: loc.path))?[.size] as? NSNumber)?.int64Value ?? 0
                if size > 50_000_000 { do { try fm.moveItem(at: loc, to: dest); ok = true } catch { ok = false } }
            }
            done(ok)
            s.finishTasksAndInvalidate()
        }
        func urlSession(_ s: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
            if error != nil { done(false); s.invalidateAndCancel() }
        }
    }

    #if canImport(OnnxRuntimeBindings)
    private static var ortEnv: ORTEnv?
    private static var ortSession: ORTSession?
    private static var ortIn = "img"
    private static var ortOut = "mask"
    private static var ortFailed = false

    private static func session() -> ORTSession? {
        lock.lock(); defer { lock.unlock() }
        if let s = ortSession { return s }
        if ortFailed { return nil }
        guard let url = onnxURL else { return nil }
        do {
            let env = try ORTEnv(loggingLevel: .warning)
            let opts = try ORTSessionOptions()
            try opts.setIntraOpNumThreads(4)
            let s = try ORTSession(env: env, modelPath: url.path, sessionOptions: opts)
            if let n = try s.inputNames().first { ortIn = n }
            if let n = try s.outputNames().first { ortOut = n }
            ortEnv = env; ortSession = s
            return s
        } catch { ortFailed = true; lastError = error.localizedDescription; return nil }
    }

    private static func onnxMask(_ px: [UInt8], _ w: Int, _ h: Int) -> (mask: [UInt8], alpha: [UInt8])? {
        guard let sess = session() else { return nil }
        let S = 1024
        let sc = Float(S) / Float(max(w, h))
        let nw = max(1, Int((Float(w) * sc).rounded())), nh = max(1, Int((Float(h) * sc).rounded()))
        let ox = (S - nw) / 2, oy = (S - nh) / 2
        let plane = S * S
        guard let data = NSMutableData(length: 3 * plane * 4) else { return nil }
        let fp = data.mutableBytes.bindMemory(to: Float.self, capacity: 3 * plane)   // zero padded
        for y in 0..<nh {
            let fy = max(0, min(Float(h - 1), (Float(y) + 0.5) / sc - 0.5))
            let y0 = Int(fy), y1 = min(h - 1, y0 + 1), ty = fy - Float(y0)
            for x in 0..<nw {
                let fx = max(0, min(Float(w - 1), (Float(x) + 0.5) / sc - 0.5))
                let x0 = Int(fx), x1 = min(w - 1, x0 + 1), tx = fx - Float(x0)
                for c in 0..<3 {
                    let a = Float(px[(y0 * w + x0) * 4 + c]) * (1 - tx) + Float(px[(y0 * w + x1) * 4 + c]) * tx
                    let b = Float(px[(y1 * w + x0) * 4 + c]) * (1 - tx) + Float(px[(y1 * w + x1) * 4 + c]) * tx
                    fp[c * plane + (y + oy) * S + (x + ox)] = (a * (1 - ty) + b * ty) / 255
                }
            }
        }
        do {
            let input = try ORTValue(tensorData: data, elementType: .float,
                                     shape: [1, 3, NSNumber(value: S), NSNumber(value: S)])
            let outs = try sess.run(withInputs: [ortIn: input], outputNames: [ortOut], runOptions: nil)
            guard let ov = outs[ortOut] else { return nil }
            let od = try ov.tensorData() as Data
            guard od.count >= plane * 4 else { return nil }
            var map = [Float](repeating: 0, count: plane)
            od.withUnsafeBytes { raw in
                let p = raw.bindMemory(to: Float.self)
                for i in 0..<plane { map[i] = p[i] }
            }
            return finish(map, mw: S, mh: S, cropX: ox, cropY: oy, cropW: nw, cropH: nh, w, h)
        } catch { lastError = error.localizedDescription; return nil }
    }
    #else
    private static func onnxMask(_ px: [UInt8], _ w: Int, _ h: Int) -> (mask: [UInt8], alpha: [UInt8])? { nil }
    #endif

    /// sigmoid if needed → bilinear resize of the (cropped) map to w×h → mask + alpha.
    private static func finish(_ map0: [Float], mw: Int, mh: Int, cropX: Int, cropY: Int, cropW: Int, cropH: Int,
                               _ w: Int, _ h: Int) -> (mask: [UInt8], alpha: [UInt8])? {
        var map = map0
        var lo = Float.greatestFiniteMagnitude, hi = -Float.greatestFiniteMagnitude
        for v in map { if v < lo { lo = v }; if v > hi { hi = v } }
        if lo < -0.01 || hi > 1.01 { for i in 0..<map.count { map[i] = 1 / (1 + expf(-map[i])) } }
        var mask = [UInt8](repeating: 0, count: w * h)
        var alpha = [UInt8](repeating: 0, count: w * h)
        var on = 0
        for y in 0..<h {
            let fy = max(0, min(Float(cropH - 1), (Float(y) + 0.5) * Float(cropH) / Float(h) - 0.5))
            let y0 = Int(fy), y1 = min(cropH - 1, y0 + 1), ty = fy - Float(y0)
            for x in 0..<w {
                let fx = max(0, min(Float(cropW - 1), (Float(x) + 0.5) * Float(cropW) / Float(w) - 0.5))
                let x0 = Int(fx), x1 = min(cropW - 1, x0 + 1), tx = fx - Float(x0)
                let r0 = (cropY + y0) * mw + cropX, r1 = (cropY + y1) * mw + cropX
                let a = map[r0 + x0] * (1 - tx) + map[r0 + x1] * tx
                let b = map[r1 + x0] * (1 - tx) + map[r1 + x1] * tx
                let v = max(0, min(1, a * (1 - ty) + b * ty))
                alpha[y * w + x] = UInt8(v * 255)
                if v > 0.5 { mask[y * w + x] = 1; on += 1 }
            }
        }
        let frac = Float(on) / Float(w * h)
        if frac < 0.004 || frac > 0.985 { return nil }
        return (mask, alpha)
    }

    private static func coreMLMask(_ px: [UInt8], _ w: Int, _ h: Int) -> (mask: [UInt8], alpha: [UInt8])? {
        guard let model = load(),
              let cg = AnimeDecomposer.image(from: px, width: w, height: h)?.cgImage else { return nil }
        let req = VNCoreMLRequest(model: model)
        req.imageCropAndScaleOption = .scaleFill
        let handler = VNImageRequestHandler(cgImage: cg, options: [:])
        do { try handler.perform([req]) } catch { return nil }
        guard let res = req.results?.first else { return nil }
        var map: [Float] = []
        var mw = 0, mh = 0
        if let po = res as? VNPixelBufferObservation {
            let pb = po.pixelBuffer
            CVPixelBufferLockBaseAddress(pb, .readOnly)
            defer { CVPixelBufferUnlockBaseAddress(pb, .readOnly) }
            mw = CVPixelBufferGetWidth(pb); mh = CVPixelBufferGetHeight(pb)
            guard let base = CVPixelBufferGetBaseAddress(pb), mw > 0, mh > 0 else { return nil }
            let bpr = CVPixelBufferGetBytesPerRow(pb)
            let fmt = CVPixelBufferGetPixelFormatType(pb)
            map = [Float](repeating: 0, count: mw * mh)
            for y in 0..<mh {
                let row = UnsafeRawPointer(base).advanced(by: y * bpr)
                for x in 0..<mw {
                    if fmt == kCVPixelFormatType_OneComponent32Float {
                        map[y * mw + x] = row.load(fromByteOffset: x * 4, as: Float.self)
                    } else if fmt == kCVPixelFormatType_32BGRA {
                        map[y * mw + x] = Float(row.load(fromByteOffset: x * 4, as: UInt8.self)) / 255
                    } else {
                        map[y * mw + x] = Float(row.load(fromByteOffset: x, as: UInt8.self)) / 255
                    }
                }
            }
        } else if let fo = res as? VNCoreMLFeatureValueObservation, let arr = fo.featureValue.multiArrayValue {
            let nd = arr.shape.count
            guard nd >= 2 else { return nil }
            mh = arr.shape[nd - 2].intValue; mw = arr.shape[nd - 1].intValue
            let sy = arr.strides[nd - 2].intValue, sx = arr.strides[nd - 1].intValue
            guard mw > 0, mh > 0 else { return nil }
            map = [Float](repeating: 0, count: mw * mh)
            let p = arr.dataPointer
            for y in 0..<mh {
                for x in 0..<mw {
                    let idx = y * sy + x * sx
                    var v: Float = 0
                    switch arr.dataType {
                    case .float32: v = p.load(fromByteOffset: idx * 4, as: Float.self)
                    case .double: v = Float(p.load(fromByteOffset: idx * 8, as: Double.self))
                    default:
                        #if arch(arm64)
                        v = Float(p.load(fromByteOffset: idx * 2, as: Float16.self))
                        #endif
                    }
                    map[y * mw + x] = v
                }
            }
        } else { return nil }
        var lo = Float.greatestFiniteMagnitude, hi = -Float.greatestFiniteMagnitude
        for v in map { if v < lo { lo = v }; if v > hi { hi = v } }
        if lo < -0.01 || hi > 1.01 { for i in 0..<map.count { map[i] = 1 / (1 + expf(-map[i])) } }
        var mask = [UInt8](repeating: 0, count: w * h)
        var alpha = [UInt8](repeating: 0, count: w * h)
        var on = 0
        for y in 0..<h {
            let fy = max(0, min(Float(mh - 1), (Float(y) + 0.5) * Float(mh) / Float(h) - 0.5))
            let y0 = Int(fy), y1 = min(mh - 1, y0 + 1), ty = fy - Float(y0)
            for x in 0..<w {
                let fx = max(0, min(Float(mw - 1), (Float(x) + 0.5) * Float(mw) / Float(w) - 0.5))
                let x0 = Int(fx), x1 = min(mw - 1, x0 + 1), tx = fx - Float(x0)
                let a = map[y0 * mw + x0] * (1 - tx) + map[y0 * mw + x1] * tx
                let b = map[y1 * mw + x0] * (1 - tx) + map[y1 * mw + x1] * tx
                let v = max(0, min(1, a * (1 - ty) + b * ty))
                alpha[y * w + x] = UInt8(v * 255)
                if v > 0.5 { mask[y * w + x] = 1; on += 1 }
            }
        }
        let frac = Float(on) / Float(w * h)
        if frac < 0.004 || frac > 0.985 { return nil }
        return (mask, alpha)
    }
}
