// PreviewView.swift — the GL preview surface (UI).
//
// A GLKView with its own GLES context that renders the scene through
// SceneRenderer every time the editor asks (requestDraw). It also serves as
// the VideoSource: video layers get their frames from per-layer async
// samplers, and an arriving frame schedules the next draw.

import UIKit
import OpenGLES
import GLKit

final class PreviewView: GLKView, VideoSource {

    var quality = 1 {
        didSet { setNeedsDisplay() }
    }

    private var renderer: SceneRenderer?
    private var samplers: [Int: VideoFrames.Sampler] = [:]

    init() {
        let ctx = GLContext.make() ?? EAGLContext(api: .openGLES2)!
        super.init(frame: .zero, context: ctx)
        drawableColorFormat = .RGBA8888
        drawableDepthFormat = .formatNone
        drawableStencilFormat = .formatNone
        drawableMultisample = .multisampleNone
        enableSetNeedsDisplay = true
        isOpaque = true
        backgroundColor = UIColor.black
        contentMode = .redraw
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    /// Kotlin: preview.onResume() — GLKView has no pause; redraw instead.
    func requestDraw() {
        setNeedsDisplay()
    }

    /// Kotlin: preview.onPause() — drop the async video samplers.
    func releaseVideos() {
        samplers.removeAll()
    }

    override func draw(_ rect: CGRect) {
        guard let ctx = context as? EAGLContext else { return }
        // Not laid out yet (0x0 drawable) — drawing now would just fail.
        guard bounds.width > 1, bounds.height > 1 else { return }
        EAGLContext.setCurrent(ctx)
        if renderer == nil {
            renderer = SceneRenderer(context: ctx)
        }
        guard let renderer = renderer else { return }
        renderer.quality = quality
        let tex = renderer.draw(project: Editor.project, scene: Editor.scene,
                                time: Editor.time, video: self)

        // present: blit the scene texture into the drawable.
        // A GLKView's drawable is NOT framebuffer 0 — binding 0 draws into
        // nothing (the blank viewport). bindDrawable() binds the real one.
        bindDrawable()
        glViewport(0, 0, GLsizei(drawableWidth), GLsizei(drawableHeight))
        glDisable(GLenum(GL_BLEND))
        glClearColor(0, 0, 0, 1)
        glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
        renderer.present(tex)
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        setNeedsDisplay()
    }

    // MARK: - VideoSource

    func videoTexture(layerId: Int, path: String, srcTime: Float) -> GLuint {
        if let s = samplers[layerId] {
            return s.texture(at: srcTime)
        }
        let s = VideoFrames.Sampler(path: path)
        s.onUploaded = { [weak self] in
            self?.setNeedsDisplay()
        }
        samplers[layerId] = s
        return s.texture(at: srcTime)
    }

    func videoFrameArrived() -> Bool {
        false
    }
}
