// EditorPanelsText.swift — property-panel framework + Media/Shapes/Edit/Text panels + the color rows.

import UIKit
import UniformTypeIdentifiers
import PhotosUI

extension EditorViewController {
    /// Sweep-gradient circle that opens the full color picker (Android GradientDrawable SWEEP_GRADIENT).
    private final class RainbowCircleView: TapView {
        override func draw(_ rect: CGRect) {
            guard let c = UIGraphicsGetCurrentContext() else { return }
            let r = min(bounds.width, bounds.height) / 2 - 1
            c.saveGState()
            c.translateBy(x: bounds.width / 2, y: bounds.height / 2)
            let n = 36
            for i in 0..<n {
                let a0 = CGFloat(i) / CGFloat(n) * 2 * .pi
                let a1 = CGFloat(i + 1) / CGFloat(n) * 2 * .pi
                c.setFillColor(UIColor(hue: CGFloat(i) / CGFloat(n), saturation: 1, brightness: 1, alpha: 1).cgColor)
                c.move(to: .zero)
                c.addArc(center: .zero, radius: r, startAngle: a0, endAngle: a1, clockwise: false)
                c.closePath()
                c.fillPath()
            }
            c.restoreGState()
        }
    }


        // ================================================================ panels

        func refreshPanel() {
            panelList.arrangedSubviews.forEach { $0.removeFromSuperview() }
            rows.removeAll()
            if panel == P_NONE { return }
            if panel == P_MEDIA { buildMedia() }
            else if panel == P_SHAPES { buildShapes() }
            else {
                guard let l = selected() else { closePanel(); return }
                switch panel {
                case P_EDIT: buildEdit(l)
                case P_XFORM: buildXform(l)
                case P_FX: buildFx(l)
                case P_BLEND: buildBlend(l)
                case P_SPEED: buildSpeed(l)
                case P_GRAPH: buildGraph(l)
                default: break
                }
            }
            syncRows()
        }

        func addRow(_ parent: UIStackView, _ l: Layer, _ d: PropDef, _ label: String? = nil) {
            if d.options != nil { addOptionRow(parent, l, d); return }
            let tr = l.track(d.key)
            let s = RulerSlider(frame: .zero)
            s.label = label ?? d.label
            s.lo = d.min; s.hi = d.max; s.dec = d.dec
            s.infinite = d.inf
            s.span = d.span > 0 ? d.span : 1
            s.onExprIcon = { [weak self] in self?.showExpression(l, d) }
            s.value = tr.eval(l.editTime(d.key, Editor.time))
            s.onBegin = { [weak self] in
                guard let self = self else { return }
                self.pushUndo()
                self.selKey = d.key
                self.syncRows(s)
            }
            s.onChange = { [weak self] v in
                guard let self = self else { return }
                tr.set(l.editTime(d.key, Editor.time), v, self.autoKeyOn)
                self.syncRows(s)
                self.render()
            }
            s.onLabelTap = { [weak self] in
                guard let self = self else { return }
                self.selKey = d.key
                self.syncRows()
                // tapping a parameter name opens its graph
                if tr.keys.count >= 2 {
                    self.graphProp = d.key; self.graphKey = 0
                    self.openPanel(P_GRAPH)
                } else {
                    self.toast("Add 2 keyframes to \(d.label) to edit its graph")
                }
            }
            s.onLabelLong = { [weak self] in self?.showExpression(l, d) }
            put(parent, s, 60)
            rows.append(Row(s, d, l))
        }

        func addOptionRow(_ parent: UIStackView, _ l: Layer, _ d: PropDef) {
            let tr = l.track(d.key)
            let opts = d.options ?? []
            if opts.count == 2 {
                let sw = SwitchRow()
                sw.label = d.label
                sw.on = tr.base >= 0.5
                sw.captionOff = opts[0]; sw.captionOn = opts[1]
                sw.onToggle = { [weak self] v in
                    guard let self = self else { return }
                    self.pushUndo()
                    tr.keys.removeAll()
                    tr.base = v ? 1 : 0
                    self.render()
                }
                put(parent, sw, 52)
                return
            }
            text(parent, d.label, C.TEXT, 14, true)
            parent.addArrangedSubview(chipRow(opts, ktInt(tr.base)) { [weak self] i in
                guard let self = self else { return }
                self.pushUndo()
                tr.keys.removeAll()
                tr.base = Float(i)
                self.refreshPanel()
                self.render()
            })
        }

        func addPlain(_ parent: UIStackView, _ label: String, _ lo: Float, _ hi: Float, _ v: Float,
                              _ dec: Int, _ onChange: @escaping (Float) -> Void) {
            let s = RulerSlider(frame: .zero)
            s.label = label; s.lo = lo; s.hi = hi; s.value = v; s.dec = dec; s.canKey = false
            s.onBegin = { [weak self] in self?.pushUndo() }
            s.onChange = onChange
            put(parent, s, 60)
        }

        func syncRows(_ except: RulerSlider? = nil) {
            for r in rows {
                let tr = r.layer.track(r.d.key)
                let t = r.layer.editTime(r.d.key, Editor.time)
                if r.slider !== except { r.slider.value = tr.eval(t) }
                r.slider.hasKey = tr.keyAt(t) != nil
                r.slider.hasAnim = !tr.keys.isEmpty
                r.slider.hasExpr = tr.exprActive()
                r.slider.rowSelected = r.d.key == selKey
                r.slider.setNeedsDisplay()
            }
            diamondSide.set("diamond_f",
                            rows.contains(where: { $0.d.key == selKey && $0.slider.hasKey }) ? C.GREEN
                            : (rows.contains(where: { $0.d.key == selKey }) ? C.TEXT : C.DIM))
        }

        /** Adds or removes a keyframe on the parameter that was tapped last. */
        func keySelected() {
            guard let r = rows.first(where: { $0.d.key == selKey }) else {
                toast("Tap a parameter first, then tap the keyframe button")
                return
            }
            pushUndo()
            r.layer.track(r.d.key).toggleKey(r.layer.editTime(r.d.key, Editor.time))
            syncRows(); render()
        }

        /** Full color picker: saturation, hue, opacity, hex and an eyedropper that samples the preview. */
        func showColorPicker(_ initial: Int32, _ onPick: @escaping (Int32) -> Void) {
            let box = vStack()
            box.isLayoutMarginsRelativeArrangement = true
            box.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 4, leading: 4, bottom: 4, trailing: 4)
            let cp = ColorPickerView(frame: .zero)
            cp.setColor(initial)
            put(box, cp, 250, 0, 0)
            let row = hRow()
            row.isLayoutMarginsRelativeArrangement = true
            row.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 10, leading: 0, bottom: 6, trailing: 0)
            let hex = makeField("")
            hex.font = monoFont(14)
            hex.text = String(format: "%08X", UInt32(bitPattern: initial))
            hex.placeholder = "#RRGGBB"
            let sw = UIView()
            sw.backgroundColor = argbToUIColor(initial)
            var lock = false
            cp.onChange = { c in
                sw.backgroundColor = argbToUIColor(c)
                lock = true
                hex.text = String(format: "%08X", UInt32(bitPattern: c))
                lock = false
                onPick(c)
            }
            bind(hex) { s in
                if lock { return }
                var t = s.trimmingCharacters(in: .whitespaces)
                if t.hasPrefix("#") { t.removeFirst() }
                var v: Int32? = nil
                if t.count == 6, let u = UInt64(t, radix: 16) {
                    v = Int32(bitPattern: UInt32(0xFF000000) | UInt32(u))
                } else if t.count == 8, let u = UInt64(t, radix: 16) {
                    v = Int32(bitPattern: UInt32(u))
                }
                if let v = v {
                    cp.setColor(v)
                    sw.backgroundColor = argbToUIColor(v)
                    onPick(v)
                }
            }
            row.addArrangedSubview(wrap(hex, 0, 40, 0, 0, 0, 0))
            row.addArrangedSubview(wrap(sw, 52, 40, 0, 0, 0, 0))
            box.addArrangedSubview(row)
            var ref: Dlg? = nil
            put(box, pill("Pen: pick a color from the preview", "pipette") { [weak self] in
                ref?.dismiss()
                self?.startEyedropper { c in
                    self?.showColorPicker(c, onPick)
                    onPick(c)
                }
            }, 44, 6, 6)
            pushUndo()
            ref = Dlg(self).setTitle("Color").setView(box).setPositiveButton("Done") { [weak self] _, _ in
                // never leave the eyedropper armed after the dialog is gone —
                // it used to hijack the next preview tap
                self?.overlay.pick = nil
            }.show()
        }

        func startEyedropper(_ cb: @escaping (Int32) -> Void) {
            toast("Tap the preview to pick a color")
            overlay.pick = { [weak self] x, y in
                guard let self = self else { return }
                self.overlay.pick = nil   // one shot
                let w = Int(self.preview.bounds.width)
                let h = Int(self.preview.bounds.height)
                guard w > 0, h > 0 else { return }
                // PORT NOTE: PixelCopy.request → drawHierarchy snapshot read through a 1x1 context.
                let fmt = UIGraphicsImageRendererFormat()
                fmt.scale = 1
                let r = UIGraphicsImageRenderer(size: CGSize(width: w, height: h), format: fmt)
                let img = r.image { _ in self.preview.drawHierarchy(in: self.preview.bounds, afterScreenUpdates: false) }
                guard img.cgImage != nil else { self.toast("Could not read the preview"); return }
                let px = UnsafeMutablePointer<UInt8>.allocate(capacity: 4)
                px.initialize(repeating: 0, count: 4)
                defer { px.deallocate() }
                if let ctx = CGContext(data: px, width: 1, height: 1, bitsPerComponent: 8, bytesPerRow: 4,
                                       space: CGColorSpaceCreateDeviceRGB(),
                                       bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) {
                    ctx.interpolationQuality = .none
                    let ix = clamp(Int(x), 0, w - 1)
                    let iy = clamp(Int(y), 0, h - 1)
                    UIGraphicsPushContext(ctx)
                    img.draw(in: CGRect(x: -CGFloat(ix), y: -CGFloat(iy), width: CGFloat(w), height: CGFloat(h)))
                    UIGraphicsPopContext()
                    cb(argbColor(255, Int(px[0]), Int(px[1]), Int(px[2])))
                } else {
                    self.toast("Eyedropper is not available here")
                }
            }
            // and a timeout: if the user never taps the preview, stand down
            DispatchQueue.main.asyncAfter(deadline: .now() + 10) { [weak self] in
                self?.overlay.pick = nil
            }
        }

        func colorRow(_ cur: Int32, _ onPick: @escaping (Int32) -> Void) -> UIView {
            let colors: [Int32] = [Int32(bitPattern: 0xFFFFFFFF), Int32(bitPattern: 0xFF000000),
                                   Int32(bitPattern: 0xFFF44336), Int32(bitPattern: 0xFFFF9800),
                                   Int32(bitPattern: 0xFFFFEB3B), Int32(bitPattern: 0xFF22C55E),
                                   Int32(bitPattern: 0xFF00E5FF), Int32(bitPattern: 0xFF2979FF),
                                   Int32(bitPattern: 0xFF7C4DFF), Int32(bitPattern: 0xFFFF4081)]
            let row = hRow()
            let now = TapView()
            now.backgroundColor = argbToUIColor(cur)
            now.onClick = { [weak self] in self?.showColorPicker(cur, onPick) }
            row.addArrangedSubview(wrap(now, 44, 36, 4, 6, 10, 6))
            for col in colors {
                let v = TapView()
                v.backgroundColor = argbToUIColor(col)
                v.onClick = { onPick(col) }
                row.addArrangedSubview(wrap(v, 32, 32, 3, 6, 3, 6))
            }
            let more = RainbowCircleView()
            more.onClick = { [weak self] in self?.showColorPicker(cur, onPick) }
            row.addArrangedSubview(wrap(more, 36, 36, 8, 4, 4, 4))
            let sv = UIScrollView()
            sv.showsHorizontalScrollIndicator = false
            row.translatesAutoresizingMaskIntoConstraints = false
            sv.addSubview(row)
            NSLayoutConstraint.activate([
                row.leadingAnchor.constraint(equalTo: sv.contentLayoutGuide.leadingAnchor),
                row.trailingAnchor.constraint(equalTo: sv.contentLayoutGuide.trailingAnchor),
                row.topAnchor.constraint(equalTo: sv.contentLayoutGuide.topAnchor),
                row.bottomAnchor.constraint(equalTo: sv.contentLayoutGuide.bottomAnchor),
                row.heightAnchor.constraint(equalTo: sv.frameLayoutGuide.heightAnchor)
            ])
            return sv
        }

        func addColorRow(_ parent: UIStackView, _ cur: Int32, _ onPick: @escaping (Int32) -> Void) {
            parent.addArrangedSubview(wrap(colorRow(cur, onPick), 0, 48, 0, 0, 0, 0))
        }

        func setColorParam(_ l: Layer, _ cp: ColorParam, _ col: Int32) {
            let vals: [(String, Int)] = [("_r", colorRed(col)), ("_g", colorGreen(col)),
                                         ("_b", colorBlue(col)), ("_a", colorAlpha(col))]
            for (suffix, v) in vals {
                let tr = l.track(cp.key + suffix)
                tr.keys.removeAll()
                tr.base = Float(v) / 255
            }
        }

        func addColorParam(_ parent: UIStackView, _ l: Layer, _ cp: ColorParam) {
            func cur() -> Int32 {
                argbColor(ktInt(l.p(cp.key + "_a", 0) * 255), ktInt(l.p(cp.key + "_r", 0) * 255),
                          ktInt(l.p(cp.key + "_g", 0) * 255), ktInt(l.p(cp.key + "_b", 0) * 255))
            }
            let row = hRow()
            row.alignment = .fill
            row.backgroundColor = argbToUIColor(C.CARD)
            row.isLayoutMarginsRelativeArrangement = true
            row.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 14, bottom: 0, trailing: 10)
            let tv = UILabel()
            tv.text = cp.label
            tv.textColor = argbToUIColor(C.TEXT)
            tv.font = boldFont(15)
            tv.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
            row.addArrangedSubview(tv)
            let sw = TapView()
            sw.backgroundColor = argbToUIColor(cur())
            sw.onClick = { [weak self] in
                self?.showColorPicker(cur()) { col in
                    self?.setColorParam(l, cp, col)
                    sw.backgroundColor = argbToUIColor(col)
                    self?.render()
                }
            }
            row.addArrangedSubview(wrap(sw, 72, 34, 0, 0, 0, 0))
            put(parent, row, 52)
        }

        // ---------------------------------------------------------------- media + shapes

        func buildMedia() {
            let p: UIStackView = panelList
            text(p, "Media", C.TEXT, 16, true)
            put(p, pill("Import video", "import") { [weak self] in self?.pickMedia(R_VIDEO, [.movie, .audiovisualContent]) }, 44)
            put(p, pill("Import image", "import") { [weak self] in self?.pickMedia(R_IMAGE, [.image]) }, 44)
            put(p, pill("Import audio", "import") { [weak self] in self?.pickMedia(R_AUDIOFILE, [.audio]) }, 44)
            put(p, pill("Import 3D model (.glb)", "import") { [weak self] in self?.pickFile(R_GLB, glbTypes()) }, 44)
            put(p, pill("Import volume (.vdb)", "import") { [weak self] in self?.pickFile(R_GLB, vdbTypes()) }, 44)
            put(p, pill("Beat markers from an audio file", "graph") { [weak self] in self?.pickFile(R_BEAT, [.audio]) }, 44)
            var files: [URL] = (try? FileManager.default.contentsOfDirectory(
                at: Projects.mediaDir(), includingPropertiesForKeys: [.contentModificationDateKey])) ?? []
            files.sort { a, b in
                let da = (try? a.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate)?.timeIntervalSince1970 ?? 0
                let db = (try? b.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate)?.timeIntervalSince1970 ?? 0
                return da > db
            }
            files = Array(files.prefix(12))
            if !files.isEmpty { text(p, "Recent media", C.DIM, 13) }
            for f in files {
                let ext = f.pathExtension.lowercased()
                let type: LayerType
                if ext == "glb" || ext == "vdb" { type = .MODEL }
                else if ["mp4", "mov", "mkv", "webm", "3gp", "m4v"].contains(ext) { type = .VIDEO }
                else if ["m4a", "mp3", "aac", "wav", "ogg", "flac"].contains(ext) { type = .AUDIO }
                else { type = .IMAGE }
                let ic = type == .VIDEO ? "media" : (type == .MODEL ? "cube" : "media")
                put(p, pill(afterFirst(f.lastPathComponent, "_"), ic) { [weak self] in
                    self?.addMedia(f.path, type)
                }, 40)
            }
        }

        func buildShapes() {
            text(panelList, "Add shape", C.TEXT, 16, true)
            let all: [ShapeKind] = [.RECT, .ROUND, .CIRCLE, .TRIANGLE, .STAR]
            let names = all.map { cap($0.rawValue.lowercased()) }
            panelList.addArrangedSubview(chipRow(names, -1) { [weak self] i in
                guard let self = self else { return }
                let l = self.addLayer(.SHAPE)
                l.shape = all[i]
                self.render()
            })
        }

        // ---------------------------------------------------------------- edit

        func buildEdit(_ l: Layer) {
            let p: UIStackView = panelList
            switch l.type {
            case .TEXT:
                buildText(p, l)
            case .SHAPE:
                text(p, "Shape", C.TEXT, 16, true)
                let all: [ShapeKind] = [.RECT, .ROUND, .CIRCLE, .TRIANGLE, .STAR]
                let names = all.map { cap($0.rawValue.lowercased()) }
                p.addArrangedSubview(chipRow(names, all.firstIndex(of: l.shape) ?? 0) { [weak self] i in
                    guard let self = self else { return }
                    self.pushUndo()
                    l.shape = all[i]
                    self.refreshPanel(); self.render()
                })
                text(p, "Color", C.DIM)
                addColorRow(p, l.color) { [weak self] c in self?.pushUndo(); l.color = c; self?.render() }
            case .GROUP:
                text(p, "Group", C.TEXT, 16, true)
                text(p, "Put layers inside with Parent in their Transform panel. Tap the ^ arrow in the timeline to open or close the group. Groups can have effects, and 3D layers inside a group keep their 3D look.", C.DIM, 12)
                text(p, "Mask", C.GREEN, 13, true)
                text(p, "The top layer inside the group masks the layers beneath it.", C.DIM, 12)
                p.addArrangedSubview(chipRow(["None", "Alpha", "Inverted alpha", "Luma", "Inverted luma"], l.mask) { [weak self] i in
                    guard let self = self else { return }
                    self.pushUndo()
                    l.mask = i
                    self.refreshPanel(); self.render()
                })
            case .AUDIO:
                text(p, "Audio", C.TEXT, 16, true)
                text(p, l.name)
                addRow(p, l, Defs.audio[0])
                put(p, pill("Beat markers from this audio", "graph") { [weak self] in
                    self?.beatsFrom(l.imagePath ?? "", l.start)
                }, 42)
                text(p, "Plays during preview and is mixed into the render (the first audio layer; AAC or MP3 files work best).", C.DIM, 12)
            case .FLARE:
                text(p, "Optical Flare", C.TEXT, 16, true)
                put(p, pill("Customize", "edit", C.GREEN, C.ONDARK) { [weak self] in
                    self?.openFlareEditor(l)
                }, 48)
                for d in Defs.flare { addRow(p, l, d) }
                text(p, "Move the light with the Transform panel or drag it in the preview. Turn the 3D cube on and it follows a camera and shrinks with distance.", C.DIM, 12)
            case .ADJUST:
                text(p, "Adjustment layer", C.TEXT, 16, true)
                text(p, "Add effects to it in the Effects panel. They apply to everything below it for as long as the layer lasts.")
            case .CAMERA:
                text(p, "Camera", C.TEXT, 16, true)
                addRow(p, l, Defs.camera[0])
                text(p, "Position and rotate it in Transform. It controls every layer whose 3D cube is on.")
            case .NULL:
                text(p, "Null object", C.TEXT, 16, true)
                text(p, "An invisible layer. Turn its 3D cube on, then pick it as Parent in other layers' Transform panel.")
            default:
                text(p, cap(l.type.rawValue.lowercased()), C.TEXT, 16, true)
                text(p, l.name)
                if l.type == .VIDEO {
                    text(p, "Length: " + String(format: "%.1f", l.srcDur) + " s. Decoded with the system decoder.")
                    put(p, pill("Extract audio", "export") { [weak self] in self?.extractAudio(l) }, 42)
                    put(p, pill("Beat markers from this video", "graph") { [weak self] in
                        self?.beatsFrom(l.imagePath ?? "", l.start)
                    }, 42)
                }
                if l.type == .MODEL {
                    text(p, "Static .glb mesh. Transforms are baked on load and everything is drawn from one GPU buffer per part.")
                }
            }
        }

        func buildText(_ p: UIStackView, _ l: Layer) {
            text(p, "Text", C.TEXT, 16, true)
            p.addArrangedSubview(chipRow(["Text", "Style", "Animate"], textTab) { [weak self] i in
                guard let self = self else { return }
                self.textTab = i
                self.refreshPanel()
            })
            switch textTab {
            case 0:
                let et = makeField(l.text)
                bind(et) { [weak self] s in
                    l.text = s
                    self?.render()
                }
                put(p, et, 44)
                text(p, "Alignment", C.GREEN, 13, true)
                p.addArrangedSubview(chipRow(["Left", "Center", "Right"], l.align) { [weak self] i in
                    guard let self = self else { return }
                    self.pushUndo()
                    l.align = i
                    self.render()
                })
                text(p, "Letter case", C.GREEN, 13, true)
                p.addArrangedSubview(chipRow(["As typed", "UPPER", "lower"], l.caps) { [weak self] i in
                    guard let self = self else { return }
                    self.pushUndo()
                    l.caps = i
                    self.render()
                })
                let sb = SwitchRow()
                sb.label = "Bold"; sb.on = l.bold
                sb.onToggle = { [weak self] v in self?.pushUndo(); l.bold = v; self?.render() }
                put(p, sb, 52)
                let si = SwitchRow()
                si.label = "Italic"; si.on = l.italic
                si.onToggle = { [weak self] v in self?.pushUndo(); l.italic = v; self?.render() }
                put(p, si, 52)
                let su = SwitchRow()
                su.label = "Underline"; su.on = l.underline
                su.onToggle = { [weak self] v in self?.pushUndo(); l.underline = v; self?.render() }
                put(p, su, 52)
                let ss = SwitchRow()
                ss.label = "Strikethrough"; ss.on = l.strike
                ss.onToggle = { [weak self] v in self?.pushUndo(); l.strike = v; self?.render() }
                put(p, ss, 52)
                addRow(p, l, Defs.text[4])
                text(p, "Font", C.GREEN, 13, true)
                let fams = ["sans-serif", "serif", "monospace", "cursive", "casual", "sans-serif-condensed",
                            "sans-serif-light", "sans-serif-medium", "sans-serif-black", "serif-monospace"]
                let names = ["Sans", "Serif", "Mono", "Cursive", "Casual", "Condensed", "Light", "Medium", "Black", "Typewriter"]
                let sel = l.fontPath != nil ? -1 : (fams.firstIndex(of: l.font) ?? -1)
                p.addArrangedSubview(chipRow(names, sel) { [weak self] i in
                    guard let self = self else { return }
                    self.pushUndo()
                    l.font = fams[i]
                    l.fontPath = nil
                    self.refreshPanel(); self.render()
                })
                put(p, pill(l.fontPath != nil ? "Custom font loaded. Import another" : "Import a font file (.ttf or .otf)",
                            "import") { [weak self] in self?.pickFile(R_FONT, [.data]) }, 42)
                text(p, "Color", C.GREEN, 13, true)
                addColorRow(p, l.color) { [weak self] c in self?.pushUndo(); l.color = c; self?.render() }
                addRow(p, l, Defs.transform[2], "Size")
            case 1:
                text(p, "Stroke", C.GREEN, 13, true)
                addRow(p, l, Defs.text[0])
                addColorRow(p, l.strokeColor) { [weak self] c in self?.pushUndo(); l.strokeColor = c; self?.render() }
                text(p, "Stroke position", C.DIM, 12)
                p.addArrangedSubview(chipRow(["Outside", "Center", "Inside"], l.strokePos) { [weak self] i in
                    guard let self = self else { return }
                    self.pushUndo()
                    l.strokePos = i
                    self.render()
                })
                text(p, "Corners", C.DIM, 12)
                p.addArrangedSubview(chipRow(["Round", "Sharp"], l.strokeJoin) { [weak self] i in
                    guard let self = self else { return }
                    self.pushUndo()
                    l.strokeJoin = i
                    self.render()
                })
                text(p, "Second stroke (outside the first)", C.GREEN, 13, true)
                addRow(p, l, Defs.text[8])
                addColorRow(p, l.stroke2Color) { [weak self] c in self?.pushUndo(); l.stroke2Color = c; self?.render() }
                text(p, "Border box", C.GREEN, 13, true)
                addRow(p, l, Defs.text[1])
                addRow(p, l, Defs.text[2])
                addRow(p, l, Defs.text[9])
                addColorRow(p, l.borderColor) { [weak self] c in self?.pushUndo(); l.borderColor = c; self?.render() }
                let bd = SwitchRow()
                bd.label = "Dashed border"; bd.on = l.borderDash
                bd.onToggle = { [weak self] v in self?.pushUndo(); l.borderDash = v; self?.render() }
                put(p, bd, 52)
                text(p, "Box fill", C.DIM, 12)
                addColorRow(p, colorAlpha(l.borderFill) == 0 ? Int32(bitPattern: 0xFF000000) : l.borderFill) { [weak self] c in
                    self?.pushUndo(); l.borderFill = c; self?.render()
                }
                put(p, pill("No box fill", "close") { [weak self] in
                    self?.pushUndo(); l.borderFill = 0; self?.refreshPanel(); self?.render()
                }, 40)
                text(p, "Shadow", C.GREEN, 13, true)
                let sh = SwitchRow()
                sh.label = "Shadow"; sh.on = l.shadowOn
                sh.onToggle = { [weak self] v in
                    guard let self = self else { return }
                    self.pushUndo()
                    l.shadowOn = v
                    self.refreshPanel(); self.render()
                }
                put(p, sh, 52)
                if l.shadowOn {
                    addColorRow(p, l.shadowColor) { [weak self] c in self?.pushUndo(); l.shadowColor = c; self?.render() }
                    addRow(p, l, Defs.text[5])
                    addRow(p, l, Defs.text[6])
                    addRow(p, l, Defs.text[7])
                }
                text(p, "Spacing", C.GREEN, 13, true)
                addRow(p, l, Defs.text[3])
            default:
                buildTextAnim(p, l)
            }
        }

        func buildTextAnim(_ p: UIStackView, _ l: Layer) {
            put(p, pill("Add animation", "plus", C.GREEN, C.ONDARK) { [weak self] in
                guard let self = self else { return }
                Dlg(self).setTitle("Add animation").setItems(TextAnim.TYPES) { [weak self] _, w in
                    guard let self = self else { return }
                    self.pushUndo()
                    let a = TextAnim(w, (w == 8 || w == 10) ? 2 : 0)
                    if w == 5 { a.scaleFrom = 0 }
                    if w == 6 { a.rotFrom = 90 }
                    l.anims.append(a)
                    self.expanded.insert("anim:\(l.id):\(l.anims.count - 1)")
                    self.refreshPanel(); self.render()
                }.show()
            }, 46)
            if l.anims.isEmpty {
                text(p, "Animations play per letter. Stack several, for example Slide up in plus Fade out. Outline draw animates the stroke from the Style tab.", C.DIM, 12)
            }
            for (i, a) in l.anims.enumerated() {
                let key = "anim:\(l.id):\(i)"
                let isOpen = expanded.contains(key)
                let card = vStack()
                let bar = hRow()
                bar.backgroundColor = argbToUIColor(C.CARD)
                bar.isLayoutMarginsRelativeArrangement = true
                bar.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 14, bottom: 0, trailing: 2)
                let tv = UILabel()
                tv.text = a.name()
                tv.textColor = argbToUIColor(C.TEXT)
                tv.font = boldFont(16)
                tv.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
                bar.addArrangedSubview(tv)
                let chev = IconView(isOpen ? "chev_up" : "chev_down", C.DIM, 20)
                chev.onClick = { [weak self] in
                    guard let self = self else { return }
                    if self.expanded.contains(key) { self.expanded.remove(key) } else { self.expanded.insert(key) }
                    self.refreshPanel()
                }
                bar.addArrangedSubview(wrap(chev, 40, 48, 0, 0, 0, 0))
                let del = IconView("trash", C.RED, 20)
                del.onClick = { [weak self] in
                    guard let self = self else { return }
                    self.pushUndo()
                    l.anims.removeAll { $0 === a }
                    self.refreshPanel(); self.render()
                }
                bar.addArrangedSubview(wrap(del, 40, 48, 0, 0, 0, 0))
                card.addArrangedSubview(bar)
                if isOpen {
                    card.addArrangedSubview(chipRow(["In", "Out", "Loop"], a.mode) { [weak self] m in
                        guard let self = self else { return }
                        self.pushUndo()
                        a.mode = m
                        self.refreshPanel(); self.render()
                    })
                    addPlain(card, "Start (s)", 0, 10, a.start, 2) { [weak self] v in a.start = v; self?.render() }
                    addPlain(card, "Duration (s)", 0.05, 5, a.dur, 2) { [weak self] v in a.dur = v; self?.render() }
                    addPlain(card, "Delay per letter (s)", 0, 0.5, a.stagger, 2) { [weak self] v in a.stagger = v; self?.render() }
                    addPlain(card, "Distance", 0, 3, a.distance, 2) { [weak self] v in a.distance = v; self?.render() }
                    addPlain(card, "Scale from", 0, 3, a.scaleFrom, 2) { [weak self] v in a.scaleFrom = v; self?.render() }
                    addPlain(card, "Rotate from (deg)", -360, 360, a.rotFrom, 0) { [weak self] v in a.rotFrom = v; self?.render() }
                    addPlain(card, "Speed (loops)", 0, 10, a.speed, 1) { [weak self] v in a.speed = v; self?.render() }
                    text(card, "Easing", C.DIM, 12)
                    card.addArrangedSubview(chipRow(["Linear", "Ease out", "Ease in-out", "Bounce", "Custom curve"], a.ease) { [weak self] e in
                        guard let self = self else { return }
                        self.pushUndo()
                        a.ease = e
                        if e == 4 { a.curve.ease = Ease.CUSTOM }
                        self.refreshPanel(); self.render()
                    })
                    if a.ease == 4 {
                        let gv = GraphView(frame: .zero)
                        gv.key = a.curve
                        gv.onBegin = { [weak self] in self?.pushUndo() }
                        gv.onChange = { [weak self] in self?.render() }
                        put(card, gv, 200)
                    }
                    let sf = SwitchRow()
                    sf.label = "Fade while moving"; sf.on = a.fade
                    sf.onToggle = { [weak self] v in self?.pushUndo(); a.fade = v; self?.render() }
                    put(card, sf, 52)
                }
                put(p, card, 0, 3, 6)
            }
        }
}
