// Particles.swift — deterministic particle field in the style of CC Particle World (Render).
//
// State is a pure function of (seed, time): every particle's age is
// `t mod life` offset by a hash of its index. No state survives between
// frames, so scrubbing, caching and export produce identical results.
// Positions are returned in layer-local 3D space (x/y in world units, z depth).

import Foundation

struct Particle {
    var x: Float
    var y: Float
    var z: Float
    var size: Float   // relative size multiplier
    var life: Float   // 0 fresh → 1 dead
    var soft: Float   // 0 hard dot … 1 fully blurred (depth of field)
}

enum ParticlesSim {

    static func field(count: Int, spread: Float, speed: Float, gravity: Float,
                      life: Float, seed: Float, dirX: Float, dirY: Float,
                      t: Float, ar: Float,
                      posX: Float = 0, posY: Float = 0, posZ: Float = 0,
                      radX: Float = 0.5, radY: Float = 0.5, radZ: Float = 0,
                      dirZ: Float = 0, resist: Float = 0, wobble: Float = 0,
                      sizeVar: Float = 0.7, sizeEnd: Float = 1,
                      dof: Float = 0, focus: Float = 0) -> [Particle] {
        var out: [Particle] = []
        let n = max(1, min(count, 6000))
        out.reserveCapacity(n)
        let time = max(0, t)
        let lf = max(life, 0.05)
        for i in 0..<n {
            let fi = Float(i)
            let h0 = hash(seed * 131.0 + fi)
            let h1 = hash(seed * 977.0 + fi * 7.0)
            let h2 = hash(seed * 3313.0 + fi * 13.0)
            let h3 = hash(seed * 6151.0 + fi * 29.0)
            let h4 = hash(seed * 17.0 + fi * 3.0)
            let h5 = hash(seed * 4001.0 + fi * 19.0)
            let h6 = hash(seed * 811.0 + fi * 23.0)

            var age = time - h0 * lf
            age = age.truncatingRemainder(dividingBy: lf)
            if age < 0 { age += lf }
            let p = age / lf

            // producer: a box/ellipsoid volume (Radius X/Y/Z)
            let bx = (h1 * 2 - 1) * radX + posX
            let by = (h2 * 2 - 1) * radY + posY
            let bz = (h5 * 2 - 1) * radZ + posZ

            // physics: direction + velocity variance, resistance, gravity, wobble
            let vx = (dirX + (h3 - 0.5) * spread * 0.6) * speed
            let vy = (dirY + (h4 - 0.5) * spread * 0.6) * speed
            let vz = (dirZ + (h6 - 0.5) * spread * 0.6) * speed
            var travel = age
            if resist > 0.001 {
                let k = resist * 4
                travel = (1 - exp(-k * age)) / k
            }
            var x = bx + vx * travel
            var y = by + vy * travel + gravity * travel * travel * 0.5
            let z = bz + vz * travel
            if wobble > 0.001 {
                x += sin(age * 1.7 + h3 * 6.283) * wobble * 0.15
                y += cos(age * 1.3 + h4 * 6.283) * wobble * 0.15
            }

            // many tiny particles, a few big ones (like a star-dust field)
            let base = (1 - sizeVar) + sizeVar * (0.2 + 1.8 * h2 * h2 * h2 * 2.2)
            let sz = base * (1 + (sizeEnd - 1) * p)
            let soft = min(1, max(0, abs(z - focus) * dof * 0.8))
            out.append(Particle(x: x, y: y, z: z, size: sz, life: p, soft: soft))
        }
        return out
    }

    private static func hash(_ x: Float) -> Float {
        var n = UInt32(truncatingIfNeeded: Int64(x * 8192.0))
        n = n &* 747796405 &+ 2891336453
        n = ((n >> ((n >> 28) + 4)) ^ n) &* 277803737
        n = (n >> 22) ^ n
        return Float(n % 100000) / 100000
    }
}
