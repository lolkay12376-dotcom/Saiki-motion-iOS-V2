// Widgets.swift — small reusable widgets: chips, pills, tool buttons, chip rows, effect cards, switches, tabs, toggles, fill slider.

import UIKit
import Foundation

// MARK: - ChipView

/// Small outlined text chip, e.g. the preview quality switch.
final class ChipView: TapView {
    var text: String

    init(_ text: String) {
        self.text = text
        super.init(frame: .zero)
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let w = bounds.width, h = bounds.height
        let r = CGRect(x: 2, y: 6, width: w - 4, height: h - 12)
        strokeRoundRect(c, r, 8, 1.5, Int32(bitPattern: 0xFF4A4A52))
        drawText(text, w / 2, h / 2 + 4.5, color: C.TEXT, size: 13, bold: true, align: .center)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - PillButton

/// Rounded text button, optionally with a leading icon. Used for "Add Effect" etc.
final class PillButton: TapView {
    var text: String
    var icon: String?
    private let fillColor: Int32
    private let textColor: Int32

    init(_ text: String, _ icon: String?, _ fillColor: Int32, _ textColor: Int32) {
        self.text = text
        self.icon = icon
        self.fillColor = fillColor
        self.textColor = textColor
        super.init(frame: .zero)
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let w = bounds.width, h = bounds.height
        var col = argbToUIColor(fillColor)
        if isHighlighted { col = col.withAlphaComponent(170.0 / 255.0) }
        c.setFillColor(col.cgColor)
        c.addPath(CGPath(roundedRect: CGRect(x: 0, y: 0, width: w, height: h), cornerWidth: 12, cornerHeight: 12, transform: nil))
        c.fillPath()
        let tw = measureText(text, 15, true)
        let iw: CGFloat = icon != nil ? 22 + 8 : 0
        var x = (w - tw - iw) / 2
        if let ic = icon {
            Icons.draw(c, ic, x + 11, h / 2, 20, textColor)
            x += iw
        }
        drawText(text, x, h / 2 + 5, color: textColor, size: 15, bold: true, align: .left)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - ToolButton

/// Icon above a label; used for the bottom tool bar.
final class ToolButton: TapView {
    var icon: String
    var label: String
    var tint: Int32 = C.TEXT

    init(_ icon: String, _ label: String) {
        self.icon = icon
        self.label = label
        super.init(frame: .zero)
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let w = bounds.width, h = bounds.height
        let col: Int32 = isHighlighted
            ? Int32(bitPattern: UInt32(bitPattern: tint) | 0x80000000)
            : tint
        Icons.draw(c, icon, w / 2, h / 2 - 7, 24, col)
        drawText(label, w / 2, h - 10, color: col, size: 11, align: .center)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - chipRow

/// Horizontal row of selectable pills (Kotlin top-level fun chipRow).
/// Buttons are 92x38 at 3pt side / 4pt vertical margins → the row is 46pt tall.
private final class ChipRowScrollView: UIScrollView {
    override var intrinsicContentSize: CGSize { CGSize(width: UIView.noIntrinsicMetric, height: 46) }
}

func chipRow(_ labels: [String], _ sel: Int, _ onPick: @escaping (Int) -> Void) -> UIView {
    let sv = ChipRowScrollView()
    sv.showsHorizontalScrollIndicator = false
    sv.clipsToBounds = true
    let row = UIView(frame: CGRect(x: 0, y: 0, width: CGFloat(labels.count) * 98 + 3, height: 46))
    for (i, nm) in labels.enumerated() {
        let on = i == sel
        let b = PillButton(nm, nil, on ? C.GREEN : C.CARD2, on ? C.ONDARK : C.TEXT)
        b.onClick = { onPick(i) }
        b.frame = CGRect(x: 3 + CGFloat(i) * 98, y: 4, width: 92, height: 38)
        row.addSubview(b)
    }
    sv.addSubview(row)
    sv.contentSize = row.frame.size
    return sv
}

// MARK: - SwitchRow

/// Card with a label and an on/off switch. Used for every two-state setting.
final class SwitchRow: TapView {
    var label = ""
    var captionOn = "On"
    var captionOff = "Off"
    var on = false
    var onToggle: ((Bool) -> Void)? = nil

    override init(frame: CGRect) {
        super.init(frame: frame)
        onClick = { [weak self] in
            guard let self = self else { return }
            self.on = !self.on
            self.onToggle?(self.on)
            self.setNeedsDisplay()
        }
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let w = bounds.width, h = bounds.height
        fillRoundRect(c, CGRect(x: 0, y: 0, width: w, height: h), 10, C.CARD)
        drawText(label, 14, h / 2 + 5, color: C.TEXT, size: 15, bold: true, align: .left)
        let sw: CGFloat = 50
        let sh: CGFloat = 28
        let x1 = w - 14
        let x0 = x1 - sw
        let y0 = (h - sh) / 2
        fillRoundRect(c, CGRect(x: x0, y: y0, width: sw, height: sh), sh / 2, on ? C.GREEN : Int32(bitPattern: 0xFF3A3A44))
        fillCircle(c, on ? x1 - sh / 2 : x0 + sh / 2, y0 + sh / 2, sh / 2 - 3, Int32(bitPattern: 0xFFFFFFFF))
        drawText(on ? captionOn : captionOff, x0 - 10, h / 2 + 4, color: C.DIM, size: 12, align: .right)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - TabBar

/// Two to four text tabs with an accent underline under the selected one.
final class TabBar: TapView {
    private let labels: [String]
    var sel: Int
    private let onPick: (Int) -> Void

    init(_ labels: [String], _ sel: Int, _ onPick: @escaping (Int) -> Void) {
        self.labels = labels
        self.sel = sel
        self.onPick = onPick
        super.init(frame: .zero)
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let w = bounds.width / CGFloat(labels.count)
        for i in 0..<labels.count {
            let on = i == sel
            drawText(labels[i], w * (CGFloat(i) + 0.5), bounds.height / 2 + 5,
                     color: on ? C.GREEN : C.DIM, size: 15, bold: true, align: .center)
            if on {
                strokeLine(c, w * CGFloat(i) + 16, bounds.height - 3, w * CGFloat(i + 1) - 16, bounds.height - 3, 3, C.GREEN)
            }
        }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        let i = clamp(Int(t.location(in: self).x / (bounds.width / CGFloat(labels.count))), 0, labels.count - 1)
        if i != sel { sel = i; setNeedsDisplay(); onPick(i) }
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - PillToggle

/// Small pill toggle used in the top bar for motion blur. Tap to switch, long-press for settings.
final class PillToggle: TapView {
    var on = false {
        didSet { setNeedsDisplay() }
    }
    // onClick is inherited from TapView; redeclaring it as a stored
    // property is illegal ("cannot override with a stored property").
    var onLong: (() -> Void)? = nil

    override init(frame: CGRect) {
        super.init(frame: frame)
        let lp = UILongPressGestureRecognizer(target: self, action: #selector(longPressed(_:)))
        lp.minimumPressDuration = 0.4
        lp.cancelsTouchesInView = false
        addGestureRecognizer(lp)
    }

    @objc private func longPressed(_ g: UILongPressGestureRecognizer) {
        if g.state == .began && onLong != nil { onLong?() }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesEnded(touches, with: event)
        onClick?()
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let w: CGFloat = 40
        let h: CGFloat = 22
        let l = (bounds.width - w) / 2
        let t = (bounds.height - h) / 2
        fillRoundRect(c, CGRect(x: l, y: t, width: w, height: h), h / 2, on ? C.GREEN : Int32(bitPattern: 0xFF55555E))
        let cx = on ? l + w - h / 2 : l + h / 2
        fillCircle(c, cx, t + h / 2, h / 2 - 3, Int32(bitPattern: 0xFFFFFFFF))
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - FillSlider

/// Rounded fill slider (drag across the bar). Used for playback speed.
final class FillSlider: UIControl {
    var lo: Float = 0
    var hi: Float = 1
    var value: Float = 0
    var suffix = "x"
    var onBegin: (() -> Void)? = nil
    var onChange: ((Float) -> Void)? = nil
    private var dragging = false

    override init(frame: CGRect) { super.init(frame: frame) }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        fillRoundRect(c, CGRect(x: 0, y: 0, width: bounds.width, height: bounds.height), bounds.height / 2, C.CARD)
        let f = CGFloat(clamp((value - lo) / (hi - lo), 0, 1))
        let fill = isUserInteractionEnabled ? C.GREEN : Int32(bitPattern: 0xFF55555E)
        c.saveGState()
        c.clip(to: CGRect(x: 0, y: 0, width: bounds.width * f, height: bounds.height))
        fillRoundRect(c, CGRect(x: 0, y: 0, width: bounds.width, height: bounds.height), bounds.height / 2, fill)
        c.restoreGState()
        drawText(String(format: "%.2f", value) + suffix, bounds.width / 2, bounds.height / 2 + 5,
                 color: isUserInteractionEnabled ? C.ONDARK : C.DIM, size: 15, bold: true, align: .center)
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard isUserInteractionEnabled, let t = touches.first else { return }
        dragging = true
        disallowParentScrollInterception(self, true)
        onBegin?()
        setv(t.location(in: self).x)
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard dragging, let t = touches.first else { return }
        setv(t.location(in: self).x)
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        dragging = false
        disallowParentScrollInterception(self, false)
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        dragging = false
        disallowParentScrollInterception(self, false)
    }

    private func setv(_ x: CGFloat) {
        let v = lo + clamp(Float(x / bounds.width), 0, 1) * (hi - lo)
        value = Float(kotlinRound(v * 20)) / 20
        value = clamp(value, lo, hi)
        setNeedsDisplay()
        onChange?(value)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - EffectCard

/// Effect tile whose icon automatically swipes between the processed and the original anime portrait.
final class EffectCard: TapView {
    var name: String
    var category: String
    var before: UIImage? = nil
    var after: UIImage? = nil
    var badge = false
    var thumbHeight: Float = 0.8
    var anim = "swipe"
    var thumbId: String? = nil
    var origId: String? = nil

    init(_ name: String, _ category: String) {
        self.name = name
        self.category = category
        super.init(frame: .zero)
    }

    /// PORT NOTE: postInvalidateOnAnimation / postInvalidateDelayed replaced with a
    /// scheduled setNeedsDisplay (60fps while swiping, 400ms while "rendering").
    // Lag fix: ONE shared 20fps ticker redraws only the cards actually on screen.
    // (Every card of the effects grid lives in the view tree at once; each used to
    // run its own redraw timer, so 70+ cards repainted continuously, starved the
    // main thread and swallowed taps — "can't close the panel, super laggy".)
    private func scheduleRedraw(_ delay: TimeInterval) { }

    var isVisibleOnScreen: Bool {
        guard let w = window, !isHidden, alpha > 0.01 else { return false }
        return convert(bounds, to: w).intersects(w.bounds)
    }

    override func didMoveToWindow() {
        super.didMoveToWindow()
        if window != nil {
            EffectCardTicker.shared.add(self)
            setNeedsDisplay()
        } else {
            EffectCardTicker.shared.remove(self)
        }
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let w = bounds.width
        let th = min(w * CGFloat(thumbHeight), bounds.height - 44)
        fillRoundRect(c, CGRect(x: 0, y: 0, width: w, height: bounds.height), 12, C.CARD)
        // thumbnail area, top corners rounded 12
        c.saveGState()
        let clipPath = UIBezierPath(roundedRect: CGRect(x: 0, y: 0, width: w, height: th),
                                    byRoundingCorners: [.topLeft, .topRight],
                                    cornerRadii: CGSize(width: 12, height: 12)).cgPath
        c.addPath(clipPath)
        c.clip()
        // The card picks its pictures up from the EffectThumbs caches as they arrive;
        // until then the cheap raw() placeholder shows the sample picture.
        if let oid = origId {
            if let gl = EffectThumbs.cache[oid] {
                before = gl
            } else if before == nil {
                before = EffectThumbs.raw(String(oid.dropFirst("__orig:".count)))
            }
        }
        if let tid = thumbId, after == nil {
            after = EffectThumbs.cache[tid]
        }
        let a = after
        let b = before
        if let a = a, let b = b {
            let ph = Float(nowMs() % 3600) / 3600.0
            let u: Float = ph < 0.5 ? ph * 2 : 2 - ph * 2
            drawFit(c, b, 0, w, th)
            switch anim {
            case "fade":
                c.saveGState()
                c.setAlpha(CGFloat(clamp(u, 0, 1)))
                drawFit(c, a, 0, w, th)
                c.restoreGState()
            case "cut":
                if ph >= 0.5 { drawFit(c, a, 0, w, th) }
            case "wipe":
                let ey = th * CGFloat(0.06 + 0.88 * u)
                c.saveGState()
                c.clip(to: CGRect(x: 0, y: 0, width: w, height: ey))
                drawFit(c, a, 0, w, th)
                c.restoreGState()
                strokeLine(c, 0, ey, w, ey, 2, Int32(bitPattern: 0xFFFFFFFF))
            default:
                let ex = w * CGFloat(0.08 + 0.84 * u)
                c.saveGState()
                c.clip(to: CGRect(x: 0, y: 0, width: ex, height: th))
                drawFit(c, a, 0, w, th)
                c.restoreGState()
                strokeLine(c, ex, 0, ex, th, 2, Int32(bitPattern: 0xFFFFFFFF))
                fillCircle(c, ex, th / 2, 9, Int32(bitPattern: 0xFFFFFFFF))
                fillCircle(c, ex, th / 2, 3.5, Int32(bitPattern: 0xFF111114))
            }
            scheduleRedraw(1.0 / 30.0)
        } else if let b = b {
            drawFit(c, b, 0, w, th)
            drawText("Rendering...", w / 2, th - 8, color: Int32(bitPattern: 0xFFFFFFFF), size: 11, align: .center)
            scheduleRedraw(0.3)
        } else {
            fillRect(c, CGRect(x: 0, y: 0, width: w, height: th), C.CARD2)
            drawText("rendering", w / 2, th / 2, color: C.DIM, size: 12, align: .center)
            scheduleRedraw(0.4)
        }
        c.restoreGState()
        drawText(name, 10, th + 22, color: C.TEXT, size: 14, bold: true, align: .left)
        drawText(category, 10, th + 38, color: C.DIM, size: 11, align: .left)
        if badge { fillCircle(c, w - 14, th + 20, 5, C.GREEN) }
    }

    /// Center-crop fit (Android drawBitmap with src center-crop rect + dst rect).
    private func drawFit(_ c: CGContext, _ img: UIImage, _ x: CGFloat, _ w: CGFloat, _ h: CGFloat) {
        let bw = img.size.width, bh = img.size.height
        guard bw > 0, bh > 0 else { return }
        let s = max(w / bw, h / bh)
        let dw = bw * s, dh = bh * s
        let dx = x + (w - dw) / 2
        let dy = (h - dh) / 2
        c.saveGState()
        c.clip(to: CGRect(x: x, y: 0, width: w, height: h))
        img.draw(in: CGRect(x: dx, y: dy, width: dw, height: dh))
        c.restoreGState()
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}


/// Shared redraw clock for EffectCard (see EffectCard.didMoveToWindow).
final class EffectCardTicker {
    static let shared = EffectCardTicker()
    private let cards = NSHashTable<EffectCard>.weakObjects()
    private var link: CADisplayLink?

    func add(_ c: EffectCard) {
        cards.add(c)
        if link == nil {
            let l = CADisplayLink(target: self, selector: #selector(tick))
            l.preferredFramesPerSecond = 20
            l.add(to: .main, forMode: .common)
            link = l
        }
    }

    func remove(_ c: EffectCard) {
        cards.remove(c)
        if cards.count == 0 { link?.invalidate(); link = nil }
    }

    @objc private func tick() {
        for c in cards.allObjects where c.isVisibleOnScreen { c.setNeedsDisplay() }
    }
}
