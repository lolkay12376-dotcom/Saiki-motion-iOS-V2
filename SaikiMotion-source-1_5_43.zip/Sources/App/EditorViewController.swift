// iOS port of EditorActivity.kt — SaikiMotion (the editor shell)
//
// The editor used to be one 4,200-line file. It is now split by feature so
// each screen is easy to find and debug — this file holds the class itself:
// stored state, lifecycle, the UI skeleton (top bar / preview / transport /
// timeline / toolbar / panel rail), playback, undo-redo and the EditHost /
// TimelineHost glue. Everything else lives in Sources/App/Editor/:
//
//   EditorAudio.swift        AVAudioPlayer plumbing
//   EditorFlare.swift        Optical Flare library + customization overlay
//   EditorDialogs.swift      motion blur / parent / expressions / scene setup / render
//   EditorLayers.swift       add, clone, copy, paste, group, split, trim, menus
//   EditorImport.swift       every picker (video/image/audio/glb/vdb/font/fx/preset)
//   EditorPanelsText.swift   panel framework + Media/Shapes/Edit/Text + color rows
//   EditorTransform.swift    Transform panel, anchor & align, parenting
//   EditorBlendSpeed.swift   Blending + Speed panels, time remap
//   EditorEffects.swift      Effects panel: applied / browse / presets / custom
//   EditorGraph.swift        the graph editor panel
//   EditorSceneSetup.swift   Scene Setup mode (orbit editing camera)
//   EditorHelpers.swift      field binding, string helpers, pretty JSON
//
// PORT NOTES (lifecycle + platform):
//  - Activity → UIViewController built 100% programmatically. onCreate → viewDidLoad,
//    onResume → viewWillAppear, onPause → viewWillDisappear, onDestroy → deinit.
//  - onBackPressed → onBack(): closes the panel / deselects / pops or dismisses the VC.
//    The navigation bar is hidden while the editor is on screen (the editor has its own top bar).
//  - onConfigurationChanged (full buildUi() rebuild) → RootLayout computes the portrait and
//    landscape layouts dynamically in layoutSubviews, so no rebuild is needed on rotation.
//  - windowSoftInputMode adjustResize → UIResponder.keyboardWillShow/Hide notifications that
//    shrink the root layout (and the full-screen Effects panel) above the keyboard.
//  - Choreographer.postFrameCallback → CADisplayLink on .main/.common with a weak proxy target
//    (the link retains the proxy, the proxy does not retain the VC, so deinit can invalidate).
//  - android.media.MediaPlayer → AVAudioPlayer: players are created + prepared on a background
//    thread (prepareAsync parity); SEEK_CLOSEST → currentTime assignment; drift window 140 ms.
//  - ACTION_GET_CONTENT → UIDocumentPickerViewController(asCopy: true); the Kotlin
//    ContentResolver copies go through ProjectIO.copyMediaIntoSandbox (same "<ts>_<name>"
//    and "<ts>_font.ttf" naming).
//  - MediaMetadataRetriever duration → AVAsset.duration, loaded off the main thread.
//  - PixelCopy.request(preview, ...) → a drawHierarchy snapshot of the GLKView read through a
//    1x1 bitmap context (eyedropper).
//  - MediaStore Downloads/Music writes → <Documents>/SaikiMotion (ProjectIO convention; the
//    location string in the toasts mirrors it).
//  - onSaveInstanceState/savedInstanceState: iOS does not restore editor state after a kill;
//    the selected layer only survives within a session (selId is a plain property).
//  - Kotlin `selectedId` / `autoKey` properties renamed selId / autoKeyOn (the TimelineHost /
//    EditHost protocols require methods with those exact names; a stored property with the same
//    name as a method is not a safe Swift pattern).
//  - Dlg is an overlay on the key window (not a presented VC), so the Kotlin
//    `setView(ScrollView(box))` wrappers are dropped — Dlg wraps long content in its own
//    CapScroll already.

import UIKit
import AVFoundation
import CoreMedia
import UniformTypeIdentifiers
import PhotosUI


// Panel ids (Kotlin P_*) and picker request codes (Kotlin R_*), at file scope so closures with
// [weak self] capture lists can reference them without an implicit-self error.
let P_NONE = 0; let P_MEDIA = 1; let P_SHAPES = 2; let P_EDIT = 3
let P_XFORM = 4; let P_FX = 5; let P_BLEND = 6; let P_SPEED = 7; let P_GRAPH = 8
let R_VIDEO = 51; let R_IMAGE = 52; let R_GLB = 53; let R_FX = 54; let R_PRESET = 55
let R_BEAT = 57; let R_AUDIOFILE = 58; let R_FONT = 59

/// Kotlin ACTION_GET_CONTENT "*/*" for the .glb picker: any file, GLB files first.
func glbTypes() -> [UTType] {
    var ts: [UTType] = [.data]
    if let g = UTType(filenameExtension: "glb") { ts.insert(g, at: 0) }
    return ts
}

/// Same shape for OpenVDB volumes: any file, .vdb files first.
func vdbTypes() -> [UTType] {
    var ts: [UTType] = [.data]
    if let v = UTType(filenameExtension: "vdb") { ts.insert(v, at: 0) }
    return ts
}

/// CADisplayLink target that does not retain the view controller (see PORT NOTES above).
private final class DisplayLinkProxy: NSObject {
    weak var vc: EditorViewController?
    @objc func tick(_ link: CADisplayLink) { vc?.doFrame() }
}

/// LinearLayout-with-weights replacement for the editor root. Lays out the fixed-height rows
/// and the two weighted areas (preview 1.0 / timeline 1.15); landscape splits the width
/// 46% / 54% exactly like the Kotlin orientation branch. panelBox height -1 = dynamic
/// (300 pt portrait / 220 pt landscape, like the Kotlin per-orientation LayoutParams).
/// Hidden views and views that were re-parented (the full-screen Effects panel) are skipped.
private final class RootLayout: UIView {
    var top: UIView? = nil
    var previewBox: UIView? = nil
    var tr: UIView? = nil
    var timeline: UIView? = nil
    var toolbarBox: UIView? = nil
    var panelBox: UIView? = nil

    override init(frame: CGRect) { super.init(frame: frame) }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    private func panelH() -> CGFloat { bounds.width > bounds.height ? 220 : 300 }

    private func lay(_ its: [(UIView?, CGFloat, Float)], _ r: CGRect) {
        let vis: [(UIView, CGFloat, Float)] = its.compactMap { it in
            guard let v = it.0, v.superview === self, !v.isHidden else { return nil }
            return (v, it.1, it.2)
        }
        var fixed: CGFloat = 0
        var tw: Float = 0
        for (_, h, w) in vis {
            let hh = h < 0 ? panelH() : h
            if hh > 0 { fixed += hh } else { tw += w }
        }
        let free = max(0, r.height - fixed)
        var y = r.minY
        for (v, h, w) in vis {
            let hh: CGFloat
            if h < 0 { hh = panelH() }
            else if h > 0 { hh = h }
            else { hh = tw > 0 ? free * CGFloat(w / tw) : 0 }
            v.frame = CGRect(x: r.minX, y: y, width: r.width, height: hh)
            y += hh
        }
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        let area = CGRect(x: 0, y: 0, width: bounds.width, height: bounds.height)
        if bounds.width > bounds.height {
            let lw = floor(area.width * 0.46)
            lay([(top, 52, 0), (previewBox, 0, 1), (tr, 48, 0)],
                CGRect(x: 0, y: 0, width: lw, height: area.height))
            lay([(timeline, 0, 1.15), (toolbarBox, 76, 0), (panelBox, -1, 0)],
                CGRect(x: lw, y: 0, width: area.width - lw, height: area.height))
        } else {
            lay([(top, 52, 0), (previewBox, 0, 1), (tr, 48, 0), (timeline, 0, 1.15),
                 (toolbarBox, 76, 0), (panelBox, -1, 0)], area)
        }
    }
}

final class EditorViewController: UIViewController, EditHost, TimelineHost, UIDocumentPickerDelegate, PHPickerViewControllerDelegate {
    var projectId: String
    var preview: PreviewView!
    var overlay: OverlayView!
    var aspect: AspectLayout!
    var timeline: TimelineView!
    var titleView: UILabel!
    var subView: UILabel!
    var playIcon: IconView!
    var markIcon: IconView!
    var cubeIcon: IconView!
    var mbToggle: PillToggle!
    var parentIcon: IconView!
    var moreIcon: IconView!
    var gearIcon: IconView!
    var sceneSetupBtn: IconView!
    var renderBtn: UIView!
    var actionBar: UIView!
    var qualityChip: ChipView!
    var toolbarBox: UIScrollView!
    var toolbarRow: UIStackView!
    var panelBox: UIView!
    var panelList: UIStackView!
    var diamondSide: IconView!
    var xformTab = 0
    var scaleLinked = true
    var sepDims = true
    var moveMode = false

    var selId = -1                 // PORT NOTE: Kotlin `selectedId` property
    var panel = 0
    var fxTab = 0
    var fxCat = 0                  // kept for parity (unused in Kotlin too)
    var playing = false { didSet { FrameCache.playing = playing } }
    var lastTs: Double = 0
    var autoKeyOn = false          // PORT NOTE: Kotlin `autoKey` property
    var quality = 1
    var graphProp = ""
    var curveClip: Key? = nil
    var graphKey = 0
    var graphTab = 1               // graph editor view: 0 ease / 1 value / 2 speed
    var selKey = ""
    var screen: UIView!
    fileprivate var rootLayout: RootLayout!    // Kotlin `panelHome` (panelBox's non-full parent)
    var textTab = 0
    var players: [Int: AVAudioPlayer] = [:]
    var startingAudio = Set<Int>()
    var prepared = Set<Int>()
    let audioLead = 110
    var multi: [Int] = []          // LinkedHashSet semantics: ordered + unique
    var multiMode = false
    var clipboard: [Layer] = []

    var expanded = Set<String>()
    final class Row {
        let slider: RulerSlider
        let d: PropDef
        let layer: Layer
        init(_ slider: RulerSlider, _ d: PropDef, _ layer: Layer) {
            self.slider = slider; self.d = d; self.layer = layer
        }
    }
    var rows: [Row] = []
    var undoStack: [String] = []   // Kotlin `undo`
    var redoStack: [String] = []   // Kotlin `redo`

    var fxQuery = ""
    final class FxSnap {
        let id: String
        let tracks: [(String, JObj)]
        let inputs: [String: Int]
        let off: Bool
        init(_ id: String, _ tracks: [(String, JObj)], _ inputs: [String: Int], _ off: Bool) {
            self.id = id; self.tracks = tracks; self.inputs = inputs; self.off = off
        }
    }
    var fxClip: [FxSnap] = []

    var pendingPick = 0
    var kbInset: CGFloat = 0
    var rootBottom: NSLayoutConstraint? = nil
    var displayLink: CADisplayLink? = nil
    fileprivate var linkProxy: DisplayLinkProxy? = nil

    // ---- autosave architecture (rounds 11/14/19) ----
    var dirty = false                   // unsaved edits exist
    var lastEditTs: CFAbsoluteTime = 0  // when the last edit landed
    var saveWork: DispatchWorkItem? = nil
    var lastSavedText = ""
    var idleSaving = false              // re-entry guard (IDLE_SAVE lesson)

    var flareLayer: Layer? = nil
    var flareBackup: JObj? = nil
    var flareOverlay: UIView? = nil
    var flareContent: UIStackView? = nil
    var flareTabs: TabBar? = nil
    var flTab = 0
    var flSel = 0

    // ================================================================ init / lifecycle

    init(projectId: String) {
        self.projectId = projectId
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    override func viewDidLoad() {
        super.viewDidLoad()
        Registry.initialize()      // Kotlin: Registry.init(this)
        CrashLog.install()         // R19: signal-safe crash logger, before any UI work
        FreezeWatchdog.start()     // R15/R19: freeze detection (heartbeat-change rule)
        // Kotlin also installs CrashLog here; HomeViewController owns the single install on iOS
        // (NSSetUncaughtExceptionHandler is idempotent anyway) — PORT NOTE.
        Editor.project = Projects.load(projectId) ?? Project(name: "Untitled")
        lastSavedText = Editor.project.toJson().toString(2)
        Editor.sceneIndex = 0
        Editor.time = 0
        selId = -1
        buildUi()
        refreshAll()
        safe("previews") {
            // cards pick thumbnails up from the cache themselves — no full panel rebuild
            EffectThumbs.generate(self, preview) { }
        }
        NotificationCenter.default.addObserver(self, selector: #selector(saveNow),
                                               name: UIApplication.willResignActiveNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(saveNow),
                                               name: UIApplication.didEnterBackgroundNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(saveNow),
                                               name: UIApplication.willTerminateNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(kbChanged(_:)),
                                               name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(kbChanged(_:)),
                                               name: UIResponder.keyboardWillHideNotification, object: nil)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
        preview.requestDraw()      // Kotlin: preview.onResume() (GLKView has no pause; redraw)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
        playing = false
        stopAudio()
        displayLink?.isPaused = true
        playIcon.set("play", C.GREEN)
        preview.releaseVideos()    // Kotlin: preview.onPause()
        saveWork?.cancel()
        FrameCache.playing = false
        Projects.save(projectId, Editor.project)
        dirty = false              // the explicit save above covers everything
        FreezeWatchdog.setDirty(false)
    }

    // ================================================================ autosave (rounds 11/14/19)

    /// Every edit funnels through pushUndo()/beginEdit(), so this is the one
    /// place that marks the project dirty. Saving is fully decoupled from
    /// editing — see maybeIdleSave().
    func markDirty() {
        dirty = true
        FrameCache.bump()              // every edit makes cached frames stale
        lastEditTs = CFAbsoluteTimeGetCurrent()
        scheduleSave()
        FreezeWatchdog.setDirty(true)
        CrashLog.note("edit")
    }

    /// Round-19 freeze fix: edits NEVER save synchronously. (The shipped
    /// binary ran the whole project serialization inside refreshTitle() on
    /// the main thread every second edit — the "anything I do freezes" bug.)
    /// Instead the render path — already on the main thread — saves once
    /// after the user has been idle ~10 s. Explicit save paths are untouched.
    /// Save fix: the old code only saved from the render path after 10 s idle, but
    /// nothing renders while the user is idle — so edits were never written.
    /// Now a debounced save fires ~1.5 s after the last edit, and the project is also
    /// saved whenever the app leaves the foreground.
    func scheduleSave() {
        saveWork?.cancel()
        let w = DispatchWorkItem { [weak self] in self?.saveNow() }
        saveWork = w
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4, execute: w)
    }

    /// Saves whenever the serialized project differs from what is on disk. This does not
    /// depend on every edit path remembering to call markDirty() (colour pickers, sliders
    /// and others did not), so even the slightest change is written.
    @objc func saveNow() {
        saveWork?.cancel()
        guard !idleSaving else { return }
        idleSaving = true
        defer { idleSaving = false }
        let text = Editor.project.toJson().toString(2)
        if text == lastSavedText { dirty = false; FreezeWatchdog.setDirty(false); return }
        lastSavedText = text
        FrameCache.bump()              // the picture changed → cached frames are stale
        CrashLog.note("save")
        Projects.save(projectId, Editor.project)
        if let e = Projects.lastError { toast("Save failed: " + e); lastSavedText = "" }
        dirty = Projects.lastError != nil
        FreezeWatchdog.setDirty(false)
    }

    func maybeIdleSave() {
        guard dirty, !idleSaving else { return }
        guard CFAbsoluteTimeGetCurrent() - lastEditTs >= 10.0 else { return }
        idleSaving = true
        CrashLog.note("save")
        Projects.save(projectId, Editor.project)
        dirty = false
        FreezeWatchdog.setDirty(false)
        idleSaving = false
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        applyFullPanelFrame()
    }

    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        // Kotlin onConfigurationChanged → buildUi() + refreshAll(); RootLayout recomputes both
        // orientations itself, so only a relayout pass is needed.
        rootLayout.setNeedsLayout()
        coordinator.animate(alongsideTransition: nil) { [weak self] _ in
            self?.applyFullPanelFrame()
        }
    }

    deinit {
        displayLink?.invalidate()
        NotificationCenter.default.removeObserver(self)
        releaseAudio()             // Kotlin: onDestroy → releaseAudio()
    }

    func toast(_ s: String) { Snack.show(self, s) }

    func safe(_ step: String, _ block: () throws -> Void) {
        do { try block() } catch {
            var m = (error as? LocalizedError)?.errorDescription ?? (error as NSError).localizedDescription
            if m.isEmpty { m = String(describing: type(of: error)) }
            toast(step + ": " + m)
        }
    }

    // ================================================================ UI skeleton

    @discardableResult
    func icon(_ name: String, _ tint: Int32 = C.TEXT, click: @escaping () -> Void = {}) -> IconView {
        let v = IconView(name, tint)
        v.onClick = click
        return v
    }

    func hRow() -> UIStackView {
        let r = UIStackView()
        r.axis = .horizontal
        r.alignment = .center
        r.spacing = 0
        return r
    }

    func vStack() -> UIStackView {
        let r = UIStackView()
        r.axis = .vertical
        r.spacing = 0
        r.alignment = .fill
        return r
    }

    func spacer() -> UIView {
        let v = UIView()
        v.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
        return v
    }

    func addIcon(_ parent: UIStackView, _ v: IconView, _ w: CGFloat = 44, _ h: CGFloat = 48) {
        parent.addArrangedSubview(wrap(v, w, h, 0, 0, 0, 0))
    }

    func buildUi() {
        screen = view
        screen.backgroundColor = argbToUIColor(C.BG)

        // ---- top bar
        let top = hRow()
        top.isLayoutMarginsRelativeArrangement = true
        top.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 4, bottom: 0, trailing: 8)
        addIcon(top, icon("back", C.GREEN) { [weak self] in self?.onBack() }, 40)
        let tcol = vStack()
        titleView = UILabel()
        titleView.textColor = argbToUIColor(C.TEXT)
        titleView.font = boldFont(17)
        titleView.numberOfLines = 1
        // never let the trailing icons crush the title into an unreadable sliver
        titleView.adjustsFontSizeToFitWidth = true
        titleView.minimumScaleFactor = 0.55
        titleView.setContentCompressionResistancePriority(UILayoutPriority(749), for: .horizontal)
        subView = UILabel()
        subView.textColor = argbToUIColor(C.GREEN)
        subView.font = monoTimeFont(11)
        subView.adjustsFontSizeToFitWidth = true
        subView.minimumScaleFactor = 0.6
        subView.numberOfLines = 1
        tcol.addArrangedSubview(titleView)
        tcol.addArrangedSubview(subView)
        tcol.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
        top.addArrangedSubview(tcol)
        cubeIcon = icon("cube") { [weak self] in self?.toggle3d() }
        addIcon(top, cubeIcon, 40)
        mbToggle = PillToggle()
        mbToggle.onClick = { [weak self] in
            guard let self = self, let l = self.selected() else { return }
            self.pushUndo()
            l.mblur = !l.mblur
            self.mbToggle.on = l.mblur
            self.refreshPanel(); self.render()
        }
        mbToggle.onLong = { [weak self] in
            guard let self = self, let l = self.selected() else { return }
            self.showMotionBlurSettings(l)
        }
        top.addArrangedSubview(wrap(mbToggle, 52, 40, 0, 0, 0, 0))
        parentIcon = icon("dup") { [weak self] in
            guard let self = self, let l = self.selected() else { return }
            self.showParentPopup(l, self.parentIcon)
        }
        addIcon(top, parentIcon, 40)
        moreIcon = icon("more") { [weak self] in self?.showLayersMenu() }
        addIcon(top, moreIcon, 40)
        gearIcon = icon("gear") { [weak self] in self?.showSceneDialog() }
        addIcon(top, gearIcon, 40)
        sceneSetupBtn = icon("camera") { [weak self] in self?.toggleSceneSetup() }
        addIcon(top, sceneSetupBtn, 40)
        renderBtn = wrap(pill("Render", "export", C.GREEN, C.ONDARK) { [weak self] in
            self?.showRenderDialog()
        }, 104, 38, 0, 0, 0, 0)
        top.addArrangedSubview(renderBtn)

        // ---- preview area
        let previewBox = UIView()
        previewBox.backgroundColor = argbToUIColor(Int32(bitPattern: 0xFF161618))
        aspect = AspectLayout()
        preview = PreviewView()
        overlay = OverlayView(self, self)
        aspect.addSubview(preview)
        aspect.addSubview(overlay)
        previewBox.addSubview(aspect)
        aspect.autoresizingMask = [.flexibleWidth, .flexibleHeight]

        // ---- transport row (green-editor layout: utilities left, playback
        // centered in a subtle pill group, history right — even spacing,
        // nothing can overlap)
        let tr = hRow()
        tr.isLayoutMarginsRelativeArrangement = true
        tr.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 6, bottom: 0, trailing: 6)
        addIcon(tr, icon("fit") { [weak self] in self?.timeline.fitToScene() }, 34)
        qualityChip = ChipView("Full")
        qualityChip.onClick = { [weak self] in self?.cycleQuality() }
        tr.addArrangedSubview(wrap(qualityChip, 48, 48, 0, 0, 0, 0))
        markIcon = icon("bookmark") { [weak self] in self?.toggleMarker() }
        markIcon.onLong = { [weak self] in self?.nameMarker() }
        addIcon(tr, markIcon, 34)
        tr.addArrangedSubview(spacer())
        let playGroup = hRow()
        playGroup.spacing = 0
        let prev = icon("prev") { [weak self] in self?.stepFrame(-1) }
        prev.onLong = { [weak self] in self?.jump(-1) }
        playGroup.addArrangedSubview(wrap(prev, 34, 44, 0, 0, 0, 0))
        playIcon = IconView("play", C.GREEN, 30)
        playIcon.onClick = { [weak self] in self?.togglePlay() }
        playGroup.addArrangedSubview(wrap(playIcon, 40, 44, 0, 0, 0, 0))
        let next = icon("next") { [weak self] in self?.stepFrame(1) }
        next.onLong = { [weak self] in self?.jump(1) }
        playGroup.addArrangedSubview(wrap(next, 34, 44, 0, 0, 0, 0))
        let playPill = UIView()
        playPill.backgroundColor = argbToUIColor(Int32(bitPattern: 0xFF241A12))
        playPill.layer.cornerRadius = 21
        playPill.layer.borderWidth = 1
        playPill.layer.borderColor = argbToUIColor(Int32(bitPattern: 0xFF4A3018)).cgColor
        playPill.addSubview(playGroup)
        playGroup.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            // size the pill to its buttons — it used to have no width, so the
            // play button sat OUTSIDE the pill's bounds and never got touches
            playGroup.centerYAnchor.constraint(equalTo: playPill.centerYAnchor),
            playGroup.leadingAnchor.constraint(equalTo: playPill.leadingAnchor, constant: 6),
            playGroup.trailingAnchor.constraint(equalTo: playPill.trailingAnchor, constant: -6),
        ])
        tr.addArrangedSubview(wrap(playPill, 0, 44, 0, 2, 0, 2))
        tr.addArrangedSubview(spacer())
        addIcon(tr, icon("layers") { [weak self] in self?.showLayersMenu() }, 34)
        addIcon(tr, icon("undo") { [weak self] in self?.doUndo() }, 34)
        addIcon(tr, icon("redo") { [weak self] in self?.doRedo() }, 34)

        timeline = TimelineView(self, self)

        // The floating action bar over the timeline: trim in / split / trim out / delete.
        // It appears only while a layer is selected, which keeps the main toolbar clean.
        let tlBox = UIView()
        tlBox.clipsToBounds = true          // the playhead / ruler must not bleed over the panels
        timeline.clipsToBounds = true
        tlBox.addSubview(timeline)
        let abar = UIStackView()
        abar.axis = .horizontal
        abar.alignment = .center
        abar.spacing = 0
        abar.backgroundColor = argbToUIColor(Int32(bitPattern: 0xF01E1E22)).withAlphaComponent(0.94)
        abar.layer.cornerRadius = 26
        abar.layer.borderWidth = 1
        abar.layer.borderColor = argbToUIColor(Int32(bitPattern: 0xFF3A3A42)).cgColor
        abar.isLayoutMarginsRelativeArrangement = true
        abar.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 8, bottom: 0, trailing: 8)
        addIcon(abar, icon("trimin") { [weak self] in self?.trimTo(true) }, 52, 48)
        addIcon(abar, icon("split") { [weak self] in self?.splitAtPlayhead(false) }, 52, 48)
        addIcon(abar, icon("trimout") { [weak self] in self?.trimTo(false) }, 52, 48)
        addIcon(abar, icon("trash", C.RED) { [weak self] in self?.deleteLayer() }, 52, 48)
        actionBar = abar
        actionBar.isHidden = true
        tlBox.addSubview(abar)
        abar.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            abar.centerXAnchor.constraint(equalTo: tlBox.centerXAnchor),
            abar.bottomAnchor.constraint(equalTo: tlBox.bottomAnchor, constant: -8),
            abar.heightAnchor.constraint(equalToConstant: 48)
        ])

        // ---- bottom tool bar
        toolbarBox = UIScrollView()
        toolbarBox.showsHorizontalScrollIndicator = false
        toolbarBox.backgroundColor = argbToUIColor(C.PANEL)
        toolbarRow = hRow()
        toolbarRow.translatesAutoresizingMaskIntoConstraints = false
        toolbarBox.addSubview(toolbarRow)
        NSLayoutConstraint.activate([
            toolbarRow.topAnchor.constraint(equalTo: toolbarBox.contentLayoutGuide.topAnchor),
            toolbarRow.bottomAnchor.constraint(equalTo: toolbarBox.contentLayoutGuide.bottomAnchor),
            toolbarRow.leadingAnchor.constraint(equalTo: toolbarBox.contentLayoutGuide.leadingAnchor),
            toolbarRow.trailingAnchor.constraint(equalTo: toolbarBox.contentLayoutGuide.trailingAnchor),
            toolbarRow.heightAnchor.constraint(equalTo: toolbarBox.frameLayoutGuide.heightAnchor)
        ])

        // ---- property panel (side rail + scroll)
        panelBox = UIView()
        panelBox.backgroundColor = argbToUIColor(C.PANEL)
        let ph = hRow()
        ph.alignment = .fill
        ph.spacing = 0
        let side = UIStackView()
        side.axis = .vertical
        side.alignment = .center
        side.spacing = 0
        side.addArrangedSubview(wrap(icon("close") { [weak self] in self?.closePanel() }, 48, 48, 0, 0, 0, 0))
        side.addArrangedSubview(wrap(icon("plus", C.GREEN) { [weak self] in
            guard let self = self else { return }
            self.fxTab = 1; self.openPanel(P_FX)
        }, 48, 44, 0, 0, 0, 0))
        diamondSide = icon("diamond_f", C.DIM) { [weak self] in self?.keySelected() }
        side.addArrangedSubview(wrap(diamondSide, 48, 44, 0, 0, 0, 0))
        side.addArrangedSubview(wrap(icon("graph", C.DIM) { [weak self] in
            guard let self = self else { return }
            if let l = self.selected(), !self.selKey.isEmpty, l.track(self.selKey).keys.count >= 2 { self.graphProp = self.selKey; self.graphKey = 0 }
            self.openPanel(P_GRAPH)
        }, 48, 44, 0, 0, 0, 0))
        side.addArrangedSubview(wrap(icon("box", C.DIM) { [weak self] in
            guard let self = self else { return }
            self.fxTab = 2; self.openPanel(P_FX)
        }, 48, 44, 0, 0, 0, 0))
        side.addArrangedSubview(wrap(icon("more", C.DIM) { [weak self] in self?.showPanelMenu() }, 48, 44, 0, 0, 0, 0))
        ph.addArrangedSubview(fixedWidth(side, 52))
        let panelSv = UIScrollView()
        panelList = vStack()
        panelList.isLayoutMarginsRelativeArrangement = true
        panelList.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 6, leading: 4, bottom: 16, trailing: 8)
        panelList.translatesAutoresizingMaskIntoConstraints = false
        panelSv.addSubview(panelList)
        NSLayoutConstraint.activate([
            panelList.topAnchor.constraint(equalTo: panelSv.contentLayoutGuide.topAnchor),
            panelList.bottomAnchor.constraint(equalTo: panelSv.contentLayoutGuide.bottomAnchor),
            panelList.leadingAnchor.constraint(equalTo: panelSv.contentLayoutGuide.leadingAnchor),
            panelList.trailingAnchor.constraint(equalTo: panelSv.contentLayoutGuide.trailingAnchor),
            panelList.widthAnchor.constraint(equalTo: panelSv.frameLayoutGuide.widthAnchor)
        ])
        ph.addArrangedSubview(panelSv)
        ph.translatesAutoresizingMaskIntoConstraints = false
        panelBox.addSubview(ph)
        NSLayoutConstraint.activate([
            ph.topAnchor.constraint(equalTo: panelBox.topAnchor),
            ph.bottomAnchor.constraint(equalTo: panelBox.bottomAnchor),
            ph.leadingAnchor.constraint(equalTo: panelBox.leadingAnchor),
            ph.trailingAnchor.constraint(equalTo: panelBox.trailingAnchor)
        ])

        timeline.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        tlBox.clipsToBounds = true

        // ---- root (the Kotlin LinearLayout with orientation branches)
        rootLayout = RootLayout()
        rootLayout.translatesAutoresizingMaskIntoConstraints = false
        rootLayout.top = top
        rootLayout.previewBox = previewBox
        rootLayout.tr = tr
        rootLayout.timeline = tlBox
        rootLayout.toolbarBox = toolbarBox
        rootLayout.panelBox = panelBox
        // The slots must actually live in the hierarchy — RootLayout.lay() only frames
        // views whose superview is itself (placePanel() re-parents panelBox later, so it
        // is appended last here to keep it on top of the weighted stack).
        rootLayout.addSubview(top)
        rootLayout.addSubview(previewBox)
        rootLayout.addSubview(tr)
        rootLayout.addSubview(tlBox)
        rootLayout.addSubview(toolbarBox)
        rootLayout.addSubview(panelBox)
        screen.addSubview(rootLayout)
        rootBottom = rootLayout.bottomAnchor.constraint(equalTo: screen.safeAreaLayoutGuide.bottomAnchor)
        NSLayoutConstraint.activate([
            rootLayout.topAnchor.constraint(equalTo: screen.safeAreaLayoutGuide.topAnchor),
            rootLayout.leadingAnchor.constraint(equalTo: screen.safeAreaLayoutGuide.leadingAnchor),
            rootLayout.trailingAnchor.constraint(equalTo: screen.safeAreaLayoutGuide.trailingAnchor),
            rootBottom!
        ])

        toolbarBox.isHidden = false
        panelBox.isHidden = true
    }

    // ================================================================ small helpers

    func selected() -> Layer? { Editor.scene.layers.first { $0.id == selId } }

    func render() {
        FreezeWatchdog.beat()          // main thread is alive (R15/R19)
        if !playing { scheduleSave() } // any visible change → saved shortly after
        preview.requestDraw()
        overlay.setNeedsDisplay()
        timeline.setNeedsDisplay()
    }

    @discardableResult
    func pill(_ text: String, _ icon: String? = nil, _ fill: Int32 = C.CARD2, _ tc: Int32 = C.TEXT,
                      click: @escaping () -> Void) -> PillButton {
        let b = PillButton(text, icon, fill, tc)
        b.onClick = click
        return b
    }

    /// Kotlin put(parent, v, hDp, mT, mB): adds with top/bottom margins; h>0 → fixed height.
    @discardableResult
    func put(_ parent: UIStackView, _ v: UIView, _ h: CGFloat = 0, _ mT: CGFloat = 3, _ mB: CGFloat = 3) -> UIView {
        parent.addArrangedSubview(pad(v, mT, 0, mB, 0))
        if h > 0 { v.heightAnchor.constraint(equalToConstant: h).isActive = true }
        return v
    }

    /// Wraps a view in padding (Android view.setPadding / layout margins).
    func pad(_ v: UIView, _ t: CGFloat, _ l: CGFloat, _ b: CGFloat, _ r: CGFloat) -> UIView {
        let w = UIView()
        w.translatesAutoresizingMaskIntoConstraints = false
        v.translatesAutoresizingMaskIntoConstraints = false
        w.addSubview(v)
        NSLayoutConstraint.activate([
            v.topAnchor.constraint(equalTo: w.topAnchor, constant: t),
            v.bottomAnchor.constraint(equalTo: w.bottomAnchor, constant: -b),
            v.leadingAnchor.constraint(equalTo: w.leadingAnchor, constant: l),
            v.trailingAnchor.constraint(equalTo: w.trailingAnchor, constant: -r)
        ])
        return w
    }

    /// Wraps a view with explicit size + margins (Android LayoutParams with setMargins).
    func wrap(_ v: UIView, _ w: CGFloat, _ h: CGFloat, _ l: CGFloat, _ t: CGFloat, _ r: CGFloat, _ b: CGFloat) -> UIView {
        let box = pad(v, t, l, b, r)
        if w > 0 { v.widthAnchor.constraint(equalToConstant: w).isActive = true }
        if h > 0 { v.heightAnchor.constraint(equalToConstant: h).isActive = true }
        return box
    }

    /// Wrapper that pins the child to the edges but fixes the wrapper width (the 52pt side rail).
    func fixedWidth(_ v: UIView, _ w: CGFloat) -> UIView {
        let box = UIView()
        box.translatesAutoresizingMaskIntoConstraints = false
        v.translatesAutoresizingMaskIntoConstraints = false
        box.addSubview(v)
        NSLayoutConstraint.activate([
            v.topAnchor.constraint(equalTo: box.topAnchor),
            v.bottomAnchor.constraint(equalTo: box.bottomAnchor),
            v.leadingAnchor.constraint(equalTo: box.leadingAnchor),
            v.trailingAnchor.constraint(equalTo: box.trailingAnchor),
        ])
        box.widthAnchor.constraint(equalToConstant: w).isActive = true
        return box
    }

    @discardableResult
    func text(_ parent: UIStackView, _ t: String, _ color: Int32 = C.DIM,
                      _ size: CGFloat = 13, _ bold: Bool = false) -> UILabel {
        let tv = UILabel()
        tv.text = t
        tv.textColor = argbToUIColor(color)
        tv.font = bold ? boldFont(size) : sysFont(size)
        tv.numberOfLines = 0
        parent.addArrangedSubview(pad(tv, 6, 6, 4, 6))
        return tv
    }

    func refreshAll() {
        aspect.ratio = CGFloat(Float(Editor.project.w) / Float(Editor.project.h))
        if selected() == nil { selId = -1 }
        safe("title") { refreshTitle() }
        safe("toolbar") { refreshToolbar() }
        safe("panel") { showBottom() }
        safe("panel") { refreshPanel() }
        safe("time") { onTimeChanged() }
        safe("audio") { ensureAudio() }
    }

    func refreshTitle() {
        let l = selected()
        titleView.text = l?.name ?? Editor.project.name
        let on = l != nil && (l!.is3d || l!.type == .MODEL || l!.type == .CAMERA)
        cubeIcon.set("cube", on ? C.GREEN : C.TEXT)
        let sel = l != nil
        cubeIcon.isHidden = !sel
        mbToggle.isHidden = !sel || l!.type == .AUDIO
        parentIcon.isHidden = !sel
        moreIcon.isHidden = !sel
        gearIcon.isHidden = sel
        sceneSetupBtn.isHidden = sel
        sceneSetupBtn.set("camera", sceneSetupOn ? C.GREEN : C.TEXT)
        renderBtn.isHidden = sel
        if let l = l {
            mbToggle.on = l.mblur
            parentIcon.set("dup", l.parentId >= 0 ? C.GREEN : C.TEXT)
        }
        actionBar.isHidden = !sel
    }

    /** The Effects panel covers the whole screen; every other panel sits under the timeline. */
    func placePanel(_ full: Bool) {
        let cur = panelBox.superview
        if full {
            if cur !== screen {
                panelBox.removeFromSuperview()
                screen.addSubview(panelBox)
            }
            panelBox.autoresizingMask = []
            screen.bringSubviewToFront(panelBox)
            applyFullPanelFrame()
            rootLayout.setNeedsLayout()
        } else if cur !== rootLayout {
            panelBox.removeFromSuperview()
            panelBox.autoresizingMask = []
            rootLayout.addSubview(panelBox)   // re-appended last — its layout slot
            rootLayout.setNeedsLayout()
        }
    }

    func applyFullPanelFrame() {
        guard panelBox.superview === screen else { return }
        var f = screen.safeAreaLayoutGuide.layoutFrame
        f.size.height = max(0, f.height - kbInset)
        panelBox.frame = f
    }

    func showBottom() {
        placePanel(panel == P_FX && fxTab == 1)
        toolbarBox.isHidden = panel != P_NONE
        panelBox.isHidden = panel == P_NONE
        rootLayout.setNeedsLayout()   // visibility changes must re-flow the weighted layout
    }

    func onTimeChanged() {
        syncRows()
        subView.text = timeline.timecode(Editor.time) + " / " + timeline.timecode(Editor.scene.duration)
        let has = Editor.scene.markers.contains { abs($0 - Editor.time) < 0.02 }
        markIcon.set(has ? "bookmark_f" : "bookmark", has ? C.BLUE : C.TEXT)
        render()
    }

    func onBack() {
        if panel != P_NONE {
            closePanel()
        } else if selId != -1 {
            onSelect(-1)
        } else if let nav = navigationController {
            nav.popViewController(animated: true)
        } else {
            dismiss(animated: true)
        }
    }

    func openPanel(_ p: Int) {
        if p != P_MEDIA && p != P_SHAPES && selected() == nil { toast("Select a layer first"); return }
        panel = p
        showBottom(); refreshPanel()
    }

    func closePanel() { panel = P_NONE; showBottom() }

    // ================================================================ keyboard (adjustResize)

    @objc private func kbChanged(_ n: Notification) {
        guard let info = n.userInfo else { return }
        let show = n.name == UIResponder.keyboardWillShowNotification
        let dur = (info[UIResponder.keyboardAnimationDurationUserInfoKey] as? Double) ?? 0.25
        var endH: CGFloat = 0
        if show, let f = (info[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
            endH = max(0, f.height - view.safeAreaInsets.bottom)
        }
        kbInset = endH
        UIView.animate(withDuration: dur) {
            self.rootBottom?.constant = self.kbInset
            if self.panelBox.superview === self.view {
                var fr = self.view.safeAreaLayoutGuide.layoutFrame
                fr.size.height = max(0, fr.height - self.kbInset)
                self.panelBox.frame = fr
            }
            self.view.layoutIfNeeded()
        }
    }

    // ================================================================ tool bar

    func refreshToolbar() {
        toolbarRow.arrangedSubviews.forEach { $0.removeFromSuperview() }
        func tool(_ ic: String, _ label: String, _ tint: Int32 = C.TEXT, _ click: @escaping () -> Void) {
            let b = ToolButton(ic, label)
            b.tint = tint
            b.onClick = click
            toolbarRow.addArrangedSubview(wrap(b, 76, 76, 0, 0, 0, 0))
        }
        guard let l = selected() else {
            tool("media", "Media") { [weak self] in self?.openPanel(P_MEDIA) }
            tool("text", "Text") { [weak self] in self?.addLayer(.TEXT) }
            tool("solid", "Solid") { [weak self] in self?.addSolid() }
            tool("adjust", "Adjustment") { [weak self] in self?.addLayer(.ADJUST) }
            tool("audio", "Audio") { [weak self] in self?.pickMedia(R_AUDIOFILE, [.audio], false) }
            tool("nullobj", "Null") { [weak self] in self?.addLayer(.NULL) }
            tool("shape", "Shape") { [weak self] in self?.openPanel(P_SHAPES) }
            tool("camera", "Camera") { [weak self] in self?.addLayer(.CAMERA) }
            tool("particles", "Particles") { [weak self] in self?.addParticles() }
            tool("flare", "Optical Flare") { [weak self] in self?.showFlareLibrary() }
            tool("layers", "Group") { [weak self] in self?.addLayer(.GROUP) }
            tool("cube", "3D Model") { [weak self] in self?.pickFile(R_GLB, glbTypes()) }
            return
        }
        toolbarRow.addArrangedSubview(wrap(icon("back", C.GREEN) { [weak self] in self?.onSelect(-1) }, 44, 76, 0, 0, 0, 0))
        if l.type == .VIDEO { tool("audio", "Extract audio") { [weak self] in self?.extractAudio(l) } }
        tool("edit", "Edit") { [weak self] in self?.openPanel(P_EDIT) }
        tool("move", "Transform") { [weak self] in self?.openPanel(P_XFORM) }
        if l.isRenderable() || l.type == .GROUP {
            tool("sparkle", "Effects") { [weak self] in self?.openPanel(P_FX) }
            tool("drop", "Blending") { [weak self] in self?.openPanel(P_BLEND) }
            tool("speed", "Speed") { [weak self] in self?.openPanel(P_SPEED) }
        }
    }

    // ================================================================ playback (Choreographer → CADisplayLink)

    func doFrame() {
        FreezeWatchdog.beat()          // playback frames count as liveness
        if !playing { return }
        let ts = CACurrentMediaTime()
        if lastTs != 0 && ts > lastTs {
            var t = Editor.time + Float(ts - lastTs)
            var wrapped = false
            if t >= Editor.scene.duration { t = 0; wrapped = true }
            Editor.time = t
            if wrapped { startAudio() } else { tickAudio() }
            onTimeChanged()
        }
        lastTs = ts
    }

    func togglePlay() {
        CrashLog.note("play")
        playing = !playing
        playIcon.set(playing ? "pause" : "play", C.GREEN)
        if playing {
            lastTs = 0
            if displayLink == nil {
                let proxy = DisplayLinkProxy()
                proxy.vc = self
                let link = CADisplayLink(target: proxy, selector: #selector(DisplayLinkProxy.tick(_:)))
                link.add(to: .main, forMode: .common)
                linkProxy = proxy
                displayLink = link
            }
            displayLink?.isPaused = false
            startAudio()
        } else {
            displayLink?.isPaused = true
            stopAudio()
        }
    }

    func stepFrame(_ dir: Int) {
        Editor.time = clamp(Editor.time + Float(dir) / Float(Editor.project.fps), 0, Editor.scene.duration)
        onTimeChanged()
    }

    func jump(_ dir: Int) {
        var times: [Float] = []
        times.append(contentsOf: Editor.scene.markers)
        if let l = selected() {
            for (_, tr) in l.props { for k in tr.keys { times.append(k.t) } }
        }
        times.sort()
        let now = Editor.time
        let target = dir > 0 ? times.first { $0 > now + 0.02 } : times.last { $0 < now - 0.02 }
        if let target = target { Editor.time = target; onTimeChanged() }
    }

    func toggleMarker() {
        var ms = Editor.scene.markers
        let ex = ms.first { abs($0 - Editor.time) < 0.02 }
        pushUndo()
        if let ex = ex {
            Editor.scene.setMarkerName(ex, "")
            ms.removeAll { $0 == ex }
        } else {
            ms.append(Editor.time)
        }
        Editor.scene.markers = ms
        onTimeChanged()
    }

    func nameMarker() {
        var ms = Editor.scene.markers
        var m: Float? = ms.first { abs($0 - Editor.time) < 0.02 }
        if m == nil {
            pushUndo()
            ms.append(Editor.time)
            m = Editor.time
            Editor.scene.markers = ms
            onTimeChanged()
        }
        guard let tm = m else { return }
        let box = vStack()
        box.isLayoutMarginsRelativeArrangement = true
        box.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 4, leading: 4, bottom: 4, trailing: 4)
        text(box, timeline.timecode(tm), C.DIM, 13)
        let et = makeField("")
        et.placeholder = "Marker name"
        et.text = Editor.scene.markerName(tm) ?? ""
        box.addArrangedSubview(wrap(et, 0, 44, 0, 0, 0, 0))
        text(box, "Expressions can reach this marker by name:  marker.key(\"name\")", C.DIM, 12)
        Dlg(self).setTitle("Name marker").setView(box).setPositiveButton("Save") { [weak self] _, _ in
            guard let self = self else { return }
            self.pushUndo()
            Editor.scene.setMarkerName(tm, et.text ?? "")
            self.timeline.setNeedsDisplay()
            self.render()
        }.setNegativeButton("Cancel", nil).show()
    }

    func cycleQuality() {
        quality = quality == 1 ? 2 : (quality == 2 ? 4 : 1)
        preview.quality = quality
        qualityChip.text = quality == 1 ? "Full" : (quality == 2 ? "1/2" : "1/4")
        qualityChip.setNeedsDisplay()
        render()
    }

    // ================================================================ undo / redo

    func snapshot() -> String { Editor.project.toJson().toString() }

    func pushUndo() {
        markDirty()                    // every edit passes through here (R11/R19)
        let s = snapshot()
        if undoStack.last == s { return }
        undoStack.append(s)
        if undoStack.count > 40 { undoStack.removeFirst() }
        redoStack.removeAll()
    }

    func restore(_ js: String) {
        FrameCache.bump()
        markDirty()
        if let o = try? JObj(json: js) { Editor.project = Project.fromJson(o) }
        // a restored project with zero scenes must not wedge sceneIndex at -1
        if Editor.project.scenes.isEmpty {
            Editor.project.scenes = [Scene("Scene 1")]
        }
        Editor.sceneIndex = clamp(Editor.sceneIndex, 0, Editor.project.scenes.count - 1)
        Editor.time = clamp(Editor.time, 0, Editor.scene.duration)
        refreshAll()
    }

    func doUndo() {
        if undoStack.isEmpty { toast("Nothing to undo"); return }
        redoStack.append(snapshot())
        let js = undoStack.removeLast()
        restore(js)
    }

    func doRedo() {
        if redoStack.isEmpty { toast("Nothing to redo"); return }
        undoStack.append(snapshot())
        let js = redoStack.removeLast()
        restore(js)
    }

    // ================================================================ hosts

    func selectedLayer() -> Layer? { selected() }
    func autoKey() -> Bool { autoKeyOn }
    func beginEdit() { pushUndo() }
    func onEdited() { syncRows(); render() }
    func selectedId() -> Int { selId }
    func isSelected(_ id: Int) -> Bool { id == selId || multi.contains(id) }
    func onSeek(_ t: Float) { Editor.time = t; onTimeChanged() }

    func onSelect(_ id: Int) {
        if multiMode && id >= 0 {
            if let i = multi.firstIndex(of: id) { multi.remove(at: i) } else { multi.append(id) }
            selId = id
            panel = P_NONE
            refreshTitle(); refreshToolbar(); showBottom(); refreshPanel(); render()
            return
        }
        if !multiMode { multi.removeAll() }
        selId = id
        panel = id >= 0 && selected()?.type == .TEXT ? P_EDIT : P_NONE
        refreshTitle(); refreshToolbar(); showBottom(); refreshPanel(); render()
    }

    func onToggleVisible(_ l: Layer) {
        pushUndo()
        l.visible = !l.visible
        render()
    }

    func onTimingChanged() { render() }

    func onReorder(_ l: Layer, _ listIndex: Int) {
        pushUndo()
        var ls = Editor.scene.layers
        ls.removeAll { $0 === l }
        ls.insert(l, at: clamp(listIndex, 0, ls.count))
        Editor.scene.layers = ls
        render()
    }

    func onKeyTap(_ l: Layer, _ key: String, _ idx: Int) {
        selId = l.id
        graphProp = key
        graphKey = idx
        let ks = l.track(key).keys
        if ks.indices.contains(idx) { Editor.time = ks[idx].t }
        panel = P_GRAPH
        refreshTitle(); refreshToolbar(); showBottom(); refreshPanel(); onTimeChanged()
    }
}
