vec4 effect(vec2 uv) {
    vec2 dir = (uv - 0.5);
    float r = src(clamp(uv + dir * amount, 0.0, 1.0)).r;
    float b = src(clamp(uv - dir * amount, 0.0, 1.0)).b;
    vec4 c = src(uv);
    return vec4(r, c.g, b, c.a);
}
