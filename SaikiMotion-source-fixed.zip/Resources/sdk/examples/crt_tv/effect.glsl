vec4 effect(vec2 uv) {
    vec2 cc = uv - 0.5;
    vec2 duv = 0.5 + cc * (1.0 + curve * dot(cc, cc) * 1.6);
    if (duv.x < 0.0 || duv.x > 1.0 || duv.y < 0.0 || duv.y > 1.0) return vec4(0.0);
    vec4 c = src(duv);
    float m = 1.0 - mask * 0.35 * (0.5 + 0.5 * sin(duv.x * uRes.x * 3.14159));
    return vec4(c.rgb * m + vec3(luma(c.rgb)) * 0.18, c.a);
}
