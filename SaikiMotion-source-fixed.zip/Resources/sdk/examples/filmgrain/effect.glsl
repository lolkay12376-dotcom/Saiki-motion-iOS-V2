vec4 effect(vec2 uv) {
    vec4 c = src(uv);
    float n = vnoise(uv * uRes / (size * 3.0) + vec2(uTime * 61.7, uTime * 23.9));
    return vec4(c.rgb + (n - 0.5) * amount * 0.28, c.a);
}
