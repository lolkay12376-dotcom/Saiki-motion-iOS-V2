vec4 effect(vec2 uv) {
    vec4 c = src(uv);
    float m = smoothstep(center - soft, center + soft, uv.y);
    vec3 g = vec3(luma(c.rgb)) * grade.rgb * 1.4;
    return vec4(mix(c.rgb, g, m), c.a);
}
