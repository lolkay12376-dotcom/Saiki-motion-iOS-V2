vec4 effect(vec2 uv) {
    vec4 c = src(uv);
    float p = 0.5 + 0.5 * sin(uTime * rate * 6.2831);
    return vec4(mix(c.rgb, tint.rgb, p * 0.65), c.a);
}
