// EditorAudio.swift — audio playback (MediaPlayer → AVAudioPlayer port).

import UIKit
import AVFoundation

extension EditorViewController {
        // ================================================================ audio (MediaPlayer → AVAudioPlayer)

        /** Players are created and prepared in the background as soon as an audio layer exists, so Play starts instantly. */
        func ensureAudio() {
            var ids = Set<Int>()
            for l in Editor.scene.layers {
                guard l.type == .AUDIO else { continue }
                ids.insert(l.id)
                guard let path = l.imagePath, players[l.id] == nil, !startingAudio.contains(l.id) else { continue }
                let id = l.id
                startingAudio.insert(id)
                safeThread("audio-\(id)") { [weak self] in
                    let mp = try? AVAudioPlayer(contentsOf: URL(fileURLWithPath: path))
                    if let mp = mp { _ = mp.prepareToPlay() }
                    DispatchQueue.main.async {
                        guard let self = self else { return }
                        self.startingAudio.remove(id)
                        if let mp = mp {
                            self.players[id] = mp
                            self.prepared.insert(id)
                        }
                    }
                }
            }
            for id in Array(players.keys) where !ids.contains(id) {
                players.removeValue(forKey: id)   // AVAudioPlayer is released by ARC (no explicit release)
                prepared.remove(id)
                startingAudio.remove(id)
            }
        }

        func releaseAudio() {
            players.removeAll()
            prepared.removeAll()
            startingAudio.removeAll()
        }

        func stopAudio() {
            for mp in players.values { mp.pause() }
        }

        func startAudio() { ensureAudio(); tickAudio(true) }

        /** Keeps every audio layer locked to the playhead and corrects drift. */
        func tickAudio(_ restart: Bool = false) {
            let t = Editor.time
            for l in Editor.scene.layers {
                guard let mp = players[l.id], prepared.contains(l.id) else { continue }
                let inside = l.visible && t >= l.start && t <= l.end
                let wantMs = Float(ktInt((t - l.start + l.srcOffset) * 1000)) + Float(audioLead)
                let want = wantMs / 1000
                if inside {
                    let v = clamp(l.p("volume", t), 0, 1)
                    mp.volume = v
                    if !mp.isPlaying {
                        mp.currentTime = Double(want)  // SEEK_CLOSEST parity
                        mp.play()
                    } else if restart || abs(mp.currentTime - Double(want)) > 0.14 {
                        mp.currentTime = Double(want)
                    }
                } else if mp.isPlaying {
                    mp.pause()
                }
            }
        }
}
