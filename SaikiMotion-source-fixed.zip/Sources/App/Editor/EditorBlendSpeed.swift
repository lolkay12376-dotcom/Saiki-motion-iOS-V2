// EditorBlendSpeed.swift — Blending + Speed panels and the time-remap helpers.

import UIKit

extension EditorViewController {
        // ---------------------------------------------------------------- blending + speed

        func buildBlend(_ l: Layer) {
            let p: UIStackView = panelList
            text(p, "Blending", C.TEXT, 16, true)
            addRow(p, l, Defs.transform[3])
            text(p, "Blend mode", C.DIM)
            p.addArrangedSubview(chipRow(["Normal", "Add", "Screen", "Multiply"], l.blend) { [weak self] i in
                guard let self = self else { return }
                self.pushUndo()
                l.blend = i
                self.refreshPanel(); self.render()
            })
            let mb = SwitchRow()
            mb.label = "Motion blur"; mb.on = l.mblur
            mb.onToggle = { [weak self] v in
                guard let self = self else { return }
                self.pushUndo()
                l.mblur = v
                self.refreshPanel(); self.render()
            }
            put(p, mb, 52)
            if l.mblur {
                addRow(p, l, Defs.blur[0])
                addRow(p, l, Defs.blur[1])
                text(p, "Works on every layer: shapes, text, media, video, groups, particles and 3D. A camera with motion blur on blurs all 3D layers below it. More samples is smoother but slower.", C.DIM, 12)
            }
        }

        func buildSpeed(_ l: Layer) {
            let p: UIStackView = panelList
            let hasMap = l.props["remapT"]?.keys.isEmpty == false
            let spd = l.speedAt(Editor.time)
            let head = hRow()
            let ht = UILabel()
            ht.text = "Playback Speed"
            ht.textColor = argbToUIColor(C.TEXT)
            ht.font = boldFont(16)
            ht.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
            head.addArrangedSubview(ht)
            let here = UILabel()
            here.text = String(format: "%.2fx here", spd)
            here.textColor = argbToUIColor(C.DIM)
            here.font = sysFont(13)
            head.addArrangedSubview(here)
            put(p, head, 0, 4, 4)
            let fs = FillSlider()
            fs.lo = 0.1
            fs.hi = 4
            fs.value = abs(hasMap ? 1 : l.track("remapSpeed").eval(Editor.time))
            fs.value = clamp(fs.value, 0.1, 4)
            fs.isUserInteractionEnabled = !hasMap
            fs.onBegin = { [weak self] in self?.pushUndo() }
            fs.onChange = { [weak self] v in
                guard let self = self else { return }
                self.ensureRemap(l)
                l.track("remapSpeed").set(Editor.time, v, self.autoKeyOn)
                here.text = String(format: "%.2fx here", v)
                self.render()
            }
            put(p, fs, 46)
            let presets: [Float] = [0.1, 0.25, 0.5, 1, 2, 4]
            let labels = ["0.1x", "0.25x", "0.5x", "1.0x", "2.0x", "4.0x"]
            for rowStart in [0, 3] {
                let rw = hRow()
                rw.distribution = .fillEqually
                rw.spacing = 3
                for k in rowStart..<(rowStart + 3) {
                    let on = !hasMap && abs(spd - presets[k]) < 0.01
                    let b = pill(labels[k], nil, on ? C.GREEN : C.CARD2, on ? C.ONDARK : C.TEXT) { [weak self] in
                        guard let self = self, !hasMap else { return }
                        self.pushUndo()
                        self.ensureRemap(l)
                        let tr = l.track("remapSpeed")
                        tr.keys.removeAll()
                        tr.base = presets[k]
                        self.refreshPanel(); self.render()
                    }
                    rw.addArrangedSubview(wrap(b, 0, 40, 0, 0, 0, 0))
                }
                put(p, rw, 40)
            }
            if hasMap { text(p, "Time Remap keyframes are driving playback. Remove them to use the speed slider.", C.AMBER, 12) }

            text(p, "Time Remap", C.TEXT, 16, true)
            if !hasMap {
                text(p, "Keyframe which moment of the source plays at each point in time.", C.DIM, 12)
                put(p, pill("Add Time Remap keyframes", "plus") { [weak self] in
                    guard let self = self else { return }
                    self.pushUndo()
                    self.ensureRemapKeys(l)
                    self.selKey = "remapT"
                    self.refreshPanel(); self.render()
                }, 44)
                let q = hRow()
                q.distribution = .fillEqually
                q.spacing = 3
                q.addArrangedSubview(wrap(pill("Freeze frame") { [weak self] in
                    guard let self = self else { return }
                    self.pushUndo()
                    self.freezeFrame(l)
                    self.selKey = "remapT"
                    self.refreshPanel(); self.render()
                }, 0, 40, 0, 0, 0, 0))
                q.addArrangedSubview(wrap(pill("Reverse") { [weak self] in
                    guard let self = self else { return }
                    self.pushUndo()
                    self.reverseRemap(l)
                    self.selKey = "remapT"
                    self.refreshPanel(); self.render()
                }, 0, 40, 0, 0, 0, 0))
                put(p, q, 40)
            } else {
                if let rd = Registry.get("remap"), let def = rd.props.first(where: { $0.key == "remapT" }) {
                    addRow(p, l, def, "Time Remap (s)")
                }
                let q = hRow()
                q.distribution = .fillEqually
                q.spacing = 3
                q.addArrangedSubview(wrap(pill("Freeze frame") { [weak self] in
                    guard let self = self else { return }
                    self.pushUndo()
                    self.freezeFrame(l)
                    self.refreshPanel(); self.render()
                }, 0, 40, 0, 0, 0, 0))
                q.addArrangedSubview(wrap(pill("Reverse") { [weak self] in
                    guard let self = self else { return }
                    self.pushUndo()
                    self.reverseRemap(l)
                    self.refreshPanel(); self.render()
                }, 0, 40, 0, 0, 0, 0))
                put(p, q, 40)
                put(p, pill("Remove Time Remap", "trash", C.CARD2, C.RED) { [weak self] in
                    guard let self = self else { return }
                    self.pushUndo()
                    l.track("remapT").keys.removeAll()
                    self.refreshPanel(); self.render()
                }, 42)
                text(p, "Tap the name, then the keyframe diamond, to add a keyframe at the playhead.", C.DIM, 12)
            }

            text(p, "Frame Interpolation", C.TEXT, 16, true)
            let itr = l.track("remapInterp")
            p.addArrangedSubview(chipRow(["Off", "Frame Blend", "Optical Flow"], Int(itr.base)) { [weak self] i in
                guard let self = self else { return }
                self.pushUndo()
                self.ensureRemap(l)
                itr.keys.removeAll()
                itr.base = Float(i)
                self.refreshPanel(); self.render()
            })
            switch Int(itr.base) {
            case 1: text(p, "Blends the two source frames around each moment, so slow motion looks smooth instead of stepping.", C.DIM, 12)
            case 2: text(p, "Optical Flow currently uses Frame Blend. It applies to video layers.", C.DIM, 12)
            default: text(p, "Shows the nearest source frame. Slow motion on video can look steppy.", C.DIM, 12)
            }
            if l.type != .VIDEO { text(p, "Frame interpolation only affects video layers.", C.DIM, 12) }
        }

        func ensureRemap(_ l: Layer) {
            if !l.fx.contains("remap") { l.fx.append("remap") }
            l.fxOff.remove("remap")
        }

        /// Creates the two identity Time Remap keyframes when none exist yet.
        func ensureRemapKeys(_ l: Layer) {
            ensureRemap(l)
            let tr = l.track("remapT")
            if !tr.keys.isEmpty { return }
            let sp = l.track("remapSpeed").base
            tr.keys.append(Key(l.start, 0, .LINEAR))
            tr.keys.append(Key(l.end, (l.end - l.start) * sp, .LINEAR))
        }

        /// Holds the current source frame for one second, pushing later keyframes back.
        func freezeFrame(_ l: Layer) {
            ensureRemapKeys(l)
            let tr = l.track("remapT")
            let t = Editor.time
            let v = tr.eval(t)
            let hold: Float = 1
            for k in tr.keys where k.t > t + 0.001 { k.t += hold }
            if !tr.keys.contains(where: { abs($0.t - t) < 0.001 }) { tr.keys.append(Key(t, v, .LINEAR)) }
            tr.keys.append(Key(t + hold, v, .LINEAR))
            tr.keys.sort { $0.t < $1.t }
        }

        /// Plays the layer backwards.
        func reverseRemap(_ l: Layer) {
            ensureRemap(l)
            let tr = l.track("remapT")
            tr.keys.removeAll()
            tr.keys.append(Key(l.start, l.end - l.start, .LINEAR))
            tr.keys.append(Key(l.end, 0, .LINEAR))
        }
}
