// EditorFlare.swift — the Optical Flare library + customization overlay.

import UIKit

extension EditorViewController {
        // ================================================================ layers

        // ---------------------------------------------------------------- optical flares


        /// The "Optical Flare" button: pick a preset from the thumbnails, or Customize.
        func showFlareLibrary() {
            Flare.loadUser()
            let all = Flare.builtin() + Flare.user
            FlareThumbs.generate(preview, all) { }
            let sv = CapScroll()
            let col = vStack()
            col.isLayoutMarginsRelativeArrangement = true
            col.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 4, leading: 4, bottom: 4, trailing: 4)
            sv.addSubview(col)
            col.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                col.topAnchor.constraint(equalTo: sv.contentLayoutGuide.topAnchor),
                col.bottomAnchor.constraint(equalTo: sv.contentLayoutGuide.bottomAnchor),
                col.leadingAnchor.constraint(equalTo: sv.contentLayoutGuide.leadingAnchor),
                col.trailingAnchor.constraint(equalTo: sv.contentLayoutGuide.trailingAnchor),
                col.widthAnchor.constraint(equalTo: sv.frameLayoutGuide.widthAnchor)
            ])
            var row: UIStackView? = nil
            for (i, f) in all.enumerated() {
                if i % 2 == 0 {
                    let r = hRow()
                    r.distribution = .fillEqually
                    col.addArrangedSubview(r)
                    row = r
                }
                let th = FlareThumb(f.sig(), f.name)
                let ff = f
                th.onClick = { [weak self] in
                    Dlg.dismissCurrent()
                    self?.addFlare(ff.copy(), false)
                }
                put(row!, th, 112, 4, 4)
            }
            text(col, "Scroll down to build your own.", C.DIM, 12)
            put(col, pill("Customize", "edit", C.GREEN, C.ONDARK) { [weak self] in
                Dlg.dismissCurrent()
                self?.addFlare(Flare.deflt(), true)
            }, 52, 10, 6)
            _ = Dlg(self).setTitle("Optical Flare").setView(sv).setNegativeButton("Close", nil).show()
        }

        func addFlare(_ f: Flare, _ customize: Bool) {
            let l = addLayer(.FLARE)
            l.name = "Optical Flare \(l.id)"
            l.flare = f
            let asp = Float(Editor.project.w) / Float(Editor.project.h)
            l.track("x").base = -0.45 * asp
            l.track("y").base = 0.3
            if customize { openFlareEditor(l) } else { render(); refreshPanel() }
        }

        func openFlareEditor(_ l: Layer) {
            if flareOverlay != nil { return }
            if l.flare == nil { l.flare = Flare.deflt() }
            pushUndo()
            flareLayer = l
            let b = JObj().put("flare", l.flare!.toJson())
            for d in Defs.flare { b.put(d.key, Double(l.track(d.key).base)) }
            flareBackup = b
            flTab = 0
            flSel = 0
            Flare.loadUser()
            buildFlareOverlay()
        }

        func closeFlareEditor(_ save: Bool) {
            if let l = flareLayer, !save, let b = flareBackup {
                if let fo = b.optJSONObject("flare") { l.flare = Flare.fromJson(fo) }
                for d in Defs.flare { l.track(d.key).base = b.optFloat(d.key, d.def) }
            }
            flareOverlay?.removeFromSuperview()
            flareOverlay = nil; flareContent = nil; flareLayer = nil; flareTabs = nil
            render(); refreshPanel()
        }

        func buildFlareOverlay() {
            let ov = vStack()
            ov.backgroundColor = argbToUIColor(Int32(bitPattern: 0xE6000000))
            let panel = vStack()
            panel.backgroundColor = argbToUIColor(C.PANEL)
            panel.layer.cornerRadius = 16
            panel.layer.masksToBounds = true
            let bar = hRow()
            bar.isLayoutMarginsRelativeArrangement = true
            bar.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 8, bottom: 0, trailing: 8)
            bar.backgroundColor = argbToUIColor(C.PANEL)
            bar.addArrangedSubview(wrap(pill("Cancel") { [weak self] in self?.closeFlareEditor(false) }, 92, 40, 0, 0, 0, 0))
            let tt = UILabel()
            tt.text = "Optical Flare"
            tt.textColor = argbToUIColor(C.TEXT)
            tt.font = boldFont(16)
            tt.textAlignment = .center
            tt.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
            bar.addArrangedSubview(tt)
            bar.addArrangedSubview(wrap(pill("Save", nil, C.GREEN, C.ONDARK) { [weak self] in self?.closeFlareEditor(true) }, 92, 40, 0, 0, 0, 0))
            let tabs = TabBar(["Presets", "Elements", "Edit", "Global"], flTab) { [weak self] i in
                guard let self = self else { return }
                self.flTab = i
                self.refreshFlare()
            }
            flareTabs = tabs
            let sv = CapScroll()
            let content = vStack()
            content.isLayoutMarginsRelativeArrangement = true
            content.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 4, leading: 8, bottom: 12, trailing: 8)
            sv.addSubview(content)
            content.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                content.topAnchor.constraint(equalTo: sv.contentLayoutGuide.topAnchor),
                content.bottomAnchor.constraint(equalTo: sv.contentLayoutGuide.bottomAnchor),
                content.leadingAnchor.constraint(equalTo: sv.contentLayoutGuide.leadingAnchor),
                content.trailingAnchor.constraint(equalTo: sv.contentLayoutGuide.trailingAnchor),
                content.widthAnchor.constraint(equalTo: sv.frameLayoutGuide.widthAnchor)
            ])
            flareContent = content
            let spacerView = UIView()
            spacerView.setContentHuggingPriority(UILayoutPriority(1), for: .vertical)
            ov.addArrangedSubview(wrap(bar, 0, 52, 0, 0, 0, 0))
            ov.addArrangedSubview(spacerView)
            ov.addArrangedSubview(wrap(tabs, 0, 44, 0, 0, 0, 0))
            ov.addArrangedSubview(sv)
            sv.setContentHuggingPriority(UILayoutPriority(1), for: .vertical)
            flareOverlay = ov
            screen.addSubview(ov)
            ov.frame = screen.safeAreaLayoutGuide.layoutFrame
            ov.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            refreshFlare()
        }

        func refreshFlare() {
            guard let l = flareLayer, let f = l.flare, let p = flareContent else { return }
            p.arrangedSubviews.forEach { $0.removeFromSuperview() }
            flareTabs?.sel = flTab
            flareTabs?.setNeedsDisplay()
            if flSel >= f.els.count { flSel = max(f.els.count - 1, 0) }
            switch flTab {
            case 0: flarePresets(p, l, f)
            case 1: flareElements(p, l, f)
            case 2: flareEditEl(p, l, f)
            default: flareGlobal(p, l, f)
            }
        }

        func flarePresets(_ p: UIStackView, _ l: Layer, _ f: Flare) {
            let all = Flare.builtin() + Flare.user
            FlareThumbs.generate(preview, all) { }
            var row: UIStackView? = nil
            for (i, pr) in all.enumerated() {
                if i % 3 == 0 {
                    let r = hRow()
                    r.distribution = .fillEqually
                    p.addArrangedSubview(r)
                    row = r
                }
                let th = FlareThumb(pr.sig(), pr.name)
                th.onClick = { [weak self] in
                    guard let self = self else { return }
                    l.flare = pr.copy()
                    self.flSel = 0
                    self.refreshFlare(); self.render()
                }
                put(row!, th, 96, 3, 3)
            }
            put(p, pill("Save as my preset", "plus") { [weak self] in
                guard let self = self else { return }
                let et = UITextField(frame: .zero)
                et.placeholder = "Preset name"
                et.text = f.name
                _ = Dlg(self).setTitle("Save preset").setView(et).setPositiveButton("Save") { [weak self] _, _ in
                    guard let self = self else { return }
                    let c = f.copy()
                    let nm = et.text?.trimmingCharacters(in: .whitespaces) ?? ""
                    c.name = nm.isEmpty ? "My flare \(Flare.user.count + 1)" : nm
                    Flare.user.append(c)
                    Flare.saveUser()
                    self.refreshFlare()
                }.setNegativeButton("Cancel", nil).show()
            }, 44, 10, 4)
            text(p, "Tap a preset to replace the flare.", C.DIM, 12)
        }

        func flareElements(_ p: UIStackView, _ l: Layer, _ f: Flare) {
            put(p, pill("Add element", "plus", C.GREEN, C.ONDARK) { [weak self] in
                guard let self = self else { return }
                _ = Dlg(self).setTitle("Add element").setItems(FlareEl.TYPES) { [weak self] _, w in
                    guard let self = self, let ff = self.flareLayer?.flare else { return }
                    let e = FlareEl(w)
                    switch w {
                    case 1, 5: e.size = 0.4; e.thick = 0.1
                    case 2: e.size = 1.2; e.stretch = 10; e.thick = 0.04; e.pos = 0
                    case 3: e.size = 0.9; e.pos = 0; e.rays = 12
                    case 4: e.size = 0.12; e.thick = 1
                    case 6: e.size = 0.05
                    default: e.pos = 0
                    }
                    ff.els.append(e)
                    self.flSel = ff.els.count - 1
                    self.flTab = 2
                    self.refreshFlare(); self.render()
                }.show()
            }, 46)
            if f.els.isEmpty { text(p, "No elements. Add a Glow to start.", C.DIM, 13) }
            for (i, e) in f.els.enumerated() {
                let row = hRow()
                row.backgroundColor = argbToUIColor(i == flSel ? Int32(bitPattern: 0xFF2A2A30) : C.CARD)
                row.isLayoutMarginsRelativeArrangement = true
                row.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 4, bottom: 0, trailing: 2)
                let eye = IconView(e.enabled ? "eye" : "eye_off", e.enabled ? Int32(bitPattern: 0xFFFFFFFF) : C.DIM, 20)
                eye.onClick = { [weak self] in e.enabled = !e.enabled; self?.refreshFlare(); self?.render() }
                row.addArrangedSubview(wrap(eye, 40, 48, 0, 0, 0, 0))
                let sw = UIView()
                sw.backgroundColor = argbToUIColor(e.color | Int32(bitPattern: 0xFF000000))
                row.addArrangedSubview(wrap(sw, 10, 26, 0, 0, 0, 0))
                let tv = UILabel()
                tv.text = "  " + e.label() + "  (" + String(format: "%.2f", e.pos) + ")"
                tv.textColor = argbToUIColor(C.TEXT)
                tv.font = sysFont(14)
                tv.numberOfLines = 1
                tv.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
                let tap = TapView()
                tap.addSubview(tv)
                tv.frame = .zero
                tap.onClick = { [weak self] in
                    guard let self = self else { return }
                    self.flSel = i; self.flTab = 2
                    self.refreshFlare()
                }
                row.addArrangedSubview(tap)
                func btn(_ icon: String, _ tint: Int32, _ click: @escaping () -> Void) {
                    let b = IconView(icon, tint, 18)
                    b.onClick = click
                    row.addArrangedSubview(wrap(b, 34, 48, 0, 0, 0, 0))
                }
                btn("chev_up", Int32(bitPattern: 0xFFFFFFFF)) { [weak self] in
                    guard let self = self else { return }
                    if i > 0 { let e2 = f.els.remove(at: i); f.els.insert(e2, at: i - 1); self.flSel = i - 1; self.refreshFlare(); self.render() }
                }
                btn("chev_down", Int32(bitPattern: 0xFFFFFFFF)) { [weak self] in
                    guard let self = self else { return }
                    if i < f.els.count - 1 { let e2 = f.els.remove(at: i); f.els.insert(e2, at: i + 1); self.flSel = i + 1; self.refreshFlare(); self.render() }
                }
                btn("dup", Int32(bitPattern: 0xFFFFFFFF)) { [weak self] in
                    guard let self = self else { return }
                    f.els.insert(e.copy(), at: i + 1)
                    self.flSel = i + 1
                    self.refreshFlare(); self.render()
                }
                btn("trash", C.RED) { [weak self] in
                    guard let self = self else { return }
                    f.els.remove(at: i)
                    self.refreshFlare(); self.render()
                }
                put(p, row, 0, 3, 3)
            }
            text(p, "Position 0 is the light itself, 1 is the screen center and 2 is the opposite side. Tap an element to edit it.", C.DIM, 12)
        }

        func flareEditEl(_ p: UIStackView, _ l: Layer, _ f: Flare) {
            if f.els.isEmpty { text(p, "Add an element in the Elements tab first.", C.DIM, 13); return }
            let e = f.els[flSel]
            text(p, "Editing: " + e.label() + "  (" + String(flSel + 1) + " of " + String(f.els.count) + ")", C.GREEN, 14, true)
            p.addArrangedSubview(chipRow(FlareEl.TYPES, e.type) { [weak self] i in
                guard let self = self else { return }
                e.type = i
                self.refreshFlare(); self.render()
            })
            addPlain(p, "Position on axis", -1, 3, e.pos, 2) { e.pos = $0; self.render() }
            addPlain(p, "Size", 0.01, 2, e.size, 3) { e.size = $0; self.render() }
            if e.type == 0 || e.type == 2 || e.type == 1 || e.type == 5 { addPlain(p, "Stretch (width / height)", 0.1, 20, e.stretch, 2) { e.stretch = $0; self.render() } }
            addPlain(p, "Rotation", -180, 180, e.rot, 0) { e.rot = $0; self.render() }
            addPlain(p, "Brightness", 0, 4, e.bright, 2) { e.bright = $0; self.render() }
            addPlain(p, "Softness", 0, 1, e.soft, 2) { e.soft = $0; self.render() }
            if e.type == 1 || e.type == 2 || e.type == 4 || e.type == 5 { addPlain(p, e.type == 4 ? "Outline thickness (1 = filled)" : "Thickness", 0.01, 1, e.thick, 2) { e.thick = $0; self.render() } }
            if e.type == 4 { addPlain(p, "Sides", 3, 12, Float(e.sides), 0) { e.sides = Int($0); self.render() } }
            if e.type == 3 { addPlain(p, "Rays", 2, 32, Float(e.rays), 0) { e.rays = Int($0); self.render() } }
            if e.type == 1 || e.type == 4 || e.type == 5 { addPlain(p, "Rainbow fringe", 0, 1, e.chroma, 2) { e.chroma = $0; self.render() } }
            let fo = SwitchRow()
            fo.label = "Turn with the flare axis"
            fo.on = e.follow
            fo.onToggle = { e.follow = $0; self.render() }
            put(p, fo, 52)
            text(p, "Color", C.GREEN, 13, true)
            addColorRow(p, e.color) { [weak self] c in e.color = c; self?.render() }
        }

        func flareGlobal(_ p: UIStackView, _ l: Layer, _ f: Flare) {
            text(p, "Whole flare", C.GREEN, 14, true)
            text(p, "Tint (multiplies every element)", C.DIM, 12)
            addColorRow(p, f.tint) { [weak self] c in f.tint = c; self?.render() }
            for d in Defs.flare {
                let tr = l.track(d.key)
                addPlain(p, d.label, d.min, d.max, tr.base, d.dec) { [weak self] v in
                    tr.base = v
                    self?.render()
                }
                if !tr.keys.isEmpty { text(p, d.label + " is keyframed. Edit it in the layer's Edit panel.", C.AMBER, 11) }
            }
            text(p, "3D and camera", C.GREEN, 14, true)
            addPlain(p, "Size change with distance", 0, 1, f.depthScale, 2) { [weak self] in f.depthScale = $0; self?.render() }
            addPlain(p, "Fade when the light leaves the screen", 0.01, 1.5, f.edgeFade, 2) { [weak self] in f.edgeFade = $0; self?.render() }
            let d3 = SwitchRow()
            d3.label = "3D layer (follows the camera)"
            d3.on = l.is3d
            d3.onToggle = { [weak self] _ in
                self?.toggle3d()
                self?.refreshFlare()
            }
            put(p, d3, 52)
            text(p, "With 3D on, the light is projected through the camera. Drag the light in the preview to place it.", C.DIM, 12)
        }
}
