// EditorSceneSetup.swift — Scene Setup mode (the top-bar orbit camera).
//
// Brings back the original's Scene Setup: while it is on, one finger orbits
// an editing camera around the 3D scene and a pinch dollies in/out. The
// scene's own camera layers are never touched — leaving the mode restores
// the exact previous view. A floating pill over the preview shows the mode
// and offers a quick exit.
//
// SceneRenderer.editCam layout: [fov°, eyeX, eyeY, eyeZ, rotX°, rotY°].
// The eye sits on a sphere around the origin and the rotation always looks
// back at the origin (rx = -elevation, ry = azimuth).

import UIKit
import ObjectiveC

extension EditorViewController {

    // ---------------------------------------------------------------- state

    /// Extensions cannot hold stored properties, so the pill + gesture list
    /// ride in a small box hung off the view controller with associated
    /// objects (created lazily, removed on exit).
    private final class SceneSetupBox {
        var pill: UIView? = nil
        var gestures: [UIGestureRecognizer] = []
    }

    private var ssBox: SceneSetupBox {
        if let b = objc_getAssociatedObject(self, &SceneSetupKey.box) as? SceneSetupBox { return b }
        let b = SceneSetupBox()
        objc_setAssociatedObject(self, &SceneSetupKey.box, b, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        return b
    }

    private enum SceneSetupKey { static var box: UInt8 = 0 }

    var sceneSetupOn: Bool {
        get { SceneRenderer.editCam != nil }
        set { newValue ? enterSceneSetup() : exitSceneSetup() }
    }

    // ---------------------------------------------------------------- enter / exit

    func enterSceneSetup() {
        guard SceneRenderer.editCam == nil else { return }
        // start from whatever the scene looks like now: the first live camera
        // layer, else the default (eye at z = 3)
        var cam: [Float] = [Editor.scene.fov, 0, 0, 3, 0, 0]
        if let c = Editor.scene.layers.first(where: { $0.type == .CAMERA && $0.visible }),
           Editor.time >= c.start, Editor.time <= c.end {
            let ct = c.editTime("x", Editor.time)
            cam = [c.p("fov", ct), c.p("x", ct), c.p("y", ct), c.p("z", ct),
                   c.p("rotX", ct), c.p("rotY", ct)]
        }
        SceneRenderer.editCam = cam
        buildSceneSetupPill()
        installSceneSetupGestures()
        render()
        toast("Scene setup: drag to orbit, pinch to dolly")
    }

    func exitSceneSetup() {
        SceneRenderer.editCam = nil
        let box = ssBox
        box.pill?.removeFromSuperview()
        box.pill = nil
        for g in box.gestures { g.view?.removeGestureRecognizer(g) }
        box.gestures.removeAll()
        render()
    }

    func toggleSceneSetup() { sceneSetupOn ? exitSceneSetup() : enterSceneSetup() }

    // ---------------------------------------------------------------- floating pill

    private func buildSceneSetupPill() {
        guard ssBox.pill == nil else { return }
        let pill = UIView()
        pill.backgroundColor = argbToUIColor(Int32(bitPattern: 0xE6162820))
        pill.layer.cornerRadius = 17
        pill.layer.borderWidth = 1
        pill.layer.borderColor = argbToUIColor(C.GREEN).cgColor
        pill.translatesAutoresizingMaskIntoConstraints = false

        let ic = IconView("camera", C.GREEN, 18)
        ic.translatesAutoresizingMaskIntoConstraints = false
        pill.addSubview(ic)
        let lbl = UILabel()
        lbl.text = "SCENE SETUP"
        lbl.font = boldFont(11)
        lbl.textColor = argbToUIColor(C.GREEN)
        lbl.translatesAutoresizingMaskIntoConstraints = false
        pill.addSubview(lbl)
        let x = IconView("close", C.TEXT, 16)
        x.onClick = { [weak self] in self?.exitSceneSetup() }
        x.translatesAutoresizingMaskIntoConstraints = false
        pill.addSubview(x)

        NSLayoutConstraint.activate([
            ic.leadingAnchor.constraint(equalTo: pill.leadingAnchor, constant: 10),
            ic.centerYAnchor.constraint(equalTo: pill.centerYAnchor),
            lbl.leadingAnchor.constraint(equalTo: ic.trailingAnchor, constant: 6),
            lbl.centerYAnchor.constraint(equalTo: pill.centerYAnchor),
            x.leadingAnchor.constraint(equalTo: lbl.trailingAnchor, constant: 8),
            x.trailingAnchor.constraint(equalTo: pill.trailingAnchor, constant: -6),
            x.centerYAnchor.constraint(equalTo: pill.centerYAnchor),
            pill.heightAnchor.constraint(equalToConstant: 34),
        ])
        view.addSubview(pill)
        NSLayoutConstraint.activate([
            pill.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 58),
            pill.centerXAnchor.constraint(equalTo: view.centerXAnchor),
        ])
        ssBox.pill = pill
    }

    // ---------------------------------------------------------------- gestures

    private func installSceneSetupGestures() {
        let box = ssBox
        guard box.gestures.isEmpty else { return }
        guard let host = preview.superview ?? (preview as UIView?) else { return }

        let pan = UIPanGestureRecognizer(target: self, action: #selector(ssPanned(_:)))
        pan.maximumNumberOfTouches = 1
        pan.cancelsTouchesInView = true
        host.addGestureRecognizer(pan)

        let pinch = UIPinchGestureRecognizer(target: self, action: #selector(ssPinched(_:)))
        pinch.cancelsTouchesInView = true
        host.addGestureRecognizer(pinch)

        box.gestures = [pan, pinch]
    }

    /// Orbit: the eye moves on the sphere, the camera keeps looking at the origin.
    @objc private func ssPanned(_ g: UIPanGestureRecognizer) {
        guard g.state == .changed, var e = SceneRenderer.editCam, e.count == 6 else { return }
        let v = g.translation(in: g.view)
        g.setTranslation(.zero, in: g.view)
        let dist = max(0.6, sqrt(e[1] * e[1] + e[2] * e[2] + e[3] * e[3]))
        var pitch = -e[4] + Float(v.y) * 0.35      // elevation in degrees
        let yaw = e[5] - Float(v.x) * 0.35         // azimuth in degrees
        pitch = clamp(pitch, -89, 89)
        let pr = pitch * Float.pi / 180
        let yr = yaw * Float.pi / 180
        e[1] = dist * cos(pr) * sin(yr)            // eye x
        e[2] = dist * sin(pr)                      // eye y
        e[3] = dist * cos(pr) * cos(yr)            // eye z
        e[4] = -pitch                              // rotX looks back at the origin
        e[5] = yaw
        SceneRenderer.editCam = e
        render()
    }

    /// Dolly: scale the eye vector, rotation stays the same.
    @objc private func ssPinched(_ g: UIPinchGestureRecognizer) {
        guard g.state == .changed, var e = SceneRenderer.editCam, e.count == 6 else { return }
        let dist = max(0.6, sqrt(e[1] * e[1] + e[2] * e[2] + e[3] * e[3]))
        let nd = clamp(dist / Float(max(g.scale, 0.01)), 0.6, 24)
        g.scale = 1
        let k = nd / dist
        e[1] *= k
        e[2] *= k
        e[3] *= k
        SceneRenderer.editCam = e
        render()
    }
}
