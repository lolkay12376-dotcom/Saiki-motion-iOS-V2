/* CCrashLog — async-signal-safe crash logger (Round 19 design, source edition)
 *
 * Rules this file obeys (the lessons of rounds 14-19, paid for in crashes):
 *   1. A signal handler may ONLY use write(2)-family syscalls and touch
 *      memory that was allocated BEFORE the crash. No malloc, no stdio,
 *      no Objective-C, no Swift, no locks.
 *   2. The log fd is pre-opened at install time; the ring buffer is static.
 *   3. After writing the report the handler restores the default disposition
 *      and re-raises, so iOS still produces its own .ips for the crash log
 *      list — our report is the readable companion, not a replacement.
 */

#ifndef CCRASHLOG_H
#define CCRASHLOG_H

#include <stdint.h>

/* Called once from Swift at process start (before any UI work).
 * dir_fd_path is "<Documents>/Crash" — the directory must exist already;
 * this function creates the log file and pre-opens it. Returns 0 on success. */
int ccrash_install(const char *dir_path);

/* Record an action tag in the ring (async-signal-safe, lock-free single-writer).
 * Called from Swift at interesting points: "edit", "save", "impv", "vdb", ... */
void ccrash_note(const char *tag);

/* Watchdog exports the freeze state before it aborts; the handler prints it. */
void ccrash_set_watchdog(int frozen, const char *detail);

/* Write a freeze report (called by the watchdog thread, not a handler). */
void ccrash_report_freeze(const char *detail);

#endif /* CCRASHLOG_H */
