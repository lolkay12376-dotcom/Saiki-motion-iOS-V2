// Editor.swift — the editor's session state (Core).
//
// Kotlin `object Editor`. The open project, the active scene index and the
// playhead time live here so every module (timeline, preview, graph, audio)
// reads the same source of truth while the EditorActivity is on screen.

import Foundation

enum Editor {
    static var project: Project = Project(name: "Untitled")
    static var sceneIndex: Int = 0
    static var time: Float = 0

    /// Safety net for a project whose scenes array is empty (hand-edited or
    /// corrupted JSON): a shared stand-in scene so `Editor.scene` can never
    /// index out of range and crash the app on open/undo-restore.
    private static let emptyScene = Scene("Scene 1")

    /// The scene `sceneIndex` points at (first scene as a safety net).
    static var scene: Scene {
        get {
            if project.scenes.indices.contains(sceneIndex) { return project.scenes[sceneIndex] }
            return project.scenes.first ?? emptyScene
        }
        set {
            if project.scenes.indices.contains(sceneIndex) {
                project.scenes[sceneIndex] = newValue
            } else if !project.scenes.isEmpty {
                project.scenes[0] = newValue
            } else {
                // repairing an empty project: give it its first scene back
                project.scenes = [newValue]
                sceneIndex = 0
            }
        }
    }
}
