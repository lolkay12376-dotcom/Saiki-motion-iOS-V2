// Util.swift — shared small utilities (Core).
//
// Color conversion (Android ARGB Int32 ↔ UIColor), math helpers with Kotlin
// semantics, the background-thread helper, Paths, the toast (Snack), the
// capped scroll view and the Dlg dialog builder. Everything here is
// dependency-free so any file can use it.

import UIKit
import Foundation

// MARK: - Colors

/// Android ARGB Int32 → UIColor (the whole app speaks ARGB Int32 like Kotlin).
func argbToUIColor(_ argb: Int32) -> UIColor {
    let a = CGFloat((UInt32(bitPattern: argb) >> 24) & 0xFF) / 255
    let r = CGFloat((UInt32(bitPattern: argb) >> 16) & 0xFF) / 255
    let g = CGFloat((UInt32(bitPattern: argb) >> 8) & 0xFF) / 255
    let b = CGFloat(UInt32(bitPattern: argb) & 0xFF) / 255
    return UIColor(red: r, green: g, blue: b, alpha: a)
}

/// RGBA components → Android ARGB Int32.
func argbColor(_ a: Int, _ r: Int, _ g: Int, _ b: Int) -> Int32 {
    Int32(bitPattern: (UInt32(clamping: a) << 24) | (UInt32(clamping: r) << 16)
          | (UInt32(clamping: g) << 8) | UInt32(clamping: b))
}

func colorAlpha(_ c: Int32) -> Int { Int((UInt32(bitPattern: c) >> 24) & 0xFF) }
func colorRed(_ c: Int32) -> Int { Int((UInt32(bitPattern: c) >> 16) & 0xFF) }
func colorGreen(_ c: Int32) -> Int { Int((UInt32(bitPattern: c) >> 8) & 0xFF) }
func colorBlue(_ c: Int32) -> Int { Int(UInt32(bitPattern: c) & 0xFF) }

// MARK: - Math (Kotlin semantics)

func clamp<T: Comparable>(_ v: T, _ lo: T, _ hi: T) -> T {
    if v < lo { return lo }
    if v > hi { return hi }
    return v
}

/// kotlin.math.round — round half away from zero (Swift's .rounded() does
/// the same, spelled out here for clarity).
func kotlinRound(_ v: Float) -> Float { v.rounded() }

/// System.currentTimeMillis() equivalent used for media file names.
func nowMs() -> Int64 { Int64(Date().timeIntervalSince1970 * 1000) }

/// java.util.Random-style LCG — deterministic per seed so wiggle/noise
/// expressions and particle fields replay identically.
func ktRandom(_ seed: inout UInt64) -> UInt64 {
    seed = seed &* 6364136223846793005 &+ 1442695040888963407
    return seed
}

/// Deterministic 1-D value noise used by expressions (Kotlin `noise`).
func noise1(_ x: Float) -> Float {
    let i = floorf(x)
    let f = x - i
    let u = f * f * (3 - 2 * f)
    let h = { (n: Float) -> Float in
        // Float → raw bits is the `.bitPattern` PROPERTY in Swift — there is
        // no UInt32(bitPattern: Float) initializer (that init only exists
        // for same-size integer pairs like Int32 ↔ UInt32).
        var s = n.bitPattern
        s = s &* 747796405 &+ 2891336453
        s = ((s >> ((s >> 28) + 4)) ^ s) &* 277803737
        s = (s >> 22) ^ s
        return Float(s % 1000) / 1000
    }
    return h(i) * (1 - u) + h(i + 1) * u
}

// MARK: - Threads

/// Thread { start() } + join-free equivalent: run `body` off the main thread.
/// The Kotlin code used raw threads everywhere; one helper keeps the naming.
func safeThread(_ label: String, _ body: @escaping () -> Void) {
    Thread.detachNewThread {
        body()
    }
}

// MARK: - Paths

/// Filesystem locations the Kotlin app reached through Environment / cacheDir.
enum Paths {
    static var root: URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? FileManager.default.temporaryDirectory
        return docs.appendingPathComponent("SaikiMotion", isDirectory: true)
    }

    static var cache: URL {
        let c = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask).first
            ?? FileManager.default.temporaryDirectory
        return c.appendingPathComponent("SaikiMotion", isDirectory: true)
    }

    static func ensure() {
        try? FileManager.default.createDirectory(at: cache, withIntermediateDirectories: true)
        try? FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
    }
}

// MARK: - Snack (the toast)

/// Snackbar replacement. Two call shapes, exactly like the Kotlin helper:
/// a plain `Snack.show(text)` for non-VC contexts and `Snack.show(vc, text)`.
enum Snack {
    private static var current: UILabel? = nil
    private static var hideWork: DispatchWorkItem? = nil

    static func show(_ vc: UIViewController, _ text: String) { show(text) }

    static func show(_ text: String) {
        DispatchQueue.main.async {
            guard let window = appKeyWindow() else { return }
            if let cur = current { cur.removeFromSuperview(); current = nil }
            hideWork?.cancel()
            let lbl = UILabel()
            lbl.text = text
            lbl.textColor = argbToUIColor(C.TEXT)
            lbl.font = sysFont(14)
            lbl.textAlignment = .center
            lbl.numberOfLines = 0
            lbl.backgroundColor = UIColor(red: 34.0 / 255.0, green: 34.0 / 255.0,
                                          blue: 40.0 / 255.0, alpha: 0.96)
            lbl.layer.cornerRadius = 16
            lbl.layer.masksToBounds = true
            let maxW = window.bounds.width - 48
            let sz = lbl.sizeThatFits(CGSize(width: maxW, height: .greatestFiniteMagnitude))
            let w = min(maxW, sz.width + 36)
            let h = sz.height + 24
            lbl.frame = CGRect(x: (window.bounds.width - w) / 2,
                               y: window.bounds.height - 170 - h, width: w, height: h)
            lbl.alpha = 0
            window.addSubview(lbl)
            current = lbl
            UIView.animate(withDuration: 0.15) { lbl.alpha = 1 }
            let work = DispatchWorkItem {
                UIView.animate(withDuration: 0.35, animations: { lbl.alpha = 0 }) { _ in
                    lbl.removeFromSuperview()
                    if Snack.current === lbl { Snack.current = nil }
                }
            }
            hideWork = work
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.4, execute: work)
        }
    }
}

// MARK: - CapScroll

/// ScrollView whose content never scrolls past its frame — the Kotlin app
/// wrapped long dialogs in a "capped" scroller so short content never
/// wobbles. Also grows with content up to a max height when used inline.
final class CapScroll: UIScrollView {
    var maxContentHeight: CGFloat = 10_000

    override init(frame: CGRect) {
        super.init(frame: frame)
        showsVerticalScrollIndicator = true
        alwaysBounceVertical = false
        backgroundColor = .clear
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - Dlg

/// AlertDialog replacement: a dimmed overlay card on the key window with a
/// builder chain — setTitle / setMessage / setView / setItems / setIconItems /
/// setPositiveButton / setNegativeButton / setNeutralButton / create / show.
///
/// Button and item callbacks receive the dialog and the index (0 = positive,
/// 1 = neutral, 2 = negative for buttons; the picked row for items), which is
/// the shape every Kotlin handler in the port uses.
///
/// Lifetime: the dim view holds BOTH the card and this Dlg object via
/// associated objects for exactly as long as it stays in the window, so the
/// button/item handlers can safely capture the dialog weakly. Nothing else
/// may retain a Dlg — dismiss() removes the dim from the window, which
/// releases the whole cluster (dim, card, dialog) in one step.
///
/// NSObject base (fix16): the dialog is stored as an associated object with
/// a retain policy — that path is only defined for real ObjC objects.
final class Dlg: NSObject {
    private weak var owner: UIViewController?
    private var title: String? = nil
    private var message: String? = nil
    private var customView: UIView? = nil
    private var items: [String] = []
    private var itemIcons: [String]? = nil
    private var onItem: ((Dlg, Int) -> Void)? = nil
    private var buttons: [(String, Int, ((Dlg, Int) -> Void)?)] = []
    /// WEAK on purpose: the window owns the dim while the dialog is shown,
    /// and the dim owns this Dlg through its associated object (see show()).
    /// A strong overlay would close a dim ↔ Dlg retain cycle and leak both.
    private weak var overlay: UIView? = nil

    private static weak var current: Dlg? = nil

    init(_ owner: UIViewController) {
        self.owner = owner
    }

    @discardableResult
    func setTitle(_ t: String) -> Dlg { title = t; return self }

    @discardableResult
    func setMessage(_ m: String) -> Dlg { message = m; return self }

    @discardableResult
    func setView(_ v: UIView) -> Dlg { customView = v; return self }

    @discardableResult
    func setItems(_ labels: [String], _ cb: @escaping (Dlg, Int) -> Void) -> Dlg {
        items = labels; itemIcons = nil; onItem = cb; return self
    }

    @discardableResult
    func setIconItems(_ labels: [String], _ icons: [String], _ cb: @escaping (Dlg, Int) -> Void) -> Dlg {
        items = labels; itemIcons = icons; onItem = cb; return self
    }

    @discardableResult
    func setPositiveButton(_ t: String, _ cb: ((Dlg, Int) -> Void)?) -> Dlg {
        buttons.append((t, 0, cb)); return self
    }

    @discardableResult
    func setNeutralButton(_ t: String, _ cb: ((Dlg, Int) -> Void)?) -> Dlg {
        buttons.append((t, 1, cb)); return self
    }

    @discardableResult
    func setNegativeButton(_ t: String, _ cb: ((Dlg, Int) -> Void)?) -> Dlg {
        buttons.append((t, 2, cb)); return self
    }

    /// Builds the dialog without showing it (the scene dialog rebuilds its
    /// content while open, so it needs create() then show()).
    @discardableResult
    func create() -> Dlg { self }

    @discardableResult
    func show() -> Dlg {
        Dlg.dismissCurrent()
        guard let window = appKeyWindow() else { return self }
        Dlg.current = self

        let dim = UIView(frame: window.bounds)
        dim.backgroundColor = UIColor(white: 0, alpha: 0.55)
        dim.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        let tap = UITapGestureRecognizer(target: self, action: #selector(dimsTapped))
        dim.addGestureRecognizer(tap)
        window.addSubview(dim)

        let card = UIView()
        card.backgroundColor = argbToUIColor(C.PANEL)
        card.layer.cornerRadius = 18
        card.layer.masksToBounds = true

        let col = UIStackView()
        col.axis = .vertical
        col.alignment = .fill
        col.spacing = 0
        col.translatesAutoresizingMaskIntoConstraints = false
        card.addSubview(col)
        NSLayoutConstraint.activate([
            col.topAnchor.constraint(equalTo: card.topAnchor, constant: 14),
            col.bottomAnchor.constraint(lessThanOrEqualTo: card.bottomAnchor, constant: -12),
            col.leadingAnchor.constraint(equalTo: card.leadingAnchor, constant: 18),
            col.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -18),
        ])

        var topH: CGFloat = 14
        if let t = title {
            let l = UILabel()
            l.text = t
            l.textColor = argbToUIColor(C.TEXT)
            l.font = boldFont(17)
            l.numberOfLines = 0
            col.addArrangedSubview(l)
            topH += 24
        }
        if let m = message {
            let l = UILabel()
            l.text = m
            l.textColor = argbToUIColor(C.DIM)
            l.font = sysFont(13)
            l.numberOfLines = 0
            col.addArrangedSubview(l)
            topH += 18
        }
        if !items.isEmpty {
            let sv = CapScroll()
            let list = UIStackView()
            list.axis = .vertical
            list.spacing = 0
            list.translatesAutoresizingMaskIntoConstraints = false
            sv.addSubview(list)
            NSLayoutConstraint.activate([
                list.topAnchor.constraint(equalTo: sv.contentLayoutGuide.topAnchor),
                list.bottomAnchor.constraint(equalTo: sv.contentLayoutGuide.bottomAnchor),
                list.leadingAnchor.constraint(equalTo: sv.contentLayoutGuide.leadingAnchor),
                list.trailingAnchor.constraint(equalTo: sv.contentLayoutGuide.trailingAnchor),
                list.widthAnchor.constraint(equalTo: sv.frameLayoutGuide.widthAnchor),
            ])
            for (i, label) in items.enumerated() {
                let row = UIStackView()
                row.axis = .horizontal
                row.alignment = .center
                row.spacing = 8
                row.isLayoutMarginsRelativeArrangement = true
                row.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 8, bottom: 0, trailing: 4)
                if itemIcons != nil {
                    let iv = IconView(itemIcons?[i] ?? "file", C.TEXT, 22)
                    iv.isUserInteractionEnabled = false
                    iv.translatesAutoresizingMaskIntoConstraints = false
                    iv.widthAnchor.constraint(equalToConstant: 30).isActive = true   // had no size → icons were invisible
                    iv.heightAnchor.constraint(equalToConstant: 30).isActive = true
                    row.addArrangedSubview(iv)
                }
                let l = UILabel()
                l.text = label
                l.textColor = argbToUIColor(C.TEXT)
                l.font = sysFont(15)
                l.numberOfLines = 1
                l.textAlignment = .left               // icon + text sit on the left side
                row.semanticContentAttribute = .forceLeftToRight
                l.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
                row.addArrangedSubview(l)
                let tapV = TapView()
                tapV.addSubview(row)
                // rows were never sized (frame .zero), so every list dialog looked empty
                row.translatesAutoresizingMaskIntoConstraints = false
                row.isUserInteractionEnabled = false
                NSLayoutConstraint.activate([
                    row.leadingAnchor.constraint(equalTo: tapV.leadingAnchor),
                    row.trailingAnchor.constraint(equalTo: tapV.trailingAnchor),
                    row.topAnchor.constraint(equalTo: tapV.topAnchor),
                    row.bottomAnchor.constraint(equalTo: tapV.bottomAnchor),
                ])
                tapV.onClick = { [weak self] in
                    guard let self = self else { return }
                    let cb = self.onItem
                    self.dismiss()
                    cb?(self, i)
                }
                list.addArrangedSubview(tapV)
                tapV.heightAnchor.constraint(equalToConstant: 46).isActive = true
            }
            col.addArrangedSubview(sv)
            sv.heightAnchor.constraint(lessThanOrEqualToConstant: 340).isActive = true
            // the scroll view has no intrinsic height: size it to its rows (was collapsing to 0)
            let fit = sv.heightAnchor.constraint(equalTo: list.heightAnchor)
            fit.priority = UILayoutPriority(750)
            fit.isActive = true
        }
        if let v = customView {
            col.addArrangedSubview(v)
        }

        // buttons — the original's Android-style order: negative (Cancel)
        // on the left, positive (Create/OK) on the right
        let btns = buttons.sorted { $0.1 > $1.1 }   // negative, neutral, positive
        if !btns.isEmpty {
            let r = UIStackView()
            r.axis = .horizontal
            r.distribution = .fillEqually
            r.spacing = 8
            r.isLayoutMarginsRelativeArrangement = true
            r.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 10, leading: 0, bottom: 0, trailing: 0)
            for (t, idx, cb) in btns {
                let b = PillButton(t, nil, C.CARD2, idx == 0 ? C.GREEN : C.TEXT)
                b.onClick = { [weak self] in
                    guard let self = self else { return }
                    self.dismiss()
                    cb?(self, idx)
                }
                r.addArrangedSubview(b)
                b.heightAnchor.constraint(equalToConstant: 40).isActive = true
            }
            col.addArrangedSubview(r)
        }

        window.addSubview(card)
        let maxW = min(window.bounds.width - 48, 420)
        let maxH = window.bounds.height * 0.78
        // Tentative full-height frame first so autolayout can resolve the column,
        // then shrink the card around its content (col's bottom is only
        // lessThanOrEqual the card bottom, so the fitting size is exact).
        card.frame = CGRect(x: (window.bounds.width - maxW) / 2,
                            y: (window.bounds.height - maxH) / 2 - 40, width: maxW, height: maxH)
        card.setNeedsLayout()
        card.layoutIfNeeded()
        let need = col.systemLayoutSizeFitting(
            CGSize(width: maxW - 36, height: maxH),
            withHorizontalFittingPriority: .required,
            verticalFittingPriority: .fittingSizeLevel)
        let h = clamp(need.height + 26, 60, maxH)
        card.frame = CGRect(x: (window.bounds.width - maxW) / 2,
                            y: (window.bounds.height - h) / 2 - 40, width: maxW, height: h)
        card.alpha = 0
        card.transform = CGAffineTransform(scaleX: 1.05, y: 1.05)
        overlay = dim
        dim.accessibilityLabel = "dlg-dim"
        objc_setAssociatedObject(dim, &DlgCardKey, card, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        // Lifetime (fix16): nothing else keeps this Dlg alive. `current` is
        // weak, every button/item handler captures it weakly, and gesture
        // targets do NOT retain their target — so the moment the builder
        // chain returned, the Dlg deallocated and Cancel/Create (plus
        // tap-outside and every item row) silently no-op'ed while the
        // orphaned card kept floating on the window. Tying the object to
        // its dim — which the window owns exactly while the dialog is on
        // screen — gives it the same lifetime as the UI; dismiss() removes
        // the dim and releases everything again. No cycle: overlay is weak.
        objc_setAssociatedObject(dim, &DlgSelfKey, self, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        UIView.animate(withDuration: 0.18) {
            card.alpha = 1
            card.transform = .identity
        }
        return self
    }

    func dismiss() {
        if let ov = overlay {
            if let card = objc_getAssociatedObject(ov, &DlgCardKey) as? UIView {
                UIView.animate(withDuration: 0.15, animations: { card.alpha = 0; ov.alpha = 0 }) { _ in
                    card.removeFromSuperview()
                    ov.removeFromSuperview()
                }
            } else {
                ov.removeFromSuperview()
            }
        }
        overlay = nil
        if Dlg.current === self { Dlg.current = nil }
    }

    static func dismissCurrent() {
        current?.dismiss()
    }

    @objc private func dimsTapped() {
        dismiss()
    }
}

private var DlgCardKey: UInt8 = 0
private var DlgSelfKey: UInt8 = 0

// MARK: - misc

extension Array {
    /// Safe subscript so a stale index can never crash list UIs.
    subscript(safe index: Int) -> Element? {
        indices.contains(index) ? self[index] : nil
    }
}
