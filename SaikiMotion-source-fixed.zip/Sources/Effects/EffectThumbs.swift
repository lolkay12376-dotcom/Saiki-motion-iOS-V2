// EffectThumbs.swift — before/after thumbnails for the effect browser (Effects).
//
// Renders every effect in the catalog against generated sample images on a
// background GL context, offscreen, then hands UIImages to `cache` — the
// cards pick them up asynchronously. `__orig:<id>` holds the untouched
// sample; `<id>` holds the processed result. Shader problems land in
// Registry.errors with the same pass, so the browser and the SDK IDE show
// one consistent story.

import UIKit
import OpenGLES
import GLKit
import Foundation

enum EffectThumbs {

    static var cache: [String: UIImage] = [:]
    static var lastError = ""

    private static let queue = DispatchQueue(label: "saiki.thumbs", qos: .utility)
    private static var generating = false

    static func origKey(_ id: String) -> String { "__orig:" + id }

    /// Deterministic hash (String.hashValue changes every launch, which made
    /// the sample picture jump around and defeated the disk cache).
    static func stable(_ s: String) -> Int {
        var h = 5381
        for u in s.unicodeScalars { h = (h &* 33 &+ Int(u.value)) & 0x7fffffff }
        return h
    }

    // Bundled sample photos (Resources/img, bundle root).
    private static let bundledSamples: [(String, String)] = [
        ("fx_woman", "jpg"), ("fx_mountain", "jpg"), ("fx_ramen", "jpg"),
        ("fx_apple", "png"), ("fx_greenscreen", "jpg"),
        ("fx_girl", "jpg"), ("fx_forest", "jpg"), ("anime_portrait", "jpg"),
    ]
    // indices: 0 woman, 1 cows-in-field, 2 ramen, 3 empty (particles),
    //          4 green-screen anime girl, 5 girl, 6 forest, 7 anime portrait

    /// Which sample photo suits an effect: colour work → girl/forest,
    /// keying/masking → green-screen girl/portrait, VHS/overlay/glitch → cows,
    /// particles/generators → empty frame.
    static func sampleIndex(_ def: EffectDef) -> Int {
        let key = (def.id + " " + def.name + " " + def.desc).lowercased()
        let cat = def.category.lowercased()
        let h = stable(def.id)
        func has(_ w: [String]) -> Bool { w.contains { key.contains($0) } }
        if cat == "keying" || has(["chroma", "key", "matte", "mask", "green"]) { return h % 2 == 0 ? 4 : 7 }
        if has(["particle", "emitter", "snow", "rain", "confetti", "sparks"]) || cat == "generate" { return 3 }
        if has(["vhs", "crt", "scan", "grain", "film", "overlay", "glitch", "noise", "tv"])
            || cat == "glitch and motion" || cat == "light and glow" { return 1 }
        if cat == "color" || has(["color", "grade", "lut", "hue", "tone", "curve"]) { return h % 2 == 0 ? 5 : 6 }
        let rest = [0, 2, 7, 1]
        return rest[h % rest.count]
    }
    static func sampleIndex(id: String) -> Int {
        if let d = Registry.byId[id] { return sampleIndex(d) }
        return stable(id) % sampleCount
    }
    static let sampleCount = bundledSamples.count
    private static let imageLock = NSLock()

    private static func bundled(_ i: Int) -> UIImage? {
        guard i >= 0, i < bundledSamples.count else { return nil }
        let (name, ext) = bundledSamples[i]
        guard let u = Bundle.main.url(forResource: name, withExtension: ext),
              let src = UIImage(contentsOfFile: u.path) else { return nil }
        // center-crop to a 256 square once: small uploads, small memory
        let n: CGFloat = 256
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 1
        fmt.opaque = true
        let sc = max(n / src.size.width, n / src.size.height)
        let w = src.size.width * sc, h = src.size.height * sc
        return UIGraphicsImageRenderer(size: CGSize(width: n, height: n), format: fmt).image { _ in
            src.draw(in: CGRect(x: (n - w) / 2, y: (n - h) / 2, width: w, height: h))
        }
    }

    // MARK: disk cache (thumbs are rendered once per build, then just loaded)

    private static var diskDir: URL? = {
        guard let base = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask).first else { return nil }
        let d = base.appendingPathComponent("fxthumbs2-\(AppInfo.build)", isDirectory: true)
        try? FileManager.default.createDirectory(at: d, withIntermediateDirectories: true)
        return d
    }()

    private static func diskName(_ id: String, _ orig: Bool) -> String {
        let safe = id.map { $0.isLetter || $0.isNumber ? String($0) : "_" }.joined()
        return (orig ? "o_" : "a_") + safe + ".jpg"
    }

    private static func loadFromDisk(_ id: String) -> (UIImage, UIImage)? {
        guard let d = diskDir,
              let a = UIImage(contentsOfFile: d.appendingPathComponent(diskName(id, false)).path),
              let b = UIImage(contentsOfFile: d.appendingPathComponent(diskName(id, true)).path) else { return nil }
        return (b, a)
    }

    private static func saveToDisk(_ id: String, _ before: UIImage?, _ after: UIImage?) {
        guard let d = diskDir, let b = before?.jpegData(compressionQuality: 0.85),
              let a = after?.jpegData(compressionQuality: 0.85) else { return }
        try? b.write(to: d.appendingPathComponent(diskName(id, true)), options: .atomic)
        try? a.write(to: d.appendingPathComponent(diskName(id, false)), options: .atomic)
    }

    static func ready(_ id: String) -> Bool { cache[id] != nil }

    /// The raw sample image for an effect id (same variant the generation
    /// pass used for it, so before/after cards match).
    static func raw(_ id: String) -> UIImage? {
        sample(String(sampleIndex(id: id)))
    }

    /// Editor spelling: (vc, preview, done).
    static func generate(_ vc: UIViewController, _ preview: PreviewView?,
                         _ done: @escaping () -> Void) {
        generate(done)
    }

    /// SDK IDE spelling: (done).
    static func generate(_ done: @escaping () -> Void) {
        queue.async {
            runGeneration()
            DispatchQueue.main.async(execute: done)
        }
    }

    /// Renders the whole catalog (skips ids already cached).
    private static func runGeneration() {
        guard !generating else { return }
        generating = true
        defer { generating = false }

        guard let ctx = GLContext.make() else {
            lastError = "GL unavailable"
            return
        }
        let prev = EAGLContext.current()
        EAGLContext.setCurrent(ctx)
        defer { EAGLContext.setCurrent(prev) }

        let size = 256
        let target = Gl.Target(size, size)
        guard let quad = GLProgram(vertex: SceneRenderer.layerQuadVertex, fragment: """
precision mediump float;
varying vec2 vUv;
uniform sampler2D uTex;
uniform float uFlipY;
void main() {
    vec2 p = vec2(vUv.x, mix(vUv.y, 1.0 - vUv.y, uFlipY));
    gl_FragColor = texture2D(uTex, p);
}
""") else {
            lastError = "quad shader failed"
            return
        }

        // sample textures
        var sampleTex: [GLuint] = []
        for i in 0..<sampleCount {
            sampleTex.append(Gl.upload(sample(String(i))) ?? sampleTex.first ?? 0)
        }
        guard let first = sampleTex.first, first != 0 else {
            lastError = "sample upload failed"
            return
        }

        // snapshot the catalog: a concurrent reload must not mutate the
        // array while this background queue iterates it
        let defs = Registry.order
        for def in defs {
            let key = def.id
            if cache[key] != nil { continue }
            if let (b, a) = loadFromDisk(key) {
                cacheMutex.lock()
                cache[origKey(key)] = b
                cache[key] = a
                cacheMutex.unlock()
                continue
            }
            // pass-through defs (remap, particles, transform) show the raw sample
            let passThrough = def.kind == 1 || def.glsl.contains("return src(uv);") && def.props.isEmpty
            if passThrough && def.id != "tile" {
                cacheMutex.lock()
                cache[key] = sample(String(sampleIndex(id: key)))
                cache[origKey(def.id)] = sample(String(sampleIndex(id: key)))
                cacheMutex.unlock()
                continue
            }

            let (src, _) = Gl.effectShaderSource(def)
            guard let prog = GLProgram(vertex: GLProgram.defaultVertex, fragment: src) else {
                Registry.noteError(def.id, Gl.lastShaderLog)
                continue
            }

            let which = min(sampleIndex(def), sampleTex.count - 1)
            let inTex = sampleTex[which]

            // 1 — draw the sample into the target
            target.bind()
            glDisable(GLenum(GL_BLEND))
            glViewport(0, 0, GLsizei(size), GLsizei(size))
            quad.use()
            quad.setFloat("uFlipY", 1)
            quad.setMat3("uMat", [1, 0, 0, 0, 1, 0, 0, 0, 1])
            quad.setVec2("uQuad", 2, 2)
            quad.setFloat("uAspect", 1)
            quad.setTexture("uTex", inTex, 0)
            Gl.drawQuad(quad)

            let before = target.readImage()

            // 2 — apply the effect with default parameter values
            prog.use()
            prog.setTexture("uTex", target.tex, 0)
            prog.setVec2("uRes", Float(size), Float(size))
            prog.setFloat("uTime", 1.7)
            prog.setFloat("uHas0", 0)
            prog.setFloat("uHas1", 0)
            for pd in def.props {
                prog.setFloat(pd.key, pd.def)
            }
            for cp in def.colors {
                let d = UInt32(bitPattern: cp.def)
                prog.setVec4(cp.key,
                             Float((d >> 16) & 0xFF) / 255,
                             Float((d >> 8) & 0xFF) / 255,
                             Float(d & 0xFF) / 255,
                             Float((d >> 24) & 0xFF) / 255)
            }
            Gl.drawQuad(prog)

            let after = target.readImage()

            cacheMutex.lock()
            if let b = before { cache[origKey(def.id)] = b }
            if let a = after { cache[def.id] = a }
            cacheMutex.unlock()
            saveToDisk(def.id, before, after)
            glFlush()
            usleep(3000)   // let the UI thread breathe between effects
        }

        // free sample textures on this context
        for t in sampleTex { Gl.delete(t) }
    }

    private static let cacheMutex = NSLock()

    // MARK: - sample images
    //
    // Deterministic "photos" so every install shows the same cards: a dusk
    // landscape, a colorful still-life and a portrait-ish gradient with
    // strong highlights and shadows (good for glow / keying / color fx).

    private static var sampleImages: [String: UIImage] = [:]

    static func sample(_ variant: String) -> UIImage {
        imageLock.lock()
        defer { imageLock.unlock() }
        if let img = sampleImages[variant] { return img }
        if let i = Int(variant), let b = bundled(i) {
            sampleImages[variant] = b
            return b
        }
        let n = 320
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 1
        let r = UIGraphicsImageRenderer(size: CGSize(width: n, height: n), format: fmt)
        let img = r.image { ctx in
            let c = ctx.cgContext
            let v = Int(variant.last?.wholeNumberValue ?? 0) % 3
            if v == 0 {
                // dusk hills
                let sky = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(),
                                     colors: [UIColor(red: 1.0, green: 0.62, blue: 0.35, alpha: 1).cgColor,
                                              UIColor(red: 0.23, green: 0.16, blue: 0.42, alpha: 1).cgColor] as CFArray,
                                     locations: [0, 1])!
                c.drawLinearGradient(sky, start: .zero, end: CGPoint(x: 0, y: CGFloat(n)), options: [])
                c.setFillColor(UIColor(red: 1, green: 0.9, blue: 0.6, alpha: 1).cgColor)
                c.fillEllipse(in: CGRect(x: CGFloat(n) * 0.62, y: CGFloat(n) * 0.22, width: 46, height: 46))
                c.setFillColor(UIColor(red: 0.12, green: 0.1, blue: 0.2, alpha: 1).cgColor)
                c.move(to: CGPoint(x: 0, y: CGFloat(n) * 0.72))
                c.addLine(to: CGPoint(x: CGFloat(n) * 0.35, y: CGFloat(n) * 0.5))
                c.addLine(to: CGPoint(x: CGFloat(n) * 0.62, y: CGFloat(n) * 0.76))
                c.addLine(to: CGPoint(x: CGFloat(n), y: CGFloat(n) * 0.6))
                c.addLine(to: CGPoint(x: CGFloat(n), y: CGFloat(n)))
                c.addLine(to: CGPoint(x: 0, y: CGFloat(n)))
                c.closePath()
                c.fillPath()
                c.setFillColor(UIColor.black.withAlphaComponent(0.35).cgColor)
                c.fill(CGRect(x: 0, y: CGFloat(n) * 0.86, width: CGFloat(n), height: CGFloat(n) * 0.14))
            } else if v == 1 {
                // still life blocks
                let g = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(),
                                   colors: [UIColor(red: 0.1, green: 0.12, blue: 0.16, alpha: 1).cgColor,
                                            UIColor(red: 0.24, green: 0.28, blue: 0.34, alpha: 1).cgColor] as CFArray,
                                   locations: [0, 1])!
                c.drawLinearGradient(g, start: .zero, end: CGPoint(x: CGFloat(n), y: CGFloat(n)), options: [])
                let cols: [UIColor] = [UIColor(red: 0.95, green: 0.3, blue: 0.32, alpha: 1),
                                       UIColor(red: 0.98, green: 0.75, blue: 0.2, alpha: 1),
                                       UIColor(red: 0.25, green: 0.65, blue: 0.9, alpha: 1),
                                       UIColor(red: 0.4, green: 0.85, blue: 0.55, alpha: 1)]
                let rects = [CGRect(x: 30, y: 60, width: 110, height: 110),
                             CGRect(x: 160, y: 40, width: 90, height: 140),
                             CGRect(x: 80, y: 170, width: 160, height: 100),
                             CGRect(x: 210, y: 180, width: 70, height: 70)]
                for (i, rc) in rects.enumerated() {
                    c.setFillColor(cols[i % cols.count].cgColor)
                    c.fill(rc)
                }
            } else {
                // portrait gradient + bright window + skin tones
                let g = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(),
                                   colors: [UIColor(red: 0.85, green: 0.78, blue: 0.72, alpha: 1).cgColor,
                                            UIColor(red: 0.35, green: 0.3, blue: 0.28, alpha: 1).cgColor] as CFArray,
                                   locations: [0, 1])!
                c.drawLinearGradient(g, start: CGPoint(x: 0, y: 0), end: CGPoint(x: CGFloat(n), y: CGFloat(n)),
                                     options: [])
                c.setFillColor(UIColor(white: 1, alpha: 0.95).cgColor)
                c.fill(CGRect(x: CGFloat(n) * 0.66, y: 24, width: 74, height: 96))
                c.setFillColor(UIColor(red: 0.72, green: 0.5, blue: 0.4, alpha: 1).cgColor)
                c.fillEllipse(in: CGRect(x: CGFloat(n) * 0.3, y: CGFloat(n) * 0.34, width: 120, height: 150))
                c.setFillColor(UIColor(red: 0.2, green: 0.16, blue: 0.14, alpha: 1).cgColor)
                c.fillEllipse(in: CGRect(x: CGFloat(n) * 0.3 + 18, y: CGFloat(n) * 0.34 + 52, width: 26, height: 16))
                c.fillEllipse(in: CGRect(x: CGFloat(n) * 0.3 + 76, y: CGFloat(n) * 0.34 + 52, width: 26, height: 16))
            }
        }
        sampleImages[variant] = img
        return img
    }

    /// Sample image by any hashable seed (stable within one run).
    static func sampleAt(_ seed: Int) -> UIImage {
        sample(String(abs(seed) % sampleCount))
    }

    /// Drops cached thumbs (effect edited / deleted).
    static func invalidate() {
        cacheMutex.lock()
        cache.removeAll()
        cacheMutex.unlock()
        if let d = diskDir, let fs = try? FileManager.default.contentsOfDirectory(atPath: d.path) {
            for f in fs { try? FileManager.default.removeItem(at: d.appendingPathComponent(f)) }
        }
    }
}
