// AudioTools.swift — audio extraction + beat detection (Media).
//
// extractAudio: AVAssetExportSession m4a pass-through of the audio track
// (the "Extract audio" toolbar action on video layers).
// detectBeats: energy-onset detector — RMS windows off a mono decode, peaks
// above a local adaptive threshold become markers. Cheap, fully offline,
// good enough to snap cuts to music.

import Foundation
import AVFoundation

enum AudioTools {

    /// Extracts the audio track of `srcPath` into `destURL` (.m4a).
    static func extractAudio(_ srcPath: String, _ destURL: URL) -> Bool {
        let asset = AVURLAsset(url: URL(fileURLWithPath: srcPath))
        guard asset.tracks(withMediaType: .audio).first != nil else { return false }
        guard let session = AVAssetExportSession(asset: asset,
                                                  presetName: AVAssetExportPresetAppleM4A) else { return false }
        try? FileManager.default.removeItem(at: destURL)
        session.outputURL = destURL
        session.outputFileType = .m4a
        session.timeRange = CMTimeRange(start: .zero, duration: asset.duration)
        let sem = DispatchSemaphore(value: 0)
        var ok = false
        session.exportAsynchronously {
            ok = session.status == .completed
            sem.signal()
        }
        _ = sem.wait(timeout: .now() + 120)
        return ok
    }

    /// Beat times (seconds) for an audio file. Empty when the file can't be
    /// decoded or is silent.
    static func detectBeats(_ path: String) -> [Float] {
        let asset = AVURLAsset(url: URL(fileURLWithPath: path))
        guard let track = asset.tracks(withMediaType: .audio).first else { return [] }
        guard let reader = try? AVAssetReader(asset: asset) else { return [] }

        let outputSettings: [String: Any] = [
            AVFormatIDKey: kAudioFormatLinearPCM,
            AVLinearPCMBitDepthKey: 16,
            AVLinearPCMIsFloatKey: false,
            AVLinearPCMIsBigEndianKey: false,
            AVNumberOfChannelsKey: 1,
            AVLinearPCMIsNonInterleaved: false,
        ]
        let output = AVAssetReaderTrackOutput(track: track, outputSettings: outputSettings)
        output.alwaysCopiesSampleData = false
        reader.add(output)
        guard reader.startReading() else { return [] }

        // 1024-sample RMS windows (~23 ms at 44.1 kHz).
        var rms: [Float] = []
        rms.reserveCapacity(20000)
        var buf: [Float] = []
        buf.reserveCapacity(1024)

        while let sample = output.copyNextSampleBuffer() {
            let count = CMSampleBufferGetNumSamples(sample)
            if count <= 0 { CMSampleBufferInvalidate(sample); continue }

            var abl = AudioBufferList()
            var block: CMBlockBuffer? = nil
            let st = CMSampleBufferGetAudioBufferListWithRetainedBlockBuffer(
                sample,
                bufferListSizeNeededOut: nil,
                bufferListOut: &abl,
                bufferListSize: MemoryLayout<AudioBufferList>.size,
                blockBufferAllocator: kCFAllocatorDefault,
                blockBufferMemoryAllocator: kCFAllocatorDefault,
                flags: 0,
                blockBufferOut: &block)
            _ = block // retained for the duration of this iteration
            if st != noErr { CMSampleBufferInvalidate(sample); continue }

            let nbuf = Int(abl.mNumberBuffers)
            if nbuf > 0 {
                let ab = abl.mBuffers
                if let data = ab.mData {
                    let total = min(Int(ab.mDataByteSize) / MemoryLayout<Int16>.size, count)
                    let samples = data.assumingMemoryBound(to: Int16.self)
                    for i in 0..<total {
                        buf.append(Float(samples[i]) / 32768)
                        if buf.count >= 1024 {
                            var sum: Float = 0
                            for s in buf { sum += s * s }
                            rms.append(sqrt(sum / Float(buf.count)))
                            buf.removeAll(keepingCapacity: true)
                        }
                    }
                }
            }
            CMSampleBufferInvalidate(sample)
        }

        guard rms.count > 8 else { return [] }
        // window length in seconds: decode rate is the file's rate; both
        // 44.1 and 48 kHz land at ~22–23 ms, the shipped build assumed 44.1.
        let winSec: Float = 1024 / 44100

        // adaptive threshold: beat when energy exceeds the local mean by
        // 42 % and is a local maximum, with 120 ms de-duplication.
        var beats: [Float] = []
        let n = rms.count
        for i in 1..<(n - 1) {
            let span = 24
            let lo = max(0, i - span), hi = min(n, i + span)
            var sum: Float = 0
            for j in lo..<hi { sum += rms[j] }
            let mean = sum / Float(hi - lo)
            if rms[i] > mean * 1.42 && rms[i] > rms[i - 1] && rms[i] >= rms[i + 1] && rms[i] > 0.004 {
                let t = Float(i) * winSec
                if beats.isEmpty || t - beats[beats.count - 1] > 0.12 {
                    beats.append(t)
                }
            }
        }
        return beats
    }
}
