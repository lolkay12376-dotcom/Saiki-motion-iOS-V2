// Flare.swift — optical flares (Model).
//
// A Flare is a stack of elements placed along the flare axis: position 0 is
// the light itself, 1 the screen centre, 2 the opposite side. Elements are
// glows, polygons, rays, rings — the classic lens-flare kit. FlareThumbs
// renders each preset into a small cached UIImage with CoreGraphics so the
// library grid feels instant.

import UIKit

// MARK: - FlareEl

final class FlareEl {
    static let TYPES = ["Glow", "Polygon", "Line", "Rays", "Ring", "Ring polygon", "Dot"]

    var type = 0
    var enabled = true
    var pos: Float = 1            // along the axis
    var size: Float = 0.5
    var stretch: Float = 1
    var rot: Float = 0
    var bright: Float = 1
    var soft: Float = 0.5
    var thick: Float = 0.3
    var sides = 6
    var rays = 8
    var chroma: Float = 0
    var follow = false
    var color: Int32 = Int32(bitPattern: 0xFFFFFFFF)

    init(_ type: Int = 0) {
        self.type = type
    }

    func label() -> String {
        Self.TYPES.indices.contains(type) ? Self.TYPES[type] : "Element"
    }

    func copy() -> FlareEl {
        let e = FlareEl(type)
        e.enabled = enabled; e.pos = pos; e.size = size; e.stretch = stretch; e.rot = rot
        e.bright = bright; e.soft = soft; e.thick = thick; e.sides = sides; e.rays = rays
        e.chroma = chroma; e.follow = follow; e.color = color
        return e
    }

    func toJson() -> JObj {
        JObj().put("type", Int64(type)).put("enabled", enabled).put("pos", Double(pos))
            .put("size", Double(size)).put("stretch", Double(stretch)).put("rot", Double(rot))
            .put("bright", Double(bright)).put("soft", Double(soft)).put("thick", Double(thick))
            .put("sides", Int64(sides)).put("rays", Int64(rays)).put("chroma", Double(chroma))
            .put("follow", follow).put("color", Double(UInt32(bitPattern: color)))
    }

    static func fromJson(_ o: JObj) -> FlareEl {
        let e = FlareEl(o.optInt("type"))
        e.enabled = o.optBool("enabled", true)
        e.pos = o.optFloat("pos", 1); e.size = o.optFloat("size", 0.5)
        e.stretch = o.optFloat("stretch", 1); e.rot = o.optFloat("rot")
        e.bright = o.optFloat("bright", 1); e.soft = o.optFloat("soft", 0.5)
        e.thick = o.optFloat("thick", 0.3); e.sides = o.optInt("sides", 6)
        e.rays = o.optInt("rays", 8); e.chroma = o.optFloat("chroma")
        e.follow = o.optBool("follow")
        e.color = Int32(bitPattern: UInt32(clamping: Int64(o.optDouble("color"))))
        return e
    }
}

// MARK: - Flare

final class Flare {
    var name = "Flare"
    var tint: Int32 = Int32(bitPattern: 0xFFFFFFFF)
    var depthScale: Float = 0.6
    var edgeFade: Float = 0.5
    var els: [FlareEl] = []

    // user presets (<Documents>/SaikiMotion/flares.json)
    static var user: [Flare] = []

    func copy() -> Flare {
        let f = Flare()
        f.name = name; f.tint = tint; f.depthScale = depthScale; f.edgeFade = edgeFade
        for e in els { f.els.append(e.copy()) }
        return f
    }

    /// Signature for thumbnail caching — element types + colors + sizes.
    func sig() -> String {
        var s = name + "|"
        for e in els {
            s += "\(e.type),\(e.pos),\(e.size),\(UInt32(bitPattern: e.color)),\(e.enabled ? 1 : 0);"
        }
        return s + "|" + String(UInt32(bitPattern: tint))
    }

    func toJson() -> JObj {
        let o = JObj().put("name", name).put("tint", Double(UInt32(bitPattern: tint)))
            .put("depthScale", Double(depthScale)).put("edgeFade", Double(edgeFade))
        let a = JArr()
        for e in els { a.put(e.toJson()) }
        o.put("els", a)
        return o
    }

    static func fromJson(_ o: JObj) -> Flare {
        let f = Flare()
        f.name = o.optString("name", "Flare")
        f.tint = Int32(bitPattern: UInt32(clamping: Int64(o.optDouble("tint"))))
        f.depthScale = o.optFloat("depthScale", 0.6)
        f.edgeFade = o.optFloat("edgeFade", 0.5)
        if let a = o.optJSONArray("els") {
            for i in 0..<a.count {
                if let eo = a.optJSONObject(i) { f.els.append(FlareEl.fromJson(eo)) }
            }
        }
        return f
    }

    // -- presets --

    static func deflt() -> Flare {
        let f = Flare()
        f.name = "Custom"
        let glow = FlareEl(0)
        glow.pos = 0; glow.size = 0.55; glow.soft = 0.7; glow.bright = 1.4
        let ring = FlareEl(3)
        ring.pos = 1; ring.size = 0.9; ring.thick = 0.05; ring.rays = 10; ring.bright = 0.7
        let ray = FlareEl(2)
        ray.pos = 0; ray.size = 1.4; ray.stretch = 8; ray.thick = 0.03; ray.bright = 0.9
        f.els = [glow, ray, ring]
        return f
    }

    static func builtin() -> [Flare] {
        var out: [Flare] = []

        // 1 — Classic
        do {
            let f = Flare()
            f.name = "Classic"
            let g = FlareEl(0); g.pos = 0; g.size = 0.5; g.bright = 1.5; g.soft = 0.6
            let r = FlareEl(3); r.pos = 1; r.size = 0.8; r.thick = 0.06; r.rays = 12; r.bright = 0.6
            let p = FlareEl(1); p.pos = 1.6; p.size = 0.28; p.sides = 6; p.thick = 0.5
            let d = FlareEl(6); d.pos = 0.6; d.size = 0.1
            f.els = [g, r, p, d]
            out.append(f)
        }
        // 2 — Sunbeam
        do {
            let f = Flare()
            f.name = "Sunbeam"
            f.tint = Int32(bitPattern: 0xFFFFE9B0)
            let g = FlareEl(0); g.pos = 0; g.size = 0.7; g.bright = 1.8; g.soft = 0.4
            let ray = FlareEl(2); ray.pos = 0; ray.size = 1.8; ray.stretch = 12; ray.thick = 0.02; ray.bright = 1.2
            let ray6 = FlareEl(3); ray6.pos = 0; ray6.size = 1.1; ray6.rays = 6; ray6.thick = 0.04
            f.els = [g, ray, ray6]
            out.append(f)
        }
        // 3 — Anamorphic
        do {
            let f = Flare()
            f.name = "Anamorphic"
            f.tint = Int32(bitPattern: 0xFF8FD4FF)
            let line = FlareEl(2); line.pos = 0; line.size = 1.7; line.stretch = 16; line.thick = 0.025; line.bright = 1.5
            let g = FlareEl(0); g.pos = 0; g.size = 0.35; g.bright = 1.2
            let d = FlareEl(6); d.pos = 1.25; d.size = 0.08
            let d2 = FlareEl(6); d2.pos = 0.75; d2.size = 0.05
            f.els = [line, g, d, d2]
            out.append(f)
        }
        // 4 — Rainbow ring
        do {
            let f = Flare()
            f.name = "Rainbow ring"
            let r = FlareEl(1); r.pos = 1; r.size = 1.1; r.sides = 32; r.thick = 0.35; r.chroma = 0.9; r.bright = 0.8
            let g = FlareEl(0); g.pos = 0; g.size = 0.3; g.bright = 1.3
            f.els = [g, r]
            out.append(f)
        }
        // 5 — Sci-fi
        do {
            let f = Flare()
            f.name = "Sci-fi"
            f.tint = Int32(bitPattern: 0xFFB0FFE9)
            let g = FlareEl(0); g.pos = 0; g.size = 0.42; g.bright = 1.6; g.soft = 0.8
            let hex = FlareEl(5); hex.pos = 1; hex.size = 0.5; hex.sides = 6; hex.thick = 0.5; hex.follow = true
            let hex2 = FlareEl(5); hex2.pos = 1.4; hex2.size = 0.3; hex2.sides = 6; hex2.thick = 1; hex2.follow = true
            let ray = FlareEl(3); ray.pos = 0; ray.size = 0.9; ray.rays = 4; ray.thick = 0.06
            f.els = [g, hex, hex2, ray]
            out.append(f)
        }
        return out
    }

    // -- user presets on disk --

    static func userFile() -> URL {
        Projects.root.appendingPathComponent("flares.json")
    }

    static func loadUser() {
        user = []
        guard let o = JObj.readDictionary(userFile()) else { return }
        if let a = o.optJSONArray("flares") {
            for i in 0..<a.count {
                if let fo = a.optJSONObject(i) { user.append(Flare.fromJson(fo)) }
            }
        }
    }

    static func saveUser() {
        let a = JArr()
        for f in user { a.put(f.toJson()) }
        let o = JObj().put("flares", a)
        try? o.toString(4).write(to: userFile(), atomically: true, encoding: .utf8)
    }
}

extension JObj {
    /// Reads a file into a JObj (nil when missing/broken).
    static func readDictionary(_ url: URL) -> JObj? {
        guard let text = try? String(contentsOf: url, encoding: .utf8) else { return nil }
        return JObj.parse(text)
    }
}

// MARK: - FlareThumbs

/// Renders flare presets into cached thumbnails (dark card + the flare
/// elements drawn along the axis).
enum FlareThumbs {
    static var cache: [String: UIImage] = [:]

    static func generate(_ preview: PreviewView?, _ flares: [Flare], _ done: @escaping () -> Void) {
        DispatchQueue.global(qos: .userInitiated).async {
            for f in flares {
                let key = f.sig()
                if cache[key] != nil { continue }
                let img = render(f)
                DispatchQueue.main.async {
                    cache[key] = img
                }
            }
            DispatchQueue.main.async(execute: done)
        }
    }

    private static func render(_ f: Flare) -> UIImage {
        let size = CGSize(width: 112, height: 64)
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 2
        let r = UIGraphicsImageRenderer(size: size, format: fmt)
        return r.image { ctx in
            let c = ctx.cgContext
            fillRect(c, CGRect(origin: .zero, size: size), Int32(bitPattern: 0xFF101014))
            let cx0 = size.width * 0.22
            let cx1 = size.width * 0.78
            let cy = size.height / 2
            let tint = argbToUIColor(f.tint)

            func elColor(_ e: FlareEl) -> UIColor {
                let base = argbToUIColor(e.color)
                return tint.withAlphaComponent(1).mixed(with: base, alpha: 0.6)
            }

            for e in f.els where e.enabled {
                let ex = cx0 + (cx1 - cx0) * CGFloat(e.pos / 2)
                let es = CGFloat(e.size) * size.height * 0.5
                let col = elColor(e)
                c.saveGState()
                c.translateBy(x: ex, y: cy)
                c.rotate(by: CGFloat(e.rot) * .pi / 180)
                c.setAlpha(clamp(CGFloat(e.bright) * 0.85, 0, 1))
                switch e.type {
                case 0: // glow — radial falloff via concentric alpha circles
                    for i in stride(from: 10, through: 1, by: -1) {
                        let rr = es * CGFloat(i) / 10
                        c.setFillColor(col.withAlphaComponent(CGFloat(1.0 - Double(i) / 10.0) * 0.5).cgColor)
                        c.fillEllipse(in: CGRect(x: -rr, y: -rr, width: rr * 2, height: rr * 2))
                    }
                case 1, 5: // polygon / ring polygon
                    let n = max(3, e.sides)
                    let path = CGMutablePath()
                    for i in 0...n {
                        let a = CGFloat(i) / CGFloat(n) * 2 * .pi - .pi / 2
                        let px = cos(a) * es, py = sin(a) * es
                        if i == 0 { path.move(to: CGPoint(x: px, y: py)) } else { path.addLine(to: CGPoint(x: px, y: py)) }
                    }
                    c.addPath(path)
                    if e.thick >= 0.95 {
                        c.setFillColor(col.cgColor)
                        c.fillPath()
                    } else {
                        c.setStrokeColor(col.cgColor)
                        c.setLineWidth(max(1.5, es * CGFloat(e.thick)))
                        c.strokePath()
                    }
                case 2: // line through the light
                    c.setStrokeColor(col.cgColor)
                    c.setLineWidth(max(1.5, es * 0.25))
                    c.move(to: CGPoint(x: -es * CGFloat(e.stretch), y: 0))
                    c.addLine(to: CGPoint(x: es * CGFloat(e.stretch), y: 0))
                    c.strokePath()
                case 3: // rays
                    let n = max(2, e.rays)
                    c.setStrokeColor(col.cgColor)
                    c.setLineWidth(max(1, es * 0.08))
                    for i in 0..<n {
                        let a = CGFloat(i) / CGFloat(n) * 2 * .pi
                        c.move(to: .zero)
                        c.addLine(to: CGPoint(x: cos(a) * es, y: sin(a) * es))
                    }
                    c.strokePath()
                case 4: // ring
                    c.setStrokeColor(col.cgColor)
                    c.setLineWidth(max(1.5, es * CGFloat(e.thick)))
                    c.strokeEllipse(in: CGRect(x: -es, y: -es, width: es * 2, height: es * 2))
                default: // dot
                    c.setFillColor(col.cgColor)
                    c.fillEllipse(in: CGRect(x: -es, y: -es, width: es * 2, height: es * 2))
                }
                c.restoreGState()
            }
        }
    }
}

extension UIColor {
    /// Simple linear RGB mix used for tinting flare elements.
    func mixed(with other: UIColor, alpha t: CGFloat) -> UIColor {
        var r1: CGFloat = 0, g1: CGFloat = 0, b1: CGFloat = 0, a1: CGFloat = 0
        var r2: CGFloat = 0, g2: CGFloat = 0, b2: CGFloat = 0, a2: CGFloat = 0
        getRed(&r1, green: &g1, blue: &b1, alpha: &a1)
        other.getRed(&r2, green: &g2, blue: &b2, alpha: &a2)
        return UIColor(red: r1 + (r2 - r1) * t, green: g1 + (g2 - g1) * t,
                       blue: b1 + (b2 - b1) * t, alpha: a1 + (a2 - a1) * t)
    }
}
