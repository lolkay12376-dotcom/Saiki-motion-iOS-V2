// Project.swift — project + scene models and the parameter definition tables.
//
// Kotlin Core/Project.kt. A Project is the whole edit: canvas size, fps, a
// scene list and the next-id counter. A Scene is layers + duration +
// markers + camera setup.

import Foundation

// MARK: - Scene

final class Scene {
    var name: String
    var layers: [Layer] = []
    var duration: Float = 5
    var fov: Float = 55
    var bg: Int32 = Int32(bitPattern: 0xFF000000)
    var markers: [Float] = []
    var markerNames: [Float: String] = [:]

    init(_ name: String) {
        self.name = name
    }

    func markerName(_ t: Float) -> String? {
        for m in markers where abs(m - t) < 0.02 {
            if let n = markerNames[m], !n.isEmpty { return n }
        }
        return nil
    }

    func setMarkerName(_ t: Float, _ name: String) {
        for m in markers where abs(m - t) < 0.02 {
            if name.isEmpty {
                markerNames.removeValue(forKey: m)
            } else {
                markerNames[m] = name
            }
            return
        }
    }

    /// Name → time lookup for expressions (`marker("beat")` → seconds).
    /// Built by inverting `markerNames` (time → name); with duplicate
    /// names the last one wins, same as the Kotlin original.
    func markersByName() -> [String: Float] {
        var out: [String: Float] = [:]
        for (t, n) in markerNames { out[n] = t }
        return out
    }

    func toJson() -> JObj {
        let o = JObj()
        o.put("name", name).put("duration", Double(duration)).put("fov", Double(fov))
        o.put("bg", Double(UInt32(bitPattern: bg)))
        let la = JArr()
        for l in layers { la.put(l.toJson()) }
        o.put("layers", la)
        let ma = JArr()
        for m in markers { ma.put(Double(m)) }
        o.put("markers", ma)
        let mo = JObj()
        for (k, v) in markerNames { mo.put(String(format: "%.3f", Double(k)), v) }
        o.put("markerNames", mo)
        return o
    }

    static func fromJson(_ o: JObj) -> Scene {
        let s = Scene(o.optString("name", "Scene"))
        s.duration = max(0.1, o.optFloat("duration", 5))
        s.fov = o.optFloat("fov", 55)
        s.bg = Int32(bitPattern: UInt32(clamping: Int64(o.optDouble("bg"))))
        if let la = o.optJSONArray("layers") {
            for i in 0..<la.count {
                if let lo = la.optJSONObject(i) { s.layers.append(Layer.fromJson(lo)) }
            }
        }
        if let ma = o.optJSONArray("markers") {
            for i in 0..<ma.count { s.markers.append(ma.optFloat(i)) }
        }
        if let mo = o.optJSONObject("markerNames") {
            for k in mo.keys { s.markerNames[Float(k) ?? 0] = mo.optString(k) }
        }
        return s
    }
}

// MARK: - Project

final class Project: Store {
    var id: String
    var name: String
    var createdAt: Date
    var updatedAt: Date
    var w: Int
    var h: Int
    var fps: Int
    var nextId: Int
    var scenes: [Scene]

    init(id: String = UUID().uuidString,
         name: String,
         createdAt: Date = Date(),
         updatedAt: Date = Date(),
         w: Int = 1080, h: Int = 1920, fps: Int = 30,
         nextId: Int = 1) {
        self.id = id
        self.name = name
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.w = w
        self.h = h
        self.fps = fps
        self.nextId = nextId
        self.scenes = [Scene("Scene 1")]
    }

    func toJson() -> JObj {
        let o = JObj()
        o.put("id", id).put("name", name)
        o.put("createdAt", Int64(createdAt.timeIntervalSince1970 * 1000))
        o.put("updatedAt", Int64(updatedAt.timeIntervalSince1970 * 1000))
        o.put("w", Int64(w)).put("h", Int64(h)).put("fps", Int64(fps))
        o.put("nextId", Int64(nextId))
        let sa = JArr()
        for s in scenes { sa.put(s.toJson()) }
        o.put("scenes", sa)
        return o
    }

    static func fromJson(_ o: JObj) -> Project {
        let p = Project(id: o.optString("id", UUID().uuidString),
                        name: o.optString("name", "Untitled"),
                        createdAt: Date(timeIntervalSince1970: o.optDouble("createdAt") / 1000),
                        updatedAt: Date(timeIntervalSince1970: o.optDouble("updatedAt") / 1000),
                        w: o.optInt("w", 1080), h: o.optInt("h", 1920),
                        fps: clamp(o.optInt("fps", 30), 10, 60),
                        nextId: o.optInt("nextId", 1))
        p.scenes = []
        if let sa = o.optJSONArray("scenes") {
            for i in 0..<sa.count {
                if let so = sa.optJSONObject(i) { p.scenes.append(Scene.fromJson(so)) }
            }
        }
        if p.scenes.isEmpty { p.scenes = [Scene("Scene 1")] }
        return p
    }
}

// MARK: - Defs
//
// The parameter tables every panel reads. Order matters: indices are used
// by the panels (e.g. Defs.transform[2] is scale).

enum Defs {
    // x, y, scale, opacity, rotZ
    static let transform: [PropDef] = [
        PropDef("x", "Position X", -4, 4, 0, 3, nil, true, 4),
        PropDef("y", "Position Y", -4, 4, 0, 3, nil, true, 4),
        PropDef("scale", "Scale", 0.02, 8, 1, 3),
        PropDef("opacity", "Opacity", 0, 1, 1, 2),
        PropDef("rotZ", "Rotation Z", -360, 360, 0, 1),
    ]

    static let scaleXY: [PropDef] = [
        PropDef("scaleX", "Scale X", 0.02, 8, 1, 3),
        PropDef("scaleY", "Scale Y", 0.02, 8, 1, 3),
    ]

    static let pos3d: [PropDef] = [
        PropDef("z", "Position Z", -10, 10, 0, 2),
    ]

    static let rot3d: [PropDef] = [
        PropDef("rotX", "Rotation X", -360, 360, 0, 1),
        PropDef("rotY", "Rotation Y", -360, 360, 0, 1),
    ]

    static let anchor: [PropDef] = [
        PropDef("anchorX", "Anchor X", 0, 100, 50, 1),
        PropDef("anchorY", "Anchor Y", 0, 100, 50, 1),
    ]

    // strokeW, borderW, borderPad, spacing, size, shadowX, shadowY, shadowBlur, stroke2W, borderRadius
    static let text: [PropDef] = [
        PropDef("strokeW", "Stroke width", 0, 0.3, 0, 3),
        PropDef("borderW", "Border width", 0, 0.5, 0, 3),
        PropDef("borderPad", "Border padding", 0, 0.6, 0.12, 3),
        PropDef("spacing", "Letter spacing", 0, 0.5, 0, 3),
        PropDef("fontSize", "Font size", 0.05, 4, 0.45, 3),
        PropDef("shadowX", "Shadow offset X", -0.2, 0.2, 0.03, 3),
        PropDef("shadowY", "Shadow offset Y", -0.2, 0.2, 0.03, 3),
        PropDef("shadowBlur", "Shadow blur", 0, 0.4, 0.06, 3),
        PropDef("stroke2W", "Second stroke width", 0, 0.3, 0, 3),
        PropDef("borderRadius", "Border corner radius", 0, 0.3, 0.06, 3),
    ]

    static let audio: [PropDef] = [
        PropDef("volume", "Volume", 0, 1, 1, 2),
    ]

    static let camera: [PropDef] = [
        PropDef("fov", "Field of view", 15, 120, 55, 0),
    ]

    // flare global knobs (the Edit panel of a flare layer)
    static let flare: [PropDef] = [
        PropDef("fIntensity", "Intensity", 0, 4, 1, 2),
        PropDef("fAxis", "Axis length", 0, 2, 1, 2),
    ]

    // motion blur
    static let blur: [PropDef] = [
        PropDef("mbSamples", "Samples", 2, 24, 8, 0),
        PropDef("mbAmount", "Blur strength", 0, 4, 1, 2),
    ]
}
