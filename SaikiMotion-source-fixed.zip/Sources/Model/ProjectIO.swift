// ProjectIO.swift — moving bytes into the sandbox (Model).
//
// The single gate for imports: picker copies land here with the "<ts>_<name>"
// naming and fonts as "<ts>_font.<ext>" — identical to the Android original,
// so files written by either build sort and dedupe the same way. Returns the
// absolute path of the stored file; callers hand that path straight to the
// layer model (`imagePath`, `fontPath`).

import Foundation
import UniformTypeIdentifiers

enum ProjectIO {

    /// Make sure the sandbox folders exist before writing.
    static func ensureDirs() { Projects.ensureDirs() }

    /// Unique media file name for a source name: "<timestamp>_<name>".
    /// Fonts keep their extension and get the "<ts>_font" stem convention.
    static func sandboxName(forOriginal original: String) -> String {
        let ts = Int(Date().timeIntervalSince1970)
        let clean = original.replacingOccurrences(of: "/", with: "_")
        if clean.lowercased().hasSuffix(".ttf") || clean.lowercased().hasSuffix(".otf") {
            return "\(ts)_font.\((clean as NSString).pathExtension)"
        }
        return "\(ts)_\(clean)"
    }

    /// Copy an imported file (already a local, readable URL — e.g. from a
    /// document picker opened with asCopy: true) into Projects.mediaDir.
    ///
    /// `kind`: "font" for font files, "" for everything else. Security-scoped
    /// bookmarks are not needed (pickers are asCopy), but Files-app URLs that
    /// arrive scoped are still handled defensively.
    ///
    /// Returns the stored file's absolute path, or nil if the copy failed.
    @discardableResult
    static func copyMediaIntoSandbox(url source: URL, kind: String) -> String? {
        ensureDirs()
        let scoped = source.startAccessingSecurityScopedResource()
        defer { if scoped { source.stopAccessingSecurityScopedResource() } }
        let name = sandboxName(forOriginal: source.lastPathComponent)
        let dest = Projects.mediaDir().appendingPathComponent(name)
        do {
            if FileManager.default.fileExists(atPath: dest.path) {
                try FileManager.default.removeItem(at: dest)
            }
            try FileManager.default.copyItem(at: source, to: dest)
            return dest.path
        } catch {
            return nil
        }
    }

    /// Legacy one-argument spelling (name-only importers).
    @discardableResult
    static func copyMediaIntoSandbox(_ source: URL) -> String? {
        copyMediaIntoSandbox(url: source, kind: "")
    }

    /// Write raw data (e.g. a picked photo) into the media dir. Returns the
    /// absolute path of the stored file.
    @discardableResult
    static func writeDataIntoSandbox(_ data: Data, name original: String) -> String? {
        ensureDirs()
        let name = sandboxName(forOriginal: original)
        let dest = Projects.mediaDir().appendingPathComponent(name)
        do {
            try data.write(to: dest, options: .atomic)
            return dest.path
        } catch {
            return nil
        }
    }

    /// Absolute URL for a stored media file name.
    static func mediaURL(_ name: String) -> URL {
        Projects.mediaDir().appendingPathComponent(name)
    }

    /// Remove a stored media file (callers decide — media may be shared).
    static func deleteMedia(_ name: String) {
        try? FileManager.default.removeItem(at: mediaURL(name))
    }
}
