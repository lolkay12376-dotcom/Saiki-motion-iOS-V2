// Store.swift — the persistence protocol every saved model adopts.
//
// `Store` = "this type round-trips through JObj". The editor's undo stack
// snapshots whole projects as JSON strings; presets and exported effects go
// through the same door.

import Foundation

protocol Store: AnyObject {
    func toJson() -> JObj
    static func fromJson(_ o: JObj) -> Self
}

/// Change notifications used by list screens. Posted on the main thread.
/// Declared as an extension of Notification.Name so implicit-member syntax
/// (`NotificationCenter.addObserver(name: .projectsChanged ...)`) resolves.
extension Notification.Name {
    static let projectsChanged = Notification.Name("store.projectsChanged")
    static let languageChanged = Notification.Name("store.languageChanged")
}

/// Namespace alias kept for explicit call sites (`StoreNotification.post`).
enum StoreNotification {
    static func post(_ name: Notification.Name) {
        NotificationCenter.default.post(name: name, object: nil)
    }
}
