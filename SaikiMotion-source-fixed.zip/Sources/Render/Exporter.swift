// Exporter.swift — offscreen render to MP4 (Render).
//
// Renders every frame through the same SceneRenderer the preview uses (full
// quality, deterministic video sampling), writes H.264 via AVAssetWriter,
// then muxes the first audio layer on top with an AVMutableComposition pass.
// Output lands in <Documents>/SaikiMotion/exports and (optionally) Photos.

import Foundation
import AVFoundation
import OpenGLES
import GLKit
import UIKit

struct RenderSettings {
    var scale: Float = 1          // canvas resolution multiplier
    var fps: Int = 30
    var draft = false             // quarter-res fast pass
    var withAudio = true
}

enum Exporter {

    final class Result {
        var url: URL? = nil
        var error: String? = nil
        var frames = 0
    }

    /// Renders `project`'s current scene to an .mp4. Blocking — call off main.
    static func export(project: Project, scene: Scene, settings: RenderSettings) -> Result {
        let res = Result()
        Paths.ensure()
        let outDir = Paths.root.appendingPathComponent("exports", isDirectory: true)
        try? FileManager.default.createDirectory(at: outDir, withIntermediateDirectories: true)
        let name = "\(alnum(project.name))-\(nowMs()).mp4"
        let outURL = outDir.appendingPathComponent(name)
        try? FileManager.default.removeItem(at: outURL)

        let w = max(16, Int(Float(project.w) * settings.scale) & ~1)   // even for H.264
        let h = max(16, Int(Float(project.h) * settings.scale) & ~1)
        let fps = settings.fps
        let duration = scene.duration

        guard let ctx = GLContext.make() else {
            res.error = "Could not create a GL context."
            return res
        }
        let prev = EAGLContext.current()
        EAGLContext.setCurrent(ctx)
        defer { EAGLContext.setCurrent(prev) }

        let renderer = SceneRenderer(context: ctx)
        renderer.quality = settings.draft ? 4 : 1

        // audio: first visible audio layer
        var audioURL: URL? = nil
        var audioStart: Float = 0
        var audioOffset: Float = 0
        if settings.withAudio {
            for l in scene.layers where l.type == .AUDIO && l.visible {
                if let p = l.imagePath {
                    audioURL = URL(fileURLWithPath: p)
                    audioStart = l.start
                    audioOffset = l.srcOffset
                    break
                }
            }
        }

        let writer = try? AVAssetWriter(outputURL: outURL, fileType: .mp4)
        guard let writer = writer else {
            res.error = "Could not create the movie file."
            return res
        }
        let videoSettings: [String: Any] = [
            AVVideoCodecKey: AVVideoCodecType.h264,
            AVVideoWidthKey: w,
            AVVideoHeightKey: h,
        ]
        let videoInput = AVAssetWriterInput(mediaType: .video, outputSettings: videoSettings)
        videoInput.expectsMediaDataInRealTime = false
        let adaptor = AVAssetWriterInputPixelBufferAdaptor(
            assetWriterInput: videoInput,
            sourcePixelBufferAttributes: [
                kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
                kCVPixelBufferWidthKey as String: w,
                kCVPixelBufferHeightKey as String: h,
            ])
        writer.add(videoInput)

        // GL readback buffer (RGBA → BGRA swap while copying); sized after the
        // first draw() fixes the renderer's working resolution
        var glData = [UInt8](repeating: 0, count: 4)

        writer.startWriting()
        writer.startSession(atSourceTime: .zero)

        let frames = Int(duration * Float(fps))
        let queue = DispatchQueue(label: "saiki.export")
        let done = DispatchSemaphore(value: 0)

        var frameIdx = 0
        let timeInc = 1.0 / Double(fps)

        // Frame pump: writer input pulls frames as fast as it can consume them.
        videoInput.requestMediaDataWhenReady(on: queue) {
            while videoInput.isReadyForMoreMediaData {
                if frameIdx >= frames || writer.status == .failed {
                    videoInput.markAsFinished()
                    done.signal()
                    return
                }
                let t = Float(Double(frameIdx) * timeInc)

                // render at preview res then read pixels
                _ = renderer.draw(project: project, scene: scene, time: t, video: nil)
                guard let target = renderer.sceneTarget else {
                    videoInput.markAsFinished()
                    done.signal()
                    return
                }
                if glData.count != target.width * target.height * 4 {
                    glData = [UInt8](repeating: 0, count: target.width * target.height * 4)
                }
                glBindFramebuffer(GLenum(GL_FRAMEBUFFER), target.fbo)
                glReadPixels(0, 0, GLsizei(target.width), GLsizei(target.height),
                             GLenum(GL_RGBA), GLenum(GL_UNSIGNED_BYTE), &glData)

                if let pb = makePixelBuffer(glData, Int(target.width), Int(target.height), w, h) {
                    let cm = CMTime(seconds: Double(frameIdx) * timeInc, preferredTimescale: CMTimeScale(fps * 1000))
                    adaptor.append(pb, withPresentationTime: cm)
                    ExporterProgress.shared.add()
                }
                frameIdx += 1
            }
        }

        _ = done.wait(timeout: .now() + 60 * 60 * 24)
        res.frames = frameIdx
        if writer.status == .failed {
            res.error = writer.error?.localizedDescription ?? "The encoder failed."
            try? FileManager.default.removeItem(at: outURL)
            return res
        }
        writer.finishWriting {
            // status becomes .completed here
        }
        while writer.status == .writing {
            Thread.sleep(forTimeInterval: 0.05)
        }
        if writer.status != .completed {
            res.error = writer.error?.localizedDescription ?? "The encoder did not finish."
            try? FileManager.default.removeItem(at: outURL)
            return res
        }

        // audio mux pass
        if let audioURL = audioURL {
            let muxed = muxAudio(video: outURL, audio: audioURL,
                                 at: audioStart, offset: audioOffset,
                                 duration: duration)
            if let muxed = muxed {
                try? FileManager.default.removeItem(at: outURL)
                res.url = muxed
                return res
            }
            // mux failed → ship the silent video
        }
        res.url = outURL
        return res
    }

    /// RGBA buffer (bottom-up) → CVPixelBuffer (top-down BGRA), scaled to outW×outH.
    private static func makePixelBuffer(_ data: [UInt8], _ rw: Int, _ rh: Int,
                                        _ outW: Int, _ outH: Int) -> CVPixelBuffer? {
        var pb: CVPixelBuffer?
        CVPixelBufferCreate(kCFAllocatorDefault, outW, outH,
                            kCVPixelFormatType_32BGRA, nil, &pb)
        guard let pb = pb else { return nil }
        CVPixelBufferLockBaseAddress(pb, [])
        defer { CVPixelBufferUnlockBaseAddress(pb, []) }
        guard let base = CVPixelBufferGetBaseAddress(pb) else { return nil }
        let bpr = CVPixelBufferGetBytesPerRow(pb)
        let dst = base.assumingMemoryBound(to: UInt8.self)

        for y in 0..<outH {
            // flip vertically (GL origin bottom-left → video top-left)
            let srcY = min(rh - 1, Int(Float(rh - 1) * Float(outH - 1 - y) / Float(max(outH - 1, 1))))
            let row = srcY * rw * 4
            let dstRow = y * bpr
            if rw == outW {
                for x in 0..<outW {
                    let s = row + x * 4
                    let d = dstRow + x * 4
                    dst[d] = data[s + 2]      // B
                    dst[d + 1] = data[s + 1]  // G
                    dst[d + 2] = data[s]      // R
                    dst[d + 3] = data[s + 3]  // A
                }
            } else {
                for x in 0..<outW {
                    let sx = min(rw - 1, Int(Float(rw - 1) * Float(x) / Float(max(outW - 1, 1))))
                    let s = row + sx * 4
                    let d = dstRow + x * 4
                    dst[d] = data[s + 2]
                    dst[d + 1] = data[s + 1]
                    dst[d + 2] = data[s]
                    dst[d + 3] = data[s + 3]
                }
            }
        }
        return pb
    }

    /// Composes the rendered video + one audio track into a final .mp4.
    private static func muxAudio(video: URL, audio: URL, at start: Float, offset: Float,
                                 duration: Float) -> URL? {
        let comp = AVMutableComposition()
        guard let vTrack = comp.addMutableTrack(withMediaType: .video, preferredTrackID: 1),
              let vidAsset = try? AVURLAsset(url: video),
              let vSrc = vidAsset.tracks(withMediaType: .video).first else { return nil }
        let vRange = CMTimeRange(start: .zero, duration: vidAsset.duration)
        try? vTrack.insertTimeRange(vRange, of: vSrc, at: .zero)

        if let aTrack = comp.addMutableTrack(withMediaType: .audio, preferredTrackID: 2),
           let audAsset = try? AVURLAsset(url: audio),
           let aSrc = audAsset.tracks(withMediaType: .audio).first {
            let at = CMTime(seconds: Double(max(0, offset)), preferredTimescale: 600)
            let inDur = audAsset.duration - at
            let want = CMTime(seconds: Double(duration), preferredTimescale: 600)
            let len = min(inDur, want)
            if len.seconds > 0 {
                let range = CMTimeRange(start: at, duration: len)
                let insertAt = CMTime(seconds: Double(max(0, start)), preferredTimescale: 600)
                try? aTrack.insertTimeRange(range, of: aSrc, at: insertAt)
            }
        }

        let out = video.deletingLastPathComponent()
            .appendingPathComponent("mux-" + video.lastPathComponent)
        try? FileManager.default.removeItem(at: out)
        guard let session = AVAssetExportSession(asset: comp,
                                                 presetName: AVAssetExportPresetHighestQuality) else { return nil }
        session.outputURL = out
        session.outputFileType = .mp4
        let sem = DispatchSemaphore(value: 0)
        session.exportAsynchronously { sem.signal() }
        _ = sem.wait(timeout: .now() + 1800)
        guard session.status == .completed else {
            try? FileManager.default.removeItem(at: out)
            return nil
        }
        return out
    }

    private static func alnum(_ s: String) -> String {
        String(s.map { c in
            (c.isASCII && c.isLetter) || (c.isASCII && c.isNumber) ? c : "_"
        })
    }
}

