// FrameCache.swift — rendered-frame cache for live playback (Render).
//
// While the timeline plays, every live-rendered frame is also written as a
// JPEG into <Caches>/SaikiMotion/frames/<projectId>/. Playing the same range
// again (with no edits in between) shows the cached frames instead of
// re-running the GL pipeline, so heavy scenes stop lagging on the second pass.
// Any edit bumps `version`, which makes older frames stale (purged lazily).
// The cache lives outside the project: it can be cleared from Home → Extras
// without touching a single project.

import UIKit
import Foundation

enum FrameCache {

    static var version = 0          // bumped by every edit
    static var playing = false      // cache is only used / filled during playback
    static var enabled = true
    static let fps: Float = 30

    private static let queue = DispatchQueue(label: "saiki.framecache", qos: .utility)
    private static let lock = NSLock()
    private static var pending = Set<String>()
    private static var purged: [String: Int] = [:]

    static var root: URL {
        Paths.cache.appendingPathComponent("frames", isDirectory: true)
    }

    static func bump() { version &+= 1 }

    private static func frameIndex(_ t: Float) -> Int { Int((max(0, t) * fps).rounded()) }

    private static func name(_ w: Int, _ h: Int, _ q: Int, _ t: Float) -> String {
        "\(version)_\(q)_\(w)x\(h)_\(frameIndex(t)).jpg"
    }

    private static func url(_ pid: String, _ n: String) -> URL {
        root.appendingPathComponent(pid, isDirectory: true).appendingPathComponent(n)
    }

    static func lookup(_ pid: String, _ w: Int, _ h: Int, _ q: Int, _ t: Float) -> UIImage? {
        let u = url(pid, name(w, h, q, t))
        guard FileManager.default.fileExists(atPath: u.path) else { return nil }
        return UIImage(contentsOfFile: u.path)
    }

    static func has(_ pid: String, _ w: Int, _ h: Int, _ q: Int, _ t: Float) -> Bool {
        FileManager.default.fileExists(atPath: url(pid, name(w, h, q, t)).path)
    }

    static func store(_ pid: String, _ w: Int, _ h: Int, _ q: Int, _ t: Float, _ img: UIImage) {
        let n = name(w, h, q, t)
        let key = pid + "/" + n
        lock.lock()
        if pending.contains(key) { lock.unlock(); return }
        pending.insert(key)
        lock.unlock()
        let ver = version
        queue.async {
            let dir = root.appendingPathComponent(pid, isDirectory: true)
            try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
            if purged[pid] != ver {
                purged[pid] = ver
                let prefix = "\(ver)_"
                for f in (try? FileManager.default.contentsOfDirectory(atPath: dir.path)) ?? []
                where !f.hasPrefix(prefix) {
                    try? FileManager.default.removeItem(at: dir.appendingPathComponent(f))
                }
            }
            if let d = img.jpegData(compressionQuality: 0.82) {
                try? d.write(to: dir.appendingPathComponent(n), options: .atomic)
            }
            lock.lock(); pending.remove(key); lock.unlock()
        }
    }

    // MARK: size + clearing (Home → Extras)

    static func totalBytes() -> Int64 {
        var total: Int64 = 0
        let keys: [URLResourceKey] = [.fileSizeKey, .isRegularFileKey]
        if let en = FileManager.default.enumerator(at: Paths.cache, includingPropertiesForKeys: keys) {
            for case let u as URL in en {
                let v = try? u.resourceValues(forKeys: Set(keys))
                if v?.isRegularFile == true { total += Int64(v?.fileSize ?? 0) }
            }
        }
        return total
    }

    static func sizeText() -> String {
        let b = Double(totalBytes())
        if b >= 1_073_741_824 { return String(format: "%.2f GB", b / 1_073_741_824) }
        return String(format: "%.1f MB", b / 1_048_576)
    }

    /// Deletes every cached frame and thumbnail. Projects and media are untouched.
    static func clearAll() {
        lock.lock(); pending.removeAll(); purged.removeAll(); lock.unlock()
        let fm = FileManager.default
        for f in (try? fm.contentsOfDirectory(atPath: Paths.cache.path)) ?? [] {
            try? fm.removeItem(at: Paths.cache.appendingPathComponent(f))
        }
        if let base = fm.urls(for: .cachesDirectory, in: .userDomainMask).first {
            for f in (try? fm.contentsOfDirectory(atPath: base.path)) ?? [] where f.hasPrefix("fxthumbs") {
                try? fm.removeItem(at: base.appendingPathComponent(f))
            }
        }
        EffectThumbs.cache.removeAll()
        version &+= 1
    }
}
