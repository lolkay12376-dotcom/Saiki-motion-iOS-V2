// Gl.swift — OpenGL ES plumbing (Render).
//
// A tiny GL layer shared by the preview, the thumbnail generator and the
// exporter: program compile + uniform binding, ping-pong framebuffers,
// texture upload from UIImage, and the effect-shader prelude that wraps a
// user's `vec4 effect(vec2 uv)` body in the SDK runtime (src/luma/noise/…
// helpers, one uniform per parameter).

import Foundation
import OpenGLES
import GLKit
import CoreGraphics
import UIKit

// MARK: - program

final class GLProgram {
    let handle: GLuint
    private var uniforms: [String: GLint] = [:]

    static let defaultVertex = """
attribute vec2 aPos;
varying vec2 vUv;
void main() {
    vUv = aPos * 0.5 + 0.5;
    gl_Position = vec4(aPos, 0.0, 1.0);
}
"""

    /// Convenience: default quad vertex + custom fragment.
    convenience init?(fragment: String) {
        self.init(vertex: GLProgram.defaultVertex, fragment: fragment)
    }

    /// Full init: custom vertex + fragment.
    init?(vertex: String, fragment: String) {
        func compile(_ type: GLenum, _ src: String) -> GLuint {
            let s = glCreateShader(type)
            // glShaderSource wants UnsafePointer<UnsafePointer<GLchar>?> —
            // build that from the Swift string's C representation.
            src.withCString { cstr in
                var cp: [UnsafePointer<CChar>?] = [cstr]
                glShaderSource(s, 1, &cp, nil)
            }
            glCompileShader(s)
            var ok = GL_FALSE
            glGetShaderiv(s, GLenum(GL_COMPILE_STATUS), &ok)
            if ok == GL_FALSE {
                var len = GLsizei(0)
                glGetShaderiv(s, GLenum(GL_INFO_LOG_LENGTH), &len)
                if len > 0 {
                    var log = [CChar](repeating: 0, count: Int(len))
                    var out = GLsizei(0)
                    glGetShaderInfoLog(s, len, &out, &log)
                    Gl.lastShaderLog = String(cString: log)
                } else {
                    Gl.lastShaderLog = "shader compile failed"
                }
                glDeleteShader(s)
                return 0
            }
            return s
        }

        let vs = compile(GLenum(GL_VERTEX_SHADER), vertex)
        let fs = compile(GLenum(GL_FRAGMENT_SHADER), fragment)
        if vs == 0 || fs == 0 {
            if vs != 0 { glDeleteShader(vs) }
            if fs != 0 { glDeleteShader(fs) }
            handle = 0
            return nil
        }
        let p = glCreateProgram()
        glAttachShader(p, vs)
        glAttachShader(p, fs)
        glLinkProgram(p)
        glDeleteShader(vs)
        glDeleteShader(fs)
        var ok = GL_FALSE
        glGetProgramiv(p, GLenum(GL_LINK_STATUS), &ok)
        if ok == GL_FALSE {
            var len = GLsizei(0)
            glGetProgramiv(p, GLenum(GL_INFO_LOG_LENGTH), &len)
            if len > 0 {
                var log = [CChar](repeating: 0, count: Int(len))
                var out = GLsizei(0)
                glGetProgramInfoLog(p, len, &out, &log)
                Gl.lastShaderLog = String(cString: log)
            }
            glDeleteProgram(p)
            handle = 0
            return nil
        }
        handle = p
    }

    deinit {
        if handle != 0 { glDeleteProgram(handle) }
    }

    func use() {
        glUseProgram(handle)
    }

    func loc(_ name: String) -> GLint {
        if let l = uniforms[name] { return l }
        let l = glGetUniformLocation(handle, name)
        uniforms[name] = l
        return l
    }

    func setFloat(_ name: String, _ v: Float) {
        let l = loc(name)
        if l >= 0 { glUniform1f(l, v) }
    }

    func setVec2(_ name: String, _ x: Float, _ y: Float) {
        let l = loc(name)
        if l >= 0 { glUniform2f(l, x, y) }
    }

    func setVec3(_ name: String, _ x: Float, _ y: Float, _ z: Float) {
        let l = loc(name)
        if l >= 0 { glUniform3f(l, x, y, z) }
    }

    func setVec4(_ name: String, _ r: Float, _ g: Float, _ b: Float, _ a: Float) {
        let l = loc(name)
        if l >= 0 { glUniform4f(l, r, g, b, a) }
    }

    func setTexture(_ name: String, _ tex: GLuint, _ unit: GLint) {
        let l = loc(name)
        if l >= 0 {
            glActiveTexture(GLenum(GL_TEXTURE0 + unit))
            glBindTexture(GLenum(GL_TEXTURE_2D), tex)
            glUniform1i(l, Int32(unit))
        }
    }
}

enum Gl {
    /// Last shader compile/link log (for Registry.errors / SDK problems).
    static var lastShaderLog = ""

    // GL buffer objects belong to ONE context. The old lazy static was created
    // in whichever context drew first (often the thumbnail thread's), so every
    // other context — the preview above all — drew with a buffer that did not
    // exist there: a black viewport and previews stuck on "Rendering...".
    // One VBO per context now.
    private static var quadVBOs: [ObjectIdentifier: GLuint] = [:]
    private static let vboLock = NSLock()

    static func quadVBOForCurrentContext() -> GLuint {
        guard let ctx = EAGLContext.current() else { return 0 }
        let key = ObjectIdentifier(ctx)
        vboLock.lock()
        defer { vboLock.unlock() }
        if let b = quadVBOs[key] { return b }
        var buf = GLuint(0)
        glGenBuffers(1, &buf)
        glBindBuffer(GLenum(GL_ARRAY_BUFFER), buf)
        let verts: [Float] = [-1, -1, 1, -1, -1, 1, 1, 1]
        verts.withUnsafeBufferPointer { ptr in
            glBufferData(GLenum(GL_ARRAY_BUFFER), MemoryLayout<Float>.size * verts.count, ptr.baseAddress, GLenum(GL_STATIC_DRAW))
        }
        quadVBOs[key] = buf
        return buf
    }

    static func drawQuad(_ program: GLProgram) {
        program.use()
        glBindBuffer(GLenum(GL_ARRAY_BUFFER), quadVBOForCurrentContext())
        let aPos = glGetAttribLocation(program.handle, "aPos")
        if aPos >= 0 {
            glEnableVertexAttribArray(GLuint(aPos))
            glVertexAttribPointer(GLuint(aPos), 2, GLenum(GL_FLOAT), GLboolean(GL_FALSE),
                                  GLsizei(MemoryLayout<Float>.size * 2), nil)
        }
        glDrawArrays(GLenum(GL_TRIANGLE_STRIP), 0, 4)
        if aPos >= 0 { glDisableVertexAttribArray(GLuint(aPos)) }
    }

    // MARK: - textures

    static func makeTexture(_ width: Int, _ height: Int, _ pixels: UnsafeRawPointer? = nil) -> GLuint {
        var tex = GLuint(0)
        glGenTextures(1, &tex)
        glBindTexture(GLenum(GL_TEXTURE_2D), tex)
        glTexParameteri(GLenum(GL_TEXTURE_2D), GLenum(GL_TEXTURE_MIN_FILTER), GL_LINEAR)
        glTexParameteri(GLenum(GL_TEXTURE_2D), GLenum(GL_TEXTURE_MAG_FILTER), GL_LINEAR)
        glTexParameteri(GLenum(GL_TEXTURE_2D), GLenum(GL_TEXTURE_WRAP_S), GL_CLAMP_TO_EDGE)
        glTexParameteri(GLenum(GL_TEXTURE_2D), GLenum(GL_TEXTURE_WRAP_T), GL_CLAMP_TO_EDGE)
        glTexImage2D(GLenum(GL_TEXTURE_2D), 0, GL_RGBA, GLsizei(width), GLsizei(height), 0,
                     GLenum(GL_RGBA), GLenum(GL_UNSIGNED_BYTE), pixels)
        return tex
    }

    /// Uploads a UIImage (RGBA8, straight alpha) to a texture.
    static func upload(_ image: UIImage) -> GLuint? {
        guard let cg = image.cgImage else { return nil }
        let maxSide = 4096
        let sc = min(1.0, Double(maxSide) / Double(max(cg.width, cg.height, 1)))
        let w = max(1, Int(Double(cg.width) * sc)), h = max(1, Int(Double(cg.height) * sc))
        guard cg.width > 0, cg.height > 0 else { return nil }
        var data = [UInt8](repeating: 0, count: w * h * 4)
        // The pointer handed to CGContext must stay valid for the WHOLE draw.
        // (`&data` is only valid for the call itself — drawing afterwards
        // wrote through a dangling pointer: heap corruption → random SIGABRT.)
        let drew: Bool = data.withUnsafeMutableBytes { raw -> Bool in
            guard let ctx = CGContext(data: raw.baseAddress, width: w, height: h, bitsPerComponent: 8,
                                      bytesPerRow: w * 4, space: CGColorSpaceCreateDeviceRGB(),
                                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            ctx.setBlendMode(.copy)
            ctx.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h))
            return true
        }
        guard drew else { return nil }
        var tex = GLuint(0)
        glGenTextures(1, &tex)
        glBindTexture(GLenum(GL_TEXTURE_2D), tex)
        glTexParameteri(GLenum(GL_TEXTURE_2D), GLenum(GL_TEXTURE_MIN_FILTER), GL_LINEAR)
        glTexParameteri(GLenum(GL_TEXTURE_2D), GLenum(GL_TEXTURE_MAG_FILTER), GL_LINEAR)
        glTexParameteri(GLenum(GL_TEXTURE_2D), GLenum(GL_TEXTURE_WRAP_S), GL_CLAMP_TO_EDGE)
        glTexParameteri(GLenum(GL_TEXTURE_2D), GLenum(GL_TEXTURE_WRAP_T), GL_CLAMP_TO_EDGE)
        data.withUnsafeBytes { raw in
            glTexImage2D(GLenum(GL_TEXTURE_2D), 0, GL_RGBA, GLsizei(w), GLsizei(h), 0,
                         GLenum(GL_RGBA), GLenum(GL_UNSIGNED_BYTE), raw.baseAddress)
        }
        return tex
    }

    static func delete(_ tex: GLuint) {
        if tex != 0 { glDeleteTextures(1, [tex]) }
    }

    // MARK: - framebuffers

    /// An offscreen render target: texture + FBO sized `w`x`h`.
    final class Target {
        let width: Int
        let height: Int
        var tex: GLuint = 0
        var fbo: GLuint = 0

        init(_ w: Int, _ h: Int) {
            width = max(1, w)
            height = max(1, h)
            tex = Gl.makeTexture(width, height)
            glGenFramebuffers(1, &fbo)
            glBindFramebuffer(GLenum(GL_FRAMEBUFFER), fbo)
            glFramebufferTexture2D(GLenum(GL_FRAMEBUFFER), GLenum(GL_COLOR_ATTACHMENT0),
                                   GLenum(GL_TEXTURE_2D), tex, 0)
            glBindFramebuffer(GLenum(GL_FRAMEBUFFER), 0)
        }

        deinit {
            if fbo != 0 { glDeleteFramebuffers(1, [fbo]) }
            if tex != 0 { Gl.delete(tex) }
        }

        func bind() {
            glBindFramebuffer(GLenum(GL_FRAMEBUFFER), fbo)
            glViewport(0, 0, GLsizei(width), GLsizei(height))
        }

        /// Reads the pixels back as a UIImage (RGBA, flipped to UIKit space).
        func readImage() -> UIImage? {
            var data = [UInt8](repeating: 0, count: width * height * 4)
            glBindFramebuffer(GLenum(GL_FRAMEBUFFER), fbo)
            glReadPixels(0, 0, GLsizei(width), GLsizei(height),
                         GLenum(GL_RGBA), GLenum(GL_UNSIGNED_BYTE), &data)
            glBindFramebuffer(GLenum(GL_FRAMEBUFFER), 0)
            // glReadPixels fills rows bottom-first; a CG bitmap expects the
            // top row first. Reverse the row order, otherwise everything
            // read back from GL (effect thumbnails) comes out upside down.
            let row = width * 4
            var flipped = [UInt8](repeating: 0, count: width * height * 4)
            for y in 0..<height {
                let src = (height - 1 - y) * row
                flipped.replaceSubrange(y * row..<(y + 1) * row, with: data[src..<(src + row)])
            }
            // Build the image while the buffer pointer is valid (see upload()).
            let w = width, h = height
            let made: CGImage? = flipped.withUnsafeMutableBytes { raw -> CGImage? in
                guard let ctx = CGContext(data: raw.baseAddress, width: w, height: h,
                                          bitsPerComponent: 8, bytesPerRow: row,
                                          space: CGColorSpaceCreateDeviceRGB(),
                                          bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return nil }
                return ctx.makeImage()
            }
            guard let img = made else { return nil }
            return UIImage(cgImage: img)
        }
    }

    /// Binds `target` then draws `program`'s quad over it.
    static func renderQuad(_ program: GLProgram, _ target: Target) {
        target.bind()
        drawQuad(program)
    }

    // MARK: - the effect shader prelude

    /// Wraps a def's GLSL body in the SDK runtime. Returns the full source
    /// and the 1-based line number where the user's code begins.
    static func effectShaderSource(_ d: EffectDef) -> (String, Int) {
        var src = """
precision mediump float;
varying vec2 vUv;
uniform sampler2D uTex;
uniform sampler2D uIn0;
uniform sampler2D uIn1;
uniform vec2 uRes;
uniform float uTime;
uniform float uHas0;
uniform float uHas1;

"""
        for p in d.props {
            src += "uniform float \(p.key);\n"
        }
        for c in d.colors {
            src += "uniform vec4 \(c.key);\n"
        }
        src += """
float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
float hash11(float p) { p = fract(p * 0.1031); p *= p + 33.33; p *= p + p; return fract(p); }
float hash21(vec2 p) { vec3 q = fract(vec3(p.xyx) * 0.1031); q += dot(q, q.yzx + 33.33); return fract((q.x + q.y) * q.z); }
float vnoise(vec2 p) {
    vec2 i = floor(p); vec2 f = fract(p); vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash21(i), hash21(i + vec2(1.0, 0.0)), u.x),
               mix(hash21(i + vec2(0.0, 1.0)), hash21(i + vec2(1.0, 1.0)), u.x), u.y);
}
float fbm(vec2 p) {
    float v = 0.0; float a = 0.5;
    for (int i = 0; i < 4; i++) { v += a * vnoise(p); p = p * 2.03; a *= 0.5; }
    return v;
}
vec2 rot(vec2 p, float a) { float c = cos(a); float s = sin(a); return vec2(c * p.x - s * p.y, s * p.x + c * p.y); }
vec3 hsv2rgb(vec3 c) {
    vec3 p = abs(fract(c.xxx + vec3(1.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0);
    return c.z * mix(vec3(1.0), clamp(p - 1.0, 0.0, 1.0), c.y);
}
vec3 rgb2hsv(vec3 c) {
    vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
    vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
    vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));
    float d = q.x - min(q.w, q.y);
    float e = 1.0e-10;
    return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}
vec4 unpremul(vec4 c) { if (c.a <= 0.0) { return vec4(0.0); } return vec4(c.rgb / c.a, c.a); }
vec4 src(vec2 uv) { return texture2D(uTex, clamp(uv, 0.0, 1.0)); }
vec4 srcW(vec2 uv, float pad) { return texture2D(uTex, clamp(uv, pad, 1.0 - pad)); }
vec4 in0(vec2 uv) { return texture2D(uIn0, clamp(uv, 0.0, 1.0)) * uHas0; }
vec4 in1(vec2 uv) { return texture2D(uIn1, clamp(uv, 0.0, 1.0)) * uHas1; }

vec4 effect(vec2 uv) {
"""
        let offset = src.components(separatedBy: "\n").count   // user code starts on the next line
        src += d.glsl
        if !d.glsl.hasSuffix("\n") { src += "\n" }
        src += "}\n\nvoid main() { gl_FragColor = effect(vUv); }\n"
        return (src, offset)
    }
}

// MARK: - GLContext: one context per thread

/// OpenGL ES contexts are per-thread; the preview owns the main-thread one,
/// thumbnails/export create their own on their work queue.
enum GLContext {
    static func make() -> EAGLContext? {
        EAGLContext(api: .openGLES3) ?? EAGLContext(api: .openGLES2)
    }
}
