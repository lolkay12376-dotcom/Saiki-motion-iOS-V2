// Xf.swift — transforms (Render).
//
// The 2D world: x spans [-ar, ar], y spans [-1, 1] (ar = canvas aspect).
// Every layer quad is placed by (x, y), scaled by (scale * scaleX/Y),
// rotated by rotZ around its anchor, and inherits the parent chain. The
// same math feeds the renderer and the overlay's selection box, so what
// you drag is what you see.

import Foundation
import CoreGraphics
import UIKit

enum Xf {

    /// Natural quad size (world units) of a layer's content.
    static func quadSize(_ l: Layer) -> (Float, Float) {
        switch l.type {
        case .IMAGE, .VIDEO:
            let (iw, ih) = contentAspect(l)
            let h: Float = 1.0
            return (h * iw / max(ih, 0.0001), h)
        case .TEXT:
            let fs = l.p("fontSize", Editor.time)
            let (tw, th) = TextRaster.measure(l)
            return (tw / max(th, 0.0001) * fs, fs)
        case .SHAPE:
            return (0.8, 0.84)
        case .FLARE:
            return (2, 2)
        case .PARTICLES:
            return (2, 2)
        case .MODEL:
            return (1, 1)
        default:
            return (0.8, 0.84)
        }
    }

    /// Source pixel aspect of a layer's media (1:1 when unknown).
    static func contentAspect(_ l: Layer) -> (Float, Float) {
        guard let path = l.imagePath else { return (1, 1) }
        if path.lowercased().hasSuffix(".glb") || path.lowercased().hasSuffix(".abc") {
            return (1, 1)
        }
        if let img = UIImage(contentsOfFile: path) {
            return (Float(img.size.width), Float(img.size.height))
        }
        if let (w, h) = VideoFrames.videoSize(path) {
            return (Float(w), Float(h))
        }
        return (1, 1)
    }

    /// 3x3 affine (a..f) of a layer at time `t`, parents included.
    /// Column-major like CGAffineTransform: [a b c d tx ty].
    static func matrix(_ l: Layer, _ t: Float) -> [Float] {
        return chainMatrix(l, t, 0)
    }

    private static func chainMatrix(_ l: Layer, _ t: Float, _ depth: Int) -> [Float] {
        guard depth < 16 else { return [1, 0, 0, 1, 0, 0] }
        var m = localMatrix(l, t)
        if l.parentId >= 0, let parent = Editor.scene.layers.first(where: { $0.id == l.parentId }) {
            m = mul(chainMatrix(parent, t, depth + 1), m)
        }
        return m
    }

    /// The layer's own matrix: translate to (x, y), rotate, scale, then
    /// offset by the anchor inside the quad.
    static func localMatrix(_ l: Layer, _ t: Float) -> [Float] {
        let lt = l.editTime("x", t)
        let x = l.p("x", lt)
        let y = l.p("y", lt)
        let sc = l.p("scale", lt)
        let sx = l.p("scaleX", lt)
        let sy = l.p("scaleY", lt)
        let rz = l.p("rotZ", lt) * Float.pi / 180
        let ax = l.p("anchorX", lt)
        let ay = l.p("anchorY", lt)
        let (qw, qh) = quadSize(l)

        // anchor offset in world units (rotated with the quad)
        let ox = -(ax - 50) / 100 * qw * sc * sx
        let oy = (ay - 50) / 100 * qh * sc * sy
        let c = cos(rz), s = sin(rz)
        let rox = ox * c - oy * s
        let roy = ox * s + oy * c

        // T(x + rox, y + roy) * R(rz) * S(sc*sx, sc*sy)
        let a = c * sc * sx, b = s * sc * sx
        let cc = -s * sc * sy, d = c * sc * sy
        return [a, b, cc, d, x + rox, y + roy]
    }

    /// C * M (row-vector convention like CGAffineTransform concatenation).
    static func mul(_ c: [Float], _ m: [Float]) -> [Float] {
        // CGAffineTransformConcat(child, parent) semantics:
        // result = child applied first, then parent.
        let a = m[0] * c[0] + m[1] * c[2]
        let b = m[0] * c[1] + m[1] * c[3]
        let cc = m[2] * c[0] + m[3] * c[2]
        let d = m[2] * c[1] + m[3] * c[3]
        let tx = m[4] * c[0] + m[5] * c[2] + c[4]
        let ty = m[4] * c[1] + m[5] * c[3] + c[5]
        return [a, b, cc, d, tx, ty]
    }

    /// Applies the matrix to a point.
    static func apply(_ m: [Float], _ x: Float, _ y: Float) -> (Float, Float) {
        (m[0] * x + m[2] * y + m[4], m[1] * x + m[3] * y + m[5])
    }

    /// World-space corners of the layer quad at time t (tl, tr, br, bl).
    static func quadCorners(_ l: Layer, _ t: Float) -> [(Float, Float)] {
        let m = matrix(l, t)
        let (qw, qh) = quadSize(l)
        let hw = qw / 2, hh = qh / 2
        return [apply(m, -hw, hh), apply(m, hw, hh), apply(m, hw, -hh), apply(m, -hw, -hh)]
    }

    /// Hit test in world space.
    static func hit(_ l: Layer, _ x: Float, _ y: Float, _ t: Float) -> Bool {
        let m = matrix(l, t)
        let inv = invert(m)
        guard let inv = inv else { return false }
        let (qw, qh) = quadSize(l)
        let p = apply(inv, x, y)
        return abs(p.0) <= qw / 2 && abs(p.1) <= qh / 2
    }

    static func invert(_ m: [Float]) -> [Float]? {
        let det = m[0] * m[3] - m[1] * m[2]
        if abs(det) < 1e-9 { return nil }
        let id = 1 / det
        return [m[3] * id, -m[1] * id, -m[2] * id, m[0] * id,
                (m[2] * m[5] - m[3] * m[4]) * id, (m[1] * m[4] - m[0] * m[5]) * id]
    }

    /// The camera that drives a 3D layer (nearest camera above it), or nil.
    static func camera(for l: Layer) -> Layer? {
        guard let idx = Editor.scene.layers.firstIndex(where: { $0 === l }) else { return nil }
        var best: Layer? = nil
        var bestIdx = -1
        for (j, c) in Editor.scene.layers.enumerated() where c.type == .CAMERA && c.visible && j > idx {
            if bestIdx < 0 || j < bestIdx {
                best = c
                bestIdx = j
            }
        }
        return best
    }

    /// Convert canvas-normalized (0..1, 0..1 top-left) to world units.
    static func world(_ nx: Float, _ ny: Float, ar: Float) -> (Float, Float) {
        (nx * 2 * ar - ar, 1 - ny * 2)
    }
}
