// CrashLog.swift — Swift side of the round-19 crash logger.
//
// Contract (from 19 rounds of binary patching, distilled):
//   * Install once, as early as possible in process lifetime.
//   * Never log from a signal handler in Swift — that is exactly the
//     round-14 "emergency save from signal context" bug that wedged the
//     main thread for 30+ seconds. All signal-context work lives in C.
//   * Uncaught NSExceptions are logged here too (main thread, safe to
//     use Foundation), then re-raised so iOS still writes its .ips.

import Foundation
import CCrashLog

/// fix2: `NSSetUncaughtExceptionHandler` takes a plain C function pointer.
/// A closure that mentions anything from the enclosing enum (`note`,
/// `crashDir`) "captures context" and the compiler rejects it — the v6 CI
/// run died on exactly that: *"a C function pointer cannot be formed from a
/// closure that captures context"* (CrashLog.swift:30:39). A TOP-LEVEL
/// function has no enclosing context, so it always converts; it reaches
/// back into the enum with fully-qualified static calls instead.
private func saikiUncaughtExceptionHandler(_ exc: NSException) {
    CrashLog.note("nsexc")
    let name = exc.name.rawValue
    let reason = exc.reason ?? ""
    let msg = "UNCAUGHT EXCEPTION: \(name) — \(reason)\n"
    let f = CrashLog.crashDir().appendingPathComponent("latest_exception.log")
    try? msg.write(to: f, atomically: true, encoding: .utf8)
}

enum CrashLog {

    /// Create <Documents>/Crash and install handlers. Safe to call twice.
    /// fix1: pass the Swift String straight to C — Swift bridges String to
    /// `const char *` for the duration of the call. (The old
    /// utf8CString/withUnsafeBufferPointer dance handed C an
    /// UnsafePointer<UInt8> where it wanted UnsafePointer<CChar> —
    /// UInt8 vs Int8, a compile error, twice.)
    static func install() {
        let dir = crashDir()
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        _ = ccrash_install(dir.path)

        // Route uncaught NSExceptions into the same report file. The handler
        // itself runs on the crashing thread *before* the abort, so Foundation
        // is allowed — but keep it minimal anyway.
        // fix2: pass the top-level function above, NOT a closure — see its
        // comment for why a closure cannot be used here.
        NSSetUncaughtExceptionHandler(saikiUncaughtExceptionHandler)
    }

    /// Record what the app is doing — shows up in the crash report ring.
    /// Cheap (one memcpy); call it at every interesting transition.
    static func note(_ tag: String) {
        ccrash_note(tag)
    }

    /// Directory shown in the Files app (R15/R19 user-visible crash folder).
    static func crashDir() -> URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? FileManager.default.temporaryDirectory
        return docs.appendingPathComponent("Crash", isDirectory: true)
    }

    /// Count of reports — Extras tab shows this (R19 §7).
    static func reportCount() -> Int {
        let files = (try? FileManager.default.contentsOfDirectory(at: crashDir(),
                                                                  includingPropertiesForKeys: nil)) ?? []
        return files.filter { $0.pathExtension == "log" }.count
    }
}
