// FreezeWatchdog.swift — round 15/19 design, corrected.
//
// What 19 rounds taught us, encoded here:
//   * Liveness = the heartbeat VALUE CHANGES. The round-14 bug ("a poke that
//     gets answered means alive") made real freezes undetectable, because a
//     wedged thread can still have a signal handler that answers pokes while
//     the run loop itself never turns. So: only a monotonic counter.
//   * A freeze is declared ONLY when the heartbeat stopped AND unsaved work
//     is in flight. Never while idling on menus, never during guarded
//     long operations (VDB import, export), never right after backgrounding.
//   * When a real freeze is confirmed: write the report, then abort. A wedged
//     app inside LiveContainer freezes the whole container — a clean kill is
//     strictly better for the user (and the OS log then tells the truth).

import Foundation
import UIKit
import CCrashLog

enum FreezeWatchdog {

    private static let checkInterval: TimeInterval = 2.0
    private static let stuckChecksNeeded = 3        // ~6 s truly stuck
    private static var thread: Thread? = nil
    private static let lock = NSLock()

    // Written only on the main thread; read by the watchdog thread.
    private static var heartbeat: Int64 = 0
    private static var dirty = false                // unsaved work in flight

    // Guarded operations: main thread may legitimately go quiet.
    private static var guarded = 0
    private static var guardLabel = ""

    /// Start the watchdog. Call once after CrashLog.install().
    static func start() {
        lock.lock()
        if thread != nil { lock.unlock(); return }   // idempotent
        DispatchQueue.main.async { observeLifecycle() }
        let t = Thread(block: run)
        t.name = "freeze-watchdog"
        t.qualityOfService = .utility
        thread = t
        lock.unlock()
        t.start()
    }

    // MARK: main-thread API ------------------------------------------------

    /// Call from the render/frame path and from every edit. Cheap.
    static func beat() { heartbeat &+= 1 }

    /// Unsaved work exists (set by the editor's markDirty()).
    static func setDirty(_ on: Bool) { dirty = on }

    /// Wrap a long main-thread-quiet operation: VDB import, export, share.
    static func runGuarded<T>(_ label: String, _ body: () throws -> T) rethrows -> T {
        lock.lock(); guarded += 1; if guardLabel.isEmpty { guardLabel = label }; lock.unlock()
        defer { lock.lock(); guarded -= 1; if guarded <= 0 { guarded = 0; guardLabel = "" }; lock.unlock() }
        return try body()
    }

    // MARK: watchdog thread -------------------------------------------------

    private static func run() {
        // A busy-but-healthy editor (user thinking, dialog open) used to be
        // aborted as "frozen" because only render/edit calls bumped the
        // heartbeat. Now the watchdog pings the main queue itself: if the
        // main thread answers, it is alive, whatever the user is doing.
        var lastPong: Int64 = 0
        var stuck = 0
        while true {
            DispatchQueue.main.async { lock.lock(); pong &+= 1; lock.unlock() }
            Thread.sleep(forTimeInterval: checkInterval)

            lock.lock()
            let p = pong
            let bg = inBackground
            let busy = guarded > 0
            let lbl = guardLabel
            lock.unlock()

            if p != lastPong || bg {
                stuck = 0
            } else if dirty {
                stuck += 1
                // long guarded work (VDB import, share) gets a much longer leash
                let needed = busy ? 15 : stuckChecksNeeded
                if stuck >= needed {
                    let detail = "main thread unresponsive for \(stuck * Int(checkInterval))s with unsaved work" +
                                 (busy ? " (in \(lbl))" : "")
                    ccrash_set_watchdog(1, detail)
                    CrashLog.note("freeze")
                    ccrash_report_freeze(detail)
                    abort()
                }
            } else {
                stuck = 0
            }
            lastPong = p
        }
    }

    private static var pong: Int64 = 0
    private static var inBackground = false
    private static var observing = false

    private static func observeLifecycle() {
        guard !observing else { return }
        observing = true
        let nc = NotificationCenter.default
        nc.addObserver(forName: UIApplication.didEnterBackgroundNotification, object: nil, queue: .main) { _ in
            lock.lock(); inBackground = true; lock.unlock()
        }
        nc.addObserver(forName: UIApplication.willEnterForegroundNotification, object: nil, queue: .main) { _ in
            lock.lock(); inBackground = false; lock.unlock()
        }
    }
}
