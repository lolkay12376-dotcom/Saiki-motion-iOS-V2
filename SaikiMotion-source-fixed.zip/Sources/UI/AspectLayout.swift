// AspectLayout.swift — letterboxing container (UI).
//
// Frames its subviews to the largest rect with the canvas aspect that fits
// the bounds — the Android FrameLayout + manual aspect math the preview
// area used. Setting `ratio` re-flows immediately.

import UIKit

final class AspectLayout: UIView {

    /// width / height of the canvas (e.g. 1080/1920 = 0.5625).
    var ratio: CGFloat = 9.0 / 16.0 {
        didSet {
            if ratio != oldValue { setNeedsLayout() }
        }
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        clipsToBounds = true
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    override func layoutSubviews() {
        super.layoutSubviews()
        guard bounds.width > 1, bounds.height > 1, ratio > 0 else { return }
        var w = bounds.width
        var h = w / ratio
        if h > bounds.height {
            h = bounds.height
            w = h * ratio
        }
        let f = CGRect(x: (bounds.width - w) / 2, y: (bounds.height - h) / 2, width: w, height: h)
        for v in subviews {
            v.frame = f
        }
    }
}
