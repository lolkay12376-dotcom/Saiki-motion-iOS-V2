// Chibi.swift — the app mascots (UI).
//
// Two bundled chibis (Resources/img, app-bundle root):
//   • chibi_thinking — the girl pondering with her cat: the empty-projects
//     illustration on the Projects tab.
//   • chibi_writing  — the girl drawing on her tablet: the AI Suggest
//     "in development" illustration on the AI tab.

import UIKit

final class ChibiView: UIView {

    enum Which { case thinking, writing }

    let which: Which
    var onImage: (() -> Void)? = nil

    private let iv = UIImageView()
    private var loaded = false

    init(_ which: Which) {
        self.which = which
        super.init(frame: .zero)
        iv.contentMode = .scaleAspectFit
        addSubview(iv)
        isUserInteractionEnabled = false
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    private var resourceName: String {
        which == .thinking ? "chibi_thinking" : "chibi_writing"
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        iv.frame = bounds.insetBy(dx: 6, dy: 6)
        if !loaded {
            loaded = true
            // asset catalogs first, then the bundle root (Resources/img is a
            // group build, so the pngs land beside the executable)
            var img = UIImage(named: resourceName)
            if img == nil, let u = Bundle.main.url(forResource: resourceName, withExtension: "png") {
                img = UIImage(contentsOfFile: u.path)
            }
            iv.image = img
        }
    }
}
