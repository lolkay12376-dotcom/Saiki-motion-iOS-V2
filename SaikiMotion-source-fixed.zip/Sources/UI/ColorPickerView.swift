// ColorPickerView.swift — the HSV color picker square + hue/opacity bars.

import UIKit
import Foundation

// MARK: - ColorPickerView

/// Saturation / brightness square, hue bar and opacity bar.
final class ColorPickerView: UIControl {
    var onChange: ((Int32) -> Void)? = nil
    private var hue: Float = 0
    private var sat: Float = 1
    private var value: Float = 1
    // PORT NOTE: Kotlin private `alpha` renamed (UIView.alpha collision).
    private var alphaVal: Float = 1
    private var drag = 0
    private let barH: CGFloat = 28
    private let gap: CGFloat = 12

    override init(frame: CGRect) {
        super.init(frame: frame)
    }

    func setColor(_ c: Int32) {
        let hsvn = ColorPickerView.argbToHSV(c)
        hue = hsvn.h; sat = hsvn.s; value = hsvn.v
        alphaVal = Float(colorAlpha(c)) / 255.0
        setNeedsDisplay()
    }

    func color() -> Int32 {
        ColorPickerView.hsvToARGB(hue, sat, value, Int(alphaVal * 255))
    }

    private func sqH() -> CGFloat { bounds.height - 2 * (barH + gap) }

    private static func hsvToARGB(_ h: Float, _ s: Float, _ v: Float, _ a: Int = 255) -> Int32 {
        let u = UIColor(hue: CGFloat(h) / 360, saturation: CGFloat(s), brightness: CGFloat(v), alpha: 1)
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, al: CGFloat = 0
        u.getRed(&r, green: &g, blue: &b, alpha: &al)
        return argbColor(a, Int(r * 255 + 0.5), Int(g * 255 + 0.5), Int(b * 255 + 0.5))
    }

    private static func argbToHSV(_ c: Int32) -> (h: Float, s: Float, v: Float) {
        let u = argbToUIColor(c)
        var h: CGFloat = 0, s: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        if u.getHue(&h, saturation: &s, brightness: &b, alpha: &a) {
            return (Float(h) * 360, Float(s), Float(b))
        }
        return (0, 0, 1)
    }

    private func marker(_ c: CGContext, _ x: CGFloat, _ y: CGFloat) {
        strokeCircle(c, x, y, 9, 3, Int32(bitPattern: 0xFFFFFFFF))
        strokeCircle(c, x, y, 10.5, 1.2, Int32(bitPattern: 0xFF000000))
    }

    private func gradientRoundRect(_ c: CGContext, _ r: CGRect, _ radius: CGFloat,
                                   colors: [CGColor], start: CGPoint, end: CGPoint) {
        guard let g = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors as CFArray, locations: nil) else { return }
        c.saveGState()
        c.addPath(CGPath(roundedRect: r, cornerWidth: radius, cornerHeight: radius, transform: nil))
        c.clip()
        c.drawLinearGradient(g, start: start, end: end, options: [])
        c.restoreGState()
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let w = bounds.width
        let sh = sqH()
        let sq = CGRect(x: 0, y: 0, width: w, height: sh)
        // white → hue (horizontal)
        gradientRoundRect(c, sq, 10,
                          colors: [UIColor.white.cgColor, argbToUIColor(ColorPickerView.hsvToARGB(hue, 1, 1)).cgColor],
                          start: CGPoint(x: 0, y: 0), end: CGPoint(x: w, y: 0))
        // transparent black → black (vertical)
        gradientRoundRect(c, sq, 10,
                          colors: [UIColor.black.withAlphaComponent(0).cgColor, UIColor.black.cgColor],
                          start: CGPoint(x: 0, y: 0), end: CGPoint(x: 0, y: sh))
        marker(c, CGFloat(sat) * w, CGFloat(1 - value) * sh)
        // hue bar
        let hy = sh + gap
        let bar = CGRect(x: 0, y: hy, width: w, height: barH)
        var cols: [CGColor] = []
        for i in 0...6 { cols.append(argbToUIColor(ColorPickerView.hsvToARGB(Float(i) * 60, 1, 1)).cgColor) }
        gradientRoundRect(c, bar, barH / 2, colors: cols,
                          start: CGPoint(x: 0, y: 0), end: CGPoint(x: w, y: 0))
        marker(c, CGFloat(hue / 360) * w, hy + barH / 2)
        // opacity bar
        let ay = hy + barH + gap
        let abar = CGRect(x: 0, y: ay, width: w, height: barH)
        fillRoundRect(c, abar, barH / 2, Int32(bitPattern: 0xFF666666))
        let base = ColorPickerView.hsvToARGB(hue, sat, value)
        gradientRoundRect(c, abar, barH / 2,
                          colors: [argbToUIColor(base & 0x00FFFFFF).cgColor,
                                   argbToUIColor(base | Int32(bitPattern: 0xFF000000)).cgColor],
                          start: CGPoint(x: 0, y: 0), end: CGPoint(x: w, y: 0))
        marker(c, CGFloat(alphaVal) * w, ay + barH / 2)
    }

    private func apply(_ pt: CGPoint) {
        let w = bounds.width
        let sh = sqH()
        let pxv = clamp(Float(pt.x / w), 0, 1)
        if drag == 1 {
            sat = pxv
            value = 1 - clamp(Float(pt.y / sh), 0, 1)
        } else if drag == 2 {
            hue = pxv * 359.9
        } else {
            alphaVal = pxv
        }
        setNeedsDisplay()
        onChange?(color())
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        let pt = t.location(in: self)
        let sh = sqH()
        disallowParentScrollInterception(self, true)
        drag = pt.y < sh ? 1 : (pt.y < sh + gap + barH + gap / 2 ? 2 : 3)
        apply(pt)
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard drag != 0, let t = touches.first else { return }
        apply(t.location(in: self))
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        drag = 0
        disallowParentScrollInterception(self, false)
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        drag = 0
        disallowParentScrollInterception(self, false)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}
