// MovePad.swift — MovePadView (trackpad), GridPick (3x3 anchors), FlareThumb.

import UIKit
import Foundation

// MARK: - MovePadView

/// Drag anywhere inside to move X and Y together (relative movement, like a trackpad).
final class MovePadView: UIControl {
    var px: Float = 0
    var py: Float = 0
    var onBegin: (() -> Void)? = nil
    var onMove: ((Float, Float) -> Void)? = nil
    private var lx: CGFloat = 0
    private var ly: CGFloat = 0

    override init(frame: CGRect) { super.init(frame: frame) }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        fillRoundRect(c, CGRect(x: 0, y: 0, width: bounds.width, height: bounds.height), 12, C.CARD)
        let cx = bounds.width / 2
        let cy = bounds.height / 2
        strokeLine(c, cx, 0, cx, bounds.height, 1, Int32(bitPattern: 0xFF3A3A42))
        strokeLine(c, 0, cy, bounds.width, cy, 1, Int32(bitPattern: 0xFF3A3A42))
        let ox = CGFloat(clamp(px / 3 * 160, Float(-cx + 14), Float(cx - 14)))
        let oy = CGFloat(clamp(-py / 3 * 160, Float(-cy + 14), Float(cy - 14)))
        fillCircle(c, cx + ox, cy + oy, 9, C.GREEN)
        drawText("X " + String(format: "%.2f", px) + "   Y " + String(format: "%.2f", py),
                 12, 20, color: C.DIM, size: 12, align: .left)
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        lx = t.location(in: self).x
        ly = t.location(in: self).y
        disallowParentScrollInterception(self, true)
        onBegin?()
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        let p = t.location(in: self)
        let k: Float = 3 / 160
        onMove?((Float(p.x - lx)) * k, -(Float(p.y - ly)) * k)
        lx = p.x
        ly = p.y
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        disallowParentScrollInterception(self, false)
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        disallowParentScrollInterception(self, false)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - GridPick

/// 3x3 anchor preset picker. Index 0..8, row-major from top-left.
final class GridPick: TapView {
    var sel = -1
    var onPick: ((Int) -> Void)? = nil

    override init(frame: CGRect) { super.init(frame: frame) }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        fillRoundRect(c, CGRect(x: 0, y: 0, width: bounds.width, height: bounds.height), 12, C.CARD)
        let padX: CGFloat = 28
        let padY: CGFloat = 22
        for i in 0..<9 {
            let x = padX + (bounds.width - 2 * padX) * CGFloat(i % 3) / 2
            let y = padY + (bounds.height - 2 * padY) * CGFloat(i / 3) / 2
            fillCircle(c, x, y, i == sel ? 10 : 5, i == sel ? C.GREEN : C.DIM)
        }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        let p = t.location(in: self)
        let col = clamp(Int(p.x / (bounds.width / 3)), 0, 2)
        let row = clamp(Int(p.y / (bounds.height / 3)), 0, 2)
        onPick?(row * 3 + col)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - FlareThumb

/// A card showing a pre-rendered flare; picks the picture up from FlareThumbs once it exists.
final class FlareThumb: TapView {
    let key: String
    let label: String

    init(_ key: String, _ label: String) {
        self.key = key
        self.label = label
        super.init(frame: .zero)
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let w = bounds.width
        let h = bounds.height
        fillRoundRect(c, CGRect(x: 0, y: 0, width: w, height: h), 14, Int32(bitPattern: 0xFF0B0B10))
        let b = FlareThumbs.cache[key]
        let th = h - 26
        if let b = b {
            c.saveGState()
            let clip = UIBezierPath(roundedRect: CGRect(x: 0, y: 0, width: w, height: h), cornerRadius: 14).cgPath
            c.addPath(clip)
            c.clip()
            let s = max(w / b.size.width, (th + 8) / b.size.height)
            let dw = b.size.width * s
            let dh = b.size.height * s
            if let cgi = b.cgImage {
                c.draw(cgi, in: CGRect(x: (w - dw) / 2, y: (th + 8 - dh) / 2, width: dw, height: dh))
            }
            c.restoreGState()
        } else {
            drawText("Rendering...", w / 2, th / 2, color: C.DIM, size: 11, align: .center)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { [weak self] in
                self?.setNeedsDisplay()
            }
        }
        fillRect(c, CGRect(x: 0, y: h - 26, width: w, height: 26), Int32(bitPattern: 0xCC000000))
        drawText(label, w / 2, h - 9, color: Int32(bitPattern: 0xFFFFFFFF), size: 12, bold: true, align: .center)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}
