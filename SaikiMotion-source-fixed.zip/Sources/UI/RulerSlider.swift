// RulerSlider.swift — the scrolling-ruler value control used for every parameter.

import UIKit
import Foundation

// MARK: - RulerSlider

/// The scrolling-ruler value control used for every parameter.
/// Drag horizontally to change the value, tap the label to toggle a keyframe.
final class RulerSlider: UIControl {
    var label = ""
    var lo: Float = 0
    var hi: Float = 1
    var value: Float = 0
    var dec = 2
    var hasKey = false
    var hasAnim = false
    var canKey = true
    var onChange: ((Float) -> Void)? = nil
    var onBegin: (() -> Void)? = nil
    var onLabelTap: (() -> Void)? = nil
    var onLabelLong: (() -> Void)? = nil
    var hasExpr = false
    var infinite = false
    var span: Float = 1
    var onExprIcon: (() -> Void)? = nil
    var rowSelected = false

    private var onIcon = false
    private var longFired = false
    private var raw: Float = 0
    private var downX: CGFloat = 0
    private var lastX: CGFloat = 0
    private var dragging = false
    private var onLabel = false
    private var longWork: DispatchWorkItem? = nil

    override init(frame: CGRect) {
        super.init(frame: frame)
    }

    private func fmt(_ v: Float) -> String {
        let q: Float = abs(v) < 0.5 * pow(10, -Float(dec)) ? 0 : v
        return String(format: "%.\(dec)f", q)
    }

    private func labelW() -> CGFloat { bounds.width * 0.36 }
    private func ppu() -> CGFloat {
        // guard: a degenerate range (min == max) must not divide by zero
        let range: Float = infinite ? max(span, 0.001) : max(hi - lo, 0.001)
        return (bounds.width - labelW()) / CGFloat(range * 0.6)
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let w = bounds.width, h = bounds.height
        fillRoundRect(c, CGRect(x: 0, y: 0, width: w, height: h), 10, C.CARD)
        if rowSelected {
            strokeRoundRect(c, bounds.insetBy(dx: 1, dy: 1), 10, 2, C.GREEN)
        }

        let lw = labelW()
        drawText(label, 14, h / 2 + 5, color: hasExpr ? C.RED : C.TEXT, size: 15, bold: true, align: .left)
        if onExprIcon != nil {
            let ec: Int32 = hasExpr ? C.RED : Int32(bitPattern: 0xFF7A7A84)
            let r = CGRect(x: lw - 38, y: h - 24, width: 32, height: 18)
            strokeRoundRect(c, r, 6, 2, ec)
            drawText("fx", lw - 22, h - 11, color: ec, size: 10, bold: true, align: .center)
        }
        if canKey && (hasKey || hasAnim) {
            Icons.draw(c, hasKey ? "diamond_f" : "diamond", lw - 14, 16, 12,
                       hasKey ? C.GREEN : Int32(bitPattern: 0xFF7A7A84))
        }

        // ruler
        let cxv = lw + (w - lw) / 2
        let ppuVal = ppu()
        c.saveGState()
        c.clip(to: CGRect(x: lw, y: 0, width: w - lw, height: h))
        let range: Float = infinite ? span : hi - lo
        let rawStep: Float = range * 0.1
        let mag: Float = pow(10, Float(floor(log10(Double(rawStep)))))
        let f: Float = rawStep / mag
        let nice: Float = f < 1.5 ? 1 : (f < 3.5 ? 2 : (f < 7.5 ? 5 : 10))
        let major: Float = nice * mag
        let minor: Float = major / 5
        let k0 = Int(ceil(Double((value - Float((cxv - lw) / ppuVal)) / minor)))
        let k1 = Int(floor(Double((value + Float((w - cxv) / ppuVal)) / minor)))
        if k1 >= k0 {
            for k in k0...k1 {
                let v = Float(k) * minor
                if v < lo - 0.0001 || v > hi + 0.0001 { continue }
                let x = cxv + CGFloat(v - value) * ppuVal
                let isMajor = k % 5 == 0
                let top: CGFloat = isMajor ? h - 18 : h - 11
                strokeLine(c, x, top, x, h - 4, 1.2, Int32(bitPattern: 0xFF6B6B75))
                if isMajor {
                    let s = String(format: major >= 1 ? "%.0f" : "%.1f", v)
                    drawText(s, x, h - 22, color: Int32(bitPattern: 0xFF8C8C96), size: 11, align: .center)
                }
            }
        }
        // boundary markers at min and max
        let xl = cxv + CGFloat(lo - value) * ppuVal
        let xh = cxv + CGFloat(hi - value) * ppuVal
        if xl >= lw && xl <= w { strokeLine(c, xl, 8, xl, h - 4, 2, Int32(bitPattern: 0xFFFFFFFF)) }
        if xh >= lw && xh <= w { strokeLine(c, xh, 8, xh, h - 4, 2, Int32(bitPattern: 0xFFFFFFFF)) }
        // centre line
        strokeLine(c, cxv, 30, cxv, h, 2, C.GREEN)
        c.restoreGState()

        // value bubble
        let s = fmt(value)
        let bw = max(44, measureText(s, 15, true) + 20)
        let r = CGRect(x: cxv - bw / 2, y: 6, width: bw, height: 28)
        fillRoundRect(c, r, 8, C.GREEN)
        drawText(s, cxv, 26, color: C.ONDARK, size: 15, bold: true, align: .center)
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        let pt = t.location(in: self)
        downX = pt.x; lastX = pt.x; dragging = false
        onLabel = pt.x < labelW()
        onIcon = onLabel && onExprIcon != nil && pt.x > labelW() - 42 && pt.y > bounds.height * 0.45
        longFired = false
        raw = value
        if !onLabel {
            onBegin?()
            disallowParentScrollInterception(self, true)
        } else if !onIcon {
            // postDelayed(longRun, 450)
            longWork = DispatchWorkItem(block: { [weak self] in
                guard let self = self, !self.dragging else { return }
                self.longFired = true
                self.onLabelLong?()
            })
            if let work = longWork { DispatchQueue.main.asyncAfter(deadline: .now() + 0.45, execute: work) }
        }
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        let x = t.location(in: self).x
        if onLabel { return }
        if abs(x - downX) > 4 { dragging = true }
        let dx = x - lastX
        lastX = x
        raw = raw - Float(dx) / Float(ppu())
        if !infinite { raw = clamp(raw, lo, hi) }
        let v: Float = dec == 0 ? Float(kotlinRound(raw)) : raw
        if v != value { value = v; onChange?(v); setNeedsDisplay() }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else {
            longWork?.cancel(); longWork = nil
            disallowParentScrollInterception(self, false)
            return
        }
        let x = t.location(in: self).x
        longWork?.cancel(); longWork = nil
        if onIcon && abs(x - downX) < 10 { onExprIcon?() }
        else if onLabel && !longFired && abs(x - downX) < 8 { onLabelTap?() }
        disallowParentScrollInterception(self, false)
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        longWork?.cancel(); longWork = nil
        disallowParentScrollInterception(self, false)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}
