// Theme.swift — the design system (UI).
// Color constants, fonts and the Canvas/Paint-style drawing helpers every
// custom view shares. The current context handed out by UIKit inside draw(_:)
// is top-left origin with y pointing down — identical to Android's Canvas —
// so all Kotlin coordinates carry over. "dp" values are used as points
// directly (PORTING_GUIDE rule 22).

import UIKit
import Foundation

// iOS port of Ui.kt — SaikiMotion
// Custom UI widgets: color constants, vector icons, icon/chip/pill/tool buttons,
// the scrolling RulerSlider, effect cards, bezier graph editor, switch rows,
// color picker, value graph and the Toast replacement.
//
// PORT NOTE (general): Android Paint/Canvas drawing is ported to draw(_:) + CGContext.
// The current context handed out by UIKit inside draw(_:) is top-left origin with y
// pointing down — identical to Android's Canvas — so all Kotlin coordinates carry over.
// "dp" values are used as points directly (PORTING_GUIDE rule 22).

import UIKit
import Foundation

// MARK: - Colors (object C)

/// Theme constants (ARGB Int32, Android bit layout).
/// GREEN is the app accent — the editor orange used for buttons, the
/// playhead, selected chips, keyframes and every highlight. ONDARK is the
/// near-black green text drawn on top of the accent fills.
enum C {
    static let BG = Int32(bitPattern: 0xFF0E0E10)
    static let PANEL = Int32(bitPattern: 0xFF111114)
    static let CARD = Int32(bitPattern: 0xFF1C1C21)
    static let CARD2 = Int32(bitPattern: 0xFF26262C)
    static let GREEN = Int32(bitPattern: 0xFFFF8A1F)
    static let GREEN_DARK = Int32(bitPattern: 0xFFD96A00)
    static let ONDARK = Int32(bitPattern: 0xFF0D2113)
    static let AMBER = Int32(bitPattern: 0xFFF5B301)
    static let RED = Int32(bitPattern: 0xFFEF4444)
    static let BLUE = Int32(bitPattern: 0xFF38BDF8)
    static let TEXT = Int32(bitPattern: 0xFFFFFFFF)
    static let DIM = Int32(bitPattern: 0xFF8C8C96)
    static let LINE = Int32(bitPattern: 0xFF2A2A30)
}

// MARK: - Shared UIKit helpers (additions required by the Canvas/Paint port)

/// Key window of the app (iOS 15 scene API).
func appKeyWindow() -> UIWindow? {
    let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
    let windows = scenes.flatMap { $0.windows }
    return windows.first { $0.isKeyWindow } ?? windows.first
}

@inline(__always) func boldFont(_ size: CGFloat) -> UIFont { UIFont.boldSystemFont(ofSize: size) }
@inline(__always) func sysFont(_ size: CGFloat) -> UIFont { UIFont.systemFont(ofSize: size) }

/// Android Paint.measureText equivalent.
func measureText(_ s: String, _ size: CGFloat, _ bold: Bool = false) -> CGFloat {
    if s.isEmpty { return 0 }
    let attr = NSAttributedString(string: s, attributes: [
        .font: bold ? boldFont(size) : sysFont(size)
    ])
    return attr.size().width
}

/// Android Canvas.drawText equivalent: (x, y) is the text BASELINE, returns the text width.
/// `align` mirrors Paint.Align (left/center/right).
@discardableResult
func drawText(_ s: String, _ x: CGFloat, _ y: CGFloat, color: Int32,
              size: CGFloat, bold: Bool = false, align: NSTextAlignment = .left) -> CGFloat {
    if s.isEmpty { return 0 }
    let f = bold ? boldFont(size) : sysFont(size)
    let attr = NSAttributedString(string: s, attributes: [.font: f, .foregroundColor: argbToUIColor(color)])
    let w = attr.size().width
    var px = x
    if align == .center { px -= w / 2 } else if align == .right { px -= w }
    attr.draw(at: CGPoint(x: px, y: y - f.ascender))
    return w
}

func fillRoundRect(_ c: CGContext, _ r: CGRect, _ radius: CGFloat, _ color: Int32) {
    c.setFillColor(argbToUIColor(color).cgColor)
    c.addPath(CGPath(roundedRect: r, cornerWidth: radius, cornerHeight: radius, transform: nil))
    c.fillPath()
}

func strokeRoundRect(_ c: CGContext, _ r: CGRect, _ radius: CGFloat, _ width: CGFloat, _ color: Int32) {
    c.setStrokeColor(argbToUIColor(color).cgColor)
    c.setLineWidth(width)
    c.addPath(CGPath(roundedRect: r, cornerWidth: radius, cornerHeight: radius, transform: nil))
    c.strokePath()
}

func strokeLine(_ c: CGContext, _ x0: CGFloat, _ y0: CGFloat, _ x1: CGFloat, _ y1: CGFloat,
                _ width: CGFloat, _ color: Int32) {
    c.setStrokeColor(argbToUIColor(color).cgColor)
    c.setLineWidth(width)
    c.move(to: CGPoint(x: x0, y: y0))
    c.addLine(to: CGPoint(x: x1, y: y1))
    c.strokePath()
}

func fillCircle(_ c: CGContext, _ x: CGFloat, _ y: CGFloat, _ r: CGFloat, _ color: Int32) {
    c.setFillColor(argbToUIColor(color).cgColor)
    c.fillEllipse(in: CGRect(x: x - r, y: y - r, width: 2 * r, height: 2 * r))
}

func strokeCircle(_ c: CGContext, _ x: CGFloat, _ y: CGFloat, _ r: CGFloat, _ width: CGFloat, _ color: Int32) {
    c.setStrokeColor(argbToUIColor(color).cgColor)
    c.setLineWidth(width)
    c.strokeEllipse(in: CGRect(x: x - r, y: y - r, width: 2 * r, height: 2 * r))
}

func fillRect(_ c: CGContext, _ r: CGRect, _ color: Int32) {
    c.setFillColor(argbToUIColor(color).cgColor)
    c.fill(r)
}

/// PORT NOTE: Android `parent.requestDisallowInterceptTouchEvent(true/false)` — while a drag
/// is active every ancestor UIScrollView's pan gesture is disabled, re-enabled afterwards.
func disallowParentScrollInterception(_ v: UIView, _ disallow: Bool) {
    var p = v.superview
    while let sv = p {
        if let sc = sv as? UIScrollView { sc.panGestureRecognizer.isEnabled = !disallow }
        p = sv.superview
    }
}

/// PORT NOTE: Android's `View.setOnClickListener { ... }` + `isPressed` invalidate behavior
/// packed into one base class. Click = touch-up inside bounds, just like Android.
class TapView: UIControl {
    var onClick: (() -> Void)? = nil

    override var isHighlighted: Bool { didSet { setNeedsDisplay() } }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        isHighlighted = true
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        isHighlighted = false
        if let t = touches.first, bounds.contains(t.location(in: self)) { onClick?() }
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        isHighlighted = false
    }
}