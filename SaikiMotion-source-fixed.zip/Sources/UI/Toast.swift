// Toast.swift — the android.widget.Toast replacement.

import UIKit
import Foundation

// MARK: - Toast

/// android.widget.Toast replacement (PORTING_GUIDE rule 15): a small rounded dark label
/// overlay on the key window that fades out after ~2.2s.
final class Toast {
    private static var current: UILabel? = nil

    private init() {}

    static func show(_ text: String) {
        guard let window = appKeyWindow() else { return }
        if let cur = current { cur.removeFromSuperview(); current = nil }
        let lbl = UILabel()
        lbl.text = text
        lbl.textColor = argbToUIColor(C.TEXT)
        lbl.font = sysFont(14)
        lbl.textAlignment = .center
        lbl.numberOfLines = 0
        lbl.backgroundColor = UIColor(red: 34.0 / 255.0, green: 34.0 / 255.0, blue: 40.0 / 255.0, alpha: 0.96)
        lbl.layer.cornerRadius = 16
        lbl.layer.masksToBounds = true
        let maxW = window.bounds.width - 48
        let sz = lbl.sizeThatFits(CGSize(width: maxW, height: .greatestFiniteMagnitude))
        let w = min(maxW, sz.width + 36)
        let h = sz.height + 24
        lbl.frame = CGRect(x: (window.bounds.width - w) / 2, y: window.bounds.height - 160 - h, width: w, height: h)
        lbl.alpha = 0
        window.addSubview(lbl)
        current = lbl
        UIView.animate(withDuration: 0.15) { lbl.alpha = 1 }
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.05) {
            UIView.animate(withDuration: 0.35, animations: { lbl.alpha = 0 }) { _ in
                lbl.removeFromSuperview()
                if Toast.current === lbl { Toast.current = nil }
            }
        }
    }
}
