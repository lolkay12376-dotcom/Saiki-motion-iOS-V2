/*********************************************************************
  bitshuffle-generic.c — scalar bit-shuffle implementation.

  Faithful re-implementation of the scalar path from c-blosc 1.21.5
  (bitshuffle-generic.c): for each byte-plane j of the elements, gather the
  j-th byte of every element, transpose its bits into 8 packed bit-rows
  (MSB-first), and store the plane block at offset j*8*(size/8) — exactly
  the layout OpenVDB's blosc integration produces, so Houdini / EmberGen /
  OpenVDB 10 files decode correctly.

  `size` must be a multiple of 8 (blosc_internal_bit(un)shuffle checks
  this before calling).
**********************************************************************/

#include <string.h>
#include <stddef.h>
#include <stdint.h>
#include "bitshuffle-generic.h"
#include "blosc-common.h"


/* Transpose the bits of `size` bytes: output holds 8 rows of size/8 bytes,
   row b carrying bit (7-b) of every input byte (MSB first). */
static void bshuf_trans_bit_byte(const void* in, void* out, const size_t size) {
    const char* in_b = (const char*)in;
    char* out_b = (char*)out;
    size_t nbyte_bitrow = size / 8;
    size_t ii, kk;
    char x;
    unsigned int bit;

    memset(out_b, 0, size);
    for (ii = 0; ii < nbyte_bitrow; ii++) {
        for (kk = 0; kk < 8; kk++) {
            x = in_b[ii * 8 + kk];
            for (bit = 0; bit < 8; bit++) {
                out_b[bit * nbyte_bitrow + ii] |= (char)(((x >> (7 - bit)) & 1) << (7 - kk));
            }
        }
    }
}

/* Inverse of the above. */
static void bshuf_untrans_bit_byte(const void* in, void* out, const size_t size) {
    const char* in_b = (const char*)in;
    char* out_b = (char*)out;
    size_t nbyte_bitrow = size / 8;
    size_t ii, kk;
    char x;
    unsigned int bit;

    for (ii = 0; ii < nbyte_bitrow; ii++) {
        for (kk = 0; kk < 8; kk++) {
            x = 0;
            for (bit = 0; bit < 8; bit++) {
                x <<= 1;
                x |= (char)((in_b[bit * nbyte_bitrow + ii] >> (7 - kk)) & 1);
            }
            out_b[ii * 8 + kk] = x;
        }
    }
}


int64_t blosc_internal_bshuf_trans_bit_elem_scal(void* in, void* out, const size_t size,
                                                 const size_t elem_size, void* tmp) {
    char* p_in = (char*)in;
    char* p_out = (char*)out;
    char* p_tmp = (char*)tmp;
    size_t nbyte_bitrow = size / 8;
    size_t ii, jj;

    if ((size % 8) != 0) {
        return -1;
    }

    for (jj = 0; jj < elem_size; jj++) {
        /* gather byte-plane jj */
        for (ii = 0; ii < size; ii++) {
            p_tmp[ii] = p_in[ii * elem_size + jj];
        }
        /* bit-transpose it into the plane block for jj */
        bshuf_trans_bit_byte(p_tmp, p_out + jj * 8 * nbyte_bitrow, size);
    }
    return (int64_t)(size * elem_size);
}


int64_t blosc_internal_bshuf_untrans_bit_elem_scal(void* in, void* out, const size_t size,
                                                   const size_t elem_size, void* tmp) {
    char* p_in = (char*)in;
    char* p_out = (char*)out;
    char* p_tmp = (char*)tmp;
    size_t nbyte_bitrow = size / 8;
    size_t ii, jj;

    if ((size % 8) != 0) {
        return -1;
    }

    for (jj = 0; jj < elem_size; jj++) {
        /* bit-untranspose the plane block for jj */
        bshuf_untrans_bit_byte(p_in + jj * 8 * nbyte_bitrow, p_tmp, size);
        /* scatter back to every element */
        for (ii = 0; ii < size; ii++) {
            p_out[ii * elem_size + jj] = p_tmp[ii];
        }
    }
    return (int64_t)(size * elem_size);
}
