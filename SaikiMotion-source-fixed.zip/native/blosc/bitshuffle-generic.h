/*********************************************************************
  bitshuffle-generic.h — scalar (portable) bit-shuffle routines.

  Restored for the source build: the recovered subset shipped only the
  byte-unshuffle; the decompress path also needs the bit-wise variants
  (BITSHUFFLE flag, what OpenVDB/Houdini write by default).
**********************************************************************/

#ifndef BITSHUFFLE_GENERIC_H
#define BITSHUFFLE_GENERIC_H

#include "blosc-export.h"
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*  Bit-shuffle a block of sz elements, each elem_size bytes.  tmp must hold
    at least `sz` bytes.  Returns the number of bytes processed. */
BLOSC_NO_EXPORT int64_t blosc_internal_bshuf_trans_bit_elem_scal(void* in, void* out,
                                                                 const size_t size,
                                                                 const size_t elem_size,
                                                                 void* tmp);

/*  Inverse of the above. */
BLOSC_NO_EXPORT int64_t blosc_internal_bshuf_untrans_bit_elem_scal(void* in, void* out,
                                                                   const size_t size,
                                                                   const size_t elem_size,
                                                                   void* tmp);

#ifdef __cplusplus
}
#endif

#endif /* BITSHUFFLE_GENERIC_H */
