/*********************************************************************
  blosc-comp-features.h — compiler feature detection shims.

  Restored stub for the source build: none of the optional intrinsics are
  needed on the generic path (arm64 iOS), so the header is intentionally
  minimal.
**********************************************************************/

#ifndef BLOSC_COMP_FEATURES_H
#define BLOSC_COMP_FEATURES_H

#endif /* BLOSC_COMP_FEATURES_H */
