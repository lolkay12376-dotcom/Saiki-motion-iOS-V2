/*********************************************************************
  blosc-export.h — visibility macros for c-blosc.

  Upstream ships this in blosc-export.h; it was missing from the recovered
  decompression-only subset, so it is restored here verbatim in spirit:
  everything is hidden except the public blosc_* API.
**********************************************************************/

#ifndef BLOSC_EXPORT_H
#define BLOSC_EXPORT_H

/* Only GCC/Clang understand the visibility attributes. */
#if defined(_WIN32) || defined(__CYGWIN__)
  #define BLOSC_EXPORT __declspec(dllexport)
  #define BLOSC_NO_EXPORT
#else
  #if defined(__GNUC__) || defined(__clang__)
    #define BLOSC_EXPORT __attribute__((visibility("default")))
    #define BLOSC_NO_EXPORT __attribute__((visibility("hidden")))
  #else
    #define BLOSC_EXPORT
    #define BLOSC_NO_EXPORT
  #endif
#endif

/* Inline macro for the dispatchers. */
#ifndef BLOSC_INLINE
  #if defined(_MSC_VER) && !defined(__cplusplus)
    #define BLOSC_INLINE __inline
  #elif defined(__GNUC__) || defined(__clang__)
    #define BLOSC_INLINE inline
  #else
    #define BLOSC_INLINE
  #endif
#endif

#endif /* BLOSC_EXPORT_H */
