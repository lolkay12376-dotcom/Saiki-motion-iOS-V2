/*********************************************************************
  blosc-private.h — internal helpers for blosc.c.

  The upstream file was corrupted during the binary rounds ("404 Not Found"
  placeholder).  blosc.c in this subset defines its context struct inline
  and needs nothing from here, so this is a valid empty stub that keeps the
  header set complete.
**********************************************************************/

#ifndef BLOSC_PRIVATE_H
#define BLOSC_PRIVATE_H

#endif /* BLOSC_PRIVATE_H */
