/*********************************************************************
  blosclz.h — BloscLZ codec interface (restored for the source build).
**********************************************************************/

#ifndef BLOSCLZ_H
#define BLOSCLZ_H

#include "blosc-export.h"

#ifdef __cplusplus
extern "C" {
#endif

#define BLOSCLZ_VERSION_MAJOR 1
#define BLOSCLZ_VERSION_MINOR 1
#define BLOSCLZ_VERSION_RELEASE 0
#define BLOSCLZ_VERSION_STRING "1.1.0"

/*
  Compress a block of data.  Returns the number of bytes written, or 0 if
  the data could not be compressed (in which case the caller should store
  the block uncompressed).
*/
BLOSC_NO_EXPORT int blosclz_compress(const int clevel, const void* input, int length,
                                     void* output, int maxout, const int split_block);

/*
  Decompress a block of data compressed by blosclz_compress.  Returns the
  number of bytes decompressed, or a negative value on error.
*/
BLOSC_NO_EXPORT int blosclz_decompress(const void* input, int length, void* output, int maxout);

#ifdef __cplusplus
}
#endif

#endif /* BLOSCLZ_H */
