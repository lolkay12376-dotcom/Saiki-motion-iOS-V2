/*********************************************************************
  shuffle.h — dispatch interface for shuffle/unshuffle routines.

  Restored for the source build (was missing from the recovered subset).
**********************************************************************/

#ifndef SHUFFLE_H
#define SHUFFLE_H

#include "blosc-export.h"
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*  Shuffle a block of bytes.  This operation will transpose the bytes
    leaving the first byte of every element in the first blocksize/ typesize
    bytes of the destination, the second in the second, etc. */
BLOSC_NO_EXPORT void blosc_internal_shuffle(const size_t bytesoftype, const size_t blocksize,
                                            const uint8_t* _src, const uint8_t* _dest);

/*  Unshuffle a block of bytes. */
BLOSC_NO_EXPORT void blosc_internal_unshuffle(const size_t bytesoftype, const size_t blocksize,
                                              const uint8_t* _src, const uint8_t* _dest);

/*  Bit-shuffle a block of bytes by transposing the bits. */
BLOSC_NO_EXPORT int blosc_internal_bitshuffle(const size_t bytesoftype, const size_t blocksize,
                                              const uint8_t* const _src, const uint8_t* _dest,
                                              const uint8_t* _tmp);

/*  Bit-unshuffle a block of bytes by untransposing the bits. */
BLOSC_NO_EXPORT int blosc_internal_bitunshuffle(const size_t bytesoftype, const size_t blocksize,
                                                const uint8_t* const _src, const uint8_t* _dest,
                                                const uint8_t* _tmp);

#ifdef __cplusplus
}
#endif

#endif /* SHUFFLE_H */
