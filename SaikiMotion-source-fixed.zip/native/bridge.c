/* bridge.c — Swift-facing entry points for the native decoders.
 *
 * SaikiMotion source build. The recovered decoders are freestanding C that
 * take an OS-services vtable (struct Host); this bridge is the only file
 * that links the C library, so the decoders stay untouched.
 *
 * saiki_abc_to_glb(src, out, cap):
 *   Transcodes an Alembic/Ogawa .abc next to itself ("<stem>.glb") and
 *   copies that new path into `out` (no in-place Swift String games here —
 *   the source build can afford a plain buffer).
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "abc2glb.c"

static void* host_fopen(const char* p, const char* mode) { return fopen(p, mode); }
static int host_fclose(void* f) { return fclose((FILE*)f); }
static unsigned long host_fread(void* buf, unsigned long sz, unsigned long n, void* f) {
    return fread(buf, sz, n, (FILE*)f);
}
static unsigned long host_fwrite(const void* buf, unsigned long sz, unsigned long n, void* f) {
    return fwrite(buf, sz, n, (FILE*)f);
}
static void* host_malloc(unsigned long n) { return malloc(n); }
static void host_free(void* p) { free(p); }

int saiki_abc_to_glb(const char* src_path, char* out_glb_path, unsigned long out_cap) {
    if (!src_path || !out_glb_path || out_cap < 4) return 0;
    size_t n = strlen(src_path);
    if (n < 5 || n > 1024) return 0;
    unsigned char buf[1100];
    memcpy(buf, src_path, n + 1);

    struct Host host;
    host.fopen = host_fopen;
    host.fclose = host_fclose;
    host.fread = host_fread;
    host.fwrite = host_fwrite;
    host.malloc = host_malloc;
    host.free = host_free;

    if (!abc_hook(buf, (unsigned long)n, &host)) return 0;
    if (n >= out_cap) return 0;
    memcpy(out_glb_path, buf, n + 1);
    return 1;
}
