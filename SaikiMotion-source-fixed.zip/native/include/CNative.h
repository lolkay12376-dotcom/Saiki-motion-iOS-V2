#ifndef CNATIVE_H
#define CNATIVE_H

/* Umbrella for the SaikiMotion native decoders module.
 * Linked as a static framework; imported from Swift as `import CNative`.
 *
 * NOTE: the c-blosc headers are deliberately NOT included here. Public
 * framework headers are COPIED into CNative.framework/Headers at build
 * time, and a copied "../blosc/blosc.h" include cannot resolve from
 * there — it broke the Swift Clang-module build. Only the single
 * function Swift calls is re-declared below, verbatim from blosc.h
 * (BLOSC_EXPORT expands to nothing on iOS static builds). */

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* c-blosc 1.21.5 — decompress one Blosc frame (blosc.c). */
int blosc_decompress(const void* src, void* dest, size_t destsize);

/* Alembic/Ogawa -> GLB transcode (bridge.c). Writes "<stem>.glb" beside the
 * source and copies that path into out_glb_path. Returns 1 on success. */
int saiki_abc_to_glb(const char* src_path, char* out_glb_path, unsigned long out_cap);

#ifdef __cplusplus
}
#endif

#endif /* CNATIVE_H */
