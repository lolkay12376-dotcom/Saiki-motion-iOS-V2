// EditorLiveCache.swift — idle "live render" cache for the editor (After Effects style).
//
// While nothing is being touched, the editor renders the frame at the playhead — then the
// next uncached frame after it, wrapping round — into the on-disk FrameCache
// (<Caches>/SaikiMotion/frames/…). The timeline shows cached ranges as a green bar and
// playback reads cached frames instead of re-running the GL pipeline, so scenes with many
// layers play smoothly. Any edit makes the cache stale; the cache can be cleared from
// Scene setup → Live render cache or Home → Extras.
//
// Frames are rendered one at a time on the main thread with the preview's own renderer
// (no second set of textures in memory), at most about 40% of the time, and it pauses
// at once when you touch anything, play, open a dialog, or the system warns about memory.

import UIKit

extension EditorViewController {

    func startLiveCache() {
        stopLiveCache()
        let t = Timer(timeInterval: 0.06, repeats: true) { [weak self] _ in self?.liveTick() }
        RunLoop.main.add(t, forMode: .common)
        liveTimer = t
        NotificationCenter.default.addObserver(self, selector: #selector(liveMemoryWarning),
                                               name: UIApplication.didReceiveMemoryWarningNotification,
                                               object: nil)
    }

    func stopLiveCache() {
        liveTimer?.invalidate()
        liveTimer = nil
        NotificationCenter.default.removeObserver(self, name: UIApplication.didReceiveMemoryWarningNotification,
                                                  object: nil)
    }

    @objc func liveMemoryWarning() {
        FrameCache.suspended = true       // stop rendering ahead until the editor is reopened
        preview.releaseVideos()
    }

    func liveTick() {
        guard FrameCache.enabled, !FrameCache.suspended, !FrameCache.liveFull, !playing,
              view.window != nil, navigationController?.topViewController === self,
              presentedViewController == nil else { return }
        let now = CFAbsoluteTimeGetCurrent()
        if now - lastActivity < 0.6 || now < liveNextAt { return }
        let k = preview.cacheKey
        guard k.0 > 1, k.1 > 1 else { return }
        guard let t = FrameCache.nextUncached(from: Editor.time, duration: Editor.scene.duration,
                                              Editor.project.id, k.0, k.1, k.2) else {
            if liveBusy { liveBusy = false; timeline.setNeedsDisplay() }
            return
        }
        liveBusy = true
        let t0 = CACurrentMediaTime()
        let ok = preview.cacheFrame(at: t)
        let dt = CACurrentMediaTime() - t0
        liveNextAt = CFAbsoluteTimeGetCurrent() + (ok ? max(0.02, dt * 1.5) : 1.0)
        if now - lastTimelineRefresh > 0.3 {
            lastTimelineRefresh = now
            timeline.setNeedsDisplay()
        }
    }
}
