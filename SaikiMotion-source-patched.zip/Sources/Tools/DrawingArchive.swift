// DrawingArchive.swift — the `.saikidrawing` single-file bundle for Drawing Editor artworks.
//
//   "SAIKIDRW1\n"                      10-byte magic
//   u32  json length (LE)              JSON-encoded DrawItem
//   u32  file count
//   per file: u16 name length, name (UTF-8, e.g. "<layerId>.png"), u64 data length, data
//
// Layer PNGs are keyed by layer id, so import only has to remap ids.

import Foundation

enum DrawingArchive {
    static let fileExtension = "saikidrawing"
    private static let magic = Array("SAIKIDRW1\n".utf8)

    private static func le(_ v: UInt64, _ n: Int) -> Data { Data((0..<n).map { UInt8((v >> (8 * UInt64($0))) & 0xFF) }) }
    private static func rd(_ fh: FileHandle, _ n: Int) -> Data? {
        if n == 0 { return Data() }
        guard let d = try? fh.read(upToCount: n), d.count == n else { return nil }
        return d
    }
    private static func num(_ d: Data) -> UInt64 {
        var v: UInt64 = 0
        for (i, b) in d.enumerated() { v |= UInt64(b) << (8 * UInt64(i)) }
        return v
    }

    static func isArchive(_ url: URL) -> Bool {
        guard let fh = try? FileHandle(forReadingFrom: url) else { return false }
        defer { try? fh.close() }
        return (try? fh.read(upToCount: magic.count)).map { Array($0) == magic } ?? false
    }

    /// Writes "<name>.saikidrawing" into the temp folder. Returns nil on failure.
    static func export(_ id: String) -> URL? {
        guard let item = DrawStore.item(id), !item.isFolder,
              let json = try? JSONEncoder().encode(item) else { return nil }
        let safe = item.name.replacingOccurrences(of: "/", with: "-")
        let out = FileManager.default.temporaryDirectory.appendingPathComponent("\(safe).\(fileExtension)")
        try? FileManager.default.removeItem(at: out)
        guard FileManager.default.createFile(atPath: out.path, contents: nil),
              let fh = try? FileHandle(forWritingTo: out) else { return nil }
        defer { try? fh.close() }

        var files: [(String, URL)] = []
        for l in item.layers where !l.isFolder {
            let u = DrawStore.layerURL(id, l.id)
            if FileManager.default.fileExists(atPath: u.path) { files.append((l.id + ".png", u)) }
        }
        let t = DrawStore.thumbURL(id)
        if FileManager.default.fileExists(atPath: t.path) { files.append(("thumb.png", t)) }

        fh.write(Data(magic))
        fh.write(le(UInt64(json.count), 4)); fh.write(json)
        fh.write(le(UInt64(files.count), 4))
        for (name, url) in files {
            guard let data = try? Data(contentsOf: url, options: .mappedIfSafe) else { continue }
            let nb = Data(name.utf8)
            fh.write(le(UInt64(nb.count), 2)); fh.write(nb)
            fh.write(le(UInt64(data.count), 8)); fh.write(data)
        }
        return out
    }

    /// Imports a .saikidrawing as a new artwork (fresh ids) into `parent`.
    @discardableResult
    static func import(_ url: URL, parent: String?) -> DrawItem? {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        guard let fh = try? FileHandle(forReadingFrom: url) else { return nil }
        defer { try? fh.close() }
        guard let head = rd(fh, magic.count), Array(head) == magic,
              let jl = rd(fh, 4), let json = rd(fh, Int(num(jl))),
              var item = try? JSONDecoder().decode(DrawItem.self, from: json),
              let cnt = rd(fh, 4) else { return nil }

        var blobs: [String: Data] = [:]
        for _ in 0..<Int(num(cnt)) {
            guard let nl = rd(fh, 2), let nb = rd(fh, Int(num(nl))), let name = String(data: nb, encoding: .utf8),
                  let dl = rd(fh, 8), let data = rd(fh, Int(num(dl))) else { break }
            blobs[name] = data
        }

        let newId = UUID().uuidString
        var idMap: [String: String] = [:]
        for l in item.layers { idMap[l.id] = UUID().uuidString }
        for i in 0..<item.layers.count {
            let old = item.layers[i].id
            item.layers[i].id = idMap[old]!
            if let p = item.layers[i].parent { item.layers[i].parent = idMap[p] }
            if let d = blobs[old + ".png"] {
                try? d.write(to: DrawStore.layerURL(newId, item.layers[i].id), options: .atomic)
            }
        }
        if let a = item.activeLayer { item.activeLayer = idMap[a] }
        if let d = blobs["thumb.png"] { try? d.write(to: DrawStore.thumbURL(newId), options: .atomic) }
        item.id = newId
        item.parent = parent
        item.updated = Date()
        DrawStore.upsert(item)
        return item
    }
}
