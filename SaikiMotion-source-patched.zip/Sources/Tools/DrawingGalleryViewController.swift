// DrawingGalleryViewController.swift — "My Gallery" of the Drawing Editor.
// Grid of artworks and folders. Long-press an item for: Open, Rename, Add folder, Move,
// Duplicate, Send to video editor, Delete. "+" creates a canvas (preset sizes or custom),
// Import brings a picture in as a new artwork, Select does bulk delete / move.

import UIKit
import PhotosUI
import UniformTypeIdentifiers

private final class GalleryCell: UICollectionViewCell {
    let img = UIImageView()
    let name = UILabel()
    let sub = UILabel()
    let check = UILabel()

    override init(frame: CGRect) {
        super.init(frame: frame)
        img.contentMode = .scaleAspectFit
        img.backgroundColor = argbToUIColor(C.CARD)
        img.layer.cornerRadius = 12; img.clipsToBounds = true
        img.layer.borderWidth = 1; img.layer.borderColor = argbToUIColor(C.LINE).cgColor
        name.font = .systemFont(ofSize: 13, weight: .semibold); name.textColor = argbToUIColor(C.TEXT)
        name.textAlignment = .center
        sub.font = .systemFont(ofSize: 11); sub.textColor = argbToUIColor(C.DIM); sub.textAlignment = .center
        check.textAlignment = .center; check.font = .boldSystemFont(ofSize: 14)
        check.layer.cornerRadius = 12; check.clipsToBounds = true; check.isHidden = true
        check.text = "✓"; check.textColor = argbToUIColor(C.ONDARK); check.backgroundColor = argbToUIColor(C.GREEN)
        [img, name, sub, check].forEach { contentView.addSubview($0) }
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    override func layoutSubviews() {
        super.layoutSubviews()
        let w = contentView.bounds.width
        img.frame = CGRect(x: 0, y: 0, width: w, height: w)
        name.frame = CGRect(x: 0, y: w + 6, width: w, height: 18)
        sub.frame = CGRect(x: 0, y: w + 24, width: w, height: 15)
        check.frame = CGRect(x: w - 30, y: 6, width: 24, height: 24)
    }
}

final class DrawingGalleryViewController: UIViewController, UIDocumentPickerDelegate, UICollectionViewDataSource,
                                          UICollectionViewDelegateFlowLayout, PHPickerViewControllerDelegate {
    private let folderId: String?
    private var items: [DrawItem] = []
    private var selecting = false
    private var selected = Set<String>()
    private var collection: UICollectionView!
    private let titleLabel = UILabel()
    private let empty = UILabel()
    private let header = UIView(), toolbar = UIView()
    private let selectBtn = DrawBtn(title: "Select")
    private let backBtn = DrawBtn(icon: "back")
    private var barButtons: [DrawBtn] = []
    private var thumbCache: [String: UIImage] = [:]

    init(folderId: String? = nil) {
        self.folderId = folderId
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = argbToUIColor(C.BG)
        CrashLog.note("drawing_gallery")

        header.backgroundColor = argbToUIColor(C.PANEL)
        toolbar.backgroundColor = argbToUIColor(C.PANEL)
        let lay = UICollectionViewFlowLayout()
        lay.minimumInteritemSpacing = 12; lay.minimumLineSpacing = 14
        lay.sectionInset = UIEdgeInsets(top: 16, left: 16, bottom: 24, right: 16)
        collection = UICollectionView(frame: .zero, collectionViewLayout: lay)
        collection.backgroundColor = .clear
        collection.dataSource = self; collection.delegate = self
        collection.register(GalleryCell.self, forCellWithReuseIdentifier: "c")
        collection.alwaysBounceVertical = true
        view.addSubview(collection)
        view.addSubview(header); view.addSubview(toolbar)

        titleLabel.font = .boldSystemFont(ofSize: 18); titleLabel.textColor = argbToUIColor(C.TEXT)
        titleLabel.textAlignment = .center
        header.addSubview(titleLabel)
        backBtn.onClick = { [weak self] in self?.navigationController?.popViewController(animated: true) }
        selectBtn.tint = C.GREEN
        selectBtn.onClick = { [weak self] in self?.toggleSelect() }
        header.addSubview(backBtn); header.addSubview(selectBtn)

        empty.text = "There is no artwork.\nPress ‘+’ to create a new artwork."
        empty.numberOfLines = 0; empty.textAlignment = .center
        empty.font = .systemFont(ofSize: 16); empty.textColor = argbToUIColor(C.DIM)
        view.addSubview(empty)
        buildToolbar()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
        reload()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let w = view.bounds.width, sa = view.safeAreaInsets
        header.frame = CGRect(x: 0, y: 0, width: w, height: 52 + sa.top)
        backBtn.frame = CGRect(x: 6, y: sa.top + 4, width: 44, height: 44)
        selectBtn.frame = CGRect(x: w - 90, y: sa.top + 4, width: 84, height: 44)
        titleLabel.frame = CGRect(x: 60, y: sa.top + 4, width: w - 150, height: 44)
        let tb: CGFloat = 58 + max(sa.bottom, 6)
        toolbar.frame = CGRect(x: 0, y: view.bounds.height - tb, width: w, height: tb)
        collection.frame = CGRect(x: 0, y: header.frame.maxY, width: w, height: toolbar.frame.minY - header.frame.maxY)
        empty.frame = CGRect(x: 20, y: view.bounds.midY - 50, width: w - 40, height: 80)
        let n = CGFloat(barButtons.count)
        for (i, b) in barButtons.enumerated() { b.frame = CGRect(x: CGFloat(i) * w / n, y: 2, width: w / n, height: 54) }
        collection.collectionViewLayout.invalidateLayout()
    }

    // MARK: data

    private func reload() {
        items = DrawStore.items(in: folderId)
        let parent = folderId.flatMap { DrawStore.item($0) }
        titleLabel.text = parent.map { $0.name } ?? "My Gallery (\(DrawStore.totalArtworks()))"
        backBtn.isHidden = false
        empty.isHidden = !items.isEmpty
        selectBtn.title = selecting ? "Done" : "Select"
        buildToolbar()
        collection.reloadData()
    }

    private func buildToolbar() {
        barButtons.forEach { $0.removeFromSuperview() }
        barButtons = []
        var defs: [(String, String, () -> Void)]
        if selecting {
            defs = [("trash", "Delete", { [weak self] in self?.deleteSelected() }),
                    ("box", "Move", { [weak self] in self?.moveSelected() }),
                    ("dup", "Duplicate", { [weak self] in self?.duplicateSelected() })]
        } else {
            defs = [("plus", "New", { [weak self] in self?.newSheet() }),
                    ("box", "Folder", { [weak self] in self?.newFolder() }),
                    ("import", "Import", { [weak self] in self?.importPicture() })]
        }
        for d in defs {
            let b = DrawBtn(icon: d.0, title: d.1, d.2)
            if d.1 == "Delete" { b.tint = C.RED }
            if d.1 == "New" { b.tint = C.GREEN }
            toolbar.addSubview(b); barButtons.append(b)
        }
        view.setNeedsLayout()
    }

    // MARK: collection

    func collectionView(_ cv: UICollectionView, numberOfItemsInSection s: Int) -> Int { items.count }

    func collectionView(_ cv: UICollectionView, layout l: UICollectionViewLayout, sizeForItemAt ip: IndexPath) -> CGSize {
        let cols: CGFloat = view.bounds.width > 600 ? 5 : 3
        let w = floor((cv.bounds.width - 32 - 12 * (cols - 1)) / cols)
        return CGSize(width: w, height: w + 44)
    }

    func collectionView(_ cv: UICollectionView, cellForItemAt ip: IndexPath) -> UICollectionViewCell {
        let cell = cv.dequeueReusableCell(withReuseIdentifier: "c", for: ip) as! GalleryCell
        let it = items[ip.item]
        cell.name.text = it.name
        cell.check.isHidden = !(selecting && selected.contains(it.id))
        cell.img.layer.borderColor = argbToUIColor(selected.contains(it.id) && selecting ? C.GREEN : C.LINE).cgColor
        cell.img.layer.borderWidth = selected.contains(it.id) && selecting ? 3 : 1
        if it.isFolder {
            let n = DrawStore.count(in: it.id)
            cell.sub.text = "\(n) item\(n == 1 ? "" : "s")"
            cell.img.image = nil
            cell.img.backgroundColor = argbToUIColor(C.GREEN).withAlphaComponent(0.22)
            let cfg = UIImage.SymbolConfiguration(pointSize: 44, weight: .regular)
            cell.img.image = UIImage(systemName: "folder.fill", withConfiguration: cfg)?
                .withTintColor(argbToUIColor(C.GREEN), renderingMode: .alwaysOriginal)
            cell.img.contentMode = .center
        } else {
            cell.sub.text = "\(it.w) × \(it.h)"
            cell.img.backgroundColor = argbToUIColor(C.CARD)
            cell.img.contentMode = .scaleAspectFit
            cell.img.image = thumb(it)
        }
        return cell
    }

    private func thumb(_ it: DrawItem) -> UIImage? {
        let key = it.id + "\(it.updated.timeIntervalSince1970)"
        if let t = thumbCache[key] { return t }
        let t = UIImage(contentsOfFile: DrawStore.thumbURL(it.id).path)
        if let t = t { thumbCache[key] = t }
        return t
    }

    func collectionView(_ cv: UICollectionView, didSelectItemAt ip: IndexPath) {
        let it = items[ip.item]
        if selecting {
            if selected.contains(it.id) { selected.remove(it.id) } else { selected.insert(it.id) }
            cv.reloadItems(at: [ip]); return
        }
        open(it)
    }

    func collectionView(_ cv: UICollectionView, contextMenuConfigurationForItemAt ip: IndexPath, point: CGPoint) -> UIContextMenuConfiguration? {
        guard !selecting else { return nil }
        let it = items[ip.item]
        return UIContextMenuConfiguration(identifier: nil, previewProvider: nil) { [weak self] _ in
            guard let s = self else { return nil }
            var a: [UIAction] = [UIAction(title: "Open", image: UIImage(systemName: "folder")) { _ in s.open(it) }]
            a.append(UIAction(title: "Rename", image: UIImage(systemName: "pencil")) { _ in s.rename(it) })
            a.append(UIAction(title: "Add folder", image: UIImage(systemName: "folder.badge.plus")) { _ in
                s.promptText("New folder", "Folder") { n in
                    DrawStore.makeFolder(n, parent: it.isFolder ? it.id : s.folderId); s.reload()
                }
            })
            a.append(UIAction(title: "Move to…", image: UIImage(systemName: "arrow.right.circle")) { _ in s.pickFolder([it.id]) })
            if !it.isFolder {
                a.append(UIAction(title: "Duplicate", image: UIImage(systemName: "plus.square.on.square")) { _ in
                    DrawStore.duplicate(it.id); s.reload()
                })
                a.append(UIAction(title: "Save as .saikidrawing", image: UIImage(systemName: "square.and.arrow.down")) { _ in
                    guard let u = DrawingArchive.export(it.id) else { Toast.show("Export failed"); return }
                    let v = UIActivityViewController(activityItems: [u], applicationActivities: nil)
                    v.popoverPresentationController?.sourceView = s.view
                    s.present(v, animated: true)
                })
                a.append(UIAction(title: "Send to video editor", image: UIImage(systemName: "square.and.arrow.up")) { _ in s.sendToEditor(it) })
            }
            a.append(UIAction(title: "Delete", image: UIImage(systemName: "trash"), attributes: .destructive) { _ in s.confirmDelete([it.id]) })
            return UIMenu(title: it.name, children: a)
        }
    }

    // MARK: actions

    func open(_ it: DrawItem) {
        if it.isFolder { navigationController?.pushViewController(DrawingGalleryViewController(folderId: it.id), animated: true) }
        else { navigationController?.pushViewController(DrawingEditorViewController(item: it), animated: true) }
    }

    private func toggleSelect() {
        selecting.toggle(); selected.removeAll(); reload()
    }

    private func promptText(_ title: String, _ text: String, _ done: @escaping (String) -> Void) {
        let a = UIAlertController(title: title, message: nil, preferredStyle: .alert)
        a.addTextField { $0.text = text; $0.clearButtonMode = .whileEditing }
        a.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in
            let t = a.textFields?.first?.text?.trimmingCharacters(in: .whitespaces) ?? ""
            if !t.isEmpty { done(t) }
        })
        present(a, animated: true)
    }

    private func rename(_ it: DrawItem) { promptText("Rename", it.name) { [weak self] in DrawStore.rename(it.id, $0); self?.reload() } }
    private func newFolder() { promptText("New folder", "Folder") { [weak self] in DrawStore.makeFolder($0, parent: self?.folderId); self?.reload() } }

    private func confirmDelete(_ ids: [String]) {
        let a = UIAlertController(title: "Delete \(ids.count) item\(ids.count == 1 ? "" : "s")?",
                                  message: "Folders are deleted with everything inside. This can’t be undone.", preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        a.addAction(UIAlertAction(title: "Delete", style: .destructive) { [weak self] _ in
            ids.forEach { DrawStore.delete($0) }
            self?.selected.removeAll(); self?.reload()
        })
        present(a, animated: true)
    }
    private func deleteSelected() { if selected.isEmpty { Toast.show("Nothing selected") } else { confirmDelete(Array(selected)) } }
    private func moveSelected() { if selected.isEmpty { Toast.show("Nothing selected") } else { pickFolder(Array(selected)) } }
    private func duplicateSelected() {
        for id in selected { DrawStore.duplicate(id) }
        selected.removeAll(); reload()
    }

    private func pickFolder(_ ids: [String]) {
        let s = UIAlertController(title: "Move to", message: nil, preferredStyle: .actionSheet)
        s.addAction(UIAlertAction(title: "My Gallery", style: .default) { [weak self] _ in
            ids.forEach { DrawStore.move($0, to: nil) }; self?.selected.removeAll(); self?.reload()
        })
        for f in DrawStore.all().filter({ $0.isFolder && !ids.contains($0.id) }) {
            let path = DrawStore.path(of: f.id).map { $0.name }.joined(separator: " / ")
            s.addAction(UIAlertAction(title: path, style: .default) { [weak self] _ in
                ids.forEach { DrawStore.move($0, to: f.id) }; self?.selected.removeAll(); self?.reload()
            })
        }
        s.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        s.popoverPresentationController?.sourceView = toolbar
        s.popoverPresentationController?.sourceRect = toolbar.bounds
        present(s, animated: true)
    }

    private func sendToEditor(_ it: DrawItem) {
        Toast.show("Creating project…")
        DrawExport.toProject(it) { [weak self] id in
            guard let id = id else { Toast.show("Export failed"); return }
            Toast.show("Project created")
            self?.navigationController?.pushViewController(EditorViewController(projectId: id), animated: true)
        }
    }

    // MARK: new canvas

    private func newSheet() {
        let s = UIAlertController(title: "New", message: nil, preferredStyle: .actionSheet)
        s.addAction(UIAlertAction(title: "Custom…", style: .default) { [weak self] _ in self?.customSize() })
        for p in DrawPresets.list {
            s.addAction(UIAlertAction(title: "\(p.0)   \(p.1) × \(p.2)", style: .default) { [weak self] _ in
                self?.create(p.1, p.2, name: p.0)
            })
        }
        s.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        s.popoverPresentationController?.sourceView = toolbar
        s.popoverPresentationController?.sourceRect = toolbar.bounds
        present(s, animated: true)
    }

    private func customSize() {
        let a = UIAlertController(title: "Custom canvas", message: "Max \(DrawPresets.maxSide) px per side", preferredStyle: .alert)
        a.addTextField { $0.placeholder = "Width"; $0.text = "2000"; $0.keyboardType = .numberPad }
        a.addTextField { $0.placeholder = "Height"; $0.text = "2000"; $0.keyboardType = .numberPad }
        a.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        a.addAction(UIAlertAction(title: "Create", style: .default) { [weak self] _ in
            let w = Int(a.textFields?[0].text ?? "") ?? 0, h = Int(a.textFields?[1].text ?? "") ?? 0
            self?.create(w, h, name: "Illustration")
        })
        present(a, animated: true)
    }

    private func create(_ w: Int, _ h: Int, name: String) {
        guard DrawPresets.valid(w, h) else {
            Toast.show("Size not supported (max \(DrawPresets.maxSide) px, ~\(DrawPresets.maxPixels / 1_000_000) MP)"); return
        }
        let it = DrawStore.newArtwork(name: "\(name) \(DrawStore.totalArtworks() + 1)", w: w, h: h, parent: folderId)
        navigationController?.pushViewController(DrawingEditorViewController(item: it), animated: true)
    }

    private func importPicture() {
        let sh = UIAlertController(title: "Import", message: nil, preferredStyle: .actionSheet)
        sh.addAction(UIAlertAction(title: "Picture from Photos", style: .default) { [weak self] _ in self?.importFromPhotos() })
        sh.addAction(UIAlertAction(title: "Drawing file (.saikidrawing)", style: .default) { [weak self] _ in
            guard let self = self else { return }
            let dp = UIDocumentPickerViewController(forOpeningContentTypes: [.data], asCopy: true)
            dp.delegate = self
            self.present(dp, animated: true)
        })
        sh.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        sh.popoverPresentationController?.sourceView = view
        sh.popoverPresentationController?.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.maxY - 40, width: 1, height: 1)
        present(sh, animated: true)
    }

    private func importFromPhotos() {
        var cfg = PHPickerConfiguration(); cfg.filter = .images; cfg.selectionLimit = 1
        let p = PHPickerViewController(configuration: cfg); p.delegate = self
        present(p, animated: true)
    }

    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        picker.dismiss(animated: true)
        guard let prov = results.first?.itemProvider, prov.canLoadObject(ofClass: UIImage.self) else { return }
        prov.loadObject(ofClass: UIImage.self) { [weak self] obj, _ in
            guard let img = obj as? UIImage else { return }
            DispatchQueue.main.async {
                guard let self = self else { return }
                guard let it = DrawImport.fromImage(img, name: "Picture \(DrawStore.totalArtworks() + 1)", parent: self.folderId) else {
                    Toast.show("Couldn’t import that picture"); return
                }
                self.navigationController?.pushViewController(DrawingEditorViewController(item: it), animated: true)
            }
        }
    }

    func documentPicker(_ c: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        var n = 0
        for u in urls where DrawingArchive.isArchive(u) { if DrawingArchive.import(u, parent: folderId) != nil { n += 1 } }
        Toast.show(n > 0 ? "Imported \(n) drawing\(n == 1 ? "" : "s")" : "Not a .saikidrawing file")
        reload()
    }
}
