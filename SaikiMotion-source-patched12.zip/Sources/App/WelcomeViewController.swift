// WelcomeViewController.swift — the launch "What's New" card.

import UIKit

// MARK: - What's New ---------------------------------------------------------------------

/// The original's launch card, rebuilt 1:1 from the shipped binary's
/// WelcomeViewController.viewDidLoad: black full-screen, scrollable stack
/// with the splash art at top, the kerned "SAIKI MOTION" wordmark, a big
/// "Welcome", the bordered disclaimer card (NOT A MOD / paragraph /
/// Developers / TikTok credits), the "What's New" changelog list and the
/// two-button row. Shown on every launch until "Don't show again".
final class WelcomeViewController: UIViewController {

    /// The changelog: this version's changes first, then the original's
    /// shipped UPDATES list (kept verbatim below the divider entry).
    static let UPDATES: [String] = [
        "Optical Flare rays rebuilt: smooth tapered beams instead of hard jagged wedges, plus a Rays / spikes strength slider in Global (set it to 0 for no rays at all)",
        "Flare spin is now gentle (it was ~5x too sensitive) and 'turn with the flare axis' no longer snaps when the light crosses the centre",
        "Flares always render as light (add or screen), so they can't be hidden by the layer's blend mode",
        "Video export now renders on the GL thread that owns the context — fixes exports coming out empty",
        "Deep Glow rebuilt: it no longer blows soft glows and flares out to a hard white wedge. New controls — Exposure, Threshold + softness, Falloff, Tint, Chromatic aberration and Glow only — with a soft film shoulder instead of flat clipping",
        "Optical Flare editor: Apply and the title are back on screen (the top bar was being stretched off the right edge), and the preview no longer cuts out",
        "Flares no longer disappear while the light is still on screen — they only fade once the light is well outside the frame",
        "New Multi iris element: a chain of ghost irises with per-ghost rainbow tint, size variation and spacing — all 16 flare presets reworked to cinematic grade, plus Golden Hour, Teal and Orange, Blockbuster Hero, Vintage Anamorphic, Deep Space and Cine Multi Iris",
        "Add element is now a thumbnail browser; the iris browser is grouped (Polygons, Cinematic, Hollow, Stars, Crystal) with 30 procedural irises; recolor one element, or every element at once, from Edit / Global",
        "Green editor theme — every accent (buttons, playhead, chips, keyframes, selection) is now the bright green editor green, matching the reference",
        "Timeline rebuilt Alight-Motion style: rounded pill clips colored per layer type, waveforms on audio, trim grips, a slim playhead that never covers the ruler, and pinch to zoom",
        "Fixed video import failing from the photo library (the copy now happens while the picked file still exists) and video/audio duration no longer freezes the editor",
        "Scene Setup is back: rename the project, change canvas + frame rate, duration, FOV, background, scenes — plus Scene Setup mode, an orbit editing camera that never touches your camera layers",
        "New render screen: spinning green progress ring, shimmering bar, frames counter and ETA while exporting",
        "Graph editor restyled like the reference: white curve, green handles and presets; transport row regrouped so play/pause can never overlap; ruler labels no longer hide under the playhead",
        "Thinking chibi greets you when there are no projects, and the writing chibi holds the AI tab while AI Suggest is in development",
        "Import OpenVDB volumes (.vdb) directly from the Media panel; source split into per-feature files for easier debugging",
        "————————————————",
        "Refreshed editor UI: properly sized icons everywhere (they were oversized and stretched), a compact top bar that fits iPhone 12 mini, and a slimmer playhead",
        "Timeline polish: per-layer type icons, a proper reorder gutter, softer selection highlights and brighter ruler labels",
        "Environment editor: import 3D models and volumes, or create a realistic water plane, all from one clean screen",
        "Water simulator: Gerstner waves, foam, refraction, fresnel and sun glitter — 35 keyframable parameters",
        "Cycles render engine (Project Settings): physically based shading, soft sun shadows and filmic tonemapping for 3D scenes; 2D layers are ignored while it is on",
        ".vdb volume import (OpenVDB smoke and fire) and PBR map import for models",
        "Optical Flare: 25 element types and 20 built-in presets, and the flare library now always shows its thumbnails",
        "Expressions moved to the command (⌘) icon: tap a parameter, tap ⌘, and the parameter outline turns red while the expression drives it",
        "Scene Setup mode (top bar): orbit the 3D scene with an editing camera that never touches the active camera",
        "Faster effect browser, smoother graph editor, true gaussian Blur, deeper Deep Glow, and the keyboard no longer covers dialogs",
    ]

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = argbToUIColor(Int32(bitPattern: 0xFF000000))
        isModalInPresentation = true

        // scroll + content stack (fills width, vertical, zero spacing)
        let scroll = UIScrollView()
        scroll.alwaysBounceVertical = true
        scroll.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scroll)

        let stack = UIStackView()
        stack.axis = .vertical
        stack.alignment = .fill
        stack.spacing = 0
        stack.isLayoutMarginsRelativeArrangement = true
        stack.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 28, leading: 22, bottom: 24, trailing: 22)
        stack.translatesAutoresizingMaskIntoConstraints = false
        scroll.addSubview(stack)
        NSLayoutConstraint.activate([
            scroll.topAnchor.constraint(equalTo: view.topAnchor),
            scroll.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            scroll.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scroll.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            stack.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor),
            stack.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor),
            stack.leadingAnchor.constraint(equalTo: scroll.contentLayoutGuide.leadingAnchor),
            stack.trailingAnchor.constraint(equalTo: scroll.contentLayoutGuide.trailingAnchor),
            stack.widthAnchor.constraint(equalTo: scroll.frameLayoutGuide.widthAnchor),
        ])

        // 1 - splash art (bundle image, file fallback — same as the original)
        let artImage = UIImage(named: "splash_chibi")
            ?? Bundle.main.url(forResource: "splash_chibi", withExtension: "png")
                .flatMap { UIImage(contentsOfFile: $0.path) }
        let art = UIImageView(image: artImage)
        art.contentMode = .scaleAspectFit
        stack.addArrangedSubview(art)
        art.heightAnchor.constraint(equalToConstant: 288).isActive = true

        // 2 - kerned wordmark
        let mark = UILabel()
        mark.attributedText = kerned("SAIKI MOTION", 14, C.GREEN, 0.3)
        mark.textAlignment = .center
        stack.addArrangedSubview(pad(mark, 14, 0, 0, 0))

        // 3 - Welcome
        let welcome = UILabel()
        welcome.text = "Welcome"
        welcome.textColor = argbToUIColor(Int32(bitPattern: 0xFFF2F2F2))
        welcome.font = .boldSystemFont(ofSize: 32)
        welcome.textAlignment = .center
        stack.addArrangedSubview(pad(welcome, 4, 0, 18, 0))

        // 4 - disclaimer card
        let card = UIView()
        card.backgroundColor = argbToUIColor(Int32(bitPattern: 0xFF1C2121))
        card.layer.cornerRadius = 20
        card.layer.borderWidth = 1
        card.layer.borderColor = argbToUIColor(Int32(bitPattern: 0xFF2A2A30)).cgColor
        let inner = UIStackView()
        inner.axis = .vertical
        inner.spacing = 0
        inner.isLayoutMarginsRelativeArrangement = true
        inner.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 16, leading: 18, bottom: 16, trailing: 18)
        inner.translatesAutoresizingMaskIntoConstraints = false
        card.addSubview(inner)
        NSLayoutConstraint.activate([
            inner.topAnchor.constraint(equalTo: card.topAnchor),
            inner.bottomAnchor.constraint(equalTo: card.bottomAnchor),
            inner.leadingAnchor.constraint(equalTo: card.leadingAnchor),
            inner.trailingAnchor.constraint(equalTo: card.trailingAnchor),
        ])

        let notMod = UILabel()
        notMod.text = "THIS APP IS NOT A MOD OF KEYFLOW."
        notMod.textColor = argbToUIColor(C.GREEN)
        notMod.font = .boldSystemFont(ofSize: 16)
        notMod.numberOfLines = 0
        inner.addArrangedSubview(notMod)

        let disclaimer = UILabel()
        disclaimer.attributedText = lineSpaced(
            "Saiki Motion is an independent app. We built it with a similar interface and feature set to Keyflow by Angkin, and it is free for all users. We are currently in development and we are excited for the future of Saiki Motion.",
            14, 1.2, Int32(bitPattern: 0xFFFFFFFF))
        disclaimer.numberOfLines = 0
        inner.addArrangedSubview(pad(disclaimer, 10, 0, 14, 0))

        let devs = UILabel()
        devs.text = "Developers"
        devs.textColor = argbToUIColor(Int32(bitPattern: 0xFF8C8C96))
        devs.font = .boldSystemFont(ofSize: 12)
        inner.addArrangedSubview(devs)

        let tiktok = UILabel()
        tiktok.text = "TikTok  @quintsuxf\nTikTok  @naviya903"
        tiktok.textColor = argbToUIColor(Int32(bitPattern: 0xFFFFFFFF))
        tiktok.font = .systemFont(ofSize: 15)
        tiktok.numberOfLines = 0
        inner.addArrangedSubview(pad(tiktok, 4, 0, 0, 0))

        stack.addArrangedSubview(card)

        // 5 - What's New header
        let header = UILabel()
        header.text = "What's New"
        header.textColor = argbToUIColor(C.GREEN)
        header.font = .boldSystemFont(ofSize: 13)
        stack.addArrangedSubview(pad(header, 22, 4, 0, 6))

        // 6 - changelog lines
        for u in WelcomeViewController.UPDATES {
            let line = UILabel()
            line.text = "\u{2022}  " + u
            line.textColor = argbToUIColor(Int32(bitPattern: 0xFFFFFFFF))
            line.font = .systemFont(ofSize: 14)
            line.numberOfLines = 0
            stack.addArrangedSubview(pad(line, 3, 4, 3, 4))
        }

        // 7 - button row
        let row = UIStackView()
        row.axis = .horizontal
        row.alignment = .fill
        row.distribution = .fillEqually
        row.spacing = 8

        let never = PillButton("Don't show again", nil, C.CARD2, Int32(bitPattern: 0xFFFFFFFF))
        never.onClick = { [weak self] in
            UserDefaults.standard.set(true, forKey: "hideWelcome")
            self?.dismiss(animated: true)
        }
        row.addArrangedSubview(never)
        never.heightAnchor.constraint(equalToConstant: 50).isActive = true

        let close = PillButton("Close", nil, C.GREEN, C.ONDARK)
        close.onClick = { [weak self] in
            self?.dismiss(animated: true)
        }
        row.addArrangedSubview(close)
        close.heightAnchor.constraint(equalToConstant: 50).isActive = true

        stack.addArrangedSubview(pad(row, 26, 0, 0, 0))
    }

    /// Letter-spaced bold label text (the wordmark).
    private func kerned(_ s: String, _ size: CGFloat, _ color: Int32, _ spacing: CGFloat) -> NSAttributedString {
        NSAttributedString(string: s, attributes: [
            .kern: spacing,
            .font: UIFont.boldSystemFont(ofSize: size),
            .foregroundColor: argbToUIColor(color),
        ])
    }

    /// Line-height-multiplied paragraph (the disclaimer card's body).
    private func lineSpaced(_ s: String, _ size: CGFloat, _ line: CGFloat, _ color: Int32) -> NSAttributedString {
        let p = NSMutableParagraphStyle()
        p.minimumLineHeight = size * line
        return NSAttributedString(string: s, attributes: [
            .paragraphStyle: p,
            .font: UIFont.systemFont(ofSize: size),
            .foregroundColor: argbToUIColor(color),
        ])
    }

    /// Wraps a view with directional insets so the stack stays zero-spacing.
    private func pad(_ v: UIView, _ t: CGFloat, _ l: CGFloat, _ b: CGFloat, _ r: CGFloat) -> UIView {
        let wrap = UIView()
        wrap.translatesAutoresizingMaskIntoConstraints = false
        v.translatesAutoresizingMaskIntoConstraints = false
        wrap.addSubview(v)
        NSLayoutConstraint.activate([
            v.topAnchor.constraint(equalTo: wrap.topAnchor, constant: t),
            v.bottomAnchor.constraint(equalTo: wrap.bottomAnchor, constant: -b),
            v.leadingAnchor.constraint(equalTo: wrap.leadingAnchor, constant: l),
            v.trailingAnchor.constraint(equalTo: wrap.trailingAnchor, constant: -r),
        ])
        return wrap
    }
}
