// Flare.swift — optical flares (Model).
//
// A Flare is a stack of elements placed along the flare axis: position 0 is
// the light itself, 1 the screen centre, 2 the opposite side. Elements are
// glows, glints, hoops, streaks, spike balls, rainbows, shimmers and fully
// procedural irises — the Optical-Flares kit. The shader (SceneRenderer)
// moves, rotates, scales and fades them from the light's real position, so
// a flare behaves like a lens flare, in 2D and through the 3D camera.

import UIKit

// MARK: - Iris (procedural aperture shape)

/// A procedural iris: a polygon / star / flower described by a handful of knobs.
/// The same maths runs in the flare shader and in `radius(at:)` for the browser.
struct IrisDef {
    var name = "Iris"
    var sides = 6
    var round: Float = 0       // 0 = sharp corners, 1 = circle
    var star: Float = 0        // 0 = polygon, 1 = needle star
    var curve: Float = 0       // + bulging edges, - scalloped edges
    var thick: Float = 1       // 1 = filled, less = hollow outline
    var soft: Float = 0.15
    var grad: Float = 0.3      // brighter toward the edge
    var chroma: Float = 0
    var cat = "Polygons"

    /// Radius (vertex = 1) of the shape at angle `a` (radians, 0 = up). Mirrors irisR() in GLSL.
    func radius(at a: Float) -> Float {
        let n = Float(max(3, sides))
        let seg = 2 * Float.pi / n
        var t = fmodf(a, seg); if t < 0 { t += seg }
        let hs = seg * 0.5
        let phi = abs(t - hs)
        let cosH = cos(hs), sinH = sin(hs)
        let inner = cosH + (0.12 - cosH) * star
        let den = cos(phi) * sinH - sin(phi) * (cosH - inner)
        var r = inner * sinH / max(den, 0.0001)
        let u = phi / hs
        r *= 1 + curve * 0.25 * (1 - u * u)
        let rc = (inner + 1) * 0.5
        return r + (rc - r) * round
    }

    func apply(to e: FlareEl) {
        e.sides = sides; e.round = round; e.star = star; e.curve = curve
        e.thick = thick; e.soft = soft; e.grad = grad; e.chroma = chroma
    }

    init() {}
    init(_ e: FlareEl) {
        name = "Iris"; sides = e.sides; round = e.round; star = e.star; curve = e.curve
        thick = e.thick; soft = e.soft; grad = e.grad; chroma = e.chroma
    }
    init(_ n: String, _ s: Int, round: Float = 0, star: Float = 0, curve: Float = 0,
         thick: Float = 1, soft: Float = 0.15, grad: Float = 0.3, chroma: Float = 0) {
        name = n; sides = s; self.round = round; self.star = star; self.curve = curve
        self.thick = thick; self.soft = soft; self.grad = grad; self.chroma = chroma
    }

    func toJson() -> JObj {
        JObj().put("name", name).put("sides", Int64(sides)).put("round", Double(round))
            .put("star", Double(star)).put("curve", Double(curve)).put("thick", Double(thick))
            .put("soft", Double(soft)).put("grad", Double(grad)).put("chroma", Double(chroma))
    }

    static func fromJson(_ o: JObj) -> IrisDef {
        IrisDef(o.optString("name", "Iris"), o.optInt("sides", 6), round: o.optFloat("round"),
                star: o.optFloat("star"), curve: o.optFloat("curve"), thick: o.optFloat("thick", 1),
                soft: o.optFloat("soft", 0.15), grad: o.optFloat("grad", 0.3), chroma: o.optFloat("chroma"))
    }

    static func builtin() -> [IrisDef] {
        func c(_ cat: String, _ d: IrisDef) -> IrisDef { var x = d; x.cat = cat; return x }
        return [
            c("Polygons", IrisDef("Triangle", 3, soft: 0.1)),
            c("Polygons", IrisDef("Square", 4, soft: 0.1)),
            c("Polygons", IrisDef("Pentagon", 5, soft: 0.12)),
            c("Polygons", IrisDef("Hexagon", 6)),
            c("Polygons", IrisDef("Heptagon", 7, soft: 0.12)),
            c("Polygons", IrisDef("Octagon", 8)),
            c("Polygons", IrisDef("Circle", 8, round: 1, soft: 0.08)),
            c("Cinematic", IrisDef("Soft hex", 6, round: 0.55, soft: 0.3, grad: 0.5)),
            c("Cinematic", IrisDef("Camera 7", 7, round: 0.15, curve: 0.9, soft: 0.1, grad: 0.5)),
            c("Cinematic", IrisDef("Aperture 9", 9, curve: -0.8, soft: 0.08, grad: 0.4)),
            c("Cinematic", IrisDef("Cine 5", 5, round: 0.25, curve: 0.6, soft: 0.14, grad: 0.65)),
            c("Cinematic", IrisDef("Cine 8", 8, round: 0.35, curve: 0.9, soft: 0.12, grad: 0.7, chroma: 0.25)),
            c("Cinematic", IrisDef("Vintage 6", 6, round: 0.5, soft: 0.35, grad: 0.75, chroma: 0.35)),
            c("Cinematic", IrisDef("Bokeh disc", 9, round: 1, soft: 0.22, grad: 0.85)),
            c("Cinematic", IrisDef("Bokeh rim", 12, round: 1, soft: 0.18, grad: 0.95, chroma: 0.2)),
            c("Cinematic", IrisDef("Lens rim", 7, round: 0.4, curve: 0.6, thick: 0.3, soft: 0.14, grad: 0.8, chroma: 0.6)),
            c("Hollow", IrisDef("Hollow hex", 6, thick: 0.18, soft: 0.1, grad: 0)),
            c("Hollow", IrisDef("Hollow ring", 12, round: 1, thick: 0.12, soft: 0.08, grad: 0)),
            c("Hollow", IrisDef("Thin ring", 12, round: 1, thick: 0.06, soft: 0.06, grad: 0)),
            c("Hollow", IrisDef("Onion ring", 12, round: 1, thick: 0.22, soft: 0.2, grad: 0.6, chroma: 0.3)),
            c("Hollow", IrisDef("Hollow tri", 3, round: 0.15, thick: 0.2, soft: 0.1, grad: 0.2)),
            c("Stars", IrisDef("Star 5", 5, star: 0.6, soft: 0.08)),
            c("Stars", IrisDef("Star 6", 6, star: 0.75, soft: 0.06)),
            c("Stars", IrisDef("Sparkle 4", 4, star: 0.88, soft: 0.05)),
            c("Stars", IrisDef("Flower 8", 8, round: 0.3, star: 0.35, curve: 1, soft: 0.1)),
            c("Stars", IrisDef("Spiky 12", 12, star: 0.8, soft: 0.05)),
            c("Stars", IrisDef("Starburst", 8, star: 0.92, soft: 0.04)),
            c("Crystal", IrisDef("Crystal", 6, star: 0.3, curve: -0.4, thick: 0.45, soft: 0.06, grad: 0.7, chroma: 0.5)),
            c("Crystal", IrisDef("Prism", 3, round: 0.2, thick: 0.35, soft: 0.1, grad: 0.6, chroma: 0.9)),
            c("Crystal", IrisDef("Gem 10", 10, star: 0.15, curve: 0.3, soft: 0.1, grad: 0.6)),
            c("Crystal", IrisDef("Diamond", 4, curve: -0.3, thick: 0.4, soft: 0.06, grad: 0.7, chroma: 0.6)),
            c("Crystal", IrisDef("Shard", 3, star: 0.4, soft: 0.05, grad: 0.8, chroma: 0.7)),
        ]
    }

    /// A random but pleasant iris (the "Surprise me" button).
    static func random() -> IrisDef {
        var d = IrisDef("Random", Int.random(in: 3...12))
        d.round = Bool.random() ? Float.random(in: 0...0.7) : 0
        d.star = Int.random(in: 0...2) == 0 ? Float.random(in: 0.2...0.85) : 0
        d.curve = Float.random(in: -1...1) * (Bool.random() ? 1 : 0.3)
        d.thick = Bool.random() ? 1 : Float.random(in: 0.12...0.6)
        d.soft = Float.random(in: 0.04...0.4)
        d.grad = Float.random(in: 0...0.8)
        d.chroma = Int.random(in: 0...2) == 0 ? Float.random(in: 0.3...1) : 0
        return d
    }

    static var user: [IrisDef] = []

    static func userFile() -> URL { Projects.root.appendingPathComponent("irises.json") }

    static func loadUser() {
        user = []
        guard let o = JObj.readDictionary(userFile()), let a = o.optJSONArray("irises") else { return }
        for i in 0..<a.count { if var d = a.optJSONObject(i).map({ IrisDef.fromJson($0) }) { d.cat = "My irises"; user.append(d) } }
    }

    static func saveUser() {
        let a = JArr()
        for d in user { a.put(d.toJson()) }
        try? JObj().put("irises", a).toString(4).write(to: userFile(), atomically: true, encoding: .utf8)
    }
}

// MARK: - FlareEl

final class FlareEl {
    // indices 0...6 are the original types (saved projects), 7+ are new
    static let TYPES = ["Glow", "Polygon", "Line", "Rays", "Ring", "Ring polygon", "Dot",
                        "Glint", "Hoop", "Streak", "Spike ball", "Rainbow", "Shimmer", "Iris", "Multi iris"]
    static let MAX = 16

    var type = 0
    var enabled = true
    var pos: Float = 1            // along the axis
    var size: Float = 0.5
    var stretch: Float = 1
    var rot: Float = 0
    var bright: Float = 1
    var soft: Float = 0.5
    var thick: Float = 0.3
    var sides = 6
    var rays = 8
    var chroma: Float = 0
    var follow = false
    var round: Float = 0
    var star: Float = 0
    var curve: Float = 0
    var grad: Float = 0.3
    var noise: Float = 0          // random ray length / shimmer amount
    var spin: Float = 0           // turns per screen of light travel
    var spread: Float = 0.32      // multi iris: gap between copies along the axis
    var color: Int32 = Int32(bitPattern: 0xFFFFFFFF)

    init(_ type: Int = 0) {
        self.type = type
    }

    func label() -> String {
        Self.TYPES.indices.contains(type) ? Self.TYPES[type] : "Element"
    }

    var isIris: Bool { type == 1 || type == 5 || type == 13 || type == 14 }

    func copy() -> FlareEl {
        let e = FlareEl(type)
        e.enabled = enabled; e.pos = pos; e.size = size; e.stretch = stretch; e.rot = rot
        e.bright = bright; e.soft = soft; e.thick = thick; e.sides = sides; e.rays = rays
        e.chroma = chroma; e.follow = follow; e.color = color
        e.round = round; e.star = star; e.curve = curve; e.grad = grad; e.noise = noise; e.spin = spin
        e.spread = spread
        return e
    }

    func toJson() -> JObj {
        JObj().put("type", Int64(type)).put("enabled", enabled).put("pos", Double(pos))
            .put("size", Double(size)).put("stretch", Double(stretch)).put("rot", Double(rot))
            .put("bright", Double(bright)).put("soft", Double(soft)).put("thick", Double(thick))
            .put("sides", Int64(sides)).put("rays", Int64(rays)).put("chroma", Double(chroma))
            .put("follow", follow).put("color", Double(UInt32(bitPattern: color)))
            .put("round", Double(round)).put("star", Double(star)).put("curve", Double(curve))
            .put("grad", Double(grad)).put("noise", Double(noise)).put("spin", Double(spin))
            .put("spread", Double(spread))
    }

    static func fromJson(_ o: JObj) -> FlareEl {
        let e = FlareEl(o.optInt("type"))
        e.enabled = o.optBool("enabled", true)
        e.pos = o.optFloat("pos", 1); e.size = o.optFloat("size", 0.5)
        e.stretch = o.optFloat("stretch", 1); e.rot = o.optFloat("rot")
        e.bright = o.optFloat("bright", 1); e.soft = o.optFloat("soft", 0.5)
        e.thick = o.optFloat("thick", 0.3); e.sides = o.optInt("sides", 6)
        e.rays = o.optInt("rays", 8); e.chroma = o.optFloat("chroma")
        e.follow = o.optBool("follow")
        e.round = o.optFloat("round"); e.star = o.optFloat("star"); e.curve = o.optFloat("curve")
        e.grad = o.optFloat("grad", 0.3); e.noise = o.optFloat("noise"); e.spin = o.optFloat("spin")
        e.spread = o.optFloat("spread", 0.32)
        e.color = Int32(bitPattern: UInt32(clamping: Int64(o.optDouble("color"))))
        return e
    }

    /// Sensible starting values for a freshly added element of `type`.
    static func make(_ type: Int) -> FlareEl {
        let e = FlareEl(type)
        switch type {
        case 0: e.pos = 0; e.size = 0.5; e.soft = 0.7; e.bright = 1.2
        case 1, 5: e.size = 0.3; e.thick = 0.45; e.soft = 0.15
        case 2: e.size = 1.2; e.stretch = 10; e.thick = 0.04; e.pos = 0
        case 3: e.size = 0.9; e.pos = 0; e.rays = 12
        case 4: e.size = 0.5; e.thick = 0.06; e.soft = 0.3
        case 6: e.size = 0.05; e.soft = 0.3
        case 7: e.pos = 0; e.size = 1.1; e.rays = 8; e.soft = 0.6; e.noise = 0.3; e.bright = 0.9
        case 8: e.pos = 1; e.size = 0.8; e.thick = 0.12; e.chroma = 0.6; e.bright = 0.7
        case 9: e.pos = 0; e.size = 1.8; e.stretch = 3; e.thick = 0.15; e.soft = 0.5; e.bright = 1
        case 10: e.pos = 0; e.size = 0.9; e.rays = 18; e.noise = 0.8; e.soft = 0.6; e.bright = 1
        case 11: e.pos = 1.2; e.size = 0.9; e.thick = 0.5; e.chroma = 0.8; e.bright = 0.5
        case 12: e.pos = 0; e.size = 0.7; e.rays = 14; e.noise = 0.5; e.bright = 0.8
        case 13: e.size = 0.3; e.sides = 7; e.round = 0.15; e.curve = 0.8; e.thick = 1; e.soft = 0.12; e.grad = 0.5
        case 14: e.pos = 0.45; e.size = 0.2; e.rays = 5; e.spread = 0.32; e.sides = 6; e.round = 0.1; e.curve = 0.5
            e.thick = 1; e.soft = 0.12; e.grad = 0.65; e.chroma = 0.5; e.noise = 0.5; e.bright = 0.55; e.follow = true
        default: break
        }
        return e
    }
}

// MARK: - Flare

final class Flare {
    var name = "Flare"
    var tint: Int32 = Int32(bitPattern: 0xFFFFFFFF)
    var depthScale: Float = 0.6
    var edgeFade: Float = 0.5
    var flicker: Float = 0
    var speed: Float = 1
    var rayAmt: Float = 0.6      // overall strength of every ray / spike / starburst
    var els: [FlareEl] = []

    // user presets (<Documents>/SaikiMotion/flares.json)
    static var user: [Flare] = []

    func copy() -> Flare {
        let f = Flare()
        f.name = name; f.tint = tint; f.depthScale = depthScale; f.edgeFade = edgeFade
        f.flicker = flicker; f.speed = speed; f.rayAmt = rayAmt
        for e in els { f.els.append(e.copy()) }
        return f
    }

    /// Signature for thumbnail caching.
    func sig() -> String {
        var s = name + "|"
        for e in els {
            s += "\(e.type),\(e.pos),\(e.size),\(UInt32(bitPattern: e.color)),\(e.enabled ? 1 : 0),\(e.sides),\(e.thick),\(e.stretch),\(e.rays),\(e.star),\(e.round),\(e.spread),\(e.chroma),\(e.bright);"
        }
        return s + "|" + String(UInt32(bitPattern: tint))
    }

    func toJson() -> JObj {
        let o = JObj().put("name", name).put("tint", Double(UInt32(bitPattern: tint)))
            .put("depthScale", Double(depthScale)).put("edgeFade", Double(edgeFade))
            .put("flicker", Double(flicker)).put("speed", Double(speed)).put("rayAmt", Double(rayAmt))
        let a = JArr()
        for e in els { a.put(e.toJson()) }
        o.put("els", a)
        return o
    }

    static func fromJson(_ o: JObj) -> Flare {
        let f = Flare()
        f.name = o.optString("name", "Flare")
        f.tint = Int32(bitPattern: UInt32(clamping: Int64(o.optDouble("tint"))))
        f.depthScale = o.optFloat("depthScale", 0.6)
        f.edgeFade = o.optFloat("edgeFade", 0.5)
        f.flicker = o.optFloat("flicker"); f.speed = o.optFloat("speed", 1); f.rayAmt = o.optFloat("rayAmt", 0.6)
        if let a = o.optJSONArray("els") {
            for i in 0..<a.count {
                if let eo = a.optJSONObject(i) { f.els.append(FlareEl.fromJson(eo)) }
            }
        }
        return f
    }

    // -- presets --

    private static func argb(_ v: UInt32) -> Int32 { Int32(bitPattern: v) }

    static func deflt() -> Flare {
        let f = Flare()
        f.name = "Custom"
        let glow = FlareEl.make(0); glow.size = 0.55; glow.bright = 1.4
        let streak = FlareEl.make(9); streak.size = 1.6; streak.stretch = 4; streak.thick = 0.1; streak.bright = 0.8
        let hoop = FlareEl.make(8); hoop.pos = 1; hoop.size = 0.9
        f.els = [glow, streak, hoop]
        return f
    }

    static func builtin() -> [Flare] {
        var out: [Flare] = []
        func make(_ name: String, _ tint: UInt32 = 0xFFFFFFFF, _ build: (Flare) -> Void) {
            let f = Flare(); f.name = name; f.tint = argb(tint); build(f); out.append(f)
        }
        func el(_ f: Flare, _ t: Int, _ cfg: (FlareEl) -> Void) {
            let e = FlareEl.make(t); cfg(e); f.els.append(e)
        }

        make("Hot Star", 0xFFFFF3DC) { f in
            el(f, 0) { $0.size = 1.9; $0.bright = 0.28; $0.soft = 1 }
            el(f, 0) { $0.size = 0.62; $0.bright = 1.6; $0.soft = 0.8 }
            el(f, 0) { $0.size = 0.14; $0.bright = 1.8; $0.soft = 0.3 }
            el(f, 7) { $0.size = 1.3; $0.rays = 8; $0.noise = 0.4; $0.bright = 1.0 }
            el(f, 9) { $0.size = 2.4; $0.stretch = 3; $0.thick = 0.06; $0.bright = 0.6; $0.color = argb(0xFFFFE3B8) }
            el(f, 8) { $0.pos = 1; $0.size = 1.0; $0.thick = 0.1; $0.chroma = 0.7; $0.bright = 0.5 }
            el(f, 14) { $0.pos = 0.5; $0.size = 0.13; $0.rays = 5; $0.spread = 0.3; $0.chroma = 0.5; $0.color = argb(0xFFFFD9A0); $0.bright = 0.6 }
            el(f, 11) { $0.pos = 1.3; $0.size = 1.0; $0.thick = 0.3; $0.chroma = 0.8; $0.bright = 0.22 }
        }
        make("Cinema Anamorphic", 0xFFB8DCFF) { f in
            el(f, 0) { $0.size = 1.2; $0.bright = 0.35; $0.soft = 1; $0.color = argb(0xFF4F8CFF) }
            el(f, 9) { $0.size = 3.2; $0.stretch = 5; $0.thick = 0.05; $0.soft = 0.4; $0.bright = 1.7; $0.color = argb(0xFF9CD0FF) }
            el(f, 9) { $0.size = 1.6; $0.stretch = 3; $0.thick = 0.18; $0.soft = 0.8; $0.bright = 0.5; $0.color = argb(0xFF4F9CFF) }
            el(f, 0) { $0.size = 0.3; $0.bright = 1.5; $0.soft = 0.6 }
            el(f, 14) { $0.pos = 0.6; $0.size = 0.2; $0.rays = 6; $0.spread = 0.28; $0.stretch = 0.45; $0.grad = 0.7; $0.chroma = 0.4; $0.color = argb(0xFF80C8FF); $0.bright = 0.5 }
            el(f, 8) { $0.pos = 0.8; $0.size = 0.5; $0.thick = 0.2; $0.chroma = 0.5; $0.bright = 0.35; $0.color = argb(0xFF7EC8FF) }
            el(f, 6) { $0.pos = 1.3; $0.size = 0.06; $0.bright = 0.8; $0.color = argb(0xFFFFB070) }
        }
        make("Lens Ghosts") { f in
            el(f, 0) { $0.size = 0.4; $0.bright = 1.4; $0.soft = 0.7 }
            el(f, 7) { $0.size = 0.9; $0.rays = 6; $0.bright = 0.8 }
            el(f, 14) { $0.pos = 0.35; $0.size = 0.16; $0.rays = 7; $0.spread = 0.3; $0.chroma = 0.8; $0.bright = 0.5 }
            el(f, 14) { $0.pos = 0.5; $0.size = 0.3; $0.rays = 3; $0.spread = 0.55; $0.thick = 0.25; $0.chroma = 0.5; $0.color = argb(0xFF8FC8FF); $0.bright = 0.45 }
            el(f, 8) { $0.pos = 1; $0.size = 1.2; $0.thick = 0.1; $0.chroma = 1; $0.bright = 0.5 }
        }
        make("Sun Glare", 0xFFFFEBC0) { f in
            el(f, 0) { $0.size = 1.3; $0.bright = 1.0; $0.soft = 1.0 }
            el(f, 0) { $0.size = 0.35; $0.bright = 1.8; $0.soft = 0.5 }
            el(f, 10) { $0.size = 1.2; $0.rays = 22; $0.noise = 0.9; $0.bright = 1.1 }
            el(f, 11) { $0.pos = 0.9; $0.size = 1.1; $0.thick = 0.45; $0.chroma = 0.7; $0.bright = 0.35 }
            el(f, 14) { $0.pos = 0.5; $0.size = 0.18; $0.sides = 8; $0.rays = 6; $0.spread = 0.3; $0.chroma = 0.6; $0.color = argb(0xFFFFD090); $0.bright = 0.5 }
        }
        make("Neon Spike", 0xFFFFFFFF) { f in
            el(f, 0) { $0.size = 0.35; $0.bright = 1.6; $0.color = argb(0xFFFF4FD8) }
            el(f, 10) { $0.size = 1.1; $0.rays = 14; $0.noise = 0.7; $0.color = argb(0xFFFF6FE0); $0.bright = 1.2 }
            el(f, 12) { $0.size = 0.9; $0.rays = 12; $0.noise = 0.6; $0.color = argb(0xFF4FE0FF); $0.bright = 0.9 }
            el(f, 9) { $0.size = 2.0; $0.stretch = 3; $0.thick = 0.05; $0.color = argb(0xFF6FE8FF); $0.bright = 1.0 }
            el(f, 14) { $0.pos = 0.7; $0.size = 0.15; $0.sides = 4; $0.rays = 4; $0.spread = 0.4; $0.chroma = 0; $0.color = argb(0xFFFF6FE0); $0.bright = 0.5 }
            el(f, 8) { $0.pos = 1.1; $0.size = 0.7; $0.thick = 0.1; $0.color = argb(0xFFFF6FE0); $0.bright = 0.6 }
        }
        make("Crystal", 0xFFE8F4FF) { f in
            el(f, 0) { $0.size = 0.45; $0.bright = 1.5; $0.soft = 0.7 }
            el(f, 7) { $0.size = 1.0; $0.rays = 4; $0.soft = 0.8; $0.bright = 1.2 }
            el(f, 14) { $0.pos = 0.5; $0.size = 0.18; $0.sides = 6; $0.star = 0.5; $0.rays = 5; $0.spread = 0.3; $0.chroma = 0.7; $0.grad = 0.8; $0.bright = 0.6 }
            el(f, 13) { $0.pos = 1.7; $0.size = 0.15; $0.sides = 4; $0.star = 0.85; $0.bright = 0.9; $0.follow = true }
        }
        make("Golden Hour", 0xFFFFD9A0) { f in
            el(f, 0) { $0.size = 2.2; $0.bright = 0.4; $0.soft = 1; $0.color = argb(0xFFFF9A40) }
            el(f, 0) { $0.size = 0.7; $0.bright = 1.5; $0.soft = 0.8 }
            el(f, 9) { $0.size = 2.6; $0.stretch = 4; $0.thick = 0.07; $0.bright = 0.9; $0.color = argb(0xFFFFC070) }
            el(f, 12) { $0.size = 0.8; $0.rays = 10; $0.noise = 0.4; $0.bright = 0.5 }
            el(f, 14) { $0.pos = 0.5; $0.size = 0.22; $0.rays = 6; $0.spread = 0.3; $0.round = 0.5; $0.soft = 0.3; $0.grad = 0.8; $0.chroma = 0.3; $0.color = argb(0xFFFFB060); $0.bright = 0.5 }
            el(f, 11) { $0.pos = 1.2; $0.size = 1.2; $0.thick = 0.35; $0.chroma = 0.5; $0.bright = 0.2 }
        }
        make("Teal and Orange", 0xFFFFFFFF) { f in
            el(f, 0) { $0.size = 0.8; $0.bright = 1.2; $0.soft = 0.9; $0.color = argb(0xFFFFA050) }
            el(f, 0) { $0.size = 0.2; $0.bright = 1.6; $0.soft = 0.4 }
            el(f, 9) { $0.size = 3.0; $0.stretch = 4.5; $0.thick = 0.05; $0.bright = 1.2; $0.color = argb(0xFF35D4C8) }
            el(f, 7) { $0.size = 1.0; $0.rays = 6; $0.bright = 0.6; $0.color = argb(0xFFFFC890) }
            el(f, 14) { $0.pos = 0.55; $0.size = 0.2; $0.rays = 5; $0.spread = 0.34; $0.stretch = 0.6; $0.grad = 0.7; $0.chroma = 0.2; $0.color = argb(0xFF35D4C8); $0.bright = 0.5 }
            el(f, 8) { $0.pos = 1.1; $0.size = 0.8; $0.thick = 0.12; $0.bright = 0.5; $0.color = argb(0xFFFFA050) }
        }
        make("Blockbuster Hero", 0xFFFFFFFF) { f in
            el(f, 0) { $0.size = 1.4; $0.bright = 0.6; $0.soft = 1; $0.color = argb(0xFFBFD8FF) }
            el(f, 0) { $0.size = 0.5; $0.bright = 1.8; $0.soft = 0.6 }
            el(f, 7) { $0.size = 1.8; $0.rays = 8; $0.noise = 0.5; $0.bright = 1.1 }
            el(f, 9) { $0.size = 3.4; $0.stretch = 5; $0.thick = 0.05; $0.bright = 1.5; $0.color = argb(0xFFD8E8FF) }
            el(f, 14) { $0.pos = 0.45; $0.size = 0.16; $0.rays = 7; $0.spread = 0.27; $0.chroma = 0.6; $0.bright = 0.55 }
            el(f, 14) { $0.pos = 1.4; $0.size = 0.3; $0.rays = 3; $0.spread = 0.3; $0.thick = 0.3; $0.chroma = 0.5; $0.color = argb(0xFFA8CCFF); $0.bright = 0.4 }
            el(f, 11) { $0.pos = 1.0; $0.size = 1.5; $0.thick = 0.4; $0.chroma = 0.9; $0.bright = 0.25 }
        }
        make("Vintage Anamorphic", 0xFFFFE6B0) { f in
            el(f, 0) { $0.size = 0.9; $0.bright = 1.0; $0.soft = 1; $0.color = argb(0xFFFFB050) }
            el(f, 9) { $0.size = 3.0; $0.stretch = 4; $0.thick = 0.12; $0.soft = 0.7; $0.bright = 1.0; $0.color = argb(0xFFFFC060) }
            el(f, 14) { $0.pos = 0.6; $0.size = 0.28; $0.rays = 5; $0.spread = 0.36; $0.round = 1; $0.soft = 0.3; $0.grad = 0.9; $0.noise = 0.6; $0.chroma = 0.3; $0.color = argb(0xFFFFB868); $0.bright = 0.45 }
            el(f, 12) { $0.size = 0.7; $0.rays = 12; $0.noise = 0.6; $0.bright = 0.5 }
            el(f, 8) { $0.pos = 1; $0.size = 1.0; $0.thick = 0.15; $0.chroma = 0.6; $0.bright = 0.4 }
        }
        make("Deep Space", 0xFFD8D0FF) { f in
            el(f, 0) { $0.size = 1.5; $0.bright = 0.5; $0.soft = 1; $0.color = argb(0xFF7A5CFF) }
            el(f, 0) { $0.size = 0.3; $0.bright = 1.7; $0.soft = 0.5 }
            el(f, 10) { $0.size = 1.4; $0.rays = 16; $0.noise = 0.8; $0.bright = 0.9; $0.color = argb(0xFFB8A8FF) }
            el(f, 9) { $0.size = 2.4; $0.stretch = 4; $0.thick = 0.05; $0.bright = 1.0; $0.color = argb(0xFF8FA8FF) }
            el(f, 14) { $0.pos = 0.6; $0.size = 0.14; $0.sides = 5; $0.star = 0.5; $0.rays = 6; $0.spread = 0.3; $0.chroma = 0.9; $0.bright = 0.5 }
            el(f, 11) { $0.pos = 1.3; $0.size = 1.3; $0.thick = 0.5; $0.chroma = 1; $0.bright = 0.25 }
        }
        make("Cine Multi Iris", 0xFFFFF4E0) { f in
            el(f, 0) { $0.size = 0.5; $0.bright = 1.5; $0.soft = 0.7 }
            el(f, 9) { $0.size = 2.2; $0.stretch = 4; $0.thick = 0.06; $0.bright = 0.9 }
            el(f, 14) { $0.pos = 0.3; $0.size = 0.12; $0.rays = 8; $0.spread = 0.22; $0.chroma = 0.7; $0.bright = 0.55 }
            el(f, 14) { $0.pos = 0.5; $0.size = 0.26; $0.rays = 4; $0.spread = 0.45; $0.thick = 0.3; $0.curve = 0.8; $0.chroma = 0.5; $0.color = argb(0xFFA8D0FF); $0.bright = 0.45 }
            el(f, 14) { $0.pos = 0.9; $0.size = 0.18; $0.sides = 8; $0.rays = 5; $0.spread = 0.3; $0.round = 0.4; $0.grad = 0.9; $0.color = argb(0xFFFFC890); $0.bright = 0.4 }
            el(f, 8) { $0.pos = 1; $0.size = 1.1; $0.thick = 0.1; $0.chroma = 0.8; $0.bright = 0.4 }
        }
        make("Classic", 0xFFFFFFFF) { f in
            el(f, 0) { $0.size = 0.5; $0.bright = 1.5; $0.soft = 0.6 }
            el(f, 4) { $0.pos = 1; $0.size = 0.8; $0.thick = 0.06; $0.bright = 0.6 }
            el(f, 13) { $0.pos = 1.6; $0.size = 0.28; $0.sides = 6; $0.thick = 0.5; $0.bright = 0.8 }
            el(f, 6) { $0.pos = 0.6; $0.size = 0.1 }
        }
        make("Sunbeam", 0xFFFFE9B0) { f in
            el(f, 0) { $0.size = 0.7; $0.bright = 1.8; $0.soft = 0.4 }
            el(f, 9) { $0.size = 1.8; $0.stretch = 5; $0.thick = 0.06; $0.bright = 1.2 }
            el(f, 7) { $0.size = 1.1; $0.rays = 6; $0.bright = 0.9 }
        }
        make("Rainbow ring", 0xFFFFFFFF) { f in
            el(f, 0) { $0.size = 0.3; $0.bright = 1.3 }
            el(f, 11) { $0.pos = 1; $0.size = 1.1; $0.thick = 0.6; $0.chroma = 1; $0.bright = 0.8 }
        }
        make("Sci-fi", 0xFFB0FFE9) { f in
            el(f, 0) { $0.size = 0.42; $0.bright = 1.6; $0.soft = 0.8 }
            el(f, 13) { $0.pos = 1; $0.size = 0.5; $0.sides = 6; $0.thick = 0.5; $0.follow = true }
            el(f, 13) { $0.pos = 1.4; $0.size = 0.3; $0.sides = 6; $0.thick = 1; $0.follow = true }
            el(f, 7) { $0.size = 0.9; $0.rays = 4; $0.soft = 0.8 }
        }
        return out
    }

    // -- user presets on disk --

    static func userFile() -> URL {
        Projects.root.appendingPathComponent("flares.json")
    }

    static func loadUser() {
        user = []
        guard let o = JObj.readDictionary(userFile()) else { return }
        if let a = o.optJSONArray("flares") {
            for i in 0..<a.count {
                if let fo = a.optJSONObject(i) { user.append(Flare.fromJson(fo)) }
            }
        }
    }

    static func saveUser() {
        let a = JArr()
        for f in user { a.put(f.toJson()) }
        let o = JObj().put("flares", a)
        try? o.toString(4).write(to: userFile(), atomically: true, encoding: .utf8)
    }
}

extension JObj {
    /// Reads a file into a JObj (nil when missing/broken).
    static func readDictionary(_ url: URL) -> JObj? {
        guard let text = try? String(contentsOf: url, encoding: .utf8) else { return nil }
        return JObj.parse(text)
    }
}

// MARK: - FlareThumbs

/// Renders flare presets into cached thumbnails (dark card + the elements drawn
/// additively along the axis, with real gradients).
enum FlareThumbs {
    static var cache: [String: UIImage] = [:]

    /// One single-element flare per element type (the Add-element browser thumbnails).
    static func elementPreviews() -> [Flare] {
        FlareEl.TYPES.indices.map { t in
            let f = Flare(); f.name = FlareEl.TYPES[t]
            let e = FlareEl.make(t); e.pos = t == 14 ? 0.5 : 1; e.follow = false
            if t == 2 || t == 9 { e.size = min(e.size, 1.0) }
            f.els = [e]
            return f
        }
    }

    static func generate(_ preview: PreviewView?, _ flares: [Flare], _ done: @escaping () -> Void) {
        DispatchQueue.global(qos: .userInitiated).async {
            for f in flares {
                let key = f.sig()
                if cache[key] != nil { continue }
                let img = render(f)
                DispatchQueue.main.async { cache[key] = img }
            }
            DispatchQueue.main.async(execute: done)
        }
    }

    private static func glow(_ c: CGContext, _ r: CGFloat, _ col: UIColor, _ a: CGFloat, power: CGFloat = 1) {
        let cs = CGColorSpaceCreateDeviceRGB()
        let stops: [CGFloat] = [0, 0.25, 0.6, 1]
        let alphas: [CGFloat] = [1, 0.45, 0.1, 0].map { pow($0, power) * a }
        var comps: [CGFloat] = []
        var cr: CGFloat = 0, cg: CGFloat = 0, cb: CGFloat = 0, ca: CGFloat = 0
        col.getRed(&cr, green: &cg, blue: &cb, alpha: &ca)
        for al in alphas { comps += [cr, cg, cb, al] }
        guard let g = CGGradient(colorSpace: cs, colorComponents: comps, locations: stops, count: 4) else { return }
        c.drawRadialGradient(g, startCenter: .zero, startRadius: 0, endCenter: .zero, endRadius: r, options: [])
    }

    static func irisPath(_ d: IrisDef, _ r: CGFloat) -> CGPath {
        let p = CGMutablePath()
        let n = 120
        for i in 0...n {
            let a = Float(i) / Float(n) * 2 * .pi
            let rr = CGFloat(d.radius(at: a)) * r
            let x = CGFloat(sin(a)) * rr, y = -CGFloat(cos(a)) * rr
            if i == 0 { p.move(to: CGPoint(x: x, y: y)) } else { p.addLine(to: CGPoint(x: x, y: y)) }
        }
        p.closeSubpath()
        return p
    }

    private static func render(_ f: Flare) -> UIImage {
        let size = CGSize(width: 112, height: 64)
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 2
        let r = UIGraphicsImageRenderer(size: size, format: fmt)
        return r.image { ctx in
            let c = ctx.cgContext
            fillRect(c, CGRect(origin: .zero, size: size), Int32(bitPattern: 0xFF08080C))
            let cx0 = size.width * 0.2
            let cx1 = size.width * 0.8
            let cy = size.height / 2
            let tint = argbToUIColor(f.tint)
            c.setBlendMode(.plusLighter)

            for e in f.els where e.enabled {
                let ex = cx0 + (cx1 - cx0) * CGFloat(e.pos / 2)
                let es = CGFloat(e.size) * size.height * 0.5
                let base = argbToUIColor(e.color)
                let col = tint.withAlphaComponent(1).mixed(with: base, alpha: 0.65)
                let br = clamp(CGFloat(e.bright) * 0.8, 0, 1.2)
                c.saveGState()
                c.translateBy(x: ex, y: cy)
                c.rotate(by: CGFloat(e.rot) * .pi / 180)
                switch e.type {
                case 14:
                    let n = min(max(e.rays, 2), 8)
                    for k in 0..<n {
                        let kk = CGFloat(k)
                        c.saveGState()
                        c.translateBy(x: kk * CGFloat(e.spread) * (cx1 - cx0) / 2, y: 0)
                        var d = IrisDef(e); d.round = e.round
                        let path = irisPath(d, es * (1 - 0.06 * kk))
                        let hue = UIColor(hue: (0.08 + kk * 0.17).truncatingRemainder(dividingBy: 1), saturation: 0.65 * CGFloat(e.chroma), brightness: 1, alpha: 1)
                        let cc = col.mixed(with: hue, alpha: CGFloat(e.chroma) * 0.8)
                        c.setAlpha(min(1, br * 0.9 / (1 + 0.12 * kk)))
                        if d.thick >= 0.95 { c.addPath(path); c.setFillColor(cc.withAlphaComponent(0.55).cgColor); c.fillPath() }
                        c.addPath(path); c.setStrokeColor(cc.cgColor)
                        c.setLineWidth(max(1.2, es * CGFloat(min(d.thick, 0.5)) * 0.5)); c.strokePath()
                        c.restoreGState()
                    }
                case 0, 12:
                    glow(c, es * 1.1, col, min(1, br), power: 0.8)
                case 1, 5, 13:
                    var d = IrisDef(e)
                    if e.type != 13 { d.star = 0; d.round = 0; d.curve = 0 }
                    let path = irisPath(d, es)
                    c.setAlpha(min(1, br * 0.9))
                    if d.thick >= 0.95 {
                        c.addPath(path); c.setFillColor(col.withAlphaComponent(0.55).cgColor); c.fillPath()
                    }
                    c.addPath(path); c.setStrokeColor(col.cgColor)
                    c.setLineWidth(max(1.2, es * CGFloat(min(d.thick, 0.5)) * 0.5)); c.strokePath()
                case 2, 9:
                    c.saveGState()
                    c.scaleBy(x: max(2, CGFloat(e.stretch)) * 1.2, y: max(0.08, CGFloat(e.thick)) * 0.9)
                    glow(c, es * 0.9, col, min(1, br), power: 0.9)
                    c.restoreGState()
                case 3, 7, 10:
                    let n = max(3, e.rays)
                    c.setStrokeColor(col.withAlphaComponent(min(1, br)).cgColor)
                    c.setLineWidth(e.type == 3 ? max(1, es * 0.06) : 0.8)
                    for i in 0..<n {
                        let a = CGFloat(i) / CGFloat(n) * 2 * .pi
                        let len = es * (e.type == 3 ? 1 : (1 - CGFloat(e.noise) * CGFloat((i * 37) % 10) / 14))
                        c.move(to: .zero)
                        c.addLine(to: CGPoint(x: cos(a) * len, y: sin(a) * len))
                    }
                    c.strokePath()
                    glow(c, es * 0.35, col, min(1, br) * 0.7)
                case 4, 8:
                    c.setStrokeColor(col.withAlphaComponent(min(1, br)).cgColor)
                    c.setLineWidth(max(1.2, es * CGFloat(e.thick) * 0.5))
                    c.strokeEllipse(in: CGRect(x: -es * 0.5, y: -es * 0.5, width: es, height: es))
                case 11:
                    let cols: [UIColor] = [.red, .orange, .yellow, .green, .cyan, .blue, .purple]
                    for (i, rc) in cols.enumerated() {
                        c.setStrokeColor(rc.withAlphaComponent(min(1, br)).cgColor)
                        c.setLineWidth(max(1, es * 0.05))
                        let rr = es * (0.62 + 0.38 * CGFloat(i) / 6)
                        c.strokeEllipse(in: CGRect(x: -rr, y: -rr, width: rr * 2, height: rr * 2))
                    }
                default:
                    c.setFillColor(col.cgColor)
                    c.fillEllipse(in: CGRect(x: -es * 0.5, y: -es * 0.5, width: es, height: es))
                }
                c.restoreGState()
            }
        }
    }
}

extension UIColor {
    /// Simple linear RGB mix used for tinting flare elements.
    func mixed(with other: UIColor, alpha t: CGFloat) -> UIColor {
        var r1: CGFloat = 0, g1: CGFloat = 0, b1: CGFloat = 0, a1: CGFloat = 0
        var r2: CGFloat = 0, g2: CGFloat = 0, b2: CGFloat = 0, a2: CGFloat = 0
        getRed(&r1, green: &g1, blue: &b1, alpha: &a1)
        other.getRed(&r2, green: &g2, blue: &b2, alpha: &a2)
        return UIColor(red: r1 + (r2 - r1) * t, green: g1 + (g2 - g1) * t,
                       blue: b1 + (b2 - b1) * t, alpha: a1 + (a2 - a1) * t)
    }
}
