// SceneRenderer.swift — the compositor (Render).
//
// Draws a scene at time `t` into an offscreen target and hands back the
// texture. Pipeline per layer: content (image/video/text/shape/flare/
// particles/model/vdb/adjustment) → effect chain (ping-pong GLSL passes,
// one per applied effect, uniforms from the layer's tracks) → composite
// onto the scene buffer with the blend mode. Motion blur renders the layer
// at sub-times and accumulates. 3D layers and models project through the
// nearest camera above them.
//
// The same renderer drives the live preview, the effect thumbnails and the
// exporter — one look everywhere.

import Foundation
import OpenGLES
import GLKit
import UIKit

// MARK: - video source

/// Frame provider for video layers (preview: async buckets; export: sync).
protocol VideoSource: AnyObject {
    func videoTexture(layerId: Int, path: String, srcTime: Float) -> GLuint
    func videoFrameArrived() -> Bool
}

// MARK: - renderer

final class SceneRenderer {

    let context: EAGLContext
    var isExport = false            // export renders use the full blur sample budget
    var quality = 1                 // 1 full, 2 half, 4 quarter

    // targets (lazily sized)
    private(set) var sceneTarget: Gl.Target?
    private var scratchTarget: Gl.Target?      // composite intermediate
    private var layerA: Gl.Target?
    private var layerB: Gl.Target?
    private var accumTarget: Gl.Target?
    private var groupTarget: Gl.Target?
    private var groupPool: [Gl.Target] = []     // one offscreen buffer per precomp nesting level
    private var groupDepth = 0
    private var inTargets: [Gl.Target?] = [nil, nil]

    private(set) var width = 576
    private(set) var height = 1024

    // programs
    private var quadProg: GLProgram?          // textured quad (premult)
    private var shapeProg: GLProgram?
    private var flareProg: GLProgram?
    private var particleProg: GLProgram?
    private var particleVBO = GLuint(0)
    private var meshProg: GLProgram?
    private var vdbProg: GLProgram?
    private var compositeProg: GLProgram?

    // caches
    private var imageTex: [String: GLuint] = [:]
    private var imageTexBytes: [String: Int] = [:]
    private var imageTexOrder: [String] = []        // least recently used first
    private var imageTexTotal = 0
    private var imageTexSide = 0
    private let imageTexBudget = 360 * 1_048_576    // GPU memory for image layers
    private var videoSamplers: [Int: VideoFrames.Sampler] = [:]
    private var models: [String: GlbModel] = [:]
    private var volumes: [String: VdbVolume] = [:]
    private var effectProgs: [String: GLProgram] = [:]
    private var failedProgs = Set<String>()

    private var videoSource: VideoSource?

    init(context: EAGLContext) {
        self.context = context
    }

    // MARK: - entry

    /// Renders `scene` and returns the scene texture (owned by the renderer).
    func draw(project: Project, scene: Scene, time: Float, video: VideoSource?) -> GLuint {
        videoSource = video
        let ar = Float(project.w) / Float(max(project.h, 1))
        height = 1024 / max(1, quality)
        width = max(2, Int(Float(height) * ar))

        if sceneTarget == nil || sceneTarget!.width != width || sceneTarget!.height != height {
            sceneTarget = Gl.Target(width, height)
            scratchTarget = Gl.Target(width, height)
            layerA = Gl.Target(width, height)
            layerB = Gl.Target(width, height)
            accumTarget = Gl.Target(width, height)
            groupTarget = Gl.Target(width, height)
            groupPool.removeAll()
            let iw = 256
            let ih = max(2, Int(Float(256) / ar))
            inTargets = [Gl.Target(iw, ih), Gl.Target(iw, ih)]
        }

        EAGLContext.setCurrent(context)
        buildPrograms()

        // clear scene with bg
        sceneTarget!.bind()
        glClearColor(Float((UInt32(bitPattern: scene.bg) >> 16) & 0xFF) / 255,
                     Float((UInt32(bitPattern: scene.bg) >> 8) & 0xFF) / 255,
                     Float(UInt32(bitPattern: scene.bg) & 0xFF) / 255, 1)
        glClear(GLbitfield(GL_COLOR_BUFFER_BIT))

        var visited: [Layer: Bool] = [:]
        for l in scene.layers {
            // a group draws its own children (once, inside its precomp buffer)
            if l.parentId >= 0, let par = scene.layers.first(where: { $0.id == l.parentId }), par.type == .GROUP { continue }
            drawLayer(l, project: project, scene: scene, time: time, target: sceneTarget!, ar: ar,
                      visited: &visited)
        }

        return sceneTarget!.tex
    }

    /// The composited frame as an image (thumbnails / export readback).
    func snapshot() -> UIImage? {
        sceneTarget?.readImage()
    }

    /// Blits a texture to the currently bound framebuffer + viewport (the
    /// preview's drawable). Call with this renderer's context current.
    func present(_ tex: GLuint, flipY: Bool = false) {
        guard let p = quadProg else { return }
        p.use()
        resetQuadState(p)
        p.setFloat("uFlipY", flipY ? 1 : 0)
        p.setVec4("uColor", 1, 1, 1, 1)
        p.setMat3("uMat", [1, 0, 0, 0, 1, 0, 0, 0, 1])
        let ar = Float(width) / Float(max(height, 1))
        p.setVec2("uQuad", ar * 2, 2)
        p.setFloat("uAspect", ar)
        p.setTexture("uTex", tex, 0)
        Gl.drawQuad(p)
    }

    // MARK: - per-layer

    private func drawLayer(_ l: Layer, project: Project, scene: Scene, time: Float,
                           target: Gl.Target, ar: Float, visited: inout [Layer: Bool]) {
        guard l.visible else { return }
        guard time >= l.start - 0.001 && time <= l.end + 0.001 else { return }
        if visited[l] != nil { return }
        visited[l] = true
        defer { visited[l] = nil }

        switch l.type {
        case .AUDIO, .CAMERA, .NULL:
            return
        case .GROUP:
            if (l.mblur || (Xf.camera(for: l)?.mblur ?? false)) && l.mask == 0 {
                drawBlurredGroup(l, project: project, scene: scene, time: time, target: target, ar: ar,
                                 visited: &visited)
            } else {
                drawGroup(l, project: project, scene: scene, time: time, target: target, ar: ar, visited: &visited)
            }
            return
        default:
            break
        }

        let opacity = l.p("opacity", l.editTime("opacity", time))

        // motion blur: accumulate sub-time renders. A camera with motion blur on
        // blurs every 3D layer below it (so camera moves blur everything).
        let blurOn = l.mblur || (Xf.camera(for: l)?.mblur ?? false)
        var mbSamples = 1
        let hasParticles = l.type == .PARTICLES || (l.fx.contains("particles") && !l.fxOff.contains("particles"))
        let amount = l.p("mbAmount", time)
        let shutter = 0.12 * amount
        if blurOn {
            let cap = min(Int(max(2, l.p("mbSamples", time))), 64)
            let camMoves = (Xf.camera(for: l) != nil) && (l.is3d || l.type == .MODEL || l.type == .PARTICLES)
            let content = l.type == .VIDEO || l.type == .PARTICLES || l.type == .MODEL || l.type == .FLARE || !l.fx.isEmpty || camMoves
            // samples follow the real on-screen travel (projected through the camera VP) so the
            // copies always overlap: ~1 sample per pixel travelled, clamped 8...64
            let px = screenTravel(l, time: time, shutter: shutter)
            if px >= 0.5 {
                mbSamples = min(hasParticles ? (isExport ? 40 : 16) : (isExport ? 64 : 24), max(8, Int(px.rounded(.up)) + 1))
            } else if content && !hasParticles {
                mbSamples = min(cap, 12)
            }
        }
        if mbSamples > 1 {
            let stutter = l.mbStutter
            if hasParticles { particleSimTime = time }
            defer { particleSimTime = nil }
            accumTarget!.bind()
            glClearColor(0, 0, 0, 0)
            glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
            for s in 0..<mbSamples {
                let u = (Float(s) + mbJitter(s, time)) / Float(mbSamples)
                var st = time - shutter * (u - 0.5)
                if stutter { st = time - shutter * 0.5 * round(Float(s) / Float(max(mbSamples - 1, 1)) - 0.5) }
                let clamped = clamp(st, l.start, l.end)
                renderLayerContent(l, scene: scene, time: clamped, ar: ar, visited: &visited,
                                   target: target)
                let frac = u - 0.5
                composite(accumTarget!, src: layerA!.tex, alpha: 1 / Float(s + 1), mode: 5,
                          rgbShift: l.mbRgb ? frac * 0.004 * amount : 0)
            }
            if !l.fx.isEmpty {
                // effects run once on the blurred result (was once per sample: far too slow)
                layerA!.bind()
                glDisable(GLenum(GL_BLEND))
                blit(accumTarget!.tex)
                glEnable(GLenum(GL_BLEND))
                applyEffects(l, time: time)
                composite(target, src: layerA!.tex, alpha: opacity, mode: flareMode(l))
            } else {
                composite(target, src: accumTarget!.tex, alpha: opacity, mode: flareMode(l))
            }
        } else if (l.type == .IMAGE || l.type == .VIDEO) && l.blend == 0 && l.mask == 0 && l.fx.isEmpty {
            // Fast path (the common case: a plain image/video layer): one blended quad
            // straight into the scene. The general path below costs four full-screen
            // passes and three render-target switches per layer, which is what made scenes
            // with dozens of layers crawl on a tile-based GPU.
            if opacity <= 0.0005 { return }
            target.bind()
            glEnable(GLenum(GL_BLEND))
            glBlendFunc(GLenum(GL_ONE), GLenum(GL_ONE_MINUS_SRC_ALPHA))
            drawMediaLayer(l, time: time, opacity: opacity)
            glDisable(GLenum(GL_BLEND))
        } else {
            renderLayerContent(l, scene: scene, time: time, ar: ar, visited: &visited, target: target)
            applyEffects(l, time: time)
            composite(target, src: layerA!.tex, alpha: opacity, mode: flareMode(l))
        }
    }

    /// Stable per-frame jitter in [0,1) for stratified blur sampling (hash of sample + frame).
    private func mbJitter(_ s: Int, _ time: Float) -> Float {
        var h = UInt32(truncatingIfNeeded: s &* 73856093) ^ UInt32(truncatingIfNeeded: Int(time * 1000) &* 19349663)
        h = (h ^ (h >> 13)) &* 1274126177
        h ^= h >> 16
        return Float(h & 0xFFFF) / 65536
    }

    /// Max on-screen distance (pixels) any quad corner/centre travels between
    /// time - shutter/2 and time + shutter/2, including camera motion.
    private func screenTravel(_ l: Layer, time: Float, shutter: Float) -> Float {
        var (qw, qh) = Xf.quadSize(l)
        let isPart = l.type == .PARTICLES || l.fx.contains("particles")
        if isPart { qw *= 2.5; qh *= 2.5 }
        let useCam = l.is3d || (isPart && Xf.camera(for: l) != nil)
        let ar = Float(width) / Float(max(height, 1))
        let halfW = Float(width) * 0.5, halfH = Float(height) * 0.5
        func proj(_ t: Float, _ cx: Float, _ cy: Float) -> (Float, Float)? {
            let m = Xf.matrix(l, t)
            let x = cx * qw, y = cy * qh
            let wx = m[0] * x + m[2] * y + m[4]
            let wy = m[1] * x + m[3] * y + m[5]
            if useCam {
                let z = Xf.worldZ(l, t)
                let (vp, has) = cameraVP(l, scene: Editor.scene, time: t)
                if has {
                    let cw = vp[3] * wx + vp[7] * wy + vp[11] * z + vp[15]
                    if cw < 0.02 { return nil }
                    let cxp = vp[0] * wx + vp[4] * wy + vp[8] * z + vp[12]
                    let cyp = vp[1] * wx + vp[5] * wy + vp[9] * z + vp[13]
                    return (cxp / cw, cyp / cw)
                }
                let w = 1 - z / 3
                if w < 0.02 { return nil }
                return (wx / ar / w, wy / w)
            }
            return (wx / ar, wy)
        }
        var best: Float = 0
        let pts: [(Float, Float)] = [(-0.5, -0.5), (0.5, -0.5), (-0.5, 0.5), (0.5, 0.5), (0, 0)]
        for (cx, cy) in pts {
            guard let a = proj(time - shutter * 0.5, cx, cy), let b = proj(time + shutter * 0.5, cx, cy) else { continue }
            let dx = (a.0 - b.0) * halfW, dy = (a.1 - b.1) * halfH
            best = max(best, (dx * dx + dy * dy).squareRoot())
        }
        return best
    }

    /// Motion blur for a whole group: children are rendered at several sub-times
    /// and averaged, so everything inside the group blurs together.
    private func drawBlurredGroup(_ g: Layer, project: Project, scene: Scene, time: Float,
                                  target: Gl.Target, ar: Float, visited: inout [Layer: Bool]) {
        let children = scene.layers.filter { $0.parentId == g.id }
        guard !children.isEmpty, let accum = accumTarget, let grp = groupTarget else { return }
        let amount = g.p("mbAmount", time)
        let shutter = 0.12 * amount
        var travel: Float = 0
        for c in children { travel = max(travel, screenTravel(c, time: time, shutter: shutter)) }
        let n = travel >= 0.5 ? min(isExport ? 48 : 20, max(8, Int(travel.rounded(.up)) + 1))
                              : min(Int(max(2, g.p("mbSamples", time))), 12)
        let opacity = g.p("opacity", time)
        accum.bind()
        glClearColor(0, 0, 0, 0)
        glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
        for s in 0..<n {
            let st = clamp(time - shutter * ((Float(s) + mbJitter(s, time)) / Float(n) - 0.5), g.start, g.end)
            grp.bind()
            glClearColor(0, 0, 0, 0)
            glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
            for c in children {
                drawLayer(c, project: project, scene: scene, time: st, target: grp, ar: ar, visited: &visited)
            }
            composite(accum, src: grp.tex, alpha: 1 / Float(s + 1), mode: 5, rgbShift: 0)
        }
        composite(target, src: accum.tex, alpha: opacity, mode: g.blend)
    }

    // MARK: - content

    private func renderLayerContent(_ l: Layer, scene: Scene, time: Float, ar: Float,
                                    visited: inout [Layer: Bool], target: Gl.Target) {
        layerA!.bind()
        glClearColor(0, 0, 0, 0)
        glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
        glDisable(GLenum(GL_BLEND))

        switch l.type {
        case .IMAGE, .VIDEO:
            drawMediaLayer(l, time: time)
        case .TEXT:
            drawTextLayer(l, time: time)
        case .SHAPE:
            // "Particles" added from the + menu is a Shape layer carrying the particles effect
            if l.fx.contains("particles") && !l.fxOff.contains("particles") {
                if l.p("pShowSrc", l.editTime("pShowSrc", time)) >= 0.5 {
                    drawShapeLayer(l, time: time)
                }
                drawParticleLayer(l, time: time)
            } else {
                drawShapeLayer(l, time: time)
            }
        case .FLARE:
            drawFlareLayer(l, time: time)
        case .PARTICLES:
            if l.p("pShowSrc", l.editTime("pShowSrc", time)) >= 0.5 {
                drawShapeLayer(l, time: time)
            }
            drawParticleLayer(l, time: time)
        case .MODEL:
            drawModelLayer(l, scene: scene, time: time, ar: ar)
        case .ADJUST:
            // content = the current accumulation buffer (scene or group)
            blit(target.tex)
        default:
            break
        }
        glEnable(GLenum(GL_BLEND))
    }

    /// Fullscreen (identity) state for the layer-quad program. blit()/present() draw with the
    /// same program as 3D layers; without this reset they reused the previous layer's
    /// rotation / perspective, so every full-frame copy came out tilted — the diagonal
    /// "cut" across Deep Glow (and any haze) that only showed once something glowed.
    private func resetQuadState(_ p: GLProgram) {
        p.setVec3("uRot", 0, 0, 0)
        p.setFloat("uZ", 0)
        p.setFloat("uInvCam", 0)
        p.setFloat("uUseVP", 0)
    }

    /// Fullscreen copy of `tex` into the currently bound target.
    private func blit(_ tex: GLuint) {
        guard let p = quadProg else { return }
        p.use()
        resetQuadState(p)
        p.setFloat("uFlipY", 0)
        p.setVec4("uColor", 1, 1, 1, 1)
        p.setMat3("uMat", [1, 0, 0, 0, 1, 0, 0, 0, 1])
        p.setVec2("uQuad", Float(width) / Float(max(height, 1)) * 2, 2)
        p.setFloat("uAspect", Float(width) / Float(max(height, 1)))
        p.setTexture("uTex", tex, 0)
        Gl.drawQuad(p)
    }

    private func drawMediaLayer(_ l: Layer, time: Float, opacity: Float = 1) {
        guard let path = l.imagePath else { return }
        var tex: GLuint = 0
        if l.type == .VIDEO {
            let srcT = sourceTime(l, time)
            if let vs = videoSource {
                tex = vs.videoTexture(layerId: l.id, path: path, srcTime: srcT)
            } else {
                let s = samplerFor(l)
                tex = s.texture(at: srcT)
            }
        }
        if tex == 0 {
            tex = imageTexture(path)
        }
        guard tex != 0 else { return }
        if let p = quadProg {
            p.use()
            p.setFloat("uFlipY", 1)
            p.setVec4("uColor", opacity, opacity, opacity, opacity)
            p.setTexture("uTex", tex, 0)
            drawLayerQuad(l, time: time, program: p)
        }
    }

    private func drawTextLayer(_ l: Layer, time: Float) {
        let img = TextRaster.raster(l, time)
        guard img.size.width > 1, img.size.height > 1, let tex = Gl.upload(img) else { return }
        defer { Gl.delete(tex) }
        if let p = quadProg {
            p.use()
            p.setFloat("uFlipY", 1)
            p.setVec4("uColor", 1, 1, 1, 1)
            p.setTexture("uTex", tex, 0)
            drawLayerQuad(l, time: time, program: p)
        }
    }

    private func drawShapeLayer(_ l: Layer, time: Float) {
        guard let p = shapeProg else { return }
        let (qw, qh) = Xf.quadSize(l)
        let m = Xf.matrix(l, time)
        p.use()
        p.setMat3("uMat", m)
        p.setVec2("uQuad", qw, qh)
        p.setFloat("uAspect", Float(width) / Float(max(height, 1)))
        let c = l.color
        p.setVec4("uColor",
                  Float((UInt32(bitPattern: c) >> 16) & 0xFF) / 255,
                  Float((UInt32(bitPattern: c) >> 8) & 0xFF) / 255,
                  Float(UInt32(bitPattern: c) & 0xFF) / 255,
                  Float((UInt32(bitPattern: c) >> 24) & 0xFF) / 255)
        var kind = 0
        switch l.shape {
        case .RECT: kind = 0
        case .ROUND: kind = 1
        case .CIRCLE: kind = 2
        case .TRIANGLE: kind = 3
        case .STAR: kind = 4
        }
        p.setFloat("uKind", Float(kind))
        p.setFloat("uCornerRadius", 0.12)
        Gl.drawQuad(p)
    }

    private func drawFlareLayer(_ l: Layer, time: Float) {
        guard let f = l.flare, let p = flareProg else { return }
        let ar = Float(width) / Float(max(height, 1))
        let lt = l.editTime("x", time)
        var wx = l.p("x", lt), wy = l.p("y", lt)
        var visible: Float = 1
        var sizeMul: Float = 1

        if l.is3d {
            // real 3D light: projected through the camera; grows/shrinks with distance and
            // disappears behind the camera
            let z = Xf.worldZ(l, time)
            let (vp, _) = cameraVP(l, scene: Editor.scene, time: time)
            let (nx, ny, w) = projectPoint(vp, wx, wy, z)
            let (_, _, w0) = projectPoint(vp, 0, 0, 0)
            if w <= 0.01 { visible = 0 }
            sizeMul = 1 + (min(max(w0 / max(w, 0.01), 0.15), 6) - 1) * f.depthScale
            wx = nx * ar; wy = ny
        } else if l.parentId >= 0 {
            let m = Xf.matrix(l, time)
            wx = m[4]; wy = m[5]
        }
        let fx = wx / ar / 2 + 0.5       // 0..1 across the canvas
        let fy = 0.5 - wy / 2
        let intensity = l.p("fIntensity", lt) * visible
        let axis = l.p("fAxis", lt)

        p.use()
        p.setVec2("uLight", fx, fy)
        p.setFloat("uIntensity", intensity)
        p.setFloat("uAxis", axis)
        p.setVec4("uTint",
                  Float((UInt32(bitPattern: f.tint) >> 16) & 0xFF) / 255,
                  Float((UInt32(bitPattern: f.tint) >> 8) & 0xFF) / 255,
                  Float(UInt32(bitPattern: f.tint) & 0xFF) / 255, 1)
        p.setFloat("uSizeMul", sizeMul)
        p.setFloat("uEdgeFade", f.edgeFade)
        p.setFloat("uAspect", ar)
        p.setFloat("uTime", time)
        p.setFloat("uFlicker", f.flicker)
        p.setFloat("uSpeed", f.speed)
        p.setFloat("uRayAmt", f.rayAmt)
        let n = min(f.els.count, FlareEl.MAX)
        p.setFloat("uCount", Float(n))
        for i in 0..<FlareEl.MAX {
            guard i < n else { p.setVec4("uA[\(i)]", -1, 0, 0, 0); continue }
            let e = f.els[i]
            p.setVec4("uA[\(i)]", Float(e.enabled ? e.type : -1), e.pos, e.size, e.rot)
            p.setVec4("uB[\(i)]", e.bright, e.soft, e.thick, max(e.stretch, 0.05))
            p.setVec4("uC[\(i)]", Float(e.sides), Float(e.rays), e.chroma, e.follow ? 1 : 0)
            p.setVec4("uD[\(i)]", e.round, e.star, e.curve, e.grad)
            p.setVec4("uE[\(i)]", e.noise, e.spin, Float(i) * 7.31 + 1.7, e.spread)
            p.setVec4("uCol[\(i)]",
                      Float((UInt32(bitPattern: e.color) >> 16) & 0xFF) / 255,
                      Float((UInt32(bitPattern: e.color) >> 8) & 0xFF) / 255,
                      Float(UInt32(bitPattern: e.color) & 0xFF) / 255, 1)
        }
        Gl.drawFull(p)
    }

    /// Flares are light: with the default blend they add onto the scene instead of covering it.
    private func flareMode(_ l: Layer) -> Int {
        l.type == .FLARE ? (l.blend == 2 ? 2 : 1) : l.blend
    }

    /// Projects a world point with a column-major 4x4: (screen x, screen y, w).
    private func projectPoint(_ vp: [Float], _ x: Float, _ y: Float, _ z: Float) -> (Float, Float, Float) {
        let cx = vp[0] * x + vp[4] * y + vp[8] * z + vp[12]
        let cy = vp[1] * x + vp[5] * y + vp[9] * z + vp[13]
        let cw = vp[3] * x + vp[7] * y + vp[11] * z + vp[15]
        return (cx / max(abs(cw), 0.0001), cy / max(abs(cw), 0.0001), cw)
    }

    /// While set, particle simulation uses this time (camera/layer still use the blur sub-time),
    /// so particles stay crisp and visible under motion blur instead of averaging to nothing.
    private var particleSimTime: Float? = nil

    private func drawParticleLayer(_ l: Layer, time: Float) {
        guard let p = particleProg else { return }
        let ar = Float(width) / Float(max(height, 1))
        let lt = l.editTime("x", time)
        let field = ParticlesSim.field(count: Int(l.p("pCount", lt)), spread: l.p("pSpread", lt),
                                       speed: l.p("pSpeed", lt), gravity: l.p("pGravity", lt),
                                       life: l.p("pLife", lt), seed: l.p("pSeed", lt),
                                       dirX: l.p("pDirX", lt), dirY: l.p("pDirY", lt), t: particleSimTime ?? time, ar: ar,
                                       posX: l.p("pPosX", lt), posY: l.p("pPosY", lt), posZ: l.p("pPosZ", lt),
                                       radX: l.p("pRadX", lt), radY: l.p("pRadY", lt), radZ: l.p("pRadZ", lt),
                                       dirZ: l.p("pDirZ", lt), resist: l.p("pResist", lt),
                                       wobble: l.p("pWobble", lt), sizeVar: l.p("pSizeVar", lt),
                                       sizeEnd: l.p("pSizeEnd", lt), dof: l.p("pDof", lt),
                                       focus: l.p("pFocus", lt),
                                       burst: l.p("pBurst", lt), burstForce: l.p("pBurstForce", lt),
                                       edge: l.p("pSoftEdge", lt))
        let m = Xf.matrix(l, time)
        let scene = Editor.scene
        let (vp, hasCam) = cameraVP(l, scene: scene, time: time)
        let use3D = hasCam || l.is3d
        let occlude = l.p("pOcclude", lt) >= 0.5

        // Occlude: particles behind a 3D layer / model are hidden by it.
        var blockers: [(Float, Float, Float, Float, Float)] = []   // minX, minY, maxX, maxY, z
        if occlude {
            for o in scene.layers where o !== l && o.visible
                && time >= o.start - 0.001 && time <= o.end + 0.001
                && (o.is3d || o.type == .MODEL) && o.isRenderable() && o.type != .PARTICLES {
                let ot = o.editTime("x", time)
                let sc = o.p("scale", ot)
                let (qw, qh) = Xf.quadSize(o)
                let hw = qw * sc * 0.5, hh = qh * sc * 0.5
                let ox = o.p("x", ot), oy = o.p("y", ot), oz = Xf.worldZ(o, time)
                var minX = Float.greatestFiniteMagnitude, minY = minX
                var maxX = -Float.greatestFiniteMagnitude, maxY = maxX
                var ok = true
                for (sx, sy) in [(-hw, -hh), (hw, -hh), (hw, hh), (-hw, hh)] {
                    let (px, py, pw) = projectPoint(vp, ox + sx, oy + sy, oz)
                    if pw <= 0.01 { ok = false; break }
                    minX = min(minX, px); maxX = max(maxX, px)
                    minY = min(minY, py); maxY = max(maxY, py)
                }
                if ok { blockers.append((minX, minY, maxX, maxY, oz)) }
            }
        }

        struct Pt { var x: Float; var y: Float; var z: Float; var size: Float; var life: Float; var soft: Float; var w: Float }
        var list: [Pt] = []
        list.reserveCapacity(field.count)
        let layerZ = Xf.worldZ(l, time)   // Position Z of the layer (and its 3D parents) moves the whole field
        for q0 in field {
            var q = q0
            q.z += layerZ
            var wx = m[0] * q.x + m[2] * q.y + m[4]
            var wy = m[1] * q.x + m[3] * q.y + m[5]
            var sz = q.size
            var w: Float = 1
            if use3D {
                let (sx, sy, pw) = projectPoint(vp, wx, wy, q.z)
                if pw <= 0.05 { continue }
                w = pw
                if occlude {
                    var hidden = false
                    for b in blockers where q.z < b.4 - 0.001 && sx >= b.0 && sx <= b.2 && sy >= b.1 && sy <= b.3 {
                        hidden = true; break
                    }
                    if hidden { continue }
                }
            } else {
                let pf = 1 / max(0.2, 1 - q.z / 3)
                wx *= pf; wy *= pf; sz *= pf
                w = 1 / pf
            }
            list.append(Pt(x: wx, y: wy, z: q.z, size: sz, life: q.life, soft: q.soft, w: w))
        }
        if list.isEmpty { return }
        if use3D { list.sort { $0.w > $1.w } }   // far → near; the flat (2D) field needs no sort — saves ~ms per frame

        p.use()
        setMat4(p, "uVP", vp)
        p.setFloat("uAspect", ar)
        p.setFloat("uOrtho", use3D ? 0 : 1)
        p.setFloat("uSize", l.p("pSize", lt))
        p.setFloat("uPx", Float(height) * 0.5)
        // particle opacity × the layer's own opacity, plus birth/death fade
        p.setFloat("uOpacity", l.p("pOpacity", lt) * clamp(l.p("opacity", lt), 0, 1))
        p.setFloat("uFadeIn", max(0.001, l.p("pFadeIn", lt)))
        p.setFloat("uFadeOut", max(0.001, l.p("pFadeOut", lt)))
        func pc(_ k: String, _ def: UInt32) -> (Float, Float, Float, Float) {
            (colorComp(l, key: k + "_r", def: Float((def >> 16) & 0xFF) / 255, time: time),
             colorComp(l, key: k + "_g", def: Float((def >> 8) & 0xFF) / 255, time: time),
             colorComp(l, key: k + "_b", def: Float(def & 0xFF) / 255, time: time),
             colorComp(l, key: k + "_a", def: 1, time: time))
        }
        let ca = pc("pColA", 0xFFFFFFFF), cb = pc("pColB", 0xFFFFFFFF)
        p.setVec4("uColA", ca.0, ca.1, ca.2, ca.3)
        p.setVec4("uColB", cb.0, cb.1, cb.2, cb.3)

        var pts = [Float]()
        pts.reserveCapacity(list.count * 6)
        for q in list {
            pts.append(q.x); pts.append(q.y); pts.append(q.z)
            pts.append(q.size); pts.append(q.life); pts.append(q.soft)
        }
        // one buffer for the renderer's lifetime (was glGenBuffers/glDeleteBuffers every frame)
        if particleVBO == 0 { glGenBuffers(1, &particleVBO) }
        glBindBuffer(GLenum(GL_ARRAY_BUFFER), particleVBO)
        pts.withUnsafeBufferPointer { ptr in
            glBufferData(GLenum(GL_ARRAY_BUFFER), MemoryLayout<Float>.size * pts.count,
                         ptr.baseAddress, GLenum(GL_DYNAMIC_DRAW))
        }
        let stride = GLsizei(MemoryLayout<Float>.size * 6)
        let aPos = glGetAttribLocation(p.handle, "aPos")
        let aData = glGetAttribLocation(p.handle, "aData")
        if aPos >= 0 {
            glEnableVertexAttribArray(GLuint(aPos))
            glVertexAttribPointer(GLuint(aPos), 3, GLenum(GL_FLOAT), GLboolean(GL_FALSE), stride, nil)
        }
        if aData >= 0 {
            glEnableVertexAttribArray(GLuint(aData))
            glVertexAttribPointer(GLuint(aData), 3, GLenum(GL_FLOAT), GLboolean(GL_FALSE), stride,
                                  UnsafeRawPointer(bitPattern: MemoryLayout<Float>.size * 3))
        }
        glEnable(GLenum(GL_BLEND))
        glBlendFunc(GLenum(GL_ONE), GLenum(GL_ONE_MINUS_SRC_ALPHA))
        glDrawArrays(GLenum(GL_POINTS), 0, GLsizei(list.count))
        glDisable(GLenum(GL_BLEND))
        if aPos >= 0 { glDisableVertexAttribArray(GLuint(aPos)) }
        if aData >= 0 { glDisableVertexAttribArray(GLuint(aData)) }
        glBindBuffer(GLenum(GL_ARRAY_BUFFER), 0)
    }

    private func drawModelLayer(_ l: Layer, scene: Scene, time: Float, ar: Float) {
        guard let path = l.imagePath else { return }
        let lower = path.lowercased()
        if lower.hasSuffix(".vdb") {
            drawVdbLayer(l, path: path, scene: scene, time: time)
            return
        }
        guard let model = modelFor(path), let p = meshProg else { return }

        let (vp, _) = cameraVP(l, scene: scene, time: time)
        p.use()
        setMat4(p, "uVP", vp)
        let m = modelMatrix(l, time: time, model: model)
        setMat4(p, "uModel", m)

        // Real depth buffer for the model: the layer targets have none, so without it triangles were
        // drawn in file order and any concave / multi-part model looked scrambled.
        var depthOn = false
        if let tgt = layerA {
            let rb = modelDepthBuffer(tgt.width, tgt.height)
            if rb != 0 {
                glFramebufferRenderbuffer(GLenum(GL_FRAMEBUFFER), GLenum(GL_DEPTH_ATTACHMENT), GLenum(GL_RENDERBUFFER), rb)
                if glCheckFramebufferStatus(GLenum(GL_FRAMEBUFFER)) == GLenum(GL_FRAMEBUFFER_COMPLETE) {
                    depthOn = true
                    glDisable(GLenum(GL_SCISSOR_TEST))
                    glDepthMask(GLboolean(GL_TRUE))
                    glClearDepthf(1)
                    glClear(GLbitfield(GL_DEPTH_BUFFER_BIT))
                    glEnable(GLenum(GL_DEPTH_TEST))
                    glDepthFunc(GLenum(GL_LEQUAL))
                } else {
                    glFramebufferRenderbuffer(GLenum(GL_FRAMEBUFFER), GLenum(GL_DEPTH_ATTACHMENT), GLenum(GL_RENDERBUFFER), 0)
                }
            }
        }
        glDisable(GLenum(GL_CULL_FACE))
        model.draw(p, eye: GlbModel.eye(fromVP: vp))
        if depthOn {
            glDisable(GLenum(GL_DEPTH_TEST))
            glFramebufferRenderbuffer(GLenum(GL_FRAMEBUFFER), GLenum(GL_DEPTH_ATTACHMENT), GLenum(GL_RENDERBUFFER), 0)
        }
    }

    private var modelDepthRB = GLuint(0)
    private var modelDepthSize = (0, 0)

    private func modelDepthBuffer(_ w: Int, _ h: Int) -> GLuint {
        if modelDepthRB != 0 && modelDepthSize == (w, h) { return modelDepthRB }
        if modelDepthRB != 0 { glDeleteRenderbuffers(1, &modelDepthRB); modelDepthRB = 0 }
        var rb = GLuint(0)
        glGenRenderbuffers(1, &rb)
        glBindRenderbuffer(GLenum(GL_RENDERBUFFER), rb)
        glRenderbufferStorage(GLenum(GL_RENDERBUFFER), GLenum(0x81A6) /* DEPTH_COMPONENT24 */, GLsizei(w), GLsizei(h))
        glBindRenderbuffer(GLenum(GL_RENDERBUFFER), 0)
        modelDepthRB = rb
        modelDepthSize = (w, h)
        return rb
    }

    private func drawVdbLayer(_ l: Layer, path: String, scene: Scene, time: Float) {
        guard let vol = volumeFor(path), let p = vdbProg else { return }
        let (vp, _) = cameraVP(l, scene: scene, time: time)
        p.use()
        setMat4(p, "uVP", vp)
        setMat4(p, "uModel", modelMatrix(l, time: time, model: nil))
        p.setFloat("uBx", vol.bounds.0)
        p.setFloat("uBy", vol.bounds.1)
        p.setFloat("uBz", vol.bounds.2)
        p.setVec4("uColor", 0.75, 0.85, 1, 0.35)
        Gl.drawQuad(p)
    }

    // MARK: - groups

    private func poolTarget(_ d: Int) -> Gl.Target? {
        while groupPool.count <= d { groupPool.append(Gl.Target(width, height)) }
        return groupPool[d]
    }

    /// A group is a precomp: its children render into a private transparent buffer (so nothing
    /// outside the children's own pixels is ever touched), then the mask, the group's effects,
    /// opacity and blend mode are applied to that result as one image.
    private func drawGroup(_ g: Layer, project: Project, scene: Scene, time: Float, target: Gl.Target,
                           ar: Float, visited: inout [Layer: Bool]) {
        let children = scene.layers.filter { $0.parentId == g.id }
        guard !children.isEmpty else { return }
        let opacity = g.p("opacity", time)
        let hasFx = !g.fx.isEmpty

        guard g.precomp || g.mask != 0 || hasFx, groupDepth < 4, let grp = poolTarget(groupDepth) else {
            // flat group: children composite straight onto the target
            for c in children {
                drawLayer(c, project: project, scene: scene, time: time, target: target, ar: ar, visited: &visited)
            }
            return
        }
        groupDepth += 1
        defer { groupDepth -= 1 }

        grp.bind()
        glClearColor(0, 0, 0, 0)
        glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
        for c in children {
            drawLayer(c, project: project, scene: scene, time: time, target: grp, ar: ar, visited: &visited)
        }

        // mask buffer = first child's content
        if g.mask != 0, let first = children.first, first.isRenderable() {
            layerB!.bind()
            glClearColor(0, 0, 0, 0)
            glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
            var v: [Layer: Bool] = [:]
            renderLayerContent(first, scene: scene, time: time, ar: ar, visited: &v, target: grp)
            applyEffects(first, time: time)
            composite(grp, src: grp.tex, mask: layerB!.tex, maskMode: g.mask, alpha: 1, mode: 0)
        }

        // the group's own effects run on the flattened precomp
        layerA!.bind()
        glDisable(GLenum(GL_BLEND))
        blit(grp.tex)
        glEnable(GLenum(GL_BLEND))
        if hasFx { applyEffects(g, time: time) }
        composite(target, src: layerA!.tex, alpha: opacity, mode: g.blend)
    }

    // MARK: - effects

    /// Effect programs are context-bound — this renderer compiles and caches
    /// its own copies, recording failures into Registry.errors for the UIs.
    private func effectProgram(_ d: EffectDef) -> GLProgram? {
        if let p = effectProgs[d.id] { return p }
        if failedProgs.contains(d.id) { return nil }
        let (src, _) = Gl.effectShaderSource(d)
        guard let p = GLProgram(vertex: GLProgram.defaultVertex, fragment: src) else {
            Registry.noteError(d.id, Gl.lastShaderLog)
            failedProgs.insert(d.id)
            return nil
        }
        effectProgs[d.id] = p
        return p
    }

    private func applyEffects(_ l: Layer, time: Float) {
        guard !l.fx.isEmpty else { return }
        var readTex = layerA!.tex
        var readIsA = true

        for entry in l.fx {
            if l.fxOff.contains(entry) { continue }
            guard let d = Registry.get(entry) else { continue }
            let write = readIsA ? layerB! : layerA!
            if d.id == "deepglow" {
                if applyDeepGlow(l, entry: entry, def: d, read: readTex, write: write, time: time) {
                    readTex = write.tex
                    readIsA = !readIsA
                }
                continue
            }
            guard let p = effectProgram(d) else { continue }

            p.use()
            p.setTexture("uTex", readTex, 0)
            p.setVec2("uRes", Float(write.width), Float(write.height))
            p.setFloat("uTime", time)
            p.setFloat("uHas0", 0)
            p.setFloat("uHas1", 0)

            // layer inputs (in0/in1): the referenced layer's content, small
            var keepAlive: [Gl.Target] = []
            for (slot, nm) in d.inputs.enumerated() where slot < 2 {
                let rid = l.inputs[entry + ":" + nm]
                if let rid = rid, let ref = Editor.scene.layers.first(where: { $0.id == rid }),
                   ref.isRenderable(), let t = inTargets[slot] {
                    t.bind()
                    glClearColor(0, 0, 0, 0)
                    glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
                    var v: [Layer: Bool] = [:]
                    renderLayerContent(ref, scene: Editor.scene, time: time,
                                       ar: Float(width) / Float(max(height, 1)),
                                       visited: &v, target: sceneTarget!)
                    p.setTexture(slot == 0 ? "uIn0" : "uIn1", t.tex, GLint(1 + slot))
                    p.setFloat(slot == 0 ? "uHas0" : "uHas1", 1)
                    keepAlive.append(t)
                } else {
                    p.setFloat(slot == 0 ? "uHas0" : "uHas1", 0)
                }
            }
            _ = keepAlive

            // params
            let single = d.kind == 1
            for pd in d.props {
                let key = single ? pd.key : entry + "__" + pd.key
                p.setFloat(pd.key, paramValue(l, key: key, def: pd.def, time: time))
            }
            for cp in d.colors {
                let base = single ? cp.key : entry + "__" + cp.key
                let defC = UInt32(bitPattern: cp.def)
                p.setVec4(cp.key,
                          colorComp(l, key: base + "_r", def: Float((defC >> 16) & 0xFF) / 255, time: time),
                          colorComp(l, key: base + "_g", def: Float((defC >> 8) & 0xFF) / 255, time: time),
                          colorComp(l, key: base + "_b", def: Float(defC & 0xFF) / 255, time: time),
                          colorComp(l, key: base + "_a", def: Float((defC >> 24) & 0xFF) / 255, time: time))
            }

            write.bind()
            glDisable(GLenum(GL_BLEND))
            Gl.drawFull(p)
            glEnable(GLenum(GL_BLEND))

            readTex = write.tex
            readIsA = !readIsA
        }

        // ensure the chain's result is in layerA for compositing
        if readTex != layerA!.tex {
            layerA!.bind()
            glDisable(GLenum(GL_BLEND))
            blit(readTex)
            glEnable(GLenum(GL_BLEND))
        }
    }

    // MARK: - Deep Glow (multi-pass bloom)

    private var glowProgs: [GLProgram] = []          // extract, down, blur, final
    private var glowLevels: [Gl.Target] = []
    private var glowTmp: [Gl.Target] = []
    private var glowBlur: [Gl.Target] = []
    private var glowSize = (0, 0)
    private static let glowN = 7

    private func glowSetup() -> Bool {
        if glowProgs.isEmpty {
            let hdr = "precision highp float;\nprecision highp sampler2D;\nvarying vec2 vUv;\n"
            let extract = hdr + """
uniform sampler2D uTex; uniform vec2 uPx; uniform float uThr, uKnee;
vec4 tap(vec2 uv) {
    vec4 t = min(texture2D(uTex, uv), vec4(16.0));
    // threshold on the premultiplied (over black) brightness: dividing by alpha made every
    // faint pixel of a glow/flare count as full white, which blew the whole area out
    float l = max(max(t.r, t.g), t.b);
    float knee = uThr * uKnee + 0.0001;
    float sf = clamp(l - uThr + knee, 0.0, 2.0 * knee);
    sf = sf * sf / (4.0 * knee);
    float k = max(sf, l - uThr) / max(l, 0.0001);
    return t * clamp(k, 0.0, 1.0);
}
void main() {
    vec2 o = uPx * 0.5;
    vec4 a = tap(vUv + vec2(-o.x, -o.y)) + tap(vUv + vec2(o.x, -o.y))
           + tap(vUv + vec2(-o.x, o.y)) + tap(vUv + vec2(o.x, o.y));
    gl_FragColor = a * 0.25;
}
"""
            let down = hdr + """
uniform sampler2D uTex; uniform vec2 uPx;
void main() {
    vec2 o = uPx * 0.5;
    gl_FragColor = (texture2D(uTex, vUv + vec2(-o.x, -o.y)) + texture2D(uTex, vUv + vec2(o.x, -o.y))
                  + texture2D(uTex, vUv + vec2(-o.x, o.y)) + texture2D(uTex, vUv + vec2(o.x, o.y))) * 0.25;
}
"""
            let blur = hdr + """
uniform sampler2D uTex; uniform vec2 uStep;
void main() {
    vec4 c = texture2D(uTex, vUv) * 0.2270270270;
    c += (texture2D(uTex, vUv + uStep * 1.3846153846) + texture2D(uTex, vUv - uStep * 1.3846153846)) * 0.3162162162;
    c += (texture2D(uTex, vUv + uStep * 3.2307692308) + texture2D(uTex, vUv - uStep * 3.2307692308)) * 0.0702702703;
    gl_FragColor = c;
}
"""
            // final: original + (accumulated glow). Only two textures are read.
            let fin = hdr + """
uniform sampler2D uTex; uniform sampler2D uG;
uniform float uGain, uChroma, uOnly, uTintAmt;
uniform vec4 uTintCol;
void main() {
    vec4 c = texture2D(uTex, vUv);
    vec4 g = texture2D(uG, vUv);
    if (uChroma > 0.001) {
        vec2 dir = (vUv - 0.5) * uChroma * 0.04;
        g.r = texture2D(uG, vUv + dir).r;
        g.b = texture2D(uG, vUv - dir).b;
    }
    g = clamp(g * uGain, 0.0, 64.0);
    if (!(g.r == g.r) || !(g.g == g.g) || !(g.b == g.b) || !(g.a == g.a)) { g = vec4(0.0); }
    float gl = max(g.r, max(g.g, g.b));
    g.rgb = mix(g.rgb, uTintCol.rgb * gl, uTintAmt);
    // linear for normal values (slope 1), soft shoulder only for very hot values
    vec3 add = g.rgb / (1.0 + g.rgb * 0.18);
    float n = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715)))) - 0.5;
    add += n * (1.0 / 255.0) * min(1.0, g.a * 4.0);
    add = max(add, 0.0);
    float base = uOnly > 0.5 ? 0.0 : 1.0;
    vec3 rgb = c.rgb * base + add;
    float ga = max(clamp(g.a, 0.0, 1.0), max(add.r, max(add.g, add.b)));
    float a = clamp(c.a * base + ga * (1.0 - c.a * base), 0.0, 1.0);
    gl_FragColor = vec4(rgb, a);
}
"""
            // accumulate: acc[k] = blur[k] * w + upsample(acc[k+1])
            let up = hdr + """
uniform sampler2D uA; uniform sampler2D uB; uniform float uW;
void main() { gl_FragColor = texture2D(uA, vUv) * uW + texture2D(uB, vUv); }
"""
            let scale = hdr + """
uniform sampler2D uA; uniform float uW;
void main() { gl_FragColor = texture2D(uA, vUv) * uW; }
"""
            for src in [extract, down, blur, fin, up, scale] {
                guard let p = GLProgram(vertex: GLProgram.defaultVertex, fragment: src) else { return false }
                glowProgs.append(p)
            }
        }
        if glowSize != (width, height) || glowLevels.isEmpty {
            glowLevels = []; glowTmp = []; glowBlur = []
            for k in 0..<SceneRenderer.glowN {
                let div = 2 << k
                let w = max(2, width / div), h = max(2, height / div)
                glowLevels.append(Gl.Target(w, h, half: true))
                glowTmp.append(Gl.Target(w, h, half: true))
                glowBlur.append(Gl.Target(w, h, half: true))
            }
            glowSize = (width, height)
        }
        return true
    }

    /// Deep Glow: threshold → downsample chain → separable Gaussian per level → weighted
    /// recombine. Smooth at every radius (no per-pixel sampling noise).
    private func applyDeepGlow(_ l: Layer, entry: String, def d: EffectDef, read: GLuint,
                               write: Gl.Target, time: Float) -> Bool {
        guard glowSetup() else { return false }
        let single = d.kind == 1
        func val(_ key: String, _ def: Float) -> Float {
            paramValue(l, key: single ? key : entry + "__" + key, def: def, time: time)
        }
        let radius = max(0, val("radius", 0.12))
        let intensity = max(0, val("intensity", 1))
        let thr = min(max(val("threshold", 0.3), 0), 0.999)
        let knee = min(max(val("knee", 0.5), 0), 1)
        let falloff = min(max(val("falloff", 0.5), 0), 1)
        let tintAmt = min(max(val("tintAmt", 0), 0), 1)
        let tintHue = val("tintHue", 0.08)
        let chromaAb = min(max(val("chroma", 0), 0), 1)
        let glowOnly = val("glowOnly", 0)
        let N = SceneRenderer.glowN
        glDisable(GLenum(GL_BLEND))
        glDisable(GLenum(GL_SCISSOR_TEST)); glDisable(GLenum(GL_CULL_FACE)); glDisable(GLenum(GL_DEPTH_TEST))
        glColorMask(GLboolean(GL_TRUE), GLboolean(GL_TRUE), GLboolean(GL_TRUE), GLboolean(GL_TRUE))

        // 1) bright pass → level 0 (half res)
        let ex = glowProgs[0]
        ex.use()
        ex.setTexture("uTex", read, 0)
        ex.setVec2("uPx", 1 / Float(width), 1 / Float(height))
        ex.setFloat("uThr", thr)
        ex.setFloat("uKnee", knee)
        Gl.renderQuad(ex, glowLevels[0])

        // 2) downsample chain
        let dn = glowProgs[1]
        for k in 1..<N {
            dn.use()
            dn.setTexture("uTex", glowLevels[k - 1].tex, 0)
            dn.setVec2("uPx", 1 / Float(glowLevels[k - 1].width), 1 / Float(glowLevels[k - 1].height))
            Gl.renderQuad(dn, glowLevels[k])
        }

        // 3) separable Gaussian on every level
        let bl = glowProgs[2]
        for k in 0..<N {
            let lv = glowLevels[k]
            bl.use()
            bl.setTexture("uTex", lv.tex, 0)
            bl.setVec2("uStep", 1 / Float(lv.width), 0)
            Gl.renderQuad(bl, glowTmp[k])
            bl.setTexture("uTex", glowTmp[k].tex, 0)
            bl.setVec2("uStep", 0, 1 / Float(lv.height))
            Gl.renderQuad(bl, glowBlur[k])
        }

        // 4) level weights follow the radius continuously (log-space gaussian)
        let sigmaPx = max(radius, 0.0005) * Float(height) * 0.2
        let pos = min(max(log2(max(sigmaPx, 1) / 4), 0), Float(N - 1))
        var w = [Float](repeating: 0, count: N)
        var sum: Float = 0
        for k in 0..<N {
            let dk = Float(k) - pos
            let sg = 0.55 + falloff * 1.6
            w[k] = exp(-dk * dk / (2 * sg * sg))
            sum += w[k]
        }
        // Normalise to the strongest level (not the sum): dividing by the sum spread the energy
        // over all levels and made the glow collapse as the radius grew.
        let wMax = max(w.max() ?? 1, 0.0001)
        for k in 0..<N { w[k] = w[k] / wMax * 0.9 }
        _ = sum

        // 5) accumulate from the smallest level up (each pass reads at most two textures;
        //    results go into glowTmp, which is free once the blur is done)
        let sc = glowProgs[5], upP = glowProgs[4]
        sc.use()
        sc.setTexture("uA", glowBlur[N - 1].tex, 0)
        sc.setFloat("uW", w[N - 1])
        Gl.renderQuad(sc, glowTmp[N - 1])
        for k in stride(from: N - 2, through: 0, by: -1) {
            upP.use()
            upP.setTexture("uA", glowBlur[k].tex, 0)
            upP.setTexture("uB", glowTmp[k + 1].tex, 1)
            upP.setFloat("uW", w[k])
            Gl.renderQuad(upP, glowTmp[k])
        }

        let f = glowProgs[3]
        f.use()
        f.setTexture("uTex", read, 0)
        f.setTexture("uG", glowTmp[0].tex, 1)
        f.setFloat("uGain", intensity * 1.6)
        f.setFloat("uChroma", chromaAb)
        f.setFloat("uOnly", glowOnly)
        f.setFloat("uTintAmt", tintAmt)
        var tr: CGFloat = 1, tg: CGFloat = 1, tb: CGFloat = 1, ta: CGFloat = 1
        UIColor(hue: CGFloat(tintHue - floor(tintHue)), saturation: 1, brightness: 1, alpha: 1).getRed(&tr, green: &tg, blue: &tb, alpha: &ta)
        f.setVec4("uTintCol", Float(tr), Float(tg), Float(tb), 1)
        Gl.renderQuad(f, write)
        glEnable(GLenum(GL_BLEND))
        return true
    }

    private func paramValue(_ l: Layer, key: String, def: Float, time: Float) -> Float {
        if let tr = l.props[key] {
            return tr.evalExpr(l.editTime(key, time), time, tr.exprActive() ? Editor.scene.markersByName() : [:])
        }
        return def
    }

    private func colorComp(_ l: Layer, key: String, def: Float, time: Float) -> Float {
        if let tr = l.props[key] {
            return tr.eval(l.editTime(key, time))
        }
        return def
    }

    // MARK: - composite

    /// Composites `src` over `target`'s current content (through the
    /// scratch buffer — never read+write the same texture in one pass).
    private func composite(_ target: Gl.Target, src: GLuint, alpha: Float, mode: Int,
                           rgbShift: Float = 0) {
        composite(target, src: src, mask: 0, maskMode: 0, alpha: alpha, mode: mode, rgbShift: rgbShift)
    }

    private func composite(_ target: Gl.Target, src: GLuint, mask: GLuint, maskMode: Int,
                           alpha: Float, mode: Int, rgbShift: Float = 0) {
        guard let p = compositeProg, let scratch = scratchTarget else { return }
        scratch.bind()
        glDisable(GLenum(GL_BLEND))
        p.use()
        p.setTexture("uScene", target.tex, 0)
        p.setTexture("uSrc", src, 1)
        p.setTexture("uMask", mask, 2)
        p.setFloat("uAlpha", alpha)
        p.setFloat("uMode", Float(mode))
        p.setFloat("uMaskMode", Float(maskMode))
        p.setFloat("uRgbShift", rgbShift)
        Gl.drawFull(p)

        target.bind()
        blit(scratch.tex)
    }

    // MARK: - helpers

    /// Image layers → GL textures, kept in a byte-budgeted LRU. (The old cache held 24
    /// textures, evicted without deleting them on the GPU, and so thrashed — re-decoding
    /// PNGs every frame and leaking GPU memory — as soon as a scene had more than 24
    /// images. That was the lag + crash with ~60 layers.)
    private func imageTexture(_ path: String) -> GLuint {
        // textures never need more pixels than the working resolution (plus headroom
        // for zoomed layers); this also keeps decoded size small for big canvases
        let side = max(384, 1536 / max(1, quality))
        if side != imageTexSide { flushImageTextures(); imageTexSide = side }
        if let t = imageTex[path] {
            if imageTexOrder.last != path {
                if let i = imageTexOrder.firstIndex(of: path) { imageTexOrder.remove(at: i) }
                imageTexOrder.append(path)
            }
            return t
        }
        var made: GLuint = 0
        var bytes = 0
        autoreleasepool {
            guard let img = UIImage(contentsOfFile: path) else { return }
            bytes = Gl.uploadBytes(img, maxSide: side)
            made = Gl.upload(img, maxSide: side) ?? 0
        }
        if made == 0 { return 0 }
        imageTex[path] = made
        imageTexBytes[path] = bytes
        imageTexTotal += bytes
        imageTexOrder.append(path)
        while imageTexTotal > imageTexBudget, imageTexOrder.count > 1 {
            let old = imageTexOrder.removeFirst()
            if let t = imageTex.removeValue(forKey: old) { Gl.delete(t) }
            imageTexTotal -= imageTexBytes.removeValue(forKey: old) ?? 0
        }
        return made
    }

    private func flushImageTextures() {
        EAGLContext.setCurrent(context)
        for (_, t) in imageTex { Gl.delete(t) }
        imageTex.removeAll(); imageTexBytes.removeAll(); imageTexOrder.removeAll()
        imageTexTotal = 0
    }

    /// Drops every cached image texture (memory warning / leaving the editor).
    func trimMemory() { flushImageTextures() }

    private func samplerFor(_ l: Layer) -> VideoFrames.Sampler {
        if let s = videoSamplers[l.id] { return s }
        let s = VideoFrames.Sampler(path: l.imagePath ?? "")
        videoSamplers[l.id] = s
        return s
    }

    private var failedModels = Set<String>()

    private func modelFor(_ path: String) -> GlbModel? {
        if let m = models[path] { return m }
        if failedModels.contains(path) { return nil }      // never re-parse a broken file every frame
        let p = GlbModel.validate(path: path)
        guard let m = GlbModel.load(p) else {
            failedModels.insert(path)
            return nil
        }
        models[path] = m
        models[p] = m
        return m
    }

    private func volumeFor(_ path: String) -> VdbVolume? {
        if let v = volumes[path] { return v }
        guard let v = VdbVolume.load(path) else { return nil }
        volumes[path] = v
        return v
    }

    /// Source-media time for a video layer at scene time `t` (remap aware).
    private func sourceTime(_ l: Layer, _ t: Float) -> Float {
        if let tr = l.props["remapT"], !tr.keys.isEmpty {
            return max(0, tr.eval(t) + l.srcOffset)
        }
        let sp = l.props["remapSpeed"]?.eval(t) ?? 1
        return max(0, (t - l.start) * sp + l.srcOffset)
    }

    /// Draws the layer's quad with its world matrix (2D path).
    private func drawLayerQuad(_ l: Layer, time: Float, program: GLProgram) {
        let (qw, qh) = Xf.quadSize(l)
        let m = Xf.matrix(l, time)
        program.setMat3("uMat", m)
        program.setVec2("uQuad", qw, qh)
        program.setFloat("uAspect", Float(width) / Float(max(height, 1)))
        if l.is3d {
            let lt = l.editTime("x", time)
            let d = Float.pi / 180
            program.setVec3("uRot", l.p("rotX", lt) * d, -l.p("rotY", lt) * d, 0)
            program.setFloat("uZ", Xf.worldZ(l, time))
            let (vp, hasCam) = cameraVP(l, scene: Editor.scene, time: time)
            if hasCam {
                program.setFloat("uUseVP", 1)
                setMat4(program, "uVP", vp)
            } else {
                program.setFloat("uUseVP", 0)
            }
            program.setFloat("uInvCam", 1.0 / 3.0)
        } else {
            program.setFloat("uUseVP", 0)
            program.setVec3("uRot", 0, 0, 0)
            program.setFloat("uZ", 0)
            program.setFloat("uInvCam", 0)
        }
        Gl.drawQuad(program)
    }

    // MARK: - matrices / cameras

    /// Scene Setup mode (the top-bar orbit camera): while set, every 3D layer
    /// is drawn through this editing camera instead of the scene camera. The
    /// active camera layer is never touched, so leaving the mode restores the
    /// exact previous view. Layout: [fov°, eyeX, eyeY, eyeZ, rotX°, rotY°].
    static var editCam: [Float]? = nil

    private func cameraVP(_ l: Layer, scene: Scene, time: Float) -> ([Float], Bool) {
        let ar = Float(width) / Float(max(height, 1))
        if let e = SceneRenderer.editCam {
            return (perspectiveLookAt(e[0], ar, e[1], e[2], e[3],
                                      e[4] * Float.pi / 180, e[5] * Float.pi / 180), true)
        }
        if let cam = Xf.camera(for: l) {
            let ct = cam.editTime("x", time)
            let fov = cam.p("fov", ct)
            // z is an offset from the neutral distance at which the z=0 plane exactly fills the
            // comp (visible half-height 1, same as 2D layers) — so adding a camera never zooms
            let neutral = 1 / tan(fov * Float.pi / 360)
            let ex = cam.p("x", ct), ey = cam.p("y", ct), ez = cam.p("z", ct) + neutral
            let rx = cam.p("rotX", ct) * Float.pi / 180
            let ry = cam.p("rotY", ct) * Float.pi / 180
            let rz = cam.p("rotZ", ct) * Float.pi / 180
            return (perspectiveLookAt(fov, ar, ex, ey, ez, rx, ry, rz), true)
        }
        // default: camera at z = 3 looking at origin
        return (perspectiveLookAt(scene.fov, ar, 0, 0, 3, 0, 0), false)
    }

    private func modelMatrix(_ l: Layer, time: Float, model: GlbModel?) -> [Float] {
        let lt = l.editTime("x", time)
        let s = l.p("scale", lt)
        let norm = model?.normalize ?? [1, 0, 0, 0]
        let x = l.p("x", lt)
        let y = l.p("y", lt)
        let z = Xf.worldZ(l, time)
        let rx = l.p("rotX", lt) * Float.pi / 180
        let ry = l.p("rotY", lt) * Float.pi / 180
        let rz = l.p("rotZ", lt) * Float.pi / 180
        let sc = s * norm[0]

        var m = identity4()
        m = mul4(rotY4(ry), m)
        m = mul4(rotX4(rx), m)
        m = mul4(rotZ4(rz), m)
        m = mul4(scale4(sc, sc, sc), m)
        // M = T(pos) * R * S * T(-centre): the model turns around its OWN centre (it used to turn
        // around its file origin, so off-centre models orbited wildly and drifted when rotated)
        let ox = norm[1], oy = norm[2], oz = norm[3]
        m[12] = x + m[0] * ox + m[4] * oy + m[8] * oz
        m[13] = y + m[1] * ox + m[5] * oy + m[9] * oz
        m[14] = z + m[2] * ox + m[6] * oy + m[10] * oz
        return m
    }

    private func perspectiveLookAt(_ fovDeg: Float, _ ar: Float,
                                   _ ex: Float, _ ey: Float, _ ez: Float,
                                   _ rx: Float, _ ry: Float, _ rz: Float = 0) -> [Float] {
        let f = 1 / tan(fovDeg * Float.pi / 360)
        let near: Float = 0.05, far: Float = 100
        let nf = 1 / (near - far)
        var p = identity4()
        p[0] = f / ar
        p[5] = f
        p[10] = (far + near) * nf
        p[11] = -1
        p[14] = 2 * far * near * nf
        p[15] = 0

        var v = identity4()
        // orbit: world yaw first, then pitch, then roll about the view axis
        v = mul4(rotY4(-ry), v)
        v = mul4(rotX4(-rx), v)
        v = mul4(rotZ4(-rz), v)
        v[12] = -ex; v[13] = -ey; v[14] = -ez

        return mul4(p, v)
    }

    private func setMat4(_ p: GLProgram, _ name: String, _ m: [Float]) {
        let l = p.loc(name)
        if l >= 0 {
            m.withUnsafeBufferPointer { ptr in
                glUniformMatrix4fv(l, 1, GLboolean(GL_FALSE), ptr.baseAddress)
            }
        }
    }

    // MARK: - programs

    /// Transforming quad vertex shader (layer matrix, quad size, aspect).
    /// The transform used to sit in the FRAGMENT shader, where gl_Position
    /// does not exist: the shader never compiled and nothing was ever drawn.
    static let layerQuadVertex = """
attribute vec2 aPos;
uniform mat3 uMat;
uniform vec2 uQuad;
uniform float uAspect;
uniform vec3 uRot;
uniform float uZ;
uniform float uInvCam;
uniform mat4 uVP;
uniform float uUseVP;
varying vec2 vUv;
void main() {
    vUv = aPos * 0.5 + 0.5;
    vec2 w = (uMat * vec3((vUv - 0.5) * uQuad, 1.0)).xy;
    vec2 c = (uMat * vec3(0.0, 0.0, 1.0)).xy;
    vec3 o = vec3(w - c, 0.0);
    float cy = cos(uRot.y), sy = sin(uRot.y);
    o = vec3(o.x * cy + o.z * sy, o.y, -o.x * sy + o.z * cy);
    float cx = cos(uRot.x), sx = sin(uRot.x);
    o = vec3(o.x, o.y * cx - o.z * sx, o.y * sx + o.z * cx);
    vec3 pos = vec3(c + o.xy, o.z + uZ);
    if (uUseVP > 0.5) {
        vec4 cl = uVP * vec4(pos, 1.0);
        if (cl.w < 0.02) { gl_Position = vec4(2.0, 2.0, 0.0, 1.0); }   // behind the camera
        else { gl_Position = vec4(cl.xy, 0.0, cl.w); }
    } else {
        gl_Position = vec4(pos.x / uAspect, pos.y, 0.0, 1.0 - pos.z * uInvCam);
    }
}
"""

    private static let quadVertex = """
attribute vec2 aPos;
varying vec2 vUv;
void main() {
    vUv = aPos * 0.5 + 0.5;
    gl_Position = vec4(aPos, 0.0, 1.0);
}
"""

    /// Builds (once) the pipeline shaders. Call with the context current.
    func buildPrograms() {
        if quadProg != nil { return }

        quadProg = GLProgram(vertex: SceneRenderer.layerQuadVertex, fragment: """
precision mediump float;
varying vec2 vUv;
uniform sampler2D uTex;
uniform float uFlipY;
uniform vec4 uColor;
void main() {
    vec2 p = vec2(vUv.x, mix(vUv.y, 1.0 - vUv.y, uFlipY));
    gl_FragColor = texture2D(uTex, p) * uColor;
}
""")
        if quadProg == nil { CrashLog.note("quadProg FAILED: " + Gl.lastShaderLog) }
        shapeProg = GLProgram(vertex: """
attribute vec2 aPos;
uniform mat3 uMat;
uniform vec2 uQuad;
uniform float uAspect;
varying vec2 vQ;
void main() {
    vec2 lc = (aPos * 0.5 + 0.5 - 0.5) * uQuad;
    vQ = lc;
    vec2 w = (uMat * vec3(lc, 1.0)).xy;
    gl_Position = vec4(w.x / uAspect, w.y, 0.0, 1.0);
}
""", fragment: """
precision mediump float;
varying vec2 vQ;
uniform vec4 uColor;
uniform float uKind;
uniform float uCornerRadius;
uniform vec2 uQuadSize;
void main() {
    vec2 q = vQ;
    float a = 0.0;
    if (uKind < 0.5) { a = 1.0; }
    else if (uKind < 1.5) {
        vec2 d = abs(q) - (uQuadSize * 0.5 - vec2(uCornerRadius));
        float outD = length(max(d, 0.0)) + min(max(d.x, d.y), 0.0) - uCornerRadius;
        a = 1.0 - smoothstep(-0.004, 0.004, outD);
    }
    else if (uKind < 2.5) {
        a = 1.0 - smoothstep(0.48 * min(uQuadSize.x, uQuadSize.y), 0.5 * min(uQuadSize.x, uQuadSize.y), length(q));
    }
    else if (uKind < 3.5) {
        vec2 v1 = vec2(-uQuadSize.x * 0.5, -uQuadSize.y * 0.5) - q;
        vec2 v2 = vec2(uQuadSize.x * 0.5, -uQuadSize.y * 0.5) - q;
        vec2 v3 = q - vec2(-uQuadSize.x * 0.5, -uQuadSize.y * 0.5);
        float s1 = v1.x * v2.y - v1.y * v2.x;
        float s2 = v2.x * v3.y - v2.y * v3.x;
        float s3 = v3.x * -v1.y - v3.y * -v1.x;
        a = ((s1 >= 0.0 && s2 >= 0.0 && s3 >= 0.0) || (s1 <= 0.0 && s2 <= 0.0 && s3 <= 0.0)) ? 1.0 : 0.0;
    }
    else {
        float n = 5.0;
        float a0 = atan(q.y, q.x) + 1.5708;
        float seg = 6.2831 / n;
        float rIn = 0.22 * min(uQuadSize.x, uQuadSize.y);
        float rOut = 0.5 * min(uQuadSize.x, uQuadSize.y);
        float ang = mod(a0, seg) - seg * 0.5;
        float rLim = mix(rOut, rIn, abs(ang) / (seg * 0.5));
        a = 1.0 - smoothstep(rLim - 0.01, rLim + 0.01, length(q));
    }
    gl_FragColor = vec4(uColor.rgb * a, uColor.a * a);
}
""")

        flareProg = GLProgram(vertex: SceneRenderer.quadVertex, fragment: """
precision highp float;
varying vec2 vUv;
uniform vec2 uLight;
uniform float uIntensity, uAxis, uSizeMul, uEdgeFade, uAspect, uCount, uTime, uFlicker, uSpeed, uRayAmt;
uniform vec4 uTint;
uniform vec4 uA[16];
uniform vec4 uB[16];
uniform vec4 uC[16];
uniform vec4 uD[16];
uniform vec4 uE[16];
uniform vec4 uCol[16];

float hn(float x) { return fract(sin(x * 127.1) * 43758.5453); }
float vn(float x) { float i = floor(x); float f = fract(x); f = f * f * (3.0 - 2.0 * f); return mix(hn(i), hn(i + 1.0), f); }
vec3 hsv2rgb(vec3 c) {
    vec3 p = abs(fract(c.xxx + vec3(1.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0);
    return c.z * mix(vec3(1.0), clamp(p - 1.0, 0.0, 1.0), c.y);
}

// procedural iris: radius (vertex = 1) of the polygon / star / flower at angle a
float irisR(float a, float n, float round, float star, float curve) {
    float seg = 6.28318 / n;
    float t = mod(a, seg);
    float hs = seg * 0.5;
    float phi = abs(t - hs);
    float cosH = cos(hs);
    float sinH = sin(hs);
    float inner = mix(cosH, 0.12, star);
    float den = cos(phi) * sinH - sin(phi) * (cosH - inner);
    float r = min(inner * sinH / max(den, 0.05), 2.0);
    float u = phi / hs;
    r *= 1.0 + curve * 0.25 * (1.0 - u * u);
    float rc = (inner + 1.0) * 0.5;
    return mix(r, rc, round);
}

float irisMask(vec2 d, float size, float n, float round, float star, float curve,
               float thick, float soft, float grad) {
    float a = atan(d.y, d.x) + 1.5708;
    float R = irisR(a, n, round, star, curve) * size;
    float x = length(d) / max(R, 0.0001);
    float edge = 0.02 + soft * 0.6;
    float outer = 1.0 - smoothstep(1.0 - edge, 1.0, x);
    float hole = mix(smoothstep(1.0 - thick - edge, 1.0 - thick + 0.001, x), 1.0, step(0.99, thick));
    return outer * hole * mix(1.0, x * x, grad);
}

void main() {
    vec2 asp = vec2(uAspect, 1.0);
    vec2 p = vUv * asp;
    vec2 L = uLight * asp;
    vec2 ax = (vec2(0.5) * asp - L) * uAxis;
    float axLen = length(ax);
    float axAng = atan(ax.y, ax.x);
    vec3 acc = vec3(0.0);

    for (int i = 0; i < 16; i++) {
        float t = uA[i].x;
        if (t < -0.5 || float(i) + 0.5 > uCount) { continue; }
        float pos = uA[i].y;
        float size = min(uA[i].z * uSizeMul, 3.0);
        float bright = uB[i].x;
        float soft = uB[i].y;
        float thick = uB[i].z;
        float stretch = uB[i].w;
        float sides = uC[i].x;
        float rays = uC[i].y;
        float chroma = uC[i].z;
        float follow = uC[i].w;
        float noise = uE[i].x;

        float ang = radians(uA[i].w) + follow * axAng * smoothstep(0.03, 0.3, axLen) + uE[i].y * 1.2 * axLen;
        vec2 d = p - (L + ax * pos);
        float ca = cos(ang);
        float sa = sin(ang);
        d = vec2(ca * d.x + sa * d.y, -sa * d.x + ca * d.y);
        float r = length(d);

        // PERFORMANCE: skip every pixel that is outside the element's reach. Without this each
        // pixel evaluated up to 16 elements (atan/pow/iris x3, multi-iris x8) -> heavy lag.
        bool multi = t > 13.5 && t < 14.5;
        if (!multi && r > size * max(stretch, 1.0) * 2.6 + 0.01) { continue; }
        if (bright * uIntensity < 0.002) { continue; }

        vec3 m = vec3(0.0);
        if (t < 0.5) {                                  // Glow
            vec2 q = vec2(d.x / stretch, d.y);
            float x = length(q) / max(size, 0.001);
            float g = exp(-pow(x, mix(2.0, 0.85, soft)) * 4.5) * (1.0 - smoothstep(0.85, 1.0, x));
            // real lens glare: hot core + long inverse-square wings (like the reference photos)
            float wing = (1.0 / (1.0 + x * x * 24.0)) * (1.0 - smoothstep(0.55, 1.0, x));
            g = mix(g, g * 0.6 + wing * 0.5, soft);
            m = vec3(g);
        } else if (t < 1.5 || (t > 4.5 && t < 5.5) || (t > 12.5 && t < 13.5)) {   // Polygon / Ring polygon / Iris
            float st = 0.0; float rd = 0.0; float cv = 0.0; float gr = uD[i].w; float th = thick; float sf = soft;
            if (t > 12.5) { rd = uD[i].x; st = uD[i].y; cv = uD[i].z; }
            else { th = t < 1.5 ? max(thick, 0.3) : thick; gr = 0.3; sf = 0.12; }
            vec2 q = vec2(d.x / stretch, d.y);
            float k = chroma * 0.07;
            m = vec3(irisMask(q, size * (1.0 + k), sides, rd, st, cv, th, sf, gr),
                     irisMask(q, size, sides, rd, st, cv, th, sf, gr),
                     irisMask(q, size * (1.0 - k), sides, rd, st, cv, th, sf, gr));
            if (chroma > 0.01) { m *= vec3(1.0, 0.85, 1.0); }
        } else if (t < 2.5) {                            // Line
            vec2 s = vec2(size * stretch * 0.5, size * 0.5 * max(thick, 0.01));
            vec2 qq = abs(d) - s;
            float e = 0.004 + soft * 0.03;
            m = vec3(1.0 - smoothstep(-e, e, length(max(qq, 0.0)) + min(max(qq.x, qq.y), 0.0)));
        } else if (t < 3.5) {                            // Rays (soft beams)
            float n = max(rays, 2.0);
            float a = atan(d.y, d.x);
            float beam = pow(abs(cos(a * n * 0.5)), 28.0);
            float rad = exp(-r / max(size * 0.35, 0.001)) * (1.0 - smoothstep(size * 0.6, size, r));
            m = vec3(beam * rad * 0.7 * uRayAmt);
        } else if (t < 4.5) {                            // Ring
            float R = size * 0.5;
            float w = max(thick, 0.01) * R;
            float e = 0.004 + soft * 0.02;
            float k = chroma * 0.06;
            vec3 rr = vec3(r / (1.0 + k), r, r / (1.0 - k));
            if (thick >= 0.95) { m = 1.0 - smoothstep(R * (1.0 - soft * 0.5) - e, R + e, rr); }
            else { m = 1.0 - smoothstep(w * 0.5 - e, w * 0.5 + e, abs(rr - R)); }
        } else if (t < 6.5) {                            // Dot
            float R = size * 0.5;
            m = vec3(1.0 - smoothstep(R * (1.0 - soft * 0.8), R, r));
        } else if (t < 7.5) {                            // Glint: smooth starburst
            float n = max(rays, 2.0);
            float a = atan(d.y, d.x);
            float seg = 6.28318 / n;
            float idx = mod(floor(a / seg + 0.5), n);
            float fr = (fract(a / seg + 0.5) - 0.5) * seg;
            float lenv = mix(1.0, 0.6 + 0.4 * hn(idx * 3.7 + uE[i].z), noise * 0.6);
            float len = size * 0.5 * lenv;
            float w = mix(0.018, 0.075, soft);
            float beam = exp(-(fr * fr) / (w * w));
            float rad = exp(-r / max(len * 0.45, 0.001)) * (1.0 - smoothstep(len * 0.55, len, r));
            float core = exp(-r / max(size * 0.05, 0.001)) * 0.7;
            m = vec3(beam * rad * 0.8 * uRayAmt + core);
        } else if (t < 8.5) {                            // Hoop
            float R = size * 0.5;
            float w = max(thick, 0.02) * R * 0.5;
            float k = chroma * 0.07;
            vec3 rr = vec3(r / (1.0 + k), r, r / (1.0 - k));
            vec3 z = (rr - R) / w;
            m = exp(-z * z * (1.0 + (1.0 - soft) * 3.0));
        } else if (t < 9.5) {                            // Streak (anamorphic)
            float len = size * stretch * 0.5;
            float wy = size * 0.5 * max(thick, 0.01) * 0.35 + 0.002;
            float hx = exp(-abs(d.x) / max(len * (0.12 + 0.5 * soft), 0.001));
            float vy = exp(-(d.y / wy) * (d.y / wy));
            m = vec3(hx * vy * (1.0 - smoothstep(len * 0.8, len * 1.2, abs(d.x))));
        } else if (t < 10.5) {                           // Spike ball: fine smooth spikes
            float n = max(rays, 3.0) * 2.0;
            float a = atan(d.y, d.x);
            float seg = 6.28318 / n;
            float idx = mod(floor(a / seg + 0.5), n);
            float fr = (fract(a / seg + 0.5) - 0.5) * seg;
            float lenv = mix(1.0, 0.45 + 0.55 * hn(idx * 5.3 + uE[i].z), noise * 0.7);
            float len = size * 0.5 * lenv;
            float w = mix(0.012, 0.04, soft);
            float beam = exp(-(fr * fr) / (w * w));
            float rad = exp(-r / max(len * 0.4, 0.001)) * (1.0 - smoothstep(len * 0.6, len, r));
            float core = exp(-pow(r / max(size * 0.12, 0.001), 1.2) * 2.0);
            m = vec3(beam * rad * 0.6 * uRayAmt + core * 0.9);
        } else if (t < 11.5) {                           // Rainbow
            float x = r / max(size * 0.5, 0.001);
            float inner = 1.0 - thick * 0.7;
            float band = smoothstep(inner, inner + 0.12, x) * (1.0 - smoothstep(0.92, 1.0, x));
            vec3 spec = hsv2rgb(vec3(clamp((1.0 - (x - inner) / max(1.0 - inner, 0.05)) * 0.75, 0.0, 0.8), 0.9, 1.0));
            m = band * mix(vec3(1.0), spec, 0.25 + 0.75 * chroma);
        } else if (t > 14.5) {                           // Arc: partial lens ring with colour fringe
            float R = size * 0.5;
            float w = max(thick, 0.02) * R * 0.5;
            float k = chroma * 0.07;
            vec3 rr = vec3(r / (1.0 + k), r, r / (1.0 - k));
            vec3 z = (rr - R) / w;
            float aa = atan(d.y, d.x);
            float hs = clamp(uE[i].w, 0.02, 1.0) * 3.14159;
            float am = 1.0 - smoothstep(hs * (1.0 - soft), hs, abs(aa));
            m = exp(-z * z * (1.0 + (1.0 - soft) * 3.0)) * am;
        } else if (t > 13.5) {                           // Multi iris: a chain of ghost irises
            float cnt = clamp(rays, 2.0, 8.0);
            vec3 mm = vec3(0.0);
            for (int k = 0; k < 8; k++) {
                float fk = float(k);
                if (fk + 0.5 > cnt) { break; }
                float h1 = hn(fk * 12.9 + uE[i].z);
                float h2 = hn(fk * 7.7 + uE[i].z + 3.0);
                vec2 dk = p - (L + ax * (pos + fk * uE[i].w));
                dk = vec2(ca * dk.x + sa * dk.y, -sa * dk.x + ca * dk.y);
                float szk = size * (1.0 - noise * 0.6 * h1) * (1.0 - 0.06 * fk);
                float mk = irisMask(vec2(dk.x / stretch, dk.y), szk, sides, uD[i].x, uD[i].y, uD[i].z,
                                    max(thick, 0.05), soft, uD[i].w);
                vec3 spec = hsv2rgb(vec3(fract(0.08 + fk * 0.17 + h2 * 0.1), 0.65, 1.0));
                vec3 tk = mix(vec3(1.0), spec, chroma * 0.9);
                mm += mk * tk * (0.55 + 0.45 * h2) / (1.0 + 0.12 * fk);
            }
            m = mm;
        } else {                                         // Shimmer
            float x = r / max(size, 0.001);
            float a = atan(d.y, d.x);
            float g = exp(-pow(x, 1.2) * 3.5) * (1.0 - smoothstep(0.9, 1.0, x));
            float nz = vn(a * rays * 0.35 + 20.0 + uTime * uSpeed * 1.2) * 0.7
                     + vn(a * rays * 0.9 + uTime * uSpeed * 2.3) * 0.5;
            m = vec3(g * (0.45 + nz * 1.1 * (0.25 + noise)));
        }

        float fl = 1.0 + uFlicker * (vn(uTime * uSpeed * 9.0 + float(i) * 3.1) - 0.5) * 0.7;
        acc += uCol[i].rgb * uTint.rgb * m * bright * fl;
    }

    // the whole flare fades as the light leaves the frame
    vec2 lp = uLight;
    float outside = max(max(-lp.x, lp.x - 1.0), max(-lp.y, lp.y - 1.0));
    outside = max(outside - 0.12, 0.0);                 // never fades while the light is on or near the frame
    float vis = 1.0 - smoothstep(0.0, max(uEdgeFade, 0.05) + 0.25, outside);
    acc = clamp(acc, 0.0, 60.0) * uIntensity * vis;

    // soft highlight roll-off keeps hot colours from clipping to flat white
    vec3 o = vec3(1.0) - exp(-acc * 1.1);
    float lum = max(o.r, max(o.g, o.b));
    o = mix(o, vec3(lum), smoothstep(0.55, 1.0, lum) * 0.45);   // hot cores bleed to white like film
    float dn = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715)))) - 0.5;
    o = max(o + dn * (1.0 / 255.0) * step(0.002, o), 0.0);
    gl_FragColor = vec4(o, max(o.r, max(o.g, o.b)));
}
""")

        particleProg = GLProgram(vertex: """
attribute vec3 aPos;
attribute vec3 aData;
uniform mat4 uVP;
uniform float uAspect;
uniform float uOrtho;
uniform float uSize;
uniform float uPx;
uniform float uOpacity;
uniform float uFadeIn;
uniform float uFadeOut;
uniform vec4 uColA;
uniform vec4 uColB;
varying vec4 vCol;
varying float vLife;
varying float vOp;
varying float vSoft;
varying float vFi;
varying float vFo;
varying float vPS;
void main() {
    vOp = uOpacity;
    vFi = uFadeIn;
    vFo = uFadeOut;
    float k = 1.0;
    if (uOrtho > 0.5) {
        gl_Position = vec4(aPos.x / uAspect, aPos.y, 0.0, 1.0);
    } else {
        vec4 c = uVP * vec4(aPos, 1.0);
        gl_Position = c;
        k = 3.0 / max(c.w, 0.05);
    }
    vSoft = aData.z;
    float ps = max(4.0, uSize * uPx * aData.x * k * (1.0 + aData.z * 0.35));
    gl_PointSize = ps;
    vPS = ps;
    vLife = aData.y;
    vCol = mix(uColA, uColB, clamp(aData.y, 0.0, 1.0));
}
""", fragment: """
precision mediump float;
varying vec4 vCol;
varying float vLife;
varying float vOp;
varying float vSoft;
varying float vFi;
varying float vFo;
varying float vPS;
void main() {
    vec2 c = gl_PointCoord - 0.5;
    float d = length(c);
    float aa = 1.5 / max(vPS, 3.0);
    float a = 1.0 - smoothstep(mix(0.5 - aa, 0.0, vSoft), 0.5, d);   // edge0 < edge1 (reversed edges are undefined in GLSL)
    float fade = smoothstep(0.0, vFi, vLife) * (1.0 - smoothstep(1.0 - vFo, 1.0, vLife));
    a *= fade * vOp * vCol.a;
    gl_FragColor = vec4(vCol.rgb * a, a);
}
""")

        meshProg = GLProgram(vertex: GlbModel.vertexSource, fragment: GlbModel.fragmentSource)

        vdbProg = GLProgram(vertex: SceneRenderer.quadVertex, fragment: """
precision mediump float;
varying vec2 vUv;
uniform mat4 uVP;
uniform mat4 uModel;
uniform float uBx;
uniform float uBy;
uniform float uBz;
uniform vec4 uColor;
void main() {
    float best = 0.0;
    for (int i = 0; i < 8; i++) {
        float z = (float(i) / 7.0 - 0.5) * uBz;
        vec3 p = vec3((vUv.x - 0.5) * uBx, (vUv.y - 0.5) * uBy, z);
        vec4 w = uModel * vec4(p, 1.0);
        vec4 clip = uVP * w;
        float depth = clamp((clip.z / max(abs(clip.w), 0.0001)) * 0.5 + 0.5, 0.0, 1.0);
        float d = length(vUv - 0.5);
        float ring = smoothstep(0.5, 0.35, d);
        best = max(best, ring * (0.25 + 0.75 * (1.0 - depth)));
    }
    gl_FragColor = vec4(uColor.rgb * best, uColor.a * best);
}
""")

        compositeProg = GLProgram(vertex: SceneRenderer.quadVertex, fragment: """
precision mediump float;
varying vec2 vUv;
uniform sampler2D uScene;
uniform sampler2D uSrc;
uniform sampler2D uMask;
uniform float uAlpha;
uniform float uMode;      // 0 normal 1 add 2 screen 3 multiply 4 accumulate 5 running average
uniform float uMaskMode;  // 0 none 1 alpha 2 inv alpha 3 luma 4 inv luma
uniform float uRgbShift;
void main() {
    vec4 s = texture2D(uSrc, vUv);
    if (uRgbShift != 0.0) {
        s.r = texture2D(uSrc, clamp(vUv + vec2(uRgbShift, 0.0), 0.0, 1.0)).r;
        s.b = texture2D(uSrc, clamp(vUv - vec2(uRgbShift, 0.0), 0.0, 1.0)).b;
    }
    vec4 sRaw = s;
    s *= uAlpha;
    if (uMode > 4.5) {
        // running average: acc = mix(acc, sample, 1/(i+1)). Keeps full precision in 8-bit
        // targets (additive 1/N accumulation rounds dim pixels to 0 → visible opacity steps)
        gl_FragColor = mix(texture2D(uScene, vUv), sRaw, uAlpha);
        return;
    }
    if (uMaskMode > 0.5) {
        vec4 mk = texture2D(uMask, vUv);
        float m = 1.0;
        if (uMaskMode < 1.5) { m = mk.a; }
        else if (uMaskMode < 2.5) { m = 1.0 - mk.a; }
        else if (uMaskMode < 3.5) { m = dot(mk.rgb, vec3(0.299, 0.587, 0.114)); }
        else { m = 1.0 - dot(mk.rgb, vec3(0.299, 0.587, 0.114)); }
        s *= m;
    }
    vec4 d = texture2D(uScene, vUv);
    if (uMode < 0.5) {
        gl_FragColor = s + d * (1.0 - s.a);
    } else if (uMode < 1.5) {
        gl_FragColor = d + s;
    } else if (uMode < 2.5) {
        vec3 scr = 1.0 - (1.0 - d.rgb) * (1.0 - s.rgb);
        gl_FragColor = mix(d, vec4(scr, max(d.a, s.a)), s.a);
    } else if (uMode < 3.5) {
        vec3 mul = d.rgb * s.rgb;
        gl_FragColor = mix(d, vec4(mul, d.a * s.a), s.a);
    } else {
        gl_FragColor = d + s;
    }
}
""")
    }

    // MARK: - math

    private func identity4() -> [Float] {
        [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]
    }

    private func scale4(_ x: Float, _ y: Float, _ z: Float) -> [Float] {
        [x, 0, 0, 0, 0, y, 0, 0, 0, 0, z, 0, 0, 0, 0, 1]
    }

    private func rotX4(_ a: Float) -> [Float] {
        let c = cos(a), s = sin(a)
        return [1, 0, 0, 0, 0, c, s, 0, 0, -s, c, 0, 0, 0, 0, 1]
    }

    private func rotY4(_ a: Float) -> [Float] {
        let c = cos(a), s = sin(a)
        return [c, 0, -s, 0, 0, 1, 0, 0, s, 0, c, 0, 0, 0, 0, 1]
    }

    private func rotZ4(_ a: Float) -> [Float] {
        let c = cos(a), s = sin(a)
        return [c, s, 0, 0, -s, c, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]
    }

    /// a * b (column-major, OpenGL order).
    private func mul4(_ a: [Float], _ b: [Float]) -> [Float] {
        var o = [Float](repeating: 0, count: 16)
        for c in 0..<4 {
            for r in 0..<4 {
                var s: Float = 0
                for k in 0..<4 {
                    s += a[k * 4 + r] * b[c * 4 + k]
                }
                o[c * 4 + r] = s
            }
        }
        return o
    }
}

// MARK: - mat3 upload

extension GLProgram {
    func setMat3(_ name: String, _ m0: [Float]) {
        let l = loc(name)
        // Xf matrices are 2D affines [a b c d tx ty]; GL needs 9 floats
        // (column-major). Passing 6 made GL read garbage => the skew.
        let m: [Float] = m0.count == 6
            ? [m0[0], m0[1], 0, m0[2], m0[3], 0, m0[4], m0[5], 1] : m0
        if l >= 0 {
            m.withUnsafeBufferPointer { ptr in
                glUniformMatrix3fv(l, 1, GLboolean(GL_FALSE), ptr.baseAddress)
            }
        }
    }
}
