// SceneRenderer.swift — the compositor (Render).
//
// Draws a scene at time `t` into an offscreen target and hands back the
// texture. Pipeline per layer: content (image/video/text/shape/flare/
// particles/model/vdb/adjustment) → effect chain (ping-pong GLSL passes,
// one per applied effect, uniforms from the layer's tracks) → composite
// onto the scene buffer with the blend mode. Motion blur renders the layer
// at sub-times and accumulates. 3D layers and models project through the
// nearest camera above them.
//
// The same renderer drives the live preview, the effect thumbnails and the
// exporter — one look everywhere.

import Foundation
import OpenGLES
import GLKit
import UIKit

// MARK: - video source

/// Frame provider for video layers (preview: async buckets; export: sync).
protocol VideoSource: AnyObject {
    func videoTexture(layerId: Int, path: String, srcTime: Float) -> GLuint
    func videoFrameArrived() -> Bool
}

// MARK: - renderer

final class SceneRenderer {

    let context: EAGLContext
    var quality = 1                 // 1 full, 2 half, 4 quarter

    // targets (lazily sized)
    private(set) var sceneTarget: Gl.Target?
    private var scratchTarget: Gl.Target?      // composite intermediate
    private var layerA: Gl.Target?
    private var layerB: Gl.Target?
    private var accumTarget: Gl.Target?
    private var groupTarget: Gl.Target?
    private var inTargets: [Gl.Target?] = [nil, nil]

    private(set) var width = 576
    private(set) var height = 1024

    // programs
    private var quadProg: GLProgram?          // textured quad (premult)
    private var shapeProg: GLProgram?
    private var flareProg: GLProgram?
    private var particleProg: GLProgram?
    private var meshProg: GLProgram?
    private var vdbProg: GLProgram?
    private var compositeProg: GLProgram?

    // caches
    private var imageTex: [String: GLuint] = [:]
    private var imageTexBytes: [String: Int] = [:]
    private var imageTexOrder: [String] = []        // least recently used first
    private var imageTexTotal = 0
    private var imageTexSide = 0
    private let imageTexBudget = 360 * 1_048_576    // GPU memory for image layers
    private var videoSamplers: [Int: VideoFrames.Sampler] = [:]
    private var models: [String: GlbModel] = [:]
    private var volumes: [String: VdbVolume] = [:]
    private var effectProgs: [String: GLProgram] = [:]
    private var failedProgs = Set<String>()

    private var videoSource: VideoSource?

    init(context: EAGLContext) {
        self.context = context
    }

    // MARK: - entry

    /// Renders `scene` and returns the scene texture (owned by the renderer).
    func draw(project: Project, scene: Scene, time: Float, video: VideoSource?) -> GLuint {
        videoSource = video
        let ar = Float(project.w) / Float(max(project.h, 1))
        height = 1024 / max(1, quality)
        width = max(2, Int(Float(height) * ar))

        if sceneTarget == nil || sceneTarget!.width != width || sceneTarget!.height != height {
            sceneTarget = Gl.Target(width, height)
            scratchTarget = Gl.Target(width, height)
            layerA = Gl.Target(width, height)
            layerB = Gl.Target(width, height)
            accumTarget = Gl.Target(width, height)
            groupTarget = Gl.Target(width, height)
            let iw = 256
            let ih = max(2, Int(Float(256) / ar))
            inTargets = [Gl.Target(iw, ih), Gl.Target(iw, ih)]
        }

        EAGLContext.setCurrent(context)
        buildPrograms()

        // clear scene with bg
        sceneTarget!.bind()
        glClearColor(Float((UInt32(bitPattern: scene.bg) >> 16) & 0xFF) / 255,
                     Float((UInt32(bitPattern: scene.bg) >> 8) & 0xFF) / 255,
                     Float(UInt32(bitPattern: scene.bg) & 0xFF) / 255, 1)
        glClear(GLbitfield(GL_COLOR_BUFFER_BIT))

        var visited: [Layer: Bool] = [:]
        for l in scene.layers {
            drawLayer(l, project: project, scene: scene, time: time, target: sceneTarget!, ar: ar,
                      visited: &visited)
        }

        return sceneTarget!.tex
    }

    /// The composited frame as an image (thumbnails / export readback).
    func snapshot() -> UIImage? {
        sceneTarget?.readImage()
    }

    /// Blits a texture to the currently bound framebuffer + viewport (the
    /// preview's drawable). Call with this renderer's context current.
    func present(_ tex: GLuint, flipY: Bool = false) {
        guard let p = quadProg else { return }
        p.use()
        p.setFloat("uFlipY", flipY ? 1 : 0)
        p.setVec4("uColor", 1, 1, 1, 1)
        p.setMat3("uMat", [1, 0, 0, 0, 1, 0, 0, 0, 1])
        let ar = Float(width) / Float(max(height, 1))
        p.setVec2("uQuad", ar * 2, 2)
        p.setFloat("uAspect", ar)
        p.setTexture("uTex", tex, 0)
        Gl.drawQuad(p)
    }

    // MARK: - per-layer

    private func drawLayer(_ l: Layer, project: Project, scene: Scene, time: Float,
                           target: Gl.Target, ar: Float, visited: inout [Layer: Bool]) {
        guard l.visible else { return }
        guard time >= l.start - 0.001 && time <= l.end + 0.001 else { return }
        if visited[l] != nil { return }
        visited[l] = true
        defer { visited[l] = nil }

        switch l.type {
        case .AUDIO, .CAMERA, .NULL:
            return
        case .GROUP:
            if (l.mblur || (Xf.camera(for: l)?.mblur ?? false)) && l.mask == 0 {
                drawBlurredGroup(l, project: project, scene: scene, time: time, target: target, ar: ar,
                                 visited: &visited)
            } else {
                drawGroup(l, project: project, scene: scene, time: time, ar: ar, visited: &visited)
            }
            return
        default:
            break
        }

        let opacity = l.p("opacity", l.editTime("opacity", time))

        // motion blur: accumulate sub-time renders. A camera with motion blur on
        // blurs every 3D layer below it (so camera moves blur everything).
        let blurOn = l.mblur || (Xf.camera(for: l)?.mblur ?? false)
        var mbSamples = 1
        let amount = l.p("mbAmount", time)
        let shutter = 0.12 * amount
        if blurOn {
            let cap = min(Int(max(2, l.p("mbSamples", time))), 64)
            let camMoves = (Xf.camera(for: l) != nil) && (l.is3d || l.type == .MODEL || l.type == .PARTICLES)
            let content = l.type == .VIDEO || l.type == .PARTICLES || l.type == .MODEL || l.type == .FLARE || !l.fx.isEmpty || camMoves
            // samples follow the real on-screen travel (projected through the camera VP) so the
            // copies always overlap: ~1 sample per pixel travelled, clamped 8...64
            let px = screenTravel(l, time: time, shutter: shutter)
            if px >= 0.5 {
                mbSamples = min(64, max(8, Int(px.rounded(.up)) + 1))
            } else if content {
                mbSamples = min(cap, 12)
            }
        }
        if mbSamples > 1 {
            let stutter = l.mbStutter
            accumTarget!.bind()
            glClearColor(0, 0, 0, 0)
            glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
            for s in 0..<mbSamples {
                let u = (Float(s) + mbJitter(s, time)) / Float(mbSamples)
                var st = time - shutter * (u - 0.5)
                if stutter { st = time - shutter * 0.5 * round(Float(s) / Float(max(mbSamples - 1, 1)) - 0.5) }
                let clamped = clamp(st, l.start, l.end)
                renderLayerContent(l, scene: scene, time: clamped, ar: ar, visited: &visited,
                                   target: target)
                applyEffects(l, time: clamped)
                let frac = u - 0.5
                composite(accumTarget!, src: layerA!.tex, alpha: 1 / Float(s + 1), mode: 5,
                          rgbShift: l.mbRgb ? frac * 0.004 * amount : 0)
            }
            composite(target, src: accumTarget!.tex, alpha: opacity, mode: l.blend)
        } else if (l.type == .IMAGE || l.type == .VIDEO) && l.blend == 0 && l.mask == 0 && l.fx.isEmpty {
            // Fast path (the common case: a plain image/video layer): one blended quad
            // straight into the scene. The general path below costs four full-screen
            // passes and three render-target switches per layer, which is what made scenes
            // with dozens of layers crawl on a tile-based GPU.
            if opacity <= 0.0005 { return }
            target.bind()
            glEnable(GLenum(GL_BLEND))
            glBlendFunc(GLenum(GL_ONE), GLenum(GL_ONE_MINUS_SRC_ALPHA))
            drawMediaLayer(l, time: time, opacity: opacity)
            glDisable(GLenum(GL_BLEND))
        } else {
            renderLayerContent(l, scene: scene, time: time, ar: ar, visited: &visited, target: target)
            applyEffects(l, time: time)
            composite(target, src: layerA!.tex, alpha: opacity, mode: l.blend)
        }
    }

    /// Stable per-frame jitter in [0,1) for stratified blur sampling (hash of sample + frame).
    private func mbJitter(_ s: Int, _ time: Float) -> Float {
        var h = UInt32(truncatingIfNeeded: s &* 73856093) ^ UInt32(truncatingIfNeeded: Int(time * 1000) &* 19349663)
        h = (h ^ (h >> 13)) &* 1274126177
        h ^= h >> 16
        return Float(h & 0xFFFF) / 65536
    }

    /// Max on-screen distance (pixels) any quad corner/centre travels between
    /// time - shutter/2 and time + shutter/2, including camera motion.
    private func screenTravel(_ l: Layer, time: Float, shutter: Float) -> Float {
        let (qw, qh) = Xf.quadSize(l)
        let ar = Float(width) / Float(max(height, 1))
        let halfW = Float(width) * 0.5, halfH = Float(height) * 0.5
        func proj(_ t: Float, _ cx: Float, _ cy: Float) -> (Float, Float)? {
            let m = Xf.matrix(l, t)
            let x = cx * qw, y = cy * qh
            let wx = m[0] * x + m[2] * y + m[4]
            let wy = m[1] * x + m[3] * y + m[5]
            if l.is3d {
                let z = l.p("z", l.editTime("x", t))
                let (vp, has) = cameraVP(l, scene: Editor.scene, time: t)
                if has {
                    let cw = vp[3] * wx + vp[7] * wy + vp[11] * z + vp[15]
                    if cw < 0.02 { return nil }
                    let cxp = vp[0] * wx + vp[4] * wy + vp[8] * z + vp[12]
                    let cyp = vp[1] * wx + vp[5] * wy + vp[9] * z + vp[13]
                    return (cxp / cw, cyp / cw)
                }
                let w = 1 - z / 3
                if w < 0.02 { return nil }
                return (wx / ar / w, wy / w)
            }
            return (wx / ar, wy)
        }
        var best: Float = 0
        let pts: [(Float, Float)] = [(-0.5, -0.5), (0.5, -0.5), (-0.5, 0.5), (0.5, 0.5), (0, 0)]
        for (cx, cy) in pts {
            guard let a = proj(time - shutter * 0.5, cx, cy), let b = proj(time + shutter * 0.5, cx, cy) else { continue }
            let dx = (a.0 - b.0) * halfW, dy = (a.1 - b.1) * halfH
            best = max(best, (dx * dx + dy * dy).squareRoot())
        }
        return best
    }

    /// Motion blur for a whole group: children are rendered at several sub-times
    /// and averaged, so everything inside the group blurs together.
    private func drawBlurredGroup(_ g: Layer, project: Project, scene: Scene, time: Float,
                                  target: Gl.Target, ar: Float, visited: inout [Layer: Bool]) {
        let children = scene.layers.filter { $0.parentId == g.id }
        guard !children.isEmpty, let accum = accumTarget, let grp = groupTarget else { return }
        let amount = g.p("mbAmount", time)
        let shutter = 0.12 * amount
        var travel: Float = 0
        for c in children { travel = max(travel, screenTravel(c, time: time, shutter: shutter)) }
        let n = travel >= 0.5 ? min(48, max(8, Int(travel.rounded(.up)) + 1))
                              : min(Int(max(2, g.p("mbSamples", time))), 12)
        let opacity = g.p("opacity", time)
        accum.bind()
        glClearColor(0, 0, 0, 0)
        glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
        for s in 0..<n {
            let st = clamp(time - shutter * ((Float(s) + mbJitter(s, time)) / Float(n) - 0.5), g.start, g.end)
            grp.bind()
            glClearColor(0, 0, 0, 0)
            glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
            for c in children {
                drawLayer(c, project: project, scene: scene, time: st, target: grp, ar: ar, visited: &visited)
            }
            composite(accum, src: grp.tex, alpha: 1 / Float(s + 1), mode: 5, rgbShift: 0)
        }
        composite(target, src: accum.tex, alpha: opacity, mode: g.blend)
    }

    // MARK: - content

    private func renderLayerContent(_ l: Layer, scene: Scene, time: Float, ar: Float,
                                    visited: inout [Layer: Bool], target: Gl.Target) {
        layerA!.bind()
        glClearColor(0, 0, 0, 0)
        glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
        glDisable(GLenum(GL_BLEND))

        switch l.type {
        case .IMAGE, .VIDEO:
            drawMediaLayer(l, time: time)
        case .TEXT:
            drawTextLayer(l, time: time)
        case .SHAPE:
            // "Particles" added from the + menu is a Shape layer carrying the particles effect
            if l.fx.contains("particles") && !l.fxOff.contains("particles") {
                if l.p("pShowSrc", l.editTime("pShowSrc", time)) >= 0.5 {
                    drawShapeLayer(l, time: time)
                }
                drawParticleLayer(l, time: time)
            } else {
                drawShapeLayer(l, time: time)
            }
        case .FLARE:
            drawFlareLayer(l, time: time)
        case .PARTICLES:
            if l.p("pShowSrc", l.editTime("pShowSrc", time)) >= 0.5 {
                drawShapeLayer(l, time: time)
            }
            drawParticleLayer(l, time: time)
        case .MODEL:
            drawModelLayer(l, scene: scene, time: time, ar: ar)
        case .ADJUST:
            // content = the current accumulation buffer (scene or group)
            blit(target.tex)
        default:
            break
        }
        glEnable(GLenum(GL_BLEND))
    }

    /// Fullscreen copy of `tex` into the currently bound target.
    private func blit(_ tex: GLuint) {
        guard let p = quadProg else { return }
        p.use()
        p.setFloat("uFlipY", 0)
        p.setVec4("uColor", 1, 1, 1, 1)
        p.setMat3("uMat", [1, 0, 0, 0, 1, 0, 0, 0, 1])
        p.setVec2("uQuad", Float(width) / Float(max(height, 1)) * 2, 2)
        p.setFloat("uAspect", Float(width) / Float(max(height, 1)))
        p.setTexture("uTex", tex, 0)
        Gl.drawQuad(p)
    }

    private func drawMediaLayer(_ l: Layer, time: Float, opacity: Float = 1) {
        guard let path = l.imagePath else { return }
        var tex: GLuint = 0
        if l.type == .VIDEO {
            let srcT = sourceTime(l, time)
            if let vs = videoSource {
                tex = vs.videoTexture(layerId: l.id, path: path, srcTime: srcT)
            } else {
                let s = samplerFor(l)
                tex = s.texture(at: srcT)
            }
        }
        if tex == 0 {
            tex = imageTexture(path)
        }
        guard tex != 0 else { return }
        if let p = quadProg {
            p.use()
            p.setFloat("uFlipY", 1)
            p.setVec4("uColor", opacity, opacity, opacity, opacity)
            p.setTexture("uTex", tex, 0)
            drawLayerQuad(l, time: time, program: p)
        }
    }

    private func drawTextLayer(_ l: Layer, time: Float) {
        let img = TextRaster.raster(l, time)
        guard img.size.width > 1, img.size.height > 1, let tex = Gl.upload(img) else { return }
        defer { Gl.delete(tex) }
        if let p = quadProg {
            p.use()
            p.setFloat("uFlipY", 1)
            p.setVec4("uColor", 1, 1, 1, 1)
            p.setTexture("uTex", tex, 0)
            drawLayerQuad(l, time: time, program: p)
        }
    }

    private func drawShapeLayer(_ l: Layer, time: Float) {
        guard let p = shapeProg else { return }
        let (qw, qh) = Xf.quadSize(l)
        let m = Xf.matrix(l, time)
        p.use()
        p.setMat3("uMat", m)
        p.setVec2("uQuad", qw, qh)
        p.setFloat("uAspect", Float(width) / Float(max(height, 1)))
        let c = l.color
        p.setVec4("uColor",
                  Float((UInt32(bitPattern: c) >> 16) & 0xFF) / 255,
                  Float((UInt32(bitPattern: c) >> 8) & 0xFF) / 255,
                  Float(UInt32(bitPattern: c) & 0xFF) / 255,
                  Float((UInt32(bitPattern: c) >> 24) & 0xFF) / 255)
        var kind = 0
        switch l.shape {
        case .RECT: kind = 0
        case .ROUND: kind = 1
        case .CIRCLE: kind = 2
        case .TRIANGLE: kind = 3
        case .STAR: kind = 4
        }
        p.setFloat("uKind", Float(kind))
        p.setFloat("uCornerRadius", 0.12)
        Gl.drawQuad(p)
    }

    private func drawFlareLayer(_ l: Layer, time: Float) {
        guard let f = l.flare, let p = flareProg else { return }
        let ar = Float(width) / Float(max(height, 1))
        let lt = l.editTime("x", time)
        let fx = l.p("x", lt) / ar / 2 + 0.5       // 0..1 across the canvas
        let fy = 0.5 - l.p("y", lt) / 2
        let intensity = l.p("fIntensity", lt)
        let axis = l.p("fAxis", lt)

        p.use()
        p.setVec2("uLight", fx, fy)
        p.setFloat("uIntensity", intensity)
        p.setFloat("uAxis", axis)
        p.setVec4("uTint",
                  Float((UInt32(bitPattern: f.tint) >> 16) & 0xFF) / 255,
                  Float((UInt32(bitPattern: f.tint) >> 8) & 0xFF) / 255,
                  Float(UInt32(bitPattern: f.tint) & 0xFF) / 255,
                  Float((UInt32(bitPattern: f.tint) >> 24) & 0xFF) / 255)
        p.setFloat("uDepthScale", f.depthScale)
        p.setFloat("uEdgeFade", f.edgeFade)
        p.setFloat("uAspect", ar)
        let n = min(f.els.count, 12)
        p.setFloat("uCount", Float(n))
        let dead = FlareEl(0)
        for i in 0..<12 {
            let e = i < n ? f.els[i] : dead
            p.setFloat("uElType[\(i)]", Float(e.enabled ? e.type : -1))
            p.setVec2("uEl[\(i)]", e.pos, e.size)
            p.setFloat("uElRot[\(i)]", e.rot)
            p.setFloat("uElBright[\(i)]", e.bright)
            p.setFloat("uElSoft[\(i)]", e.soft)
            p.setFloat("uElThick[\(i)]", e.thick)
            p.setFloat("uElStretch[\(i)]", e.stretch)
            p.setFloat("uElSides[\(i)]", Float(e.sides))
            p.setFloat("uElRays[\(i)]", Float(e.rays))
            p.setFloat("uElChroma[\(i)]", e.chroma)
            p.setFloat("uElFollow[\(i)]", e.follow ? 1 : 0)
            p.setVec4("uElCol[\(i)]",
                      Float((UInt32(bitPattern: e.color) >> 16) & 0xFF) / 255,
                      Float((UInt32(bitPattern: e.color) >> 8) & 0xFF) / 255,
                      Float(UInt32(bitPattern: e.color) & 0xFF) / 255,
                      Float((UInt32(bitPattern: e.color) >> 24) & 0xFF) / 255)
        }
        Gl.drawQuad(p)
    }

    /// Projects a world point with a column-major 4x4: (screen x, screen y, w).
    private func projectPoint(_ vp: [Float], _ x: Float, _ y: Float, _ z: Float) -> (Float, Float, Float) {
        let cx = vp[0] * x + vp[4] * y + vp[8] * z + vp[12]
        let cy = vp[1] * x + vp[5] * y + vp[9] * z + vp[13]
        let cw = vp[3] * x + vp[7] * y + vp[11] * z + vp[15]
        return (cx / max(abs(cw), 0.0001), cy / max(abs(cw), 0.0001), cw)
    }

    private func drawParticleLayer(_ l: Layer, time: Float) {
        guard let p = particleProg else { return }
        let ar = Float(width) / Float(max(height, 1))
        let lt = l.editTime("x", time)
        let field = ParticlesSim.field(count: Int(l.p("pCount", lt)), spread: l.p("pSpread", lt),
                                       speed: l.p("pSpeed", lt), gravity: l.p("pGravity", lt),
                                       life: l.p("pLife", lt), seed: l.p("pSeed", lt),
                                       dirX: l.p("pDirX", lt), dirY: l.p("pDirY", lt), t: time, ar: ar,
                                       posX: l.p("pPosX", lt), posY: l.p("pPosY", lt), posZ: l.p("pPosZ", lt),
                                       radX: l.p("pRadX", lt), radY: l.p("pRadY", lt), radZ: l.p("pRadZ", lt),
                                       dirZ: l.p("pDirZ", lt), resist: l.p("pResist", lt),
                                       wobble: l.p("pWobble", lt), sizeVar: l.p("pSizeVar", lt),
                                       sizeEnd: l.p("pSizeEnd", lt), dof: l.p("pDof", lt),
                                       focus: l.p("pFocus", lt),
                                       burst: l.p("pBurst", lt), burstForce: l.p("pBurstForce", lt))
        let m = Xf.matrix(l, time)
        let scene = Editor.scene
        let (vp, hasCam) = cameraVP(l, scene: scene, time: time)
        let use3D = hasCam || l.is3d
        let occlude = l.p("pOcclude", lt) >= 0.5

        // Occlude: particles behind a 3D layer / model are hidden by it.
        var blockers: [(Float, Float, Float, Float, Float)] = []   // minX, minY, maxX, maxY, z
        if occlude {
            for o in scene.layers where o !== l && o.visible
                && time >= o.start - 0.001 && time <= o.end + 0.001
                && (o.is3d || o.type == .MODEL) && o.isRenderable() && o.type != .PARTICLES {
                let ot = o.editTime("x", time)
                let sc = o.p("scale", ot)
                let (qw, qh) = Xf.quadSize(o)
                let hw = qw * sc * 0.5, hh = qh * sc * 0.5
                let ox = o.p("x", ot), oy = o.p("y", ot), oz = o.p("z", ot)
                var minX = Float.greatestFiniteMagnitude, minY = minX
                var maxX = -Float.greatestFiniteMagnitude, maxY = maxX
                var ok = true
                for (sx, sy) in [(-hw, -hh), (hw, -hh), (hw, hh), (-hw, hh)] {
                    let (px, py, pw) = projectPoint(vp, ox + sx, oy + sy, oz)
                    if pw <= 0.01 { ok = false; break }
                    minX = min(minX, px); maxX = max(maxX, px)
                    minY = min(minY, py); maxY = max(maxY, py)
                }
                if ok { blockers.append((minX, minY, maxX, maxY, oz)) }
            }
        }

        struct Pt { var x: Float; var y: Float; var z: Float; var size: Float; var life: Float; var soft: Float; var w: Float }
        var list: [Pt] = []
        list.reserveCapacity(field.count)
        for q in field {
            var wx = m[0] * q.x + m[2] * q.y + m[4]
            var wy = m[1] * q.x + m[3] * q.y + m[5]
            var sz = q.size
            var w: Float = 1
            if use3D {
                let (sx, sy, pw) = projectPoint(vp, wx, wy, q.z)
                if pw <= 0.05 { continue }
                w = pw
                if occlude {
                    var hidden = false
                    for b in blockers where q.z < b.4 - 0.001 && sx >= b.0 && sx <= b.2 && sy >= b.1 && sy <= b.3 {
                        hidden = true; break
                    }
                    if hidden { continue }
                }
            } else {
                let pf = 1 / max(0.2, 1 - q.z / 3)
                wx *= pf; wy *= pf; sz *= pf
                w = 1 / pf
            }
            list.append(Pt(x: wx, y: wy, z: q.z, size: sz, life: q.life, soft: q.soft, w: w))
        }
        if list.isEmpty { return }
        list.sort { $0.w > $1.w }   // far → near so nearer dots sit on top

        p.use()
        setMat4(p, "uVP", vp)
        p.setFloat("uAspect", ar)
        p.setFloat("uOrtho", use3D ? 0 : 1)
        p.setFloat("uSize", l.p("pSize", lt))
        p.setFloat("uPx", Float(height) * 0.5)
        // particle opacity × the layer's own opacity, plus birth/death fade
        p.setFloat("uOpacity", l.p("pOpacity", lt) * clamp(l.p("opacity", lt), 0, 1))
        p.setFloat("uFadeIn", max(0.001, l.p("pFadeIn", lt)))
        p.setFloat("uFadeOut", max(0.001, l.p("pFadeOut", lt)))
        func pc(_ k: String, _ def: UInt32) -> (Float, Float, Float, Float) {
            (colorComp(l, key: k + "_r", def: Float((def >> 16) & 0xFF) / 255, time: time),
             colorComp(l, key: k + "_g", def: Float((def >> 8) & 0xFF) / 255, time: time),
             colorComp(l, key: k + "_b", def: Float(def & 0xFF) / 255, time: time),
             colorComp(l, key: k + "_a", def: 1, time: time))
        }
        let ca = pc("pColA", 0xFFFFFFFF), cb = pc("pColB", 0xFFFFFFFF)
        p.setVec4("uColA", ca.0, ca.1, ca.2, ca.3)
        p.setVec4("uColB", cb.0, cb.1, cb.2, cb.3)

        var pts = [Float]()
        pts.reserveCapacity(list.count * 6)
        for q in list {
            pts.append(q.x); pts.append(q.y); pts.append(q.z)
            pts.append(q.size); pts.append(q.life); pts.append(q.soft)
        }
        var vbo = GLuint(0)
        glGenBuffers(1, &vbo)
        glBindBuffer(GLenum(GL_ARRAY_BUFFER), vbo)
        pts.withUnsafeBufferPointer { ptr in
            glBufferData(GLenum(GL_ARRAY_BUFFER), MemoryLayout<Float>.size * pts.count,
                         ptr.baseAddress, GLenum(GL_DYNAMIC_DRAW))
        }
        let stride = GLsizei(MemoryLayout<Float>.size * 6)
        let aPos = glGetAttribLocation(p.handle, "aPos")
        let aData = glGetAttribLocation(p.handle, "aData")
        if aPos >= 0 {
            glEnableVertexAttribArray(GLuint(aPos))
            glVertexAttribPointer(GLuint(aPos), 3, GLenum(GL_FLOAT), GLboolean(GL_FALSE), stride, nil)
        }
        if aData >= 0 {
            glEnableVertexAttribArray(GLuint(aData))
            glVertexAttribPointer(GLuint(aData), 3, GLenum(GL_FLOAT), GLboolean(GL_FALSE), stride,
                                  UnsafeRawPointer(bitPattern: MemoryLayout<Float>.size * 3))
        }
        glEnable(GLenum(GL_BLEND))
        glBlendFunc(GLenum(GL_ONE), GLenum(GL_ONE_MINUS_SRC_ALPHA))
        glDrawArrays(GLenum(GL_POINTS), 0, GLsizei(list.count))
        glDisable(GLenum(GL_BLEND))
        if aPos >= 0 { glDisableVertexAttribArray(GLuint(aPos)) }
        if aData >= 0 { glDisableVertexAttribArray(GLuint(aData)) }
        glDeleteBuffers(1, [vbo])
    }

    private func drawModelLayer(_ l: Layer, scene: Scene, time: Float, ar: Float) {
        guard let path = l.imagePath else { return }
        let lower = path.lowercased()
        if lower.hasSuffix(".vdb") {
            drawVdbLayer(l, path: path, scene: scene, time: time)
            return
        }
        guard let model = modelFor(path), let p = meshProg else { return }

        let (vp, _) = cameraVP(l, scene: scene, time: time)
        p.use()
        setMat4(p, "uVP", vp)
        let m = modelMatrix(l, time: time, model: model)
        setMat4(p, "uModel", m)
        model.draw(p)
    }

    private func drawVdbLayer(_ l: Layer, path: String, scene: Scene, time: Float) {
        guard let vol = volumeFor(path), let p = vdbProg else { return }
        let (vp, _) = cameraVP(l, scene: scene, time: time)
        p.use()
        setMat4(p, "uVP", vp)
        setMat4(p, "uModel", modelMatrix(l, time: time, model: nil))
        p.setFloat("uBx", vol.bounds.0)
        p.setFloat("uBy", vol.bounds.1)
        p.setFloat("uBz", vol.bounds.2)
        p.setVec4("uColor", 0.75, 0.85, 1, 0.35)
        Gl.drawQuad(p)
    }

    // MARK: - groups

    private func drawGroup(_ g: Layer, project: Project, scene: Scene, time: Float,
                           ar: Float, visited: inout [Layer: Bool]) {
        let children = scene.layers.filter { $0.parentId == g.id }
        guard !children.isEmpty else { return }
        let opacity = g.p("opacity", time)

        if g.mask == 0 {
            // no mask: children composite straight onto the scene
            for c in children {
                drawLayer(c, project: project, scene: scene, time: time, target: sceneTarget!,
                          ar: ar, visited: &visited)
            }
            return
        }

        // render children into the group buffer
        groupTarget!.bind()
        glClearColor(0, 0, 0, 0)
        glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
        for c in children {
            drawLayer(c, project: project, scene: scene, time: time, target: groupTarget!,
                      ar: ar, visited: &visited)
        }

        // mask buffer = first child's content
        if let first = children.first, first.isRenderable() {
            layerB!.bind()
            glClearColor(0, 0, 0, 0)
            glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
            var v: [Layer: Bool] = [:]
            renderLayerContent(first, scene: scene, time: time, ar: ar, visited: &v, target: groupTarget!)
            applyEffects(first, time: time)
            composite(groupTarget!, src: groupTarget!.tex, mask: layerB!.tex, maskMode: g.mask,
                      alpha: 1, mode: 0)
        }
        composite(sceneTarget!, src: groupTarget!.tex, alpha: opacity, mode: g.blend)
    }

    // MARK: - effects

    /// Effect programs are context-bound — this renderer compiles and caches
    /// its own copies, recording failures into Registry.errors for the UIs.
    private func effectProgram(_ d: EffectDef) -> GLProgram? {
        if let p = effectProgs[d.id] { return p }
        if failedProgs.contains(d.id) { return nil }
        let (src, _) = Gl.effectShaderSource(d)
        guard let p = GLProgram(vertex: GLProgram.defaultVertex, fragment: src) else {
            Registry.noteError(d.id, Gl.lastShaderLog)
            failedProgs.insert(d.id)
            return nil
        }
        effectProgs[d.id] = p
        return p
    }

    private func applyEffects(_ l: Layer, time: Float) {
        guard !l.fx.isEmpty else { return }
        var readTex = layerA!.tex
        var readIsA = true

        for entry in l.fx {
            if l.fxOff.contains(entry) { continue }
            guard let d = Registry.get(entry) else { continue }
            guard let p = effectProgram(d) else { continue }
            let write = readIsA ? layerB! : layerA!

            p.use()
            p.setTexture("uTex", readTex, 0)
            p.setVec2("uRes", Float(write.width), Float(write.height))
            p.setFloat("uTime", time)
            p.setFloat("uHas0", 0)
            p.setFloat("uHas1", 0)

            // layer inputs (in0/in1): the referenced layer's content, small
            var keepAlive: [Gl.Target] = []
            for (slot, nm) in d.inputs.enumerated() where slot < 2 {
                let rid = l.inputs[entry + ":" + nm]
                if let rid = rid, let ref = Editor.scene.layers.first(where: { $0.id == rid }),
                   ref.isRenderable(), let t = inTargets[slot] {
                    t.bind()
                    glClearColor(0, 0, 0, 0)
                    glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
                    var v: [Layer: Bool] = [:]
                    renderLayerContent(ref, scene: Editor.scene, time: time,
                                       ar: Float(width) / Float(max(height, 1)),
                                       visited: &v, target: sceneTarget!)
                    p.setTexture(slot == 0 ? "uIn0" : "uIn1", t.tex, GLint(1 + slot))
                    p.setFloat(slot == 0 ? "uHas0" : "uHas1", 1)
                    keepAlive.append(t)
                } else {
                    p.setFloat(slot == 0 ? "uHas0" : "uHas1", 0)
                }
            }
            _ = keepAlive

            // params
            let single = d.kind == 1
            for pd in d.props {
                let key = single ? pd.key : entry + "__" + pd.key
                p.setFloat(pd.key, paramValue(l, key: key, def: pd.def, time: time))
            }
            for cp in d.colors {
                let base = single ? cp.key : entry + "__" + cp.key
                let defC = UInt32(bitPattern: cp.def)
                p.setVec4(cp.key,
                          colorComp(l, key: base + "_r", def: Float((defC >> 16) & 0xFF) / 255, time: time),
                          colorComp(l, key: base + "_g", def: Float((defC >> 8) & 0xFF) / 255, time: time),
                          colorComp(l, key: base + "_b", def: Float(defC & 0xFF) / 255, time: time),
                          colorComp(l, key: base + "_a", def: Float((defC >> 24) & 0xFF) / 255, time: time))
            }

            write.bind()
            glDisable(GLenum(GL_BLEND))
            Gl.drawQuad(p)
            glEnable(GLenum(GL_BLEND))

            readTex = write.tex
            readIsA = !readIsA
        }

        // ensure the chain's result is in layerA for compositing
        if readTex != layerA!.tex {
            layerA!.bind()
            glDisable(GLenum(GL_BLEND))
            blit(readTex)
            glEnable(GLenum(GL_BLEND))
        }
    }

    private func paramValue(_ l: Layer, key: String, def: Float, time: Float) -> Float {
        if let tr = l.props[key] {
            return tr.evalExpr(l.editTime(key, time), time, tr.exprActive() ? Editor.scene.markersByName() : [:])
        }
        return def
    }

    private func colorComp(_ l: Layer, key: String, def: Float, time: Float) -> Float {
        if let tr = l.props[key] {
            return tr.eval(l.editTime(key, time))
        }
        return def
    }

    // MARK: - composite

    /// Composites `src` over `target`'s current content (through the
    /// scratch buffer — never read+write the same texture in one pass).
    private func composite(_ target: Gl.Target, src: GLuint, alpha: Float, mode: Int,
                           rgbShift: Float = 0) {
        composite(target, src: src, mask: 0, maskMode: 0, alpha: alpha, mode: mode, rgbShift: rgbShift)
    }

    private func composite(_ target: Gl.Target, src: GLuint, mask: GLuint, maskMode: Int,
                           alpha: Float, mode: Int, rgbShift: Float = 0) {
        guard let p = compositeProg, let scratch = scratchTarget else { return }
        scratch.bind()
        glDisable(GLenum(GL_BLEND))
        p.use()
        p.setTexture("uScene", target.tex, 0)
        p.setTexture("uSrc", src, 1)
        p.setTexture("uMask", mask, 2)
        p.setFloat("uAlpha", alpha)
        p.setFloat("uMode", Float(mode))
        p.setFloat("uMaskMode", Float(maskMode))
        p.setFloat("uRgbShift", rgbShift)
        Gl.drawQuad(p)

        target.bind()
        blit(scratch.tex)
    }

    // MARK: - helpers

    /// Image layers → GL textures, kept in a byte-budgeted LRU. (The old cache held 24
    /// textures, evicted without deleting them on the GPU, and so thrashed — re-decoding
    /// PNGs every frame and leaking GPU memory — as soon as a scene had more than 24
    /// images. That was the lag + crash with ~60 layers.)
    private func imageTexture(_ path: String) -> GLuint {
        // textures never need more pixels than the working resolution (plus headroom
        // for zoomed layers); this also keeps decoded size small for big canvases
        let side = max(384, 1536 / max(1, quality))
        if side != imageTexSide { flushImageTextures(); imageTexSide = side }
        if let t = imageTex[path] {
            if imageTexOrder.last != path {
                if let i = imageTexOrder.firstIndex(of: path) { imageTexOrder.remove(at: i) }
                imageTexOrder.append(path)
            }
            return t
        }
        var made: GLuint = 0
        var bytes = 0
        autoreleasepool {
            guard let img = UIImage(contentsOfFile: path) else { return }
            bytes = Gl.uploadBytes(img, maxSide: side)
            made = Gl.upload(img, maxSide: side) ?? 0
        }
        if made == 0 { return 0 }
        imageTex[path] = made
        imageTexBytes[path] = bytes
        imageTexTotal += bytes
        imageTexOrder.append(path)
        while imageTexTotal > imageTexBudget, imageTexOrder.count > 1 {
            let old = imageTexOrder.removeFirst()
            if let t = imageTex.removeValue(forKey: old) { Gl.delete(t) }
            imageTexTotal -= imageTexBytes.removeValue(forKey: old) ?? 0
        }
        return made
    }

    private func flushImageTextures() {
        EAGLContext.setCurrent(context)
        for (_, t) in imageTex { Gl.delete(t) }
        imageTex.removeAll(); imageTexBytes.removeAll(); imageTexOrder.removeAll()
        imageTexTotal = 0
    }

    /// Drops every cached image texture (memory warning / leaving the editor).
    func trimMemory() { flushImageTextures() }

    private func samplerFor(_ l: Layer) -> VideoFrames.Sampler {
        if let s = videoSamplers[l.id] { return s }
        let s = VideoFrames.Sampler(path: l.imagePath ?? "")
        videoSamplers[l.id] = s
        return s
    }

    private func modelFor(_ path: String) -> GlbModel? {
        if let m = models[path] { return m }
        let p = GlbModel.validate(path: path)
        guard let m = GlbModel.load(p) else { return nil }
        models[p] = m
        return m
    }

    private func volumeFor(_ path: String) -> VdbVolume? {
        if let v = volumes[path] { return v }
        guard let v = VdbVolume.load(path) else { return nil }
        volumes[path] = v
        return v
    }

    /// Source-media time for a video layer at scene time `t` (remap aware).
    private func sourceTime(_ l: Layer, _ t: Float) -> Float {
        if let tr = l.props["remapT"], !tr.keys.isEmpty {
            return max(0, tr.eval(t) + l.srcOffset)
        }
        let sp = l.props["remapSpeed"]?.eval(t) ?? 1
        return max(0, (t - l.start) * sp + l.srcOffset)
    }

    /// Draws the layer's quad with its world matrix (2D path).
    private func drawLayerQuad(_ l: Layer, time: Float, program: GLProgram) {
        let (qw, qh) = Xf.quadSize(l)
        let m = Xf.matrix(l, time)
        program.setMat3("uMat", m)
        program.setVec2("uQuad", qw, qh)
        program.setFloat("uAspect", Float(width) / Float(max(height, 1)))
        if l.is3d {
            let lt = l.editTime("x", time)
            let d = Float.pi / 180
            program.setVec3("uRot", l.p("rotX", lt) * d, -l.p("rotY", lt) * d, 0)
            program.setFloat("uZ", l.p("z", lt))
            let (vp, hasCam) = cameraVP(l, scene: Editor.scene, time: time)
            if hasCam {
                program.setFloat("uUseVP", 1)
                setMat4(program, "uVP", vp)
            } else {
                program.setFloat("uUseVP", 0)
            }
            program.setFloat("uInvCam", 1.0 / 3.0)
        } else {
            program.setFloat("uUseVP", 0)
            program.setVec3("uRot", 0, 0, 0)
            program.setFloat("uZ", 0)
            program.setFloat("uInvCam", 0)
        }
        Gl.drawQuad(program)
    }

    // MARK: - matrices / cameras

    /// Scene Setup mode (the top-bar orbit camera): while set, every 3D layer
    /// is drawn through this editing camera instead of the scene camera. The
    /// active camera layer is never touched, so leaving the mode restores the
    /// exact previous view. Layout: [fov°, eyeX, eyeY, eyeZ, rotX°, rotY°].
    static var editCam: [Float]? = nil

    private func cameraVP(_ l: Layer, scene: Scene, time: Float) -> ([Float], Bool) {
        let ar = Float(width) / Float(max(height, 1))
        if let e = SceneRenderer.editCam {
            return (perspectiveLookAt(e[0], ar, e[1], e[2], e[3],
                                      e[4] * Float.pi / 180, e[5] * Float.pi / 180), true)
        }
        if let cam = Xf.camera(for: l) {
            let ct = cam.editTime("x", time)
            let fov = cam.p("fov", ct)
            // z is an offset from the neutral distance at which the z=0 plane exactly fills the
            // comp (visible half-height 1, same as 2D layers) — so adding a camera never zooms
            let neutral = 1 / tan(fov * Float.pi / 360)
            let ex = cam.p("x", ct), ey = cam.p("y", ct), ez = cam.p("z", ct) + neutral
            let rx = cam.p("rotX", ct) * Float.pi / 180
            let ry = cam.p("rotY", ct) * Float.pi / 180
            let rz = cam.p("rotZ", ct) * Float.pi / 180
            return (perspectiveLookAt(fov, ar, ex, ey, ez, rx, ry, rz), true)
        }
        // default: camera at z = 3 looking at origin
        return (perspectiveLookAt(scene.fov, ar, 0, 0, 3, 0, 0), false)
    }

    private func modelMatrix(_ l: Layer, time: Float, model: GlbModel?) -> [Float] {
        let lt = l.editTime("x", time)
        let s = l.p("scale", lt)
        let norm = model?.normalize ?? [1, 0, 0, 0]
        let x = l.p("x", lt) + norm[1]
        let y = l.p("y", lt) + norm[2]
        let z = l.p("z", lt) + norm[3]
        let rx = l.p("rotX", lt) * Float.pi / 180
        let ry = l.p("rotY", lt) * Float.pi / 180
        let rz = l.p("rotZ", lt) * Float.pi / 180
        let sc = s * norm[0]

        var m = identity4()
        m = mul4(rotY4(ry), m)
        m = mul4(rotX4(rx), m)
        m = mul4(rotZ4(rz), m)
        m = mul4(scale4(sc, sc, sc), m)
        m[12] = x; m[13] = y; m[14] = z
        return m
    }

    private func perspectiveLookAt(_ fovDeg: Float, _ ar: Float,
                                   _ ex: Float, _ ey: Float, _ ez: Float,
                                   _ rx: Float, _ ry: Float, _ rz: Float = 0) -> [Float] {
        let f = 1 / tan(fovDeg * Float.pi / 360)
        let near: Float = 0.05, far: Float = 100
        let nf = 1 / (near - far)
        var p = identity4()
        p[0] = f / ar
        p[5] = f
        p[10] = (far + near) * nf
        p[11] = -1
        p[14] = 2 * far * near * nf
        p[15] = 0

        var v = identity4()
        // orbit: world yaw first, then pitch, then roll about the view axis
        v = mul4(rotY4(-ry), v)
        v = mul4(rotX4(-rx), v)
        v = mul4(rotZ4(-rz), v)
        v[12] = -ex; v[13] = -ey; v[14] = -ez

        return mul4(p, v)
    }

    private func setMat4(_ p: GLProgram, _ name: String, _ m: [Float]) {
        let l = p.loc(name)
        if l >= 0 {
            m.withUnsafeBufferPointer { ptr in
                glUniformMatrix4fv(l, 1, GLboolean(GL_FALSE), ptr.baseAddress)
            }
        }
    }

    // MARK: - programs

    /// Transforming quad vertex shader (layer matrix, quad size, aspect).
    /// The transform used to sit in the FRAGMENT shader, where gl_Position
    /// does not exist: the shader never compiled and nothing was ever drawn.
    static let layerQuadVertex = """
attribute vec2 aPos;
uniform mat3 uMat;
uniform vec2 uQuad;
uniform float uAspect;
uniform vec3 uRot;
uniform float uZ;
uniform float uInvCam;
uniform mat4 uVP;
uniform float uUseVP;
varying vec2 vUv;
void main() {
    vUv = aPos * 0.5 + 0.5;
    vec2 w = (uMat * vec3((vUv - 0.5) * uQuad, 1.0)).xy;
    vec2 c = (uMat * vec3(0.0, 0.0, 1.0)).xy;
    vec3 o = vec3(w - c, 0.0);
    float cy = cos(uRot.y), sy = sin(uRot.y);
    o = vec3(o.x * cy + o.z * sy, o.y, -o.x * sy + o.z * cy);
    float cx = cos(uRot.x), sx = sin(uRot.x);
    o = vec3(o.x, o.y * cx - o.z * sx, o.y * sx + o.z * cx);
    vec3 pos = vec3(c + o.xy, o.z + uZ);
    if (uUseVP > 0.5) {
        vec4 cl = uVP * vec4(pos, 1.0);
        if (cl.w < 0.02) { gl_Position = vec4(2.0, 2.0, 0.0, 1.0); }   // behind the camera
        else { gl_Position = vec4(cl.xy, 0.0, cl.w); }
    } else {
        gl_Position = vec4(pos.x / uAspect, pos.y, 0.0, 1.0 - pos.z * uInvCam);
    }
}
"""

    private static let quadVertex = """
attribute vec2 aPos;
varying vec2 vUv;
void main() {
    vUv = aPos * 0.5 + 0.5;
    gl_Position = vec4(aPos, 0.0, 1.0);
}
"""

    /// Builds (once) the pipeline shaders. Call with the context current.
    func buildPrograms() {
        if quadProg != nil { return }

        quadProg = GLProgram(vertex: SceneRenderer.layerQuadVertex, fragment: """
precision mediump float;
varying vec2 vUv;
uniform sampler2D uTex;
uniform float uFlipY;
uniform vec4 uColor;
void main() {
    vec2 p = vec2(vUv.x, mix(vUv.y, 1.0 - vUv.y, uFlipY));
    gl_FragColor = texture2D(uTex, p) * uColor;
}
""")
        if quadProg == nil { CrashLog.note("quadProg FAILED: " + Gl.lastShaderLog) }
        shapeProg = GLProgram(vertex: """
attribute vec2 aPos;
uniform mat3 uMat;
uniform vec2 uQuad;
uniform float uAspect;
varying vec2 vQ;
void main() {
    vec2 lc = (aPos * 0.5 + 0.5 - 0.5) * uQuad;
    vQ = lc;
    vec2 w = (uMat * vec3(lc, 1.0)).xy;
    gl_Position = vec4(w.x / uAspect, w.y, 0.0, 1.0);
}
""", fragment: """
precision mediump float;
varying vec2 vQ;
uniform vec4 uColor;
uniform float uKind;
uniform float uCornerRadius;
uniform vec2 uQuadSize;
void main() {
    vec2 q = vQ;
    float a = 0.0;
    if (uKind < 0.5) { a = 1.0; }
    else if (uKind < 1.5) {
        vec2 d = abs(q) - (uQuadSize * 0.5 - vec2(uCornerRadius));
        float outD = length(max(d, 0.0)) + min(max(d.x, d.y), 0.0) - uCornerRadius;
        a = 1.0 - smoothstep(-0.004, 0.004, outD);
    }
    else if (uKind < 2.5) {
        a = 1.0 - smoothstep(0.48 * min(uQuadSize.x, uQuadSize.y), 0.5 * min(uQuadSize.x, uQuadSize.y), length(q));
    }
    else if (uKind < 3.5) {
        vec2 v1 = vec2(-uQuadSize.x * 0.5, -uQuadSize.y * 0.5) - q;
        vec2 v2 = vec2(uQuadSize.x * 0.5, -uQuadSize.y * 0.5) - q;
        vec2 v3 = q - vec2(-uQuadSize.x * 0.5, -uQuadSize.y * 0.5);
        float s1 = v1.x * v2.y - v1.y * v2.x;
        float s2 = v2.x * v3.y - v2.y * v3.x;
        float s3 = v3.x * -v1.y - v3.y * -v1.x;
        a = ((s1 >= 0.0 && s2 >= 0.0 && s3 >= 0.0) || (s1 <= 0.0 && s2 <= 0.0 && s3 <= 0.0)) ? 1.0 : 0.0;
    }
    else {
        float n = 5.0;
        float a0 = atan(q.y, q.x) + 1.5708;
        float seg = 6.2831 / n;
        float rIn = 0.22 * min(uQuadSize.x, uQuadSize.y);
        float rOut = 0.5 * min(uQuadSize.x, uQuadSize.y);
        float ang = mod(a0, seg) - seg * 0.5;
        float rLim = mix(rOut, rIn, abs(ang) / (seg * 0.5));
        a = 1.0 - smoothstep(rLim - 0.01, rLim + 0.01, length(q));
    }
    gl_FragColor = vec4(uColor.rgb * a, uColor.a * a);
}
""")

        flareProg = GLProgram(vertex: SceneRenderer.quadVertex, fragment: """
precision mediump float;
varying vec2 vUv;
uniform vec2 uLight;
uniform float uIntensity;
uniform float uAxis;
uniform vec4 uTint;
uniform float uDepthScale;
uniform float uEdgeFade;
uniform float uAspect;
uniform float uCount;
uniform float uElType[12];
uniform vec2 uEl[12];
uniform float uElRot[12];
uniform float uElBright[12];
uniform float uElSoft[12];
uniform float uElThick[12];
uniform float uElStretch[12];
uniform float uElSides[12];
uniform float uElRays[12];
uniform float uElChroma[12];
uniform float uElFollow[12];
uniform vec4 uElCol[12];

float elMask(int i, vec2 p) {
    float t = uElType[i];
    vec2 ps = uEl[i];
    float pos = ps.x;
    float size = ps.y;
    if (t < -0.5) { return 0.0; }
    vec2 axis = vec2(0.5, 0.5) - uLight;
    vec2 centre = uLight + axis * pos;
    vec2 d = p - centre;
    if (uElFollow[i] > 0.5) {
        float ca = cos(uElRot[i]), sa = sin(uElRot[i]);
        d = vec2(ca * d.x - sa * d.y, sa * d.x + ca * d.y);
    }
    float r = length(d);
    float m = 0.0;
    if (t < 0.5) {
        m = (1.0 - smoothstep(0.0, size * (1.0 - uElSoft[i] * 0.5), r));
        m = pow(clamp(m, 0.0, 1.0), 1.0 + uElSoft[i] * 3.0);
    } else if (t < 1.5) {
        float n = max(uElSides[i], 3.0);
        float a = atan(d.y, d.x);
        float seg = 6.2831 / n;
        float ang = mod(a, seg) - seg * 0.5;
        float rLim = mix(size, size * max(uElThick[i], 0.02), abs(ang) / (seg * 0.5));
        m = 1.0 - smoothstep(rLim - 0.004, rLim + 0.004, r);
    } else if (t < 2.5) {
        vec2 s = vec2(size * uElStretch[i] * 0.5, size * 0.5 * max(uElThick[i], 0.01));
        vec2 q = abs(d) - s;
        m = 1.0 - smoothstep(-0.004, 0.004, length(max(q, 0.0)) + min(max(q.x, q.y), 0.0));
    } else if (t < 3.5) {
        float n = max(uElRays[i], 2.0);
        float a = atan(d.y, d.x);
        float beam = abs(cos(a * n * 0.5));
        m = smoothstep(0.35, 0.65, beam) * (1.0 - smoothstep(0.0, size, r));
    } else if (t < 4.5) {
        m = 1.0 - smoothstep(size * 0.45, size * 0.5, r);
    } else {
        float halfR = size * 0.5 * max(1.0 - uElThick[i], 0.08);
        m = (1.0 - smoothstep(halfR - 0.006, halfR + 0.006, r))
          - (1.0 - smoothstep(halfR - size * 0.5 * uElThick[i] - 0.006, halfR - size * 0.5 * uElThick[i] + 0.006, r));
    }
    return clamp(m, 0.0, 1.0);
}

void main() {
    vec3 acc = vec3(0.0);
    float maxA = 0.0;
    for (int i = 0; i < 12; i++) {
        float active = step(float(i) + 0.5, uCount);
        float m = elMask(i, vUv) * active;
        vec3 c = uElCol[i].rgb * uTint.rgb;
        vec3 cc = c;
        if (uElChroma[i] > 0.01) {
            cc = c * mix(vec3(1.0, 0.4, 0.4), vec3(0.4, 0.4, 1.0), clamp(m * 2.0, 0.0, 1.0));
        }
        acc += cc * m * uElBright[i];
        maxA = max(maxA, m);
    }
    acc *= uIntensity;
    float axisDist = length((vUv - uLight) * vec2(uAspect, 1.0));
    float fade = 1.0 - smoothstep(0.3 * max(uAxis, 0.01), 0.3 * max(uAxis, 0.01) + 0.5 + uEdgeFade, axisDist);
    acc *= mix(1.0, fade, uDepthScale);
    gl_FragColor = vec4(acc, clamp(maxA * uIntensity, 0.0, 1.0));
}
""")

        particleProg = GLProgram(vertex: """
attribute vec3 aPos;
attribute vec3 aData;
uniform mat4 uVP;
uniform float uAspect;
uniform float uOrtho;
uniform float uSize;
uniform float uPx;
uniform float uOpacity;
uniform float uFadeIn;
uniform float uFadeOut;
uniform vec4 uColA;
uniform vec4 uColB;
varying vec4 vCol;
varying float vLife;
varying float vOp;
varying float vSoft;
varying float vFi;
varying float vFo;
void main() {
    vOp = uOpacity;
    vFi = uFadeIn;
    vFo = uFadeOut;
    float k = 1.0;
    if (uOrtho > 0.5) {
        gl_Position = vec4(aPos.x / uAspect, aPos.y, 0.0, 1.0);
    } else {
        vec4 c = uVP * vec4(aPos, 1.0);
        gl_Position = c;
        k = 3.0 / max(c.w, 0.05);
    }
    vSoft = aData.z;
    gl_PointSize = max(3.0, uSize * uPx * aData.x * k * (1.0 + aData.z * 0.35));
    vLife = aData.y;
    vCol = mix(uColA, uColB, clamp(aData.y, 0.0, 1.0));
}
""", fragment: """
precision mediump float;
varying vec4 vCol;
varying float vLife;
varying float vOp;
varying float vSoft;
varying float vFi;
varying float vFo;
void main() {
    vec2 c = gl_PointCoord - 0.5;
    float d = length(c);
    float a = 1.0 - smoothstep(mix(0.46, 0.0, vSoft), 0.5, d);   // edge0 < edge1 (reversed edges are undefined in GLSL)
    float fade = smoothstep(0.0, vFi, vLife) * (1.0 - smoothstep(1.0 - vFo, 1.0, vLife));
    a *= fade * vOp * vCol.a;
    gl_FragColor = vec4(vCol.rgb * a, a);
}
""")

        meshProg = GLProgram(vertex: """
attribute vec3 aPos;
attribute vec3 aNormal;
attribute vec2 aUv;
uniform mat4 uVP;
uniform mat4 uModel;
varying vec3 vN;
varying vec3 vL;
void main() {
    vec4 w = uModel * vec4(aPos, 1.0);
    gl_Position = uVP * w;
    vN = normalize(vec3(uModel[0].xyz * aNormal.x + uModel[1].xyz * aNormal.y + uModel[2].xyz * aNormal.z));
    vL = normalize(vec3(2.0, 3.0, 4.0) - w.xyz);
}
""", fragment: """
precision mediump float;
uniform vec4 uColor;
varying vec3 vN;
varying vec3 vL;
void main() {
    float diff = clamp(dot(normalize(vN), normalize(vL)), 0.0, 1.0);
    float rim = pow(1.0 - clamp(dot(normalize(vN), vec3(0.0, 0.0, 1.0)), 0.0, 1.0), 2.0);
    vec3 c = uColor.rgb * (0.35 + 0.65 * diff) + vec3(0.25) * rim;
    gl_FragColor = vec4(c, uColor.a);
}
""")

        vdbProg = GLProgram(vertex: SceneRenderer.quadVertex, fragment: """
precision mediump float;
varying vec2 vUv;
uniform mat4 uVP;
uniform mat4 uModel;
uniform float uBx;
uniform float uBy;
uniform float uBz;
uniform vec4 uColor;
void main() {
    float best = 0.0;
    for (int i = 0; i < 8; i++) {
        float z = (float(i) / 7.0 - 0.5) * uBz;
        vec3 p = vec3((vUv.x - 0.5) * uBx, (vUv.y - 0.5) * uBy, z);
        vec4 w = uModel * vec4(p, 1.0);
        vec4 clip = uVP * w;
        float depth = clamp((clip.z / max(abs(clip.w), 0.0001)) * 0.5 + 0.5, 0.0, 1.0);
        float d = length(vUv - 0.5);
        float ring = smoothstep(0.5, 0.35, d);
        best = max(best, ring * (0.25 + 0.75 * (1.0 - depth)));
    }
    gl_FragColor = vec4(uColor.rgb * best, uColor.a * best);
}
""")

        compositeProg = GLProgram(vertex: SceneRenderer.quadVertex, fragment: """
precision mediump float;
varying vec2 vUv;
uniform sampler2D uScene;
uniform sampler2D uSrc;
uniform sampler2D uMask;
uniform float uAlpha;
uniform float uMode;      // 0 normal 1 add 2 screen 3 multiply 4 accumulate 5 running average
uniform float uMaskMode;  // 0 none 1 alpha 2 inv alpha 3 luma 4 inv luma
uniform float uRgbShift;
void main() {
    vec4 s = texture2D(uSrc, vUv);
    if (uRgbShift != 0.0) {
        s.r = texture2D(uSrc, clamp(vUv + vec2(uRgbShift, 0.0), 0.0, 1.0)).r;
        s.b = texture2D(uSrc, clamp(vUv - vec2(uRgbShift, 0.0), 0.0, 1.0)).b;
    }
    vec4 sRaw = s;
    s *= uAlpha;
    if (uMode > 4.5) {
        // running average: acc = mix(acc, sample, 1/(i+1)). Keeps full precision in 8-bit
        // targets (additive 1/N accumulation rounds dim pixels to 0 → visible opacity steps)
        gl_FragColor = mix(texture2D(uScene, vUv), sRaw, uAlpha);
        return;
    }
    if (uMaskMode > 0.5) {
        vec4 mk = texture2D(uMask, vUv);
        float m = 1.0;
        if (uMaskMode < 1.5) { m = mk.a; }
        else if (uMaskMode < 2.5) { m = 1.0 - mk.a; }
        else if (uMaskMode < 3.5) { m = dot(mk.rgb, vec3(0.299, 0.587, 0.114)); }
        else { m = 1.0 - dot(mk.rgb, vec3(0.299, 0.587, 0.114)); }
        s *= m;
    }
    vec4 d = texture2D(uScene, vUv);
    if (uMode < 0.5) {
        gl_FragColor = s + d * (1.0 - s.a);
    } else if (uMode < 1.5) {
        gl_FragColor = d + s;
    } else if (uMode < 2.5) {
        vec3 scr = 1.0 - (1.0 - d.rgb) * (1.0 - s.rgb);
        gl_FragColor = mix(d, vec4(scr, max(d.a, s.a)), s.a);
    } else if (uMode < 3.5) {
        vec3 mul = d.rgb * s.rgb;
        gl_FragColor = mix(d, vec4(mul, d.a * s.a), s.a);
    } else {
        gl_FragColor = d + s;
    }
}
""")
    }

    // MARK: - math

    private func identity4() -> [Float] {
        [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]
    }

    private func scale4(_ x: Float, _ y: Float, _ z: Float) -> [Float] {
        [x, 0, 0, 0, 0, y, 0, 0, 0, 0, z, 0, 0, 0, 0, 1]
    }

    private func rotX4(_ a: Float) -> [Float] {
        let c = cos(a), s = sin(a)
        return [1, 0, 0, 0, 0, c, s, 0, 0, -s, c, 0, 0, 0, 0, 1]
    }

    private func rotY4(_ a: Float) -> [Float] {
        let c = cos(a), s = sin(a)
        return [c, 0, -s, 0, 0, 1, 0, 0, s, 0, c, 0, 0, 0, 0, 1]
    }

    private func rotZ4(_ a: Float) -> [Float] {
        let c = cos(a), s = sin(a)
        return [c, s, 0, 0, -s, c, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]
    }

    /// a * b (column-major, OpenGL order).
    private func mul4(_ a: [Float], _ b: [Float]) -> [Float] {
        var o = [Float](repeating: 0, count: 16)
        for c in 0..<4 {
            for r in 0..<4 {
                var s: Float = 0
                for k in 0..<4 {
                    s += a[k * 4 + r] * b[c * 4 + k]
                }
                o[c * 4 + r] = s
            }
        }
        return o
    }
}

// MARK: - mat3 upload

extension GLProgram {
    func setMat3(_ name: String, _ m0: [Float]) {
        let l = loc(name)
        // Xf matrices are 2D affines [a b c d tx ty]; GL needs 9 floats
        // (column-major). Passing 6 made GL read garbage => the skew.
        let m: [Float] = m0.count == 6
            ? [m0[0], m0[1], 0, m0[2], m0[3], 0, m0[4], m0[5], 1] : m0
        if l >= 0 {
            m.withUnsafeBufferPointer { ptr in
                glUniformMatrix3fv(l, 1, GLboolean(GL_FALSE), ptr.baseAddress)
            }
        }
    }
}
