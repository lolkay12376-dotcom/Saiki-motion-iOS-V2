// Json.swift — org.json-style JSON for SaikiMotion (Core).
//
// The Kotlin app spoke org.json (JSONObject/JSONArray). This is the Swift
// equivalent with the same shape: a mutable ordered object, a mutable array,
// a failable+throwing text parser and a compact writer. Everything that
// persists (projects, presets, effect defs) round-trips through JObj, so the
// editor's undo stack can snapshot whole projects as strings.

import Foundation

/// Compact number formatting that matches org.json: integral doubles print
/// without a decimal part, others use the shortest round-trip form.
enum JSONWriter {
    static func numberToString(_ d: Double) -> String {
        if d.isNaN || d.isInfinite { return "null" }
        if d == d.rounded() && abs(d) < 1e15 {
            return String(format: "%.0f", d)
        }
        var s = "\(d)"
        if s.hasSuffix(".0") { s = String(s.dropLast(2)) }
        return s
    }

    static func escape(_ s: String) -> String {
        var out = "\""
        for ch in s.unicodeScalars {
            switch ch {
            case "\"": out += "\\\""
            case "\\": out += "\\\\"
            case "\n": out += "\\n"
            case "\r": out += "\\r"
            case "\t": out += "\\t"
            case "\u{08}": out += "\\b"
            case "\u{0C}": out += "\\f"
            default:
                if ch.value < 0x20 {
                    out += String(format: "\\u%04x", ch.value)
                } else {
                    out.unicodeScalars.append(ch)
                }
            }
        }
        return out + "\""
    }
}

/// JSONArray equivalent — an ordered, mutable JSON array.
final class JArr {
    var items: [Any] = []

    init() {}

    init(_ items: [Any]) { self.items = items }

    // -- chaining puts (the Kotlin code chains these) --

    @discardableResult
    func put(_ v: Any?) -> JArr {
        items.append(v ?? NSNull())
        return self
    }

    // -- getters --

    var count: Int { items.count }
    var isEmpty: Bool { items.isEmpty }

    func opt(_ i: Int) -> Any? {
        items.indices.contains(i) ? items[i] : nil
    }

    func optString(_ i: Int, _ def: String = "") -> String {
        guard let v = opt(i) else { return def }
        if let s = v as? String { return s }
        if let n = v as? NSNumber { return n.stringValue }
        return def
    }

    func optDouble(_ i: Int, _ def: Double = 0) -> Double {
        guard let v = opt(i) else { return def }
        if let n = v as? NSNumber { return n.doubleValue }
        if let s = v as? String { return Double(s) ?? def }
        return def
    }

    func optFloat(_ i: Int, _ def: Float = 0) -> Float {
        guard let v = opt(i) else { return def }
        if let n = v as? NSNumber { return n.floatValue }
        if let s = v as? String { return Float(s) ?? def }
        return def
    }

    func optInt(_ i: Int, _ def: Int = 0) -> Int {
        guard let v = opt(i) else { return def }
        if let n = v as? NSNumber { return n.intValue }
        if let s = v as? String { return Int(s) ?? def }
        return def
    }

    func optBool(_ i: Int, _ def: Bool = false) -> Bool {
        guard let v = opt(i) else { return def }
        if let n = v as? NSNumber { return n.boolValue }
        if let s = v as? String { return s == "true" }
        return def
    }

    func optJSONObject(_ i: Int) -> JObj? {
        (opt(i) as? JObj) ?? (opt(i) as? [String: Any]).map { JObj(dict: $0) }
    }

    func optJSONArray(_ i: Int) -> JArr? {
        (opt(i) as? JArr) ?? (opt(i) as? [Any]).map { JArr($0) }
    }

    // -- writer --

    func toString() -> String {
        // SAVE FIX: arrays used to be passed to the scalar writer, which turned the
        // whole array (scenes / layers / anims...) into a quoted string. Write each item.
        "[" + items.map { JSONWriterValue.writer(value: $0) }.joined(separator: ",") + "]"
    }

    /// org.json toString(indent) — 4-space indent like the Kotlin app used.
    func toString(_ indent: Int) -> String { pretty(items, indent) }

    private func pretty(_ v: Any, _ ind: Int) -> String {
        let pad = String(repeating: " ", count: ind)
        let pad2 = String(repeating: " ", count: ind + 4)
        if let o = v as? JObj { return o.toString(ind + 4) }
        if let a = v as? JArr {
            if a.items.isEmpty { return "[]" }
            var s = "[\n"
            for (i, e) in a.items.enumerated() {
                s += pad2 + pretty(e, ind + 4) + (i < a.items.count - 1 ? ",\n" : "\n")
            }
            return s + pad + "]"
        }
        return JSONWriterValue.scalar(v)
    }
}

/// JSONObject equivalent — insertion-ordered, mutable, chainable.
final class JObj {
    var dict: [String: Any] = [:]
    private var order: [String] = []

    init() {}

    init(dict: [String: Any]) {
        for (k, v) in dict { _ = put(k, v) }
    }

    /// Parse from text. Throws JsonError-like NSError on malformed input so
    /// callers can `try JObj(json:)` exactly like org.json's checked getter.
    init(json: String) throws {
        let parser = JSONParser(json)
        let v = try parser.parseValue()
        parser.skipWs()
        guard parser.atEnd else {
            throw NSError(domain: "JObj", code: 1,
                          userInfo: [NSLocalizedDescriptionKey: "End of character expected"])
        }
        if let o = v as? [String: Any] {
            for (k, val) in o { _ = put(k, val) }
        } else {
            throw NSError(domain: "JObj", code: 2,
                          userInfo: [NSLocalizedDescriptionKey: "Not a JSON object"])
        }
    }

    /// Lenient parse (nil instead of throwing) — the reader convenience
    /// org.json's JSONTokener offers.
    static func parse(_ text: String) -> JObj? {
        try? JObj(json: text)
    }

    // -- puts --

    @discardableResult
    func put(_ key: String, _ v: Any?) -> JObj {
        if v == nil || v is NSNull {
            if dict[key] != nil { dict[key] = NSNull() }
            return self
        }
        if dict[key] == nil { order.append(key) }
        dict[key] = v!
        return self
    }

    @discardableResult
    func remove(_ key: String) -> JObj {
        if dict[key] != nil {
            dict.removeValue(forKey: key)
            order.removeAll { $0 == key }
        }
        return self
    }

    // -- keys / getters --

    var keys: [String] { order.filter { dict[$0] != nil } }
    var length: Int { keys.count }

    func has(_ key: String) -> Bool { dict[key] != nil }

    func opt(_ key: String) -> Any? { dict[key] }

    func optString(_ key: String, _ def: String = "") -> String {
        guard let v = dict[key] else { return def }
        if let s = v as? String { return s }
        if let n = v as? NSNumber { return n.stringValue }
        return def
    }

    func optDouble(_ key: String, _ def: Double = 0) -> Double {
        guard let v = dict[key], !(v is NSNull) else { return def }
        if let n = v as? NSNumber { return n.doubleValue }
        if let s = v as? String { return Double(s) ?? def }
        return def
    }

    func optFloat(_ key: String, _ def: Float = 0) -> Float {
        Float(optDouble(key, Double(def)))
    }

    func optInt(_ key: String, _ def: Int = 0) -> Int {
        guard let v = dict[key], !(v is NSNull) else { return def }
        if let n = v as? NSNumber { return n.intValue }
        if let s = v as? String { return Int(Double(s) ?? Double(def)) }
        return def
    }

    func optLong(_ key: String, _ def: Int64 = 0) -> Int64 {
        guard let v = dict[key], !(v is NSNull) else { return def }
        if let n = v as? NSNumber { return n.int64Value }
        if let s = v as? String { return Int64(Double(s) ?? Double(def)) }
        return def
    }

    func optBool(_ key: String, _ def: Bool = false) -> Bool {
        guard let v = dict[key], !(v is NSNull) else { return def }
        if let n = v as? NSNumber { return n.boolValue }
        if let s = v as? String { return s == "true" || s == "1" }
        return def
    }

    func optJSONObject(_ key: String) -> JObj? {
        guard let v = dict[key], !(v is NSNull) else { return nil }
        if let o = v as? JObj { return o }
        if let o = v as? [String: Any] { return JObj(dict: o) }
        return nil
    }

    func optJSONArray(_ key: String) -> JArr? {
        guard let v = dict[key], !(v is NSNull) else { return nil }
        if let a = v as? JArr { return a }
        if let a = v as? [Any] { return JArr(a) }
        return nil
    }

    /// get*-with-throw surface used by the SDK IDE for validation.
    func getString(_ key: String) throws -> String {
        guard let v = dict[key], !(v is NSNull) else {
            throw NSError(domain: "JObj", code: 3,
                          userInfo: [NSLocalizedDescriptionKey: "No value for \(key)"])
        }
        if let s = v as? String { return s }
        if let n = v as? NSNumber { return n.stringValue }
        throw NSError(domain: "JObj", code: 4,
                      userInfo: [NSLocalizedDescriptionKey: "Not a string: \(key)"])
    }

    // -- writer --

    func toString() -> String {
        var s = "{"
        for (i, k) in keys.enumerated() {
            if i > 0 { s += "," }
            s += JSONWriter.escape(k) + ":" + JSONWriterValue.writer(value: dict[k]!)
        }
        return s + "}"
    }

    /// org.json toString(indent).
    func toString(_ indent: Int) -> String {
        if keys.isEmpty { return "{}" }
        let pad = String(repeating: " ", count: indent)
        let pad2 = String(repeating: " ", count: indent + 4)
        var s = "{\n"
        let ks = keys
        for (i, k) in ks.enumerated() {
            let v = dict[k]!
            let body: String
            if let o = v as? JObj { body = o.toString(indent + 4) }
            else if let a = v as? JArr { body = a.toString(indent + 4) }
            else { body = JSONWriterValue.scalar(v) }
            s += pad2 + JSONWriter.escape(k) + ":" + body + (i < ks.count - 1 ? ",\n" : "\n")
        }
        return s + pad + "}"
    }
}

/// Internal shared writer bits.
private enum JSONWriterValue {
    static func scalar(_ v: Any) -> String {
        switch v {
        case let s as String: return JSONWriter.escape(s)
        case let n as NSNumber:
            if CFGetTypeID(n) == CFBooleanGetTypeID() { return n.boolValue ? "true" : "false" }
            return JSONWriter.numberToString(n.doubleValue)
        case let b as Bool: return b ? "true" : "false"
        case let d as Double: return JSONWriter.numberToString(d)
        case let f as Float: return JSONWriter.numberToString(Double(f))
        case let i as Int64: return String(i)
        case let i as Int32: return String(i)
        case let i as Int: return String(i)
        case is NSNull: return "null"
        default: return JSONWriter.escape(String(describing: v))
        }
    }

    static func writer(value: Any) -> String {
        if let o = value as? JObj { return o.toString() }
        if let a = value as? JArr { return a.toString() }
        if let a = value as? [Any] { return JArr(a).toString() }
        if let d = value as? [String: Any] { return JObj(dict: d).toString() }
        return scalar(value)
    }
}

/// Recursive-descent JSON parser producing JObj/JArr/[String:Any]-free values.
private final class JSONParser {
    // Byte-based (UTF-8) parser: the old [Character] version used ~16 bytes per char and
    // grapheme clustering, which was extremely slow / memory hungry on multi-MB glTF files.
    private let s: [UInt8]
    private var i = 0

    init(_ text: String) {
        var b = Array(text.utf8)
        if b.count >= 3, b[0] == 0xEF, b[1] == 0xBB, b[2] == 0xBF { b.removeFirst(3) }
        s = b
    }

    var atEnd: Bool { i >= s.count }

    private func fail(_ code: Int, _ msg: String) -> NSError {
        NSError(domain: "JObj", code: code, userInfo: [NSLocalizedDescriptionKey: msg])
    }

    func skipWs() {
        while i < s.count && (s[i] == 0x20 || s[i] == 0x0A || s[i] == 0x0D || s[i] == 0x09 || s[i] == 0) { i += 1 }
    }

    func parseValue() throws -> Any {
        skipWs()
        guard i < s.count else { throw fail(5, "Unexpected end of input") }
        switch s[i] {
        case UInt8(ascii: "{"): return try parseObject()
        case UInt8(ascii: "["): return try parseArray()
        case UInt8(ascii: "\""): return try parseString()
        case UInt8(ascii: "t"): try expect("true"); return true
        case UInt8(ascii: "f"): try expect("false"); return false
        case UInt8(ascii: "n"): try expect("null"); return NSNull()
        default: return try parseNumber()
        }
    }

    private func expect(_ word: String) throws {
        for ch in word.utf8 {
            guard i < s.count, s[i] == ch else { throw fail(6, "Malformed JSON") }
            i += 1
        }
    }

    private func parseObject() throws -> [String: Any] {
        i += 1
        var out: [String: Any] = [:]
        skipWs()
        if i < s.count && s[i] == UInt8(ascii: "}") { i += 1; return out }
        while i < s.count {
            skipWs()
            guard i < s.count, s[i] == UInt8(ascii: "\"") else { throw fail(7, "Expected string key") }
            let k = try parseString()
            skipWs()
            guard i < s.count, s[i] == UInt8(ascii: ":") else { throw fail(8, "Expected ':'") }
            i += 1
            out[k] = try parseValue()
            skipWs()
            if i < s.count && s[i] == UInt8(ascii: ",") { i += 1; continue }
            if i < s.count && s[i] == UInt8(ascii: "}") { i += 1; return out }
            throw fail(9, "Expected ',' or '}'")
        }
        throw fail(10, "Unterminated object")
    }

    private func parseArray() throws -> JArr {
        i += 1
        let arr = JArr()
        skipWs()
        if i < s.count && s[i] == UInt8(ascii: "]") { i += 1; return arr }
        while i < s.count {
            arr.items.append(try parseValue())
            skipWs()
            if i < s.count && s[i] == UInt8(ascii: ",") { i += 1; continue }
            if i < s.count && s[i] == UInt8(ascii: "]") { i += 1; return arr }
            throw fail(11, "Expected ',' or ']'")
        }
        throw fail(12, "Unterminated array")
    }

    private func hex4(_ at: Int) -> UInt32? {
        guard at + 3 < s.count else { return nil }
        var v: UInt32 = 0
        for k in 0..<4 {
            let c = s[at + k]
            var d: UInt32
            switch c {
            case 48...57: d = UInt32(c) - 48
            case 65...70: d = UInt32(c) - 55
            case 97...102: d = UInt32(c) - 87
            default: return nil
            }
            v = v << 4 | d
        }
        return v
    }

    private func parseString() throws -> String {
        i += 1
        let start = i
        // fast path: no escapes
        while i < s.count && s[i] != UInt8(ascii: "\"") && s[i] != UInt8(ascii: "\\") { i += 1 }
        guard i < s.count else { throw fail(13, "Unterminated string") }
        if s[i] == UInt8(ascii: "\"") {
            let str = String(decoding: s[start..<i], as: UTF8.self)
            i += 1
            return str
        }
        var buf = Array(s[start..<i])
        while i < s.count {
            let c = s[i]
            if c == UInt8(ascii: "\"") {
                i += 1
                return String(decoding: buf, as: UTF8.self)
            }
            if c == UInt8(ascii: "\\") {
                i += 1
                guard i < s.count else { break }
                switch s[i] {
                case UInt8(ascii: "n"): buf.append(0x0A)
                case UInt8(ascii: "r"): buf.append(0x0D)
                case UInt8(ascii: "t"): buf.append(0x09)
                case UInt8(ascii: "b"): buf.append(0x08)
                case UInt8(ascii: "f"): buf.append(0x0C)
                case UInt8(ascii: "u"):
                    if var v = hex4(i + 1) {
                        i += 4
                        if v >= 0xD800 && v < 0xDC00, i + 6 < s.count, s[i + 1] == UInt8(ascii: "\\"),
                           s[i + 2] == UInt8(ascii: "u"), let lo = hex4(i + 3), lo >= 0xDC00 && lo < 0xE000 {
                            v = 0x10000 + ((v - 0xD800) << 10) + (lo - 0xDC00)
                            i += 6
                        }
                        let u = Unicode.Scalar(v) ?? "\u{FFFD}"
                        buf.append(contentsOf: Array(String(Character(u)).utf8))
                    }
                default: buf.append(s[i])
                }
                i += 1
            } else {
                buf.append(c)
                i += 1
            }
        }
        throw fail(13, "Unterminated string")
    }

    private func parseNumber() throws -> Any {
        let start = i
        if i < s.count && (s[i] == UInt8(ascii: "-") || s[i] == UInt8(ascii: "+")) { i += 1 }
        var isDouble = false
        while i < s.count {
            let ch = s[i]
            if ch >= 48 && ch <= 57 { i += 1; continue }
            if ch == UInt8(ascii: ".") || ch == UInt8(ascii: "e") || ch == UInt8(ascii: "E") {
                isDouble = true; i += 1; continue
            }
            if ch == UInt8(ascii: "-") || ch == UInt8(ascii: "+") { i += 1; continue }
            break
        }
        guard i > start else { throw fail(14, "Malformed number") }
        let text = String(decoding: s[start..<i], as: UTF8.self)
        if !isDouble, let v = Int64(text) { return v }
        if let v = Double(text) { return v }
        throw fail(15, "Malformed number: \(text)")
    }
}
