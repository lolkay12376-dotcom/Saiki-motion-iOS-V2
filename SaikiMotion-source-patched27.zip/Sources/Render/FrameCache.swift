// FrameCache.swift — rendered-frame cache for live playback (Render).
//
// While the timeline plays, every live-rendered frame is also written as a
// JPEG into <Caches>/SaikiMotion/frames/<projectId>/. Playing the same range
// again (with no edits in between) shows the cached frames instead of
// re-running the GL pipeline, so heavy scenes stop lagging on the second pass.
// Any edit bumps `version`, which makes older frames stale (purged lazily).
// The cache lives outside the project: it can be cleared from Home → Extras
// without touching a single project.

import UIKit
import Foundation

enum FrameCache {

    /// Bumped by every edit. Starts from the clock so frames written by an earlier
    /// launch (whose project may have been edited since) can never be shown.
    static var version = Int(Date().timeIntervalSince1970) & 0x3FFFFFFF
    static var playing = false      // playback reads from / fills the cache
    static var scrubbing = false    // dragging the timeline also reads cached frames (smooth scrub)
    /// Live render cache on/off (Scene setup → Live render cache, Home → Extras).
    static var enabled: Bool = (UserDefaults.standard.object(forKey: "liveCache") as? Bool) ?? true {
        didSet { UserDefaults.standard.set(enabled, forKey: "liveCache") }
    }
    static let fps: Float = 30

    // Live (After-Effects-style) cache bookkeeping: which frames of the current
    // version / size are already on disk, so the timeline can draw the green bar and
    // the idle renderer knows what is still missing.
    static var suspended = false                    // memory warning → stop rendering ahead
    static var liveBytes: Int64 = 0                 // written this session (approx.)
    static let maxLiveBytes: Int64 = 700 * 1_048_576
    static var liveFull: Bool { liveBytes >= maxLiveBytes }
    private static var cachedIdx = Set<Int>()
    private static var cachedVer = -1
    private static var cachedKey = ""
    private static var runs: [(Float, Float)] = []
    private static var runsDirty = true

    private static let queue = DispatchQueue(label: "saiki.framecache", qos: .utility)
    private static let lock = NSLock()
    private static var pending = Set<String>()
    private static var purged: [String: Int] = [:]

    static var root: URL {
        Paths.cache.appendingPathComponent("frames", isDirectory: true)
    }

    static func bump() { version &+= 1 }

    private static func frameIndex(_ t: Float) -> Int { Int((max(0, t) * fps).rounded()) }

    private static func name(_ w: Int, _ h: Int, _ q: Int, _ t: Float) -> String {
        "\(version)_\(q)_\(w)x\(h)_\(frameIndex(t)).jpg"
    }

    private static func url(_ pid: String, _ n: String) -> URL {
        root.appendingPathComponent(pid, isDirectory: true).appendingPathComponent(n)
    }

    private static func syncSet(_ key: String) {      // call with `lock` held
        if cachedVer != version || cachedKey != key {
            cachedVer = version; cachedKey = key
            cachedIdx.removeAll(); runs = []; runsDirty = true
        }
    }

    private static func mark(_ idx: Int, _ key: String) {
        lock.lock(); syncSet(key); cachedIdx.insert(idx); runsDirty = true; lock.unlock()
    }

    private static func unmark(_ idx: Int, _ key: String) {
        lock.lock(); syncSet(key); cachedIdx.remove(idx); runsDirty = true; lock.unlock()
    }

    static func lookup(_ pid: String, _ w: Int, _ h: Int, _ q: Int, _ t: Float) -> UIImage? {
        let u = url(pid, name(w, h, q, t))
        let key = "\(pid)_\(w)x\(h)_\(q)"
        guard FileManager.default.fileExists(atPath: u.path) else { unmark(frameIndex(t), key); return nil }
        mark(frameIndex(t), key)
        return UIImage(contentsOfFile: u.path)
    }

    /// First frame at or after `t` (wrapping round) that is not cached yet; nil when
    /// the whole scene is cached.
    static func nextUncached(from t: Float, duration: Float, _ pid: String,
                             _ w: Int, _ h: Int, _ q: Int) -> Float? {
        let key = "\(pid)_\(w)x\(h)_\(q)"
        let total = max(1, Int((duration * fps).rounded(.down)))
        let start = min(total, frameIndex(t))
        lock.lock(); syncSet(key); let set = cachedIdx; lock.unlock()
        for k in 0...total {
            let i = (start + k) % (total + 1)
            if set.contains(i) { continue }
            let tt = Float(i) / fps
            if has(pid, w, h, q, tt) { mark(i, key); continue }
            return tt
        }
        return nil
    }

    /// Cached time ranges (seconds) for the timeline's green bar.
    static func cachedRuns() -> [(Float, Float)] {
        lock.lock(); defer { lock.unlock() }
        if cachedVer != version { cachedVer = version; cachedIdx.removeAll(); runs = []; runsDirty = false; return [] }
        if runsDirty {
            var out: [(Float, Float)] = []
            var a = -1, b = -1
            for i in cachedIdx.sorted() {
                if a < 0 { a = i; b = i }
                else if i == b + 1 { b = i }
                else { out.append((Float(a) / fps, Float(b + 1) / fps)); a = i; b = i }
            }
            if a >= 0 { out.append((Float(a) / fps, Float(b + 1) / fps)) }
            runs = out
            runsDirty = false
        }
        return runs
    }

    static func has(_ pid: String, _ w: Int, _ h: Int, _ q: Int, _ t: Float) -> Bool {
        FileManager.default.fileExists(atPath: url(pid, name(w, h, q, t)).path)
    }

    static func store(_ pid: String, _ w: Int, _ h: Int, _ q: Int, _ t: Float, _ img: UIImage) {
        let n = name(w, h, q, t)
        let key = pid + "/" + n
        mark(frameIndex(t), "\(pid)_\(w)x\(h)_\(q)")
        lock.lock()
        if pending.contains(key) { lock.unlock(); return }
        pending.insert(key)
        lock.unlock()
        let ver = version
        queue.async {
            let dir = root.appendingPathComponent(pid, isDirectory: true)
            try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
            if purged[pid] != ver {
                purged[pid] = ver
                liveBytes = 0
                let prefix = "\(ver)_"
                for f in (try? FileManager.default.contentsOfDirectory(atPath: dir.path)) ?? []
                where !f.hasPrefix(prefix) {
                    try? FileManager.default.removeItem(at: dir.appendingPathComponent(f))
                }
            }
            if let d = img.jpegData(compressionQuality: 0.82) {
                try? d.write(to: dir.appendingPathComponent(n), options: .atomic)
                liveBytes += Int64(d.count)
            }
            lock.lock(); pending.remove(key); lock.unlock()
        }
    }

    // MARK: size + clearing (Home → Extras)

    static func totalBytes() -> Int64 {
        var total: Int64 = 0
        let keys: [URLResourceKey] = [.fileSizeKey, .isRegularFileKey]
        if let en = FileManager.default.enumerator(at: Paths.cache, includingPropertiesForKeys: keys) {
            for case let u as URL in en {
                let v = try? u.resourceValues(forKeys: Set(keys))
                if v?.isRegularFile == true { total += Int64(v?.fileSize ?? 0) }
            }
        }
        return total
    }

    static func sizeText() -> String {
        let b = Double(totalBytes())
        if b >= 1_073_741_824 { return String(format: "%.2f GB", b / 1_073_741_824) }
        return String(format: "%.1f MB", b / 1_048_576)
    }

    /// Deletes every cached frame and thumbnail. Projects and media are untouched.
    static func clearAll() {
        lock.lock()
        pending.removeAll(); purged.removeAll()
        cachedIdx.removeAll(); runs = []; runsDirty = true; liveBytes = 0
        lock.unlock()
        let fm = FileManager.default
        for f in (try? fm.contentsOfDirectory(atPath: Paths.cache.path)) ?? [] {
            try? fm.removeItem(at: Paths.cache.appendingPathComponent(f))
        }
        if let base = fm.urls(for: .cachesDirectory, in: .userDomainMask).first {
            for f in (try? fm.contentsOfDirectory(atPath: base.path)) ?? [] where f.hasPrefix("fxthumbs") {
                try? fm.removeItem(at: base.appendingPathComponent(f))
            }
        }
        EffectThumbs.cache.removeAll()
        version &+= 1
    }
}
