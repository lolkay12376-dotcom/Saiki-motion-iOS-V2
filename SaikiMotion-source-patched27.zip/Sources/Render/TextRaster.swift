// TextRaster.swift — text layers → UIImage (Render).
//
// All UIKit text styling (families, custom .ttf/.otf, stroke, second stroke,
// border box with fill, shadow, letter case/spacing) plus the per-letter
// animation stack (slide/fade/scale/rotate/typewriter/bounce/outline draw).
// Output is cached by a signature of style + quantized time so dragging the
// playhead doesn't re-raster the same frame twice.

import UIKit
import CoreText

enum TextRaster {

    private static var customFonts: [String: String] = [:]   // path → postscript name
    private static var cgFonts: [String: CGFont] = [:]

    // MARK: - fonts

    private static func familyName(_ of: String) -> String {
        switch of {
        case "serif": return "Georgia"
        case "monospace", "serif-monospace": return "Menlo"
        case "cursive": return "Snell Roundhand"
        case "casual": return "Chalkboard SE"
        case "sans-serif-condensed": return "Avenir Next Condensed"
        case "sans-serif-light": return "Helvetica Neue"
        case "sans-serif-medium": return "Helvetica Neue Medium"
        case "sans-serif-black": return "HelveticaNeue-CondensedBlack"
        default: return "Helvetica Neue"
        }
    }

    /// Registers a font file once; returns its PostScript name.
    private static let fontLock = NSLock()
    private static func registerFont(_ path0: String) -> String? {
        fontLock.lock(); defer { fontLock.unlock() }
        let path = FontLibrary.resolve(path0)
        if let n = customFonts[path] { return n }
        guard let data = FileManager.default.contents(atPath: path) else { return nil }
        guard let provider = CGDataProvider(data: data as CFData),
              let cg = CGFont(provider) else { return nil }
        var error: Unmanaged<CFError>? = nil
        if !CTFontManagerRegisterGraphicsFont(cg, &error) {
            // already registered is fine (kCTFontManagerErrorAlreadyRegistered = 105)
            if let e = error?.takeUnretainedValue(), CFErrorGetCode(e) != 105 { return nil }
        }
        let name = cg.postScriptName as String? ?? "CustomFont"
        cgFonts[path] = cg
        customFonts[path] = name
        return name
    }

    static func font(_ l: Layer, _ px: CGFloat) -> UIFont {
        if let path = l.fontPath, let name = registerFont(path) {
            // build straight from the file's CGFont (works even if name lookup fails)
            fontLock.lock(); let cgf = cgFonts[FontLibrary.resolve(path)]; fontLock.unlock()
            if let cg = cgf {
                let ct = CTFontCreateWithGraphicsFont(cg, px, nil, nil)
                return UIFont(descriptor: CTFontCopyFontDescriptor(ct), size: px)
            }
            if let f = UIFont(name: name, size: px) { return f }
        }
        let fam = familyName(l.font)
        var f = UIFont(name: fam, size: px)
        if f == nil { f = UIFont.systemFont(ofSize: px) }
        if l.bold && !(f?.fontName.lowercased().contains("bold") ?? false) {
            if let d = f?.fontDescriptor.withSymbolicTraits(.traitBold) {
                f = UIFont(descriptor: d, size: px)
            }
        }
        if l.italic {
            let desc = f?.fontDescriptor.withSymbolicTraits(.traitItalic)
            if let d = desc { f = UIFont(descriptor: d, size: px) }
        }
        return f ?? .systemFont(ofSize: px)
    }

    private static func transformed(_ s: String, _ caps: Int) -> String {
        if caps == 1 { return s.uppercased() }
        if caps == 2 { return s.lowercased() }
        return s
    }

    // MARK: - measurement

    /// (width, height) in em-units (relative to font size 1) of the layer's
    /// text — drives quadSize.
    static func measure(_ l: Layer) -> (Float, Float) {
        let text = transformed(l.text.isEmpty ? " " : l.text, l.caps)
        let px: CGFloat = 512
        let f = font(l, px)
        let attr: [NSAttributedString.Key: Any] = [
            .font: f,
            .kern: CGFloat(l.p("spacing", 0)) * px,
        ]
        let str = NSAttributedString(string: text, attributes: attr)
        let b = str.boundingRect(with: CGSize(width: 10000, height: px * 3),
                                 options: [.usesLineFragmentOrigin],
                                 context: nil)
        let w = Float(max(b.width, px * 0.3)) / Float(px)
        let h = Float(max(b.height, px * 0.6)) / Float(px)
        return (w, h)
    }

    // MARK: - raster

    /// Renders the text layer at time `t` into a UIImage (transparent
    /// background, premultiplied alpha).
    static func raster(_ l: Layer, _ t0: Float) -> UIImage {
        let t: Float = t0.isFinite ? min(max(t0, 0), 100_000) : 0
        let text = transformed(l.text.isEmpty ? " " : l.text, l.caps)
        let px: CGFloat = 256
        let f = font(l, px)

        let spacingV = CGFloat(l.p("spacing", t))
        var attrs: [NSAttributedString.Key: Any] = [
            .font: f,
            .kern: spacingV * px,
            .foregroundColor: argbToUIColor(l.color),
        ]
        if l.underline { attrs[.underlineStyle] = NSUnderlineStyle.single.rawValue }
        if l.strike { attrs[.strikethroughStyle] = NSUnderlineStyle.single.rawValue }
        // stroke / border / shadow values live in the animatable props, not the legacy fields
        let strokeWV = CGFloat(l.p("strokeW", t)) * px
        let stroke2WV = CGFloat(l.p("stroke2W", t)) * px
        let borderWV = CGFloat(l.p("borderW", t))
        let borderPadV = CGFloat(l.p("borderPad", t))
        let borderRadV = CGFloat(l.p("borderRadius", t))
        let shX = CGFloat(l.p("shadowX", t)), shY = CGFloat(l.p("shadowY", t)), shB = CGFloat(l.p("shadowBlur", t))

        let hasAnims = !l.anims.isEmpty
        let measureStr = NSAttributedString(string: text, attributes: attrs)
        let shadowPad: CGFloat = l.shadowOn ? (abs(shX) + abs(shY) + shB * 1.5) : 0
        let strokePad: CGFloat = (strokeWV + stroke2WV) / px
        let pad: CGFloat = px * (0.35 + borderWV + borderPadV + shadowPad + strokePad)
        let tb = measureStr.boundingRect(with: CGSize(width: 10000, height: px * 4),
                                         options: [.usesLineFragmentOrigin], context: nil)
        let borderPadPx = borderPadV * px
        let borderWPx = borderWV * px
        let w = ceil(tb.width) + pad * 2
        let h = ceil(tb.height) + pad * 2
        let size = CGSize(width: min(max(w, 8), 4096), height: min(max(h, 8), 4096))

        let ts = hasAnims ? Float(Int(t * 60)) / 60 : 0
        let animSig = l.anims.map { a in
            "\(a.type),\(a.mode),\(a.start),\(a.dur),\(a.stagger),\(a.distance),\(a.scaleFrom),\(a.rotFrom),\(a.speed),\(a.ease),\(a.fade),\(a.curve.x1),\(a.curve.y1),\(a.curve.x2),\(a.curve.y2)," + a.fx.map { "\($0.kind):\($0.v)" }.joined(separator: ";")
        }.joined(separator: "|")
        let key = "\(text)|\(l.color)|\(UInt32(bitPattern: l.strokeColor))|\(strokeWV)|\(l.font)|\(l.fontPath ?? "")|\(l.bold)\(l.italic)\(l.underline)\(l.strike)|\(spacingV)|\(l.align)|\(l.caps)|\(l.strokePos)|\(l.strokeJoin)|\(stroke2WV)|\(UInt32(bitPattern: l.stroke2Color))|\(borderWV)|\(UInt32(bitPattern: l.borderColor))|\(UInt32(bitPattern: l.borderFill))|\(borderPadV)|\(borderRadV)|\(l.borderDash)|\(l.shadowOn)|\(shX)|\(shY)|\(shB)|\(UInt32(bitPattern: l.shadowColor))|\(animSig)|\(ts)"
        let ck = String(key.hashValue) + "-" + String(format: "%.0f-%.0f", size.width, size.height)
        cacheLock.lock(); let hit = cache[ck]; cacheLock.unlock()
        if let img = hit { return img }

        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 1
        fmt.opaque = false
        let r = UIGraphicsImageRenderer(size: size, format: fmt)
        let img = r.image { ctx in
            let c = ctx.cgContext
            let originY = pad   // first line's top
            let lineW = tb.width

            // border box behind the text
            if borderWV > 0.001 || colorAlpha(l.borderFill) > 0 {
                let bx = pad - borderPadPx - borderWPx / 2
                let by = pad - borderPadPx - borderWPx / 2
                let bw = lineW + (borderPadPx + borderWPx / 2) * 2
                let bh = tb.height + (borderPadPx + borderWPx / 2) * 2
                let box = CGRect(x: bx, y: by, width: bw, height: bh)
                let path = UIBezierPath(roundedRect: box, cornerRadius: borderRadV * px)
                c.saveGState()
                c.addPath(path.cgPath)
                if colorAlpha(l.borderFill) > 0 {
                    c.setFillColor(argbToUIColor(l.borderFill).cgColor)
                    c.fillPath()
                    c.addPath(path.cgPath)
                }
                if borderWV > 0.001 {
                    c.setStrokeColor(argbToUIColor(l.borderColor).cgColor)
                    c.setLineWidth(borderWPx)
                    if l.borderDash {
                        c.setLineDash(phase: 0, lengths: [borderWPx * 3, borderWPx * 2])
                    }
                    c.strokePath()
                }
                c.restoreGState()
            }

            // text block (stroke2 → stroke → fill), one shadow for the whole composite
            if l.shadowOn {
                c.saveGState()
                c.setShadow(offset: CGSize(width: shX * px, height: shY * px),
                            blur: shB * px,
                            color: argbToUIColor(l.shadowColor).cgColor)
                c.beginTransparencyLayer(auxiliaryInfo: nil)
                drawStyled(c, text, attrs, f, l, t, pad, originY, lineW, hasAnims, px, strokeWV, stroke2WV)
                c.endTransparencyLayer()
                c.restoreGState()
            } else {
                drawStyled(c, text, attrs, f, l, t, pad, originY, lineW, hasAnims, px, strokeWV, stroke2WV)
            }
        }
        cacheLock.lock()
        cache[ck] = img
        cacheOrder.append(ck)
        trimCache()
        cacheLock.unlock()
        return img
    }

    /// Layers the passes back to front: second stroke, stroke, fill.
    /// UIKit's .strokeWidth is a PERCENT of the font size, and a positive value draws
    /// stroke only — so every pass is converted from px and the fill is drawn separately.
    private static func drawStyled(_ c: CGContext, _ text: String,
                                   _ attrs: [NSAttributedString.Key: Any], _ f: UIFont,
                                   _ l: Layer, _ t: Float,
                                   _ pad: CGFloat, _ originY: CGFloat, _ lineW: CGFloat,
                                   _ animated: Bool, _ px: CGFloat,
                                   _ sw: CGFloat, _ sw2: CGFloat) {
        func pass(_ color: UIColor, _ strokeColor: UIColor?, _ widthPx: CGFloat) {
            var a = attrs
            a[.foregroundColor] = color
            if let sc = strokeColor, widthPx > 0 {
                a[.strokeColor] = sc
                a[.strokeWidth] = widthPx / f.pointSize * 100      // positive = stroke only
            }
            drawTextBlock(c, text, a, f, l, t, pad, originY, lineW, animated, px)
        }
        let fill = argbToUIColor(l.color)
        let sc = argbToUIColor(l.strokeColor)
        // stroke is centred on the outline: outside = 2×, center = 1×, inside = 1× over the fill
        let pos = l.strokePos
        let outerW = pos == 0 ? sw * 2 : sw
        if sw2 > 0.01 { pass(.clear, argbToUIColor(l.stroke2Color), (outerW / 2 + sw2) * 2 + (pos == 0 ? 0 : 0)) }
        if sw > 0.01 && pos == 0 { pass(.clear, sc, outerW) }
        pass(fill, nil, 0)
        if sw > 0.01 && pos != 0 { pass(.clear, sc, pos == 2 ? sw : sw) }
    }

    /// Draws the text (per-letter when animated).
    private static func drawTextBlock(_ c: CGContext, _ text: String,
                                      _ attrs: [NSAttributedString.Key: Any], _ f: UIFont,
                                      _ l: Layer, _ t: Float,
                                      _ pad: CGFloat, _ originY: CGFloat, _ lineW: CGFloat,
                                      _ animated: Bool, _ px: CGFloat) {
        if !animated {
            let str = NSAttributedString(string: text, attributes: attrs)
            let x: CGFloat
            switch l.align {
            case 0: x = pad
            case 2: x = pad + lineW - str.size().width
            default: x = pad + (lineW - str.size().width) / 2
            }
            str.draw(at: CGPoint(x: x, y: originY))
            return
        }

        // per-letter: measure each glyph, advance manually, apply anims
        let chars = Array(text)
        var x: CGFloat = pad
        let totalW = lineW
        if l.align == 1 { x = pad + (totalW - measurePlain(text, attrs)) / 2 }
        if l.align == 2 { x = pad + (totalW - measurePlain(text, attrs)) }

        for (i, ch) in chars.enumerated() {
            let s = String(ch)
            let glyph = NSAttributedString(string: s, attributes: attrs)
            let gs = glyph.size()
            let delay = CGFloat(i) * CGFloat(l.anims.reduce(0) { max($0, $1.stagger) })
            var alpha: CGFloat = 1
            var scale: CGFloat = 1
            var rot: CGFloat = 0
            var dx: CGFloat = 0
            var dy: CGFloat = 0
            var skx: CGFloat = 0, sky: CGFloat = 0
            var sx: CGFloat = 1, sy: CGFloat = 1, persp: CGFloat = 0
            var track: CGFloat = 0

            for a in l.anims {
                let lt = CGFloat(t) - CGFloat(a.start) - (a.type == 12 ? CGFloat(i) * CGFloat(a.stagger) : delay)
                let p = clamp(Float(lt) / max(a.dur, 0.05), 0, 1)
                let e = animEase(a, p)
                if a.type == 12 {
                    // custom: mode 0 in (from → rest), 1 out (rest → to), 2 loop (ping-pong)
                    let k: Float = a.mode == 0 ? (1 - e) : (a.mode == 1 ? e : sin(p * .pi))
                    let kk = CGFloat(k)
                    let active = lt >= 0 && lt <= CGFloat(a.dur)
                    for fx in a.fx {
                        let v = fx.v
                        switch fx.kind {
                        case 0:
                            dx += CGFloat(v[0]) * kk * px; dy += CGFloat(v[1]) * kk * px
                            scale *= 1 + (CGFloat(v[2]) - 1) * kk
                            rot += CGFloat(v[3]) * kk * .pi / 180
                            alpha *= 1 - (1 - CGFloat(v[4])) * kk
                        case 1:
                            if active || a.mode == 2 {
                                let ph = CGFloat(v[4]) * (CGFloat(t) * 2 * .pi) + CGFloat(i) * CGFloat(v[5]) * 2
                                dx += CGFloat(v[0]) * px * sin(ph)
                                dy += CGFloat(v[1]) * px * cos(ph * 1.3)
                                rot += CGFloat(v[2]) * .pi / 180 * sin(ph * 0.9)
                                scale *= 1 + CGFloat(v[3]) * sin(ph * 1.1)
                            }
                        case 2:
                            let rx = CGFloat(v[0]) * kk * .pi / 180, ry = CGFloat(v[1]) * kk * .pi / 180
                            sx *= cos(ry); sy *= cos(rx)
                            persp += CGFloat(v[2]) * (abs(sin(ry)) + abs(sin(rx))) * (sin(ry) >= 0 ? 1 : -1)
                        case 3:
                            track += CGFloat(v[0]) * kk * px
                        case 4:
                            skx += tan(CGFloat(v[0]) * kk * .pi / 180)
                            sky += tan(CGFloat(v[1]) * kk * .pi / 180)
                        default: break
                        }
                    }
                    continue
                }
                switch a.type {
                case 0: dy += CGFloat((1 - e) * a.distance) * px          // slide up in
                case 1: dy -= CGFloat((1 - e) * a.distance) * px          // slide down in
                case 2: alpha *= CGFloat(a.fade ? e : (p >= 1 ? 1 : 0.15 + 0.85 * e))   // fade in
                case 3: scale *= CGFloat(a.scaleFrom + (1 - a.scaleFrom) * e)           // scale in
                case 4: alpha *= p >= 1 ? 1 : (e > 0.5 ? 1 : 0)                        // typewriter
                case 5: scale *= CGFloat(a.scaleFrom + (1 - a.scaleFrom) * bounceOut(p)) // pop
                case 6: rot += CGFloat((1 - e) * a.rotFrom) * .pi / 180  // rotate in
                case 7: dy -= CGFloat(e * a.distance) * px               // slide up out
                case 8: alpha *= CGFloat(1 - e)                          // fade out
                case 9: dy += CGFloat(e * a.distance) * px               // slide down out
                case 10: scale *= CGFloat(a.scaleFrom + (1 - a.scaleFrom) * bounceOut(p))
                case 11: alpha *= CGFloat(e)                             // outline draw
                default: break
                }
            }

            let cx = x + gs.width / 2
            let cy = originY + gs.height / 2
            c.saveGState()
            c.translateBy(x: cx + dx, y: cy + dy)
            c.rotate(by: rot)
            c.scaleBy(x: scale, y: scale)
            if skx != 0 || sky != 0 || sx != 1 || sy != 1 || persp != 0 {
                // 3D flip / skew approximated as an affine (cos-squash + perspective shear)
                let tr = CGAffineTransform(a: sx == 0 ? 0.0001 : sx, b: sky + persp * 0.35 * sx,
                                           c: skx + persp * 0.0, d: sy == 0 ? 0.0001 : sy, tx: 0, ty: 0)
                c.concatenate(tr)
            }
            c.setAlpha(clamp(alpha, 0, 1))
            glyph.draw(at: CGPoint(x: -gs.width / 2, y: -gs.height / 2))
            c.restoreGState()

            x += gs.width + (attrs[.kern] as? CGFloat ?? 0) + track
        }
    }

    private static func measurePlain(_ s: String, _ attrs: [NSAttributedString.Key: Any]) -> CGFloat {
        NSAttributedString(string: s, attributes: attrs).size().width
    }

    private static func animEase(_ a: TextAnim, _ p: Float) -> Float {
        switch a.ease {
        case 0: return p
        case 1: return Track.bezier(p, 0, 0, 0.58, 1)
        case 2: return Track.bezier(p, 0.42, 0, 0.58, 1)
        case 3: return Track.bounceOut(p)
        case 4: return Track.bezier(p, a.curve.x1, a.curve.y1, a.curve.x2, a.curve.y2)
        default: return p
        }
    }

    private static func bounceOut(_ u: Float) -> Float { Track.bounceOut(u) }

    // MARK: - cache

    private static var cache: [String: UIImage] = [:]
    private static var cacheOrder: [String] = []
    private static let cacheLock = NSLock()

    /// Caller holds cacheLock. Evicts oldest entries (the old code never recorded order,
    /// so the cache grew forever and the app ran out of memory).
    private static func trimCache() {
        while cacheOrder.count > 40 {
            let k = cacheOrder.removeFirst()
            cache.removeValue(forKey: k)
        }
    }

    /// Called when a project closes.
    static func clearCache() {
        cacheLock.lock(); defer { cacheLock.unlock() }
        cache.removeAll()
        cacheOrder.removeAll()
    }
}
