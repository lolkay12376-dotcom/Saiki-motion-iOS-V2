// DrawingStore.swift — persistence for the Drawing Editor (gallery items, folders, layers).
//
// Layout on disk:  Documents/Drawings/index.json
//                  Documents/Drawings/<artId>/<layerId>.png   (one PNG per bitmap layer)
//                  Documents/Drawings/<artId>/thumb.png
// Folders in the gallery are index entries only (isFolder == true).

import UIKit
import Foundation

struct DrawLayerMeta: Codable {
    var id: String
    var name: String
    var visible = true
    var opacity: Float = 1
    var isFolder = false
    var parent: String? = nil
    var expanded = true
}

struct DrawItem: Codable {
    var id: String
    var name: String
    var isFolder: Bool
    var parent: String?              // gallery folder id, nil = root
    var w = 0
    var h = 0
    var paperWhite = true            // false = transparent canvas
    var updated = Date()
    var layers: [DrawLayerMeta] = []
    var activeLayer: String? = nil
}

enum DrawPresets {
    static let list: [(String, Int, Int)] = [
        ("HD (Quality)", 1080, 2340), ("1:1 (2K)", 2048, 2048), ("3:4 (2K)", 1536, 2048),
        ("9:16 (2K)", 1080, 1920), ("X Header", 1500, 500), ("Chat Stamp", 370, 320),
        ("Vertical", 690, 4096), ("Postcard (JP) 300 dpi", 1181, 1748), ("A4 150 dpi", 1240, 1754),
    ]
    static let maxSide = 4096
    static let maxPixels = 8_400_000
    static func valid(_ w: Int, _ h: Int) -> Bool {
        w >= 16 && h >= 16 && w <= maxSide && h <= maxSide && w * h <= maxPixels
    }
}

enum DrawStore {
    private static var cache: [DrawItem]? = nil
    private static let lock = NSLock()

    static func root() -> URL {
        let d = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Drawings", isDirectory: true)
        try? FileManager.default.createDirectory(at: d, withIntermediateDirectories: true)
        return d
    }
    static func dir(_ artId: String) -> URL {
        let d = root().appendingPathComponent(artId, isDirectory: true)
        try? FileManager.default.createDirectory(at: d, withIntermediateDirectories: true)
        return d
    }
    static func layerURL(_ artId: String, _ layerId: String) -> URL { dir(artId).appendingPathComponent(layerId + ".png") }
    static func thumbURL(_ artId: String) -> URL { dir(artId).appendingPathComponent("thumb.png") }

    // MARK: index

    static func all() -> [DrawItem] {
        lock.lock(); defer { lock.unlock() }
        if let c = cache { return c }
        let url = root().appendingPathComponent("index.json")
        var items: [DrawItem] = []
        if let data = try? Data(contentsOf: url),
           let dec = try? JSONDecoder().decode([DrawItem].self, from: data) { items = dec }
        cache = items
        return items
    }
    private static func write(_ items: [DrawItem]) {
        lock.lock(); cache = items; lock.unlock()
        let url = root().appendingPathComponent("index.json")
        if let data = try? JSONEncoder().encode(items) { try? data.write(to: url, options: .atomic) }
    }

    static func items(in parent: String?) -> [DrawItem] {
        all().filter { $0.parent == parent }.sorted {
            if $0.isFolder != $1.isFolder { return $0.isFolder }
            return $0.updated > $1.updated
        }
    }
    static func item(_ id: String) -> DrawItem? { all().first { $0.id == id } }

    static func upsert(_ it: DrawItem) {
        var a = all()
        if let i = a.firstIndex(where: { $0.id == it.id }) { a[i] = it } else { a.append(it) }
        write(a)
    }

    @discardableResult
    static func makeFolder(_ name: String, parent: String?) -> DrawItem {
        let f = DrawItem(id: UUID().uuidString, name: name, isFolder: true, parent: parent)
        upsert(f)
        return f
    }

    /// Finds (or creates) a root-level gallery folder by name.
    static func folder(named name: String) -> DrawItem {
        if let f = all().first(where: { $0.isFolder && $0.parent == nil && $0.name == name }) { return f }
        return makeFolder(name, parent: nil)
    }

    static func newArtwork(name: String, w: Int, h: Int, parent: String?, paperWhite: Bool = true) -> DrawItem {
        var it = DrawItem(id: UUID().uuidString, name: name, isFolder: false, parent: parent)
        it.w = w; it.h = h; it.paperWhite = paperWhite
        let l = DrawLayerMeta(id: UUID().uuidString, name: "Layer 1")
        it.layers = [l]
        it.activeLayer = l.id
        upsert(it)
        return it
    }

    static func rename(_ id: String, _ name: String) {
        guard var it = item(id) else { return }
        it.name = name; it.updated = Date(); upsert(it)
    }
    static func move(_ id: String, to parent: String?) {
        guard var it = item(id), it.id != parent else { return }
        // never move a folder into itself or one of its own descendants
        var p = parent
        while let pid = p { if pid == id { return }; p = item(pid)?.parent }
        it.parent = parent; upsert(it)
    }

    static func delete(_ id: String) {
        var a = all()
        func kill(_ i: String) {
            for c in a where c.parent == i { kill(c.id) }
            try? FileManager.default.removeItem(at: root().appendingPathComponent(i))
            a.removeAll { $0.id == i }
        }
        kill(id)
        write(a)
    }

    static func duplicate(_ id: String) {
        guard var it = item(id), !it.isFolder else { return }
        let old = it.id
        it.id = UUID().uuidString
        it.name += " copy"
        it.updated = Date()
        for i in 0..<it.layers.count {
            let oldL = it.layers[i].id
            it.layers[i].id = UUID().uuidString
            if it.activeLayer == oldL { it.activeLayer = it.layers[i].id }
            for j in 0..<it.layers.count where it.layers[j].parent == oldL { it.layers[j].parent = it.layers[i].id }
            let src = layerURL(old, oldL)
            if FileManager.default.fileExists(atPath: src.path) {
                try? FileManager.default.copyItem(at: src, to: layerURL(it.id, it.layers[i].id))
            }
        }
        try? FileManager.default.copyItem(at: thumbURL(old), to: thumbURL(it.id))
        upsert(it)
    }

    static func count(in parent: String?) -> Int { all().filter { $0.parent == parent }.count }
    static func totalArtworks() -> Int { all().filter { !$0.isFolder }.count }

    static func path(of id: String?) -> [DrawItem] {
        var out: [DrawItem] = []
        var p = id
        while let pid = p, let it = item(pid) { out.insert(it, at: 0); p = it.parent }
        return out
    }
}

// MARK: - Import from the Anime Decomposer ----------------------------------------------

enum DrawImport {
    /// Creates (or reuses) the "Anime Decomposition" gallery folder and drops the layers into a
    /// new artwork inside it, keeping the auto-groups as layer folders.
    static func fromDecomposed(_ r: DecomposeResult, name: String) -> DrawItem {
        let folder = DrawStore.folder(named: "Anime Decomposition")
        var art = DrawStore.newArtwork(name: name, w: r.width, h: r.height, parent: folder.id, paperWhite: false)
        art.layers = []
        var groupId: [String: String] = [:]
        let ordered = r.layers.enumerated().sorted { ($0.element.order, $0.offset) < ($1.element.order, $1.offset) }
        var metas: [DrawLayerMeta] = []
        for (_, l) in ordered {
            var parent: String? = nil
            if !l.group.isEmpty {
                if let g = groupId[l.group] { parent = g } else {
                    let g = DrawLayerMeta(id: UUID().uuidString, name: l.group, isFolder: true)
                    groupId[l.group] = g.id
                    metas.append(g)
                    parent = g.id
                }
            }
            let id = UUID().uuidString
            var m = DrawLayerMeta(id: id, name: l.name)
            m.visible = l.visible
            m.parent = parent
            let full = AnimeDecomposer.fullCanvas(l, width: r.width, height: r.height)
            if let img = AnimeDecomposer.image(from: full, width: r.width, height: r.height),
               let png = img.pngData() {
                try? png.write(to: DrawStore.layerURL(art.id, id), options: .atomic)
            }
            metas.append(m)
        }
        // folders are only organisers; keep each folder directly before its children
        var arranged: [DrawLayerMeta] = []
        for m in metas where m.isFolder {
            arranged.append(m)
            arranged.append(contentsOf: metas.filter { $0.parent == m.id })
        }
        arranged.append(contentsOf: metas.filter { !$0.isFolder && $0.parent == nil })
        art.layers = arranged
        art.activeLayer = arranged.last(where: { !$0.isFolder })?.id
        art.updated = Date()
        DrawStore.upsert(art)
        return art
    }

    /// Photo / file → new artwork whose single layer is the picture.
    static func fromImage(_ img: UIImage, name: String, parent: String?) -> DrawItem? {
        guard let cg = img.cgImage else { return nil }
        var w = cg.width, h = cg.height
        let maxS = CGFloat(DrawPresets.maxSide)
        var scale = min(1, maxS / CGFloat(max(w, h)))
        if CGFloat(w * h) * scale * scale > CGFloat(DrawPresets.maxPixels) {
            scale = (CGFloat(DrawPresets.maxPixels) / CGFloat(w * h)).squareRoot()
        }
        w = max(16, Int(CGFloat(w) * scale)); h = max(16, Int(CGFloat(h) * scale))
        let art = DrawStore.newArtwork(name: name, w: w, h: h, parent: parent)
        guard let ctx = CGContext(data: nil, width: w, height: h, bitsPerComponent: 8, bytesPerRow: w * 4,
                                  space: CGColorSpaceCreateDeviceRGB(),
                                  bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return art }
        ctx.interpolationQuality = .high
        ctx.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h))
        if let out = ctx.makeImage(), let png = UIImage(cgImage: out).pngData(), let id = art.layers.first?.id {
            try? png.write(to: DrawStore.layerURL(art.id, id), options: .atomic)
        }
        return art
    }
}
