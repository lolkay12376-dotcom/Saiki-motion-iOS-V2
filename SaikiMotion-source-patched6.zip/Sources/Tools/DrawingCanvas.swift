// DrawingCanvas.swift — bitmap layers, brush / eraser / smudge engine, undo and the canvas view.
//
// Every layer is a premultiplied-RGBA buffer the size of the canvas. A stroke is accumulated
// in an 8-bit coverage covMask and composited from a snapshot at the stroke opacity, so
// overlapping dabs never stack (the same behaviour as Ibis Paint's opacity slider).

import UIKit
import Foundation

enum DrawTool { case brush, eraser, smudge, eyedropper, transform }

/// Customisable brush tip / stroke behaviour (shared by brush and eraser).
struct BrushStyle: Codable, Equatable {
    var name = "Pen"
    var hardness: CGFloat = 0.78      // 0 = fully soft edge, 1 = hard edge
    var spacing: CGFloat = 0.12       // dab distance as a fraction of the radius
    var scatter: CGFloat = 0          // random dab offset (fraction of radius)
    var grain: CGFloat = 0            // paper / chalk texture strength
    var sizeJitter: CGFloat = 0       // random dab size reduction
    var pressureSize: CGFloat = 1     // how much pen pressure changes the size
    var square = false                // square tip

    static let presets: [BrushStyle] = [
        BrushStyle(),
        BrushStyle(name: "Pencil", hardness: 0.55, spacing: 0.1, grain: 0.55),
        BrushStyle(name: "Marker", hardness: 0.92, spacing: 0.08, pressureSize: 0, square: true),
        BrushStyle(name: "Airbrush", hardness: 0, spacing: 0.08),
        BrushStyle(name: "Chalk", hardness: 0.6, spacing: 0.3, scatter: 0.25, grain: 0.85, sizeJitter: 0.25),
    ]
}

// MARK: - Layer bitmap ------------------------------------------------------------------

final class PixLayer {
    var meta: DrawLayerMeta
    let w: Int, h: Int
    var sourceURL: URL?
    var dirty = false
    private var store: UnsafeMutablePointer<UInt8>?
    private var _ctx: CGContext?
    static var loadedBytes = 0

    init(_ meta: DrawLayerMeta, w: Int, h: Int, url: URL? = nil) {
        self.meta = meta; self.w = w; self.h = h; self.sourceURL = url
    }
    deinit { release() }

    var isLoaded: Bool { store != nil }
    /// Pixels (premultiplied RGBA). Loaded from disk on first use.
    var buf: UnsafeMutablePointer<UInt8> { load(); return store! }
    var ctx: CGContext? { if meta.isFolder { return nil }; load(); return _ctx }

    private func load() {
        if store != nil { return }
        if meta.isFolder {
            store = UnsafeMutablePointer<UInt8>.allocate(capacity: 4)
            store!.initialize(repeating: 0, count: 4)
            return
        }
        let n = w * h * 4
        let p = UnsafeMutablePointer<UInt8>.allocate(capacity: n)
        p.initialize(repeating: 0, count: n)
        store = p
        PixLayer.loadedBytes += n
        _ctx = CGContext(data: p, width: w, height: h, bitsPerComponent: 8, bytesPerRow: w * 4,
                         space: CGColorSpaceCreateDeviceRGB(),
                         bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)
        if let u = sourceURL, FileManager.default.fileExists(atPath: u.path) { loadPNG(u) }
    }

    private func release() {
        guard let p = store else { return }
        p.deallocate(); store = nil; _ctx = nil
        if !meta.isFolder { PixLayer.loadedBytes -= w * h * 4 }
    }

    /// Frees the pixels of a layer whose PNG on disk is up to date.
    func unload() { if !dirty && !meta.isFolder { release() } }

    /// Live (not copied) view of the pixels, for drawing.
    func liveImage() -> CGImage? {
        let n = w * h * 4
        guard let p = CGDataProvider(dataInfo: nil, data: buf, size: n, releaseData: { _, _, _ in }) else { return nil }
        return CGImage(width: w, height: h, bitsPerComponent: 8, bitsPerPixel: 32, bytesPerRow: w * 4,
                       space: CGColorSpaceCreateDeviceRGB(),
                       bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.premultipliedLast.rawValue),
                       provider: p, decode: nil, shouldInterpolate: true, intent: .defaultIntent)
    }

    private func loadPNG(_ url: URL) {
        guard let c = _ctx, let cg = UIImage(contentsOfFile: url.path)?.cgImage else { return }
        c.interpolationQuality = .high
        c.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h))
    }

    func pngData() -> Data? {
        guard let cg = ctx?.makeImage() else { return nil }
        return UIImage(cgImage: cg).pngData()
    }

    func clear() { buf.update(repeating: 0, count: w * h * 4); dirty = true }
}

// MARK: - Document ----------------------------------------------------------------------

final class DrawDoc {
    var item: DrawItem
    var layers: [PixLayer] = []          // index 0 = bottom
    var activeId: String?
    var w: Int { item.w }
    var h: Int { item.h }

    init(_ item: DrawItem) {
        self.item = item
        for m in item.layers {
            layers.append(PixLayer(m, w: item.w, h: item.h, url: m.isFolder ? nil : DrawStore.layerURL(item.id, m.id)))
        }
        activeId = item.activeLayer ?? layers.last(where: { !$0.meta.isFolder })?.meta.id
        if layers.isEmpty { addLayer(name: "Layer 1") }
        if active == nil { activeId = layers.last(where: { !$0.meta.isFolder })?.meta.id }
    }

    var active: PixLayer? { layers.first { $0.meta.id == activeId && !$0.meta.isFolder } }
    var activeIndex: Int { layers.firstIndex { $0.meta.id == activeId } ?? -1 }

    func layer(_ id: String) -> PixLayer? { layers.first { $0.meta.id == id } }
    func parentChain(_ l: PixLayer) -> [PixLayer] {
        var out: [PixLayer] = []
        var p = l.meta.parent
        while let pid = p, let f = layer(pid) { out.append(f); p = f.meta.parent }
        return out
    }
    func shown(_ l: PixLayer) -> Bool { l.meta.visible && parentChain(l).allSatisfy { $0.meta.visible } }
    func alpha(_ l: PixLayer) -> CGFloat {
        var a = CGFloat(l.meta.opacity)
        for f in parentChain(l) { a *= CGFloat(f.meta.opacity) }
        return a
    }

    @discardableResult
    func addLayer(name: String? = nil, folder: Bool = false) -> PixLayer {
        let count = layers.filter { $0.meta.isFolder == folder }.count + 1
        var m = DrawLayerMeta(id: UUID().uuidString, name: name ?? (folder ? "Folder \(count)" : "Layer \(count)"))
        m.isFolder = folder
        if let a = layers.first(where: { $0.meta.id == activeId }) {
            m.parent = a.meta.isFolder ? a.meta.id : a.meta.parent
        }
        let l = PixLayer(m, w: w, h: h, url: nil)
        l.dirty = !folder
        var at = layers.count
        if let ai = layers.firstIndex(where: { $0.meta.id == activeId }) { at = ai + 1 }
        layers.insert(l, at: min(at, layers.count))
        if folder, let a = active, a.meta.parent == m.parent { a.meta.parent = m.id }
        activeId = folder ? activeId : m.id
        return l
    }

    func duplicate(_ l: PixLayer) {
        guard !l.meta.isFolder, let i = layers.firstIndex(where: { $0 === l }) else { return }
        var m = l.meta
        m.id = UUID().uuidString; m.name += " copy"
        let c = PixLayer(m, w: w, h: h, url: nil)
        c.buf.update(from: l.buf, count: w * h * 4)
        c.dirty = true
        layers.insert(c, at: i + 1)
        activeId = m.id
    }

    func remove(_ l: PixLayer) {
        let id = l.meta.id
        for c in layers where c.meta.parent == id { c.meta.parent = l.meta.parent }
        layers.removeAll { $0 === l }
        try? FileManager.default.removeItem(at: DrawStore.layerURL(item.id, id))
        if layers.filter({ !$0.meta.isFolder }).isEmpty { addLayer(name: "Layer 1") }
        if active == nil { activeId = layers.last(where: { !$0.meta.isFolder })?.meta.id }
    }

    func mergeDown(_ l: PixLayer) -> Bool {
        guard !l.meta.isFolder, let i = layers.firstIndex(where: { $0 === l }) else { return false }
        guard let below = layers[..<i].last(where: { !$0.meta.isFolder }), let ctx = below.ctx,
              let img = l.liveImage() else { return false }
        ctx.setAlpha(alpha(l))
        ctx.draw(img, in: CGRect(x: 0, y: 0, width: w, height: h))
        ctx.setAlpha(1)
        below.dirty = true
        remove(l)
        activeId = below.meta.id
        return true
    }

    /// Moves a layer one step up (+1) or down (-1) in the stack, skipping over its own folder rows.
    func move(_ l: PixLayer, by d: Int) {
        guard let i = layers.firstIndex(where: { $0 === l }) else { return }
        let j = i + d
        guard j >= 0 && j < layers.count else { return }
        layers.swapAt(i, j)
    }

    // MARK: composite helpers

    func composite(range: Range<Int>, into ctx: CGContext) {
        for i in range where i >= 0 && i < layers.count {
            let l = layers[i]
            guard !l.meta.isFolder, shown(l), let img = l.liveImage() else { continue }
            ctx.setAlpha(alpha(l))
            ctx.draw(img, in: CGRect(x: 0, y: 0, width: w, height: h))
            trim(keep: nil)
        }
        ctx.setAlpha(1)
    }

    /// Keeps the RAM used by layer bitmaps bounded: clean layers are re-read from disk when needed.
    func trim(keep: PixLayer?) {
        guard PixLayer.loadedBytes > 380_000_000 else { return }
        for l in layers where l !== keep && l !== active && l.isLoaded && !l.dirty {
            l.unload()
            if PixLayer.loadedBytes <= 300_000_000 { break }
        }
    }

    func makeContext() -> CGContext? {
        CGContext(data: nil, width: w, height: h, bitsPerComponent: 8, bytesPerRow: 0,
                  space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)
    }

    func flattenContext(withPaper: Bool) -> CGContext? {
        guard let c = makeContext() else { return nil }
        if withPaper && item.paperWhite {
            c.setFillColor(UIColor.white.cgColor)
            c.fill(CGRect(x: 0, y: 0, width: w, height: h))
        }
        composite(range: 0..<layers.count, into: c)
        return c
    }
    func flatten(withPaper: Bool) -> CGImage? { flattenContext(withPaper: withPaper)?.makeImage() }

    // MARK: saving

    func syncMeta() {
        item.layers = layers.map { $0.meta }
        item.activeLayer = activeId
        item.updated = Date()
    }

    func save() {
        for l in layers where !l.meta.isFolder && l.dirty {
            if let d = l.pngData() { try? d.write(to: DrawStore.layerURL(item.id, l.meta.id), options: .atomic) }
            l.dirty = false
        }
        trim(keep: nil)
        if let cg = flatten(withPaper: true) {
            let maxS: CGFloat = 360
            let sc = min(1, maxS / CGFloat(max(w, h)))
            let tw = max(1, Int(CGFloat(w) * sc)), th = max(1, Int(CGFloat(h) * sc))
            let r = UIGraphicsImageRenderer(size: CGSize(width: tw, height: th))
            let img = r.image { _ in UIImage(cgImage: cg).draw(in: CGRect(x: 0, y: 0, width: tw, height: th)) }
            try? img.pngData()?.write(to: DrawStore.thumbURL(item.id), options: .atomic)
        }
        syncMeta()
        DrawStore.upsert(item)
    }
}

// MARK: - Undo --------------------------------------------------------------------------

struct DrawUndo {
    var layerId: String
    var x: Int, y: Int, w: Int, h: Int
    var before: [UInt8]
    var after: [UInt8]
}

// MARK: - Canvas view -------------------------------------------------------------------

final class DrawingCanvasView: UIView, UIGestureRecognizerDelegate {
    var doc: DrawDoc! { didSet { cachesDirty = true; fit() } }
    var tool: DrawTool = .brush { didSet { if tool != .transform { cancelTransform() } } }
    var brushSize: CGFloat = 12          // canvas pixels
    var opacity: CGFloat = 1
    var style = BrushStyle()
    var color = UIColor.black
    var onColorPicked: ((UIColor) -> Void)?
    var onChanged: (() -> Void)?         // after a stroke / undo / redo / transform
    var onTransformState: ((Bool) -> Void)?
    var onBlocked: ((String) -> Void)?

    private(set) var undoStack: [DrawUndo] = []
    private(set) var redoStack: [DrawUndo] = []
    private var undoBytes = 0

    // view transform
    private var scale: CGFloat = 1, tx: CGFloat = 0, ty: CGFloat = 0
    // caches
    private var below: CGImage?, above: CGImage?
    var cachesDirty = true
    // stroke state
    private var snap: UnsafeMutablePointer<UInt8>?
    private var covMask: UnsafeMutablePointer<UInt8>?
    private var stroking = false
    private var pending: CGPoint?
    private var pendingTime: TimeInterval = 0
    private var lastPt = CGPoint.zero
    private var carry: CGFloat = 0
    private var dminX = 0, dminY = 0, dmaxX = 0, dmaxY = 0
    private var strokeLayer: PixLayer?
    private var patch: [Float] = []
    private var patchR = 0
    private var holdTimer: Timer?
    private var picking = false
    private let bubble = UIView()
    // layer transform
    private var tfDX: CGFloat = 0, tfDY: CGFloat = 0, tfScale: CGFloat = 1, tfAngle: CGFloat = 0
    var isTransforming: Bool { tfDX != 0 || tfDY != 0 || tfScale != 1 || tfAngle != 0 }

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor(white: 0.12, alpha: 1)
        isMultipleTouchEnabled = true
        clipsToBounds = true
        let pinch = UIPinchGestureRecognizer(target: self, action: #selector(onPinch(_:)))
        let pan = UIPanGestureRecognizer(target: self, action: #selector(onPan(_:)))
        pan.minimumNumberOfTouches = 2
        let rot = UIRotationGestureRecognizer(target: self, action: #selector(onRotate(_:)))
        for g in [pinch, pan, rot] as [UIGestureRecognizer] { g.delegate = self; addGestureRecognizer(g) }
        bubble.frame = CGRect(x: 0, y: 0, width: 54, height: 54)
        bubble.layer.cornerRadius = 27
        bubble.layer.borderWidth = 4
        bubble.layer.borderColor = UIColor(white: 0.9, alpha: 1).cgColor
        bubble.isHidden = true
        bubble.isUserInteractionEnabled = false
        addSubview(bubble)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
    deinit { snap?.deallocate(); covMask?.deallocate() }

    func gestureRecognizer(_ a: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith b: UIGestureRecognizer) -> Bool { true }

    override func layoutSubviews() {
        super.layoutSubviews()
        if scale == 1 && tx == 0 && ty == 0 && doc != nil { fit() }
    }

    func fit() {
        guard doc != nil, bounds.width > 10 else { return }
        let s = min(bounds.width / CGFloat(doc.w), bounds.height / CGFloat(doc.h)) * 0.94
        scale = s
        tx = (bounds.width - CGFloat(doc.w) * s) / 2
        ty = (bounds.height - CGFloat(doc.h) * s) / 2
        setNeedsDisplay()
    }

    var zoomScale: CGFloat { scale }
    func toCanvas(_ p: CGPoint) -> CGPoint { CGPoint(x: (p.x - tx) / scale, y: (p.y - ty) / scale) }
    private func toView(_ p: CGPoint) -> CGPoint { CGPoint(x: p.x * scale + tx, y: p.y * scale + ty) }

    private var pickCtx: CGContext?
    func invalidateCaches() { cachesDirty = true; pickCtx = nil; setNeedsDisplay() }

    // MARK: drawing the view

    private func rebuildCaches() {
        cachesDirty = false
        below = nil; above = nil
        guard doc != nil else { return }
        let ai = doc.activeIndex
        let n = doc.layers.count
        if ai > 0, let c = doc.makeContext() { doc.composite(range: 0..<ai, into: c); below = c.makeImage() }
        if ai >= 0 && ai + 1 < n, let c = doc.makeContext() { doc.composite(range: (ai + 1)..<n, into: c); above = c.makeImage() }
        if ai < 0, let c = doc.makeContext() { doc.composite(range: 0..<n, into: c); below = c.makeImage() }
    }

    override func draw(_ rect: CGRect) {
        guard doc != nil, let c = UIGraphicsGetCurrentContext() else { return }
        if cachesDirty { rebuildCaches() }
        let cw = CGFloat(doc.w), ch = CGFloat(doc.h)
        let canvasRect = CGRect(x: tx, y: ty, width: cw * scale, height: ch * scale)
        c.saveGState()
        c.clip(to: canvasRect)
        if doc.item.paperWhite {
            c.setFillColor(UIColor.white.cgColor); c.fill(canvasRect)
        } else {
            c.setFillColor(UIColor(white: 0.30, alpha: 1).cgColor); c.fill(canvasRect)
            c.setFillColor(UIColor(white: 0.42, alpha: 1).cgColor)
            let t: CGFloat = 12
            let vis = rect.intersection(canvasRect)
            var y = floor((vis.minY - ty) / t) * t + ty
            while y < vis.maxY {
                var x = floor((vis.minX - tx) / t) * t + tx
                while x < vis.maxX {
                    let ix = Int(((x - tx) / t).rounded()), iy = Int(((y - ty) / t).rounded())
                    if (ix + iy) & 1 == 0 { c.fill(CGRect(x: x, y: y, width: t, height: t)) }
                    x += t
                }
                y += t
            }
        }
        c.interpolationQuality = scale < 1 ? .medium : .none
        let full = CGRect(x: tx, y: ty, width: cw * scale, height: ch * scale)
        if let b = below { UIImage(cgImage: b).draw(in: full) }
        if let a = doc.active, doc.shown(a), let img = a.liveImage() {
            c.saveGState()
            if tool == .transform && isTransforming {
                c.translateBy(x: tx, y: ty); c.scaleBy(x: scale, y: scale)
                c.concatenate(layerTransform())
                UIImage(cgImage: img).draw(in: CGRect(x: 0, y: 0, width: cw, height: ch), blendMode: .normal, alpha: doc.alpha(a))
            } else {
                UIImage(cgImage: img).draw(in: full, blendMode: .normal, alpha: doc.alpha(a))
            }
            c.restoreGState()
        }
        if let a = above { UIImage(cgImage: a).draw(in: full) }
        c.restoreGState()
        c.setStrokeColor(UIColor(white: 1, alpha: 0.18).cgColor)
        c.setLineWidth(1)
        c.stroke(canvasRect.insetBy(dx: -0.5, dy: -0.5))
    }

    // MARK: navigation gestures

    @objc private func onPan(_ g: UIPanGestureRecognizer) {
        if g.state == .began { abortStroke() }
        let d = g.translation(in: self)
        g.setTranslation(.zero, in: self)
        if tool == .transform { tfDX += d.x / scale; tfDY += d.y / scale; onTransformState?(true) }
        else { tx += d.x; ty += d.y }
        setNeedsDisplay()
    }

    @objc private func onPinch(_ g: UIPinchGestureRecognizer) {
        if g.state == .began { abortStroke() }
        let f = g.scale
        g.scale = 1
        if tool == .transform {
            tfScale = max(0.05, min(20, tfScale * f)); onTransformState?(true)
        } else {
            let p = g.location(in: self)
            let ns = max(0.05, min(40, scale * f))
            let k = ns / scale
            tx = p.x - (p.x - tx) * k
            ty = p.y - (p.y - ty) * k
            scale = ns
        }
        setNeedsDisplay()
    }

    @objc private func onRotate(_ g: UIRotationGestureRecognizer) {
        if g.state == .began { abortStroke() }
        if tool == .transform {
            tfAngle += g.rotation
            onTransformState?(true)
            setNeedsDisplay()
        }
        g.rotation = 0
    }

    // MARK: layer transform

    private func layerTransform() -> CGAffineTransform {
        let cx = CGFloat(doc.w) / 2, cy = CGFloat(doc.h) / 2
        var t = CGAffineTransform(translationX: cx + tfDX, y: cy + tfDY)
        t = t.rotated(by: tfAngle).scaledBy(x: tfScale, y: tfScale)
        return t.translatedBy(x: -cx, y: -cy)
    }

    func cancelTransform() {
        guard isTransforming else { return }
        tfDX = 0; tfDY = 0; tfScale = 1; tfAngle = 0
        onTransformState?(false)
        setNeedsDisplay()
    }

    func applyTransform() {
        guard isTransforming, let layer = doc.active, let old = layer.liveImage() else { return }
        let n = doc.w * doc.h * 4
        let before = Array(UnsafeBufferPointer(start: layer.buf, count: n))
        let tmp = UnsafeMutablePointer<UInt8>.allocate(capacity: n)
        tmp.initialize(repeating: 0, count: n)
        defer { tmp.deallocate() }
        guard let c = CGContext(data: tmp, width: doc.w, height: doc.h, bitsPerComponent: 8, bytesPerRow: doc.w * 4,
                                space: CGColorSpaceCreateDeviceRGB(),
                                bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return }
        c.interpolationQuality = .high
        c.translateBy(x: 0, y: CGFloat(doc.h)); c.scaleBy(x: 1, y: -1)
        UIGraphicsPushContext(c)
        c.concatenate(layerTransform())
        UIImage(cgImage: old).draw(in: CGRect(x: 0, y: 0, width: doc.w, height: doc.h))
        UIGraphicsPopContext()
        layer.buf.update(from: tmp, count: n)
        layer.dirty = true
        let after = Array(UnsafeBufferPointer(start: layer.buf, count: n))
        pushUndo(DrawUndo(layerId: layer.meta.id, x: 0, y: 0, w: doc.w, h: doc.h, before: before, after: after))
        tfDX = 0; tfDY = 0; tfScale = 1; tfAngle = 0
        onTransformState?(false)
        setNeedsDisplay()
        onChanged?()
    }

    // MARK: undo / redo

    private func pushUndo(_ u: DrawUndo) {
        undoStack.append(u); undoBytes += u.before.count + u.after.count
        for r in redoStack { undoBytes -= r.before.count + r.after.count }
        redoStack.removeAll()
        while undoBytes > 160_000_000 && undoStack.count > 1 {
            let f = undoStack.removeFirst(); undoBytes -= f.before.count + f.after.count
        }
    }
    var canUndo: Bool { !undoStack.isEmpty }
    var canRedo: Bool { !redoStack.isEmpty }

    private func apply(_ u: DrawUndo, _ pixels: [UInt8]) {
        guard let l = doc.layer(u.layerId), !l.meta.isFolder else { return }
        pixels.withUnsafeBufferPointer { src in
            for row in 0..<u.h {
                let d = l.buf + ((u.y + row) * doc.w + u.x) * 4
                (d).update(from: src.baseAddress! + row * u.w * 4, count: u.w * 4)
            }
        }
        l.dirty = true
        invalidateCaches()
    }

    func undo() {
        guard let u = undoStack.popLast() else { return }
        apply(u, u.before); redoStack.append(u); onChanged?()
    }
    func redo() {
        guard let u = redoStack.popLast() else { return }
        apply(u, u.after); undoStack.append(u); onChanged?()
    }

    // MARK: touches

    private func pressure(_ t: UITouch) -> CGFloat {
        guard t.type == .pencil, t.maximumPossibleForce > 0 else { return 1 }
        return 0.35 + 0.65 * min(1, t.force / t.maximumPossibleForce)
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first, doc != nil else { return }
        if (event?.allTouches?.count ?? 1) > 1 { abortStroke(); return }
        let p = toCanvas(t.location(in: self))
        if tool == .eyedropper { picking = true; pickAt(p, t.location(in: self)); return }
        if tool == .transform { lastPt = t.location(in: self); return }
        guard let l = doc.active else { onBlocked?("Select a layer first"); return }
        if !doc.shown(l) { onBlocked?("This layer is hidden"); return }
        pending = p
        pendingTime = t.timestamp
        lastPt = p
        holdTimer?.invalidate()
        if tool == .brush || tool == .eraser {
            holdTimer = Timer.scheduledTimer(withTimeInterval: 0.45, repeats: false) { [weak self] _ in
                guard let self = self, self.pending != nil, !self.stroking else { return }
                self.pending = nil
                self.picking = true
                self.pickAt(self.lastPt, self.toView(self.lastPt))
            }
        }
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first, doc != nil else { return }
        if (event?.allTouches?.count ?? 1) > 1 { abortStroke(); return }
        let vp = t.location(in: self)
        let p = toCanvas(vp)
        if picking { pickAt(p, vp); return }
        if tool == .transform {
            tfDX += (vp.x - lastPt.x) / scale; tfDY += (vp.y - lastPt.y) / scale
            lastPt = vp; onTransformState?(true); setNeedsDisplay(); return
        }
        if let s = pending {
            if hypot(p.x - s.x, p.y - s.y) * scale < 4 { return }
            holdTimer?.invalidate()
            beginStroke(at: s, pressure: pressure(t))
            pending = nil
        }
        guard stroking else { return }
        // use coalesced touches for smooth lines
        let all = event?.coalescedTouches(for: t) ?? [t]
        for ct in all { extendStroke(to: toCanvas(ct.location(in: self)), pressure: pressure(ct)) }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        holdTimer?.invalidate()
        if picking { picking = false; bubble.isHidden = true; return }
        if let s = pending, let t = touches.first {                // a tap = one dab
            pending = nil
            beginStroke(at: s, pressure: pressure(t))
        }
        if stroking { endStroke() }
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        holdTimer?.invalidate()
        picking = false; bubble.isHidden = true
        abortStroke()
    }

    // MARK: eyedropper

    private func pickAt(_ p: CGPoint, _ viewPt: CGPoint) {
        if pickCtx == nil { pickCtx = doc.flattenContext(withPaper: true) }
        let x = Int(p.x), y = Int(p.y)
        bubble.center = CGPoint(x: viewPt.x, y: max(40, viewPt.y - 70))
        guard let c = pickCtx, let d = c.data, x >= 0, y >= 0, x < c.width, y < c.height else { return }
        let px = d.assumingMemoryBound(to: UInt8.self) + y * c.bytesPerRow + x * 4
        let a = CGFloat(px[3]) / 255
        let col: UIColor
        if a <= 0.004 { col = UIColor(white: 0.5, alpha: 1) } else {
            col = UIColor(red: min(1, CGFloat(px[0]) / 255 / a), green: min(1, CGFloat(px[1]) / 255 / a),
                          blue: min(1, CGFloat(px[2]) / 255 / a), alpha: 1)
        }
        bubble.backgroundColor = col
        bubble.isHidden = false
        if a > 0.004 { onColorPicked?(col) }
    }

    // MARK: strokes

    private func ensureBuffers() {
        let n = doc.w * doc.h
        if snap == nil || snapCount != n * 4 {
            snap?.deallocate(); covMask?.deallocate()
            snap = UnsafeMutablePointer<UInt8>.allocate(capacity: n * 4)
            covMask = UnsafeMutablePointer<UInt8>.allocate(capacity: n)
            covMask!.initialize(repeating: 0, count: n)
            snapCount = n * 4
        }
    }
    private var snapCount = 0

    private func beginStroke(at p: CGPoint, pressure: CGFloat) {
        guard let l = doc.active else { return }
        ensureBuffers()
        snap!.update(from: l.buf, count: doc.w * doc.h * 4)
        strokeLayer = l
        stroking = true
        dminX = Int.max; dminY = Int.max; dmaxX = -1; dmaxY = -1
        lastPt = p
        carry = 0
        if tool == .smudge {
            patchR = max(2, Int(brushSize / 2 * pressure))
            patch = [Float](repeating: 0, count: (patchR * 2 + 1) * (patchR * 2 + 1) * 4)
            samplePatch(at: p, into: &patch, r: patchR, keep: 0, layer: l)
        } else {
            dab(p, pressure: pressure)
            flush()
        }
    }

    private func extendStroke(to p: CGPoint, pressure: CGFloat) {
        guard stroking, let l = strokeLayer else { return }
        let r = max(0.5, brushSize / 2 * (tool == .smudge ? pressure : effP(pressure)))
        let step = max(0.7, r * (tool == .smudge ? 0.18 : max(0.03, style.spacing)))
        var dx = p.x - lastPt.x, dy = p.y - lastPt.y
        let dist = hypot(dx, dy)
        if dist < 0.01 { return }
        dx /= dist; dy /= dist
        var pos = step - carry
        while pos <= dist {
            let q = CGPoint(x: lastPt.x + dx * pos, y: lastPt.y + dy * pos)
            if tool == .smudge { smudgeStep(q, pressure: pressure, layer: l) } else { dab(q, pressure: pressure) }
            pos += step
        }
        carry = dist - (pos - step)
        lastPt = p
        if tool != .smudge { flush() } else { markDirtyView() }
    }

    private func abortStroke() {
        holdTimer?.invalidate()
        pending = nil
        guard stroking, let l = strokeLayer, let sn = snap else { stroking = false; return }
        if dmaxX >= dminX {
            let x0 = max(0, dminX), x1 = min(doc.w - 1, dmaxX), y0 = max(0, dminY), y1 = min(doc.h - 1, dmaxY)
            if x1 >= x0 && y1 >= y0 {
                for y in y0...y1 {
                    let o = (y * doc.w + x0) * 4
                    (l.buf + o).update(from: sn + o, count: (x1 - x0 + 1) * 4)
                }
            }
            clearMask()
        }
        stroking = false
        invalidateCaches()
    }

    private func endStroke() {
        guard stroking, let l = strokeLayer, let sn = snap else { return }
        stroking = false
        pickCtx = nil
        if dmaxX >= dminX {
            let x = max(0, dminX), y = max(0, dminY)
            let w = min(doc.w - 1, dmaxX) - x + 1, h = min(doc.h - 1, dmaxY) - y + 1
            if w > 0 && h > 0 {
                var before = [UInt8](repeating: 0, count: w * h * 4)
                var after = before
                for row in 0..<h {
                    let o = ((y + row) * doc.w + x) * 4
                    before.withUnsafeMutableBufferPointer { ($0.baseAddress! + row * w * 4).update(from: sn + o, count: w * 4) }
                    after.withUnsafeMutableBufferPointer { ($0.baseAddress! + row * w * 4).update(from: l.buf + o, count: w * 4) }
                }
                pushUndo(DrawUndo(layerId: l.meta.id, x: x, y: y, w: w, h: h, before: before, after: after))
                l.dirty = true
            }
            clearMask()
        }
        onChanged?()
    }

    private func clearMask() {
        guard let m = covMask, dmaxX >= dminX else { return }
        let x0 = max(0, dminX), x1 = min(doc.w - 1, dmaxX)
        let y0 = max(0, dminY), y1 = min(doc.h - 1, dmaxY)
        if x1 < x0 || y1 < y0 { return }
        let count = x1 - x0 + 1
        for y in y0...y1 {
            let row: Int = y * doc.w + x0
            (m + row).update(repeating: 0, count: count)
        }
    }

    private func grow(_ x0: Int, _ y0: Int, _ x1: Int, _ y1: Int) {
        dminX = min(dminX, x0); dminY = min(dminY, y0); dmaxX = max(dmaxX, x1); dmaxY = max(dmaxY, y1)
    }

    private var flushX0 = Int.max, flushY0 = Int.max, flushX1 = -1, flushY1 = -1

    /// Stamps a soft round dab into the coverage covMask.
    private func effP(_ pr: CGFloat) -> CGFloat { 1 - style.pressureSize + style.pressureSize * pr }

    private func grainNoise(_ x: Int, _ y: Int) -> CGFloat {
        var h = UInt32(truncatingIfNeeded: x &* 73856093) ^ UInt32(truncatingIfNeeded: y &* 19349663)
        h = (h ^ (h >> 13)) &* 1274126177
        h ^= h >> 16
        return CGFloat(h & 0xFFFF) / 65535
    }

    private func dab(_ p0: CGPoint, pressure: CGFloat) {
        guard let m = covMask else { return }
        var p = p0
        var r = max(0.5, brushSize / 2 * effP(pressure))
        if style.sizeJitter > 0 { r = max(0.5, r * (1 - style.sizeJitter * CGFloat.random(in: 0...1))) }
        if style.scatter > 0 {
            let an = CGFloat.random(in: 0..<(2 * CGFloat.pi))
            let dd = r * style.scatter * CGFloat.random(in: 0...1)
            p.x += cos(an) * dd; p.y += sin(an) * dd
        }
        let x0 = max(0, Int(floor(p.x - r - 1))), x1 = min(doc.w - 1, Int(ceil(p.x + r + 1)))
        let y0 = max(0, Int(floor(p.y - r - 1))), y1 = min(doc.h - 1, Int(ceil(p.y + r + 1)))
        if x1 < x0 || y1 < y0 { return }
        let aa = max(1, r * (1 - style.hardness))
        for y in y0...y1 {
            let dy = CGFloat(y) + 0.5 - p.y
            for x in x0...x1 {
                let dx = CGFloat(x) + 0.5 - p.x
                let d = style.square ? max(abs(dx), abs(dy)) : (dx * dx + dy * dy).squareRoot()
                var cov = min(1, max(0, (r - d) / aa))
                if cov <= 0 { continue }
                if style.grain > 0 { cov *= 1 - style.grain + style.grain * grainNoise(x, y) }
                let v = UInt8(cov * 255)
                let i = y * doc.w + x
                if v > m[i] { m[i] = v }
            }
        }
        grow(x0, y0, x1, y1)
        flushX0 = min(flushX0, x0); flushY0 = min(flushY0, y0); flushX1 = max(flushX1, x1); flushY1 = max(flushY1, y1)
    }

    /// Composites the covMask over the stroke-start snapshot for the pixels touched since the last flush.
    private func flush() {
        guard flushX1 >= flushX0, let l = strokeLayer, let m = covMask, let sn = snap else { return }
        var cr: CGFloat = 0, cg: CGFloat = 0, cb: CGFloat = 0, ca: CGFloat = 0
        color.getRed(&cr, green: &cg, blue: &cb, alpha: &ca)
        let R = Float(cr * 255), G = Float(cg * 255), B = Float(cb * 255)
        let op = Float(opacity)
        let erase = tool == .eraser
        for y in flushY0...flushY1 {
            for x in flushX0...flushX1 {
                let i = y * doc.w + x
                let mv = m[i]
                if mv == 0 { continue }
                let a = Float(mv) / 255 * op
                let o = i * 4
                if erase {
                    let k = 1 - a
                    l.buf[o] = UInt8(Float(sn[o]) * k); l.buf[o + 1] = UInt8(Float(sn[o + 1]) * k)
                    l.buf[o + 2] = UInt8(Float(sn[o + 2]) * k); l.buf[o + 3] = UInt8(Float(sn[o + 3]) * k)
                } else {
                    let k = 1 - a
                    l.buf[o] = UInt8(min(255, R * a + Float(sn[o]) * k))
                    l.buf[o + 1] = UInt8(min(255, G * a + Float(sn[o + 1]) * k))
                    l.buf[o + 2] = UInt8(min(255, B * a + Float(sn[o + 2]) * k))
                    l.buf[o + 3] = UInt8(min(255, 255 * a + Float(sn[o + 3]) * k))
                }
            }
        }
        let tl = toView(CGPoint(x: flushX0, y: flushY0)), br = toView(CGPoint(x: flushX1 + 1, y: flushY1 + 1))
        setNeedsDisplay(CGRect(x: tl.x - 2, y: tl.y - 2, width: br.x - tl.x + 4, height: br.y - tl.y + 4))
        flushX0 = Int.max; flushY0 = Int.max; flushX1 = -1; flushY1 = -1
    }

    // MARK: smudge

    private func samplePatch(at p: CGPoint, into pt: inout [Float], r: Int, keep: Float, layer: PixLayer) {
        let d = r * 2 + 1
        let cx = Int(p.x), cy = Int(p.y)
        for j in 0..<d {
            let y = cy + j - r
            if y < 0 || y >= doc.h { continue }
            for i in 0..<d {
                let x = cx + i - r
                if x < 0 || x >= doc.w { continue }
                let o = (y * doc.w + x) * 4
                let k = (j * d + i) * 4
                for c in 0..<4 { pt[k + c] = pt[k + c] * keep + Float(layer.buf[o + c]) * (1 - keep) }
            }
        }
    }

    private func smudgeStep(_ p: CGPoint, pressure: CGFloat, layer l: PixLayer) {
        let r = patchR
        let d = r * 2 + 1
        let cx = Int(p.x.rounded()), cy = Int(p.y.rounded())
        let strength = Float(max(0.08, opacity)) * 0.8
        let rr = Float(r)
        for j in 0..<d {
            let y = cy + j - r
            if y < 0 || y >= doc.h { continue }
            for i in 0..<d {
                let x = cx + i - r
                if x < 0 || x >= doc.w { continue }
                let dx = Float(i - r), dy = Float(j - r)
                let dist = (dx * dx + dy * dy).squareRoot()
                let cov = min(1, max(0, (rr - dist) / max(1, rr * 0.5)))
                if cov <= 0 { continue }
                let k = cov * strength
                let o = (y * doc.w + x) * 4
                let pk = (j * d + i) * 4
                for c in 0..<4 { l.buf[o + c] = UInt8(max(0, min(255, Float(l.buf[o + c]) * (1 - k) + patch[pk + c] * k))) }
            }
        }
        grow(cx - r, cy - r, cx + r, cy + r)
        flushX0 = min(flushX0, cx - r); flushY0 = min(flushY0, cy - r)
        flushX1 = max(flushX1, cx + r); flushY1 = max(flushY1, cy + r)
        let keep = Float(min(0.97, 0.55 + 0.42 * opacity))
        samplePatch(at: p, into: &patch, r: r, keep: keep, layer: l)
    }

    private func markDirtyView() {
        guard flushX1 >= flushX0 else { return }
        let tl = toView(CGPoint(x: max(0, flushX0), y: max(0, flushY0)))
        let br = toView(CGPoint(x: min(doc.w, flushX1 + 1), y: min(doc.h, flushY1 + 1)))
        setNeedsDisplay(CGRect(x: tl.x - 2, y: tl.y - 2, width: br.x - tl.x + 4, height: br.y - tl.y + 4))
        flushX0 = Int.max; flushY0 = Int.max; flushX1 = -1; flushY1 = -1
    }
}
