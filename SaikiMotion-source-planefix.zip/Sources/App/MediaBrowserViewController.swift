// MediaBrowserViewController.swift — in-app photo/video browser (all media, albums, full-screen grid).

import UIKit
import Photos

final class MediaBrowserViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate,
                                        UICollectionViewDelegateFlowLayout {

    private let onPick: (String, Bool) -> Void       // (file path in the media folder, isVideo)
    private let onFailure: (String) -> Void
    var onSystemPicker: (() -> Void)?

    private struct Album { let title: String; let collection: PHAssetCollection? }
    private var albums: [Album] = []
    private var current = 0
    private var filter = 0                            // 0 all, 1 photos, 2 videos
    private var assets: PHFetchResult<PHAsset> = PHFetchResult<PHAsset>()
    private var columns = 3
    private var grid: UICollectionView!
    private let albumButton = UIButton(type: .system)
    private let caching = PHCachingImageManager()
    private let busy = UIActivityIndicatorView(style: .large)

    init(onPick: @escaping (String, Bool) -> Void, onFailure: @escaping (String) -> Void) {
        self.onPick = onPick
        self.onFailure = onFailure
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = argbToUIColor(C.BG)
        overrideUserInterfaceStyle = .dark
        navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: .close, target: self, action: #selector(close))
        albumButton.setTitle("Recents ▾", for: .normal)
        albumButton.titleLabel?.font = .boldSystemFont(ofSize: 16)
        albumButton.addTarget(self, action: #selector(pickAlbum), for: .touchUpInside)
        navigationItem.titleView = albumButton
        navigationItem.rightBarButtonItem = UIBarButtonItem(image: UIImage(systemName: "square.grid.3x3.fill"),
                                                            style: .plain, target: self, action: #selector(toggleFull))

        let seg = UISegmentedControl(items: ["All", "Photos", "Videos"])
        seg.selectedSegmentIndex = 0
        seg.addTarget(self, action: #selector(filterChanged(_:)), for: .valueChanged)
        seg.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(seg)

        let lay = UICollectionViewFlowLayout()
        lay.minimumInteritemSpacing = 2
        lay.minimumLineSpacing = 2
        grid = UICollectionView(frame: .zero, collectionViewLayout: lay)
        grid.backgroundColor = .clear
        grid.dataSource = self
        grid.delegate = self
        grid.register(MediaCell.self, forCellWithReuseIdentifier: "c")
        grid.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(grid)
        busy.color = .white
        busy.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(busy)
        NSLayoutConstraint.activate([
            seg.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 6),
            seg.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 12),
            seg.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -12),
            grid.topAnchor.constraint(equalTo: seg.bottomAnchor, constant: 8),
            grid.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            grid.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            grid.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            busy.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            busy.centerYAnchor.constraint(equalTo: view.centerYAnchor)])

        PHPhotoLibrary.requestAuthorization(for: .readWrite) { [weak self] st in
            DispatchQueue.main.async {
                guard let self = self else { return }
                if st == .denied || st == .restricted {
                    self.dismiss(animated: true) { self.onSystemPicker?() }
                    return
                }
                self.loadAlbums()
            }
        }
    }

    @objc private func close() { dismiss(animated: true) }

    /// The grid button: whole library = full-height sheet and a denser 5-column grid; again = back.
    @objc private func toggleFull() {
        let full = columns == 3
        columns = full ? 5 : 3
        navigationItem.rightBarButtonItem?.image = UIImage(systemName: full ? "square.grid.2x2.fill" : "square.grid.3x3.fill")
        if let sh = navigationController?.sheetPresentationController {
            sh.animateChanges { sh.selectedDetentIdentifier = full ? .large : .medium }
        }
        grid.collectionViewLayout.invalidateLayout()
    }

    @objc private func filterChanged(_ s: UISegmentedControl) { filter = s.selectedSegmentIndex; reload() }

    // MARK: albums

    private func loadAlbums() {
        albums = [Album(title: "Recents", collection: nil)]
        func add(_ sub: PHAssetCollectionSubtype, _ name: String) {
            let r = PHAssetCollection.fetchAssetCollections(with: .smartAlbum, subtype: sub, options: nil)
            if let c = r.firstObject, PHAsset.fetchAssets(in: c, options: nil).count > 0 { albums.append(Album(title: name, collection: c)) }
        }
        add(.smartAlbumRecentlyAdded, "Recently Saved")
        add(.smartAlbumFavorites, "Favorites")
        add(.smartAlbumVideos, "Videos")
        add(.smartAlbumScreenshots, "Screenshots")
        add(.smartAlbumSelfPortraits, "Selfies")
        add(.smartAlbumLivePhotos, "Live Photos")
        add(.smartAlbumPanoramas, "Panoramas")
        add(.smartAlbumSlomoVideos, "Slo-mo")
        add(.smartAlbumTimelapses, "Time-lapse")
        let mine = PHAssetCollection.fetchAssetCollections(with: .album, subtype: .any, options: nil)
        mine.enumerateObjects { c, _, _ in
            if PHAsset.fetchAssets(in: c, options: nil).count > 0 { self.albums.append(Album(title: c.localizedTitle ?? "Album", collection: c)) }
        }
        current = 0
        reload()
    }

    @objc private func pickAlbum() {
        let sheet = UIAlertController(title: "Albums", message: nil, preferredStyle: .actionSheet)
        for (i, a) in albums.enumerated() {
            sheet.addAction(UIAlertAction(title: a.title, style: .default) { [weak self] _ in
                self?.current = i
                self?.reload()
            })
        }
        sheet.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        if let pop = sheet.popoverPresentationController { pop.sourceView = albumButton; pop.sourceRect = albumButton.bounds }
        present(sheet, animated: true)
    }

    private func reload() {
        guard current < albums.count else { return }
        let opts = PHFetchOptions()
        opts.sortDescriptors = [NSSortDescriptor(key: "creationDate", ascending: false)]
        switch filter {
        case 1: opts.predicate = NSPredicate(format: "mediaType == %d", PHAssetMediaType.image.rawValue)
        case 2: opts.predicate = NSPredicate(format: "mediaType == %d", PHAssetMediaType.video.rawValue)
        default: opts.predicate = NSPredicate(format: "mediaType == %d OR mediaType == %d",
                                              PHAssetMediaType.image.rawValue, PHAssetMediaType.video.rawValue)
        }
        let a = albums[current]
        assets = a.collection.map { PHAsset.fetchAssets(in: $0, options: opts) } ?? PHAsset.fetchAssets(with: opts)
        albumButton.setTitle(a.title + " ▾", for: .normal)
        grid.reloadData()
    }

    // MARK: grid

    func collectionView(_ cv: UICollectionView, numberOfItemsInSection section: Int) -> Int { assets.count }

    func collectionView(_ cv: UICollectionView, cellForItemAt ip: IndexPath) -> UICollectionViewCell {
        let cell = cv.dequeueReusableCell(withReuseIdentifier: "c", for: ip) as! MediaCell
        let a = assets.object(at: ip.item)
        cell.tag = ip.item
        cell.setDuration(a.mediaType == .video ? a.duration : nil)
        let side = (cv.bounds.width / CGFloat(columns)) * UIScreen.main.scale
        caching.requestImage(for: a, targetSize: CGSize(width: side, height: side), contentMode: .aspectFill, options: nil) { img, _ in
            if cell.tag == ip.item { cell.imageView.image = img }
        }
        return cell
    }

    func collectionView(_ cv: UICollectionView, layout: UICollectionViewLayout, sizeForItemAt ip: IndexPath) -> CGSize {
        let w = floor((cv.bounds.width - CGFloat(columns - 1) * 2) / CGFloat(columns))
        return CGSize(width: w, height: w)
    }

    func collectionView(_ cv: UICollectionView, didSelectItemAt ip: IndexPath) {
        importAsset(assets.object(at: ip.item))
    }

    // MARK: import (original file, iCloud allowed)

    private func importAsset(_ a: PHAsset) {
        let isVideo = a.mediaType == .video
        let res = PHAssetResource.assetResources(for: a)
        let wanted: PHAssetResourceType = isVideo ? .video : .photo
        guard let r = res.first(where: { $0.type == wanted }) ?? res.first else { onFailure("Could not read the item"); return }
        let ext = (r.originalFilename as NSString).pathExtension.lowercased()
        Projects.ensureDirs()
        let name = String(Int(Date().timeIntervalSince1970 * 1000)) + "_photo." + (ext.isEmpty ? (isVideo ? "mov" : "jpg") : ext)
        let dest = Projects.mediaDir().appendingPathComponent(name)
        try? FileManager.default.removeItem(at: dest)
        let o = PHAssetResourceRequestOptions()
        o.isNetworkAccessAllowed = true
        busy.startAnimating()
        view.isUserInteractionEnabled = false
        PHAssetResourceManager.default().writeData(for: r, toFile: dest, options: o) { [weak self] err in
            DispatchQueue.main.async {
                guard let self = self else { return }
                self.busy.stopAnimating()
                self.view.isUserInteractionEnabled = true
                if err != nil { self.onFailure("Import failed"); return }
                let cb = self.onPick
                self.dismiss(animated: true) { cb(dest.path, isVideo) }
            }
        }
    }
}

private final class MediaCell: UICollectionViewCell {
    let imageView = UIImageView()
    private let badge = UILabel()

    override init(frame: CGRect) {
        super.init(frame: frame)
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        imageView.frame = contentView.bounds
        imageView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        imageView.backgroundColor = UIColor(white: 0.15, alpha: 1)
        contentView.addSubview(imageView)
        badge.font = .monospacedDigitSystemFont(ofSize: 10, weight: .semibold)
        badge.textColor = .white
        badge.backgroundColor = UIColor(white: 0, alpha: 0.55)
        badge.layer.cornerRadius = 3
        badge.layer.masksToBounds = true
        badge.isHidden = true
        contentView.addSubview(badge)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    override func prepareForReuse() { super.prepareForReuse(); imageView.image = nil; badge.isHidden = true }

    func setDuration(_ d: TimeInterval?) {
        guard let d = d else { badge.isHidden = true; return }
        let s = Int(d.rounded())
        badge.text = String(format: " %d:%02d ", s / 60, s % 60)
        badge.sizeToFit()
        badge.frame.origin = CGPoint(x: 4, y: contentView.bounds.height - badge.bounds.height - 4)
        badge.isHidden = false
    }
}
