// EditorPuppet.swift — Puppet panel (Pin / Mesh / Sway tabs). Pins are placed and
// dragged right in the viewport (see OverlayView); this file is the panel.

import UIKit

extension PuppetEdit { static var tab = 0 }

extension EditorViewController {

    func puppetPanelOpen() -> Bool { panel == P_PUPPET }

    func openPuppet() {
        guard let l = selected() else { return }
        if l.puppet == nil { pushUndo(); l.puppet = Puppet() }
        PuppetEdit.sel = []
        PuppetEdit.onChange = { [weak self] in self?.refreshPanel(); self?.render() }
        openPanel(P_PUPPET)
    }

    func buildPuppet(_ l: Layer) {
        guard let pp = l.puppet else { return }
        let p: UIStackView = panelList
        put(p, TabBar(["Pin", "Mesh", "Sway"], PuppetEdit.tab) { [weak self] i in
            PuppetEdit.tab = i; self?.refreshPanel(); self?.render()
        }, 44)
        switch PuppetEdit.tab {
        case 0: puppetPinTab(l, pp)
        case 1: puppetMeshTab(l, pp)
        default: puppetSwayTab(l, pp)
        }
    }

    // ---------------------------------------------------------------- helpers

    private func fixed(_ v: UIView, _ w: CGFloat, _ h: CGFloat) -> UIView {
        v.translatesAutoresizingMaskIntoConstraints = false
        if w > 0 { v.widthAnchor.constraint(equalToConstant: w).isActive = true }
        if h > 0 { v.heightAnchor.constraint(equalToConstant: h).isActive = true }
        return v
    }

    private func pspacer() -> UIView {
        let s = UIView()
        s.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
        s.setContentCompressionResistancePriority(UILayoutPriority(1), for: .horizontal)
        return s
    }

    private func btnRow(_ spacing: CGFloat = 8) -> UIStackView {
        let r = hRow(); r.spacing = spacing; return r
    }

    private func puppetBtn(_ text: String, _ icon: String?, on: Bool = false, enabled: Bool = true,
                           _ click: @escaping () -> Void) -> PillButton {
        let b = PillButton(text, icon, on ? C.GREEN : (enabled ? C.CARD2 : C.CARD),
                           on ? C.ONDARK : (enabled ? C.TEXT : C.DIM))
        b.onClick = enabled ? click : {}
        return b
    }

    private func puppetEdit(_ body: () -> Void) {
        pushUndo(); body(); PuppetEdit.onChange?()
    }

    // ---------------------------------------------------------------- Pin tab

    private func puppetPinTab(_ l: Layer, _ pp: Puppet) {
        let p: UIStackView = panelList
        let has = !PuppetEdit.sel.isEmpty

        let top = btnRow()
        let sw = SwitchRow()
        sw.label = "Puppet"; sw.on = pp.on; sw.captionOn = "on"; sw.captionOff = "off"
        sw.onToggle = { [weak self] v in self?.pushUndo(); pp.on = v; self?.render() }
        top.addArrangedSubview(fixed(sw, 190, 48))
        top.addArrangedSubview(pspacer())
        top.addArrangedSubview(fixed(puppetBtn("Auto-key", nil, on: autoKeyOn) { [weak self] in
            guard let self = self else { return }
            self.autoKeyOn.toggle(); self.refreshPanel()
        }, 104, 44))
        top.addArrangedSubview(fixed(puppetBtn("⋮", nil) { [weak self] in self?.puppetMenu(l, pp) }, 48, 44))
        put(p, top, 0, 6, 4)

        let modes = btnRow()
        modes.addArrangedSubview(fixed(puppetBtn("Add", "plus", on: PuppetEdit.mode == 0) {
            PuppetEdit.mode = 0; PuppetEdit.onChange?()
        }, 112, 44))
        modes.addArrangedSubview(fixed(puppetBtn("Select", nil, on: PuppetEdit.mode == 1) {
            PuppetEdit.mode = 1; PuppetEdit.onChange?()
        }, 112, 44))
        modes.addArrangedSubview(fixed(puppetBtn("Multi", nil, on: PuppetEdit.mode == 2) {
            PuppetEdit.mode = 2; PuppetEdit.onChange?()
        }, 100, 44))
        modes.addArrangedSubview(pspacer())
        put(p, modes, 0, 4, 4)

        let nav = btnRow()
        func step(_ d: Int) {
            guard !pp.pins.isEmpty else { return }
            let cur = PuppetEdit.sel.last.flatMap { id in pp.pins.firstIndex { $0.id == id } } ?? (d > 0 ? -1 : 0)
            let n = (cur + d + pp.pins.count) % pp.pins.count
            PuppetEdit.sel = [pp.pins[n].id]; PuppetEdit.onChange?()
        }
        nav.addArrangedSubview(fixed(puppetBtn("", "prev") { step(-1) }, 58, 44))
        let lab = UILabel()
        lab.textAlignment = .center
        lab.textColor = argbToUIColor(C.TEXT)
        lab.font = boldFont(15)
        if let id = PuppetEdit.sel.last, pp.pin(id) != nil {
            lab.text = PuppetEdit.sel.count > 1 ? "\(PuppetEdit.sel.count) pins selected" : "Pin \(pp.number(id))"
        } else {
            lab.text = pp.pins.isEmpty ? "Tap the picture to add a pin" : "Tap a pin to select it"
        }
        nav.addArrangedSubview(lab)
        nav.addArrangedSubview(fixed(puppetBtn("", "next") { step(1) }, 58, 44))
        put(p, nav, 0, 4, 4)

        let acts = btnRow()
        acts.distribution = .fillEqually
        acts.addArrangedSubview(puppetBtn("Duplicate pin", "dup", enabled: has) { [weak self] in
            self?.puppetEdit {
                var made: [Int] = []
                for id in PuppetEdit.sel {
                    guard let src = pp.pin(id) else { continue }
                    let n = PuppetPin(pp.nextId, src.rx, src.ry); pp.nextId += 1
                    pp.pins.append(n)
                    l.track("pp\(n.id)x").base = (l.props["pp\(id)x"]?.eval(Editor.time) ?? 0) + 0.08
                    l.track("pp\(n.id)y").base = (l.props["pp\(id)y"]?.eval(Editor.time) ?? 0) - 0.08
                    made.append(n.id)
                }
                PuppetEdit.sel = made
            }
        })
        acts.addArrangedSubview(puppetBtn("Reset to rest", "undo", enabled: has) { [weak self] in
            guard let self = self else { return }
            self.puppetEdit {
                for id in PuppetEdit.sel {
                    l.track("pp\(id)x").set(Editor.time, 0, self.autoKeyOn)
                    l.track("pp\(id)y").set(Editor.time, 0, self.autoKeyOn)
                }
            }
        })
        acts.addArrangedSubview(puppetBtn("Delete pin", "trash", enabled: has) { [weak self] in
            self?.puppetEdit {
                for id in PuppetEdit.sel {
                    pp.pins.removeAll { $0.id == id }
                    l.props["pp\(id)x"] = nil; l.props["pp\(id)y"] = nil
                    pp.swayChain.removeAll { $0 == id }
                }
                PuppetEdit.sel = []
            }
        })
        put(p, acts, 46, 4, 4)

        let fine = btnRow()
        fine.addArrangedSubview(pspacer())
        fine.addArrangedSubview(fixed(puppetBtn("Fine", nil, on: PuppetEdit.fine) {
            PuppetEdit.fine.toggle(); PuppetEdit.onChange?()
        }, 90, 40))
        put(p, fine, 0, 4, 4)
        text(p, "Fine slows dragging to a quarter so small moves are easy. Auto-key records each move as a keyframe.", C.DIM, 12)
    }

    private func puppetMenu(_ l: Layer, _ pp: Puppet) {
        let a = UIAlertController(title: "Puppet", message: nil, preferredStyle: .actionSheet)
        a.addAction(UIAlertAction(title: "Reset all pins to rest", style: .default) { [weak self] _ in
            guard let self = self else { return }
            self.puppetEdit { for q in pp.pins {
                l.track("pp\(q.id)x").set(Editor.time, 0, self.autoKeyOn)
                l.track("pp\(q.id)y").set(Editor.time, 0, self.autoKeyOn)
            } }
        })
        a.addAction(UIAlertAction(title: "Delete all pins", style: .destructive) { [weak self] _ in
            self?.puppetEdit {
                for q in pp.pins { l.props["pp\(q.id)x"] = nil; l.props["pp\(q.id)y"] = nil }
                pp.pins = []; pp.swayChain = []; PuppetEdit.sel = []
            }
        })
        a.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        a.popoverPresentationController?.sourceView = view
        a.popoverPresentationController?.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.maxY - 60, width: 1, height: 1)
        present(a, animated: true)
    }

    // ---------------------------------------------------------------- Mesh tab

    private func puppetMeshTab(_ l: Layer, _ pp: Puppet) {
        let p: UIStackView = panelList
        let sm = SwitchRow()
        sm.label = "Show mesh"; sm.on = pp.showMesh
        sm.onToggle = { [weak self] v in pp.showMesh = v; self?.render() }
        put(p, sm, 52)
        text(p, "Mesh detail", C.TEXT, 14, true)
        p.addArrangedSubview(chipRow(["Low", "Medium", "High"], pp.density) { [weak self] i in
            guard let self = self else { return }
            self.pushUndo(); pp.density = i; self.refreshPanel(); self.render()
        })
        text(p, "Stiffness — higher keeps the bend close to each pin", C.TEXT, 14, true)
        let fs = FillSlider()
        fs.lo = 1; fs.hi = 4; fs.value = pp.stiffness; fs.suffix = ""
        fs.onBegin = { [weak self] in self?.pushUndo() }
        fs.onChange = { [weak self] v in pp.stiffness = v; self?.render() }
        put(p, fs, 44)
    }

    // ---------------------------------------------------------------- Sway tab

    private func puppetSwayTab(_ l: Layer, _ pp: Puppet) {
        let p: UIStackView = panelList
        let row = btnRow()
        row.distribution = .fillEqually
        let a = SwitchRow(); a.label = "Auto sway"; a.on = pp.swayOn
        a.onToggle = { [weak self] v in self?.pushUndo(); pp.swayOn = v; self?.render() }
        let r = SwitchRow(); r.label = "Lock root"; r.on = pp.lockRoot
        r.onToggle = { [weak self] v in self?.pushUndo(); pp.lockRoot = v; self?.render() }
        row.addArrangedSubview(a); row.addArrangedSubview(r)
        put(p, row, 52)

        p.addArrangedSubview(chipRow(["Gentle", "Medium", "Strong"], pp.swayStrength) { [weak self] i in
            guard let self = self else { return }
            self.pushUndo(); pp.swayStrength = i; self.refreshPanel(); self.render()
        })
        text(p, "Tap pins from root to tip. The root stays still, the tip swings most.", C.DIM, 13)

        if pp.pins.isEmpty {
            text(p, "Add pins on the Pin tab first.", C.DIM, 12)
        } else {
            let sv = UIScrollView()
            sv.showsHorizontalScrollIndicator = false
            let content = UIView(frame: CGRect(x: 0, y: 0, width: CGFloat(pp.pins.count) * 106 + 6, height: 46))
            for (i, q) in pp.pins.enumerated() {
                let k = pp.swayChain.firstIndex(of: q.id)
                let nm = "Pin \(i + 1)"
                let b = PillButton(k != nil ? "\(k! + 1) · \(nm)" : nm, nil,
                                   k != nil ? C.GREEN : C.CARD2, k != nil ? C.ONDARK : C.TEXT)
                b.onClick = { [weak self] in
                    guard let self = self else { return }
                    self.pushUndo()
                    if let k = pp.swayChain.firstIndex(of: q.id) { pp.swayChain.remove(at: k) } else { pp.swayChain.append(q.id) }
                    self.refreshPanel(); self.render()
                }
                b.frame = CGRect(x: 3 + CGFloat(i) * 106, y: 4, width: 100, height: 38)
                content.addSubview(b)
            }
            sv.addSubview(content); sv.contentSize = content.frame.size
            put(p, sv, 46)
        }

        let s = RulerSlider(frame: .zero)
        s.label = "Speed (/s)"; s.lo = 0.1; s.hi = 3; s.dec = 2; s.value = pp.swaySpeed
        s.canKey = false
        s.onBegin = { [weak self] in self?.pushUndo() }
        s.onChange = { [weak self] v in pp.swaySpeed = v; self?.render() }
        put(p, s, 60)
    }
}
