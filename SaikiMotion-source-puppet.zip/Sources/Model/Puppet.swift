// Puppet.swift — puppet pin warp (Model + math).
// Pins live in the layer's quad space (-1...1, y up, same space as the
// renderer's aPos). Each pin's motion is two ordinary tracks on the layer
// ("pp<id>x" / "pp<id>y" = offset from rest), so keyframes, auto-key,
// undo, save and export all work with no special cases. Auto-sway adds a
// procedural wave on top, scaled root→tip along a chain of pins.

import Foundation
import OpenGLES

final class PuppetPin {
    var id: Int
    var rx: Float
    var ry: Float
    init(_ id: Int, _ rx: Float, _ ry: Float) { self.id = id; self.rx = rx; self.ry = ry }
}

final class Puppet {
    var on = true
    var pins: [PuppetPin] = []
    var nextId = 1
    var density = 1                 // 0 low, 1 medium, 2 high
    var showMesh = true
    var stiffness: Float = 2        // falloff power (higher = more local)
    var swayOn = false
    var lockRoot = true
    var swayStrength = 1            // 0 gentle, 1 medium, 2 strong
    var swayChain: [Int] = []       // pin ids, root first
    var swaySpeed: Float = 0.8      // cycles per second

    func pin(_ id: Int) -> PuppetPin? { pins.first { $0.id == id } }
    func number(_ id: Int) -> Int { (pins.firstIndex { $0.id == id } ?? 0) + 1 }

    func toJson() -> JObj {
        let o = JObj()
        o.put("on", on).put("nextId", Int64(nextId)).put("density", Int64(density))
        o.put("showMesh", showMesh).put("stiffness", Double(stiffness))
        o.put("swayOn", swayOn).put("lockRoot", lockRoot)
        o.put("swayStrength", Int64(swayStrength)).put("swaySpeed", Double(swaySpeed))
        let pa = JArr()
        for p in pins {
            pa.put(JObj().put("id", Int64(p.id)).put("rx", Double(p.rx)).put("ry", Double(p.ry)))
        }
        o.put("pins", pa)
        let ca = JArr(); for c in swayChain { _ = ca.put(Int64(c)) }
        o.put("chain", ca)
        return o
    }

    static func fromJson(_ o: JObj) -> Puppet {
        let p = Puppet()
        p.on = o.optBool("on", true)
        p.nextId = max(1, o.optInt("nextId", 1))
        p.density = clamp(o.optInt("density", 1), 0, 2)
        p.showMesh = o.optBool("showMesh", true)
        p.stiffness = o.optFloat("stiffness", 2)
        p.swayOn = o.optBool("swayOn")
        p.lockRoot = o.optBool("lockRoot", true)
        p.swayStrength = clamp(o.optInt("swayStrength", 1), 0, 2)
        p.swaySpeed = o.optFloat("swaySpeed", 0.8)
        if let pa = o.optJSONArray("pins") {
            for i in 0..<pa.count {
                if let po = pa.optJSONObject(i) {
                    p.pins.append(PuppetPin(po.optInt("id"), po.optFloat("rx"), po.optFloat("ry")))
                }
            }
        }
        if let ca = o.optJSONArray("chain") {
            for i in 0..<ca.count { p.swayChain.append(ca.optInt(i)) }
        }
        return p
    }
}

/// Shared state between the Puppet panel and the viewport overlay.
enum PuppetEdit {
    static var mode = 0              // 0 add, 1 select, 2 multi
    static var sel: [Int] = []       // selected pin ids (last = primary)
    static var fine = false
    static var onChange: (() -> Void)? = nil
}

enum PuppetMath {
    static let segs = [7, 12, 18]

    static func swayOffset(_ p: Puppet, _ id: Int, _ t: Float) -> (Float, Float) {
        guard p.swayOn, let k = p.swayChain.firstIndex(of: id) else { return (0, 0) }
        let n = p.swayChain.count
        let w: Float = p.lockRoot ? (n > 1 ? Float(k) / Float(n - 1) : 0) : Float(k + 1) / Float(n)
        let amp: Float = [0.03, 0.06, 0.11][p.swayStrength] * w
        let ph = 2 * Float.pi * p.swaySpeed * t - Float(k) * 0.7
        return (amp * sin(ph), amp * 0.25 * cos(ph))
    }

    /// Offset from rest of one pin at time t (keyed tracks + sway).
    static func offset(_ l: Layer, _ p: Puppet, _ pin: PuppetPin, _ t: Float) -> (Float, Float) {
        let ox = l.props["pp\(pin.id)x"]?.eval(t) ?? 0
        let oy = l.props["pp\(pin.id)y"]?.eval(t) ?? 0
        let s = swayOffset(p, pin.id, t)
        return (ox + s.0, oy + s.1)
    }

    static func pinPos(_ l: Layer, _ p: Puppet, _ pin: PuppetPin, _ t: Float) -> (Float, Float) {
        let o = offset(l, p, pin, t)
        return (pin.rx + o.0, pin.ry + o.1)
    }

    /// Displacement of a rest point (inverse-distance weighted, with a hold
    /// weight so far-away points stay put).
    static func disp(_ pins: [(Float, Float, Float, Float)], _ pw: Float, _ x: Float, _ y: Float) -> (Float, Float) {
        var sx: Float = 0, sy: Float = 0, sw = pow(1.4, -pw)
        for q in pins {
            let dx = x - q.0, dy = y - q.1
            let d2 = dx * dx + dy * dy
            let w = pow(d2 + 0.00001, -pw * 0.5)
            sx += w * q.2; sy += w * q.3; sw += w
        }
        return (sx / sw, sy / sw)
    }

    static func activePins(_ l: Layer, _ p: Puppet, _ t: Float) -> [(Float, Float, Float, Float)] {
        p.pins.map { let o = offset(l, p, $0, t); return ($0.rx, $0.ry, o.0, o.1) }
    }

    /// Deformed grid vertex positions (aPos space), row-major, (n+1)² points.
    static func gridPositions(_ l: Layer, _ p: Puppet, _ t: Float) -> [Float] {
        let n = segs[p.density]
        let pins = activePins(l, p, t)
        var out = [Float](); out.reserveCapacity((n + 1) * (n + 1) * 2)
        for j in 0...n {
            let y = -1 + 2 * Float(j) / Float(n)
            for i in 0...n {
                let x = -1 + 2 * Float(i) / Float(n)
                let d = disp(pins, p.stiffness, x, y)
                out.append(x + d.0); out.append(y + d.1)
            }
        }
        return out
    }

    private static var topoCache: [Int: ([Float], [UInt16])] = [:]
    static func topology(_ n: Int) -> ([Float], [UInt16]) {
        if let c = topoCache[n] { return c }
        var uv = [Float](), idx = [UInt16]()
        for j in 0...n { for i in 0...n { uv.append(Float(i) / Float(n)); uv.append(Float(j) / Float(n)) } }
        for j in 0..<n { for i in 0..<n {
            let a = UInt16(j * (n + 1) + i), b = a + 1, c = a + UInt16(n + 1), d = c + 1
            idx += [a, b, c, b, d, c]
        } }
        topoCache[n] = (uv, idx)
        return (uv, idx)
    }

    /// Mesh for the renderer, or nil when the layer has no active puppet.
    static func mesh(_ l: Layer, _ t: Float) -> (pos: [Float], uv: [Float], idx: [UInt16])? {
        guard let p = l.puppet, p.on, !p.pins.isEmpty else { return nil }
        let (uv, idx) = topology(segs[p.density])
        return (gridPositions(l, p, t), uv, idx)
    }
}

extension Gl {
    /// Draws an indexed triangle mesh: aPos = deformed quad-space position, aUv = rest uv.
    static func drawMesh(_ program: GLProgram, _ pos: [Float], _ uv: [Float], _ idx: [UInt16]) {
        program.use()
        glBindBuffer(GLenum(GL_ARRAY_BUFFER), 0)
        glBindBuffer(GLenum(GL_ELEMENT_ARRAY_BUFFER), 0)
        let aPos = glGetAttribLocation(program.handle, "aPos")
        let aUv = glGetAttribLocation(program.handle, "aUv")
        guard aPos >= 0, aUv >= 0 else { return }
        glEnableVertexAttribArray(GLuint(aPos))
        glEnableVertexAttribArray(GLuint(aUv))
        pos.withUnsafeBufferPointer { pp in
            uv.withUnsafeBufferPointer { up in
                idx.withUnsafeBufferPointer { ip in
                    glVertexAttribPointer(GLuint(aPos), 2, GLenum(GL_FLOAT), GLboolean(GL_FALSE), 8, pp.baseAddress)
                    glVertexAttribPointer(GLuint(aUv), 2, GLenum(GL_FLOAT), GLboolean(GL_FALSE), 8, up.baseAddress)
                    glDrawElements(GLenum(GL_TRIANGLES), GLsizei(idx.count), GLenum(GL_UNSIGNED_SHORT), ip.baseAddress)
                }
            }
        }
        glDisableVertexAttribArray(GLuint(aPos))
        glDisableVertexAttribArray(GLuint(aUv))
    }
}
