// AnimeDecomposer.swift — on-device anime character decomposition (Tools tab).
//
// Splits a character illustration into editable parts (hair, head, eyes,
// eyelids, body skin, clothes, line art, details, optional background).
// Everything runs on the phone with plain image analysis — no network, no
// model download:
//
//   1. background removal   border-colour flood fill (or the image's own alpha)
//   2. colour grouping      k-means in Lab space with a light spatial term
//   3. smoothing            majority filter on the region map
//   4. naming               skin / hair / line-art / clothes by colour + position
//   5. face carving         eyes + eyelids cut out of the head region
//   6. layers               cropped RGBA bitmaps, disjoint, composite == source
//
// Pure data in, pure data out: the view controller owns all UI.

import UIKit
import Foundation

// MARK: - public types ------------------------------------------------------------

struct DecomposeOptions {
    var layerCount = 6
    var regionSplit: Float = 25      // 0...60 — how strongly position splits same-coloured areas
    var smoothing = 1                // 0...3 majority-filter passes
    var maxSide = 1024               // working resolution (longest side)
    var removeBackground = true
    var splitEyes = true
    var keepBackground = false
}

struct DecomposedLayer {
    var name: String
    var x: Int
    var y: Int
    var w: Int
    var h: Int
    var rgba: [UInt8]                // w*h*4, un-premultiplied, cropped to the box
    var visible = true
    var area: Int
}

struct DecomposeResult {
    var width: Int
    var height: Int
    var layers: [DecomposedLayer]
}

final class CancelToken {
    private let lock = NSLock()
    private var flag = false
    func cancel() { lock.lock(); flag = true; lock.unlock() }
    var isCancelled: Bool { lock.lock(); defer { lock.unlock() }; return flag }
}

// MARK: - engine --------------------------------------------------------------------

enum AnimeDecomposer {

    private enum Role { case skin, hair, line, cloth, other }

    private static let NOSEG: UInt8 = 255

    // MARK: pixels in / out

    /// Draws the image into an un-premultiplied RGBA buffer, longest side <= maxSide
    /// (never upscaled). Orientation is applied.
    static func loadPixels(_ image: UIImage, maxSide: Int) -> (w: Int, h: Int, rgba: [UInt8])? {
        let sw = image.size.width * image.scale
        let sh = image.size.height * image.scale
        guard sw > 0, sh > 0 else { return nil }
        let k = min(1, CGFloat(maxSide) / max(sw, sh))
        let w = max(1, Int((sw * k).rounded()))
        let h = max(1, Int((sh * k).rounded()))
        var buf = [UInt8](repeating: 0, count: w * h * 4)
        var ok = false
        buf.withUnsafeMutableBytes { raw in
            guard let base = raw.baseAddress,
                  let ctx = CGContext(data: base, width: w, height: h, bitsPerComponent: 8,
                                      bytesPerRow: w * 4,
                                      space: CGColorSpace(name: CGColorSpace.sRGB) ?? CGColorSpaceCreateDeviceRGB(),
                                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)
            else { return }
            ctx.interpolationQuality = .high
            ctx.translateBy(x: 0, y: CGFloat(h))
            ctx.scaleBy(x: 1, y: -1)
            UIGraphicsPushContext(ctx)
            image.draw(in: CGRect(x: 0, y: 0, width: w, height: h))
            UIGraphicsPopContext()
            ok = true
        }
        guard ok else { return nil }
        // un-premultiply
        var i = 0
        let total = w * h * 4
        while i < total {
            let a = Int(buf[i + 3])
            if a > 0 && a < 255 {
                buf[i] = UInt8(min(255, Int(buf[i]) * 255 / a))
                buf[i + 1] = UInt8(min(255, Int(buf[i + 1]) * 255 / a))
                buf[i + 2] = UInt8(min(255, Int(buf[i + 2]) * 255 / a))
            }
            i += 4
        }
        return (w, h, buf)
    }

    /// RGBA (un-premultiplied) → UIImage.
    static func image(from rgba: [UInt8], width w: Int, height h: Int) -> UIImage? {
        guard w > 0, h > 0, rgba.count >= w * h * 4 else { return nil }
        let data = Data(rgba) as CFData
        guard let provider = CGDataProvider(data: data),
              let cg = CGImage(width: w, height: h, bitsPerComponent: 8, bitsPerPixel: 32,
                               bytesPerRow: w * 4,
                               space: CGColorSpace(name: CGColorSpace.sRGB) ?? CGColorSpaceCreateDeviceRGB(),
                               bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.last.rawValue),
                               provider: provider, decode: nil, shouldInterpolate: true,
                               intent: .defaultIntent)
        else { return nil }
        return UIImage(cgImage: cg, scale: 1, orientation: .up)
    }

    /// One layer placed on a full, transparent canvas.
    static func fullCanvas(_ layer: DecomposedLayer, width w: Int, height h: Int) -> [UInt8] {
        var out = [UInt8](repeating: 0, count: w * h * 4)
        for row in 0..<layer.h {
            let dy = layer.y + row
            if dy < 0 || dy >= h { continue }
            for col in 0..<layer.w {
                let dx = layer.x + col
                if dx < 0 || dx >= w { continue }
                let s = (row * layer.w + col) * 4
                let d = (dy * w + dx) * 4
                out[d] = layer.rgba[s]; out[d + 1] = layer.rgba[s + 1]
                out[d + 2] = layer.rgba[s + 2]; out[d + 3] = layer.rgba[s + 3]
            }
        }
        return out
    }

    /// Visible layers painted bottom → top ("over" with straight alpha).
    static func composite(_ layers: [DecomposedLayer], width w: Int, height h: Int) -> [UInt8] {
        var out = [UInt8](repeating: 0, count: w * h * 4)
        for layer in layers where layer.visible {
            for row in 0..<layer.h {
                let dy = layer.y + row
                if dy < 0 || dy >= h { continue }
                for col in 0..<layer.w {
                    let dx = layer.x + col
                    if dx < 0 || dx >= w { continue }
                    let s = (row * layer.w + col) * 4
                    let sa = Int(layer.rgba[s + 3])
                    if sa == 0 { continue }
                    let d = (dy * w + dx) * 4
                    let da = Int(out[d + 3])
                    if sa == 255 || da == 0 {
                        out[d] = layer.rgba[s]; out[d + 1] = layer.rgba[s + 1]
                        out[d + 2] = layer.rgba[s + 2]; out[d + 3] = UInt8(sa)
                    } else {
                        let fs = Float(sa) / 255, fd = Float(da) / 255
                        let oa = fs + fd * (1 - fs)
                        for c in 0..<3 {
                            let v = (Float(layer.rgba[s + c]) * fs + Float(out[d + c]) * fd * (1 - fs)) / oa
                            out[d + c] = UInt8(max(0, min(255, v)))
                        }
                        out[d + 3] = UInt8(max(0, min(255, oa * 255)))
                    }
                }
            }
        }
        return out
    }

    // MARK: colour

    private static let lin: [Float] = (0..<256).map { i -> Float in
        let c = Float(i) / 255
        return c <= 0.04045 ? c / 12.92 : powf((c + 0.055) / 1.055, 2.4)
    }

    @inline(__always) private static func labF(_ t: Float) -> Float {
        t > 0.008856 ? cbrtf(t) : (7.787 * t + 16.0 / 116.0)
    }

    private static func toLab(_ src: UnsafePointer<UInt8>, _ n: Int,
                              _ L: UnsafeMutablePointer<Float>,
                              _ A: UnsafeMutablePointer<Float>,
                              _ B: UnsafeMutablePointer<Float>) {
        lin.withUnsafeBufferPointer { lut in
            for i in 0..<n {
                let r = lut[Int(src[i * 4])]
                let g = lut[Int(src[i * 4 + 1])]
                let b = lut[Int(src[i * 4 + 2])]
                let x = (0.4124 * r + 0.3576 * g + 0.1805 * b) / 0.95047
                let y = 0.2126 * r + 0.7152 * g + 0.0722 * b
                let z = (0.0193 * r + 0.1192 * g + 0.9505 * b) / 1.08883
                let fx = labF(x), fy = labF(y), fz = labF(z)
                L[i] = 116 * fy - 16
                A[i] = 500 * (fx - fy)
                B[i] = 200 * (fy - fz)
            }
        }
    }

    private static func isSkinLike(_ r: Float, _ g: Float, _ b: Float) -> Bool {
        let cb = 128 - 0.168736 * r - 0.331264 * g + 0.5 * b
        let cr = 128 + 0.5 * r - 0.418688 * g - 0.081312 * b
        return cb >= 72 && cb <= 130 && cr >= 130 && cr <= 178 && r > 150 && r >= g && g >= b * 0.8
    }

    // MARK: connected components

    private static func components(_ mask: UnsafePointer<UInt8>, _ w: Int, _ h: Int, eight: Bool)
        -> (ids: [Int32], areas: [Int], boxes: [(Int, Int, Int, Int)]) {
        let n = w * h
        var ids = [Int32](repeating: -1, count: n)
        var areas: [Int] = []
        var boxes: [(Int, Int, Int, Int)] = []
        var stack: [Int32] = []
        for s in 0..<n where mask[s] != 0 && ids[s] < 0 {
            let cid = Int32(areas.count)
            ids[s] = cid
            stack.append(Int32(s))
            var area = 0
            var bx0 = w, by0 = h, bx1 = -1, by1 = -1
            while let cur32 = stack.popLast() {
                let cur = Int(cur32)
                let x = cur % w, y = cur / w
                area += 1
                if x < bx0 { bx0 = x }
                if x > bx1 { bx1 = x }
                if y < by0 { by0 = y }
                if y > by1 { by1 = y }
                for dy in -1...1 {
                    for dx in -1...1 {
                        if dx == 0 && dy == 0 { continue }
                        if !eight && dx != 0 && dy != 0 { continue }
                        let nx = x + dx, ny = y + dy
                        if nx < 0 || ny < 0 || nx >= w || ny >= h { continue }
                        let j = ny * w + nx
                        if mask[j] != 0 && ids[j] < 0 {
                            ids[j] = cid
                            stack.append(Int32(j))
                        }
                    }
                }
            }
            areas.append(area)
            boxes.append((bx0, by0, bx1, by1))
        }
        return (ids, areas, boxes)
    }

    // MARK: 1 — foreground

    private static func foreground(_ src: UnsafePointer<UInt8>,
                                   _ L: UnsafePointer<Float>, _ A: UnsafePointer<Float>, _ B: UnsafePointer<Float>,
                                   _ w: Int, _ h: Int, removeBg: Bool,
                                   _ fg: UnsafeMutablePointer<UInt8>) {
        let n = w * h
        // images that already carry transparency: trust the alpha channel
        var transparent = 0
        for i in 0..<n where src[i * 4 + 3] < 250 { transparent += 1 }
        if transparent > n / 100 {
            for i in 0..<n { fg[i] = src[i * 4 + 3] > 24 ? 1 : 0 }
            return
        }
        fg.initialize(repeating: 1, count: n)
        guard removeBg, w > 8, h > 8 else { return }

        // background colour = median of the 2px border ring
        var bl: [Float] = [], ba: [Float] = [], bb: [Float] = []
        func take(_ i: Int) { bl.append(L[i]); ba.append(A[i]); bb.append(B[i]) }
        for x in 0..<w { take(x); take(w + x); take((h - 1) * w + x); take((h - 2) * w + x) }
        for y in 2..<(h - 2) { take(y * w); take(y * w + 1); take(y * w + w - 1); take(y * w + w - 2) }
        bl.sort(); ba.sort(); bb.sort()
        let mL = bl[bl.count / 2], mA = ba[ba.count / 2], mB = bb[bb.count / 2]

        func dBg(_ i: Int) -> Float {
            let dl = L[i] - mL, da = A[i] - mA, db = B[i] - mB
            return sqrtf(dl * dl + da * da + db * db)
        }
        func dPair(_ i: Int, _ j: Int) -> Float {
            let dl = L[i] - L[j], da = A[i] - A[j], db = B[i] - B[j]
            return sqrtf(dl * dl + da * da + db * db)
        }

        let seen = UnsafeMutablePointer<UInt8>.allocate(capacity: n)
        seen.initialize(repeating: 0, count: n)
        defer { seen.deallocate() }
        var stack: [Int32] = []
        stack.reserveCapacity(n / 4)

        func seed(_ i: Int) {
            if seen[i] == 0 && dBg(i) < 16 { seen[i] = 1; stack.append(Int32(i)) }
        }
        for x in 0..<w { seed(x); seed((h - 1) * w + x) }
        for y in 0..<h { seed(y * w); seed(y * w + w - 1) }

        while let cur32 = stack.popLast() {
            let i = Int(cur32)
            let x = i % w, y = i / w
            var k = 0
            while k < 4 {
                var nx = x, ny = y
                if k == 0 { nx -= 1 } else if k == 1 { nx += 1 } else if k == 2 { ny -= 1 } else { ny += 1 }
                k += 1
                if nx < 0 || ny < 0 || nx >= w || ny >= h { continue }
                let j = ny * w + nx
                if seen[j] != 0 { continue }
                let d = dBg(j)
                // flat background, or a slow gradient that started at the border
                if d < 16 || (d < 36 && dPair(i, j) < 3.0) {
                    seen[j] = 1
                    stack.append(Int32(j))
                }
            }
        }
        for i in 0..<n { fg[i] = seen[i] != 0 ? 0 : 1 }

        // drop specks, keep the figure(s)
        let comps = components(fg, w, h, eight: false)
        let keep = max(24, n / 2500)
        var kept = 0
        for i in 0..<n where fg[i] != 0 {
            let id = Int(comps.ids[i])
            if id >= 0 && comps.areas[id] < keep { fg[i] = 0 } else { kept += 1 }
        }
        if kept == 0 { fg.initialize(repeating: 1, count: n) }   // never return an empty figure
    }

    // MARK: 2 — colour grouping

    private static func cluster(_ L: UnsafePointer<Float>, _ A: UnsafePointer<Float>, _ B: UnsafePointer<Float>,
                                _ fg: UnsafePointer<UInt8>, _ w: Int, _ h: Int,
                                k kWanted: Int, spatial: Float, token: CancelToken)
        -> (labels: UnsafeMutablePointer<UInt8>, k: Int)? {
        let n = w * h
        var fgIdx: [Int32] = []
        fgIdx.reserveCapacity(n)
        for i in 0..<n where fg[i] != 0 { fgIdx.append(Int32(i)) }
        let total = fgIdx.count
        if total == 0 { return nil }
        let k = max(1, min(kWanted, total / 50 + 1))

        let fw = Float(w), fh = Float(h)
        @inline(__always) func feat(_ i: Int) -> (Float, Float, Float, Float, Float) {
            (L[i], A[i], B[i], spatial * Float(i % w) / fw, spatial * Float(i / w) / fh)
        }

        // sample
        let stride = max(1, total / 24000)
        var sample: [Float] = []
        var m = 0
        var s = 0
        while s < total {
            let f = feat(Int(fgIdx[s]))
            sample.append(f.0); sample.append(f.1); sample.append(f.2); sample.append(f.3); sample.append(f.4)
            m += 1
            s += stride
        }

        var rng: UInt64 = 0x9E3779B97F4A7C15
        func rnd() -> Float {
            rng ^= rng << 13; rng ^= rng >> 7; rng ^= rng << 17
            return Float(rng >> 40) / 16777216.0
        }
        @inline(__always) func d2(_ a: [Float], _ ai: Int, _ b: [Float], _ bi: Int) -> Float {
            var t: Float = 0
            for d in 0..<5 { let v = a[ai + d] - b[bi + d]; t += v * v }
            return t
        }

        // k-means++ seeding
        var centers = [Float](repeating: 0, count: k * 5)
        let first = min(m - 1, Int(rnd() * Float(m)))
        for d in 0..<5 { centers[d] = sample[first * 5 + d] }
        var best = [Float](repeating: .infinity, count: m)
        for c in 1..<max(k, 1) where c < k {
            var sum: Float = 0
            for p in 0..<m {
                let dd = d2(sample, p * 5, centers, (c - 1) * 5)
                if dd < best[p] { best[p] = dd }
                sum += best[p]
            }
            var pick = m - 1
            var r = rnd() * sum
            for p in 0..<m { r -= best[p]; if r <= 0 { pick = p; break } }
            for d in 0..<5 { centers[c * 5 + d] = sample[pick * 5 + d] }
        }

        // Lloyd iterations on the sample
        for _ in 0..<10 {
            if token.isCancelled { return nil }
            var sums = [Float](repeating: 0, count: k * 5)
            var cnt = [Int](repeating: 0, count: k)
            for p in 0..<m {
                var bc = 0
                var bd = Float.infinity
                for c in 0..<k {
                    let dd = d2(sample, p * 5, centers, c * 5)
                    if dd < bd { bd = dd; bc = c }
                }
                cnt[bc] += 1
                for d in 0..<5 { sums[bc * 5 + d] += sample[p * 5 + d] }
            }
            for c in 0..<k where cnt[c] > 0 {
                for d in 0..<5 { centers[c * 5 + d] = sums[c * 5 + d] / Float(cnt[c]) }
            }
        }

        // assign every figure pixel
        let labels = UnsafeMutablePointer<UInt8>.allocate(capacity: n)
        labels.initialize(repeating: NOSEG, count: n)
        var counts = [Int](repeating: 0, count: k)
        for (q, idx32) in fgIdx.enumerated() {
            if q & 0x3FFFF == 0 && token.isCancelled { labels.deallocate(); return nil }
            let i = Int(idx32)
            let f = feat(i)
            var bc = 0
            var bd = Float.infinity
            for c in 0..<k {
                let o = c * 5
                let a0 = f.0 - centers[o], a1 = f.1 - centers[o + 1], a2 = f.2 - centers[o + 2]
                let a3 = f.3 - centers[o + 3], a4 = f.4 - centers[o + 4]
                let dd = a0 * a0 + a1 * a1 + a2 * a2 + a3 * a3 + a4 * a4
                if dd < bd { bd = dd; bc = c }
            }
            labels[i] = UInt8(bc)
            counts[bc] += 1
        }

        // merge crumbs into their nearest neighbour group, then renumber 0..<live
        var remap = Array(0..<k)
        var alive = counts.filter { $0 > 0 }.count
        let minArea = max(20, total / 500)
        for c in (0..<k).sorted(by: { counts[$0] < counts[$1] }) where counts[c] > 0 && counts[c] < minArea && alive > 1 {
            var bt = -1
            var bd = Float.infinity
            for t in 0..<k where t != c && counts[t] > 0 && remap[t] == t {
                let dd = d2(centers, c * 5, centers, t * 5)
                if dd < bd { bd = dd; bt = t }
            }
            if bt >= 0 {
                remap[c] = bt
                counts[bt] += counts[c]
                counts[c] = 0
                alive -= 1
            }
        }
        var newId = [Int](repeating: -1, count: k)
        var live = 0
        for c in 0..<k where remap[c] == c && counts[c] > 0 { newId[c] = live; live += 1 }
        for i in 0..<n where labels[i] != NOSEG {
            var c = Int(labels[i])
            while remap[c] != c { c = remap[c] }
            labels[i] = UInt8(max(0, newId[c]))
        }
        return (labels, max(1, live))
    }

    // MARK: 3 — smoothing

    private static func smooth(_ lab: UnsafeMutablePointer<UInt8>, _ w: Int, _ h: Int, passes: Int,
                               token: CancelToken) {
        guard passes > 0, w > 2, h > 2 else { return }
        let n = w * h
        let tmp = UnsafeMutablePointer<UInt8>.allocate(capacity: n)
        let cnt = UnsafeMutablePointer<Int32>.allocate(capacity: 256)
        defer { tmp.deallocate(); cnt.deallocate() }
        for _ in 0..<passes {
            if token.isCancelled { return }
            tmp.assign(from: lab, count: n)
            for y in 1..<(h - 1) {
                for x in 1..<(w - 1) {
                    let i = y * w + x
                    let cur = lab[i]
                    if cur == NOSEG { continue }
                    var ns = 0
                    // gather neighbourhood
                    for dy in -1...1 {
                        for dx in -1...1 {
                            let l = lab[(y + dy) * w + x + dx]
                            if l == NOSEG { continue }
                            cnt[Int(l)] = 0
                            ns += 1
                        }
                    }
                    if ns < 5 { continue }
                    for dy in -1...1 {
                        for dx in -1...1 {
                            let l = lab[(y + dy) * w + x + dx]
                            if l != NOSEG { cnt[Int(l)] += 1 }
                        }
                    }
                    var bestL = cur
                    var bestC = cnt[Int(cur)]
                    for dy in -1...1 {
                        for dx in -1...1 {
                            let l = lab[(y + dy) * w + x + dx]
                            if l != NOSEG && cnt[Int(l)] > bestC { bestC = cnt[Int(l)]; bestL = l }
                        }
                    }
                    if bestL != cur && bestC >= 5 { tmp[i] = bestL }
                }
            }
            lab.assign(from: tmp, count: n)
        }
    }

    // MARK: the pipeline

    static func run(rgba: [UInt8], width w: Int, height h: Int, options o: DecomposeOptions,
                    token: CancelToken, progress: @escaping (Double, String) -> Void)
        -> DecomposeResult? {
        let n = w * h
        guard n > 0, rgba.count >= n * 4 else { return nil }

        progress(0.05, "Reading image")
        let px = UnsafeMutablePointer<UInt8>.allocate(capacity: n * 4)
        px.initialize(from: rgba, count: n * 4)
        let L = UnsafeMutablePointer<Float>.allocate(capacity: n)
        let A = UnsafeMutablePointer<Float>.allocate(capacity: n)
        let B = UnsafeMutablePointer<Float>.allocate(capacity: n)
        let fg = UnsafeMutablePointer<UInt8>.allocate(capacity: n)
        let carved = UnsafeMutablePointer<UInt8>.allocate(capacity: n)
        carved.initialize(repeating: 0, count: n)
        defer { px.deallocate(); L.deallocate(); A.deallocate(); B.deallocate(); fg.deallocate(); carved.deallocate() }
        toLab(px, n, L, A, B)
        if token.isCancelled { return nil }

        progress(0.15, "Finding the character")
        foreground(px, L, A, B, w, h, removeBg: o.removeBackground, fg)
        if token.isCancelled { return nil }

        progress(0.30, "Grouping colors")
        let reserve = (o.splitEyes && o.layerCount >= 5) ? 2 : 0
        guard let cl = cluster(L, A, B, fg, w, h, k: max(2, o.layerCount - reserve),
                               spatial: o.regionSplit, token: token) else { return nil }
        let labels = cl.labels
        defer { labels.deallocate() }
        let k = cl.k

        progress(0.60, "Smoothing edges")
        smooth(labels, w, h, passes: o.smoothing, token: token)
        if token.isCancelled { return nil }

        progress(0.72, "Naming parts")

        // figure box
        var fx0 = w, fy0 = h, fx1 = -1, fy1 = -1
        for y in 0..<h {
            for x in 0..<w where labels[y * w + x] != NOSEG {
                if x < fx0 { fx0 = x }
                if x > fx1 { fx1 = x }
                if y < fy0 { fy0 = y }
                if y > fy1 { fy1 = y }
            }
        }
        if fx1 < 0 { return nil }
        let figH = fy1 - fy0 + 1
        let topLimit = fy0 + Int(0.45 * Float(figH))

        // per-group statistics
        var area = [Int](repeating: 0, count: k)
        var top = [Int](repeating: 0, count: k)
        var sr = [Float](repeating: 0, count: k)
        var sg = [Float](repeating: 0, count: k)
        var sb = [Float](repeating: 0, count: k)
        var sl = [Float](repeating: 0, count: k)
        var sa = [Float](repeating: 0, count: k)
        var sbb = [Float](repeating: 0, count: k)
        var sy = [Float](repeating: 0, count: k)
        var totalFg = 0
        for y in 0..<h {
            for x in 0..<w {
                let i = y * w + x
                let l = labels[i]
                if l == NOSEG { continue }
                let c = Int(l)
                if c >= k { continue }
                area[c] += 1
                totalFg += 1
                if y <= topLimit { top[c] += 1 }
                sr[c] += Float(px[i * 4]); sg[c] += Float(px[i * 4 + 1]); sb[c] += Float(px[i * 4 + 2])
                sl[c] += L[i]; sa[c] += A[i]; sbb[c] += B[i]
                sy[c] += Float(y)
            }
        }
        var mr = sr, mg = sg, mb = sb, ml = sl, ma = sa, mbb = sbb, mcy = sy
        var topShare = [Float](repeating: 0, count: k)
        for c in 0..<k where area[c] > 0 {
            let f = Float(area[c])
            mr[c] /= f; mg[c] /= f; mb[c] /= f; ml[c] /= f; ma[c] /= f; mbb[c] /= f; mcy[c] /= f
            topShare[c] = Float(top[c]) / f
        }
        let live = (0..<k).filter { area[$0] > 0 }
        func labDist(_ p: Int, _ q: Int) -> Float {
            let a = ml[p] - ml[q], b = ma[p] - ma[q], c = mbb[p] - mbb[q]
            return sqrtf(a * a + b * b + c * c)
        }

        var roles = [Role](repeating: .other, count: k)

        // line art: the darkest group, when it is small (a big dark group is dark hair / clothes)
        if let dark = live.min(by: { ml[$0] < ml[$1] }),
           ml[dark] < 38, Float(area[dark]) < 0.10 * Float(max(1, totalFg)) {
            roles[dark] = .line
        }
        // skin: skin-coloured group with the most pixels in the head zone
        var skinIdx = -1
        var bestTop = 0
        for c in live where roles[c] == .other && ml[c] > 55 && isSkinLike(mr[c], mg[c], mb[c]) && top[c] > bestTop {
            skinIdx = c; bestTop = top[c]
        }
        if skinIdx < 0 {
            var bestL: Float = 0
            for c in live where roles[c] == .other && topShare[c] > 0.4 && ml[c] > 60 && ml[c] > bestL {
                skinIdx = c; bestL = ml[c]
            }
        }
        if skinIdx >= 0 { roles[skinIdx] = .skin }
        // hair: the biggest remaining group living in the head zone
        var hairIdx = -1
        bestTop = 0
        for c in live where roles[c] == .other && topShare[c] > 0.35 && top[c] > bestTop {
            hairIdx = c; bestTop = top[c]
        }
        if hairIdx >= 0 {
            roles[hairIdx] = .hair
            for c in live where roles[c] == .other && topShare[c] > 0.5 && labDist(c, hairIdx) < 60 {
                roles[c] = .hair
            }
        }
        let midY = Float(fy0) + 0.5 * Float(figH)
        let refY: Float = skinIdx >= 0 ? mcy[skinIdx] : midY
        for c in live where roles[c] == .other {
            roles[c] = (mcy[c] >= refY || topShare[c] < 0.25) ? .cloth : .other
        }

        // names + stacking order (low = bottom)
        var names = [String](repeating: "Layer", count: k)
        var order = [Int](repeating: 60, count: k)
        var hairN = 0, clothN = 0, otherN = 0
        for c in live {
            switch roles[c] {
            case .hair:
                hairN += 1; names[c] = hairN == 1 ? "Hair" : "Hair \(hairN)"; order[c] = 50
            case .cloth:
                clothN += 1; names[c] = clothN == 1 ? "Clothes" : "Clothes \(clothN)"; order[c] = 10
            case .line:
                names[c] = "Line art"; order[c] = 70
            case .skin:
                names[c] = "Head"; order[c] = 30
            case .other:
                otherN += 1; names[c] = otherN == 1 ? "Details" : "Details \(otherN)"; order[c] = 60
            }
        }
        func newId(_ name: String, _ ord: Int) -> Int {
            names.append(name); order.append(ord)
            return names.count - 1
        }

        // head / body split, then eyes + eyelids carved out of the face
        var headComp = -1
        var bodyId = -1
        if skinIdx >= 0 {
            let skinMask = UnsafeMutablePointer<UInt8>.allocate(capacity: n)
            defer { skinMask.deallocate() }
            for i in 0..<n { skinMask[i] = labels[i] == UInt8(skinIdx) ? 1 : 0 }
            let comps = components(skinMask, w, h, eight: true)
            var topCount = [Int](repeating: 0, count: comps.areas.count)
            if fy0 <= min(h - 1, topLimit) {
                for y in fy0...min(h - 1, topLimit) {
                    for x in 0..<w {
                        let id = Int(comps.ids[y * w + x])
                        if id >= 0 { topCount[id] += 1 }
                    }
                }
            }
            if let hc = topCount.indices.max(by: { topCount[$0] < topCount[$1] }), topCount[hc] > 0 {
                headComp = hc
                var hasOther = false
                for i in 0..<n where labels[i] == UInt8(skinIdx) && Int(comps.ids[i]) != hc { hasOther = true; break }
                if hasOther {
                    bodyId = newId("Body skin", 20)
                    for i in 0..<n where labels[i] == UInt8(skinIdx) && Int(comps.ids[i]) != hc {
                        labels[i] = UInt8(bodyId)
                    }
                } else {
                    names[skinIdx] = "Head & skin"
                }
            } else {
                names[skinIdx] = "Skin"
            }

            if o.splitEyes && headComp >= 0 {
                let (bx0, by0, bx1, by1) = comps.boxes[headComp]
                let bw = bx1 - bx0 + 1, bh = by1 - by0 + 1
                if bw >= 24 && bh >= 24 {
                    let ya = by0 + Int(0.04 * Float(bh))
                    let yb = min(h - 1, by0 + Int(0.62 * Float(bh)))
                    let cand = UnsafeMutablePointer<UInt8>.allocate(capacity: n)
                    cand.initialize(repeating: 0, count: n)
                    defer { cand.deallocate() }
                    if ya <= yb {
                        for y in ya...yb {
                            var mn = w, mx = -1
                            for x in bx0...bx1 where Int(comps.ids[y * w + x]) == headComp {
                                if x < mn { mn = x }
                                if x > mx { mx = x }
                            }
                            if mx < mn { continue }
                            for x in mn...mx {
                                let i = y * w + x
                                let l = labels[i]
                                if l == NOSEG || Int(l) == skinIdx || (bodyId >= 0 && Int(l) == bodyId) { continue }
                                if Int(l) < k && roles[Int(l)] == .hair { continue }
                                cand[i] = 1
                            }
                        }
                    }
                    let ce = components(cand, w, h, eight: true)
                    let maxArea = max(8, Int(0.08 * Float(bw * bh)))
                    var eyesId = -1, lidsId = -1
                    for i in 0..<n {
                        let id = Int(ce.ids[i])
                        if id < 0 { continue }
                        let a = ce.areas[id]
                        if a < 3 || a > maxArea { continue }
                        let lc = Int(labels[i])
                        let clusterIsPale = lc < k && ml[lc] > 70 && isSkinLike(mr[lc], mg[lc], mb[lc])
                        if clusterIsPale { continue }                      // blush / highlights stay with the skin
                        let isDark = L[i] < 40 || (lc < k && roles[lc] == .line)
                        if isDark {
                            if lidsId < 0 { lidsId = newId("Eyelids", 45) }
                            labels[i] = UInt8(lidsId)
                        } else {
                            if eyesId < 0 { eyesId = newId("Eyes", 40) }
                            labels[i] = UInt8(eyesId)
                        }
                        carved[i] = 1
                    }
                }
            }
        }
        if token.isCancelled { return nil }

        // optional background layer
        if o.keepBackground {
            var any = false
            for i in 0..<n where fg[i] == 0 && px[i * 4 + 3] > 8 { any = true; break }
            if any {
                let bg = newId("Background", 0)
                for i in 0..<n where fg[i] == 0 && px[i * 4 + 3] > 8 { labels[i] = UInt8(bg) }
            }
        }

        progress(0.88, "Building layers")

        // boxes + areas per final group
        let count = names.count
        var x0 = [Int](repeating: w, count: count)
        var y0 = [Int](repeating: h, count: count)
        var x1 = [Int](repeating: -1, count: count)
        var y1 = [Int](repeating: -1, count: count)
        var ar = [Int](repeating: 0, count: count)
        @inline(__always) func grow(_ c: Int, _ x: Int, _ y: Int) {
            if x < x0[c] { x0[c] = x }
            if x > x1[c] { x1[c] = x }
            if y < y0[c] { y0[c] = y }
            if y > y1[c] { y1[c] = y }
        }
        for y in 0..<h {
            for x in 0..<w {
                let i = y * w + x
                let l = labels[i]
                if l != NOSEG {
                    let c = Int(l)
                    if c < count { ar[c] += 1; grow(c, x, y) }
                }
                if carved[i] != 0 && skinIdx >= 0 { ar[skinIdx] += 1; grow(skinIdx, x, y) }   // head underlay
            }
        }

        let ids = (0..<count).filter { ar[$0] >= 8 }.sorted {
            order[$0] != order[$1] ? order[$0] < order[$1] : $0 < $1
        }
        var layers: [DecomposedLayer] = []
        for id in ids {
            if token.isCancelled { return nil }
            let lw = x1[id] - x0[id] + 1, lh = y1[id] - y0[id] + 1
            var buf = [UInt8](repeating: 0, count: lw * lh * 4)
            let tag = UInt8(id)
            for yy in 0..<lh {
                let y = y0[id] + yy
                for xx in 0..<lw {
                    let x = x0[id] + xx
                    let i = y * w + x
                    let o4 = (yy * lw + xx) * 4
                    if labels[i] == tag {
                        buf[o4] = px[i * 4]; buf[o4 + 1] = px[i * 4 + 1]
                        buf[o4 + 2] = px[i * 4 + 2]; buf[o4 + 3] = px[i * 4 + 3] == 0 ? 255 : px[i * 4 + 3]
                    } else if id == skinIdx && carved[i] != 0 {
                        // skin underneath the eyes / lids: borrow the nearest skin pixel in the row
                        var found = -1
                        var d = 1
                        while d <= 60 && found < 0 {
                            if x - d >= 0 && labels[y * w + x - d] == tag { found = y * w + x - d }
                            else if x + d < w && labels[y * w + x + d] == tag { found = y * w + x + d }
                            d += 1
                        }
                        if found >= 0 {
                            buf[o4] = px[found * 4]; buf[o4 + 1] = px[found * 4 + 1]
                            buf[o4 + 2] = px[found * 4 + 2]; buf[o4 + 3] = 255
                        }
                    }
                }
            }
            layers.append(DecomposedLayer(name: names[id], x: x0[id], y: y0[id], w: lw, h: lh,
                                          rgba: buf, visible: true, area: ar[id]))
        }
        if layers.isEmpty { return nil }
        progress(1.0, "Done")
        return DecomposeResult(width: w, height: h, layers: layers)
    }
}
