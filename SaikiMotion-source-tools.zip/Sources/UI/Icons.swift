// Icons.swift — the vector icon kit (24x24 path icons) + the IconView button.

import UIKit
import Foundation

// MARK: - Icons

/// Vector icons drawn with Paths on a 24x24 grid. No emoji or font glyphs are used anywhere in the UI.
enum Icons {
    static func draw(_ c: CGContext, _ name: String, _ cx: CGFloat, _ cy: CGFloat,
                     _ size: CGFloat, _ color: Int32) {
        c.saveGState()
        c.translateBy(x: cx - size / 2, y: cy - size / 2)
        c.scaleBy(x: size / 24, y: size / 24)

        let col = argbToUIColor(color)
        var p = CGMutablePath()

        func strokePaint() {
            c.setStrokeColor(col.cgColor)
            c.setLineWidth(2)
            c.setLineCap(.round)
            c.setLineJoin(.round)
        }
        func fillPaint() { c.setFillColor(col.cgColor) }
        func strokePath() { c.addPath(p); c.strokePath(); p = CGMutablePath() }
        func fillPath() { c.addPath(p); c.fillPath(); p = CGMutablePath() }
        func circleFill(_ x: CGFloat, _ y: CGFloat, _ r: CGFloat) {
            fillPaint(); c.fillEllipse(in: CGRect(x: x - r, y: y - r, width: 2 * r, height: 2 * r))
        }
        func circleStroke(_ x: CGFloat, _ y: CGFloat, _ r: CGFloat) {
            strokePaint(); c.strokeEllipse(in: CGRect(x: x - r, y: y - r, width: 2 * r, height: 2 * r))
        }
        func rrStroke(_ rect: CGRect, _ rad: CGFloat) {
            strokePaint()
            c.addPath(CGPath(roundedRect: rect, cornerWidth: rad, cornerHeight: rad, transform: nil))
            c.strokePath()
        }
        func rrFill(_ rect: CGRect, _ rad: CGFloat) {
            fillPaint()
            c.addPath(CGPath(roundedRect: rect, cornerWidth: rad, cornerHeight: rad, transform: nil))
            c.fillPath()
        }
        func line(_ x0: CGFloat, _ y0: CGFloat, _ x1: CGFloat, _ y1: CGFloat) {
            strokePaint()
            c.move(to: CGPoint(x: x0, y: y0))
            c.addLine(to: CGPoint(x: x1, y: y1))
            c.strokePath()
        }
        func rectFill(_ rect: CGRect) { fillPaint(); c.fill(rect) }
        func mv(_ x: CGFloat, _ y: CGFloat) { p.move(to: CGPoint(x: x, y: y)) }
        func lt(_ x: CGFloat, _ y: CGFloat) { p.addLine(to: CGPoint(x: x, y: y)) }
        func closeP() { p.closeSubpath() }
        func quad(_ cx1: CGFloat, _ cy1: CGFloat, _ x: CGFloat, _ y: CGFloat) {
            p.addQuadCurve(to: CGPoint(x: x, y: y), control: CGPoint(x: cx1, y: cy1))
        }
        func cubic(_ c1x: CGFloat, _ c1y: CGFloat, _ c2x: CGFloat, _ c2y: CGFloat, _ x: CGFloat, _ y: CGFloat) {
            p.addCurve(to: CGPoint(x: x, y: y), control1: CGPoint(x: c1x, y: c1y), control2: CGPoint(x: c2x, y: c2y))
        }

        switch name {
        case "back":
            strokePaint(); mv(15, 5); lt(8, 12); lt(15, 19); strokePath()
        case "cube":
            strokePaint()
            mv(12, 3); lt(20, 7.5); lt(20, 16.5); lt(12, 21); lt(4, 16.5); lt(4, 7.5); closeP()
            mv(4, 7.5); lt(12, 12); lt(20, 7.5)
            mv(12, 12); lt(12, 21)
            strokePath()
        case "dots":
            for i in 0..<3 { for j in 0..<3 { circleFill(6 + CGFloat(i) * 6, 6 + CGFloat(j) * 6, 1.5) } }
        case "dup":
            rrStroke(CGRect(x: 3, y: 3, width: 11, height: 11), 2)
            rrStroke(CGRect(x: 10, y: 10, width: 11, height: 11), 2)
        case "more":
            circleFill(12, 5, 1.8); circleFill(12, 12, 1.8); circleFill(12, 19, 1.8)
        case "grid":
            rrStroke(CGRect(x: 3, y: 3, width: 18, height: 18), 2)
            strokePaint()
            mv(9, 3); lt(9, 21); mv(15, 3); lt(15, 21)
            mv(3, 9); lt(21, 9); mv(3, 15); lt(21, 15)
            strokePath()
        case "bookmark", "bookmark_f":
            if name == "bookmark_f" { fillPaint() } else { strokePaint() }
            mv(6, 3); lt(18, 3); lt(18, 21); lt(12, 16.5); lt(6, 21); closeP()
            if name == "bookmark_f" { fillPath() } else { strokePath() }
        case "prev":
            strokePaint()
            mv(18, 5); lt(8, 12); lt(18, 19); closeP()
            mv(5, 5); lt(5, 19)
            strokePath()
        case "next":
            strokePaint()
            mv(6, 5); lt(16, 12); lt(6, 19); closeP()
            mv(19, 5); lt(19, 19)
            strokePath()
        case "play":
            fillPaint(); mv(7, 4); lt(20, 12); lt(7, 20); closeP(); fillPath()
        case "pause":
            rectFill(CGRect(x: 6, y: 4, width: 4, height: 16))
            rectFill(CGRect(x: 14, y: 4, width: 4, height: 16))
        case "layers":
            fillPaint(); mv(12, 3); lt(22, 9); lt(12, 15); lt(2, 9); closeP(); fillPath()
            strokePaint(); mv(2, 13); lt(12, 19); lt(22, 13); strokePath()
        case "undo", "redo":
            strokePaint()
            if name == "redo" { c.translateBy(x: 24, y: 0); c.scaleBy(x: -1, y: 1) }
            mv(9, 5); lt(4, 10); lt(9, 15)
            mv(4, 10); lt(14, 10)
            cubic(18.5, 10, 21, 12.5, 21, 17)
            strokePath()
        case "eye", "eye_off":
            strokePaint()
            mv(2, 12); quad(12, 3, 22, 12); quad(12, 21, 2, 12); closeP()
            strokePath()
            circleFill(12, 12, 3)
            if name == "eye_off" {
                strokePaint(); mv(4, 4); lt(20, 20); strokePath()
            }
        case "chev_down":
            strokePaint(); mv(6, 9); lt(12, 15); lt(18, 9); strokePath()
        case "chev_up":
            strokePaint(); mv(6, 15); lt(12, 9); lt(18, 15); strokePath()
        case "trash":
            fillPaint(); mv(6, 8); lt(18, 8); lt(17, 21); lt(7, 21); closeP(); fillPath()
            strokePaint()
            mv(4, 6); lt(20, 6)
            mv(9, 6); lt(9, 3); lt(15, 3); lt(15, 6)
            strokePath()
        case "close":
            strokePaint(); mv(5, 5); lt(19, 19); mv(19, 5); lt(5, 19); strokePath()
        case "plus":
            strokePaint(); mv(12, 4); lt(12, 20); mv(4, 12); lt(20, 12); strokePath()
        case "diamond", "diamond_f":
            if name == "diamond_f" { fillPaint() } else { strokePaint() }
            mv(12, 3); lt(21, 12); lt(12, 21); lt(3, 12); closeP()
            if name == "diamond_f" { fillPath() } else { strokePath() }
        case "graph":
            strokePaint(); mv(3, 18); lt(9, 11); lt(13, 15); lt(21, 6); strokePath()
        case "box":
            rrStroke(CGRect(x: 3, y: 3, width: 18, height: 18), 3)
            strokePaint()
            mv(7, 9); lt(11, 12); lt(7, 15)
            mv(13, 16); lt(17, 16)
            strokePath()
        case "handle":
            strokePaint(); mv(4, 9); lt(20, 9); mv(4, 15); lt(20, 15); strokePath()
        case "media":
            rrStroke(CGRect(x: 3, y: 5, width: 18, height: 14), 2)
            strokePaint(); mv(5, 17); lt(10, 11); lt(14, 15); lt(16, 13); lt(19, 17); strokePath()
            circleFill(16.5, 9.5, 1.6)
        case "text":
            strokePaint()
            mv(5, 6); lt(19, 6)
            mv(12, 6); lt(12, 19)
            mv(9, 19); lt(15, 19)
            strokePath()
        case "shape":
            circleStroke(9, 9, 5.5)
            rrStroke(CGRect(x: 11, y: 11, width: 9, height: 9), 1.5)
        case "camera":
            rrStroke(CGRect(x: 3, y: 7, width: 13, height: 10), 2)
            strokePaint(); mv(16, 10); lt(21, 7); lt(21, 17); lt(16, 14); strokePath()
        case "nullobj":
            circleStroke(12, 12, 5)
            strokePaint()
            mv(12, 2); lt(12, 7); mv(12, 17); lt(12, 22)
            mv(2, 12); lt(7, 12); mv(17, 12); lt(22, 12)
            strokePath()
        case "particles":
            circleFill(7, 7, 1.8); circleFill(15, 6, 1.2); circleFill(11, 12, 2.2)
            circleFill(18, 14, 1.6); circleFill(6, 17, 1.4); circleFill(14, 19, 1.8)
        case "edit":
            strokePaint()
            mv(4, 20); lt(5, 15); lt(16, 4); lt(20, 8); lt(9, 19); closeP()
            mv(14, 6); lt(18, 10)
            strokePath()
        case "move":
            strokePaint()
            mv(12, 3); lt(12, 21); mv(3, 12); lt(21, 12)
            mv(9, 6); lt(12, 3); lt(15, 6); mv(9, 18); lt(12, 21); lt(15, 18)
            mv(6, 9); lt(3, 12); lt(6, 15); mv(18, 9); lt(21, 12); lt(18, 15)
            strokePath()
        case "sparkle":
            fillPaint()
            mv(12, 3); lt(14, 10); lt(21, 12); lt(14, 14); lt(12, 21)
            lt(10, 14); lt(3, 12); lt(10, 10); closeP()
            fillPath()
        case "drop":
            strokePaint()
            mv(12, 3)
            cubic(12, 3, 5, 10, 5, 15)
            cubic(5, 19, 8, 21, 12, 21)
            cubic(16, 21, 19, 19, 19, 15)
            cubic(19, 10, 12, 3, 12, 3)
            closeP()
            strokePath()
        case "speed":
            strokePaint()
            mv(5, 5); lt(12, 12); lt(5, 19)
            mv(13, 5); lt(20, 12); lt(13, 19)
            strokePath()
        case "import":
            strokePaint()
            mv(12, 3); lt(12, 15)
            mv(7, 10); lt(12, 15); lt(17, 10)
            mv(4, 19); lt(20, 19)
            strokePath()
        case "export":
            strokePaint()
            mv(12, 15); lt(12, 3)
            mv(7, 8); lt(12, 3); lt(17, 8)
            mv(4, 19); lt(20, 19)
            strokePath()
        case "check":
            strokePaint(); mv(5, 12); lt(10, 17); lt(19, 7); strokePath()
        case "solid":
            rrFill(CGRect(x: 4, y: 4, width: 16, height: 16), 3)
        case "anime":
            // face with a fringe, big eyes and a sparkle
            circleStroke(11, 13, 7.5)
            strokePaint()
            mv(4.2, 11.5); quad(8, 6.5, 11, 7); quad(14, 6.5, 17.8, 11.5)
            strokePath()
            circleFill(8.2, 13.6, 1.5)
            circleFill(13.8, 13.6, 1.5)
            strokePaint()
            mv(9.6, 17.2); quad(11, 18.2, 12.4, 17.2)
            strokePath()
            fillPaint()
            mv(19.5, 2.5); lt(20.4, 5); lt(23, 5.9); lt(20.4, 6.8); lt(19.5, 9.3)
            lt(18.6, 6.8); lt(16, 5.9); lt(18.6, 5); closeP()
            fillPath()
        case "gear":
            circleStroke(12, 12, 3.2)
            circleStroke(12, 12, 7)
            strokePaint()
            for k in 0..<8 {
                let a = CGFloat(k) * .pi / 4
                mv(12 + 7.5 * cos(a), 12 + 7.5 * sin(a))
                lt(12 + 10 * cos(a), 12 + 10 * sin(a))
            }
            strokePath()
        case "adjust":
            line(4, 7, 20, 7); line(4, 12, 20, 12); line(4, 17, 20, 17)
            circleFill(9, 7, 2.4); circleFill(15, 12, 2.4); circleFill(8, 17, 2.4)
        case "audio":
            strokePaint()
            let hs: [CGFloat] = [3, 7, 10, 6, 4]
            for k in 0..<5 {
                let x = 4 + CGFloat(k) * 4
                mv(x, 12 - hs[k]); lt(x, 12 + hs[k])
            }
            strokePath()
        case "split":
            strokePaint()
            mv(12, 3); lt(12, 21)
            mv(8, 8); lt(4, 12); lt(8, 16)
            mv(16, 8); lt(20, 12); lt(16, 16)
            strokePath()
        case "trimin":
            strokePaint()
            mv(4, 4); lt(4, 20)
            mv(8, 12); lt(20, 12)
            mv(16, 8); lt(20, 12); lt(16, 16)
            strokePath()
        case "trimout":
            strokePaint()
            mv(20, 4); lt(20, 20)
            mv(16, 12); lt(4, 12)
            mv(8, 8); lt(4, 12); lt(8, 16)
            strokePath()
        case "pipette":
            circleStroke(17, 7, 3.2)
            strokePaint(); mv(15, 9); lt(5, 19); lt(4, 20); strokePath()
        case "link":
            rrStroke(CGRect(x: 2, y: 8.5, width: 12, height: 7), 3.5)
            rrStroke(CGRect(x: 10, y: 8.5, width: 12, height: 7), 3.5)
        case "unlink":
            rrStroke(CGRect(x: 1.5, y: 8.5, width: 8.5, height: 7), 3.5)
            rrStroke(CGRect(x: 14, y: 8.5, width: 8.5, height: 7), 3.5)
            strokePaint(); mv(9, 18.5); lt(15, 5.5); strokePath()
        case "flare":
            circleStroke(12, 12, 3.2)
            strokePaint()
            mv(12, 2.5); lt(12, 6.5); mv(12, 17.5); lt(12, 21.5)
            mv(2.5, 12); lt(6.5, 12); mv(17.5, 12); lt(21.5, 12)
            mv(5.5, 5.5); lt(8.3, 8.3); mv(15.7, 15.7); lt(18.5, 18.5)
            mv(18.5, 5.5); lt(15.7, 8.3); mv(8.3, 15.7); lt(5.5, 18.5)
            strokePath()
        case "mask":
            rrStroke(CGRect(x: 4, y: 4, width: 16, height: 16), 3)
            circleStroke(12, 12, 4.5)
        case "mask_invert":
            rrFill(CGRect(x: 4, y: 4, width: 16, height: 16), 3)
            c.setFillColor(UIColor.clear.cgColor)
            c.setBlendMode(.clear)
            c.fillEllipse(in: CGRect(x: 7.5, y: 7.5, width: 9, height: 9))
            c.setBlendMode(.normal)
        case "folder":
            fillPaint()
            mv(3, 6); lt(10, 6); lt(12, 8.5); lt(21, 8.5); lt(21, 19); lt(3, 19); closeP(); fillPath()
        case "folder_open":
            strokePaint()
            mv(3, 18); lt(3, 6); lt(10, 6); lt(12, 8.5); lt(20, 8.5); lt(20, 11)
            mv(3, 18); lt(6, 11); lt(22, 11); lt(19, 18); closeP(); strokePath()
        case "file":
            strokePaint()
            mv(6, 3); lt(14, 3); lt(19, 8); lt(19, 21); lt(6, 21); closeP()
            mv(14, 3); lt(14, 8); lt(19, 8); strokePath()
        case "file_plus":
            strokePaint()
            mv(6, 3); lt(14, 3); lt(19, 8); lt(19, 21); lt(6, 21); closeP()
            mv(12.5, 12); lt(12.5, 18); mv(9.5, 15); lt(15.5, 15); strokePath()
        case "folder_plus":
            strokePaint()
            mv(3, 18); lt(3, 6); lt(10, 6); lt(12, 8.5); lt(21, 8.5); lt(21, 18); closeP()
            mv(12, 11.5); lt(12, 16); mv(9.75, 13.75); lt(14.25, 13.75); strokePath()
        case "save":
            strokePaint()
            mv(4, 4); lt(17, 4); lt(20, 7); lt(20, 20); lt(4, 20); closeP()
            mv(8, 4); lt(8, 9); lt(15, 9); lt(15, 4); mv(8, 20); lt(8, 14); lt(16, 14); lt(16, 20); strokePath()
        case "align_l":
            strokePaint(); mv(4, 3); lt(4, 21); strokePath()
            rectFill(CGRect(x: 7, y: 6, width: 11, height: 4)); rectFill(CGRect(x: 7, y: 14, width: 6, height: 4))
        case "align_hc":
            strokePaint(); mv(12, 3); lt(12, 21); strokePath()
            rectFill(CGRect(x: 5, y: 6, width: 14, height: 4)); rectFill(CGRect(x: 8, y: 14, width: 8, height: 4))
        case "align_r":
            strokePaint(); mv(20, 3); lt(20, 21); strokePath()
            rectFill(CGRect(x: 6, y: 6, width: 11, height: 4)); rectFill(CGRect(x: 11, y: 14, width: 6, height: 4))
        case "align_t":
            strokePaint(); mv(3, 4); lt(21, 4); strokePath()
            rectFill(CGRect(x: 6, y: 7, width: 4, height: 11)); rectFill(CGRect(x: 14, y: 7, width: 4, height: 6))
        case "align_vc":
            strokePaint(); mv(3, 12); lt(21, 12); strokePath()
            rectFill(CGRect(x: 6, y: 5, width: 4, height: 14)); rectFill(CGRect(x: 14, y: 8, width: 4, height: 8))
        case "align_b":
            strokePaint(); mv(3, 20); lt(21, 20); strokePath()
            rectFill(CGRect(x: 6, y: 6, width: 4, height: 11)); rectFill(CGRect(x: 14, y: 11, width: 4, height: 6))
        case "fit":
            strokePaint()
            mv(4, 9); lt(4, 4); lt(9, 4)
            mv(15, 4); lt(20, 4); lt(20, 9)
            mv(20, 15); lt(20, 20); lt(15, 20)
            mv(9, 20); lt(4, 20); lt(4, 15)
            strokePath()
        default:
            break
        }
        c.restoreGState()
    }
}

// MARK: - IconView

/// Plain icon button.
final class IconView: TapView {
    var icon: String
    var tint: Int32
    private let sizePt: CGFloat
    var onLong: (() -> Void)? = nil
    private var longFired = false

    init(_ icon: String, _ tint: Int32 = C.TEXT, _ size: CGFloat = 22) {
        self.icon = icon
        self.tint = tint
        self.sizePt = size
        super.init(frame: .zero)
        isOpaque = false
        backgroundColor = .clear
        contentMode = .redraw
        clearsContextBeforeDrawing = true
        // PORT NOTE: Android long-click timeout is 400ms; the recognizer must not
        // cancel the touch stream so normal clicks still work when onLong == nil.
        let lp = UILongPressGestureRecognizer(target: self, action: #selector(longPressed(_:)))
        lp.minimumPressDuration = 0.4
        lp.cancelsTouchesInView = false
        addGestureRecognizer(lp)
    }

    @objc private func longPressed(_ g: UILongPressGestureRecognizer) {
        if g.state == .began && onLong != nil { longFired = true; onLong?() }
    }

    func set(_ name: String, _ color: Int32) {
        icon = name; tint = color; setNeedsDisplay()
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        isHighlighted = false
        if !longFired, let t = touches.first, bounds.contains(t.location(in: self)) { onClick?() }
        longFired = false
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        isHighlighted = false
        longFired = false
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        c.clear(bounds)   // stale play-triangle pixels used to show under the pause bars
        let col: Int32 = isHighlighted
            ? Int32(bitPattern: UInt32(bitPattern: tint) | 0x80000000)
            : tint
        Icons.draw(c, icon, bounds.width / 2, bounds.height / 2, sizePt, col)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}
