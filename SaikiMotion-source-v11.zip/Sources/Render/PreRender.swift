// PreRender.swift — per-group frame cache ("Pre-render", like After Effects' precomp cache).
//
// A group with `prerender` on has its finished picture (children + mask + group effects,
// before the group's own opacity / blend) baked to disk, one LZ4-compressed RGBA frame per
// project frame: <Caches>/SaikiMotion/prerender/<project>/<group>/<sig>_<w>x<h>_<idx>.pre
//
// * `sig` is a hash of everything that can change the group's picture (the group, all its
//   descendants, cameras, referenced layers, canvas size). ANY change to the group gives a
//   new signature, so old frames can never be shown; they are purged on the next bake.
// * Playback and export draw the baked frame instead of re-running the children / effects.
//   A frame that is not baked yet simply renders live, so the picture is always correct.
// * The whole feature can be switched off (Scene setup / Home → Extras): groups then render
//   live as before.

import Foundation

enum PreRender {

    /// Global switch (default on). Off → every group renders live and nothing is baked.
    static var enabled: Bool = (UserDefaults.standard.object(forKey: "preRender") as? Bool) ?? true {
        didSet { UserDefaults.standard.set(enabled, forKey: "preRender"); FrameCache.bump() }
    }

    /// Lives in Documents/SaikiMotion/Pre-rendered (not Caches): iOS empties Caches when the app is
    /// closed or storage is low, which made every reopened project bake again.
    static var root: URL { Paths.root.appendingPathComponent("Pre-rendered", isDirectory: true) }

    private static let lock = NSLock()
    private static var sigMemo: [String: (Int, String)] = [:]      // "pid/gid" → (FrameCache.version, sig)
    private static var haveMemo: [String: Set<Int>] = [:]          // dir+sig+size → baked frame indices

    // MARK: groups + signature

    /// Every layer under `g` (children, grand-children…).
    static func descendants(of g: Layer, in scene: Scene) -> [Layer] {
        var out: [Layer] = []
        var queue = [g.id]
        var seen: Set<Int> = [g.id]
        while let id = queue.popLast() {
            for l in scene.layers where l.parentId == id && !seen.contains(l.id) {
                seen.insert(l.id); out.append(l); queue.append(l.id)
            }
        }
        return out
    }

    /// Pre-rendered groups of a scene (visible, flagged).
    static func groups(in scene: Scene) -> [Layer] {
        guard enabled else { return [] }
        return scene.layers.filter { $0.type == .GROUP && $0.prerender }
    }

    static func signature(_ g: Layer, project: Project, scene: Scene) -> String {
        let key = project.id + "/" + String(g.id)
        lock.lock()
        if let m = sigMemo[key], m.0 == FrameCache.version { lock.unlock(); return m.1 }
        lock.unlock()

        var parts = "\(project.w)x\(project.h)@\(project.fps)|\(scene.fov)|"
        var used: [Layer] = [g] + descendants(of: g, in: scene)
        // (cameras are not part of the bake: the group is a flat plane the camera looks at)
        // effect inputs pull in other layers
        for l in used.map({ $0 }) {
            for rid in l.inputs.values {
                if let r = scene.layers.first(where: { $0.id == rid }), !used.contains(where: { $0 === r }) { used.append(r) }
            }
        }
        for l in used {
            var js = l.toJson(canonical: true).toString()
            // sandbox paths change between launches / reinstalls: only the file name matters
            if let ip = l.imagePath, !ip.isEmpty {
                js = js.replacingOccurrences(of: ip, with: (ip as NSString).lastPathComponent)
            }
            if l === g { js = js.replacingOccurrences(of: "\"prerender\":true", with: "") }   // the flag itself must not invalidate
            parts += js + "\n"
        }
        parts += scene.markerNames.map { "\($0.key)=\($0.value)" }.sorted().joined(separator: ",")

        var h: UInt64 = 0xcbf29ce484222325               // FNV-1a
        for b in parts.utf8 { h = (h ^ UInt64(b)) &* 0x100000001b3 }
        let sig = String(h, radix: 16)
        lock.lock(); sigMemo[key] = (FrameCache.version, sig); lock.unlock()
        return sig
    }

    // MARK: frame grid

    static func frameIndex(_ t: Float, _ fps: Int) -> Int { Int((max(0, t) * Float(max(1, fps))).rounded()) }

    /// First…last frame index a group is on screen.
    static func range(_ g: Layer, project: Project, scene: Scene) -> ClosedRange<Int> {
        let a = frameIndex(g.start, project.fps)
        let b = max(a, frameIndex(min(g.end, scene.duration), project.fps))
        return a...b
    }

    // MARK: files

    private static func dir(_ pid: String, _ gid: Int) -> URL {
        root.appendingPathComponent(pid, isDirectory: true).appendingPathComponent(String(gid), isDirectory: true)
    }

    private static func name(_ sig: String, _ w: Int, _ h: Int, _ idx: Int) -> String { "\(sig)_\(w)x\(h)_\(idx).pre" }

    private static func memoKey(_ pid: String, _ gid: Int, _ sig: String, _ w: Int, _ h: Int) -> String {
        "\(pid)/\(gid)/\(sig)/\(w)x\(h)"
    }

    private static func have(_ pid: String, _ gid: Int, _ sig: String, _ w: Int, _ h: Int) -> Set<Int> {
        let k = memoKey(pid, gid, sig, w, h)
        lock.lock()
        if let s = haveMemo[k] { lock.unlock(); return s }
        lock.unlock()
        var s = Set<Int>()
        let prefix = "\(sig)_\(w)x\(h)_"
        for f in (try? FileManager.default.contentsOfDirectory(atPath: dir(pid, gid).path)) ?? [] where f.hasPrefix(prefix) && f.hasSuffix(".pre") {
            if let i = Int(f.dropFirst(prefix.count).dropLast(4)) { s.insert(i) }
        }
        lock.lock(); haveMemo[k] = s; lock.unlock()
        return s
    }

    static func has(_ pid: String, _ gid: Int, _ sig: String, _ w: Int, _ h: Int, _ idx: Int) -> Bool {
        have(pid, gid, sig, w, h).contains(idx)
    }

    /// Next frame (from `t` on, wrapping) of the group that is not baked yet; nil when complete.
    static func nextMissing(_ g: Layer, project: Project, scene: Scene, size: (Int, Int), from t: Float) -> Int? {
        let sig = signature(g, project: project, scene: scene)
        let got = have(project.id, g.id, sig, size.0, size.1)
        let r = range(g, project: project, scene: scene)
        if got.count >= r.count && r.allSatisfy({ got.contains($0) }) { return nil }
        let start = min(max(frameIndex(t, project.fps), r.lowerBound), r.upperBound)
        for i in start...r.upperBound where !got.contains(i) { return i }
        for i in r.lowerBound..<start where !got.contains(i) { return i }
        return nil
    }

    /// (baked, total) frames for the group at this size.
    static func progress(_ g: Layer, project: Project, scene: Scene, size: (Int, Int)) -> (Int, Int) {
        let sig = signature(g, project: project, scene: scene)
        let got = have(project.id, g.id, sig, size.0, size.1)
        let r = range(g, project: project, scene: scene)
        return (r.filter { got.contains($0) }.count, r.count)
    }

    static func load(_ pid: String, _ gid: Int, _ sig: String, _ w: Int, _ h: Int, _ idx: Int) -> Data? {
        guard has(pid, gid, sig, w, h, idx) else { return nil }
        let u = dir(pid, gid).appendingPathComponent(name(sig, w, h, idx))
        guard let packed = try? Data(contentsOf: u, options: .mappedIfSafe),
              let raw = try? (packed as NSData).decompressed(using: .lz4) as Data,
              raw.count == w * h * 4 else { return nil }
        return raw
    }

    static func store(_ pid: String, _ gid: Int, _ sig: String, _ w: Int, _ h: Int, _ idx: Int, _ rgba: [UInt8]) {
        let d = dir(pid, gid)
        try? FileManager.default.createDirectory(at: d, withIntermediateDirectories: true)
        let raw = rgba.withUnsafeBufferPointer { Data(buffer: $0) }
        guard let packed = try? (raw as NSData).compressed(using: .lz4) as Data else { return }
        let u = d.appendingPathComponent(name(sig, w, h, idx))
        guard (try? packed.write(to: u)) != nil else { return }
        let k = memoKey(pid, gid, sig, w, h)
        lock.lock(); haveMemo[k, default: []].insert(idx); lock.unlock()
    }

    /// Deletes this group's frames that belong to another signature (stale after an edit).
    static func purgeStale(_ pid: String, _ gid: Int, keep sig: String) {
        let d = dir(pid, gid)
        for f in (try? FileManager.default.contentsOfDirectory(atPath: d.path)) ?? [] where !f.hasPrefix(sig + "_") {
            try? FileManager.default.removeItem(at: d.appendingPathComponent(f))
        }
        lock.lock()
        for k in haveMemo.keys where k.hasPrefix("\(pid)/\(gid)/") && !k.hasPrefix("\(pid)/\(gid)/\(sig)/") { haveMemo[k] = nil }
        lock.unlock()
    }

    private static var purgedSig: [String: String] = [:]

    /// purgeStale, but only the first time a signature is seen for the group.
    static func purgeStaleOnce(_ pid: String, _ gid: Int, keep sig: String) {
        let k = "\(pid)/\(gid)"
        lock.lock(); let seen = purgedSig[k]; purgedSig[k] = sig; lock.unlock()
        if seen != sig { purgeStale(pid, gid, keep: sig) }
    }

    /// Drops one group's frames (flag turned off) or the whole project's.
    static func clear(_ pid: String, group gid: Int? = nil) {
        let u = gid.map { dir(pid, $0) } ?? root.appendingPathComponent(pid, isDirectory: true)
        try? FileManager.default.removeItem(at: u)
        lock.lock()
        let pre = gid.map { "\(pid)/\($0)/" } ?? "\(pid)/"
        for k in haveMemo.keys where k.hasPrefix(pre) { haveMemo[k] = nil }
        lock.unlock()
    }

    static func clearAll() {
        try? FileManager.default.removeItem(at: root)
        lock.lock(); haveMemo.removeAll(); sigMemo.removeAll(); lock.unlock()
    }
}
