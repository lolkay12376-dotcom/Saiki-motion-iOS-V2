// EditorTransform.swift — Transform panel: position/scale/rotation/anchor/align/parent.

import UIKit

extension EditorViewController {
        // ---------------------------------------------------------------- transform

        func buildXform(_ l: Layer) {
            let p: UIStackView = panelList
            p.addArrangedSubview(wrap(TabBar(["Attributes", "Anchor & Align"], xformTab) { [weak self] i in
                guard let self = self else { return }
                self.xformTab = i
                self.refreshPanel()
            }, 0, 44, 0, 0, 0, 0))
            if xformTab == 1 { buildAnchorAlign(l); return }
            let threeD = l.is3d || l.type == .MODEL || l.type == .CAMERA || Xf.isParticles(l)
            let s3 = SwitchRow()
            s3.label = "3D layer"; s3.on = l.is3d || l.type == .MODEL || l.type == .CAMERA
            s3.onToggle = { [weak self] _ in self?.toggle3d() }
            put(p, s3, 52)
            if l.type == .GROUP {
                let pc = SwitchRow()
                pc.label = "Precomp (render group as one image)"; pc.on = l.precomp
                pc.onToggle = { [weak self] v in self?.pushUndo(); l.precomp = v; self?.refreshPanel(); self?.render() }
                put(p, pc, 52)
                text(p, l.precomp ? "Children render together first, then effects, mask, opacity and blend apply to the whole group."
                                  : "Flat group: children draw straight onto the scene.", C.DIM, 12)
            }
            if l.type == .NULL && !l.is3d {
                text(p, "This Null is 2D, so it will not move other layers. Turn 3D on.", C.AMBER)
            }
            groupHeader(p, "Position") { [weak self] in self?.showPositionMenu(l, threeD) }
            if moveMode || !sepDims { addMovePad(p, l) }
            if sepDims { addRow(p, l, Defs.transform[0]); addRow(p, l, Defs.transform[1]) }
            if threeD { addRow(p, l, Defs.pos3d[0]) }
            if l.type != .CAMERA {
                let sh = hRow()
                let stt = UILabel()
                stt.text = "Scale"
                stt.textColor = argbToUIColor(C.TEXT)
                stt.font = boldFont(15)
                stt.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
                sh.addArrangedSubview(stt)
                let chain = IconView(scaleLinked ? "link" : "unlink", Int32(bitPattern: 0xFFFFFFFF), 22)
                chain.onClick = { [weak self] in
                    guard let self = self else { return }
                    self.scaleLinked = !self.scaleLinked
                    self.refreshPanel()
                }
                sh.addArrangedSubview(wrap(chain, 44, 40, 0, 0, 0, 0))
                put(p, sh, 0, 4, 0)
                addRow(p, l, Defs.transform[2], scaleLinked ? "Scale (X and Y together)" : "Scale (all)")
                if !scaleLinked {
                    addRow(p, l, Defs.scaleXY[0])
                    addRow(p, l, Defs.scaleXY[1])
                } else {
                    let lt0 = l.editTime("scaleX", Editor.time)
                    if abs(l.p("scaleX", lt0) - 1) > 0.001 || abs(l.p("scaleY", lt0) - 1) > 0.001 {
                        text(p, "X and Y are stretched separately. Tap the chain to edit them.", C.DIM, 12)
                    }
                }
            }
            let rotDefs: [PropDef] = threeD ? [Defs.transform[4], Defs.rot3d[0], Defs.rot3d[1]] : [Defs.transform[4]]
            groupHeader(p, "Rotation") { [weak self] in self?.showParamMenu(l, "Rotation", rotDefs) }
            for d in rotDefs { addRow(p, l, d) }
            if l.isRenderable() || l.type == .GROUP {
                groupHeader(p, "Opacity") { [weak self] in self?.showParamMenu(l, "Opacity", [Defs.transform[3]]) }
                addRow(p, l, Defs.transform[3])
            }
            let par = Editor.scene.layers.first { $0.id == l.parentId }
            put(p, pill("Parent: " + (par?.name ?? "None"), "layers") { [weak self] in self?.showParentDialog(l) }, 42)
            let b = hRow()
            b.distribution = .fillEqually
            b.spacing = 4
            for axis in ["rotX", "rotY", "rotZ"] {
                if !threeD && axis != "rotZ" { continue }
                b.addArrangedSubview(wrap(pill("Spin " + String(axis.last ?? "?")) { [weak self] in self?.spin(l, axis) },
                                          0, 40, 0, 0, 0, 0))
            }
            put(p, b, 40)
        }

        func groupHeader(_ p: UIStackView, _ title: String, _ onMenu: @escaping () -> Void) {
            let h = hRow()
            let t = UILabel()
            t.text = title
            t.textColor = argbToUIColor(C.TEXT)
            t.font = boldFont(15)
            t.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
            h.addArrangedSubview(t)
            let m = IconView("more", C.TEXT, 20)
            m.onClick = onMenu
            h.addArrangedSubview(wrap(m, 44, 40, 0, 0, 0, 0))
            put(p, h, 0, 4, 0)
        }

        /// The three-dot menu used by Scale, Rotation and Opacity.
        func showParamMenu(_ l: Layer, _ title: String, _ defs: [PropDef]) {
            _ = Dlg(self).setTitle(title).setIconItems(["Reset to default", "Clear keyframes (keep current value)", "Expression..."],
                                                       ["adjust", "close", "box"]) { [weak self] _, w in
                guard let self = self else { return }
                self.pushUndo()
                switch w {
                case 0:
                    for d in defs {
                        let tr = l.track(d.key)
                        tr.keys.removeAll(); tr.base = d.def
                        _ = tr.setExpr(""); tr.exprOn = false
                    }
                case 1:
                    for d in defs {
                        let tr = l.track(d.key)
                        let v = tr.eval(l.editTime(d.key, Editor.time))
                        tr.keys.removeAll(); tr.base = v
                    }
                default:
                    if defs.count == 1 { self.showExpression(l, defs[0]); return }
                    _ = Dlg(self).setTitle("Expression for").setItems(defs.map { $0.label }) { [weak self] _, i in
                        self?.showExpression(l, defs[i])
                    }.show()
                    return
                }
                self.refreshPanel(); self.render()
            }.show()
        }

        func addMovePad(_ p: UIStackView, _ l: Layer) {
            let pad = MovePadView()
            let t0 = l.editTime("x", Editor.time)
            pad.px = l.track("x").eval(t0)
            pad.py = l.track("y").eval(t0)
            pad.onBegin = { [weak self] in self?.pushUndo() }
            pad.onMove = { [weak self] dx, dy in
                guard let self = self else { return }
                let t = l.editTime("x", Editor.time)
                let d = Xf.toParentSpace(l, Editor.time, Float(dx), Float(dy))
                let nx = l.track("x").eval(t) + d.0
                let ny = l.track("y").eval(t) + d.1
                l.track("x").set(t, nx, self.autoKeyOn)
                l.track("y").set(t, ny, self.autoKeyOn)
                pad.px = nx; pad.py = ny
                pad.setNeedsDisplay()
                self.syncRows(); self.render()
            }
            put(p, pad, 150)
        }

        func showPositionMenu(_ l: Layer, _ threeD: Bool) {
            _ = Dlg(self).setTitle("Position").setIconItems(
                ["Separate dimensions  (" + (sepDims ? "on" : "off") + ")",
                 "Move mode  (" + (moveMode ? "on" : "off") + ")",
                 "Reset to default",
                 "Expression..."],
                ["grid", "move", "adjust", "box"]) { [weak self] _, w in
                guard let self = self else { return }
                switch w {
                case 0: self.sepDims = !self.sepDims
                case 1: self.moveMode = !self.moveMode
                case 2:
                    self.pushUndo()
                    for k in ["x", "y", "z"] {
                        let tr = l.track(k)
                        tr.keys.removeAll(); tr.base = 0
                        _ = tr.setExpr(""); tr.exprOn = false
                    }
                default:
                    let names = threeD ? ["Position X", "Position Y", "Position Z"] : ["Position X", "Position Y"]
                    _ = Dlg(self).setTitle("Expression for").setItems(names) { [weak self] _, i in
                        self?.showExpression(l, i == 2 ? Defs.pos3d[0] : Defs.transform[i])
                    }.show()
                    return
                }
                self.refreshPanel()
            }.show()
        }

        // ---------------------------------------------------------------- anchor + align

        func buildAnchorAlign(_ l: Layer) {
            let p: UIStackView = panelList
            text(p, "Anchor", C.TEXT, 15, true)
            addRow(p, l, Defs.anchor[0])
            addRow(p, l, Defs.anchor[1])
            let lt = l.editTime("anchorX", Editor.time)
            let ax = l.p("anchorX", lt)
            let ay = l.p("anchorY", lt)
            text(p, "Preset Anchor", C.TEXT, 15, true)
            let g = GridPick()
            g.sel = (0...8).first { abs(Float($0 % 3) * 50 - ax) < 0.5 && abs(Float($0 / 3) * 50 - ay) < 0.5 } ?? -1
            g.onPick = { [weak self] i in
                guard let self = self else { return }
                self.pushUndo()
                self.setAnchorKeepVisual(l, Float(i % 3) * 50, Float(i / 3) * 50)
                self.refreshPanel(); self.render()
            }
            put(p, g, 128)
            text(p, "Align to Canvas", C.TEXT, 15, true)
            let rows: [[String]] = [["align_l", "align_hc", "align_r"], ["align_t", "align_vc", "align_b"]]
            for (ri, rowIcons) in rows.enumerated() {
                let h = hRow()
                h.distribution = .fillEqually
                for (ci, ic) in rowIcons.enumerated() {
                    let b = IconView(ic, C.TEXT, 24)
                    b.backgroundColor = argbToUIColor(C.CARD)
                    b.layer.cornerRadius = 10
                    b.onClick = { [weak self] in
                        guard let self = self else { return }
                        self.pushUndo()
                        self.alignToCanvas(l, ri * 3 + ci)
                        self.refreshPanel(); self.render()
                    }
                    h.addArrangedSubview(wrap(b, 0, 52, 3, 3, 3, 3))
                }
                put(p, h)
            }
            text(p, "Align uses the layer's size and rotation. Choosing a preset anchor keeps the layer where it is.", C.DIM, 12)
        }

        /// Offset of the layer centre from its position, in world units, for the current anchor.
        func anchorOffset(_ l: Layer, _ lt: Float, _ ax: Float, _ ay: Float) -> (Float, Float) {
            let (qw, qh) = Xf.quadSize(l)
            let sc = l.p("scale", lt)
            let ox = -(ax - 50) / 100 * qw * sc * l.p("scaleX", lt)
            let oy = (ay - 50) / 100 * qh * sc * l.p("scaleY", lt)
            let a = Double(l.p("rotZ", lt)) * Double.pi / 180
            let c = Float(cos(a))
            let sn = Float(sin(a))
            return (ox * c - oy * sn, ox * sn + oy * c)
        }

        func setAnchorKeepVisual(_ l: Layer, _ nx: Float, _ ny: Float) {
            let t = l.editTime("anchorX", Editor.time)
            let oa = anchorOffset(l, t, l.p("anchorX", t), l.p("anchorY", t))
            let na = anchorOffset(l, t, nx, ny)
            l.track("x").set(t, l.p("x", t) + oa.0 - na.0, autoKeyOn)
            l.track("y").set(t, l.p("y", t) + oa.1 - na.1, autoKeyOn)
            l.track("anchorX").set(t, nx, autoKeyOn)
            l.track("anchorY").set(t, ny, autoKeyOn)
        }

        /// which: 0 left, 1 h-centre, 2 right, 3 top, 4 v-centre, 5 bottom.
        func alignToCanvas(_ l: Layer, _ which: Int) {
            let t = l.editTime("x", Editor.time)
            let (qw, qh) = Xf.quadSize(l)
            let sc = abs(l.p("scale", t))
            let hw = qw * sc * abs(l.p("scaleX", t)) / 2
            let hh = qh * sc * abs(l.p("scaleY", t)) / 2
            let a = Double(l.p("rotZ", t)) * Double.pi / 180
            let c = abs(Float(cos(a)))
            let sn = abs(Float(sin(a)))
            let bw = c * hw + sn * hh
            let bh = sn * hw + c * hh
            let w = Float(Editor.project.w) / Float(Editor.project.h)
            let off = anchorOffset(l, t, l.p("anchorX", t), l.p("anchorY", t))
            switch which {
            case 0: l.track("x").set(t, -w + bw - off.0, autoKeyOn)
            case 1: l.track("x").set(t, -off.0, autoKeyOn)
            case 2: l.track("x").set(t, w - bw - off.0, autoKeyOn)
            case 3: l.track("y").set(t, 1 - bh - off.1, autoKeyOn)
            case 4: l.track("y").set(t, -off.1, autoKeyOn)
            default: l.track("y").set(t, -1 + bh - off.1, autoKeyOn)
            }
        }

        func spin(_ l: Layer, _ key: String) {
            pushUndo()
            let tr = l.track(key)
            tr.keys.removeAll()
            tr.keys.append(Key(l.start, 0, .LINEAR))
            tr.keys.append(Key(l.end, 360, .LINEAR))
            refreshPanel(); render()
        }

        func showParentDialog(_ l: Layer) {
            let cands = Editor.scene.layers.filter { $0.id != l.id && $0.parentId != l.id }
            var names = ["None"]
            names += cands.map {
                $0.name + ($0.type == .NULL ? " (Null)" : ($0.type == .GROUP ? " (Group)" : ""))
            }
            Dlg(self).setTitle("Parent").setItems(names) { [weak self] _, w in
                guard let self = self else { return }
                self.pushUndo()
                l.parentId = w == 0 ? -1 : cands[w - 1].id
                self.refreshPanel(); self.render()
            }.show()
        }
}
