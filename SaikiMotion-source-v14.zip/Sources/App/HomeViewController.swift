// HomeViewController.swift — 1:1 reconstruction of the original home screen.
//
// Rebuilt from the original binary (1.5.21) and the reference screenshots:
//   • the Projects tab is "My Playground": the kerned SAIKI MOTION wordmark,
//     a big white title, the centered empty-state hint + "N projects · X.X MB
//     on device" stats, and the two bottom actions stacked above the tab bar
//     — dark-brown IMPORT PROJECT FILE over orange + NEW PROJECT.
//   • New Project opens the full creation sheet: pre-filled name, Resolution
//     (720p/1080p/1440p), Aspect ratio (16:9/9:16/1:1), Frame rate
//     (24/30/60 fps) and a live "1920 x 1080 · 30 fps" summary.
//   • symbols recovered from the app: buildUi(), refresh(), projectRow(),
//     showNewDialog(), showMenu(), showExport(), countLabel, list, kerned(),
//     makeField(), TapGesture, LongPressGesture, documentPicker(),
//     didFirstAppear, preferredStatusBarStyle
//   • UI strings recovered from the app: "New project",
//     "No projects yet. Tap NEW PROJECT to start.", "IMPORT PROJECT FILE",
//     "Rename project", "Duplicate", "Delete project?",
//     "Export project file", "Don't show again"
//   • the original screenshot: black background, bottom bar with FIVE tabs
//     (Account, Projects, Tools, Community, Extras), custom icons above
//     UPPERCASE letter-spaced labels, orange (#FF8A1F) selected, gray
//     unselected.
//
// What's New (WelcomeViewController) shows once per version on first appear,
// exactly like the original's welcome/changelog card.

import UIKit
import UniformTypeIdentifiers

final class HomeViewController: UIViewController {

    private enum Tab: Int, CaseIterable {
        case account, projects, tools, community, extras

        var label: String {
            switch self {
            case .account: return "Account"
            case .projects: return "Projects"
            case .tools: return "Tools"
            case .community: return "Community"
            case .extras: return "Extras"
            }
        }

        var icon: String {
            switch self {
            case .account: return "account"
            case .projects: return "film"
            case .tools: return "tools"
            case .community: return "people"
            case .extras: return "grid_plus"
            }
        }
    }

    // chrome
    private var barButtons: [HomeTabButton] = []
    private let content = UIView()
    private var current: UIView?
    private var tabChild: UIViewController?
    private var selectedTab: Tab = .projects
    private var didFirstAppear = false

    // projects tab state
    private var projects: [Project] = []
    private var countLabel: UILabel?
    private var listStack: UIStackView?

    private let pad: CGFloat = 16

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = argbToUIColor(C.BG)
        CrashLog.note("home")
        buildUi()
        show(.projects)

        NotificationCenter.default.addObserver(self, selector: #selector(storeChanged),
                                               name: .projectsChanged, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(languageChanged),
                                               name: .languageChanged, object: nil)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        // The whole app draws its own chrome (the editor does the same on
        // its side); no system navigation bar anywhere.
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        guard !didFirstAppear else { return }
        didFirstAppear = true
        maybeShowWelcome()
    }

    // MARK: - buildUi -------------------------------------------------------

    private func buildUi() {
        let bar = UIStackView()
        bar.axis = .horizontal
        bar.distribution = .fillEqually
        bar.backgroundColor = argbToUIColor(C.BG)
        bar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(bar)

        for tab in Tab.allCases {
            let b = HomeTabButton()
            b.icon = tab.icon
            b.setLabel(kerned(L10n.tr(tab.label), 9, .semibold, kern: 1.0))
            b.on = tab == .projects
            b.tapped = { [weak self] in self?.show(tab) }
            bar.addArrangedSubview(b)
            barButtons.append(b)
        }

        content.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(content)

        NSLayoutConstraint.activate([
            bar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            bar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            bar.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            bar.heightAnchor.constraint(equalToConstant: 58),
            content.topAnchor.constraint(equalTo: view.topAnchor),
            content.bottomAnchor.constraint(equalTo: bar.topAnchor),
            content.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            content.trailingAnchor.constraint(equalTo: view.trailingAnchor),
        ])
    }

    // MARK: - tab switching ---------------------------------------------------

    private func show(_ tab: Tab) {
        selectedTab = tab
        for (i, b) in barButtons.enumerated() {
            b.on = i == tab.rawValue
        }
        if let child = tabChild {
            child.willMove(toParent: nil)
            child.view.removeFromSuperview()
            child.removeFromParent()
            tabChild = nil
        }
        current?.removeFromSuperview()
        let v = buildTab(tab)
        v.translatesAutoresizingMaskIntoConstraints = false
        content.addSubview(v)
        NSLayoutConstraint.activate([
            v.topAnchor.constraint(equalTo: content.topAnchor),
            v.bottomAnchor.constraint(equalTo: content.bottomAnchor),
            v.leadingAnchor.constraint(equalTo: content.leadingAnchor),
            v.trailingAnchor.constraint(equalTo: content.trailingAnchor),
        ])
        current = v
    }

    private func buildTab(_ tab: Tab) -> UIView {
        switch tab {
        case .projects: return buildProjects()
        case .account: return buildAccount()
        case .tools: return buildTools()
        case .community: return buildCommunity()
        case .extras: return buildExtras()
        }
    }

    @objc private func storeChanged() { refresh() }
    @objc private func languageChanged() {
        for (i, b) in barButtons.enumerated() {
            if let tab = Tab(rawValue: i) { b.setLabel(kerned(L10n.tr(tab.label), 9, .semibold, kern: 1.0)) }
        }
        show(selectedTab)
    }

    // MARK: - Projects tab ("My Playground") --------------------------------

    private func buildProjects() -> UIView {
        let wrap = UIView()

        // the kerned wordmark above the big title (reference UI)
        let wordmark = UILabel()
        wordmark.attributedText = kerned("SAIKI MOTION", 12, .bold, kern: 2.2)
        wordmark.textColor = argbToUIColor(C.GREEN)
        wordmark.translatesAutoresizingMaskIntoConstraints = false
        wrap.addSubview(wordmark)

        let header = UILabel()
        header.text = "My Playground"
        header.font = .boldSystemFont(ofSize: 27)
        header.textColor = argbToUIColor(C.TEXT)
        header.translatesAutoresizingMaskIntoConstraints = false
        wrap.addSubview(header)

        let count = UILabel()
        count.font = .systemFont(ofSize: 12)
        count.textColor = argbToUIColor(C.DIM)
        count.textAlignment = .right
        count.translatesAutoresizingMaskIntoConstraints = false
        wrap.addSubview(count)
        countLabel = count

        // scrollable list / empty state
        let scroll = UIScrollView()
        scroll.alwaysBounceVertical = true
        scroll.translatesAutoresizingMaskIntoConstraints = false
        wrap.addSubview(scroll)

        let stack = UIStackView()
        stack.axis = .vertical
        stack.spacing = 10
        stack.translatesAutoresizingMaskIntoConstraints = false
        scroll.addSubview(stack)
        listStack = stack

        // bottom actions, exactly like the reference: dark-brown
        // IMPORT PROJECT FILE stacked above the orange + NEW PROJECT
        let importBtn = HomeBigButton()
        importBtn.title = kerned("IMPORT PROJECT FILE", 13, .bold)
        importBtn.bg = Int32(bitPattern: 0xFF14351F)      // dark green (green-editor theme)
        importBtn.fg = C.GREEN
        importBtn.icon = "import"
        importBtn.tapped = { [weak self] in self?.pickProjectFile() }
        importBtn.translatesAutoresizingMaskIntoConstraints = false
        wrap.addSubview(importBtn)

        let newBtn = HomeBigButton()
        newBtn.title = kerned(L10n.tr("New project"), 15, .bold)
        newBtn.bg = C.GREEN
        newBtn.fg = C.ONDARK
        newBtn.icon = "plus"
        newBtn.tapped = { [weak self] in self?.showNewDialog() }
        newBtn.translatesAutoresizingMaskIntoConstraints = false
        wrap.addSubview(newBtn)

        let divider = UIView()
        divider.backgroundColor = argbToUIColor(C.LINE)
        divider.translatesAutoresizingMaskIntoConstraints = false
        wrap.addSubview(divider)

        NSLayoutConstraint.activate([
            wordmark.topAnchor.constraint(equalTo: wrap.safeAreaLayoutGuide.topAnchor, constant: 16),
            wordmark.leadingAnchor.constraint(equalTo: wrap.leadingAnchor, constant: pad),
            header.topAnchor.constraint(equalTo: wordmark.bottomAnchor, constant: 2),
            header.leadingAnchor.constraint(equalTo: wrap.leadingAnchor, constant: pad),
            count.centerYAnchor.constraint(equalTo: header.centerYAnchor),
            count.trailingAnchor.constraint(equalTo: wrap.trailingAnchor, constant: -pad),
            count.leadingAnchor.constraint(greaterThanOrEqualTo: header.trailingAnchor, constant: 8),
            scroll.topAnchor.constraint(equalTo: header.bottomAnchor, constant: 10),
            scroll.leadingAnchor.constraint(equalTo: wrap.leadingAnchor),
            scroll.trailingAnchor.constraint(equalTo: wrap.trailingAnchor),
            scroll.bottomAnchor.constraint(equalTo: importBtn.topAnchor, constant: -12),
            stack.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor, constant: 4),
            stack.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor, constant: -16),
            stack.leadingAnchor.constraint(equalTo: scroll.contentLayoutGuide.leadingAnchor, constant: pad),
            stack.trailingAnchor.constraint(equalTo: scroll.contentLayoutGuide.trailingAnchor, constant: -pad),
            stack.widthAnchor.constraint(equalTo: scroll.frameLayoutGuide.widthAnchor, constant: -2 * pad),
            importBtn.leadingAnchor.constraint(equalTo: wrap.leadingAnchor, constant: pad),
            importBtn.trailingAnchor.constraint(equalTo: wrap.trailingAnchor, constant: -pad),
            importBtn.bottomAnchor.constraint(equalTo: newBtn.topAnchor, constant: -10),
            importBtn.heightAnchor.constraint(equalToConstant: 46),
            newBtn.leadingAnchor.constraint(equalTo: wrap.leadingAnchor, constant: pad),
            newBtn.trailingAnchor.constraint(equalTo: wrap.trailingAnchor, constant: -pad),
            newBtn.bottomAnchor.constraint(equalTo: wrap.bottomAnchor, constant: -12),
            newBtn.heightAnchor.constraint(equalToConstant: 46),
            divider.leadingAnchor.constraint(equalTo: wrap.leadingAnchor),
            divider.trailingAnchor.constraint(equalTo: wrap.trailingAnchor),
            divider.bottomAnchor.constraint(equalTo: wrap.bottomAnchor),
            divider.heightAnchor.constraint(equalToConstant: 0.5),
        ])

        refresh()
        return wrap
    }

    /// Total bytes used by the store (projects + media + user SDK effects).
    /// Metadata only — no file bodies are read.
    private func storeBytes() -> Int64 {
        var total: Int64 = 0
        if let en = FileManager.default.enumerator(
            at: Paths.root, includingPropertiesForKeys: [.fileSizeKey],
            options: [.skipsHiddenFiles]) {
            for case let url as URL in en {
                if let sz = (try? url.resourceValues(forKeys: [.fileSizeKey]))?.fileSize {
                    total += Int64(sz)
                }
            }
        }
        return total
    }

    /// Rebuilds the project card list + stats (the original's refresh()).
    private func refresh() {
        projects = Projects.list()
        let mb = Double(storeBytes()) / 1_048_576.0
        let stats = "\(projects.count) \(L10n.tr("projects")) · " +
                    String(format: "%.1f", mb) + " MB \(L10n.tr("on device"))"
        let stack = listStack
        let count = countLabel
        guard projects.count > 0 || stack != nil else { return }
        stack?.arrangedSubviews.forEach { $0.removeFromSuperview() }

        if projects.isEmpty {
            count?.text = nil

            // the reference empty state, now with the thinking chibi:
            // mascot art in the middle of the content area, hint + stats below
            let spacer = UIView()
            spacer.heightAnchor.constraint(equalToConstant: 24).isActive = true
            stack?.addArrangedSubview(spacer)

            let chibi = ChibiView(.thinking)
            chibi.heightAnchor.constraint(equalToConstant: 230).isActive = true
            stack?.addArrangedSubview(chibi)

            let thinking = UILabel()
            thinking.text = "Hmm... nothing here yet."
            thinking.font = .systemFont(ofSize: 14, weight: .semibold)
            thinking.textColor = argbToUIColor(C.GREEN)
            thinking.textAlignment = .center
            stack?.addArrangedSubview(thinking)

            let empty = UILabel()
            empty.text = L10n.tr("No projects yet. Tap NEW PROJECT to start.")
            empty.font = .systemFont(ofSize: 13)
            empty.textColor = argbToUIColor(C.DIM)
            empty.textAlignment = .center
            empty.numberOfLines = 0
            stack?.addArrangedSubview(empty)

            let s = UILabel()
            s.text = stats
            s.font = .systemFont(ofSize: 12)
            s.textColor = argbToUIColor(C.DIM)
            s.textAlignment = .center
            stack?.addArrangedSubview(s)
            return
        }

        count?.text = stats
        for (i, p) in projects.enumerated() {
            stack?.addArrangedSubview(projectRow(i, p))
        }
    }

    /// One project card (the original's projectRow). Tap opens the editor;
    /// long-press opens Rename / Duplicate / Delete / Export.
    private func projectRow(_ index: Int, _ info: Project) -> UIView {
        let card = UIView()
        card.backgroundColor = argbToUIColor(C.CARD)
        card.layer.cornerRadius = 14

        let name = UILabel()
        name.text = info.name
        name.font = .systemFont(ofSize: 16, weight: .semibold)
        name.textColor = argbToUIColor(C.TEXT)
        name.translatesAutoresizingMaskIntoConstraints = false
        card.addSubview(name)

        let meta = UILabel()
        meta.text = Projects.resLabel(info)
        meta.font = .systemFont(ofSize: 12)
        meta.textColor = argbToUIColor(C.DIM)
        meta.translatesAutoresizingMaskIntoConstraints = false
        card.addSubview(meta)

        let dots = ToolIconDots()
        dots.onClick = { [weak self] in self?.showDotsMenu(info) }
        dots.translatesAutoresizingMaskIntoConstraints = false
        card.addSubview(dots)

        let date = UILabel()
        date.text = relativeDate(info.updatedAt)
        date.font = .systemFont(ofSize: 11)
        date.textColor = argbToUIColor(C.DIM)
        date.translatesAutoresizingMaskIntoConstraints = false
        card.addSubview(date)

        NSLayoutConstraint.activate([
            name.topAnchor.constraint(equalTo: card.topAnchor, constant: 12),
            name.leadingAnchor.constraint(equalTo: card.leadingAnchor, constant: 14),
            name.trailingAnchor.constraint(equalTo: date.leadingAnchor, constant: -8),
            meta.topAnchor.constraint(equalTo: name.bottomAnchor, constant: 3),
            meta.leadingAnchor.constraint(equalTo: card.leadingAnchor, constant: 14),
            meta.bottomAnchor.constraint(equalTo: card.bottomAnchor, constant: -12),
            dots.topAnchor.constraint(equalTo: card.topAnchor, constant: 4),
            dots.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -4),
            dots.widthAnchor.constraint(equalToConstant: 40),
            dots.heightAnchor.constraint(equalToConstant: 40),
            date.centerYAnchor.constraint(equalTo: name.centerYAnchor),
            date.trailingAnchor.constraint(equalTo: dots.leadingAnchor, constant: -2),
            card.heightAnchor.constraint(greaterThanOrEqualToConstant: 64),
        ])

        let tap = UITapGestureRecognizer(target: self, action: #selector(rowTapped(_:)))
        tap.delegate = self
        card.addGestureRecognizer(tap)

        let long = UILongPressGestureRecognizer()
        long.minimumPressDuration = 0.35
        long.delegate = self
        long.addTarget(self, action: #selector(rowLongPressed(_:)))
        card.tag = 200 + index
        card.addGestureRecognizer(long)
        card.isUserInteractionEnabled = true
        return card
    }

    @objc private func rowTapped(_ g: UITapGestureRecognizer) {
        guard g.state == .ended, let card = g.view,
              let p = projects[safe: card.tag - 200] else { return }
        if g.location(in: card).x > card.bounds.width - 48 && g.location(in: card).y < 52 { return }   // the 3-dot button
        open(p)
    }

    @objc private func rowLongPressed(_ g: UILongPressGestureRecognizer) {
        guard g.state == .began,
              let card = g.view,
              let p = projects[safe: card.tag - 200] else { return }
        showMenu(p)
    }

    private func open(_ project: Project) {
        CrashLog.note("open_project")
        navigationController?.pushViewController(EditorViewController(projectId: project.id),
                                                 animated: true)
    }

    // MARK: - dialogs (the original's showNewDialog / showMenu / showExport) --

    /// New Project: the full creation sheet (reference UI) — pre-filled name,
    /// Resolution, Aspect ratio and Frame rate pickers plus a live size
    /// summary. Create always makes a project: an untouched field falls back
    /// to the pre-filled "Project N" name, so the button can never silently
    /// do nothing.
    private func showNewDialog() {
        var res = 1        // 0: 720p, 1: 1080p, 2: 1440p
        let aspectChips = AspectChips(selected: 0)   // presets + Custom
        var fps = 1        // 0: 24, 1: 30, 2: 60
        let fpsOptions = [24, 30, 60]

        let defaultName = "Project \(projects.count + 1)"
        let field = makeField(defaultName)

        let summary = UILabel()
        summary.font = .systemFont(ofSize: 13, weight: .medium)
        summary.textColor = argbToUIColor(C.TEXT)
        summary.textAlignment = .center

        func dims() -> (Int, Int) {
            AspectPresets.dims(base: [720, 1080, 1440][res], ratio: aspectChips.ratio)
        }
        func updateSummary() {
            let (w, h) = dims()
            summary.text = "\(w) x \(h) · \(fpsOptions[fps]) fps"
        }
        updateSummary()

        let col = UIStackView()
        col.axis = .vertical
        col.alignment = .fill
        col.spacing = 12
        col.translatesAutoresizingMaskIntoConstraints = false

        func section(_ key: String) {
            let l = UILabel()
            l.attributedText = kerned(L10n.tr(key), 11, .semibold, kern: 1.2)
            l.textColor = argbToUIColor(C.DIM)
            col.addArrangedSubview(l)
        }

        section("Project name")
        col.addArrangedSubview(field)
        section("Resolution")
        col.addArrangedSubview(segmentRow(["720p", "1080p", "1440p"], res) { i in
            res = i; updateSummary()
        })
        section("Aspect ratio")
        aspectChips.onChange = { updateSummary() }
        col.addArrangedSubview(aspectChips)
        section("Frame rate")
        col.addArrangedSubview(segmentRow(["24 fps", "30 fps", "60 fps"], fps) { i in
            fps = i; updateSummary()
        })
        col.addArrangedSubview(summary)

        Dlg(self)
            .setTitle(L10n.tr("New Project"))
            .setView(col)
            .setPositiveButton(L10n.tr("Create")) { [weak self] _, _ in
                guard let self = self else { return }
                var name = (field.text ?? "").trimmingCharacters(in: .whitespaces)
                if name.isEmpty { name = defaultName }
                let (w, h) = dims()
                var project = Project(name: name, w: w, h: h, fps: fpsOptions[fps])
                Projects.save(&project)
                self.refresh()
                self.open(project)
            }
            .setNegativeButton(L10n.tr("Cancel"), nil)
            .show()
        // NOTE: the field is pre-filled ("Project N") and is NOT auto-focused
        // — the reference sheet shows with the keyboard down so the pickers,
        // the summary and Create are all visible. Tapping the field opens the
        // keyboard as usual; Create works either way (empty falls back to the
        // pre-filled name).
    }

    /// One segmented pick row (the creation sheet's pill selectors).
    private func segmentRow(_ options: [String], _ selected: Int,
                            _ change: @escaping (Int) -> Void) -> UIStackView {
        let row = UIStackView()
        row.axis = .horizontal
        row.distribution = .fillEqually
        row.spacing = 8
        for (i, opt) in options.enumerated() {
            let p = SegPill()
            p.title = opt
            p.on = i == selected
            p.tapped = { [weak p, weak row] in
                guard let p = p, let row = row else { return }
                for case let q as SegPill in row.arrangedSubviews { q.on = (q === p) }
                change(i)
            }
            p.heightAnchor.constraint(equalToConstant: 34).isActive = true
            row.addArrangedSubview(p)
        }
        return row
    }

    /// Long-press menu on a project card.
    private func showMenu(_ p: Project) {
        Dlg(self)
            .setIconItems([L10n.tr("Rename project"), L10n.tr("Duplicate"),
                           L10n.tr("Delete project?"), L10n.tr("Export project file")],
                          ["edit", "dup", "trash", "export"]) { [weak self] _, which in
                guard let self = self else { return }
                switch which {
                case 0: self.showRename(p)
                case 1:
                    _ = Projects.duplicate(p.id)
                    self.refresh()
                case 2: self.confirmDelete(p)
                case 3: self.showExportDialog(p)
                default: break
                }
            }
            .show()
    }

    private func showRename(_ p: Project) {
        let field = makeField(p.name)
        Dlg(self)
            .setTitle(L10n.tr("Rename project"))
            .setView(field)
            .setPositiveButton(L10n.tr("OK")) { [weak self] _, _ in
                let name = (field.text ?? "").trimmingCharacters(in: .whitespaces)
                if !name.isEmpty { Projects.rename(p.id, name) }
                self?.refresh()
            }
            .setNegativeButton(L10n.tr("Cancel"), nil)
            .show()
    }

    private func confirmDelete(_ p: Project) {
        Dlg(self)
            .setTitle(L10n.tr("Delete project?"))
            .setMessage("\"\(p.name)\"")
            .setPositiveButton(L10n.tr("Delete")) { [weak self] _, _ in
                Projects.delete(p.id)
                self?.refresh()
            }
            .setNegativeButton(L10n.tr("Cancel"), nil)
            .show()
    }

    /// The card's 3-dot menu: Duplicate / Delete / Export project file.
    private func showDotsMenu(_ p: Project) {
        Dlg(self)
            .setIconItems([L10n.tr("Rename project"), L10n.tr("Duplicate"), L10n.tr("Delete project?"),
                           L10n.tr("Export project file")],
                          ["edit", "dup", "trash", "export"]) { [weak self] _, which in
                guard let self = self else { return }
                switch which {
                case 0: self.showRename(p)
                case 1:
                    _ = Projects.duplicate(p.id)
                    self.refresh()
                case 2: self.confirmDelete(p)
                case 3: self.showExportDialog(p)
                default: break
                }
            }
            .show()
    }

    /// Export sheet: plain project file, or — with "Include media" on — a
    /// self-contained .saikiproject that carries the images, video, audio and fonts.
    private func showExportDialog(_ p: Project) {
        var withMedia = false

        let title = UILabel()
        title.text = "Include media"
        title.font = .systemFont(ofSize: 15, weight: .semibold)
        title.textColor = argbToUIColor(C.TEXT)
        let sub = UILabel()
        sub.text = "Off: project file (.json) only.\nOn: one .saikiproject with all media inside."
        sub.font = .systemFont(ofSize: 12)
        sub.textColor = argbToUIColor(C.DIM)
        sub.numberOfLines = 0
        let labels = UIStackView(arrangedSubviews: [title, sub])
        labels.axis = .vertical
        labels.spacing = 3
        let sw = UISwitch()
        sw.onTintColor = argbToUIColor(C.GREEN)
        sw.setContentHuggingPriority(.required, for: .horizontal)
        sw.addAction(UIAction { [weak sw] _ in withMedia = sw?.isOn ?? false }, for: .valueChanged)
        let row = UIStackView(arrangedSubviews: [labels, sw])
        row.axis = .horizontal
        row.alignment = .center
        row.spacing = 12
        row.translatesAutoresizingMaskIntoConstraints = false

        Dlg(self)
            .setTitle(L10n.tr("Export project file"))
            .setMessage("\"\(p.name)\"")
            .setView(row)
            .setPositiveButton("Export") { [weak self] _, _ in
                guard let self = self else { return }
                if !withMedia {
                    self.showExport(p)
                    return
                }
                self.toast("Packing project…")
                DispatchQueue.global(qos: .userInitiated).async { [weak self] in
                    let url = ProjectArchive.export(p.id)
                    DispatchQueue.main.async {
                        guard let self = self else { return }
                        if let url = url { self.shareFile(url) } else { self.toast("Export failed") }
                    }
                }
            }
            .setNegativeButton(L10n.tr("Cancel"), nil)
            .show()
    }

    /// Shares the plain project JSON (named after the project, not its id).
    private func showExport(_ info: Project) {
        let safe = info.name.components(separatedBy: CharacterSet(charactersIn: "/\\:*?\"<>|")).joined(separator: "_")
        let tmp = FileManager.default.temporaryDirectory
            .appendingPathComponent((safe.isEmpty ? "project" : safe) + ".json")
        try? FileManager.default.removeItem(at: tmp)
        if (try? FileManager.default.copyItem(at: Projects.exportURL(info.id), to: tmp)) != nil {
            shareFile(tmp)
        } else {
            shareFile(Projects.exportURL(info.id))
        }
    }

    private func shareFile(_ url: URL) {
        let share = UIActivityViewController(activityItems: [url], applicationActivities: nil)
        share.popoverPresentationController?.sourceView = view
        share.popoverPresentationController?.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 1, height: 1)
        present(share, animated: true)
    }

    /// The name input used by New / Rename (the original's makeField).
    private func makeField(_ initial: String) -> UITextField {
        let f = UITextField()
        f.text = initial
        f.placeholder = L10n.tr("New Project")
        f.font = .systemFont(ofSize: 15)
        f.textColor = argbToUIColor(C.TEXT)
        f.backgroundColor = argbToUIColor(C.CARD2)
        f.layer.cornerRadius = 10
        f.autocorrectionType = .no
        f.returnKeyType = .done
        f.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 12, height: 1))
        f.leftViewMode = .always
        f.heightAnchor.constraint(equalToConstant: 40).isActive = true
        return f
    }

    // MARK: - import (the original's documentPicker) ---------------------------

    private func pickProjectFile() {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.data],
                                                    asCopy: true)
        picker.delegate = self
        picker.allowsMultipleSelection = false
        present(picker, animated: true)
    }

    // MARK: - What's New --------------------------------------------------------

    /// The original's rule: the welcome card shows on every launch until the
    /// user taps "Don't show again" ("hideWelcome" in UserDefaults) — full
    /// screen, standard cover transition (no flip).
    private func maybeShowWelcome() {
        guard !UserDefaults.standard.bool(forKey: "hideWelcome") else { return }
        let w = WelcomeViewController()
        w.modalPresentationStyle = .fullScreen
        present(w, animated: true)
    }

    // MARK: - other tabs --------------------------------------------------------

    private func cardView() -> (UIView, UIStackView) {
        let wrap = UIView()
        let stack = UIStackView()
        stack.axis = .vertical
        stack.spacing = 12
        stack.translatesAutoresizingMaskIntoConstraints = false
        wrap.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.topAnchor.constraint(equalTo: wrap.safeAreaLayoutGuide.topAnchor, constant: 18),
            stack.leadingAnchor.constraint(equalTo: wrap.leadingAnchor, constant: pad),
            stack.trailingAnchor.constraint(equalTo: wrap.trailingAnchor, constant: -pad),
        ])
        return (wrap, stack)
    }

    private func tabHeader(_ text: String) -> UILabel {
        let l = UILabel()
        l.attributedText = kerned(text, 24, .bold)
        l.textColor = argbToUIColor(C.TEXT)
        return l
    }

    private func infoCard(_ title: String, _ lines: [String]) -> UIView {
        let card = UIView()
        card.backgroundColor = argbToUIColor(C.CARD)
        card.layer.cornerRadius = 14
        let stack = UIStackView()
        stack.axis = .vertical
        stack.spacing = 6
        stack.translatesAutoresizingMaskIntoConstraints = false
        card.addSubview(stack)
        let t = UILabel()
        t.attributedText = kerned(title.uppercased(), 12, .semibold)
        t.textColor = argbToUIColor(C.GREEN)
        stack.addArrangedSubview(t)
        for ln in lines {
            let l = UILabel()
            l.text = ln
            l.font = .systemFont(ofSize: 13)
            l.textColor = argbToUIColor(C.DIM)
            l.numberOfLines = 0
            stack.addArrangedSubview(l)
        }
        NSLayoutConstraint.activate([
            stack.topAnchor.constraint(equalTo: card.topAnchor, constant: 14),
            stack.bottomAnchor.constraint(equalTo: card.bottomAnchor, constant: -14),
            stack.leadingAnchor.constraint(equalTo: card.leadingAnchor, constant: 14),
            stack.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -14),
        ])
        return card
    }

    private func buildAccount() -> UIView {
        let (wrap, stack) = cardView()
        stack.addArrangedSubview(tabHeader(L10n.tr("Account")))
        stack.addArrangedSubview(infoCard("SaikiMotion", [
            "\(L10n.tr("Version")): \(AppInfo.displayVersion)",
            AppInfo.bundleId,
            L10n.tr("Offline notice"),
        ]))
        return wrap
    }

    // MARK: - Tools tab ----------------------------------------------------------

    private func buildTools() -> UIView {
        let (wrap, stack) = cardView()
        stack.addArrangedSubview(tabHeader(L10n.tr("Tools")))
        stack.addArrangedSubview(toolCard(
            "Anime Decomposition",
            "Split an anime character into head, eyes, eyelids, hair strands, body parts, clothes and line art, right on your phone. " +
            "Layers come auto-grouped. Export as PSD, as an image, or straight into a new project.",
            icon: "anime") { [weak self] in
                self?.navigationController?.pushViewController(AnimeDecomposeViewController(), animated: true)
            })
        stack.addArrangedSubview(toolCard(
            "Drawing Editor",
            "Paint, smudge and erase on layers with folders, just like a drawing app. Hold the canvas to pick a color. " +
            "Anime Decomposition can send its layers here, and any drawing can be sent into a video project.",
            icon: "edit") { [weak self] in
                self?.navigationController?.pushViewController(DrawingGalleryViewController(), animated: true)
            })
        return wrap
    }

    /// One tappable tool entry: orange icon badge, title, description underneath.
    private func toolCard(_ title: String, _ desc: String, icon: String,
                          _ open: @escaping () -> Void) -> UIView {
        let card = ToolCardView()
        card.onClick = open
        card.backgroundColor = argbToUIColor(C.CARD)
        card.layer.cornerRadius = 14

        let badge = ToolBadgeView()
        badge.icon = icon
        badge.isUserInteractionEnabled = false
        badge.translatesAutoresizingMaskIntoConstraints = false

        let t = UILabel()
        t.text = title
        t.font = .systemFont(ofSize: 17, weight: .bold)
        t.textColor = argbToUIColor(C.TEXT)

        let d = UILabel()
        d.text = desc
        d.font = .systemFont(ofSize: 13)
        d.textColor = argbToUIColor(C.DIM)
        d.numberOfLines = 0

        let tag = UILabel()
        tag.attributedText = kerned("OPEN TOOL  ›", 11, .bold, kern: 1.4)
        tag.textColor = argbToUIColor(C.GREEN)

        let col = UIStackView(arrangedSubviews: [t, d, tag])
        col.axis = .vertical
        col.spacing = 6
        col.isUserInteractionEnabled = false
        col.translatesAutoresizingMaskIntoConstraints = false

        card.addSubview(badge)
        card.addSubview(col)
        NSLayoutConstraint.activate([
            badge.leadingAnchor.constraint(equalTo: card.leadingAnchor, constant: 14),
            badge.topAnchor.constraint(equalTo: card.topAnchor, constant: 16),
            badge.widthAnchor.constraint(equalToConstant: 44),
            badge.heightAnchor.constraint(equalToConstant: 44),
            col.topAnchor.constraint(equalTo: card.topAnchor, constant: 16),
            col.bottomAnchor.constraint(equalTo: card.bottomAnchor, constant: -16),
            col.leadingAnchor.constraint(equalTo: badge.trailingAnchor, constant: 14),
            col.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -14),
        ])
        return card
    }

    private func buildCommunity() -> UIView {
        let wrap = UIView()
        let header = tabHeader(L10n.tr("Community"))
        header.translatesAutoresizingMaskIntoConstraints = false
        wrap.addSubview(header)
        NSLayoutConstraint.activate([
            header.topAnchor.constraint(equalTo: wrap.safeAreaLayoutGuide.topAnchor, constant: 14),
            header.leadingAnchor.constraint(equalTo: wrap.leadingAnchor, constant: pad),
        ])
        // the bundled SDK example effects (the real defs, read-only)
        let gallery = EffectsGalleryViewController(mode: .browse)
        addChild(gallery)
        gallery.view.translatesAutoresizingMaskIntoConstraints = false
        wrap.addSubview(gallery.view)
        NSLayoutConstraint.activate([
            gallery.view.topAnchor.constraint(equalTo: header.bottomAnchor, constant: 8),
            gallery.view.leadingAnchor.constraint(equalTo: wrap.leadingAnchor),
            gallery.view.trailingAnchor.constraint(equalTo: wrap.trailingAnchor),
            gallery.view.bottomAnchor.constraint(equalTo: wrap.bottomAnchor),
        ])
        gallery.didMove(toParent: self)
        tabChild = gallery
        return wrap
    }

    private func buildExtras() -> UIView {
        let (wrap, stack) = cardView()
        stack.addArrangedSubview(tabHeader(L10n.tr("Extras")))
        stack.addArrangedSubview(infoCard(L10n.tr("Crash reports"), [
            "\(CrashLog.reportCount()) \(L10n.tr("in the Crash folder of this app"))",
        ]))
        // render cache (frames + effect thumbnails): lives in the Caches folder, outside every project
        let cacheCard = UIView()
        cacheCard.backgroundColor = argbToUIColor(C.CARD)
        cacheCard.layer.cornerRadius = 14
        let cacheTitle = UILabel()
        cacheTitle.text = "Render cache"
        cacheTitle.textColor = argbToUIColor(C.TEXT)
        cacheTitle.font = .systemFont(ofSize: 15, weight: .semibold)
        let cacheSize = UILabel()
        cacheSize.text = "Calculating…"
        cacheSize.textColor = argbToUIColor(C.DIM)
        cacheSize.font = .systemFont(ofSize: 13)
        DispatchQueue.global(qos: .utility).async {
            let t = FrameCache.sizeText()
            DispatchQueue.main.async { cacheSize.text = "Using \(t) — projects are not affected" }
        }
        let clearBtn = UIButton(type: .system)
        clearBtn.setTitle("Clear cache", for: .normal)
        clearBtn.setTitleColor(argbToUIColor(C.RED), for: .normal)
        clearBtn.titleLabel?.font = .systemFont(ofSize: 14, weight: .semibold)
        clearBtn.contentHorizontalAlignment = .left
        clearBtn.addAction(UIAction { _ in
            cacheSize.text = "Clearing…"
            DispatchQueue.global(qos: .utility).async {
                FrameCache.clearAll()
                let t = FrameCache.sizeText()
                DispatchQueue.main.async { cacheSize.text = "Using \(t) — projects are not affected" }
            }
        }, for: .touchUpInside)
        let liveRow = UIStackView()
        liveRow.axis = .horizontal
        liveRow.alignment = .center
        let liveLbl = UILabel()
        liveLbl.text = "Live render cache (render ahead in the editor)"
        liveLbl.textColor = argbToUIColor(C.TEXT)
        liveLbl.font = .systemFont(ofSize: 13)
        liveLbl.numberOfLines = 0
        let liveSw = UISwitch()
        liveSw.isOn = FrameCache.enabled
        liveSw.onTintColor = argbToUIColor(C.GREEN)
        liveSw.setContentHuggingPriority(.required, for: .horizontal)
        liveSw.addAction(UIAction { [weak liveSw] _ in
            if let sw = liveSw { FrameCache.enabled = sw.isOn }
        }, for: .valueChanged)
        liveRow.addArrangedSubview(liveLbl)
        liveRow.addArrangedSubview(liveSw)
        let preRow = UIStackView()
        preRow.axis = .horizontal
        preRow.alignment = .center
        let preLbl = UILabel()
        preLbl.text = "Pre-render groups (bake groups to frames)"
        preLbl.textColor = argbToUIColor(C.TEXT)
        preLbl.font = .systemFont(ofSize: 13)
        preLbl.numberOfLines = 0
        let preSw = UISwitch()
        preSw.isOn = PreRender.enabled
        preSw.onTintColor = argbToUIColor(C.GREEN)
        preSw.setContentHuggingPriority(.required, for: .horizontal)
        preSw.addAction(UIAction { [weak preSw] _ in
            if let sw = preSw { PreRender.enabled = sw.isOn }
        }, for: .valueChanged)
        preRow.addArrangedSubview(preLbl)
        preRow.addArrangedSubview(preSw)
        let cacheRows = UIStackView(arrangedSubviews: [cacheTitle, cacheSize, liveRow, preRow, clearBtn])
        cacheRows.axis = .vertical
        cacheRows.spacing = 6
        cacheRows.translatesAutoresizingMaskIntoConstraints = false
        cacheCard.addSubview(cacheRows)
        NSLayoutConstraint.activate([
            cacheRows.topAnchor.constraint(equalTo: cacheCard.topAnchor, constant: 14),
            cacheRows.bottomAnchor.constraint(equalTo: cacheCard.bottomAnchor, constant: -8),
            cacheRows.leadingAnchor.constraint(equalTo: cacheCard.leadingAnchor, constant: 14),
            cacheRows.trailingAnchor.constraint(equalTo: cacheCard.trailingAnchor, constant: -14),
        ])
        stack.addArrangedSubview(cacheCard)
        // language picker (the original localized the whole app; the picker
        // lives here so every tab re-renders in the chosen language)
        let rows = UIStackView()
        rows.axis = .vertical
        rows.spacing = 0
        for lang in L10n.languages {
            let b = UIButton(type: .system)
            b.setTitle((lang.code == L10n.current ? "• " : "   ") + lang.label,
                       for: .normal)
            b.setTitleColor(argbToUIColor(lang.code == L10n.current ? C.GREEN : C.DIM),
                            for: .normal)
            b.titleLabel?.font = .systemFont(ofSize: 14)
            b.contentHorizontalAlignment = .left
            b.heightAnchor.constraint(equalToConstant: 34).isActive = true
            b.addAction(UIAction { _ in
                L10n.current = lang.code
                // the .languageChanged observer relabels the bar and rebuilds
                // the current tab; no extra work here (it used to re-run a
                // second refresh and could double the disk reads)
                StoreNotification.post(.languageChanged)
            }, for: .touchUpInside)
            rows.addArrangedSubview(b)
        }
        let langCard = UIView()
        langCard.backgroundColor = argbToUIColor(C.CARD)
        langCard.layer.cornerRadius = 14
        rows.translatesAutoresizingMaskIntoConstraints = false
        langCard.addSubview(rows)
        NSLayoutConstraint.activate([
            rows.topAnchor.constraint(equalTo: langCard.topAnchor, constant: 8),
            rows.bottomAnchor.constraint(equalTo: langCard.bottomAnchor, constant: -8),
            rows.leadingAnchor.constraint(equalTo: langCard.leadingAnchor, constant: 14),
            rows.trailingAnchor.constraint(equalTo: langCard.trailingAnchor, constant: -14),
        ])
        stack.addArrangedSubview(langCard)
        return wrap
    }

    // MARK: - helpers ------------------------------------------------------------

    /// Uppercase letter-spaced text — the original's kerned() helper.
    private func kerned(_ s: String, _ size: CGFloat = 13, _ weight: UIFont.Weight = .medium,
                        kern: CGFloat = 1.6)
        -> NSAttributedString {
        NSAttributedString(string: s.uppercased(), attributes: [
            .kern: kern,
            .font: UIFont.systemFont(ofSize: size, weight: weight),
        ])
    }

    private func relativeDate(_ d: Date) -> String {
        let f = RelativeDateTimeFormatter()
        f.unitsStyle = .abbreviated
        return f.localizedString(for: d, relativeTo: Date())
    }
}

// MARK: - document picker delegate ----------------------------------------------

extension HomeViewController: UIDocumentPickerDelegate {
    func documentPicker(_ controller: UIDocumentPickerViewController,
                        didPickDocumentsAt urls: [URL]) {
        guard let url = urls.first else { return }
        if Projects.importFile(url) != nil {
            refresh()
            toast(L10n.tr("Import") + " · " + Projects.lastImportNote)
        } else {
            toast("Not a SaikiMotion project file")
        }
    }
}

// MARK: - toast --------------------------------------------------------------------

extension HomeViewController {
    func toast(_ text: String) {
        guard let window = appKeyWindow() else { return }
        let l = UILabel()
        l.text = "  \(text)  "
        l.font = .systemFont(ofSize: 13, weight: .medium)
        l.textColor = argbToUIColor(C.TEXT)
        l.backgroundColor = UIColor(white: 0, alpha: 0.72)
        l.layer.cornerRadius = 14
        l.clipsToBounds = true
        l.textAlignment = .center
        l.numberOfLines = 0
        l.translatesAutoresizingMaskIntoConstraints = false
        window.addSubview(l)
        NSLayoutConstraint.activate([
            l.centerXAnchor.constraint(equalTo: window.centerXAnchor),
            l.bottomAnchor.constraint(equalTo: window.safeAreaLayoutGuide.bottomAnchor, constant: -90),
            l.leadingAnchor.constraint(greaterThanOrEqualTo: window.leadingAnchor, constant: 24),
            l.trailingAnchor.constraint(lessThanOrEqualTo: window.trailingAnchor, constant: -24),
        ])
        UIView.animate(withDuration: 0.25, delay: 1.8, options: [.curveEaseIn]) {
            l.alpha = 0
        } completion: { _ in
            l.removeFromSuperview()
        }
    }
}


// MARK: - small views for the Tools tab + project cards -------------------------------------

/// A tappable card (the Tools tab entries).
private final class ToolCardView: TapView {
    override var isHighlighted: Bool {
        didSet { alpha = isHighlighted ? 0.75 : 1 }
    }
}

/// Orange rounded badge with a vector icon.
private final class ToolBadgeView: UIView {
    var icon = "" { didSet { setNeedsDisplay() } }
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = argbToUIColor(C.GREEN)
        layer.cornerRadius = 12
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        Icons.draw(c, icon, bounds.midX, bounds.midY, 24, C.ONDARK)
    }
}

/// The 3-dot button in the corner of a project card.
private final class ToolIconDots: TapView {
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        Icons.draw(c, "more", bounds.midX, bounds.midY, 22, isHighlighted ? C.GREEN : C.DIM)
    }
}


// MARK: - the 3-dot button must win over the card's tap / long-press ------------------------

extension HomeViewController: UIGestureRecognizerDelegate {
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        !(touch.view is ToolIconDots)
    }
}
