// OverlayView.swift — selection, handles, guides, eyedropper (UI).
//
// Sits transparently over the preview. Draws the selected layer's world
// quad (same math the renderer uses), corner scale handles, a rotate handle
// and optional thirds guides. Touch: tap selects the top-most hit layer,
// drag moves (auto-key aware), corner handles scale, the rotate handle
// spins, and while `pick` is set a tap reports the preview pixel instead.

import UIKit

final class OverlayView: UIView {

    weak var editHost: EditHost?
    weak var timelineHost: TimelineHost?

    /// True while the Scene dialog's guides toggle is on.
    var guides = false {
        didSet { setNeedsDisplay() }
    }

    /// Eyedropper: preview-pixel coordinates (top-left origin).
    var pick: ((Float, Float) -> Void)? = nil

    private var dragMode = 0          // 0 none, 1 move, 2 scale, 3 rotate
    private var dragLayer: Layer? = nil
    private var dragStart = CGPoint.zero
    private var startDist: Float = 0
    private var startScale: Float = 1
    private var startRot: Float = 0
    private var startCenter = CGPoint.zero

    init(_ edit: EditHost, _ timeline: TimelineHost) {
        super.init(frame: .zero)
        editHost = edit
        timelineHost = timeline
        backgroundColor = .clear
        isOpaque = false
        contentMode = .redraw
        isMultipleTouchEnabled = false
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    // MARK: - geometry

    private var worldAr: Float {
        Float(Editor.project.w) / Float(max(Editor.project.h, 1))
    }

    /// world (x, y) → view point
    private func toScreen(_ x: Float, _ y: Float) -> CGPoint {
        let nx = (x / worldAr + 1) / 2
        let ny = (1 - y) / 2
        return CGPoint(x: CGFloat(nx) * bounds.width, y: CGFloat(ny) * bounds.height)
    }

    /// view point → world (x, y)
    private func toWorld(_ p: CGPoint) -> (Float, Float) {
        let nx = Float(p.x / max(bounds.width, 1))
        let ny = Float(p.y / max(bounds.height, 1))
        return (nx * 2 * worldAr - worldAr, 1 - ny * 2)
    }

    /// Layer-local quad points → view points, through the camera for 3D layers (same math as the
    /// renderer), so the gizmo sits exactly on the drawn layer in 2D and 3D.
    private func proj(_ l: Layer, _ pts: [(Float, Float)]) -> [CGPoint] {
        let w: [(Float, Float)]
        if l.is3d, let r = SceneRenderer.gizmoSource {
            w = r.gizmoProject(l, time: Editor.time, pts: pts)
        } else {
            let m = Xf.matrix(l, Editor.time)
            w = pts.map { Xf.apply(m, $0.0, $0.1) }
        }
        return w.map { toScreen($0.0, $0.1) }
    }

    private func screenQuad(_ l: Layer) -> [CGPoint] {
        let (qw, qh) = Xf.quadSize(l)
        let hw = qw / 2, hh = qh / 2
        return proj(l, [(-hw, hh), (hw, hh), (hw, -hh), (-hw, -hh)])
    }

    /// Where the layer's anchor point (its pivot) is on screen.
    private func anchorScreen(_ l: Layer) -> CGPoint {
        let (qw, qh) = Xf.quadSize(l)
        let lt = l.editTime("x", Editor.time)
        let ax = l.p("anchorX", lt), ay = l.p("anchorY", lt)
        return proj(l, [((ax - 50) / 100 * qw, -(ay - 50) / 100 * qh)])[0]
    }

    /// Every layer that shows a gizmo: the primary selection plus the rest of a multi-selection.
    private func gizmoLayers(primary l: Layer) -> [Layer] {
        var out = [l]
        for g in Editor.scene.layers where g !== l && (editHost?.isSelected(g.id) ?? false) && g.visible
            && Editor.time >= g.start - 0.001 && Editor.time <= g.end + 0.001 { out.append(g) }
        return out
    }

    private func hitLayer(_ l: Layer, _ p: CGPoint) -> Bool {
        if !l.is3d { let w = toWorld(p); return Xf.hit(l, w.0, w.1, Editor.time) }
        let q = screenQuad(l)
        var pos = false, neg = false
        for i in 0..<4 {
            let a = q[i], b = q[(i + 1) % 4]
            let cr = (b.x - a.x) * (p.y - a.y) - (b.y - a.y) * (p.x - a.x)
            if cr > 0 { pos = true } else if cr < 0 { neg = true }
        }
        return !(pos && neg)
    }

    /// On-screen size of a 3D layer relative to its flat size (perspective), so a finger drag moves it 1:1.
    private func depthScale(_ l: Layer) -> Float {
        let q = screenQuad(l)
        let f = Xf.quadCorners(l, Editor.time).map { toScreen($0.0, $0.1) }
        let a = hypot(q[1].x - q[0].x, q[1].y - q[0].y), b = hypot(f[1].x - f[0].x, f[1].y - f[0].y)
        guard b > 1 else { return 1 }
        return Float(max(0.05, min(a / b, 20)))
    }

    private var dragGroup: [Layer] = []

    // MARK: - drawing

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }

        if guides {
            let col = Int32(bitPattern: 0x66FFFFFF)
            for i in 1..<3 {
                let x = bounds.width * CGFloat(i) / 3
                strokeLine(c, x, 0, x, bounds.height, 1, col)
                let y = bounds.height * CGFloat(i) / 3
                strokeLine(c, 0, y, bounds.width, y, 1, col)
            }
            strokeLine(c, bounds.width / 2, 0, bounds.width / 2, bounds.height, 1, col)
            strokeLine(c, 0, bounds.height / 2, bounds.width, bounds.height / 2, 1, col)
        }

        if pick != nil {
            // eyedropper crosshair
            let col = Int32(bitPattern: 0xFFFFFFFF)
            strokeLine(c, bounds.width / 2 - 14, bounds.height / 2, bounds.width / 2 + 14, bounds.height / 2, 1.5, col)
            strokeLine(c, bounds.width / 2, bounds.height / 2 - 14, bounds.width / 2, bounds.height / 2 + 14, 1.5, col)
        }

        guard let l = editHost?.selectedLayer() else { return }
        if editHost?.puppetPanelOpen() == true, let pp = l.puppet {
            drawPuppet(c, l, pp)
            return
        }
        let group = gizmoLayers(primary: l)
        for g in group { drawGizmo(c, g, primary: g === l, handles: group.count == 1) }
    }

    private func drawGizmo(_ c: CGContext, _ l: Layer, primary: Bool, handles: Bool = true) {
        let q = screenQuad(l)

        // selection box
        let sel = primary ? C.GREEN : Int32(bitPattern: 0xFF8FE3A8)
        c.saveGState()
        c.setLineDash(phase: 0, lengths: [6, 5])
        for i in 0..<4 {
            let a = q[i], b = q[(i + 1) % 4]
            strokeLine(c, a.x, a.y, b.x, b.y, 1.5, sel)
        }
        c.restoreGState()
        // corner handles (skip for camera/null/audio/adjust, and in a multi-selection: highlight only)
        if handles && (l.isRenderable() || l.type == .GROUP) {
            for p in q {
                fillCircle(c, p.x, p.y, 7, Int32(bitPattern: 0xFFFFFFFF))
                fillCircle(c, p.x, p.y, 4, sel)
            }
            // rotate handle above the top edge midpoint
            let mid = CGPoint(x: (q[0].x + q[1].x) / 2, y: (q[0].y + q[1].y) / 2)
            let dx = (q[1].x - q[0].x), dy = (q[1].y - q[0].y)
            let len = max(sqrt(dx * dx + dy * dy), 0.001)
            // outward = away from the quad centre (never inward)
            var nx = -dy / len, ny = dx / len
            let cx = (q[0].x + q[1].x + q[2].x + q[3].x) / 4
            let cy = (q[0].y + q[1].y + q[2].y + q[3].y) / 4
            if (mid.x - cx) * nx + (mid.y - cy) * ny < 0 { nx = -nx; ny = -ny }
            let hp = CGPoint(x: mid.x + nx * 34, y: mid.y + ny * 34)
            c.saveGState()
            c.setLineDash(phase: 0, lengths: [4, 4])
            strokeLine(c, mid.x, mid.y, hp.x, hp.y, 1.5, sel)
            c.restoreGState()
            fillCircle(c, hp.x, hp.y, 6, sel)

            // anchor point: ring + crosshair where the layer pivots / rotates / scales from
            let ap = anchorScreen(l)
            let orange = Int32(bitPattern: 0xFF00E5FF)
            strokeLine(c, ap.x - 11, ap.y, ap.x + 11, ap.y, 1.5, Int32(bitPattern: 0xFFFFFFFF))
            strokeLine(c, ap.x, ap.y - 11, ap.x, ap.y + 11, 1.5, Int32(bitPattern: 0xFFFFFFFF))
            fillCircle(c, ap.x, ap.y, 6.5, Int32(bitPattern: 0xFFFFFFFF))
            fillCircle(c, ap.x, ap.y, 4, orange)
        }
    }

    // MARK: - touches

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        let p = t.location(in: self)

        if pick != nil {
            pick?(Float(p.x), Float(p.y))
            pick = nil
            setNeedsDisplay()
            return
        }

        if let pl = editHost?.selectedLayer(), editHost?.puppetPanelOpen() == true,
           let pp = pl.puppet, pp.on {
            puppetBegan(pl, pp, p)
            return
        }

        guard let l = editHost?.selectedLayer() else {
            // tap-select: top-most hit layer (reverse draw order)
            let w = toWorld(p)
            for layer in Editor.scene.layers.reversed() {
                guard layer.visible, layer.isRenderable() || layer.type == .GROUP || layer.type == .CAMERA
                        || layer.type == .NULL || layer.type == .ADJUST else { continue }
                guard Editor.time >= layer.start - 0.001 && Editor.time <= layer.end + 0.001 else { continue }
                if hitLayer(layer, p) {
                    editHost?.onSelect(layer.id)
                    setNeedsDisplay()
                    return
                }
            }
            editHost?.onSelect(-1)
            setNeedsDisplay()
            return
        }

        let multi = gizmoLayers(primary: l).count > 1
        for l in gizmoLayers(primary: l) {
        let q = screenQuad(l)

        // rotate / scale handles only exist for a single selection
        if !multi && (l.isRenderable() || l.type == .GROUP) {
            let mid = CGPoint(x: (q[0].x + q[1].x) / 2, y: (q[0].y + q[1].y) / 2)
            let dx = (q[1].x - q[0].x), dy = (q[1].y - q[0].y)
            let len = max(sqrt(dx * dx + dy * dy), 0.001)
            var hx = -dy / len, hy = dx / len
            let qcx = (q[0].x + q[1].x + q[2].x + q[3].x) / 4
            let qcy = (q[0].y + q[1].y + q[2].y + q[3].y) / 4
            if (mid.x - qcx) * hx + (mid.y - qcy) * hy < 0 { hx = -hx; hy = -hy }
            let hp = CGPoint(x: mid.x + hx * 34, y: mid.y + hy * 34)
            if distance(p, hp) < 22 {
                beginDrag(3, l, p)
                let w = toWorld(p)
                startRot = l.p("rotZ", l.editTime("rotZ", Editor.time))
                _ = w
                startCenter = anchorScreen(l)
                return
            }
            // corner handle?
            for c in q where distance(p, c) < 24 {
                beginDrag(2, l, p)
                // measure from the finger (not the corner) so the layer doesn't jump, and
                // remember the centre — it was never set for scaling (stale value = wild scale)
                startCenter = anchorScreen(l)
                let wc = toWorld(p)
                let wl = toWorld(startCenter)
                startDist = max(0.02, hypot(wc.0 - wl.0, wc.1 - wl.1))
                startScale = abs(l.p("scale", Editor.time))
                return
            }
        }
        }

        // inside the quad → move (every selected layer moves together)
        let w = toWorld(p)
        if gizmoLayers(primary: l).contains(where: { hitLayer($0, p) }) {
            beginDrag(1, l, p)
            dragGroup = gizmoLayers(primary: l)
        } else {
            // tap outside: re-select whatever is under the finger
            for layer in Editor.scene.layers.reversed() {
                guard layer.visible, Editor.time >= layer.start - 0.001 && Editor.time <= layer.end + 0.001 else { continue }
                if hitLayer(layer, p) {
                    editHost?.onSelect(layer.id)
                    setNeedsDisplay()
                    return
                }
            }
            editHost?.onSelect(-1)
        }
        setNeedsDisplay()
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        if pupDrag { puppetMoved(touches); return }
        guard let t = touches.first, let l = dragLayer, dragMode != 0 else { return }
        let p = t.location(in: self)
        let autoKey = editHost?.autoKey() ?? false

        switch dragMode {
        case 1: // move — dx/dy in world units
            let w0 = toWorld(dragStart)
            let w1 = toWorld(p)
            for g in (dragGroup.isEmpty ? [l] : dragGroup) {
                let lt = g.editTime("x", Editor.time)
                var dx = w1.0 - w0.0, dy = w1.1 - w0.1
                if g.is3d { let k = depthScale(g); dx /= k; dy /= k }
                let d = Xf.toParentSpace(g, Editor.time, dx, dy)
                g.track("x").set(lt, g.p("x", lt) + d.0, autoKey)
                g.track("y").set(lt, g.p("y", lt) + d.1, autoKey)
            }
            dragStart = p
            editHost?.onEdited()
        case 2: // scale by distance from center
            let wc = toWorld(p)
            let wl = toWorld(startCenter)
            let d = max(0.02, hypot(wc.0 - wl.0, wc.1 - wl.1))
            let lt = l.editTime("scale", Editor.time)
            // damped so the gizmo is gentle: 1.0 = exactly follows the finger, lower = calmer
            let sens: Float = 0.5
            let ratio = max(0.02, 1 + (d / startDist - 1) * sens)
            l.track("scale").set(lt, startScale * ratio, autoKey)
            editHost?.onEdited()
        case 3: // rotate around the layer center
            let wc = toWorld(p)
            let wl = toWorld(startCenter)
            let a0 = atan2(dragStartWorld.y - wl.1, dragStartWorld.x - wl.0)
            let a1 = atan2(wc.1 - wl.1, wc.0 - wl.0)
            let delta = (a1 - a0) * 180 / Float.pi
            let lt = l.editTime("rotZ", Editor.time)
            l.track("rotZ").set(lt, startRot + delta, autoKey)
            editHost?.onEdited()
        default:
            break
        }
        setNeedsDisplay()
    }

    private var dragStartWorld = (x: Float(0), y: Float(0))

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        pupDrag = false
        dragMode = 0
        dragLayer = nil
        dragGroup = []
        setNeedsDisplay()
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        pupDrag = false
        dragMode = 0
        dragLayer = nil
        dragGroup = []
        setNeedsDisplay()
    }

    private func beginDrag(_ mode: Int, _ l: Layer, _ p: CGPoint) {
        editHost?.beginEdit()
        dragMode = mode
        dragLayer = l
        dragStart = p
        dragStartWorld = toWorld(p)
    }

    // MARK: - puppet pins (viewport)

    private var pupDrag = false
    private var pupLast = CGPoint.zero
    private var pupMoved = false

    /// quad space (-1...1) → view point
    private func quadToScreen(_ l: Layer, _ ax: Float, _ ay: Float) -> CGPoint {
        let (qw, qh) = Xf.quadSize(l)
        let w = Xf.apply(Xf.matrix(l, Editor.time), ax * qw / 2, ay * qh / 2)
        return toScreen(w.0, w.1)
    }

    /// view point → quad space (-1...1)
    private func screenToQuad(_ l: Layer, _ p: CGPoint) -> (Float, Float)? {
        guard let inv = Xf.invert(Xf.matrix(l, Editor.time)) else { return nil }
        let w = toWorld(p)
        let q = Xf.apply(inv, w.0, w.1)
        let (qw, qh) = Xf.quadSize(l)
        guard qw > 0, qh > 0 else { return nil }
        return (q.0 / (qw / 2), q.1 / (qh / 2))
    }

    private func drawPuppet(_ c: CGContext, _ l: Layer, _ pp: Puppet) {
        let acc = C.GREEN
        let m = Xf.matrix(l, Editor.time)
        let qs = Xf.quadSize(l)
        func scr(_ ax: Float, _ ay: Float) -> CGPoint {
            let w = Xf.apply(m, ax * qs.0 / 2, ay * qs.1 / 2)
            return toScreen(w.0, w.1)
        }
        let q = screenQuad(l)
        c.saveGState()
        c.setLineDash(phase: 0, lengths: [6, 5])
        for i in 0..<4 { strokeLine(c, q[i].x, q[i].y, q[(i + 1) % 4].x, q[(i + 1) % 4].y, 1, Int32(bitPattern: 0x88FFFFFF)) }
        c.restoreGState()

        if pp.showMesh && pp.on && !pp.pins.isEmpty {
            let n = PuppetMath.segs[pp.density]
            let g = PuppetMath.gridPositions(l, pp, Editor.time)
            var pts = [CGPoint]()
            pts.reserveCapacity((n + 1) * (n + 1))
            for i in 0..<((n + 1) * (n + 1)) { pts.append(scr(g[2 * i], g[2 * i + 1])) }
            c.setStrokeColor(argbToUIColor(Int32(bitPattern: (UInt32(bitPattern: acc) & 0x00FFFFFF) | 0xCC000000)).cgColor)
            c.setLineWidth(1)
            c.beginPath()
            for j in 0...n {
                c.move(to: pts[j * (n + 1)])
                for i in 1...n { c.addLine(to: pts[j * (n + 1) + i]) }
            }
            for i in 0...n {
                c.move(to: pts[i])
                for j in 1...n { c.addLine(to: pts[j * (n + 1) + i]) }
            }
            c.strokePath()
        }

        let white = Int32(bitPattern: 0xFFFFFFFF)
        for (i, pin) in pp.pins.enumerated() {
            let pos = PuppetMath.pinPos(l, pp, pin, Editor.time, qs)
            let s = scr(pos.0, pos.1)
            if PuppetEdit.sel.contains(pin.id) {
                fillCircle(c, s.x, s.y, 16, Int32(bitPattern: (UInt32(bitPattern: acc) & 0x00FFFFFF) | 0x66000000))
                fillCircle(c, s.x, s.y, 10, white)
                fillCircle(c, s.x, s.y, 6, acc)
            } else {
                fillCircle(c, s.x, s.y, 9, white)
                fillCircle(c, s.x, s.y, 5, C.BG)
            }
            drawText("\(i + 1)", s.x, s.y - 20, color: white, size: 11, bold: true, align: .center)
        }
    }

    private func puppetBegan(_ l: Layer, _ pp: Puppet, _ p: CGPoint) {
        pupLast = p; pupMoved = false; pupDrag = false
        var hit: PuppetPin? = nil
        var best: CGFloat = 22
        let m = Xf.matrix(l, Editor.time)
        let qs = Xf.quadSize(l)
        for q in pp.pins {
            let pos = PuppetMath.pinPos(l, pp, q, Editor.time, qs)
            let w = Xf.apply(m, pos.0 * qs.0 / 2, pos.1 * qs.1 / 2)
            let d = distance(toScreen(w.0, w.1), p)
            if d < best { best = d; hit = q }
        }
        switch PuppetEdit.mode {
        case 2:   // multi: tap toggles, drag moves everything selected
            if let h = hit {
                if let i = PuppetEdit.sel.firstIndex(of: h.id) { PuppetEdit.sel.remove(at: i) } else { PuppetEdit.sel.append(h.id) }
                pupDrag = PuppetEdit.sel.contains(h.id)
                PuppetEdit.onChange?()
            }
        case 1:   // select
            if let h = hit {
                if !PuppetEdit.sel.contains(h.id) { PuppetEdit.sel = [h.id]; PuppetEdit.onChange?() }
                pupDrag = true
            } else if !PuppetEdit.sel.isEmpty {
                PuppetEdit.sel = []; PuppetEdit.onChange?()
            }
        default:  // add
            if let h = hit {
                if !PuppetEdit.sel.contains(h.id) { PuppetEdit.sel = [h.id]; PuppetEdit.onChange?() }
                pupDrag = true
            } else if let a = screenToQuad(l, p), abs(a.0) <= 1.3, abs(a.1) <= 1.3 {
                editHost?.beginEdit()
                let d = PuppetMath.disp(PuppetMath.activePins(l, pp, Editor.time), pp.stiffness, a.0, a.1)
                // rest = where the point was before the current warp, so the new pin sits exactly under the finger
                let q = PuppetPin(pp.nextId, a.0 - d.0, a.1 - d.1)
                pp.nextId += 1
                pp.pins.append(q)
                l.track("pp\(q.id)x").base = d.0
                l.track("pp\(q.id)y").base = d.1
                PuppetEdit.sel = [q.id]
                PuppetEdit.onChange?()
            }
        }
    }

    private func puppetMoved(_ touches: Set<UITouch>) {
        guard let t = touches.first, let l = editHost?.selectedLayer(), l.puppet != nil else { return }
        let p = t.location(in: self)
        guard let a0 = screenToQuad(l, pupLast), let a1 = screenToQuad(l, p) else { return }
        if !pupMoved { editHost?.beginEdit(); pupMoved = true }
        let k: Float = PuppetEdit.fine ? 0.25 : 1
        let dx = (a1.0 - a0.0) * k, dy = (a1.1 - a0.1) * k
        let ak = editHost?.autoKey() ?? false
        let lt = Editor.time
        for id in PuppetEdit.sel {
            let tx = l.track("pp\(id)x"), ty = l.track("pp\(id)y")
            tx.set(lt, tx.eval(lt) + dx, ak)
            ty.set(lt, ty.eval(lt) + dy, ak)
        }
        pupLast = p
        editHost?.onEdited()
    }

    private func distance(_ a: CGPoint, _ b: CGPoint) -> CGFloat {
        hypot(a.x - b.x, a.y - b.y)
    }
}
