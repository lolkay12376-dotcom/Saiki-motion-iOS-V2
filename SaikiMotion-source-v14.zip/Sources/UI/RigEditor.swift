// RigEditor.swift — "Cubism Editor": live 2D rig editor for a rig group (UI).
//
// Tabs: Params · Layers (folders + parenting) · Folder (mesh deformer + paint brush
// for every layer in a folder) · Mesh (per-layer points, brush, add/delete) · Rotate.
// Keying: pick a parameter value (slider / key bar), then drag or paint — the result is
// stored as a keyform at that value. Drags are previewed live (RigCanvas.live) and committed
// on finger-up, so the preview is never wiped by a redraw.

import UIKit

// MARK: - key bar (shows keyforms of the active parameter, tap/scrub to jump)

final class KeyBar: UIView {
    var lo: Float = 0, hi: Float = 1, value: Float = 0
    var keys: [Float] = []
    var onPick: ((Float) -> Void)?

    override init(frame: CGRect) { super.init(frame: frame); backgroundColor = .clear; isOpaque = false }
    required init?(coder: NSCoder) { fatalError() }

    private func x(_ v: Float) -> CGFloat {
        let w = bounds.width - 24
        return 12 + w * CGFloat((v - lo) / max(hi - lo, 0.0001))
    }
    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let y = bounds.midY - 4
        c.setStrokeColor(argbToUIColor(C.CARD2).cgColor); c.setLineWidth(4); c.setLineCap(.round)
        c.move(to: CGPoint(x: 12, y: y)); c.addLine(to: CGPoint(x: bounds.width - 12, y: y)); c.strokePath()
        for k in keys {
            let cx = x(k), on = abs(k - value) < 0.002
            c.setFillColor(argbToUIColor(on ? C.TEXT : C.GREEN).cgColor)
            c.move(to: CGPoint(x: cx, y: y - 9)); c.addLine(to: CGPoint(x: cx + 8, y: y))
            c.addLine(to: CGPoint(x: cx, y: y + 9)); c.addLine(to: CGPoint(x: cx - 8, y: y)); c.fillPath()
        }
        let vx = x(min(hi, max(lo, value)))
        c.setStrokeColor(UIColor.white.cgColor); c.setLineWidth(2)
        c.move(to: CGPoint(x: vx, y: y - 13)); c.addLine(to: CGPoint(x: vx, y: y + 13)); c.strokePath()
        let a: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 11), .foregroundColor: argbToUIColor(C.DIM)]
        String(format: "%g", lo).draw(at: CGPoint(x: 8, y: bounds.height - 16), withAttributes: a)
        let h = String(format: "%g", hi) as NSString
        h.draw(at: CGPoint(x: bounds.width - 8 - h.size(withAttributes: a).width, y: bounds.height - 16), withAttributes: a)
    }
    private func pick(_ t: UITouch) {
        let px = t.location(in: self).x
        var v = lo + Float((px - 12) / max(bounds.width - 24, 1)) * (hi - lo)
        v = min(hi, max(lo, v))
        if let k = keys.min(by: { abs(x($0) - px) < abs(x($1) - px) }), abs(x(k) - px) < 18 { v = k }
        value = v; setNeedsDisplay(); onPick?(v)
    }
    override func touchesBegan(_ t: Set<UITouch>, with e: UIEvent?) { if let t = t.first { pick(t) } }
    override func touchesMoved(_ t: Set<UITouch>, with e: UIEvent?) { if let t = t.first { pick(t) } }
}

// MARK: - canvas

final class RigCanvas: UIView {
    var group: Layer!
    var selId = -1
    var mode = 0                                  // 0 params, 1 layers, 2 folder, 3 mesh, 4 rotate
    var tool = 0                                  // mesh tab: 0 move, 1 paint, 2 add, 3 delete
    var targets: [Int] = []                       // layers the pins / brush act on
    var brushR: Float = 0.25                      // world units
    var brushK: Float = 1
    var onSelect: ((Int) -> Void)?
    var onBeginEdit: (() -> Void)?
    var onCommit: (([Int: [String: Float]], [Int: [String: Float]]) -> Void)?   // live, start
    var onAdd: ((Layer, Float, Float) -> Void)?
    var onDel: ((Layer, PuppetPin) -> Void)?
    var onPivot: ((Layer, Float, Float) -> Void)?

    private var zoom: CGFloat = 1
    private var pan = CGPoint.zero
    private var dragPin: (Layer, PuppetPin)?
    private var dragPivot = false
    private var brushing = false
    private var brushPt: CGPoint?
    private var lastW = (Float(0), Float(0))
    private var live: [Int: [String: Float]] = [:]
    private var start: [Int: [String: Float]] = [:]
    private static var imgCache: [String: CGImage] = [:]

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = argbToUIColor(C.BG)
        contentMode = .redraw
        clipsToBounds = true
        isMultipleTouchEnabled = true
        let pi = UIPinchGestureRecognizer(target: self, action: #selector(pinch(_:)))
        let pa = UIPanGestureRecognizer(target: self, action: #selector(panned(_:)))
        pa.minimumNumberOfTouches = 2
        addGestureRecognizer(pi); addGestureRecognizer(pa)
    }
    required init?(coder: NSCoder) { fatalError() }

    @objc private func pinch(_ g: UIPinchGestureRecognizer) {
        zoom = min(6, max(0.3, zoom * g.scale)); g.scale = 1; setNeedsDisplay()
    }
    @objc private func panned(_ g: UIPanGestureRecognizer) {
        let t = g.translation(in: self); pan.x += t.x; pan.y += t.y
        g.setTranslation(.zero, in: self); setNeedsDisplay()
    }

    // MARK: geometry
    private var members: [Layer] {
        guard let r = group?.rig else { return [] }
        return Editor.scene.layers.filter { r.members.contains($0.id) }
    }
    private func lay(_ id: Int) -> Layer? { Editor.scene.layers.first { $0.id == id } }
    private var pinLayers: [Layer] {
        guard mode == 2 || mode == 3 else { return [] }
        return targets.compactMap { lay($0) }.filter { $0.puppet?.pins.isEmpty == false }
    }
    private var ar: CGFloat { CGFloat(Editor.project.w) / CGFloat(max(Editor.project.h, 1)) }
    private var sc: CGFloat { min(bounds.height / 2, bounds.width / (2 * ar)) * 0.92 * zoom }
    private var cx: CGFloat { bounds.midX + pan.x }
    private var cy: CGFloat { bounds.midY + pan.y }
    private func scr(_ x: Float, _ y: Float) -> CGPoint { CGPoint(x: cx + CGFloat(x) * sc, y: cy - CGFloat(y) * sc) }
    private func world(_ p: CGPoint) -> (Float, Float) { (Float((p.x - cx) / sc), Float(-(p.y - cy) / sc)) }
    private func toScr(_ m: [Float], _ x: Float, _ y: Float) -> CGPoint { let w = Xf.apply(m, x, y); return scr(w.0, w.1) }
    private func local(_ l: Layer, _ p: CGPoint) -> (Float, Float)? {
        guard let inv = Xf.invert(Xf.matrix(l, Editor.time)) else { return nil }
        let w = world(p); return Xf.apply(inv, w.0, w.1)
    }
    private func cg(_ l: Layer) -> CGImage? {
        guard l.type == .IMAGE, let path = l.imagePath else { return nil }
        if let c = Self.imgCache[path] { return c }
        guard let ui = UIImage(contentsOfFile: path) else { return nil }
        let mx: CGFloat = 640, k = min(1, mx / max(ui.size.width, ui.size.height))
        let sz = CGSize(width: max(1, ui.size.width * k), height: max(1, ui.size.height * k))
        let f = UIGraphicsImageRendererFormat(); f.scale = 1
        let out = UIGraphicsImageRenderer(size: sz, format: f).image { _ in ui.draw(in: CGRect(origin: .zero, size: sz)) }
        if let c = out.cgImage { Self.imgCache[path] = c; return c }
        return nil
    }
    private func setLive(_ l: Layer, _ key: String, _ v: Float) {
        if start[l.id]?[key] == nil { start[l.id, default: [:]][key] = l.rigOff[key] ?? 0 }
        live[l.id, default: [:]][key] = v
    }
    private func curOff(_ l: Layer, _ key: String) -> Float { live[l.id]?[key] ?? (l.rigOff[key] ?? 0) }

    // MARK: draw
    override func draw(_ rect: CGRect) {
        guard let ctx = UIGraphicsGetCurrentContext(), group?.rig != nil else { return }
        Rig.apply(Editor.scene.layers, Editor.time)
        for (id, d) in live { if let l = lay(id) { for (k, v) in d { l.rigOff[k] = v } } }   // live drag preview
        let t = Editor.time
        let a = Float(ar)
        let tl = scr(-a, 1), br = scr(a, -1)
        ctx.setFillColor(argbToUIColor(C.CARD).cgColor)
        ctx.fill(CGRect(x: tl.x, y: tl.y, width: br.x - tl.x, height: br.y - tl.y))
        for l in members where l.visible { drawLayer(ctx, l, t) }

        // selection outline(s)
        ctx.setStrokeColor(argbToUIColor(C.GREEN).cgColor); ctx.setLineWidth(1.5)
        let outlined: [Layer] = mode == 2 ? targets.compactMap { lay($0) } : members.filter { $0.id == selId }
        for s in outlined {
            let m = Xf.matrix(s, t); let (qw, qh) = Xf.quadSize(s)
            let q = [(-qw / 2, -qh / 2), (qw / 2, -qh / 2), (qw / 2, qh / 2), (-qw / 2, qh / 2)].map { toScr(m, $0.0, $0.1) }
            ctx.addLines(between: q + [q[0]]); ctx.strokePath()
        }
        // mesh overlay + points
        for s in pinLayers {
            guard let pp = s.puppet else { continue }
            let m = Xf.matrix(s, t); let (qw, qh) = Xf.quadSize(s)
            if pp.showMesh && pp.on {
                let n = PuppetMath.segs[min(pp.density, PuppetMath.segs.count - 1)]
                let g = PuppetMath.gridPositions(s, pp, t)
                let step = max(1, n / 14)
                func pt(_ i: Int, _ j: Int) -> CGPoint {
                    let k = (j * (n + 1) + i) * 2
                    return toScr(m, g[k] * qw / 2, g[k + 1] * qh / 2)
                }
                ctx.setStrokeColor(UIColor.cyan.withAlphaComponent(0.55).cgColor); ctx.setLineWidth(0.8)
                var j = 0
                while j <= n { ctx.move(to: pt(0, j)); for i in 1...n { ctx.addLine(to: pt(i, j)) }; j += step }
                var i = 0
                while i <= n { ctx.move(to: pt(i, 0)); for j2 in 1...n { ctx.addLine(to: pt(i, j2)) }; i += step }
                ctx.strokePath()
            }
            let r: CGFloat = (mode == 3 && tool == 1) || mode == 2 ? 4 : 7
            for pin in pp.pins {
                let o = pinOffset(s, pin, t)
                let c = toScr(m, (pin.rx + o.0) * qw / 2, (pin.ry + o.1) * qh / 2)
                ctx.setFillColor(argbToUIColor(pin === dragPin?.1 ? C.TEXT : C.GREEN).cgColor)
                ctx.fillEllipse(in: CGRect(x: c.x - r, y: c.y - r, width: r * 2, height: r * 2))
            }
        }
        if mode == 4, let s = members.first(where: { $0.id == selId }) {
            let c = pivotScreen(s)
            ctx.setStrokeColor(UIColor.cyan.cgColor); ctx.setLineWidth(2)
            ctx.strokeEllipse(in: CGRect(x: c.x - 11, y: c.y - 11, width: 22, height: 22))
            ctx.move(to: CGPoint(x: c.x - 16, y: c.y)); ctx.addLine(to: CGPoint(x: c.x + 16, y: c.y))
            ctx.move(to: CGPoint(x: c.x, y: c.y - 16)); ctx.addLine(to: CGPoint(x: c.x, y: c.y + 16))
            ctx.strokePath()
        }
        if brushing, let b = brushPt {
            let r = CGFloat(brushR) * sc
            ctx.setStrokeColor(UIColor.white.withAlphaComponent(0.85).cgColor); ctx.setLineWidth(1.5)
            ctx.strokeEllipse(in: CGRect(x: b.x - r, y: b.y - r, width: r * 2, height: r * 2))
        }
    }

    private func pinOffset(_ l: Layer, _ pin: PuppetPin, _ t: Float) -> (Float, Float) {
        ((l.props["pp\(pin.id)x"]?.eval(t) ?? 0) + (l.rigOff["pp\(pin.id)x"] ?? 0),
         (l.props["pp\(pin.id)y"]?.eval(t) ?? 0) + (l.rigOff["pp\(pin.id)y"] ?? 0))
    }
    private func pivotScreen(_ l: Layer) -> CGPoint {
        let (qw, qh) = Xf.quadSize(l)
        let ax = l.p("anchorX", Editor.time), ay = l.p("anchorY", Editor.time)
        return toScr(Xf.matrix(l, Editor.time), (ax - 50) / 100 * qw, -(ay - 50) / 100 * qh)
    }

    private func drawLayer(_ ctx: CGContext, _ l: Layer, _ t: Float) {
        let m = Xf.matrix(l, t); let (qw, qh) = Xf.quadSize(l)
        ctx.saveGState()
        ctx.translateBy(x: cx, y: cy); ctx.scaleBy(x: sc, y: -sc)
        ctx.concatenate(CGAffineTransform(a: CGFloat(m[0]), b: CGFloat(m[1]), c: CGFloat(m[2]),
                                          d: CGFloat(m[3]), tx: CGFloat(m[4]), ty: CGFloat(m[5])))
        ctx.setAlpha(CGFloat(max(0, min(1, l.p("opacity", t)))))
        let hw = CGFloat(qw) / 2, hh = CGFloat(qh) / 2
        if let img = cg(l) {
            if let mesh = PuppetMath.mesh(l, t) {
                ctx.setShouldAntialias(false)          // no seams between triangles
                let W = CGFloat(img.width), H = CGFloat(img.height)
                var i = 0
                while i + 2 < mesh.idx.count {
                    let ids = [Int(mesh.idx[i]), Int(mesh.idx[i + 1]), Int(mesh.idx[i + 2])]; i += 3
                    let d = ids.map { CGPoint(x: CGFloat(mesh.pos[2 * $0]) * hw, y: CGFloat(mesh.pos[2 * $0 + 1]) * hh) }
                    let s = ids.map { CGPoint(x: CGFloat(mesh.uv[2 * $0]) * W, y: CGFloat(mesh.uv[2 * $0 + 1]) * H) }
                    let e1 = CGPoint(x: s[1].x - s[0].x, y: s[1].y - s[0].y), e2 = CGPoint(x: s[2].x - s[0].x, y: s[2].y - s[0].y)
                    let f1 = CGPoint(x: d[1].x - d[0].x, y: d[1].y - d[0].y), f2 = CGPoint(x: d[2].x - d[0].x, y: d[2].y - d[0].y)
                    let det = e1.x * e2.y - e1.y * e2.x
                    if abs(det) < 1e-6 { continue }
                    let a = (f1.x * e2.y - f2.x * e1.y) / det, c = (f2.x * e1.x - f1.x * e2.x) / det
                    let b = (f1.y * e2.y - f2.y * e1.y) / det, dd = (f2.y * e1.x - f1.y * e2.x) / det
                    let tx = d[0].x - (a * s[0].x + c * s[0].y), ty = d[0].y - (b * s[0].x + dd * s[0].y)
                    ctx.saveGState()
                    ctx.move(to: d[0]); ctx.addLine(to: d[1]); ctx.addLine(to: d[2]); ctx.closePath(); ctx.clip()
                    ctx.concatenate(CGAffineTransform(a: a, b: b, c: c, d: dd, tx: tx, ty: ty))
                    ctx.draw(img, in: CGRect(x: 0, y: 0, width: W, height: H))
                    ctx.restoreGState()
                }
                ctx.setShouldAntialias(true)
            } else {
                ctx.draw(img, in: CGRect(x: -hw, y: -hh, width: hw * 2, height: hh * 2))
            }
        } else {
            ctx.setFillColor(argbToUIColor(C.CARD2).cgColor)
            ctx.fill(CGRect(x: -hw, y: -hh, width: hw * 2, height: hh * 2))
        }
        ctx.restoreGState()
    }

    // MARK: touch
    private func nearestPin(_ p: CGPoint) -> (Layer, PuppetPin)? {
        var best: (Layer, PuppetPin, CGFloat)? = nil
        for s in pinLayers {
            guard let pp = s.puppet else { continue }
            let m = Xf.matrix(s, Editor.time); let (qw, qh) = Xf.quadSize(s)
            for pin in pp.pins {
                let o = pinOffset(s, pin, Editor.time)
                let c = toScr(m, (pin.rx + o.0) * qw / 2, (pin.ry + o.1) * qh / 2)
                let d = hypot(c.x - p.x, c.y - p.y)
                if d < 30 && d < (best?.2 ?? .infinity) { best = (s, pin, d) }
            }
        }
        return best.map { ($0.0, $0.1) }
    }

    private func brush(_ from: (Float, Float), _ to: (Float, Float)) {
        let dx = to.0 - from.0, dy = to.1 - from.1
        let t = Editor.time
        for l in pinLayers {
            guard let pp = l.puppet, let inv = Xf.invert(Xf.matrix(l, t)) else { continue }
            let m = Xf.matrix(l, t); let (qw, qh) = Xf.quadSize(l)
            let o0 = Xf.apply(inv, 0, 0), o1 = Xf.apply(inv, dx, dy)
            let lx = o1.0 - o0.0, ly = o1.1 - o0.1
            for pin in pp.pins {
                let o = pinOffset(l, pin, t)
                let w = Xf.apply(m, (pin.rx + o.0) * qw / 2, (pin.ry + o.1) * qh / 2)
                let d = hypot(w.0 - from.0, w.1 - from.1)
                if d >= brushR { continue }
                let f = (1 - d / brushR); let k = f * f * brushK
                let kx = "pp\(pin.id)x", ky = "pp\(pin.id)y"
                setLive(l, kx, curOff(l, kx) + lx / (qw / 2) * k)
                setLive(l, ky, curOff(l, ky) + ly / (qh / 2) * k)
            }
        }
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard touches.count == 1, let tc = touches.first else { return }
        let p = tc.location(in: self)
        let sel = members.first { $0.id == selId }
        let paint = mode == 2 || (mode == 3 && tool == 1)
        if paint {
            guard !pinLayers.isEmpty else { return }
            brushing = true; brushPt = p; lastW = world(p); onBeginEdit?(); setNeedsDisplay(); return
        }
        if mode == 3 {
            if tool == 2, let s = sel, let q = local(s, p) {
                let (qw, qh) = Xf.quadSize(s)
                let rx = q.0 / (qw / 2), ry = q.1 / (qh / 2)
                if abs(rx) <= 1, abs(ry) <= 1 { onAdd?(s, rx, ry) }
                return
            }
            if tool == 3 { if let b = nearestPin(p) { onDel?(b.0, b.1) }; return }
            if let b = nearestPin(p) { dragPin = b; onBeginEdit?(); setNeedsDisplay(); return }
        }
        if mode == 4, let s = sel, hypot(pivotScreen(s).x - p.x, pivotScreen(s).y - p.y) < 30 {
            dragPivot = true; onBeginEdit?(); return
        }
        for l in members.reversed() where l.visible {
            let (qw, qh) = Xf.quadSize(l)
            if let q = local(l, p), abs(q.0) <= qw / 2, abs(q.1) <= qh / 2 { onSelect?(l.id); return }
        }
        onSelect?(-1)
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard touches.count == 1, let tc = touches.first else { return }
        let p = tc.location(in: self)
        if brushing {
            let w = world(p); brush(lastW, w); lastW = w; brushPt = p; setNeedsDisplay(); return
        }
        if let (s, pin) = dragPin, let q = local(s, p) {
            let (qw, qh) = Xf.quadSize(s)
            let t = Editor.time
            let bx = s.props["pp\(pin.id)x"]?.eval(t) ?? 0, by = s.props["pp\(pin.id)y"]?.eval(t) ?? 0
            setLive(s, "pp\(pin.id)x", q.0 / (qw / 2) - pin.rx - bx)
            setLive(s, "pp\(pin.id)y", q.1 / (qh / 2) - pin.ry - by)
        } else if dragPivot, let s = members.first(where: { $0.id == selId }), let q = local(s, p) {
            let (qw, qh) = Xf.quadSize(s)
            onPivot?(s, min(100, max(0, q.0 / qw * 100 + 50)), min(100, max(0, 50 - q.1 / qh * 100)))
        }
        setNeedsDisplay()
    }

    private func finish(commit: Bool) {
        let l = live, s = start
        live = [:]; start = [:]; dragPin = nil; dragPivot = false; brushing = false; brushPt = nil
        if commit && !l.isEmpty { onCommit?(l, s) }
        setNeedsDisplay()
    }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) { finish(commit: true) }
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) { finish(commit: false) }
}

// MARK: - controller

final class RigEditorViewController: UIViewController {
    private let group: Layer
    private weak var host: EditorViewController?
    private var curTab = 0                        // 0 params, 1 layers, 2 folder, 3 mesh, 4 rotate
    private var selId = -1
    private var selFolder = -1
    private var activeParam = -1
    private var tool = 0
    private var gridN = 4
    private var brushR: Float = 0.25
    private var brushK: Float = 1
    private let canvas = RigCanvas()
    private let stack = UIStackView()
    private let scroll = UIScrollView()
    private var tabButtons: [UIButton] = []
    private var paramSlider: RulerSlider?
    private var keyBar: KeyBar?
    private var rig: Rig { group.rig! }

    init(group: Layer, host: EditorViewController) {
        self.group = group; self.host = host
        super.init(nibName: nil, bundle: nil)
        modalPresentationStyle = .fullScreen
        activeParam = group.rig?.params.first?.id ?? -1
        selFolder = group.rig?.folders.first?.id ?? -1
    }
    required init?(coder: NSCoder) { fatalError() }

    override var prefersStatusBarHidden: Bool { false }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = argbToUIColor(C.BG)
        let done = btn("Done", C.GREEN, C.BG) { [weak self] in self?.close() }
        let title = UILabel(); title.text = "Cubism Editor — \(group.name)"
        title.textColor = argbToUIColor(C.TEXT); title.font = .systemFont(ofSize: 15, weight: .bold)
        title.adjustsFontSizeToFitWidth = true; title.minimumScaleFactor = 0.7
        let top = UIStackView(arrangedSubviews: [title, UIView(), done]); top.alignment = .center; top.spacing = 8
        let names = ["Layers", "Folder", "Mesh", "Transform"]
        let tabs = UIStackView(); tabs.distribution = .fillEqually; tabs.spacing = 5
        for (i, n) in names.enumerated() {
            let b = btn(n) { [weak self] in self?.curTab = i; self?.reload() }
            b.titleLabel?.font = .systemFont(ofSize: 13, weight: .semibold)
            b.titleLabel?.adjustsFontSizeToFitWidth = true; b.titleLabel?.minimumScaleFactor = 0.7
            b.contentEdgeInsets = UIEdgeInsets(top: 8, left: 4, bottom: 8, right: 4)
            tabButtons.append(b); tabs.addArrangedSubview(b)
        }
        canvas.group = group
        canvas.onSelect = { [weak self] id in
            guard let self = self else { return }
            self.selId = id
            if id >= 0, let f = self.rig.folderOf[id] { self.selFolder = f }
            self.reload()
        }
        canvas.onBeginEdit = { [weak self] in self?.host?.pushUndo() }
        canvas.onCommit = { [weak self] live, start in self?.commit(live, start) }
        canvas.onAdd = { [weak self] l, rx, ry in self?.addPin(l, rx, ry) }
        canvas.onDel = { [weak self] l, pin in self?.delPin(l, pin) }
        canvas.onPivot = { [weak self] l, ax, ay in self?.host?.setAnchorKeepVisual(l, ax, ay); self?.host?.render() }
        stack.axis = .vertical; stack.spacing = 10
        scroll.addSubview(stack); scroll.alwaysBounceVertical = true
        strip.axis = .vertical; strip.spacing = 4
        for v in [top, tabs, canvas, strip, scroll] as [UIView] { v.translatesAutoresizingMaskIntoConstraints = false; view.addSubview(v) }
        stack.translatesAutoresizingMaskIntoConstraints = false
        let g = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            top.topAnchor.constraint(equalTo: g.topAnchor, constant: 6),
            top.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 12),
            top.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -12),
            canvas.topAnchor.constraint(equalTo: top.bottomAnchor, constant: 8),
            canvas.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            canvas.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            canvas.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.30),
            strip.topAnchor.constraint(equalTo: canvas.bottomAnchor, constant: 6),
            strip.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 12),
            strip.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -12),
            tabs.topAnchor.constraint(equalTo: strip.bottomAnchor, constant: 8),
            tabs.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 12),
            tabs.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -12),
            scroll.topAnchor.constraint(equalTo: tabs.bottomAnchor, constant: 8),
            scroll.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scroll.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scroll.bottomAnchor.constraint(equalTo: g.bottomAnchor),
            stack.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor),
            stack.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor, constant: -30),
            stack.leadingAnchor.constraint(equalTo: scroll.frameLayoutGuide.leadingAnchor, constant: 12),
            stack.trailingAnchor.constraint(equalTo: scroll.frameLayoutGuide.trailingAnchor, constant: -12),
            stack.widthAnchor.constraint(equalTo: scroll.frameLayoutGuide.widthAnchor, constant: -24)])
        reload()
    }

    private func close() {
        dismiss(animated: true) { [weak host] in host?.refreshToolbar(); host?.refreshPanel(); host?.render() }
    }

    // MARK: helpers
    private func btn(_ title: String, _ fill: Int32 = C.CARD2, _ tc: Int32 = C.TEXT, _ act: @escaping () -> Void) -> UIButton {
        let b = UIButton(type: .system)
        b.setTitle(title, for: .normal); b.setTitleColor(argbToUIColor(tc), for: .normal)
        b.titleLabel?.font = .systemFont(ofSize: 14, weight: .semibold)
        b.backgroundColor = argbToUIColor(fill); b.layer.cornerRadius = 10
        b.contentEdgeInsets = UIEdgeInsets(top: 8, left: 12, bottom: 8, right: 12)
        b.addAction(UIAction { _ in act() }, for: .touchUpInside)
        b.heightAnchor.constraint(greaterThanOrEqualToConstant: 38).isActive = true
        return b
    }
    private func iconBtn(_ sym: String, _ act: @escaping () -> Void) -> UIButton {
        let b = UIButton(type: .system)
        b.setImage(UIImage(systemName: sym), for: .normal); b.tintColor = argbToUIColor(C.TEXT)
        b.backgroundColor = argbToUIColor(C.CARD2); b.layer.cornerRadius = 10
        b.addAction(UIAction { _ in act() }, for: .touchUpInside)
        b.widthAnchor.constraint(equalToConstant: 40).isActive = true
        b.heightAnchor.constraint(equalToConstant: 38).isActive = true
        return b
    }
    private func lbl(_ s: String, _ size: CGFloat = 14, _ color: Int32 = C.TEXT, bold: Bool = false) -> UILabel {
        let l = UILabel(); l.text = s; l.numberOfLines = 0; l.textColor = argbToUIColor(color)
        l.font = .systemFont(ofSize: size, weight: bold ? .bold : .regular); return l
    }
    private func slider(_ name: String, _ lo: Float, _ hi: Float, _ v: Float, _ dec: Int = 2,
                        _ change: @escaping (Float) -> Void) -> RulerSlider {
        let s = RulerSlider(frame: .zero)
        s.label = name; s.lo = lo; s.hi = hi; s.dec = dec; s.value = v; s.canKey = false
        s.onBegin = { [weak self] in self?.host?.pushUndo() }
        s.onChange = change
        s.heightAnchor.constraint(equalToConstant: 60).isActive = true
        return s
    }
    private func chips(_ names: [String], _ sel: Int, _ act: @escaping (Int) -> Void) -> UIStackView {
        let s = UIStackView(); s.distribution = .fillEqually; s.spacing = 6
        for (i, n) in names.enumerated() {
            let b = btn(n, i == sel ? C.GREEN : C.CARD2, i == sel ? C.BG : C.TEXT) { act(i) }
            b.titleLabel?.adjustsFontSizeToFitWidth = true; b.titleLabel?.minimumScaleFactor = 0.7
            b.contentEdgeInsets = UIEdgeInsets(top: 8, left: 4, bottom: 8, right: 4)
            s.addArrangedSubview(b)
        }
        return s
    }
    private func toggleRow(_ title: String, _ on: Bool, _ change: @escaping (Bool) -> Void) -> UIView {
        let sw = UISwitch(); sw.isOn = on; sw.onTintColor = argbToUIColor(C.GREEN)
        sw.addAction(UIAction { [unowned sw] _ in change(sw.isOn) }, for: .valueChanged)
        let r = UIStackView(arrangedSubviews: [lbl(title, 14), UIView(), sw]); r.alignment = .center
        return r
    }
    private func ask(_ title: String, _ items: [String], _ pick: @escaping (Int) -> Void) {
        _ = Dlg(self).setTitle(title).setItems(items) { _, i in pick(i) }.show()
    }
    private func confirm(_ title: String, _ msg: String, _ ok: @escaping () -> Void) {
        _ = Dlg(self).setTitle(title).setMessage(msg)
            .setPositiveButton("Yes") { _, _ in ok() }.setNegativeButton("Cancel", nil).show()
    }
    private func textField(_ ph: String, _ text: String, _ num: Bool = false) -> UITextField {
        let f = UITextField(); f.placeholder = ph; f.text = text
        f.textColor = argbToUIColor(C.TEXT); f.backgroundColor = argbToUIColor(C.CARD2)
        f.layer.cornerRadius = 8; f.keyboardType = num ? .numbersAndPunctuation : .default
        f.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: 10)); f.leftViewMode = .always
        f.heightAnchor.constraint(equalToConstant: 40).isActive = true; return f
    }
    private func textDialog(_ title: String, _ initial: String, _ ok: @escaping (String) -> Void) {
        let f = textField("Name", initial)
        _ = Dlg(self).setTitle(title).setView(f)
            .setPositiveButton("OK") { _, _ in ok((f.text ?? "").isEmpty ? initial : f.text!) }
            .setNegativeButton("Cancel", nil).show()
    }
    private func fmt(_ v: Float) -> String { String(format: "%.2f", v) }
    private func card(_ views: [UIView]) -> UIView {
        let c = UIView(); c.backgroundColor = argbToUIColor(C.CARD); c.layer.cornerRadius = 12
        let s = UIStackView(arrangedSubviews: views); s.axis = .vertical; s.spacing = 6
        s.translatesAutoresizingMaskIntoConstraints = false; c.addSubview(s)
        NSLayoutConstraint.activate([s.topAnchor.constraint(equalTo: c.topAnchor, constant: 10),
            s.bottomAnchor.constraint(equalTo: c.bottomAnchor, constant: -10),
            s.leadingAnchor.constraint(equalTo: c.leadingAnchor, constant: 10),
            s.trailingAnchor.constraint(equalTo: c.trailingAnchor, constant: -10)])
        return c
    }
    private func members() -> [Layer] { Editor.scene.layers.filter { rig.members.contains($0.id) } }
    private func layer(_ id: Int) -> Layer? { Editor.scene.layers.first { $0.id == id } }
    private var sel: Layer? { rig.members.contains(selId) ? layer(selId) : nil }
    private var active: RigParam? { rig.param(activeParam) }
    private var folder: RigFolder? { rig.folders.first { $0.id == selFolder } }
    private func folderLayers(_ f: RigFolder) -> [Layer] { members().filter { rig.folderOf[$0.id] == f.id } }
    private func redraw() { canvas.setNeedsDisplay(); host?.render() }

    static let propList: [(String, String)] = [("Position X", "x"), ("Position Y", "y"),
                                               ("Rotate", "rotZ"), ("Scale", "scale"), ("Opacity", "opacity")]
    private func propName(_ k: String) -> String {
        if let p = Self.propList.first(where: { $0.1 == k }) { return p.0 }
        return k.hasPrefix("pp") ? "Mesh pin " + k.dropFirst(2) : k
    }
    private func propRange(_ k: String) -> (Float, Float) {
        switch k { case "rotZ": return (-180, 180); case "opacity", "scale": return (-1, 1); default: return (-2, 2) }
    }

    // MARK: panel
    private func reload() {
        for (i, b) in tabButtons.enumerated() {
            b.backgroundColor = argbToUIColor(i == curTab ? C.GREEN : C.CARD2)
            b.setTitleColor(argbToUIColor(i == curTab ? C.BG : C.TEXT), for: .normal)
        }
        canvas.mode = curTab + 1                  // canvas: 1 layers, 2 folder, 3 mesh, 4 transform
        canvas.selId = selId
        canvas.tool = tool; canvas.brushR = brushR; canvas.brushK = brushK
        switch curTab {
        case 1: canvas.targets = folder.map { folderLayers($0).filter { $0.puppet != nil }.map { $0.id } } ?? []
        case 2: canvas.targets = sel.map { [$0.id] } ?? []
        default: canvas.targets = []
        }
        rebuildStrip()
        reloadPanel()
        canvas.setNeedsDisplay()
    }

    private func reloadPanel() {
        let keepY = scroll.contentOffset.y
        for v in stack.arrangedSubviews { stack.removeArrangedSubview(v); v.removeFromSuperview() }
        switch curTab {
        case 0: buildLayers()
        case 1: buildFolder()
        case 2: buildMesh()
        default: buildTransform()
        }
        view.layoutIfNeeded()
        scroll.contentOffset.y = min(keepY, max(0, scroll.contentSize.height - scroll.bounds.height))
    }

    // ---- parameter strip (always visible, Live2D style: pick a pose, then edit anything)

    private let strip = UIStackView()
    private var keyBtn: UIButton?
    private var keyInfo: UILabel?
    private static let keyedProps = ["opacity", "x", "y", "rotZ", "scale"]

    /// Layers whose keys the strip shows / edits: folder layers, the selected layer, or everything.
    private func keyTargets() -> [Int] {
        if curTab == 1, let f = folder { return folderLayers(f).map { $0.id } }
        if let l = sel { return [l.id] }
        return members().map { $0.id }
    }

    private func keyValues(_ p: RigParam, _ ids: [Int]) -> [Float] {
        var out: [Float] = []
        for b in rig.bindings where b.paramId == p.id && ids.contains(b.layerId) {
            for k in b.keys where !out.contains(where: { abs($0 - k.0) < 1e-3 }) { out.append(k.0) }
        }
        return out.sorted()
    }

    private func rebuildStrip() {
        for v in strip.arrangedSubviews { strip.removeArrangedSubview(v); v.removeFromSuperview() }
        paramSlider = nil; keyBar = nil; keyBtn = nil; keyInfo = nil
        let pick = btn(active.map { "Parameter: \($0.name)  ▾" } ?? "＋ Add a parameter") { [weak self] in self?.paramMenu() }
        guard let p = active else {
            strip.addArrangedSubview(pick)
            strip.addArrangedSubview(lbl("Start here: add a parameter (Eye open/close, Mouth, Angle X…). Then pick a pose on it and edit — keys are created for you.", 12, C.DIM))
            return
        }
        let kbtn = btn("+ Key", C.GREEN, C.BG) { [weak self] in self?.toggleKey() }
        kbtn.widthAnchor.constraint(equalToConstant: 92).isActive = true
        keyBtn = kbtn
        let row = UIStackView(arrangedSubviews: [pick, kbtn]); row.spacing = 8
        strip.addArrangedSubview(row)
        let s = slider(p.name, p.lo, p.hi, rig.value(p, group, Editor.time)) { [weak self] v in
            guard let self = self else { return }
            self.group.track(p.key).set(Editor.time, v, false)
            self.refreshKeyState()
            if self.curTab == 3 { self.reloadPanel() }
            self.redraw()
        }
        paramSlider = s; strip.addArrangedSubview(s)
        let kb = KeyBar(frame: .zero)
        kb.lo = p.lo; kb.hi = p.hi
        kb.onPick = { [weak self] v in self?.setParam(p, v) }
        kb.heightAnchor.constraint(equalToConstant: 40).isActive = true
        keyBar = kb; strip.addArrangedSubview(kb)
        let info = lbl("", 12, C.DIM); keyInfo = info; strip.addArrangedSubview(info)
        refreshKeyState()
    }

    private func refreshKeyState() {
        guard let p = active else { return }
        let ids = keyTargets()
        let pv = rig.value(p, group, Editor.time)
        let keys = keyValues(p, ids)
        let on = keys.contains { abs($0 - pv) < 1e-3 }
        keyBar?.value = pv; keyBar?.keys = keys; keyBar?.setNeedsDisplay()
        keyBtn?.setTitle(on ? "− Key" : "+ Key", for: .normal)
        keyBtn?.setTitleColor(argbToUIColor(on ? C.TEXT : C.BG), for: .normal)
        keyBtn?.backgroundColor = argbToUIColor(on ? C.CARD2 : C.GREEN)
        let hint = (p.lo == 0 && p.hi == 1) ? "  (0 = closed, 1 = open)" : ""
        keyInfo?.text = (on ? "◇ Key selected at \(fmt(pv)) — edit below to change it." : "No key at \(fmt(pv)) — edit below or press + Key to create one.") + hint
    }

    private func setParam(_ p: RigParam, _ v: Float) {
        group.track(p.key).set(Editor.time, v, false)
        paramSlider?.value = v
        refreshKeyState()
        if curTab == 3 { reloadPanel() }
        redraw()
    }

    private func toggleKey() {
        guard let p = active else { return }
        let ids = keyTargets()
        let pv = rig.value(p, group, Editor.time)
        host?.pushUndo()
        if keyValues(p, ids).contains(where: { abs($0 - pv) < 1e-3 }) {
            for b in rig.bindings where b.paramId == p.id && ids.contains(b.layerId) {
                b.keys.removeAll { abs($0.0 - pv) < 1e-3 }
            }
            rig.bindings.removeAll { $0.keys.isEmpty }
        } else {
            for id in ids {
                var keys = Self.keyedProps
                if let pp = layer(id)?.puppet { for pin in pp.pins { keys.append("pp\(pin.id)x"); keys.append("pp\(pin.id)y") } }
                for k in keys { if let b = rig.binding(p, id, k, create: true) { b.setKey(pv, b.eval(pv)) } }
            }
        }
        reload(); redraw()
    }

    /// Canvas drag / brush finished: store the change as a keyform at the current parameter value.
    private func commit(_ live: [Int: [String: Float]], _ start: [Int: [String: Float]]) {
        guard let p = active else { host?.toast("Add a parameter first"); redraw(); return }
        let pv = rig.value(p, group, Editor.time)
        for (lid, d) in live {
            for (k, v) in d {
                let delta = v - (start[lid]?[k] ?? 0)
                if abs(delta) < 1e-5 { continue }
                guard let b = rig.binding(p, lid, k, create: true) else { continue }
                b.setKey(pv, b.eval(pv) + delta)
            }
        }
        reload(); redraw()
    }

    private func paramMenu() {
        let names = rig.params.map { $0.name }
        ask("Parameters", names + ["＋ New parameter", "Rename current", "Delete current"]) { [weak self] i in
            guard let self = self else { return }
            if i < names.count { self.activeParam = self.rig.params[i].id; self.reload(); return }
            if i == names.count { self.addParamPreset(); return }
            guard let p = self.active else { return }
            if i == names.count + 1 { self.textDialog("Rename parameter", p.name) { p.name = $0; self.reload() }; return }
            self.confirm("Delete \(p.name)?", "Its keys are removed too.") {
                self.host?.pushUndo()
                self.rig.params.removeAll { $0.id == p.id }
                self.rig.bindings.removeAll { $0.paramId == p.id }
                self.group.props[p.key] = nil
                self.activeParam = self.rig.params.first?.id ?? -1
                self.reload(); self.redraw()
            }
        }
    }

    private func addParamPreset() {
        let presets: [(String, Float, Float, Float)] = [
            ("Eye L open/close", 0, 1, 1), ("Eye R open/close", 0, 1, 1), ("Mouth open/close", 0, 1, 0),
            ("Angle X", -30, 30, 0), ("Angle Y", -30, 30, 0), ("Angle Z", -30, 30, 0), ("Breath", 0, 1, 0)]
        ask("New parameter", presets.map { $0.0 } + ["Custom…"]) { [weak self] i in
            guard let self = self else { return }
            if i >= presets.count { self.addParamDialog(); return }
            let q = presets[i]
            self.host?.pushUndo()
            self.activeParam = self.rig.addParam(q.0, q.1, q.2, q.3, on: self.group).id
            self.reload()
        }
    }

    private func addParamDialog() {
        let n = textField("Name", "Param \(rig.nextId)")
        let lo = textField("Min", "-30", true), hi = textField("Max", "30", true), df = textField("Default", "0", true)
        let sv = UIStackView(arrangedSubviews: [n, lo, hi, df]); sv.axis = .vertical; sv.spacing = 8
        _ = Dlg(self).setTitle("New parameter").setView(sv)
            .setPositiveButton("Add") { [weak self] _, _ in
                guard let self = self else { return }
                var a = Float(lo.text ?? "") ?? -30, b = Float(hi.text ?? "") ?? 30
                if a > b { swap(&a, &b) }
                if b - a < 0.001 { b = a + 1 }
                let d = min(b, max(a, Float(df.text ?? "") ?? 0))
                self.host?.pushUndo()
                let p = self.rig.addParam((n.text ?? "").isEmpty ? "Param" : n.text!, a, b, d, on: self.group)
                self.activeParam = p.id
                self.reload()
            }.setNegativeButton("Cancel", nil).show()
    }

    // ---- layers (folders + parenting)
    private func buildLayers() {
        stack.addArrangedSubview(lbl("Organise layers into folders. Tap a name to select. Bring layers in: main editor → tap image → To Rig.", 12, C.DIM))
        stack.addArrangedSubview(btn("+ New folder", C.GREEN, C.BG) { [weak self] in
            guard let self = self else { return }
            self.textDialog("New folder", "Folder \(self.rig.folders.count + 1)") { name in
                self.host?.pushUndo()
                let f = RigFolder(self.rig.nextId, name); self.rig.nextId += 1
                self.rig.folders.append(f); self.selFolder = f.id; self.reload()
            }
        })
        let ms = members()
        if ms.isEmpty { stack.addArrangedSubview(lbl("This rig group is empty.", 13, C.DIM)) }
        for f in rig.folders {
            let inside = folderLayers(f)
            let name = lbl("\(f.name)  (\(inside.count))", 15, f.id == selFolder ? C.GREEN : C.TEXT, bold: true)
            name.isUserInteractionEnabled = true; name.tag = f.id
            name.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(folderTap(_:))))
            let anyVisible = inside.contains { $0.visible }
            let head = UIStackView(arrangedSubviews: [
                iconBtn(f.open ? "chevron.down" : "chevron.right") { [weak self] in f.open.toggle(); self?.reload() },
                iconBtn("folder.fill") { [weak self] in self?.selFolder = f.id; self?.reload() },
                name, UIView(),
                iconBtn(anyVisible ? "eye" : "eye.slash") { [weak self] in
                    for l in inside { l.visible = !anyVisible }; self?.reload(); self?.redraw() },
                iconBtn("ellipsis") { [weak self] in self?.folderMenu(f) }])
            head.spacing = 6; head.alignment = .center
            var rows: [UIView] = [head]
            if f.open {
                if inside.isEmpty { rows.append(lbl("Empty — use Move on a layer to put it here.", 12, C.DIM)) }
                rows += layerRows(inside)
            }
            stack.addArrangedSubview(card(rows))
        }
        let root = ms.filter { l in rig.folders.first { $0.id == rig.folderOf[l.id] } == nil }
        if !root.isEmpty {
            var rows: [UIView] = []
            if !rig.folders.isEmpty { rows.append(lbl("No folder", 13, C.DIM, bold: true)) }
            rows += layerRows(root)
            stack.addArrangedSubview(card(rows))
        }
    }

    @objc private func folderTap(_ g: UITapGestureRecognizer) { selFolder = g.view?.tag ?? -1; reload() }
    @objc private func rowTap(_ g: UITapGestureRecognizer) { selId = g.view?.tag ?? -1; reload() }

    private func layerRows(_ list: [Layer]) -> [UIView] {
        let ids = Set(list.map { $0.id })
        var order: [(Layer, Int)] = []
        func walk(_ l: Layer, _ d: Int) { order.append((l, d)); for c in list where c.parentId == l.id { walk(c, d + 1) } }
        for l in list where !ids.contains(l.parentId) { walk(l, 0) }
        var out: [UIView] = []
        for (l, d) in order {
            let name = lbl(String(repeating: "   ", count: d) + (d > 0 ? "↳ " : "") + l.name, 14,
                           l.id == selId ? C.GREEN : C.TEXT, bold: l.id == selId)
            name.numberOfLines = 1; name.lineBreakMode = .byTruncatingTail
            name.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
            name.isUserInteractionEnabled = true; name.tag = l.id
            name.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(rowTap(_:))))
            let row = UIStackView(arrangedSubviews: [name, UIView(),
                iconBtn(l.visible ? "eye" : "eye.slash") { [weak self] in l.visible.toggle(); self?.reload(); self?.redraw() },
                btn("Move") { [weak self] in self?.moveDialog(l) },
                iconBtn("ellipsis") { [weak self] in self?.layerMenu(l) }])
            row.spacing = 6; row.alignment = .center
            out.append(row)
        }
        return out
    }

    private func moveDialog(_ l: Layer) {
        let fs = rig.folders
        ask("Move \(l.name) to", ["No folder"] + fs.map { "📁 " + $0.name }) { [weak self] i in
            guard let self = self else { return }
            self.host?.pushUndo()
            if i == 0 { self.rig.folderOf[l.id] = nil }
            else { self.rig.folderOf[l.id] = fs[i - 1].id; fs[i - 1].open = true; self.selFolder = fs[i - 1].id }
            self.reload()
        }
    }

    private func folderMenu(_ f: RigFolder) {
        ask(f.name, ["Rename", "Delete folder (keep layers)"]) { [weak self] i in
            guard let self = self else { return }
            if i == 0 { self.textDialog("Rename folder", f.name) { f.name = $0; self.reload() } }
            else {
                self.host?.pushUndo()
                self.rig.folderOf = self.rig.folderOf.filter { $0.value != f.id }
                self.rig.folders.removeAll { $0.id == f.id }
                if self.selFolder == f.id { self.selFolder = self.rig.folders.first?.id ?? -1 }
                self.reload()
            }
        }
    }

    private func layerMenu(_ l: Layer) {
        ask(l.name, ["Set parent…", "Remove from rig"]) { [weak self] i in
            guard let self = self else { return }
            if i == 0 { self.parentDialog(l, self.members()); return }
            self.host?.pushUndo(); self.rig.removeLayer(l.id)
            for c in self.members() where c.parentId == l.id { c.parentId = self.group.id }
            l.parentId = -1; if self.selId == l.id { self.selId = -1 }
            self.reload(); self.redraw()
        }
    }

    private func parentDialog(_ l: Layer, _ ms: [Layer]) {
        func isDesc(_ c: Layer) -> Bool {
            var cur: Layer? = c; var n = 0
            while let x = cur, n < 64 { if x.id == l.id { return true }; cur = layer(x.parentId); n += 1 }
            return false
        }
        let cands = ms.filter { !isDesc($0) }
        ask("Parent of \(l.name)", ["Rig group (root)"] + cands.map { $0.name }) { [weak self] i in
            guard let self = self else { return }
            self.host?.pushUndo()
            l.parentId = i == 0 ? self.group.id : cands[i - 1].id
            self.reload(); self.redraw()
        }
    }

    // ---- mesh building blocks

    private func hasKeys(_ l: Layer) -> Bool { rig.bindings.contains { $0.layerId == l.id && $0.key.hasPrefix("pp") } }

    private func buildGrid(_ l: Layer, _ n: Int) {
        let pu = l.puppet ?? Puppet()
        for pin in pu.pins { l.props["pp\(pin.id)x"] = nil; l.props["pp\(pin.id)y"] = nil }
        rig.bindings.removeAll { $0.layerId == l.id && $0.key.hasPrefix("pp") }
        pu.pins.removeAll(); pu.on = true
        let d = max(n - 1, 1)
        for j in 0..<n { for i in 0..<n {
            pu.pins.append(PuppetPin(pu.nextId, -1 + 2 * Float(i) / Float(d), -1 + 2 * Float(j) / Float(d))); pu.nextId += 1 } }
        l.puppet = pu
    }

    private func gridStepper(_ apply: @escaping (Int) -> Void) -> UIView {
        let r = UIStackView(arrangedSubviews: [lbl("Mesh points: \(gridN)×\(gridN)", 14, C.TEXT, bold: true), UIView(),
            iconBtn("minus") { [weak self] in guard let self = self else { return }; self.gridN = max(2, self.gridN - 1); apply(self.gridN) },
            iconBtn("plus") { [weak self] in guard let self = self else { return }; self.gridN = min(14, self.gridN + 1); apply(self.gridN) }])
        r.spacing = 6; r.alignment = .center
        return r
    }

    private func detailChips(_ pp: Puppet) -> UIView {
        let c = card([lbl("Smoothness (render detail)", 13, C.DIM),
            chips(["Low", "Medium", "High", "Ultra"], pp.density) { [weak self] i in
                self?.host?.pushUndo(); pp.density = i; self?.reload(); self?.redraw() }])
        return c
    }

    private func brushSection() {
        stack.addArrangedSubview(slider("Brush size", 0.05, 1, brushR, 2) { [weak self] v in self?.brushR = v; self?.canvas.brushR = v })
        stack.addArrangedSubview(slider("Brush strength", 0.2, 2, brushK, 1) { [weak self] v in self?.brushK = v; self?.canvas.brushK = v })
    }

    // ---- folder
    private func buildFolder() {
        guard !rig.folders.isEmpty else {
            stack.addArrangedSubview(lbl("No folders yet. Create one in the Layers tab and move layers into it, then deform the whole folder here.", 13, C.DIM))
            stack.addArrangedSubview(btn("Go to Layers", C.GREEN, C.BG) { [weak self] in self?.curTab = 0; self?.reload() })
            return
        }
        guard let f = folder else {
            stack.addArrangedSubview(btn("Pick a folder  ▾") { [weak self] in self?.pickFolder() }); return
        }
        stack.addArrangedSubview(btn("Folder: \(f.name)  ▾") { [weak self] in self?.pickFolder() })
        let imgs = folderLayers(f).filter { $0.type == .IMAGE }
        if imgs.isEmpty { stack.addArrangedSubview(lbl("No image layers in this folder. Use Move in the Layers tab.", 13, C.DIM)); return }
        let meshed = imgs.filter { $0.puppet?.pins.isEmpty == false }
        stack.addArrangedSubview(lbl("\(imgs.count) layer(s) · \(meshed.count) with mesh", 12, C.DIM))
        stack.addArrangedSubview(gridStepper { [weak self] _ in self?.reload() })
        stack.addArrangedSubview(btn(meshed.isEmpty ? "Create mesh deformer for folder" : "Rebuild folder meshes (\(gridN)×\(gridN))", C.GREEN, C.BG) { [weak self] in
            guard let self = self else { return }
            let go: () -> Void = {
                self.host?.pushUndo()
                for l in imgs { self.buildGrid(l, self.gridN) }
                self.reload(); self.redraw()
            }
            if imgs.contains(where: { self.hasKeys($0) }) { self.confirm("Rebuild meshes?", "This removes existing mesh keys in this folder.", go) } else { go() }
        })
        if meshed.isEmpty { return }
        if let pp = meshed.first?.puppet {
            stack.addArrangedSubview(toggleRow("Show mesh", pp.showMesh) { [weak self] v in
                for l in meshed { l.puppet?.showMesh = v }; self?.redraw() })
        }
        stack.addArrangedSubview(lbl("Paint on the canvas: points under the brush follow your finger on every layer in this folder, and are keyed at the current pose.", 12, C.DIM))
        brushSection()
        stack.addArrangedSubview(btn("Clear keys of this parameter (folder)", C.CARD2, C.DIM) { [weak self] in
            guard let self = self, let p = self.active else { return }
            self.host?.pushUndo()
            let ids = meshed.map { $0.id }
            self.rig.bindings.removeAll { $0.paramId == p.id && ids.contains($0.layerId) && $0.key.hasPrefix("pp") }
            self.reload(); self.redraw() })
    }

    private func pickFolder() {
        let fs = rig.folders
        ask("Folder", fs.map { $0.name }) { [weak self] i in self?.selFolder = fs[i].id; self?.reload() }
    }

    // ---- mesh
    private func buildMesh() {
        let imgs = members().filter { $0.type == .IMAGE }
        guard !imgs.isEmpty else { stack.addArrangedSubview(lbl("Import an image layer into this rig first.", 13, C.DIM)); return }
        guard let l = sel, l.type == .IMAGE else {
            stack.addArrangedSubview(lbl("Select an image layer: tap it in the canvas or pick it here.", 13, C.DIM))
            stack.addArrangedSubview(btn("Pick layer  ▾") { [weak self] in self?.pickLayer(imgs) })
            return
        }
        stack.addArrangedSubview(btn("Layer: \(l.name)  ▾") { [weak self] in self?.pickLayer(imgs) })
        stack.addArrangedSubview(gridStepper { [weak self] _ in self?.reload() })
        guard let pp = l.puppet, !pp.pins.isEmpty else {
            stack.addArrangedSubview(btn("Create mesh (\(gridN)×\(gridN) points)", C.GREEN, C.BG) { [weak self] in
                guard let self = self else { return }
                self.host?.pushUndo(); self.buildGrid(l, self.gridN); self.reload(); self.redraw() })
            return
        }
        stack.addArrangedSubview(btn("Rebuild with \(gridN)×\(gridN) points") { [weak self] in
            guard let self = self else { return }
            let go: () -> Void = { self.host?.pushUndo(); self.buildGrid(l, self.gridN); self.reload(); self.redraw() }
            if self.hasKeys(l) { self.confirm("Rebuild mesh?", "This removes this layer's mesh keys.", go) } else { go() }
        })
        stack.addArrangedSubview(toggleRow("Show mesh", pp.showMesh) { [weak self] v in pp.showMesh = v; self?.redraw() })
        stack.addArrangedSubview(detailChips(pp))
        stack.addArrangedSubview(chips(["Move", "Paint", "Add", "Delete"], tool) { [weak self] i in self?.tool = i; self?.reload() })
        let tips = ["Drag a point to move it.", "Paint: drag over the image; points inside the brush circle follow your finger.",
                    "Tap the image to add a point there (it starts pinned until you move it at a pose).", "Tap a point to delete it."]
        stack.addArrangedSubview(lbl(tips[tool], 12, C.DIM))
        if tool == 1 { brushSection() }
        stack.addArrangedSubview(slider("Softness (falloff)", 0.5, 6, pp.stiffness, 1) { [weak self] v in pp.stiffness = v; self?.redraw() })
        let row = UIStackView(arrangedSubviews: [
            btn("Clear keys of this parameter") { [weak self] in
                guard let self = self, let p = self.active else { return }
                self.host?.pushUndo()
                self.rig.bindings.removeAll { $0.paramId == p.id && $0.layerId == l.id && $0.key.hasPrefix("pp") }
                self.reload(); self.redraw() },
            btn("Remove mesh", C.CARD2, C.DIM) { [weak self] in
                guard let self = self else { return }
                self.host?.pushUndo()
                self.rig.bindings.removeAll { $0.layerId == l.id && $0.key.hasPrefix("pp") }
                l.puppet = nil; self.reload(); self.redraw() }])
        row.spacing = 8; row.distribution = .fillEqually
        stack.addArrangedSubview(row)
    }

    private func pickLayer(_ imgs: [Layer]) {
        ask("Layer", imgs.map { $0.name }) { [weak self] i in self?.selId = imgs[i].id; self?.reload() }
    }

    private func addPin(_ l: Layer, _ rx: Float, _ ry: Float) {
        guard let pu = l.puppet else { return }
        host?.pushUndo()
        pu.pins.append(PuppetPin(pu.nextId, rx, ry)); pu.nextId += 1
        reload(); redraw()
    }

    private func delPin(_ l: Layer, _ pin: PuppetPin) {
        guard let pu = l.puppet, pu.pins.count > 1 else { host?.toast("A mesh needs at least one point"); return }
        host?.pushUndo()
        pu.pins.removeAll { $0.id == pin.id }
        rig.bindings.removeAll { $0.layerId == l.id && ($0.key == "pp\(pin.id)x" || $0.key == "pp\(pin.id)y") }
        reload(); redraw()
    }

    // ---- transform (opacity / position / rotate / scale — all keyed at the pose above)
    private func buildTransform() {
        let ms = members()
        guard !ms.isEmpty else { stack.addArrangedSubview(lbl("Import a layer into this rig first.", 13, C.DIM)); return }
        guard let l = sel else {
            stack.addArrangedSubview(lbl("Select a layer: tap it in the canvas or pick it here.", 13, C.DIM))
            stack.addArrangedSubview(btn("Pick layer  ▾") { [weak self] in self?.pickLayer(ms) })
            return
        }
        stack.addArrangedSubview(btn("Layer: \(l.name)  ▾") { [weak self] in self?.pickLayer(ms) })
        guard let p = active else { stack.addArrangedSubview(lbl("Add a parameter above first.", 13, C.DIM)); return }
        stack.addArrangedSubview(lbl("Everything here is saved as a key at the pose above. Values are changes (+/−) from the normal pose.", 12, C.DIM))
        let pv = rig.value(p, group, Editor.time)
        for (name, key) in Self.propList {
            let r = propRange(key)
            let cur = rig.binding(p, l.id, key, create: false)?.eval(pv) ?? 0
            stack.addArrangedSubview(slider(name, r.0, r.1, cur, key == "rotZ" ? 1 : 2) { [weak self] v in
                guard let self = self else { return }
                let now = self.rig.value(p, self.group, Editor.time)
                self.rig.binding(p, l.id, key, create: true)?.setKey(now, v)
                self.refreshKeyState(); self.redraw()
            })
        }
        stack.addArrangedSubview(lbl("Rotation pivot: drag the cyan dot in the canvas.", 12, C.DIM))
        stack.addArrangedSubview(btn("Reset pivot to center") { [weak self] in
            self?.host?.pushUndo(); self?.host?.setAnchorKeepVisual(l, 50, 50); self?.redraw() })
    }
}
