// EditorLayers.swift — layer management: add/clone/copy/paste/group/split/trim/menus.

import UIKit

extension EditorViewController {
        @discardableResult
        func addLayer(_ type: LayerType) -> Layer {
            pushUndo()
            let p = Editor.project
            let s = Editor.scene
            let id = p.nextId
            p.nextId += 1
            let nm: String
            switch type {
            case .SHAPE: nm = "Shape"
            case .TEXT: nm = "Text"
            case .IMAGE: nm = "Image"
            case .VIDEO: nm = "Video"
            case .CAMERA: nm = "Camera"
            case .NULL: nm = "Null"
            case .MODEL: nm = "Model"
            case .PARTICLES: nm = "Particles"
            case .GROUP: nm = "Group"
            case .ADJUST: nm = "Adjustment"
            case .AUDIO: nm = "Audio"
            case .FLARE: nm = "Optical Flare"
            }
            let l = Layer(id, "\(nm) \(id)", type)
            l.end = s.duration
            if type == .TEXT { l.color = Int32(bitPattern: 0xFFFFFFFF); if l.text.isEmpty { l.text = "Saiki Text" } }
            if type == .MODEL || type == .CAMERA { l.is3d = true }
            s.layers.append(l)
            if type == .NULL { toast("Turn on the 3D cube (top bar) so this Null can drive other layers") }
            if type == .CAMERA { toast("The camera affects layers below it that have the 3D cube on") }
            onSelect(id)
            return l
        }

        func addParticles() {
            let l = addLayer(.SHAPE)
            l.name = "Particles \(l.id)"
            l.shape = .CIRCLE
            l.fx.append("particles")
            l.track("pShowSrc").base = 0
            expanded.insert("\(l.id):particles")
            fxTab = 0
            panel = P_FX
            showBottom(); refreshPanel()
        }

        func cloneLayer(_ l: Layer, _ suffix: String) -> Layer {
            let c = Layer(Editor.project.nextId, l.name + suffix, l.type)
            Editor.project.nextId += 1
            c.text = l.text; c.color = l.color; c.color2 = l.color2; c.shape = l.shape; c.imagePath = l.imagePath
            c.bold = l.bold; c.italic = l.italic; c.font = l.font; c.fontPath = l.fontPath
            c.strokeW = l.strokeW; c.strokeColor = l.strokeColor; c.spacing = l.spacing
            c.borderW = l.borderW; c.borderColor = l.borderColor; c.borderPad = l.borderPad
            for an in l.anims { c.anims.append(an.copy()) }
            c.start = l.start; c.end = l.end; c.is3d = l.is3d; c.parentId = l.parentId
            c.blend = l.blend; c.srcDur = l.srcDur; c.visible = l.visible; c.srcOffset = l.srcOffset
            c.mask = l.mask; c.mblur = l.mblur
            c.m3Env = l.m3Env; c.m3Metal = l.m3Metal; c.m3Ao = l.m3Ao; c.occlude = l.occlude; c.m3View = l.m3View; c.vdbDens = l.vdbDens
            c.fx.append(contentsOf: l.fx)
            c.fxOff.formUnion(l.fxOff)
            for (k, v) in l.inputs { c.inputs[k] = v }
            for (k, tr) in l.props {
                let n = c.track(k)
                n.base = tr.base
                n.copyExprFrom(tr)
                for key in tr.keys {
                    let nk = Key(key.t, key.v, key.ease)
                    nk.x1 = key.x1; nk.y1 = key.y1; nk.x2 = key.x2; nk.y2 = key.y2
                    n.keys.append(nk)
                }
            }
            return c
        }

        func targets() -> [Layer] {
            let m = Editor.scene.layers.filter { multi.contains($0.id) }
            if !m.isEmpty { return m }
            if let s = selected() { return [s] }
            return []
        }

        func duplicateSelected() {
            let t = targets()
            if t.isEmpty { toast("Select a layer first"); return }
            pushUndo()
            var last = -1
            for l in t {
                let c = cloneLayer(l, " copy")
                Editor.scene.layers.append(c)
                last = c.id
            }
            multi.removeAll()
            multiMode = false
            onSelect(last)
        }

        func copySelected() {
            let t = targets()
            if t.isEmpty { toast("Select a layer first"); return }
            clipboard.removeAll()
            for l in t { clipboard.append(cloneLayer(l, "")) }
            toast("Copied \(t.count)\(t.count == 1 ? " layer" : " layers")")
        }

        func pasteLayers() {
            if clipboard.isEmpty { toast("Nothing copied yet"); return }
            pushUndo()
            var last = -1
            for c in clipboard {
                let n = cloneLayer(c, "")
                Editor.scene.layers.append(n)
                last = n.id
            }
            multi.removeAll()
            multiMode = false
            onSelect(last)
        }

        func selectAll() {
            multi.removeAll()
            for l in Editor.scene.layers { multi.append(l.id) }
            if multi.isEmpty { toast("No layers yet"); return }
            selId = multi.last ?? -1
            refreshTitle(); refreshToolbar(); render()
            toast("All layers selected")
        }

        func groupSelected(_ asMask: Bool = false) {
            var t = targets()
            if t.isEmpty { toast("Select layers first"); return }
            // a layer whose parent is also selected travels inside that parent
            let ids = Set(t.map { $0.id })
            t = t.filter { !ids.contains($0.parentId) }
            if Set(t.map { $0.parentId }).count > 1 { toast("Select layers that share the same parent group"); return }
            pushUndo()
            let top = t.compactMap { l in Editor.scene.layers.firstIndex(where: { $0 === l }) }.max() ?? 0
            let g = addLayer(.GROUP)
            var ls = Editor.scene.layers
            ls.removeAll { $0 === g }
            ls.insert(g, at: min(top + 1, ls.count))
            Editor.scene.layers = ls
            g.parentId = t.first?.parentId ?? -1
            for l in t { l.parentId = g.id }
            multi.removeAll()
            multiMode = false
            onSelect(g.id)
            toast("Grouped \(t.count) layers")
        }

        func addSolid() {
            let l = addLayer(.SHAPE)
            l.shape = .RECT
            l.name = "Solid \(l.id)"
            l.color = Int32(bitPattern: 0xFF2A2A33)
            let ar = Float(Editor.project.w) / Float(Editor.project.h)
            l.track("scale").base = min(max(2 * ar, 2) / 0.8 / 0.84 * 1.02, 8)
            refreshPanel(); render()
        }

        func deleteLayer() {
            let t = targets()
            if t.isEmpty { return }
            pushUndo()
            // deleting a group deletes everything inside it (no orphaned contents left behind)
            var doomed: [Layer] = []
            for l in t {
                doomed.append(l)
                if l.type == .GROUP { doomed += PreRender.descendants(of: l, in: Editor.scene) }
            }
            for l in doomed {
                Editor.scene.layers.removeAll { $0 === l }
            }
            let gone = Set(doomed.map { $0.id })
            for o in Editor.scene.layers where gone.contains(o.parentId) { o.parentId = -1 }
            multi.removeAll()
            multiMode = false
            onSelect(-1)
        }

        func splitLayer(_ l: Layer, _ t: Float) -> Layer? {
            if t <= l.start + 0.04 || t >= l.end - 0.04 { return nil }
            if l.type == .GROUP { return splitGroup(l, t) }
            let c = cloneLayer(l, "")
            c.name = l.name
            c.start = t
            if l.type == .VIDEO || l.type == .AUDIO { c.srcOffset = l.srcOffset + (t - l.start) }
            l.end = t
            var ls = Editor.scene.layers
            if let i = ls.firstIndex(where: { $0 === l }) { ls.insert(c, at: i + 1) }
            Editor.scene.layers = ls
            return c
        }

        /// Cuts a group in two at `t`: children are split too, and the right-hand halves
        /// (plus children that start after `t`) move into the new second group.
        func splitGroup(_ g: Layer, _ t: Float) -> Layer? {
            let g2 = cloneLayer(g, "")
            g2.name = g.name
            g2.start = t
            g.end = t
            var ls = Editor.scene.layers
            if let i = ls.firstIndex(where: { $0 === g }) { ls.insert(g2, at: i + 1) }
            Editor.scene.layers = ls
            let kids = Editor.scene.layers.filter { $0.parentId == g.id }
            for c in kids {
                if c.end <= t + 0.04 { continue }
                if c.start >= t - 0.04 { c.parentId = g2.id; continue }
                if let c2 = splitLayer(c, t) { c2.parentId = g2.id }
            }
            return g2
        }

        /** Splits the selected layers (or every layer under the playhead) at the playhead. */
        func splitAtPlayhead(_ all: Bool) {
            let t = Editor.time
            let list = all ? Editor.scene.layers : targets()
            if list.isEmpty { toast("Select a layer first"); return }
            pushUndo()
            var last: Layer? = nil
            var n = 0
            for l in list {
                if let c = splitLayer(l, t) { last = c; n += 1 }
            }
            if last == nil { toast("Move the playhead inside the layer to split it"); return }
            multi.removeAll()
            multiMode = false
            toast(n == 1 ? "Layer split" : "Split \(n) layers")
            onSelect(last!.id)
        }

        /** Moves the start or end of the selected layers to the playhead. */
        func trimTo(_ start: Bool) {
            let list = targets()
            if list.isEmpty { toast("Select a layer first"); return }
            let t = Editor.time
            pushUndo()
            var n = 0
            for l in list {
                if l.type == .GROUP { continue }
                if start && t > l.start + 0.04 && t < l.end {
                    if l.type == .VIDEO || l.type == .AUDIO { l.srcOffset += t - l.start }
                    l.start = t; n += 1
                } else if !start && t < l.end - 0.04 && t > l.start {
                    l.end = t; n += 1
                }
            }
            if n == 0 { toast("Move the playhead inside the layer first") } else { render() }
        }

        func moveLayer(_ dir: Int) {
            guard let l = selected() else { return }
            pushUndo()
            var ls = Editor.scene.layers
            guard let i = ls.firstIndex(where: { $0 === l }) else { return }
            let j = i + dir
            if j < 0 || j >= ls.count { return }
            ls.remove(at: i)
            ls.insert(l, at: j)
            Editor.scene.layers = ls
            render()
        }

        func toggle3d() {
            guard let l = selected() else { toast("Select a layer first"); return }
            if l.type == .MODEL || l.type == .CAMERA { toast("This layer is always 3D"); return }
            pushUndo()
            l.is3d = !l.is3d
            refreshTitle(); refreshPanel(); render()
            toast(l.is3d ? "3D on" : "3D off")
        }

        func showLayersMenu() {
            let labels = ["Select All Layers",
                          multiMode ? "Stop Selecting Multiple" : "Select Multiple Layers",
                          "Group Layers", "Show All Keyframes",
                          "Split at Playhead", "Split All Layers at Playhead", "Copy Layer", "Paste Layer",
                          "Duplicate Layer", "Move Layer Up", "Move Layer Down",
                          overlay.guides ? "Hide Guides" : "Show Guides", "Delete Layer", "Mask Group"]
            let icons = ["layers", "check", "layers", "graph", "split", "split", "dup", "import", "dup",
                         "chev_up", "chev_down", "dots", "trash", "mask"]
            Dlg(self).setTitle("Layers").setIconItems(labels, icons) { [weak self] _, w in
                guard let self = self else { return }
                switch w {
                case 0: self.selectAll()
                case 1:
                    self.multiMode = !self.multiMode
                    if !self.multiMode { self.multi.removeAll() }
                    self.render()
                    self.toast(self.multiMode ? "Tap layers to select them" : "Multi select off")
                case 2: self.groupSelected()
                case 3: self.timeline.expandAll()
                case 4: self.splitAtPlayhead(false)
                case 5: self.splitAtPlayhead(true)
                case 6: self.copySelected()
                case 7: self.pasteLayers()
                case 8: self.duplicateSelected()
                case 9: self.moveLayer(1)
                case 10: self.moveLayer(-1)
                case 11:
                    self.overlay.guides = !self.overlay.guides
                    self.overlay.setNeedsDisplay()
                case 13: self.groupSelected(true)
                default: self.deleteLayer()
                }
            }.setNegativeButton("Close", nil).show()
        }

        /// The two-square icon next to the title: add / copy / paste / group /
        /// keyframes / duplicate / parent.
        func showQuickLayerMenu() {
            let labels = ["Add Layer", "Copy Layer", "Paste Layer", "Group Layers",
                          "Show All Keyframes", "Duplicate Layer", "Set Parent…"]
            let icons = ["plus", "dup", "import", "layers", "graph", "dup", "link"]
            Dlg(self).setTitle("Layer").setIconItems(labels, icons) { [weak self] _, w in
                guard let self = self else { return }
                switch w {
                case 0: self.showAddLayerMenu()
                case 1: self.copySelected()
                case 2: self.pasteLayers()
                case 3: self.groupSelected()
                case 4: self.timeline.expandAll()
                case 5: self.duplicateSelected()
                default:
                    if let l = self.selected() { self.showParentPopup(l, self.parentIcon) }
                }
            }.setNegativeButton("Close", nil).show()
        }

        func showAddLayerMenu() {
            let labels = ["Media", "Solid", "Adjustment", "Null", "Shape", "Camera", "Particles", "Group"]
            let icons = ["media", "solid", "adjust", "nullobj", "shape", "camera", "particles", "layers"]
            Dlg(self).setTitle("Add Layer").setIconItems(labels, icons) { [weak self] _, w in
                guard let self = self else { return }
                switch w {
                case 0: self.openPanel(P_MEDIA)
                case 1: self.addSolid()
                case 2: self.addLayer(.ADJUST)
                case 3: self.addLayer(.NULL)
                case 4: self.openPanel(P_SHAPES)
                case 5: self.addLayer(.CAMERA)
                case 6: self.addParticles()
                default: self.addLayer(.GROUP)
                }
            }.setNegativeButton("Close", nil).show()
        }
}
