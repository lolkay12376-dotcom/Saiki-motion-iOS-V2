// Rig.swift — rig group data (Model).
//
// A rig group is a GROUP layer with a `Rig`. Parameters are tracks on that
// group ("rp<id>"), so they can be keyframed in the main editor too. A binding
// maps a parameter to one property of a member layer through keyforms
// (parameter value → output), interpolated linearly. The output is ADDED to the
// property ("x", "rotZ", "opacity", or a mesh pin "pp<id>x"/"pp<id>y").

import Foundation

final class RigParam {
    var id: Int
    var name: String
    var lo: Float
    var hi: Float
    var def: Float
    init(_ id: Int, _ name: String, _ lo: Float, _ hi: Float, _ def: Float) {
        self.id = id; self.name = name; self.lo = lo; self.hi = hi; self.def = def
    }
    var key: String { "rp\(id)" }
}

final class RigBinding {
    var id: Int
    var paramId: Int
    var layerId: Int
    var key: String
    var keys: [(Float, Float)]      // (parameter value, output), sorted by parameter value
    var rest: Float? = nil          // implicit zero-output key at the parameter default (not stored as a key)
    init(_ id: Int, _ paramId: Int, _ layerId: Int, _ key: String, _ keys: [(Float, Float)] = []) {
        self.id = id; self.paramId = paramId; self.layerId = layerId; self.key = key; self.keys = keys
    }

    func eval(_ v: Float) -> Float {
        var keys = self.keys
        if let rv = rest, !keys.contains(where: { abs($0.0 - rv) < 1e-3 }) {
            keys.append((rv, 0)); keys.sort { $0.0 < $1.0 }
        }
        guard let f = keys.first, let l = keys.last else { return 0 }
        if v <= f.0 { return f.1 }
        if v >= l.0 { return l.1 }
        for i in 1..<keys.count where v <= keys[i].0 {
            let a = keys[i - 1], b = keys[i]
            let d = b.0 - a.0
            return d < 1e-6 ? b.1 : a.1 + (b.1 - a.1) * (v - a.0) / d
        }
        return l.1
    }

    func setKey(_ pv: Float, _ out: Float) {
        if let i = keys.firstIndex(where: { abs($0.0 - pv) < 1e-3 }) { keys[i].1 = out }
        else { keys.append((pv, out)); keys.sort { $0.0 < $1.0 } }
    }
}

final class RigFolder {
    var id: Int
    var name: String
    var open = true
    init(_ id: Int, _ name: String) { self.id = id; self.name = name }
}

final class Rig {
    var folders: [RigFolder] = []
    var folderOf: [Int: Int] = [:]  // layer id → folder id (absent = root)
    var params: [RigParam] = []
    var bindings: [RigBinding] = []
    var members: [Int] = []         // layer ids imported into this rig group
    var nextId = 1

    func param(_ id: Int) -> RigParam? { params.first { $0.id == id } }

    @discardableResult
    func addParam(_ name: String, _ lo: Float, _ hi: Float, _ def: Float, on g: Layer) -> RigParam {
        let p = RigParam(nextId, name, lo, hi, def); nextId += 1
        params.append(p)
        g.track(p.key).base = def
        return p
    }

    func value(_ p: RigParam, _ g: Layer, _ t: Float) -> Float { g.p(p.key, t) }

    /// Existing binding for (param, layer, key) or a new one with a zero key at the default.
    func binding(_ p: RigParam, _ layerId: Int, _ key: String, create: Bool) -> RigBinding? {
        if let b = bindings.first(where: { $0.paramId == p.id && $0.layerId == layerId && $0.key == key }) { return b }
        guard create else { return nil }
        let b = RigBinding(nextId, p.id, layerId, key, []); b.rest = p.def; nextId += 1
        bindings.append(b)
        return b
    }

    func removeLayer(_ id: Int) {
        members.removeAll { $0 == id }
        folderOf[id] = nil
        bindings.removeAll { $0.layerId == id }
    }

    // MARK: apply (called before every frame is drawn)

    /// Members of a rig group = every layer below it in the timeline (children, folders, deformers).
    static func syncMembers(_ layers: [Layer]) {
        for g in layers {
            guard let r = g.rig else { continue }
            var inside = Set<Int>([g.id]); var grew = true
            while grew {
                grew = false
                for l in layers where !inside.contains(l.id) && inside.contains(l.parentId) { inside.insert(l.id); grew = true }
            }
            let ids = layers.filter { $0.id != g.id && inside.contains($0.id) }.map { $0.id }
            if ids != r.members { r.members = ids }
        }
    }

    static func descendants(_ g: Layer, _ layers: [Layer]) -> [Layer] {
        var inside = Set<Int>([g.id]); var out: [Layer] = []; var grew = true
        while grew {
            grew = false
            for l in layers where !inside.contains(l.id) && inside.contains(l.parentId) { inside.insert(l.id); out.append(l); grew = true }
        }
        return out
    }

    static func apply(_ layers: [Layer], _ t: Float, live: [Int: [String: Float]] = [:]) {
        var any = false
        for l in layers where l.rig != nil || l.warp != nil { any = true; break }
        if !any {
            for l in layers where !l.rigOff.isEmpty { l.rigOff.removeAll() }
            return
        }
        syncMembers(layers)
        for l in layers { if !l.rigOff.isEmpty { l.rigOff.removeAll(keepingCapacity: true) } }
        var byId = [Int: Layer]()
        for l in layers { byId[l.id] = l }
        for g in layers {
            guard let r = g.rig else { continue }
            let mem = Set(r.members)
            for b in r.bindings {
                guard mem.contains(b.layerId), let p = r.param(b.paramId), let target = byId[b.layerId] else { continue }
                target.rigOff[b.key, default: 0] += b.eval(g.p(p.key, t))
            }
        }
        for (id, d) in live { if let l = byId[id] { for (k, v) in d { l.rigOff[k] = v } } }
        for w in layers where w.deformer == 1 { if let wp = w.warp { applyWarp(w, wp, layers, t) } }
    }

    /// Warp deformer: bilinear control-grid offsets are added to the mesh pins of every image layer inside.
    static func applyWarp(_ w: Layer, _ wp: Warp, _ layers: [Layer], _ t: Float) {
        let n = max(2, wp.n)
        var offs = [Float](repeating: 0, count: n * n * 2); var moved = false
        for k in 0..<(n * n) {
            offs[2 * k] = w.p("wx\(k)", t); offs[2 * k + 1] = w.p("wy\(k)", t)
            if offs[2 * k] != 0 || offs[2 * k + 1] != 0 { moved = true }
        }
        if !moved { return }
        let mw = Xf.matrix(w, t)
        guard let invW = Xf.invert(mw) else { return }
        for l in descendants(w, layers) where l.type == .IMAGE {
            guard let pp = l.puppet, pp.on, !pp.pins.isEmpty else { continue }
            let ml = Xf.matrix(l, t)
            guard let invL = Xf.invert(ml) else { continue }
            let (qw, qh) = Xf.quadSize(l)
            for pin in pp.pins {
                let wpos = Xf.apply(ml, pin.rx * qw / 2, pin.ry * qh / 2)
                let q = Xf.apply(invW, wpos.0, wpos.1)
                let u = min(1, max(0, (q.0 - wp.bx) / max(wp.bw, 1e-4))) * Float(n - 1)
                let v = min(1, max(0, (q.1 - wp.by) / max(wp.bh, 1e-4))) * Float(n - 1)
                let i0 = min(n - 2, Int(u)), j0 = min(n - 2, Int(v))
                let fu = u - Float(i0), fv = v - Float(j0)
                var dx: Float = 0, dy: Float = 0
                for (di, dj, wgt) in [(0, 0, (1 - fu) * (1 - fv)), (1, 0, fu * (1 - fv)), (0, 1, (1 - fu) * fv), (1, 1, fu * fv)] {
                    let k = (j0 + dj) * n + (i0 + di)
                    dx += offs[2 * k] * wgt; dy += offs[2 * k + 1] * wgt
                }
                // W-local displacement → world → layer-local
                let wx = mw[0] * dx + mw[2] * dy, wy = mw[1] * dx + mw[3] * dy
                let lx = invL[0] * wx + invL[2] * wy, ly = invL[1] * wx + invL[3] * wy
                l.rigOff["pp\(pin.id)x", default: 0] += lx / (qw / 2)
                l.rigOff["pp\(pin.id)y", default: 0] += ly / (qh / 2)
            }
        }
    }

    // MARK: json

    func toJson() -> JObj {
        let o = JObj()
        o.put("nextId", Int64(nextId))
        let pa = JArr()
        for p in params {
            _ = pa.put(JObj().put("id", Int64(p.id)).put("name", p.name)
                .put("lo", Double(p.lo)).put("hi", Double(p.hi)).put("def", Double(p.def)))
        }
        o.put("params", pa)
        let ba = JArr()
        for b in bindings {
            let ka = JArr()
            for k in b.keys { _ = ka.put(JObj().put("v", Double(k.0)).put("o", Double(k.1))) }
            _ = ba.put(JObj().put("id", Int64(b.id)).put("param", Int64(b.paramId))
                .put("layer", Int64(b.layerId)).put("key", b.key).put("keys", ka)
                .put("rest", Double(b.rest ?? -99999)))
        }
        o.put("bindings", ba)
        let ma = JArr(); for m in members { _ = ma.put(Int64(m)) }
        o.put("members", ma)
        let fa = JArr()
        for f in folders { _ = fa.put(JObj().put("id", Int64(f.id)).put("name", f.name).put("open", f.open)) }
        o.put("folders", fa)
        let fo = JArr()
        for (l, f) in folderOf { _ = fo.put(JObj().put("l", Int64(l)).put("f", Int64(f))) }
        o.put("folderOf", fo)
        return o
    }

    static func fromJson(_ o: JObj) -> Rig {
        let r = Rig()
        r.nextId = max(1, o.optInt("nextId", 1))
        if let pa = o.optJSONArray("params") {
            for i in 0..<pa.count {
                guard let p = pa.optJSONObject(i) else { continue }
                r.params.append(RigParam(p.optInt("id"), p.optString("name", "Param"),
                                         p.optFloat("lo", 0), p.optFloat("hi", 1), p.optFloat("def", 0)))
            }
        }
        if let ba = o.optJSONArray("bindings") {
            for i in 0..<ba.count {
                guard let b = ba.optJSONObject(i) else { continue }
                var ks = [(Float, Float)]()
                if let ka = b.optJSONArray("keys") {
                    for j in 0..<ka.count {
                        if let k = ka.optJSONObject(j) { ks.append((k.optFloat("v"), k.optFloat("o"))) }
                    }
                }
                let nb = RigBinding(b.optInt("id"), b.optInt("param"), b.optInt("layer"), b.optString("key", "x"), ks)
                let rv = b.optFloat("rest", -99999)
                nb.rest = rv > -99998 ? rv : r.param(nb.paramId)?.def
                r.bindings.append(nb)
            }
        }
        if let ma = o.optJSONArray("members") {
            for i in 0..<ma.count { r.members.append(ma.optInt(i)) }
        }
        if let fa = o.optJSONArray("folders") {
            for i in 0..<fa.count {
                if let f = fa.optJSONObject(i) {
                    let rf = RigFolder(f.optInt("id"), f.optString("name", "Folder"))
                    rf.open = f.optBool("open", true); r.folders.append(rf)
                }
            }
        }
        if let fo = o.optJSONArray("folderOf") {
            for i in 0..<fo.count { if let e = fo.optJSONObject(i) { r.folderOf[e.optInt("l")] = e.optInt("f") } }
        }
        return r
    }
}

/// Warp deformer control grid (n × n points over a box in the deformer group's local space).
final class Warp {
    var n = 4
    var bx: Float = -0.5, by: Float = -0.5, bw: Float = 1, bh: Float = 1
    func rest(_ k: Int) -> (Float, Float) {
        let i = k % n, j = k / n, d = Float(max(n - 1, 1))
        return (bx + bw * Float(i) / d, by + bh * Float(j) / d)
    }
    func toJson() -> JObj {
        JObj().put("n", Int64(n)).put("bx", Double(bx)).put("by", Double(by)).put("bw", Double(bw)).put("bh", Double(bh))
    }
    static func fromJson(_ o: JObj) -> Warp {
        let w = Warp()
        w.n = max(2, o.optInt("n", 4)); w.bx = o.optFloat("bx", -0.5); w.by = o.optFloat("by", -0.5)
        w.bw = o.optFloat("bw", 1); w.bh = o.optFloat("bh", 1)
        return w
    }
}
