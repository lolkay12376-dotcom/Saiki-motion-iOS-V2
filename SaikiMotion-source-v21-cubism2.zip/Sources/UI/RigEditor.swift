// RigEditor.swift — "Cubism Editor": live 2D rig editor for a rig group (UI).
//
// Tabs: Params · Layers (folders + parenting) · Folder (mesh deformer + paint brush
// for every layer in a folder) · Mesh (per-layer points, brush, add/delete) · Rotate.
// Keying: pick a parameter value (slider / key bar), then drag or paint — the result is
// stored as a keyform at that value. Drags are previewed live (RigCanvas.live) and committed
// on finger-up, so the preview is never wiped by a redraw.

import UIKit

// MARK: - key bar (shows keyforms of the active parameter, tap/scrub to jump)

final class KeyBar: UIView {
    var lo: Float = 0, hi: Float = 1, value: Float = 0
    var keys: [Float] = []
    var onPick: ((Float) -> Void)?

    override init(frame: CGRect) { super.init(frame: frame); backgroundColor = .clear; isOpaque = false }
    required init?(coder: NSCoder) { fatalError() }

    private func x(_ v: Float) -> CGFloat {
        let w = bounds.width - 24
        return 12 + w * CGFloat((v - lo) / max(hi - lo, 0.0001))
    }
    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let y = bounds.midY - 4
        c.setStrokeColor(argbToUIColor(C.CARD2).cgColor); c.setLineWidth(4); c.setLineCap(.round)
        c.move(to: CGPoint(x: 12, y: y)); c.addLine(to: CGPoint(x: bounds.width - 12, y: y)); c.strokePath()
        for k in keys {
            let cx = x(k), on = abs(k - value) < 0.002
            c.setFillColor(argbToUIColor(on ? C.TEXT : C.GREEN).cgColor)
            c.move(to: CGPoint(x: cx, y: y - 9)); c.addLine(to: CGPoint(x: cx + 8, y: y))
            c.addLine(to: CGPoint(x: cx, y: y + 9)); c.addLine(to: CGPoint(x: cx - 8, y: y)); c.fillPath()
        }
        let vx = x(min(hi, max(lo, value)))
        c.setStrokeColor(UIColor.white.cgColor); c.setLineWidth(2)
        c.move(to: CGPoint(x: vx, y: y - 13)); c.addLine(to: CGPoint(x: vx, y: y + 13)); c.strokePath()
        let a: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 11), .foregroundColor: argbToUIColor(C.DIM)]
        String(format: "%g", lo).draw(at: CGPoint(x: 8, y: bounds.height - 16), withAttributes: a)
        let h = String(format: "%g", hi) as NSString
        h.draw(at: CGPoint(x: bounds.width - 8 - h.size(withAttributes: a).width, y: bounds.height - 16), withAttributes: a)
    }
    private func pick(_ t: UITouch) {
        let px = t.location(in: self).x
        var v = lo + Float((px - 12) / max(bounds.width - 24, 1)) * (hi - lo)
        v = min(hi, max(lo, v))
        if let k = keys.min(by: { abs(x($0) - px) < abs(x($1) - px) }), abs(x(k) - px) < 18 { v = k }
        value = v; setNeedsDisplay(); onPick?(v)
    }
    override func touchesBegan(_ t: Set<UITouch>, with e: UIEvent?) { if let t = t.first { pick(t) } }
    override func touchesMoved(_ t: Set<UITouch>, with e: UIEvent?) { if let t = t.first { pick(t) } }
}

// MARK: - canvas

final class RigCanvas: UIView {
    var group: Layer!
    var selId = -1
    var mode = 0                                  // 0 params, 1 layers, 2 folder, 3 mesh, 4 rotate
    var tool = 0                                  // mesh tab: 0 move, 1 paint, 2 add, 3 delete
    var targets: [Int] = []                       // layers the pins / brush act on
    var brushR: Float = 0.25                      // world units
    var brushK: Float = 1
    var onSelect: ((Int) -> Void)?
    var onBeginEdit: (() -> Void)?
    var onCommit: (([Int: [String: Float]], [Int: [String: Float]]) -> Void)?   // live, start
    var onAdd: ((Layer, Float, Float) -> Void)?
    var onDel: ((Layer, PuppetPin) -> Void)?
    var onPivot: ((Layer, Float, Float) -> Void)?
    var warpId = -1                               // warp deformer shown in mode 2
    var softR: Float = 1.5                        // warp drag falloff, in grid cells
    private var dragWarp = -1
    private var warpStartQ = (Float(0), Float(0))
    private var warpStartOff: [Float] = []

    private var zoom: CGFloat = 1
    private var pan = CGPoint.zero
    private var dragPin: (Layer, PuppetPin)?
    private var dragPivot = false
    private var brushing = false
    private var brushPt: CGPoint?
    private var lastW = (Float(0), Float(0))
    private var live: [Int: [String: Float]] = [:]
    private var start: [Int: [String: Float]] = [:]
    private static var imgCache: [String: CGImage] = [:]

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = argbToUIColor(C.BG)
        contentMode = .redraw
        clipsToBounds = true
        isMultipleTouchEnabled = true
        let pi = UIPinchGestureRecognizer(target: self, action: #selector(pinch(_:)))
        let pa = UIPanGestureRecognizer(target: self, action: #selector(panned(_:)))
        pa.minimumNumberOfTouches = 2
        addGestureRecognizer(pi); addGestureRecognizer(pa)
    }
    required init?(coder: NSCoder) { fatalError() }

    @objc private func pinch(_ g: UIPinchGestureRecognizer) {
        zoom = min(6, max(0.3, zoom * g.scale)); g.scale = 1; setNeedsDisplay()
    }
    @objc private func panned(_ g: UIPanGestureRecognizer) {
        let t = g.translation(in: self); pan.x += t.x; pan.y += t.y
        g.setTranslation(.zero, in: self); setNeedsDisplay()
    }

    // MARK: geometry
    private var members: [Layer] {
        guard let r = group?.rig else { return [] }
        return Editor.scene.layers.filter { r.members.contains($0.id) }
    }
    private func lay(_ id: Int) -> Layer? { Editor.scene.layers.first { $0.id == id } }
    private var pinLayers: [Layer] {
        guard mode == 3 else { return [] }
        return targets.compactMap { lay($0) }.filter { $0.puppet?.pins.isEmpty == false }
    }
    private var ar: CGFloat { CGFloat(Editor.project.w) / CGFloat(max(Editor.project.h, 1)) }
    private var sc: CGFloat { min(bounds.height / 2, bounds.width / (2 * ar)) * 0.92 * zoom }
    private var cx: CGFloat { bounds.midX + pan.x }
    private var cy: CGFloat { bounds.midY + pan.y }
    private func scr(_ x: Float, _ y: Float) -> CGPoint { CGPoint(x: cx + CGFloat(x) * sc, y: cy - CGFloat(y) * sc) }
    private func world(_ p: CGPoint) -> (Float, Float) { (Float((p.x - cx) / sc), Float(-(p.y - cy) / sc)) }
    private func toScr(_ m: [Float], _ x: Float, _ y: Float) -> CGPoint { let w = Xf.apply(m, x, y); return scr(w.0, w.1) }
    private func local(_ l: Layer, _ p: CGPoint) -> (Float, Float)? {
        guard let inv = Xf.invert(Xf.matrix(l, Editor.time)) else { return nil }
        let w = world(p); return Xf.apply(inv, w.0, w.1)
    }
    private func cg(_ l: Layer) -> CGImage? {
        guard l.type == .IMAGE, let path = l.imagePath else { return nil }
        if let c = Self.imgCache[path] { return c }
        guard let ui = UIImage(contentsOfFile: path) else { return nil }
        let mx: CGFloat = 640, k = min(1, mx / max(ui.size.width, ui.size.height))
        let sz = CGSize(width: max(1, ui.size.width * k), height: max(1, ui.size.height * k))
        let f = UIGraphicsImageRendererFormat(); f.scale = 1
        let out = UIGraphicsImageRenderer(size: sz, format: f).image { _ in ui.draw(in: CGRect(origin: .zero, size: sz)) }
        if let c = out.cgImage { Self.imgCache[path] = c; return c }
        return nil
    }
    private func setLive(_ l: Layer, _ key: String, _ v: Float) {
        if start[l.id]?[key] == nil { start[l.id, default: [:]][key] = l.rigOff[key] ?? 0 }
        live[l.id, default: [:]][key] = v
    }
    private func curOff(_ l: Layer, _ key: String) -> Float { live[l.id]?[key] ?? (l.rigOff[key] ?? 0) }

    // MARK: draw
    override func draw(_ rect: CGRect) {
        guard let ctx = UIGraphicsGetCurrentContext(), group?.rig != nil else { return }
        Rig.apply(Editor.scene.layers, Editor.time, live: live)      // live drag preview included
        let t = Editor.time
        let a = Float(ar)
        let tl = scr(-a, 1), br = scr(a, -1)
        ctx.setFillColor(argbToUIColor(C.CARD).cgColor)
        ctx.fill(CGRect(x: tl.x, y: tl.y, width: br.x - tl.x, height: br.y - tl.y))
        // the canvas is small: draw meshes at reduced density (lowest while interacting) so dragging stays smooth
        let busy = !live.isEmpty || dragWarp >= 0 || dragPin != nil || brushing
        var savedDens: [(Puppet, Int)] = []
        for l in members { if let pp = l.puppet { savedDens.append((pp, pp.density)); pp.density = min(pp.density, busy ? 0 : 1) } }
        for l in members where l.type == .IMAGE && shown(l) { drawLayer(ctx, l, t) }
        for (pp, d) in savedDens { pp.density = d }

        // selection outline(s)
        ctx.setStrokeColor(argbToUIColor(C.GREEN).cgColor); ctx.setLineWidth(1.5)
        let outlined: [Layer] = members.filter { $0.id == selId && $0.type != .GROUP }
        for s in outlined {
            let m = Xf.matrix(s, t); let (qw, qh) = Xf.quadSize(s)
            let q = [(-qw / 2, -qh / 2), (qw / 2, -qh / 2), (qw / 2, qh / 2), (-qw / 2, qh / 2)].map { toScr(m, $0.0, $0.1) }
            ctx.addLines(between: q + [q[0]]); ctx.strokePath()
        }
        // mesh overlay + points
        for s in pinLayers {
            guard let pp = s.puppet else { continue }
            let m = Xf.matrix(s, t); let (qw, qh) = Xf.quadSize(s)
            if pp.showMesh && pp.on {
                let n = PuppetMath.segs[min(pp.density, PuppetMath.segs.count - 1)]
                let g = PuppetMath.gridPositions(s, pp, t)
                let step = max(1, n / 14)
                func pt(_ i: Int, _ j: Int) -> CGPoint {
                    let k = (j * (n + 1) + i) * 2
                    return toScr(m, g[k] * qw / 2, g[k + 1] * qh / 2)
                }
                ctx.setStrokeColor(UIColor.cyan.withAlphaComponent(0.55).cgColor); ctx.setLineWidth(0.8)
                var j = 0
                while j <= n { ctx.move(to: pt(0, j)); for i in 1...n { ctx.addLine(to: pt(i, j)) }; j += step }
                var i = 0
                while i <= n { ctx.move(to: pt(i, 0)); for j2 in 1...n { ctx.addLine(to: pt(i, j2)) }; i += step }
                ctx.strokePath()
            }
            let r: CGFloat = (mode == 3 && tool == 1) ? 4 : 7
            for pin in pp.pins {
                let o = pinOffset(s, pin, t)
                let c = toScr(m, (pin.rx + o.0) * qw / 2, (pin.ry + o.1) * qh / 2)
                ctx.setFillColor(argbToUIColor(pin === dragPin?.1 ? C.TEXT : C.GREEN).cgColor)
                ctx.fillEllipse(in: CGRect(x: c.x - r, y: c.y - r, width: r * 2, height: r * 2))
            }
        }
        if mode == 2, let w = lay(warpId), let wp = w.warp { drawWarp(ctx, w, wp, t) }
        if mode == 4, let s = members.first(where: { $0.id == selId }) {
            let c = pivotScreen(s)
            ctx.setStrokeColor(UIColor.cyan.cgColor); ctx.setLineWidth(2)
            ctx.strokeEllipse(in: CGRect(x: c.x - 11, y: c.y - 11, width: 22, height: 22))
            ctx.move(to: CGPoint(x: c.x - 16, y: c.y)); ctx.addLine(to: CGPoint(x: c.x + 16, y: c.y))
            ctx.move(to: CGPoint(x: c.x, y: c.y - 16)); ctx.addLine(to: CGPoint(x: c.x, y: c.y + 16))
            ctx.strokePath()
        }
        if brushing, let b = brushPt {
            let r = CGFloat(brushR) * sc
            ctx.setStrokeColor(UIColor.white.withAlphaComponent(0.85).cgColor); ctx.setLineWidth(1.5)
            ctx.strokeEllipse(in: CGRect(x: b.x - r, y: b.y - r, width: r * 2, height: r * 2))
        }
    }

    private func shown(_ l: Layer) -> Bool {
        var cur: Layer? = l; var n = 0
        while let x = cur, x.id != group.id, n < 32 { if !x.visible { return false }; cur = lay(x.parentId); n += 1 }
        return true
    }
    private func warpPoint(_ w: Layer, _ wp: Warp, _ k: Int, _ t: Float) -> CGPoint {
        let r = wp.rest(k)
        return toScr(Xf.matrix(w, t), r.0 + w.p("wx\(k)", t), r.1 + w.p("wy\(k)", t))
    }
    private func drawWarp(_ ctx: CGContext, _ w: Layer, _ wp: Warp, _ t: Float) {
        let n = wp.n
        ctx.setStrokeColor(argbToUIColor(C.GREEN).withAlphaComponent(0.7).cgColor); ctx.setLineWidth(1)
        for j in 0..<n { for i in 0..<n {
            let p = warpPoint(w, wp, j * n + i, t)
            if i + 1 < n { ctx.move(to: p); ctx.addLine(to: warpPoint(w, wp, j * n + i + 1, t)) }
            if j + 1 < n { ctx.move(to: p); ctx.addLine(to: warpPoint(w, wp, (j + 1) * n + i, t)) }
        } }
        ctx.strokePath()
        for k in 0..<(n * n) {
            let p = warpPoint(w, wp, k, t)
            ctx.setFillColor(argbToUIColor(k == dragWarp ? C.TEXT : C.GREEN).cgColor)
            ctx.fillEllipse(in: CGRect(x: p.x - 6, y: p.y - 6, width: 12, height: 12))
        }
    }
    private func nearestWarp(_ p: CGPoint) -> Int? {
        guard let w = lay(warpId), let wp = w.warp else { return nil }
        var best: (Int, CGFloat)? = nil
        for k in 0..<(wp.n * wp.n) {
            let c = warpPoint(w, wp, k, Editor.time); let d = hypot(c.x - p.x, c.y - p.y)
            if d < 36 && d < (best?.1 ?? .infinity) { best = (k, d) }
        }
        return best?.0
    }

    private func pinOffset(_ l: Layer, _ pin: PuppetPin, _ t: Float) -> (Float, Float) {
        ((l.props["pp\(pin.id)x"]?.eval(t) ?? 0) + (l.rigOff["pp\(pin.id)x"] ?? 0),
         (l.props["pp\(pin.id)y"]?.eval(t) ?? 0) + (l.rigOff["pp\(pin.id)y"] ?? 0))
    }
    private func pivotScreen(_ l: Layer) -> CGPoint {
        let (qw, qh) = Xf.quadSize(l)
        let ax = l.p("anchorX", Editor.time), ay = l.p("anchorY", Editor.time)
        return toScr(Xf.matrix(l, Editor.time), (ax - 50) / 100 * qw, -(ay - 50) / 100 * qh)
    }

    private func drawLayer(_ ctx: CGContext, _ l: Layer, _ t: Float) {
        let m = Xf.matrix(l, t); let (qw, qh) = Xf.quadSize(l)
        ctx.saveGState()
        ctx.translateBy(x: cx, y: cy); ctx.scaleBy(x: sc, y: -sc)
        ctx.concatenate(CGAffineTransform(a: CGFloat(m[0]), b: CGFloat(m[1]), c: CGFloat(m[2]),
                                          d: CGFloat(m[3]), tx: CGFloat(m[4]), ty: CGFloat(m[5])))
        ctx.setAlpha(CGFloat(max(0, min(1, l.p("opacity", t)))))
        let hw = CGFloat(qw) / 2, hh = CGFloat(qh) / 2
        if let img = cg(l) {
            if let mesh = PuppetMath.mesh(l, t) {
                ctx.setShouldAntialias(false)          // no seams between triangles
                let W = CGFloat(img.width), H = CGFloat(img.height)
                var i = 0
                while i + 2 < mesh.idx.count {
                    let ids = [Int(mesh.idx[i]), Int(mesh.idx[i + 1]), Int(mesh.idx[i + 2])]; i += 3
                    let d = ids.map { CGPoint(x: CGFloat(mesh.pos[2 * $0]) * hw, y: CGFloat(mesh.pos[2 * $0 + 1]) * hh) }
                    let s = ids.map { CGPoint(x: CGFloat(mesh.uv[2 * $0]) * W, y: CGFloat(mesh.uv[2 * $0 + 1]) * H) }
                    let e1 = CGPoint(x: s[1].x - s[0].x, y: s[1].y - s[0].y), e2 = CGPoint(x: s[2].x - s[0].x, y: s[2].y - s[0].y)
                    let f1 = CGPoint(x: d[1].x - d[0].x, y: d[1].y - d[0].y), f2 = CGPoint(x: d[2].x - d[0].x, y: d[2].y - d[0].y)
                    let det = e1.x * e2.y - e1.y * e2.x
                    if abs(det) < 1e-6 { continue }
                    let a = (f1.x * e2.y - f2.x * e1.y) / det, c = (f2.x * e1.x - f1.x * e2.x) / det
                    let b = (f1.y * e2.y - f2.y * e1.y) / det, dd = (f2.y * e1.x - f1.y * e2.x) / det
                    let tx = d[0].x - (a * s[0].x + c * s[0].y), ty = d[0].y - (b * s[0].x + dd * s[0].y)
                    ctx.saveGState()
                    ctx.move(to: d[0]); ctx.addLine(to: d[1]); ctx.addLine(to: d[2]); ctx.closePath(); ctx.clip()
                    ctx.concatenate(CGAffineTransform(a: a, b: b, c: c, d: dd, tx: tx, ty: ty))
                    ctx.draw(img, in: CGRect(x: 0, y: 0, width: W, height: H))
                    ctx.restoreGState()
                }
                ctx.setShouldAntialias(true)
            } else {
                ctx.draw(img, in: CGRect(x: -hw, y: -hh, width: hw * 2, height: hh * 2))
            }
        } else {
            ctx.setFillColor(argbToUIColor(C.CARD2).cgColor)
            ctx.fill(CGRect(x: -hw, y: -hh, width: hw * 2, height: hh * 2))
        }
        ctx.restoreGState()
    }

    // MARK: touch
    private func nearestPin(_ p: CGPoint) -> (Layer, PuppetPin)? {
        var best: (Layer, PuppetPin, CGFloat)? = nil
        for s in pinLayers {
            guard let pp = s.puppet else { continue }
            let m = Xf.matrix(s, Editor.time); let (qw, qh) = Xf.quadSize(s)
            for pin in pp.pins {
                let o = pinOffset(s, pin, Editor.time)
                let c = toScr(m, (pin.rx + o.0) * qw / 2, (pin.ry + o.1) * qh / 2)
                let d = hypot(c.x - p.x, c.y - p.y)
                if d < 30 && d < (best?.2 ?? .infinity) { best = (s, pin, d) }
            }
        }
        return best.map { ($0.0, $0.1) }
    }

    private func brush(_ from: (Float, Float), _ to: (Float, Float)) {
        let dx = to.0 - from.0, dy = to.1 - from.1
        let t = Editor.time
        for l in pinLayers {
            guard let pp = l.puppet, let inv = Xf.invert(Xf.matrix(l, t)) else { continue }
            let m = Xf.matrix(l, t); let (qw, qh) = Xf.quadSize(l)
            let o0 = Xf.apply(inv, 0, 0), o1 = Xf.apply(inv, dx, dy)
            let lx = o1.0 - o0.0, ly = o1.1 - o0.1
            for pin in pp.pins {
                let o = pinOffset(l, pin, t)
                let w = Xf.apply(m, (pin.rx + o.0) * qw / 2, (pin.ry + o.1) * qh / 2)
                let d = hypot(w.0 - from.0, w.1 - from.1)
                if d >= brushR { continue }
                let f = (1 - d / brushR); let k = f * f * brushK
                let kx = "pp\(pin.id)x", ky = "pp\(pin.id)y"
                setLive(l, kx, curOff(l, kx) + lx / (qw / 2) * k)
                setLive(l, ky, curOff(l, ky) + ly / (qh / 2) * k)
            }
        }
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard touches.count == 1, let tc = touches.first else { return }
        let p = tc.location(in: self)
        let sel = members.first { $0.id == selId }
        if mode == 2 {
            if let w = lay(warpId), let wp = w.warp, let k = nearestWarp(p), let q = local(w, p) {
                dragWarp = k; warpStartQ = q; onBeginEdit?()
                warpStartOff = (0..<(wp.n * wp.n)).flatMap { [w.p("wx\($0)", Editor.time), w.p("wy\($0)", Editor.time)] }
                setNeedsDisplay(); return
            }
        }
        let paint = (mode == 3 && tool == 1)
        if paint {
            guard !pinLayers.isEmpty else { return }
            brushing = true; brushPt = p; lastW = world(p); onBeginEdit?(); setNeedsDisplay(); return
        }
        if mode == 3 {
            if tool == 2, let s = sel, let q = local(s, p) {
                let (qw, qh) = Xf.quadSize(s)
                let rx = q.0 / (qw / 2), ry = q.1 / (qh / 2)
                if abs(rx) <= 1, abs(ry) <= 1 { onAdd?(s, rx, ry) }
                return
            }
            if tool == 3 { if let b = nearestPin(p) { onDel?(b.0, b.1) }; return }
            if let b = nearestPin(p) { dragPin = b; onBeginEdit?(); setNeedsDisplay(); return }
        }
        if mode == 4, let s = sel, hypot(pivotScreen(s).x - p.x, pivotScreen(s).y - p.y) < 30 {
            dragPivot = true; onBeginEdit?(); return
        }
        for l in members.reversed() where l.type == .IMAGE && shown(l) {
            let (qw, qh) = Xf.quadSize(l)
            if let q = local(l, p), abs(q.0) <= qw / 2, abs(q.1) <= qh / 2 { onSelect?(l.id); return }
        }
        onSelect?(-1)
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard touches.count == 1, let tc = touches.first else { return }
        let p = tc.location(in: self)
        if dragWarp >= 0, let w = lay(warpId), let wp = w.warp, let q = local(w, p) {
            let n = wp.n, t = Editor.time
            let dx = q.0 - warpStartQ.0, dy = q.1 - warpStartQ.1
            let ki = dragWarp % n, kj = dragWarp / n
            for j in 0..<(n * n) {
                let dist = Float(hypot(Double(j % n - ki), Double(j / n - kj)))
                let f: Float = j == dragWarp ? 1 : (softR > 0.01 ? max(0, 1 - dist / softR) : 0)
                if f <= 0 { continue }
                let w2 = f * f
                setLive(w, "wx\(j)", warpStartOff[2 * j] + dx * w2 - (w.props["wx\(j)"]?.eval(t) ?? 0))
                setLive(w, "wy\(j)", warpStartOff[2 * j + 1] + dy * w2 - (w.props["wy\(j)"]?.eval(t) ?? 0))
            }
            setNeedsDisplay(); return
        }
        if brushing {
            let w = world(p); brush(lastW, w); lastW = w; brushPt = p; setNeedsDisplay(); return
        }
        if let (s, pin) = dragPin, let q = local(s, p) {
            let (qw, qh) = Xf.quadSize(s)
            let t = Editor.time
            let bx = s.props["pp\(pin.id)x"]?.eval(t) ?? 0, by = s.props["pp\(pin.id)y"]?.eval(t) ?? 0
            setLive(s, "pp\(pin.id)x", q.0 / (qw / 2) - pin.rx - bx)
            setLive(s, "pp\(pin.id)y", q.1 / (qh / 2) - pin.ry - by)
        } else if dragPivot, let s = members.first(where: { $0.id == selId }), let q = local(s, p) {
            let (qw, qh) = Xf.quadSize(s)
            onPivot?(s, min(100, max(0, q.0 / qw * 100 + 50)), min(100, max(0, 50 - q.1 / qh * 100)))
        }
        setNeedsDisplay()
    }

    private func finish(commit: Bool) {
        let l = live, s = start
        live = [:]; start = [:]; dragPin = nil; dragWarp = -1; dragPivot = false; brushing = false; brushPt = nil
        if commit && !l.isEmpty { onCommit?(l, s) }
        setNeedsDisplay()
    }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) { finish(commit: true) }
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) { finish(commit: false) }
}

// MARK: - controller

final class RigRowCell: UITableViewCell {
    let chev = UIButton(type: .system), icon = UIImageView(), name = UILabel()
    let eye = UIButton(type: .system), more = UIButton(type: .system)
    var indent: NSLayoutConstraint!
    var onChev: (() -> Void)?, onEye: (() -> Void)?, onMore: (() -> Void)?
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .clear; selectionStyle = .none
        name.font = .systemFont(ofSize: 14); name.lineBreakMode = .byTruncatingTail
        icon.contentMode = .scaleAspectFit
        for (b, n) in [(chev, "chevron.down"), (eye, "eye"), (more, "ellipsis")] {
            b.setImage(UIImage(systemName: n), for: .normal); b.tintColor = argbToUIColor(C.DIM)
        }
        chev.addAction(UIAction { [unowned self] _ in self.onChev?() }, for: .touchUpInside)
        eye.addAction(UIAction { [unowned self] _ in self.onEye?() }, for: .touchUpInside)
        more.addAction(UIAction { [unowned self] _ in self.onMore?() }, for: .touchUpInside)
        let v = [chev, icon, name, eye, more] as [UIView]
        for x in v { x.translatesAutoresizingMaskIntoConstraints = false; contentView.addSubview(x) }
        indent = chev.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 6)
        NSLayoutConstraint.activate([
            indent, chev.widthAnchor.constraint(equalToConstant: 26), chev.heightAnchor.constraint(equalToConstant: 34),
            chev.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            icon.leadingAnchor.constraint(equalTo: chev.trailingAnchor, constant: 2),
            icon.widthAnchor.constraint(equalToConstant: 18), icon.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            name.leadingAnchor.constraint(equalTo: icon.trailingAnchor, constant: 6),
            name.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            name.trailingAnchor.constraint(lessThanOrEqualTo: eye.leadingAnchor, constant: -4),
            more.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -6),
            more.widthAnchor.constraint(equalToConstant: 34), more.heightAnchor.constraint(equalToConstant: 34),
            more.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            eye.trailingAnchor.constraint(equalTo: more.leadingAnchor),
            eye.widthAnchor.constraint(equalToConstant: 34), eye.heightAnchor.constraint(equalToConstant: 34),
            eye.centerYAnchor.constraint(equalTo: contentView.centerYAnchor)])
    }
    required init?(coder: NSCoder) { fatalError() }
}

final class RigEditorViewController: UIViewController {
    private let groupId: Int
    private let fallbackGroup: Layer
    private var group: Layer { Editor.scene.layers.first { $0.id == groupId } ?? fallbackGroup }
    private weak var host: EditorViewController?
    private var curTab = 0                        // 0 layers, 1 warp, 2 mesh, 3 transform
    private var selId = -1
    private var selWarp = -1
    private var activeParam = -1
    private var tool = 0
    private var gridN = 4
    private var softR: Float = 1.5
    private var brushR: Float = 0.25
    private var brushK: Float = 1
    private let canvas = RigCanvas()
    private let stack = UIStackView()
    private let scroll = UIScrollView()
    private let layerTable = UITableView(frame: .zero, style: .plain)
    private let addBar = UIStackView()
    private var treeRows: [(Layer, Int)] = []
    private var collapsed = Set<Int>()
    private var dragId = -1
    private var tabButtons: [UIButton] = []
    private var paramSlider: RulerSlider?
    private var keyBar: KeyBar?
    private var rig: Rig { group.rig! }

    init(group: Layer, host: EditorViewController) {
        self.groupId = group.id; self.fallbackGroup = group; self.host = host
        super.init(nibName: nil, bundle: nil)
        modalPresentationStyle = .fullScreen
        activeParam = group.rig?.params.first?.id ?? -1
    }
    required init?(coder: NSCoder) { fatalError() }

    override var prefersStatusBarHidden: Bool { false }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = argbToUIColor(C.BG)
        let done = btn("Done", C.GREEN, C.BG) { [weak self] in self?.close() }
        let undo = iconBtn("arrow.uturn.backward") { [weak self] in self?.host?.doUndo(); self?.afterRestore() }
        let redo = iconBtn("arrow.uturn.forward") { [weak self] in self?.host?.doRedo(); self?.afterRestore() }
        let title = UILabel(); title.text = "Cubism — \(group.name)"
        title.textColor = argbToUIColor(C.TEXT); title.font = .systemFont(ofSize: 15, weight: .bold)
        title.adjustsFontSizeToFitWidth = true; title.minimumScaleFactor = 0.7
        let top = UIStackView(arrangedSubviews: [title, UIView(), undo, redo, done]); top.alignment = .center; top.spacing = 8
        let names = ["Layers", "Warp", "Mesh", "Move", "Physics"]
        let tabs = UIStackView(); tabs.distribution = .fillEqually; tabs.spacing = 5
        for (i, n) in names.enumerated() {
            let b = btn(n) { [weak self] in self?.curTab = i; self?.reload() }
            b.titleLabel?.font = .systemFont(ofSize: 13, weight: .semibold)
            b.titleLabel?.adjustsFontSizeToFitWidth = true; b.titleLabel?.minimumScaleFactor = 0.7
            b.contentEdgeInsets = UIEdgeInsets(top: 8, left: 4, bottom: 8, right: 4)
            tabButtons.append(b); tabs.addArrangedSubview(b)
        }
        canvas.group = group
        canvas.onSelect = { [weak self] id in
            guard let self = self else { return }
            self.selId = id
            self.reload()
        }
        canvas.onBeginEdit = { [weak self] in self?.host?.pushUndo() }
        canvas.onCommit = { [weak self] live, start in self?.commit(live, start) }
        canvas.onAdd = { [weak self] l, rx, ry in self?.addPin(l, rx, ry) }
        canvas.onDel = { [weak self] l, pin in self?.delPin(l, pin) }
        canvas.onPivot = { [weak self] l, ax, ay in self?.host?.setAnchorKeepVisual(l, ax, ay); self?.host?.render() }
        stack.axis = .vertical; stack.spacing = 10
        scroll.addSubview(stack); scroll.alwaysBounceVertical = true
        strip.axis = .vertical; strip.spacing = 4
        // layer tree
        layerTable.backgroundColor = .clear; layerTable.separatorStyle = .none; layerTable.rowHeight = 38
        layerTable.dataSource = self; layerTable.delegate = self
        layerTable.dragDelegate = self; layerTable.dropDelegate = self; layerTable.dragInteractionEnabled = true
        layerTable.register(RigRowCell.self, forCellReuseIdentifier: "row")
        addBar.spacing = 6; addBar.distribution = .fillEqually
        for (t, k) in [("+ Folder", 0), ("+ Warp Deformer", 1), ("+ Rotate Deformer", 2)] {
            let b = btn(t, k == 0 ? C.CARD2 : C.GREEN, k == 0 ? C.TEXT : C.BG) { [weak self] in self?.newContainer(k) }
            b.titleLabel?.font = .systemFont(ofSize: 12, weight: .semibold)
            b.titleLabel?.adjustsFontSizeToFitWidth = true; b.titleLabel?.minimumScaleFactor = 0.6
            b.contentEdgeInsets = UIEdgeInsets(top: 6, left: 4, bottom: 6, right: 4)
            addBar.addArrangedSubview(b)
        }
        for v in [top, tabs, canvas, strip, addBar, layerTable, scroll] as [UIView] { v.translatesAutoresizingMaskIntoConstraints = false; view.addSubview(v) }
        stack.translatesAutoresizingMaskIntoConstraints = false
        let g = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            top.topAnchor.constraint(equalTo: g.topAnchor, constant: 6),
            top.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 12),
            top.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -12),
            canvas.topAnchor.constraint(equalTo: top.bottomAnchor, constant: 8),
            canvas.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            canvas.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            canvas.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.30),
            strip.topAnchor.constraint(equalTo: canvas.bottomAnchor, constant: 6),
            strip.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 12),
            strip.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -12),
            tabs.topAnchor.constraint(equalTo: strip.bottomAnchor, constant: 8),
            tabs.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 12),
            tabs.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -12),
            addBar.topAnchor.constraint(equalTo: tabs.bottomAnchor, constant: 6),
            addBar.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 12),
            addBar.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -12),
            layerTable.topAnchor.constraint(equalTo: addBar.bottomAnchor, constant: 4),
            layerTable.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            layerTable.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            layerTable.bottomAnchor.constraint(equalTo: g.bottomAnchor),
            scroll.topAnchor.constraint(equalTo: tabs.bottomAnchor, constant: 8),
            scroll.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scroll.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scroll.bottomAnchor.constraint(equalTo: g.bottomAnchor),
            stack.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor),
            stack.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor, constant: -30),
            stack.leadingAnchor.constraint(equalTo: scroll.frameLayoutGuide.leadingAnchor, constant: 12),
            stack.trailingAnchor.constraint(equalTo: scroll.frameLayoutGuide.trailingAnchor, constant: -12),
            stack.widthAnchor.constraint(equalTo: scroll.frameLayoutGuide.widthAnchor, constant: -24)])
        reload()
    }

    private func close() {
        stopPreview()
        dismiss(animated: true) { [weak host] in host?.refreshToolbar(); host?.refreshPanel(); host?.render() }
    }

    /// After host undo/redo the whole project was rebuilt: re-resolve everything by id.
    private func afterRestore() {
        guard Editor.scene.layers.contains(where: { $0.id == groupId && $0.rig != nil }) else { close(); return }
        if rig.param(activeParam) == nil { activeParam = rig.params.first?.id ?? -1 }
        if layer(selId) == nil { selId = -1 }
        reload(); redraw()
    }

    // MARK: helpers
    private func btn(_ title: String, _ fill: Int32 = C.CARD2, _ tc: Int32 = C.TEXT, _ act: @escaping () -> Void) -> UIButton {
        let b = UIButton(type: .system)
        b.setTitle(title, for: .normal); b.setTitleColor(argbToUIColor(tc), for: .normal)
        b.titleLabel?.font = .systemFont(ofSize: 14, weight: .semibold)
        b.backgroundColor = argbToUIColor(fill); b.layer.cornerRadius = 10
        b.contentEdgeInsets = UIEdgeInsets(top: 8, left: 12, bottom: 8, right: 12)
        b.addAction(UIAction { _ in act() }, for: .touchUpInside)
        b.heightAnchor.constraint(greaterThanOrEqualToConstant: 38).isActive = true
        return b
    }
    private func iconBtn(_ sym: String, _ act: @escaping () -> Void) -> UIButton {
        let b = UIButton(type: .system)
        b.setImage(UIImage(systemName: sym), for: .normal); b.tintColor = argbToUIColor(C.TEXT)
        b.backgroundColor = argbToUIColor(C.CARD2); b.layer.cornerRadius = 10
        b.addAction(UIAction { _ in act() }, for: .touchUpInside)
        b.widthAnchor.constraint(equalToConstant: 40).isActive = true
        b.heightAnchor.constraint(equalToConstant: 38).isActive = true
        return b
    }
    private func lbl(_ s: String, _ size: CGFloat = 14, _ color: Int32 = C.TEXT, bold: Bool = false) -> UILabel {
        let l = UILabel(); l.text = s; l.numberOfLines = 0; l.textColor = argbToUIColor(color)
        l.font = .systemFont(ofSize: size, weight: bold ? .bold : .regular); return l
    }
    private func slider(_ name: String, _ lo: Float, _ hi: Float, _ v: Float, _ dec: Int = 2,
                        _ change: @escaping (Float) -> Void) -> RulerSlider {
        let s = RulerSlider(frame: .zero)
        s.label = name; s.lo = lo; s.hi = hi; s.dec = dec; s.value = v; s.canKey = false
        s.onBegin = { [weak self] in self?.host?.pushUndo() }
        s.onChange = change
        s.heightAnchor.constraint(equalToConstant: 60).isActive = true
        return s
    }
    private func chips(_ names: [String], _ sel: Int, _ act: @escaping (Int) -> Void) -> UIStackView {
        let s = UIStackView(); s.distribution = .fillEqually; s.spacing = 6
        for (i, n) in names.enumerated() {
            let b = btn(n, i == sel ? C.GREEN : C.CARD2, i == sel ? C.BG : C.TEXT) { act(i) }
            b.titleLabel?.adjustsFontSizeToFitWidth = true; b.titleLabel?.minimumScaleFactor = 0.7
            b.contentEdgeInsets = UIEdgeInsets(top: 8, left: 4, bottom: 8, right: 4)
            s.addArrangedSubview(b)
        }
        return s
    }
    private func toggleRow(_ title: String, _ on: Bool, _ change: @escaping (Bool) -> Void) -> UIView {
        let sw = UISwitch(); sw.isOn = on; sw.onTintColor = argbToUIColor(C.GREEN)
        sw.addAction(UIAction { [unowned sw] _ in change(sw.isOn) }, for: .valueChanged)
        let r = UIStackView(arrangedSubviews: [lbl(title, 14), UIView(), sw]); r.alignment = .center
        return r
    }
    private func ask(_ title: String, _ items: [String], _ pick: @escaping (Int) -> Void) {
        _ = Dlg(self).setTitle(title).setItems(items) { _, i in pick(i) }.show()
    }
    private func confirm(_ title: String, _ msg: String, _ ok: @escaping () -> Void) {
        _ = Dlg(self).setTitle(title).setMessage(msg)
            .setPositiveButton("Yes") { _, _ in ok() }.setNegativeButton("Cancel", nil).show()
    }
    private func textField(_ ph: String, _ text: String, _ num: Bool = false) -> UITextField {
        let f = UITextField(); f.placeholder = ph; f.text = text
        f.textColor = argbToUIColor(C.TEXT); f.backgroundColor = argbToUIColor(C.CARD2)
        f.layer.cornerRadius = 8; f.keyboardType = num ? .numbersAndPunctuation : .default
        f.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: 10)); f.leftViewMode = .always
        f.heightAnchor.constraint(equalToConstant: 40).isActive = true; return f
    }
    private func textDialog(_ title: String, _ initial: String, _ ok: @escaping (String) -> Void) {
        let f = textField("Name", initial)
        _ = Dlg(self).setTitle(title).setView(f)
            .setPositiveButton("OK") { _, _ in ok((f.text ?? "").isEmpty ? initial : f.text!) }
            .setNegativeButton("Cancel", nil).show()
    }
    private func fmt(_ v: Float) -> String { String(format: "%.2f", v) }
    private func card(_ views: [UIView]) -> UIView {
        let c = UIView(); c.backgroundColor = argbToUIColor(C.CARD); c.layer.cornerRadius = 12
        let s = UIStackView(arrangedSubviews: views); s.axis = .vertical; s.spacing = 6
        s.translatesAutoresizingMaskIntoConstraints = false; c.addSubview(s)
        NSLayoutConstraint.activate([s.topAnchor.constraint(equalTo: c.topAnchor, constant: 10),
            s.bottomAnchor.constraint(equalTo: c.bottomAnchor, constant: -10),
            s.leadingAnchor.constraint(equalTo: c.leadingAnchor, constant: 10),
            s.trailingAnchor.constraint(equalTo: c.trailingAnchor, constant: -10)])
        return c
    }
    private func members() -> [Layer] { Editor.scene.layers.filter { rig.members.contains($0.id) } }
    private func layer(_ id: Int) -> Layer? { Editor.scene.layers.first { $0.id == id } }
    private var sel: Layer? { rig.members.contains(selId) ? layer(selId) : nil }
    private var active: RigParam? { rig.param(activeParam) }
    private var warpLayer: Layer? {
        if let s = sel, s.deformer == 1 { return s }
        if let w = layer(selWarp), w.deformer == 1, rig.members.contains(w.id) { return w }
        return members().first { $0.deformer == 1 }
    }
    private var hostRenderPending = false
    private func redraw() {
        canvas.setNeedsDisplay()
        if hostRenderPending { return }                      // coalesce the expensive main-preview render
        hostRenderPending = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.12) { [weak self] in
            self?.hostRenderPending = false; self?.host?.render()
        }
    }

    static let propList: [(String, String)] = [("Position X", "x"), ("Position Y", "y"),
                                               ("Rotate", "rotZ"), ("Scale", "scale"), ("Opacity", "opacity")]
    private func propName(_ k: String) -> String {
        if let p = Self.propList.first(where: { $0.1 == k }) { return p.0 }
        return k.hasPrefix("pp") ? "Mesh pin " + k.dropFirst(2) : k
    }
    private func propRange(_ k: String) -> (Float, Float) {
        switch k { case "rotZ": return (-180, 180); case "opacity", "scale": return (-1, 1); default: return (-2, 2) }
    }

    // MARK: panel
    private func reload() {
        guard Editor.scene.layers.contains(where: { $0.id == groupId && $0.rig != nil }) else { return }
        Rig.syncMembers(Editor.scene.layers)
        canvas.group = group
        for (i, b) in tabButtons.enumerated() {
            b.backgroundColor = argbToUIColor(i == curTab ? C.GREEN : C.CARD2)
            b.setTitleColor(argbToUIColor(i == curTab ? C.BG : C.TEXT), for: .normal)
        }
        if curTab != 4 { stopPreview() }
        canvas.mode = curTab + 1                  // canvas: 1 layers, 2 warp, 3 mesh, 4 transform, 5 physics
        canvas.selId = selId
        canvas.tool = tool; canvas.brushR = brushR; canvas.brushK = brushK; canvas.softR = softR
        canvas.warpId = warpLayer?.id ?? -1
        canvas.targets = curTab == 2 ? (sel.map { [$0.id] } ?? []) : []
        layerTable.isHidden = curTab != 0; addBar.isHidden = curTab != 0; scroll.isHidden = curTab == 0
        rebuildStrip()
        reloadPanel()
        canvas.setNeedsDisplay()
    }

    private func reloadPanel() {
        let keepY = scroll.contentOffset.y
        for v in stack.arrangedSubviews { stack.removeArrangedSubview(v); v.removeFromSuperview() }
        switch curTab {
        case 0: buildLayers()
        case 1: buildWarp()
        case 2: buildMesh()
        case 3: buildTransform()
        default: buildPhysics()
        }
        view.layoutIfNeeded()
        scroll.contentOffset.y = min(keepY, max(0, scroll.contentSize.height - scroll.bounds.height))
    }

    // ---- parameter strip (always visible, Live2D style: pick a pose, then edit anything)

    private let strip = UIStackView()
    private var keyBtn: UIButton?
    private var keyInfo: UILabel?
    private static let keyedProps = ["opacity", "x", "y", "rotZ", "scale"]

    /// Layers whose keys the strip shows / edits: folder layers, the selected layer, or everything.
    private func keyTargets() -> [Int] {
        if curTab == 1, let w = warpLayer { return [w.id] }
        if let l = sel { return [l.id] }
        return members().map { $0.id }
    }

    private func keyValues(_ p: RigParam, _ ids: [Int]) -> [Float] {
        var out: [Float] = []
        for b in rig.bindings where b.paramId == p.id && ids.contains(b.layerId) {
            for k in b.keys where !out.contains(where: { abs($0 - k.0) < 1e-3 }) { out.append(k.0) }
        }
        return out.sorted()
    }

    private func rebuildStrip() {
        for v in strip.arrangedSubviews { strip.removeArrangedSubview(v); v.removeFromSuperview() }
        paramSlider = nil; keyBar = nil; keyBtn = nil; keyInfo = nil
        let pick = btn(active.map { "Parameter: \($0.name)  ▾" } ?? "＋ Add a parameter") { [weak self] in self?.paramMenu() }
        guard let p = active else {
            strip.addArrangedSubview(pick)
            strip.addArrangedSubview(lbl("Start here: add a parameter (Eye open/close, Mouth, Angle X…). Then pick a pose on it and edit — keys are created for you.", 12, C.DIM))
            return
        }
        let kbtn = btn("+ Key", C.GREEN, C.BG) { [weak self] in self?.toggleKey() }
        kbtn.widthAnchor.constraint(equalToConstant: 92).isActive = true
        keyBtn = kbtn
        let del = iconBtn("trash") { [weak self] in self?.deleteParam(p) }
        let row = UIStackView(arrangedSubviews: [pick, kbtn, del]); row.spacing = 8
        strip.addArrangedSubview(row)
        let s = slider(p.name, p.lo, p.hi, rig.value(p, group, Editor.time)) { [weak self] v in
            guard let self = self else { return }
            self.group.track(p.key).set(Editor.time, v, false)
            self.refreshKeyState()
            if self.curTab == 3 { self.reloadPanel() }
            self.redraw()
        }
        paramSlider = s; strip.addArrangedSubview(s)
        let kb = KeyBar(frame: .zero)
        kb.lo = p.lo; kb.hi = p.hi
        kb.onPick = { [weak self] v in self?.setParam(p, v) }
        kb.heightAnchor.constraint(equalToConstant: 40).isActive = true
        keyBar = kb; strip.addArrangedSubview(kb)
        let info = lbl("", 12, C.DIM); keyInfo = info; strip.addArrangedSubview(info)
        refreshKeyState()
    }

    private func refreshKeyState() {
        guard let p = active else { return }
        let ids = keyTargets()
        let pv = rig.value(p, group, Editor.time)
        let keys = keyValues(p, ids)
        let on = keys.contains { abs($0 - pv) < 1e-3 }
        keyBar?.value = pv; keyBar?.keys = keys; keyBar?.setNeedsDisplay()
        keyBtn?.setTitle(on ? "− Key" : "+ Key", for: .normal)
        keyBtn?.setTitleColor(argbToUIColor(on ? C.TEXT : C.BG), for: .normal)
        keyBtn?.backgroundColor = argbToUIColor(on ? C.CARD2 : C.GREEN)
        let hint = (p.lo == 0 && p.hi == 1) ? "  (0 = closed, 1 = open)" : ""
        keyInfo?.text = (on ? "◇ Key selected at \(fmt(pv)) — edit below to change it." : "No key at \(fmt(pv)) — edit below or press + Key to create one.") + hint
    }

    private func setParam(_ p: RigParam, _ v: Float) {
        group.track(p.key).set(Editor.time, v, false)
        paramSlider?.value = v
        refreshKeyState()
        if curTab == 3 { reloadPanel() }
        redraw()
    }

    private func toggleKey() {
        guard let p = active else { return }
        let ids = keyTargets()
        let pv = rig.value(p, group, Editor.time)
        host?.pushUndo()
        if keyValues(p, ids).contains(where: { abs($0 - pv) < 1e-3 }) {
            for b in rig.bindings where b.paramId == p.id && ids.contains(b.layerId) {
                b.keys.removeAll { abs($0.0 - pv) < 1e-3 }
            }
            rig.bindings.removeAll { $0.keys.isEmpty }
        } else {
            for id in ids {
                var keys = Self.keyedProps
                if let w = layer(id), w.deformer == 1, let wp = w.warp {
                    keys = (0..<(wp.n * wp.n)).flatMap { ["wx\($0)", "wy\($0)"] }
                }
                if let pp = layer(id)?.puppet { for pin in pp.pins { keys.append("pp\(pin.id)x"); keys.append("pp\(pin.id)y") } }
                for k in keys { if let b = rig.binding(p, id, k, create: true) { b.setKey(pv, b.eval(pv)) } }
            }
        }
        reload(); redraw()
    }

    /// Canvas drag / brush finished: store the change as a keyform at the current parameter value.
    private func commit(_ live: [Int: [String: Float]], _ start: [Int: [String: Float]]) {
        guard let p = active else { host?.toast("Add a parameter first"); redraw(); return }
        let pv = rig.value(p, group, Editor.time)
        for (lid, d) in live {
            for (k, v) in d {
                let delta = v - (start[lid]?[k] ?? 0)
                if abs(delta) < 1e-5 { continue }
                guard let b = rig.binding(p, lid, k, create: true) else { continue }
                b.setKey(pv, b.eval(pv) + delta)
            }
        }
        refreshKeyState()
        if curTab == 3 { reloadPanel() }
        redraw()
    }

    private func paramMenu() {
        let names = rig.params.map { $0.name }
        ask("Parameters", names + ["＋ New parameter", "Rename current", "Delete current"]) { [weak self] i in
            guard let self = self else { return }
            if i < names.count { self.activeParam = self.rig.params[i].id; self.reload(); return }
            if i == names.count { self.addParamPreset(); return }
            guard let p = self.active else { return }
            if i == names.count + 1 { self.textDialog("Rename parameter", p.name) { p.name = $0; self.reload() }; return }
            self.deleteParam(p)
        }
    }

    private func deleteParam(_ p: RigParam) {
        confirm("Delete \(p.name)?", "Its keys are removed too. You can undo this.") { [weak self] in
            guard let self = self else { return }
            self.host?.pushUndo()
            self.rig.params.removeAll { $0.id == p.id }
            self.rig.bindings.removeAll { $0.paramId == p.id }
            self.group.props[p.key] = nil
            self.activeParam = self.rig.params.first?.id ?? -1
            self.reload(); self.redraw()
        }
    }

    private func addParamPreset() {
        let presets: [(String, Float, Float, Float)] = [
            ("Eye L open/close", 0, 1, 1), ("Eye R open/close", 0, 1, 1), ("Mouth open/close", 0, 1, 0),
            ("Angle X", -30, 30, 0), ("Angle Y", -30, 30, 0), ("Angle Z", -30, 30, 0), ("Breath", 0, 1, 0)]
        ask("New parameter", presets.map { $0.0 } + ["Custom…"]) { [weak self] i in
            guard let self = self else { return }
            if i >= presets.count { self.addParamDialog(); return }
            let q = presets[i]
            self.host?.pushUndo()
            self.activeParam = self.rig.addParam(q.0, q.1, q.2, q.3, on: self.group).id
            self.reload()
        }
    }

    private func addParamDialog() {
        let n = textField("Name", "Param \(rig.nextId)")
        let lo = textField("Min", "-30", true), hi = textField("Max", "30", true), df = textField("Default", "0", true)
        let sv = UIStackView(arrangedSubviews: [n, lo, hi, df]); sv.axis = .vertical; sv.spacing = 8
        _ = Dlg(self).setTitle("New parameter").setView(sv)
            .setPositiveButton("Add") { [weak self] _, _ in
                guard let self = self else { return }
                var a = Float(lo.text ?? "") ?? -30, b = Float(hi.text ?? "") ?? 30
                if a > b { swap(&a, &b) }
                if b - a < 0.001 { b = a + 1 }
                let d = min(b, max(a, Float(df.text ?? "") ?? 0))
                self.host?.pushUndo()
                let p = self.rig.addParam((n.text ?? "").isEmpty ? "Param" : n.text!, a, b, d, on: self.group)
                self.activeParam = p.id
                self.reload()
            }.setNegativeButton("Cancel", nil).show()
    }

    // ---- layers tab: compact tree, drag a row onto a folder / deformer to move it in
    private func isContainer(_ l: Layer) -> Bool { l.type == .GROUP }
    private func isInside(_ x: Layer?, _ anc: Layer) -> Bool {
        var cur = x; var n = 0
        while let c = cur, n < 64 { if c.id == anc.id { return true }; cur = layer(c.parentId); n += 1 }
        return false
    }
    private func rebuildTree() {
        treeRows = []
        func walk(_ pid: Int, _ d: Int) {
            for l in Editor.scene.layers.reversed() where l.parentId == pid && l.id != groupId {
                treeRows.append((l, d))
                if isContainer(l) && !collapsed.contains(l.id) && d < 12 { walk(l.id, d + 1) }
            }
        }
        walk(groupId, 0)
        let e = lbl("Empty. Add a folder or deformer above, or put layers under this rig group in the timeline.", 13, C.DIM)
        e.textAlignment = .center
        layerTable.backgroundView = treeRows.isEmpty ? e : nil
        layerTable.reloadData()
    }
    private func buildLayers() { rebuildTree() }

    private func newContainer(_ kind: Int) {
        host?.pushUndo()
        let s = Editor.scene, p = Editor.project
        let id = p.nextId; p.nextId += 1
        let nm = ["Folder", "Warp Deformer", "Rotate Deformer"][kind]
        let n = s.layers.filter { $0.type == .GROUP && $0.rig == nil && $0.deformer == kind }.count + 1
        let l = Layer(id, "\(nm) \(n)", .GROUP)
        l.end = s.duration; l.deformer = kind
        if kind == 1 { l.warp = Warp() }
        var par = groupId
        if let sl = sel { par = sl.type == .GROUP ? sl.id : (rig.members.contains(sl.parentId) ? sl.parentId : groupId) }
        l.parentId = par
        s.layers.append(l)
        collapsed.remove(par); selId = l.id
        if kind == 1 { selWarp = l.id; fitWarp(l) }
        reload(); redraw()
    }

    private func fitWarp(_ w: Layer) {
        guard let wp = w.warp, let inv = Xf.invert(Xf.matrix(w, Editor.time)) else { return }
        var x0 = Float.infinity, y0 = Float.infinity, x1 = -Float.infinity, y1 = -Float.infinity
        for l in Rig.descendants(w, Editor.scene.layers) where l.type == .IMAGE {
            let m = Xf.matrix(l, Editor.time); let (qw, qh) = Xf.quadSize(l)
            for (cx, cy) in [(-1, -1), (1, -1), (1, 1), (-1, 1)] as [(Float, Float)] {
                let wp2 = Xf.apply(m, cx * qw / 2, cy * qh / 2); let q = Xf.apply(inv, wp2.0, wp2.1)
                x0 = min(x0, q.0); x1 = max(x1, q.0); y0 = min(y0, q.1); y1 = max(y1, q.1)
            }
        }
        guard x0.isFinite else { return }
        let pad = 0.04 * max(x1 - x0, y1 - y0)
        wp.bx = x0 - pad; wp.by = y0 - pad; wp.bw = max(x1 - x0 + 2 * pad, 0.05); wp.bh = max(y1 - y0 + 2 * pad, 0.05)
    }

    /// Image layers inside a warp deformer need a mesh to be bent; build one and fit the grid.
    private func prepareWarps(for l: Layer) {
        var cur: Layer? = l; var n = 0
        while let c = cur, n < 32 {
            if c.deformer == 1 {
                for i in Rig.descendants(c, Editor.scene.layers) where i.type == .IMAGE && (i.puppet?.pins.isEmpty ?? true) { buildGrid(i, 9) }
                if !rig.bindings.contains(where: { $0.layerId == c.id }) { fitWarp(c) }
            }
            cur = layer(c.parentId); n += 1
        }
    }

    private func layerMenu(_ l: Layer) {
        var items = ["Rename", "Move to…", "Take out of rig"]
        if isContainer(l) { items.append("Delete (keep contents)") }
        ask(l.name, items) { [weak self] i in
            guard let self = self else { return }
            switch i {
            case 0: self.textDialog("Rename", l.name) { l.name = $0; self.reload() }
            case 1:
                let c = self.members().filter { self.isContainer($0) && !self.isInside($0, l) }
                self.ask("Move \(l.name) to", ["Rig root"] + c.map { $0.name }) { j in
                    self.host?.pushUndo()
                    l.parentId = j == 0 ? self.groupId : c[j - 1].id
                    if j > 0 { self.collapsed.remove(c[j - 1].id) }
                    self.prepareWarps(for: l); self.reload(); self.redraw()
                }
            case 2:
                self.host?.pushUndo(); l.parentId = -1
                if self.selId == l.id { self.selId = -1 }
                self.reload(); self.redraw()
            default:
                self.host?.pushUndo()
                for c in Editor.scene.layers where c.parentId == l.id { c.parentId = l.parentId }
                self.rig.removeLayer(l.id)
                Editor.scene.layers.removeAll { $0.id == l.id }
                if self.selId == l.id { self.selId = -1 }
                self.reload(); self.redraw()
            }
        }
    }

    // ---- mesh building blocks

    private func hasKeys(_ l: Layer) -> Bool { rig.bindings.contains { $0.layerId == l.id && $0.key.hasPrefix("pp") } }

    private func buildGrid(_ l: Layer, _ n: Int) {
        let pu = l.puppet ?? Puppet()
        for pin in pu.pins { l.props["pp\(pin.id)x"] = nil; l.props["pp\(pin.id)y"] = nil }
        rig.bindings.removeAll { $0.layerId == l.id && $0.key.hasPrefix("pp") }
        pu.pins.removeAll(); pu.on = true
        let d = max(n - 1, 1)
        for j in 0..<n { for i in 0..<n {
            pu.pins.append(PuppetPin(pu.nextId, -1 + 2 * Float(i) / Float(d), -1 + 2 * Float(j) / Float(d))); pu.nextId += 1 } }
        l.puppet = pu
    }

    private func gridStepper(_ apply: @escaping (Int) -> Void) -> UIView {
        let r = UIStackView(arrangedSubviews: [lbl("Mesh points: \(gridN)×\(gridN)", 14, C.TEXT, bold: true), UIView(),
            iconBtn("minus") { [weak self] in guard let self = self else { return }; self.gridN = max(2, self.gridN - 1); apply(self.gridN) },
            iconBtn("plus") { [weak self] in guard let self = self else { return }; self.gridN = min(14, self.gridN + 1); apply(self.gridN) }])
        r.spacing = 6; r.alignment = .center
        return r
    }

    private func detailChips(_ pp: Puppet) -> UIView {
        let c = card([lbl("Smoothness (render detail)", 13, C.DIM),
            chips(["Low", "Medium", "High", "Ultra"], pp.density) { [weak self] i in
                self?.host?.pushUndo(); pp.density = i; self?.reload(); self?.redraw() }])
        return c
    }

    private func brushSection() {
        stack.addArrangedSubview(slider("Brush size", 0.05, 1, brushR, 2) { [weak self] v in self?.brushR = v; self?.canvas.brushR = v })
        stack.addArrangedSubview(slider("Brush strength", 0.2, 2, brushK, 1) { [weak self] v in self?.brushK = v; self?.canvas.brushK = v })
    }

    // ---- physics (pendulums)
    private var previewTimer: Timer?
    private func stopPreview() { previewTimer?.invalidate(); previewTimer = nil }

    private func buildPhysics() {
        let on = previewTimer != nil
        stack.addArrangedSubview(btn(on ? "■ Stop preview" : "▶ Preview physics", on ? C.CARD2 : C.GREEN, on ? C.TEXT : C.BG) { [weak self] in
            guard let self = self else { return }
            if self.previewTimer != nil { self.stopPreview() }
            else {
                self.previewTimer = Timer.scheduledTimer(withTimeInterval: 1.0 / 30, repeats: true) { [weak self] _ in
                    guard let self = self else { return }
                    var t = Editor.time + 1.0 / 30
                    if t >= Editor.scene.duration { t = 0 }
                    Editor.time = t; self.canvas.setNeedsDisplay()
                }
            }
            self.reloadPanel()
        })
        stack.addArrangedSubview(lbl("A pendulum swings when its input parameter moves (or from wind) and adds to its output parameter. Key the output parameter (e.g. hair rotate at −1 / 0 / +1) in the other tabs.", 12, C.DIM))
        stack.addArrangedSubview(btn("＋ New pendulum", C.GREEN, C.BG) { [weak self] in self?.addPendulum() })
        for q in rig.phys {
            let inN = rig.param(q.inId)?.name ?? "None (wind only)", outN = rig.param(q.outId)?.name ?? "—"
            let head = UIStackView(arrangedSubviews: [lbl(q.name, 15, C.TEXT, bold: true), UIView(),
                toggleSw(q.on) { [weak self] v in self?.host?.pushUndo(); q.on = v; self?.redraw() },
                iconBtn("trash") { [weak self] in
                    guard let self = self else { return }
                    self.host?.pushUndo(); self.rig.phys.removeAll { $0.id == q.id }; self.reloadPanel(); self.redraw() }])
            head.spacing = 8; head.alignment = .center
            func sl(_ n: String, _ lo: Float, _ hi: Float, _ v: Float, _ d: Int, _ set: @escaping (Float) -> Void) -> UIView {
                slider(n, lo, hi, v, d) { [weak self] x in set(x); self?.redraw() }
            }
            stack.addArrangedSubview(card([head,
                btn("Input: \(inN)  ▾") { [weak self] in self?.pickPhysParam(q, input: true) },
                btn("Output: \(outN)  ▾") { [weak self] in self?.pickPhysParam(q, input: false) },
                sl("Length (short = fast)", 0.1, 2, q.length, 2) { q.length = $0 },
                sl("Damping", 0, 1, q.damping, 2) { q.damping = $0 },
                sl("Input strength", 0, 4, q.strength, 2) { q.strength = $0 },
                sl("Max angle (°)", 5, 90, q.maxDeg, 0) { q.maxDeg = $0 },
                sl("Output weight", 0, 2, q.weight, 2) { q.weight = $0 },
                sl("Wind", 0, 1, q.wind, 2) { q.wind = $0 }]))
        }
    }

    private func toggleSw(_ on: Bool, _ change: @escaping (Bool) -> Void) -> UISwitch {
        let sw = UISwitch(); sw.isOn = on; sw.onTintColor = argbToUIColor(C.GREEN)
        sw.addAction(UIAction { [unowned sw] _ in change(sw.isOn) }, for: .valueChanged)
        return sw
    }

    private func addPendulum() {
        let names = rig.params.map { $0.name }
        ask("Input parameter (what shakes it)", names + ["None — wind only"]) { [weak self] i in
            guard let self = self else { return }
            self.host?.pushUndo()
            let q = PhysGroup(self.rig.nextId, "Pendulum \(self.rig.phys.count + 1)"); self.rig.nextId += 1
            q.inId = i < names.count ? self.rig.params[i].id : -1
            if q.inId < 0 { q.wind = 0.5 }
            let o = self.rig.addParam("\(q.name) sway", -1, 1, 0, on: self.group)
            q.outId = o.id; self.activeParam = o.id
            self.rig.phys.append(q)
            self.reload(); self.redraw()
        }
    }

    private func pickPhysParam(_ q: PhysGroup, input: Bool) {
        let ps = rig.params
        ask(input ? "Input parameter" : "Output parameter", ps.map { $0.name } + (input ? ["None — wind only"] : [])) { [weak self] i in
            guard let self = self else { return }
            self.host?.pushUndo()
            let id = i < ps.count ? ps[i].id : -1
            if input { q.inId = id } else { q.outId = id }
            self.reloadPanel(); self.redraw()
        }
    }

    // ---- warp deformer
    private func buildWarp() {
        let ws = members().filter { $0.deformer == 1 }
        guard let w = warpLayer, let wp = w.warp else {
            stack.addArrangedSubview(lbl("No warp deformer yet. In the Layers tab tap “+ Warp Deformer”, then drag layers onto it.", 13, C.DIM))
            stack.addArrangedSubview(btn("Go to Layers", C.GREEN, C.BG) { [weak self] in self?.curTab = 0; self?.reload() })
            return
        }
        stack.addArrangedSubview(btn("Deformer: \(w.name)  ▾") { [weak self] in
            self?.ask("Warp deformer", ws.map { $0.name }) { i in self?.selWarp = ws[i].id; self?.selId = ws[i].id; self?.reload() } })
        stack.addArrangedSubview(lbl("Pick a pose above, then drag the green points on the canvas. Nearby points follow softly.", 12, C.DIM))
        let r = UIStackView(arrangedSubviews: [lbl("Grid: \(wp.n)×\(wp.n)", 14, C.TEXT, bold: true), UIView(),
            iconBtn("minus") { [weak self] in self?.setWarpN(w, wp.n - 1) },
            iconBtn("plus") { [weak self] in self?.setWarpN(w, wp.n + 1) }])
        r.spacing = 6; r.alignment = .center
        stack.addArrangedSubview(r)
        stack.addArrangedSubview(slider("Soft drag (cells)", 0, 3, softR, 1) { [weak self] v in self?.softR = v; self?.canvas.softR = v })
        let row = UIStackView(arrangedSubviews: [
            btn("Fit to layers") { [weak self] in
                guard let self = self else { return }
                self.host?.pushUndo(); self.fitWarp(w); self.redraw() },
            btn("Flatten this pose", C.CARD2, C.DIM) { [weak self] in
                guard let self = self, let p = self.active else { return }
                self.host?.pushUndo()
                let pv = self.rig.value(p, self.group, Editor.time)
                for b in self.rig.bindings where b.paramId == p.id && b.layerId == w.id { b.setKey(pv, 0) }
                self.reload(); self.redraw() }])
        row.spacing = 8; row.distribution = .fillEqually
        stack.addArrangedSubview(row)
        stack.addArrangedSubview(lbl("Layers inside get a mesh automatically. Tip: Rotate Deformers bend nothing — they spin their contents (Transform tab → Rotate).", 12, C.DIM))
    }

    private func setWarpN(_ w: Layer, _ n: Int) {
        guard let wp = w.warp else { return }
        let m = min(8, max(2, n)); if m == wp.n { return }
        host?.pushUndo(); wp.n = m
        rig.bindings.removeAll { $0.layerId == w.id && ($0.key.hasPrefix("wx") || $0.key.hasPrefix("wy")) }
        reload(); redraw()
    }

    // ---- mesh
    private func buildMesh() {
        let imgs = members().filter { $0.type == .IMAGE }
        guard !imgs.isEmpty else { stack.addArrangedSubview(lbl("Import an image layer into this rig first.", 13, C.DIM)); return }
        guard let l = sel, l.type == .IMAGE else {
            stack.addArrangedSubview(lbl("Select an image layer: tap it in the canvas or pick it here.", 13, C.DIM))
            stack.addArrangedSubview(btn("Pick layer  ▾") { [weak self] in self?.pickLayer(imgs) })
            return
        }
        stack.addArrangedSubview(btn("Layer: \(l.name)  ▾") { [weak self] in self?.pickLayer(imgs) })
        stack.addArrangedSubview(gridStepper { [weak self] _ in self?.reload() })
        guard let pp = l.puppet, !pp.pins.isEmpty else {
            stack.addArrangedSubview(btn("Create mesh (\(gridN)×\(gridN) points)", C.GREEN, C.BG) { [weak self] in
                guard let self = self else { return }
                self.host?.pushUndo(); self.buildGrid(l, self.gridN); self.reload(); self.redraw() })
            return
        }
        stack.addArrangedSubview(btn("Rebuild with \(gridN)×\(gridN) points") { [weak self] in
            guard let self = self else { return }
            let go: () -> Void = { self.host?.pushUndo(); self.buildGrid(l, self.gridN); self.reload(); self.redraw() }
            if self.hasKeys(l) { self.confirm("Rebuild mesh?", "This removes this layer's mesh keys.", go) } else { go() }
        })
        stack.addArrangedSubview(toggleRow("Show mesh", pp.showMesh) { [weak self] v in pp.showMesh = v; self?.redraw() })
        stack.addArrangedSubview(detailChips(pp))
        stack.addArrangedSubview(chips(["Move", "Paint", "Add", "Delete"], tool) { [weak self] i in self?.tool = i; self?.reload() })
        let tips = ["Drag a point to move it.", "Paint: drag over the image; points inside the brush circle follow your finger.",
                    "Tap the image to add a point there (it starts pinned until you move it at a pose).", "Tap a point to delete it."]
        stack.addArrangedSubview(lbl(tips[tool], 12, C.DIM))
        if tool == 1 { brushSection() }
        stack.addArrangedSubview(slider("Softness (falloff)", 0.5, 6, pp.stiffness, 1) { [weak self] v in pp.stiffness = v; self?.redraw() })
        let row = UIStackView(arrangedSubviews: [
            btn("Clear keys of this parameter") { [weak self] in
                guard let self = self, let p = self.active else { return }
                self.host?.pushUndo()
                self.rig.bindings.removeAll { $0.paramId == p.id && $0.layerId == l.id && $0.key.hasPrefix("pp") }
                self.reload(); self.redraw() },
            btn("Remove mesh", C.CARD2, C.DIM) { [weak self] in
                guard let self = self else { return }
                self.host?.pushUndo()
                self.rig.bindings.removeAll { $0.layerId == l.id && $0.key.hasPrefix("pp") }
                l.puppet = nil; self.reload(); self.redraw() }])
        row.spacing = 8; row.distribution = .fillEqually
        stack.addArrangedSubview(row)
    }

    private func pickLayer(_ imgs: [Layer]) {
        ask("Layer", imgs.map { $0.name }) { [weak self] i in self?.selId = imgs[i].id; self?.reload() }
    }

    private func addPin(_ l: Layer, _ rx: Float, _ ry: Float) {
        guard let pu = l.puppet else { return }
        host?.pushUndo()
        pu.pins.append(PuppetPin(pu.nextId, rx, ry)); pu.nextId += 1
        reload(); redraw()
    }

    private func delPin(_ l: Layer, _ pin: PuppetPin) {
        guard let pu = l.puppet, pu.pins.count > 1 else { host?.toast("A mesh needs at least one point"); return }
        host?.pushUndo()
        pu.pins.removeAll { $0.id == pin.id }
        rig.bindings.removeAll { $0.layerId == l.id && ($0.key == "pp\(pin.id)x" || $0.key == "pp\(pin.id)y") }
        reload(); redraw()
    }

    // ---- transform (opacity / position / rotate / scale — all keyed at the pose above)
    private func buildTransform() {
        let ms = members()
        guard !ms.isEmpty else { stack.addArrangedSubview(lbl("Import a layer into this rig first.", 13, C.DIM)); return }
        guard let l = sel else {
            stack.addArrangedSubview(lbl("Select a layer: tap it in the canvas or pick it here.", 13, C.DIM))
            stack.addArrangedSubview(btn("Pick layer  ▾") { [weak self] in self?.pickLayer(ms) })
            return
        }
        stack.addArrangedSubview(btn("Layer: \(l.name)  ▾") { [weak self] in self?.pickLayer(ms) })
        guard let p = active else { stack.addArrangedSubview(lbl("Add a parameter above first.", 13, C.DIM)); return }
        stack.addArrangedSubview(lbl("Everything here is saved as a key at the pose above. Values are changes (+/−) from the normal pose.", 12, C.DIM))
        let pv = rig.value(p, group, Editor.time)
        for (name, key) in Self.propList {
            let r = propRange(key)
            let cur = rig.binding(p, l.id, key, create: false)?.eval(pv) ?? 0
            stack.addArrangedSubview(slider(name, r.0, r.1, cur, key == "rotZ" ? 1 : 2) { [weak self] v in
                guard let self = self else { return }
                let now = self.rig.value(p, self.group, Editor.time)
                self.rig.binding(p, l.id, key, create: true)?.setKey(now, v)
                self.refreshKeyState(); self.redraw()
            })
        }
        stack.addArrangedSubview(lbl("Rotation pivot: drag the cyan dot in the canvas.", 12, C.DIM))
        stack.addArrangedSubview(btn("Reset pivot to center") { [weak self] in
            self?.host?.pushUndo(); self?.host?.setAnchorKeepVisual(l, 50, 50); self?.redraw() })
    }
}

// MARK: - layer tree table (data source, drag & drop)

extension RigEditorViewController: UITableViewDataSource, UITableViewDelegate, UITableViewDragDelegate, UITableViewDropDelegate {
    func tableView(_ tv: UITableView, numberOfRowsInSection section: Int) -> Int { treeRows.count }

    func tableView(_ tv: UITableView, cellForRowAt ip: IndexPath) -> UITableViewCell {
        let c = tv.dequeueReusableCell(withIdentifier: "row", for: ip) as! RigRowCell
        let (l, d) = treeRows[ip.row]
        let box = isContainer(l), on = l.id == selId
        c.indent.constant = 6 + CGFloat(d) * 16
        c.chev.isHidden = !box; c.chev.setImage(UIImage(systemName: collapsed.contains(l.id) ? "chevron.right" : "chevron.down"), for: .normal)
        let ic = l.deformer == 1 ? "grid" : (l.deformer == 2 ? "arrow.triangle.2.circlepath" : (box ? "folder.fill" : "photo"))
        c.icon.image = UIImage(systemName: ic)
        c.icon.tintColor = argbToUIColor(l.deformer != 0 ? C.GREEN : C.DIM)
        c.name.text = l.name; c.name.textColor = argbToUIColor(on ? C.GREEN : C.TEXT)
        c.name.font = .systemFont(ofSize: 14, weight: on ? .bold : .regular)
        c.contentView.backgroundColor = on ? argbToUIColor(C.CARD) : .clear
        c.eye.setImage(UIImage(systemName: l.visible ? "eye" : "eye.slash"), for: .normal)
        c.onChev = { [weak self] in
            guard let self = self else { return }
            if self.collapsed.contains(l.id) { self.collapsed.remove(l.id) } else { self.collapsed.insert(l.id) }
            self.rebuildTree() }
        c.onEye = { [weak self] in l.visible.toggle(); self?.rebuildTree(); self?.redraw() }
        c.onMore = { [weak self] in self?.layerMenu(l) }
        return c
    }

    func tableView(_ tv: UITableView, didSelectRowAt ip: IndexPath) {
        let l = treeRows[ip.row].0
        selId = l.id; if l.deformer == 1 { selWarp = l.id }
        reload()
    }

    func tableView(_ tv: UITableView, itemsForBeginning session: UIDragSession, at ip: IndexPath) -> [UIDragItem] {
        let l = treeRows[ip.row].0; dragId = l.id
        let it = UIDragItem(itemProvider: NSItemProvider(object: l.name as NSString)); it.localObject = l.id
        return [it]
    }

    func tableView(_ tv: UITableView, canHandle session: UIDropSession) -> Bool { session.localDragSession != nil }

    func tableView(_ tv: UITableView, dropSessionDidUpdate session: UIDropSession,
                   withDestinationIndexPath ip: IndexPath?) -> UITableViewDropProposal {
        guard let dl = layer(dragId) else { return UITableViewDropProposal(operation: .cancel) }
        if let ip = ip, ip.row < treeRows.count {
            let t = treeRows[ip.row].0
            if isInside(t, dl) { return UITableViewDropProposal(operation: .cancel) }
            return UITableViewDropProposal(operation: .move, intent: isContainer(t) ? .insertIntoDestinationIndexPath : .insertAtDestinationIndexPath)
        }
        return UITableViewDropProposal(operation: .move, intent: .unspecified)
    }

    func tableView(_ tv: UITableView, performDropWith co: UITableViewDropCoordinator) {
        guard let dl = layer(dragId) else { return }
        var par = groupId; var after: Layer? = nil
        if let ip = co.destinationIndexPath, ip.row < treeRows.count {
            let t = treeRows[ip.row].0
            if co.proposal.intent == .insertIntoDestinationIndexPath && isContainer(t) { par = t.id }
            else { par = t.parentId; after = t }
        }
        if isInside(layer(par), dl) { return }
        host?.pushUndo()
        dl.parentId = par
        if let a = after, a.id != dl.id {                      // list shows front-most first, so "above" = later in array
            Editor.scene.layers.removeAll { $0.id == dl.id }
            if let i = Editor.scene.layers.firstIndex(where: { $0.id == a.id }) { Editor.scene.layers.insert(dl, at: i + 1) }
            else { Editor.scene.layers.append(dl) }
        }
        collapsed.remove(par)
        prepareWarps(for: dl)
        reload(); redraw()
    }
}
