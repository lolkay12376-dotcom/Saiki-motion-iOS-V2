// Rig.swift — rig group data (Model).
//
// A rig group is a GROUP layer with a `Rig`. Parameters are tracks on that
// group ("rp<id>"), so they can be keyframed in the main editor too. A binding
// maps a parameter to one property of a member layer through keyforms
// (parameter value → output), interpolated linearly. The output is ADDED to the
// property ("x", "rotZ", "opacity", or a mesh pin "pp<id>x"/"pp<id>y").

import Foundation

final class RigParam {
    var id: Int
    var name: String
    var lo: Float
    var hi: Float
    var def: Float
    init(_ id: Int, _ name: String, _ lo: Float, _ hi: Float, _ def: Float) {
        self.id = id; self.name = name; self.lo = lo; self.hi = hi; self.def = def
    }
    var key: String { "rp\(id)" }
}

final class RigBinding {
    var id: Int
    var paramId: Int
    var layerId: Int
    var key: String
    var keys: [(Float, Float)]      // (parameter value, output), sorted by parameter value
    var rest: Float? = nil          // implicit zero-output key at the parameter default (not stored as a key)
    init(_ id: Int, _ paramId: Int, _ layerId: Int, _ key: String, _ keys: [(Float, Float)] = []) {
        self.id = id; self.paramId = paramId; self.layerId = layerId; self.key = key; self.keys = keys
    }

    func eval(_ v: Float) -> Float {
        var keys = self.keys
        if let rv = rest, !keys.contains(where: { abs($0.0 - rv) < 1e-3 }) {
            keys.append((rv, 0)); keys.sort { $0.0 < $1.0 }
        }
        guard let f = keys.first, let l = keys.last else { return 0 }
        if v <= f.0 { return f.1 }
        if v >= l.0 { return l.1 }
        for i in 1..<keys.count where v <= keys[i].0 {
            let a = keys[i - 1], b = keys[i]
            let d = b.0 - a.0
            return d < 1e-6 ? b.1 : a.1 + (b.1 - a.1) * (v - a.0) / d
        }
        return l.1
    }

    func setKey(_ pv: Float, _ out: Float) {
        if let i = keys.firstIndex(where: { abs($0.0 - pv) < 1e-3 }) { keys[i].1 = out }
        else { keys.append((pv, out)); keys.sort { $0.0 < $1.0 } }
    }
}

/// A layer (usually a Rotate Deformer or hair layer) that the pendulum swings, with its own amount and lag.
final class PhysTarget {
    var layerId: Int
    var deg: Float          // rotation at full swing (degrees, may be negative)
    var delay: Float        // seconds behind the pendulum → chain / whip effect
    init(_ l: Int, _ d: Float, _ dl: Float) { layerId = l; deg = d; delay = dl }
}

/// Physics input (the "cause"): a parameter, how much of the pendulum's drive it supplies, and how it is normalised.
final class PhysIn {
    var paramId: Int
    var influence: Float = 100      // % — all inputs of one group are normalised so they never exceed 100 %
    var invert = false
    var useRange = false            // false → parameter min / default / max
    var nmin: Float = -1, ncen: Float = 0, nmax: Float = 1
    init(_ p: Int, _ infl: Float = 100) { paramId = p; influence = infl }
}

/// Physics output (the "effect"): a parameter that the simulated pendulum drives (value is ADDED).
final class PhysOut {
    var paramId: Int
    var scale: Float = 1            // magnification
    var invert = false              // reflect
    var peak: Float = 0             // runtime diagnostic: biggest fraction of the parameter range used (1 = 100 %)
    init(_ p: Int, _ s: Float = 1) { paramId = p; scale = s }
}

/// Live2D-style physics group: input parameter(s) move a pendulum, whose swing drives output parameter(s).
/// Nothing moves unless an input moves — there is no automatic wind / idle swing.
final class PhysGroup {
    var id: Int
    var name: String
    var on = true
    var ins: [PhysIn] = []
    var outs: [PhysOut] = []
    var length: Float = 0.5     // duration: short = snappy, long = slow and heavy
    var damping: Float = 0.3    // convergence: how fast the swing dies down (0 long, 1 immediate)
    var ease: Float = 0.85      // ease of swinging (magnitude): high = tiny input → big swing
    var reaction: Float = 0.5   // how agilely it follows sudden input changes
    var strength: Float = 1     // extra input gain
    var maxDeg: Float = 30
    var weight: Float = 1
    var wind: Float = 0         // legacy, ignored
    var targets: [PhysTarget] = []   // legacy direct layer targets (older projects)
    init(_ id: Int, _ name: String) { self.id = id; self.name = name }

    /// Deterministic: always re-simulated from rest over the last 2 s, so scrubbing/export match playback.
    func angle(_ g: Layer, _ rig: Rig, _ t: Float) -> Float {
        let used = ins.compactMap { i -> (PhysIn, RigParam)? in rig.param(i.paramId).map { (i, $0) } }
        if used.isEmpty { return 0 }
        let total = max(100, used.reduce(0) { $0 + $1.0.influence })
        let dt: Float = 1.0 / 60, g0: Float = 9.8
        let steps = Int(min(max(t, 0), 2) / dt)
        var tau = t - Float(steps) * dt
        func u(_ x: Float) -> Float {
            var sum: Float = 0
            for (i, p) in used {
                let v = g.props[p.key]?.eval(x) ?? p.def
                let lo = i.useRange ? i.nmin : p.lo, c = i.useRange ? i.ncen : p.def, hi = i.useRange ? i.nmax : p.hi
                let n = v >= c ? (v - c) / max(hi - c, 1e-4) : (v - c) / max(c - lo, 1e-4)
                sum += max(-1.5, min(1.5, n)) * (i.invert ? -1 : 1) * i.influence / total
            }
            return sum * strength * pow(ease / 0.85, 2)
        }
        let L = max(length, 0.05), maxR = max(maxDeg, 1) * .pi / 180
        let c = 2 * (0.05 + 0.95 * damping) * (g0 / L).squareRoot()
        let follow = 1 - exp(-dt / (0.002 + (1 - min(max(reaction, 0), 1)) * 0.12))   // input low-pass
        var th: Float = 0, w: Float = 0
        var uf = u(tau), u1 = uf, u2 = uf
        for _ in 0..<steps {
            tau += dt
            uf += (u(tau) - uf) * follow
            var a = (uf - 2 * u1 + u2) / (dt * dt) * 0.25
            a = min(60, max(-60, a))
            w += (-(g0 / L) * sin(th) - c * w - a / L * cos(th)) * dt
            th += w * dt
            th = min(maxR * 1.5, max(-maxR * 1.5, th))
            u2 = u1; u1 = uf
        }
        return min(1, max(-1, th / maxR))
    }
}

final class RigFolder {
    var id: Int
    var name: String
    var open = true
    init(_ id: Int, _ name: String) { self.id = id; self.name = name }
}

final class Rig {
    var folders: [RigFolder] = []
    var folderOf: [Int: Int] = [:]  // layer id → folder id (absent = root)
    var params: [RigParam] = []
    var bindings: [RigBinding] = []
    var members: [Int] = []         // layer ids imported into this rig group
    var phys: [PhysGroup] = []
    var nextId = 1

    func param(_ id: Int) -> RigParam? { params.first { $0.id == id } }

    @discardableResult
    func addParam(_ name: String, _ lo: Float, _ hi: Float, _ def: Float, on g: Layer) -> RigParam {
        let p = RigParam(nextId, name, lo, hi, def); nextId += 1
        params.append(p)
        g.track(p.key).base = def
        return p
    }

    func value(_ p: RigParam, _ g: Layer, _ t: Float) -> Float { g.p(p.key, t) }

    /// Existing binding for (param, layer, key) or a new one with a zero key at the default.
    func binding(_ p: RigParam, _ layerId: Int, _ key: String, create: Bool) -> RigBinding? {
        if let b = bindings.first(where: { $0.paramId == p.id && $0.layerId == layerId && $0.key == key }) { return b }
        guard create else { return nil }
        let b = RigBinding(nextId, p.id, layerId, key, []); b.rest = p.def; nextId += 1
        bindings.append(b)
        return b
    }

    func removeLayer(_ id: Int) {
        members.removeAll { $0 == id }
        folderOf[id] = nil
        bindings.removeAll { $0.layerId == id }
    }

    // MARK: apply (called before every frame is drawn)

    /// Members of a rig group = every layer below it in the timeline (children, folders, deformers).
    private static var lastSig = 0
    static func syncMembers(_ layers: [Layer]) {
        var h = Hasher()
        for l in layers { h.combine(l.id); h.combine(l.parentId); if let r = l.rig { h.combine(ObjectIdentifier(r)) } }
        let sig = h.finalize()
        if sig == lastSig { return }
        lastSig = sig
        for g in layers {
            guard let r = g.rig else { continue }
            var inside = Set<Int>([g.id]); var grew = true
            while grew {
                grew = false
                for l in layers where !inside.contains(l.id) && inside.contains(l.parentId) { inside.insert(l.id); grew = true }
            }
            let ids = layers.filter { $0.id != g.id && inside.contains($0.id) }.map { $0.id }
            if ids != r.members { r.members = ids }
        }
    }

    static func descendants(_ g: Layer, _ layers: [Layer]) -> [Layer] {
        var inside = Set<Int>([g.id]); var out: [Layer] = []; var grew = true
        while grew {
            grew = false
            for l in layers where !inside.contains(l.id) && inside.contains(l.parentId) { inside.insert(l.id); out.append(l); grew = true }
        }
        return out
    }

    static func apply(_ layers: [Layer], _ t: Float, live: [Int: [String: Float]] = [:]) {
        var any = false
        for l in layers where l.rig != nil || l.warp != nil { any = true; break }
        if !any {
            for l in layers where !l.rigOff.isEmpty { l.rigOff.removeAll() }
            return
        }
        syncMembers(layers)
        for l in layers { if !l.rigOff.isEmpty { l.rigOff.removeAll(keepingCapacity: true) } }
        var byId = [Int: Layer]()
        for l in layers { byId[l.id] = l }
        for g in layers {
            guard let r = g.rig else { continue }
            let mem = Set(r.members)
            var ph: [Int: Float] = [:]
            for pg in r.phys where pg.on {
                let a0 = pg.angle(g, r, t)
                for o in pg.outs {
                    guard let p = r.param(o.paramId) else { continue }
                    let f = a0 * o.scale * pg.weight * (o.invert ? -1 : 1)
                    ph[p.id, default: 0] += f * (p.hi - p.lo) / 2
                    o.peak = max(o.peak * 0.985, abs(f))
                }
                for tg in pg.targets {
                    guard let tl = byId[tg.layerId] else { continue }
                    let a = tg.delay > 0.001 ? pg.angle(g, r, t - tg.delay) : a0
                    tl.rigOff["rotZ", default: 0] += a * pg.weight * tg.deg
                }
            }
            for b in r.bindings {
                guard mem.contains(b.layerId), let p = r.param(b.paramId), let target = byId[b.layerId] else { continue }
                target.rigOff[b.key, default: 0] += b.eval(g.p(p.key, t) + (ph[p.id] ?? 0))
            }
        }
        for (id, d) in live { if let l = byId[id] { for (k, v) in d { l.rigOff[k] = v } } }
        for w in layers where w.deformer == 1 { if let wp = w.warp { applyWarp(w, wp, layers, t) } }
    }

    /// Warp deformer: bilinear control-grid offsets are added to the mesh pins of every image layer inside.
    static func applyWarp(_ w: Layer, _ wp: Warp, _ layers: [Layer], _ t: Float) {
        let n = max(2, wp.n)
        var offs = [Float](repeating: 0, count: n * n * 2); var moved = false
        for k in 0..<(n * n) {
            offs[2 * k] = w.p("wx\(k)", t); offs[2 * k + 1] = w.p("wy\(k)", t)
            if offs[2 * k] != 0 || offs[2 * k + 1] != 0 { moved = true }
        }
        if !moved { return }
        let mw = Xf.matrix(w, t)
        guard let invW = Xf.invert(mw) else { return }
        for l in descendants(w, layers) where l.type == .IMAGE {
            guard let pp = l.puppet, pp.on, !pp.pins.isEmpty else { continue }
            let ml = Xf.matrix(l, t)
            guard let invL = Xf.invert(ml) else { continue }
            let (qw, qh) = Xf.quadSize(l)
            for pin in pp.pins {
                let wpos = Xf.apply(ml, pin.rx * qw / 2, pin.ry * qh / 2)
                let q = Xf.apply(invW, wpos.0, wpos.1)
                let ru = (q.0 - wp.bx) / max(wp.bw, 1e-4), rv = (q.1 - wp.by) / max(wp.bh, 1e-4)
                // outside the grid the deformation fades out instead of dragging the whole layer along
                let out = max(max(-ru, ru - 1), max(-rv, rv - 1), 0)
                let fade = max(0, 1 - out / 0.12)
                if fade <= 0 { continue }
                let u = min(1, max(0, ru)) * Float(n - 1)
                let v = min(1, max(0, rv)) * Float(n - 1)
                let i0 = min(n - 2, Int(u)), j0 = min(n - 2, Int(v))
                let fu = u - Float(i0), fv = v - Float(j0)
                var dx: Float = 0, dy: Float = 0
                for (di, dj, wgt) in [(0, 0, (1 - fu) * (1 - fv)), (1, 0, fu * (1 - fv)), (0, 1, (1 - fu) * fv), (1, 1, fu * fv)] {
                    let k = (j0 + dj) * n + (i0 + di)
                    dx += offs[2 * k] * wgt * fade; dy += offs[2 * k + 1] * wgt * fade
                }
                // W-local displacement → world → layer-local
                let wx = mw[0] * dx + mw[2] * dy, wy = mw[1] * dx + mw[3] * dy
                let lx = invL[0] * wx + invL[2] * wy, ly = invL[1] * wx + invL[3] * wy
                l.rigOff["pp\(pin.id)x", default: 0] += lx / (qw / 2)
                l.rigOff["pp\(pin.id)y", default: 0] += ly / (qh / 2)
            }
        }
    }

    // MARK: json

    func toJson() -> JObj {
        let o = JObj()
        o.put("nextId", Int64(nextId))
        let pa = JArr()
        for p in params {
            _ = pa.put(JObj().put("id", Int64(p.id)).put("name", p.name)
                .put("lo", Double(p.lo)).put("hi", Double(p.hi)).put("def", Double(p.def)))
        }
        o.put("params", pa)
        let ba = JArr()
        for b in bindings {
            let ka = JArr()
            for k in b.keys { _ = ka.put(JObj().put("v", Double(k.0)).put("o", Double(k.1))) }
            _ = ba.put(JObj().put("id", Int64(b.id)).put("param", Int64(b.paramId))
                .put("layer", Int64(b.layerId)).put("key", b.key).put("keys", ka)
                .put("rest", Double(b.rest ?? -99999)))
        }
        o.put("bindings", ba)
        let ma = JArr(); for m in members { _ = ma.put(Int64(m)) }
        o.put("members", ma)
        let pha = JArr()
        for q in phys {
            let ia = JArr(), oa = JArr()
            for i in q.ins { _ = ia.put(JObj().put("p", Int64(i.paramId)).put("infl", Double(i.influence)).put("inv", i.invert)
                .put("ur", i.useRange).put("nmin", Double(i.nmin)).put("ncen", Double(i.ncen)).put("nmax", Double(i.nmax))) }
            for x in q.outs { _ = oa.put(JObj().put("p", Int64(x.paramId)).put("sc", Double(x.scale)).put("inv", x.invert)) }
            _ = pha.put(JObj().put("id", Int64(q.id)).put("name", q.name).put("on", q.on)
                .put("ins", ia).put("outs", oa).put("len", Double(q.length))
                .put("damp", Double(q.damping)).put("ease", Double(q.ease)).put("react", Double(q.reaction))
                .put("str", Double(q.strength)).put("max", Double(q.maxDeg)).put("wt", Double(q.weight))
                .put("tg", { () -> JArr in
                    let ta = JArr()
                    for x in q.targets { _ = ta.put(JObj().put("l", Int64(x.layerId)).put("d", Double(x.deg)).put("dl", Double(x.delay))) }
                    return ta }()))
        }
        o.put("phys", pha)
        let fa = JArr()
        for f in folders { _ = fa.put(JObj().put("id", Int64(f.id)).put("name", f.name).put("open", f.open)) }
        o.put("folders", fa)
        let fo = JArr()
        for (l, f) in folderOf { _ = fo.put(JObj().put("l", Int64(l)).put("f", Int64(f))) }
        o.put("folderOf", fo)
        return o
    }

    static func fromJson(_ o: JObj) -> Rig {
        let r = Rig()
        r.nextId = max(1, o.optInt("nextId", 1))
        if let pa = o.optJSONArray("params") {
            for i in 0..<pa.count {
                guard let p = pa.optJSONObject(i) else { continue }
                r.params.append(RigParam(p.optInt("id"), p.optString("name", "Param"),
                                         p.optFloat("lo", 0), p.optFloat("hi", 1), p.optFloat("def", 0)))
            }
        }
        if let ba = o.optJSONArray("bindings") {
            for i in 0..<ba.count {
                guard let b = ba.optJSONObject(i) else { continue }
                var ks = [(Float, Float)]()
                if let ka = b.optJSONArray("keys") {
                    for j in 0..<ka.count {
                        if let k = ka.optJSONObject(j) { ks.append((k.optFloat("v"), k.optFloat("o"))) }
                    }
                }
                let nb = RigBinding(b.optInt("id"), b.optInt("param"), b.optInt("layer"), b.optString("key", "x"), ks)
                let rv = b.optFloat("rest", -99999)
                nb.rest = rv > -99998 ? rv : r.param(nb.paramId)?.def
                r.bindings.append(nb)
            }
        }
        if let ma = o.optJSONArray("members") {
            for i in 0..<ma.count { r.members.append(ma.optInt(i)) }
        }
        if let pa = o.optJSONArray("phys") {
            for i in 0..<pa.count {
                guard let q = pa.optJSONObject(i) else { continue }
                let g = PhysGroup(q.optInt("id"), q.optString("name", "Pendulum"))
                g.on = q.optBool("on", true)
                g.length = q.optFloat("len", 0.5); g.damping = q.optFloat("damp", 0.3); g.strength = q.optFloat("str", 1)
                g.ease = q.optFloat("ease", 0.85); g.reaction = q.optFloat("react", 0.5)
                g.maxDeg = q.optFloat("max", 30); g.weight = q.optFloat("wt", 1)
                if let ia = q.optJSONArray("ins") {
                    for k in 0..<ia.count { if let x = ia.optJSONObject(k) {
                        let i = PhysIn(x.optInt("p"), x.optFloat("infl", 100)); i.invert = x.optBool("inv", false)
                        i.useRange = x.optBool("ur", false); i.nmin = x.optFloat("nmin", -1); i.ncen = x.optFloat("ncen", 0); i.nmax = x.optFloat("nmax", 1)
                        g.ins.append(i) } }
                } else if q.optInt("in", -1) >= 0 { g.ins.append(PhysIn(q.optInt("in", -1))) }
                if let oa = q.optJSONArray("outs") {
                    for k in 0..<oa.count { if let x = oa.optJSONObject(k) {
                        let o = PhysOut(x.optInt("p"), x.optFloat("sc", 1)); o.invert = x.optBool("inv", false); g.outs.append(o) } }
                } else if q.optInt("out", -1) >= 0 { g.outs.append(PhysOut(q.optInt("out", -1), 1)) }
                if let ta = q.optJSONArray("tg") {
                    for k in 0..<ta.count { if let x = ta.optJSONObject(k) { g.targets.append(PhysTarget(x.optInt("l"), x.optFloat("d"), x.optFloat("dl"))) } }
                }
                r.phys.append(g)
            }
        }
        if let fa = o.optJSONArray("folders") {
            for i in 0..<fa.count {
                if let f = fa.optJSONObject(i) {
                    let rf = RigFolder(f.optInt("id"), f.optString("name", "Folder"))
                    rf.open = f.optBool("open", true); r.folders.append(rf)
                }
            }
        }
        if let fo = o.optJSONArray("folderOf") {
            for i in 0..<fo.count { if let e = fo.optJSONObject(i) { r.folderOf[e.optInt("l")] = e.optInt("f") } }
        }
        return r
    }
}

/// Warp deformer control grid (n × n points over a box in the deformer group's local space).
final class Warp {
    var n = 4
    var bx: Float = -0.5, by: Float = -0.5, bw: Float = 1, bh: Float = 1
    func rest(_ k: Int) -> (Float, Float) {
        let i = k % n, j = k / n, d = Float(max(n - 1, 1))
        return (bx + bw * Float(i) / d, by + bh * Float(j) / d)
    }
    func toJson() -> JObj {
        JObj().put("n", Int64(n)).put("bx", Double(bx)).put("by", Double(by)).put("bw", Double(bw)).put("bh", Double(bh))
    }
    static func fromJson(_ o: JObj) -> Warp {
        let w = Warp()
        w.n = max(2, o.optInt("n", 4)); w.bx = o.optFloat("bx", -0.5); w.by = o.optFloat("by", -0.5)
        w.bw = o.optFloat("bw", 1); w.bh = o.optFloat("bh", 1)
        return w
    }
}
