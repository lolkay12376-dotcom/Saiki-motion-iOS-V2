// EditorImport.swift — every import picker (video/image/audio/glb/font/fx/preset) + addMedia + audio extraction + beat markers.

import UIKit
import AVFoundation
import CoreMedia
import UniformTypeIdentifiers
import PhotosUI

extension EditorViewController {
        func extractAudio(_ l: Layer) {
            guard let src = l.imagePath else { return }
            toast("Extracting audio...")
            safeThread("extract-audio") { [weak self] in
                let f = Paths.cache.appendingPathComponent("audio_\(nowMs()).m4a")
                if !AudioTools.extractAudio(src, f) {
                    DispatchQueue.main.async { self?.toast("This video has no audio track") }
                    return
                }
                // PORT NOTE: Android also copied the m4a into MediaStore Music/SaikiMotion; the
                // user-visible copy lands in <Documents>/SaikiMotion on iOS (Files app).
                let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
                    .appendingPathComponent("SaikiMotion", isDirectory: true)
                try? FileManager.default.createDirectory(at: docs, withIntermediateDirectories: true)
                let base = self?.beforeLast((l.name as NSString).lastPathComponent, ".") ?? ""
                let music = docs.appendingPathComponent(base + ".m4a")
                try? FileManager.default.removeItem(at: music)
                try? FileManager.default.copyItem(at: f, to: music)
                let mf = Projects.mediaDir().appendingPathComponent("\(nowMs())_" + (self?.alnum(base) ?? "") + ".m4a")
                try? FileManager.default.removeItem(at: mf)
                try? FileManager.default.copyItem(at: f, to: mf)
                try? FileManager.default.removeItem(at: f)
                DispatchQueue.main.async {
                    self?.toast("Saved to Documents/SaikiMotion and added as an audio layer")
                    self?.addMedia(mf.path, .AUDIO)
                }
            }
        }

        func beatsFrom(_ path: String, _ offset: Float) {
            if path.isEmpty { toast("Could not analyze audio"); return }
            toast("Analyzing beats...")
            safeThread("beats") { [weak self] in
                let beats = AudioTools.detectBeats(path)
                DispatchQueue.main.async {
                    guard let self = self else { return }
                    self.pushUndo()
                    var ms = Editor.scene.markers
                    var n = 0
                    for b in beats {
                        let t = offset + b
                        if t <= Editor.scene.duration && !ms.contains(where: { abs($0 - t) < 0.05 }) {
                            ms.append(t); n += 1
                        }
                    }
                    Editor.scene.markers = ms
                    self.render()
                    self.toast("Added \(n) beat markers")
                }
            }
        }

        // ================================================================ importing

        func pickFile(_ req: Int, _ types: [UTType]) {
            pendingPick = req
            let picker = UIDocumentPickerViewController(forOpeningContentTypes: types, asCopy: true)
            picker.delegate = self
            picker.allowsMultipleSelection = (req == R_IMAGE || req == R_VIDEO)
            present(picker, animated: true)
        }

        /// Adds media through an options sheet: the photo library first (PHPicker), then Files.
        /// `photos` is enabled for images and videos; audio and models go straight to Files.
        func pickMedia(_ req: Int, _ types: [UTType], _ photos: Bool = true) {
            guard photos else { pickFile(req, types); return }
            let sheet = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
            let photoLabel = req == R_VIDEO ? "Photo Library (video)" : req == R_IMAGE ? "Photo Library" : "Choose from Files"
            if req == R_IMAGE || req == R_VIDEO {
                sheet.addAction(UIAlertAction(title: photoLabel, style: .default) { [weak self] _ in
                    self?.pickFromPhotos(req)
                })
                sheet.addAction(UIAlertAction(title: "Choose from Files", style: .default) { [weak self] _ in
                    self?.pickFile(req, types)
                })
            } else {
                sheet.addAction(UIAlertAction(title: "Choose from Files", style: .default) { [weak self] _ in
                    self?.pickFile(req, types)
                })
            }
            sheet.addAction(UIAlertAction(title: "Cancel", style: .cancel))
            if let pop = sheet.popoverPresentationController { pop.sourceView = view; pop.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.maxY - 60, width: 1, height: 1) }
            present(sheet, animated: true)
        }

        /// PHPickerViewController: photo-library import for image/video (in-place load, no copy needed).
        /// The 3D tool in the bottom bar: straight to the default Files picker (models and volumes).
        func show3DImport() {
            Import3DSheet.show(in: view,
                model: { [weak self] in self?.pickFile(R_GLB, glbTypes()) },
                vdb: { [weak self] in self?.pickFile(R_GLB, vdbTypes()) })
        }

        /// The system photo picker embedded in the Media panel (compact strip, "View all", album filter).
        @available(iOS 17.0, *)
        func embedPhotoPicker(in stack: UIStackView) {
            for c in children where c is PHPickerViewController { c.willMove(toParent: nil); c.view.removeFromSuperview(); c.removeFromParent() }
            var config = PHPickerConfiguration(photoLibrary: .shared())
            config.filter = .any(of: [.images, .videos])
            config.selectionLimit = 1
            config.mode = .compact
            config.selection = .continuous
            let vc = PHPickerViewController(configuration: config)
            vc.delegate = self
            addChild(vc)
            let box = UIView()
            vc.view.translatesAutoresizingMaskIntoConstraints = false
            box.addSubview(vc.view)
            NSLayoutConstraint.activate([
                vc.view.leadingAnchor.constraint(equalTo: box.leadingAnchor),
                vc.view.trailingAnchor.constraint(equalTo: box.trailingAnchor),
                vc.view.topAnchor.constraint(equalTo: box.topAnchor),
                vc.view.bottomAnchor.constraint(equalTo: box.bottomAnchor),
                box.heightAnchor.constraint(equalToConstant: 300)])
            stack.addArrangedSubview(box)
            vc.didMove(toParent: self)
        }

        func pickFromPhotos(_ req: Int) { pickFromSystemPicker(req) }

        func pickFromSystemPicker(_ req: Int) {
            pendingPick = req
            var config = PHPickerConfiguration()
            config.filter = .any(of: [.images, .videos])
            config.selectionLimit = 0                    // multi select
            let picker = PHPickerViewController(configuration: config)
            picker.delegate = self
            present(picker, animated: true)
        }

        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            let embedded = picker.parent != nil
            if !embedded { picker.dismiss(animated: true) }
            if !embedded && results.count > 1 {
                toast("Importing \(results.count) items…")
                for r in results { importPickedItem(r, embedded: false, picker: picker) }
                return
            }
            guard let item = results.first else { return }
            importPickedItem(item, embedded: embedded, picker: picker)
        }

        func importPickedItem(_ item: PHPickerResult, embedded: Bool, picker: PHPickerViewController) {
            if embedded {                        // the Media-panel picker: kind comes from the item, selection resets
                pendingPick = item.itemProvider.hasItemConformingToTypeIdentifier(UTType.movie.identifier) ? R_VIDEO : R_IMAGE
                if #available(iOS 17.0, *), let id = item.assetIdentifier { picker.deselectAssets(withIdentifiers: [id]) }
            }
            let req = embedded ? pendingPick
                : (item.itemProvider.hasItemConformingToTypeIdentifier(UTType.movie.identifier) ? R_VIDEO : R_IMAGE)
            let wantVideo = req == R_VIDEO
            let supported = item.itemProvider.registeredTypeIdentifiers.first { uti in
                let t = UTType(uti)
                return t?.conforms(to: .movie) == true || t?.conforms(to: .image) == true || t?.conforms(to: .audiovisualContent) == true
            }
            guard let uti = supported ?? item.itemProvider.registeredTypeIdentifiers.first else {
                toast("This item is not supported")
                return
            }
            let type = UTType(uti)
            let isVid = (type?.conforms(to: .movie) == true || type?.conforms(to: .audiovisualContent) == true) && wantVideo
            toast("Importing...")
            if isVid, item.itemProvider.hasRepresentationConforming(toTypeIdentifier: UTType.movie.identifier, fileOptions: []) {
                // R12/R14 lesson: the abstract "public.movie" UTI sometimes fails
                // even when a representation exists — try the item's own registered
                // identifiers in order before giving up.
                let utis = [UTType.movie.identifier] + item.itemProvider.registeredTypeIdentifiers.filter { $0 != UTType.movie.identifier }
                loadVideo(utis, at: 0, provider: item.itemProvider)
                return
            }
            item.itemProvider.loadDataRepresentation(forTypeIdentifier: uti) { [weak self] data, _ in
                DispatchQueue.main.async {
                    guard let self = self else { return }
                    guard let data = data else { self.toast("Could not read the item"); return }
                    let ext = (type?.preferredFilenameExtension ?? (req == R_VIDEO ? "mov" : "png")).lowercased()
                    let name = String(Int(Date().timeIntervalSince1970 * 1000)) + "_" + UUID().uuidString.prefix(6) + "_photo." + ext
                    let f = Projects.mediaDir().appendingPathComponent(name)
                    do { try data.write(to: f, options: .atomic) } catch { self.toast("Import failed"); return }
                    // A photo-library "video" without a movie representation falls back to a still.
                    self.addMedia(f.path, req == R_VIDEO && !isVid ? .IMAGE : (req == R_VIDEO ? .VIDEO : .IMAGE))
                }
            }
        }

        /// Sequential video load with retry (rounds 12/14): each candidate type
        /// identifier is tried in turn; only when all fail does the user see the
        /// error. All ownership stays with ARC — the round-17 bug was raw
        /// unretained provider/block pointers; that class of bug cannot exist here.
        func loadVideo(_ utis: [String], at i: Int, provider: NSItemProvider) {
            guard i < utis.count else {
                DispatchQueue.main.async { [weak self] in self?.toast("Could not read the video") }
                return
            }
            CrashLog.note("impv")
            provider.loadFileRepresentation(forTypeIdentifier: utis[i]) { [weak self] url, _ in
                if let url = url { self?.importPickedVideo(url); return }
                self?.loadVideo(utis, at: i + 1, provider: provider)
            }
        }

        /// Videos picked from the library arrive as file URLs that are ONLY valid
        /// inside loadFileRepresentation's completion handler. The old code
        /// hopped to a background thread first and the temp URL was already
        /// gone by then — the "Import failed on a video" bug. The copy now
        /// happens synchronously in the callback (a local file copy is fast);
        /// only the UI update hops back to main.
        func importPickedVideo(_ url: URL) {
            let name = String(Int(Date().timeIntervalSince1970 * 1000)) + "_" + UUID().uuidString.prefix(6) + "_" + url.lastPathComponent.replacingOccurrences(of: " ", with: "_")
            let f = Projects.mediaDir().appendingPathComponent(name)
            try? FileManager.default.removeItem(at: f)
            var ok = false
            do { try FileManager.default.copyItem(at: url, to: f); ok = true } catch { }
            let path = f.path
            DispatchQueue.main.async { [weak self] in
                if ok {
                    self?.addMedia(path, .VIDEO)
                    self?.toast("Video imported")
                } else {
                    self?.toast("Import failed — could not copy the video")
                }
            }
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            guard let url = urls.first else { return }
            let req = pendingPick
            if urls.count > 1 && (req == R_IMAGE || req == R_VIDEO) {
                for u in urls { documentPicker(controller, didPickDocumentsAt: [u]) }
                return
            }
            if req == R_FX || req == R_PRESET {
                do {
                    let txt = try String(contentsOf: url, encoding: .utf8)
                    if req == R_FX {
                        if let err = Registry.addCustom(txt) {
                            toast(err)
                        } else {
                            toast("Effect imported")
                            EffectThumbs.generate(self, preview) { [weak self] in self?.refreshPanel() }
                            refreshPanel()
                        }
                    } else {
                        let o = try JObj(json: txt)
                        _ = try o.getString("name")
                        Registry.savePreset(o)
                        toast("Preset imported")
                        refreshPanel()
                    }
                } catch { toast("Could not read file") }
                return
            }
            if req == R_FONT {
                guard let tl = selected() else { return }
                safeThread("font") { [weak self] in
                    // goes into the font library too (a .zip adds every font in it)
                    let added = FontLibrary.importURLs([url], into: nil)
                    let p: String? = added > 0 ? FontLibrary.fonts.last.map { FontLibrary.path($0) }
                                               : ProjectIO.copyMediaIntoSandbox(url: url, kind: "font")
                    DispatchQueue.main.async {
                        guard let self = self else { return }
                        if let p = p {
                            self.pushUndo()
                            tl.fontPath = p
                            self.refreshPanel(); self.render()
                        } else {
                            self.toast("Could not load the font")
                        }
                    }
                }
                return
            }
            if req == R_BEAT {
                safeThread("beat-copy") { [weak self] in
                    let f = Paths.cache.appendingPathComponent("beat_src")
                    let scoped = url.startAccessingSecurityScopedResource()
                    defer { if scoped { url.stopAccessingSecurityScopedResource() } }
                    try? FileManager.default.removeItem(at: f)
                    var ok = false
                    do { try FileManager.default.copyItem(at: url, to: f); ok = true } catch { }
                    DispatchQueue.main.async {
                        if ok { self?.beatsFrom(f.path, 0) } else { self?.toast("Could not read audio") }
                    }
                }
                return
            }
            toast("Importing...")
            safeThread("import-media") { [weak self] in
                let type: LayerType = req == R_VIDEO ? .VIDEO : (req == R_GLB ? .MODEL : (req == R_AUDIOFILE ? .AUDIO : .IMAGE))
                var p = ProjectIO.copyMediaIntoSandbox(url: url, kind: "")
                if type == .MODEL, let q = p, let inner = GlbModel.unwrapZip(q) { p = inner }   // zipped model
                // models: validate right away so an unsupported file explains itself instead of
                // silently showing nothing
                let problem: String? = (type == .MODEL && p != nil) ? GlbModel.preflight(p!) : nil
                DispatchQueue.main.async {
                    guard let self = self else { return }
                    if let p = p {
                        if let problem = problem {
                            try? FileManager.default.removeItem(atPath: p)
                            self.toast(problem)
                        } else {
                            if type == .MODEL { self.preview.warm(p) }   // parse now, not on the first frame
                            self.addMedia(p, type)
                        }
                    } else { self.toast("Import failed") }
                }
            }
        }

        /// Scales a freshly imported image/video so it fits inside the comp (contain). An image with the
        /// comp's own aspect therefore fills it exactly instead of sitting at half size.
        func fitToComp(_ l: Layer) {
            let (qw, qh) = Xf.quadSize(l)
            let ar = Float(Editor.project.w) / Float(max(Editor.project.h, 1))
            guard qw > 0.001, qh > 0.001 else { return }
            let k = min(2 * ar / qw, 2 / qh)
            if k.isFinite && k > 0 { l.track("scale").base = k }
        }

        /// Opens the drawing editor on this image layer; Save swaps the picture and keeps every
        /// transform, effect and keyframe (only the layer's image file changes).
        func openDirectDrawing(_ l: Layer) {
            guard l.type == .IMAGE, let path = l.imagePath, let src = UIImage(contentsOfFile: path) else {
                toast("Could not open this image"); return }
            // bake orientation so the drawing canvas and the layer agree on width / height
            let fmt = UIGraphicsImageRendererFormat(); fmt.scale = 1
            let upright = UIGraphicsImageRenderer(size: src.size, format: fmt).image { _ in src.draw(at: .zero) }
            let folder = DrawStore.folder(named: "Direct edits")
            guard let item = DrawImport.fromImage(upright, name: l.name, parent: folder.id, paperWhite: false) else {
                toast("Could not open this image"); return }
            let id = l.id
            let vc = DrawingEditorViewController(item: item)
            vc.onApply = { [weak self] out in
                guard let self = self,
                      let live = Editor.scene.layers.first(where: { $0.id == id }),
                      let png = out.pngData(),
                      let np = ProjectIO.writeDataIntoSandbox(png, name: "drawn_\(nowMs()).png") else {
                    self?.toast("Could not apply the drawing"); return }
                self.pushUndo()
                live.imagePath = np
                FrameCache.bump()
                self.refreshPanel(); self.render()
                self.toast("Drawing applied")
            }
            navigationController?.pushViewController(vc, animated: true)
        }

        func addMedia(_ path: String, _ type: LayerType) {
            let l = addLayer(type)
            l.imagePath = path
            l.name = afterFirst((path as NSString).lastPathComponent, "_")
            if type == .IMAGE || type == .VIDEO { fitToComp(l) }
            if type == .VIDEO || type == .AUDIO {
                // MediaMetadataRetriever.METADATA_KEY_DURATION → AVAsset duration.
                // Loaded OFF the main thread: sync AVAsset init on a long video
                // used to freeze the editor for seconds (and watchdog-flag it).
                let layerId = l.id
                safeThread("media-duration") { [weak self] in
                    let asset = AVURLAsset(url: URL(fileURLWithPath: path))
                    let dur = CMTimeGetSeconds(asset.duration)
                    DispatchQueue.main.async {
                        guard let self = self else { return }
                        guard let live = Editor.scene.layers.first(where: { $0.id == layerId }) else { return }
                        if dur.isFinite && dur > 0 {
                            live.srcDur = Float(dur)
                            let s = Editor.scene
                            if live.srcDur > 0.5 { s.duration = max(s.duration, min(600, live.start + live.srcDur)) }
                            live.end = min(s.duration, live.start + max(live.srcDur, 0.5))
                        }
                        self.refreshTitle(); self.refreshPanel(); self.render()
                    }
                }
            }
            refreshTitle(); refreshPanel(); render()
        }

        /// Kotlin exportText wrote into MediaStore Downloads; on iOS the Files-app location is
        /// <Documents>/SaikiMotion (the same convention ProjectIO uses for project exports).
        func exportText(_ name: String, _ content: String) {
            do {
                let d = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
                    .appendingPathComponent("SaikiMotion", isDirectory: true)
                try FileManager.default.createDirectory(at: d, withIntermediateDirectories: true)
                guard let data = content.data(using: .utf8) else { throw NSError(domain: "saiki", code: 1) }
                try data.write(to: d.appendingPathComponent(name))
                toast("Saved to Documents/SaikiMotion/" + name)
            } catch { toast("Export failed") }
        }
}
