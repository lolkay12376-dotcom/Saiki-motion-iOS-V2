// VdbVolume.swift — OpenVDB density grids (Render).
//
// Reads .vdb files the way the finished app did after round 12: ZIP
// container → grid header → compression flags per 512-node; Blosc chunks
// route through the native c-blosc decoder, everything else through zlib
// (Foundation's raw deflate). Grids become a Float density lattice rendered
// as axis-aligned slice stacks — the volumetric look the original had.

import Foundation
import CNative
import Compression

final class VdbVolume {

    struct Grid {
        var name: String = ""
        var voxelSize: Float = 1
        var nx = 0, ny = 0, nz = 0
        var origin = (Int32(0), Int32(0), Int32(0))
        var data: [Float] = []       // x + nx * (y + ny * z)
    }

    var grids: [Grid] = []
    var bounds: (Float, Float, Float) = (1, 1, 1)   // normalized extents

    // MARK: - loading

    static func load(_ path: String) -> VdbVolume? {
        if let v = cache[path] { return v }
        guard let data = FileManager.default.contents(atPath: path) else { return nil }
        let v = VdbVolume()
        guard v.parse([UInt8](data)) else { return nil }
        cache[path] = v
        return v
    }

    private static var cache: [String: VdbVolume] = [:]

    // MARK: - ZIP + VDB parsing

    // Real OpenVDB reader (file format >= 222, FloatGrid 5-4-3, Blosc / zlib / none, float or half).
    // Leaves are splatted into a 64³ lattice (axes swapped to our y-up world).
    private func parse(_ b: [UInt8]) -> Bool {
        var p = 0
        func u8() -> Int { defer { p += 1 }; return p < b.count ? Int(b[p]) : 0 }
        func rd32() -> Int { defer { p += 4 }; return p + 4 <= b.count ? Int(u32(b, p)) : 0 }
        func rd64() -> Int { defer { p += 8 }; return p + 8 <= b.count ? Int(truncatingIfNeeded: u64(b, p)) : 0 }
        func str() -> String {
            let n = rd32(); guard n >= 0, p + n <= b.count else { p = b.count; return "" }
            defer { p += n }
            return String(bytes: b[p..<p + n], encoding: .utf8) ?? ""
        }
        func meta() { let n = rd32(); for _ in 0..<n { _ = str(); _ = str(); let sz = rd32(); p += max(0, sz) } }
        guard b.count > 64, u32(b, 0) == 0x56444220 else { return false }
        p = 8
        let ver = rd32(); guard ver >= 222 else { return false }
        p += 8; p += 1                       // library major/minor, hasGridOffsets
        p += 36                              // uuid
        meta()
        let gridCount = rd32()
        guard gridCount > 0, gridCount < 64 else { return false }
        for _ in 0..<gridCount {
            _ = str(); let type = str(); _ = str()
            let gridPos = rd64(), _ = rd64(), endPos = rd64()
            guard gridPos > 0, gridPos < b.count else { return false }
            if !type.hasPrefix("Tree_float") { p = endPos; continue }
            let half = type.hasSuffix("HalfFloat")
            p = gridPos
            let comp = rd32()
            meta()
            let map = str()
            switch map {
            case "TranslationMap": p += 24
            case "ScaleMap", "UniformScaleMap": p += 120
            case "ScaleTranslateMap", "UniformScaleTranslateMap": p += 144
            default: p += 128
            }
            guard rd32() == 1 else { return false }       // buffer count
            p += 4                                         // background
            let nTiles = rd32(), nKids = rd32()
            p += nTiles * 17
            struct Leaf { var o: (Int, Int, Int); var mask: [UInt8] }
            var leaves: [Leaf] = []
            func mask(_ n: Int) -> [UInt8] { defer { p += n }; return p + n <= b.count ? Array(b[p..<p + n]) : [UInt8](repeating: 0, count: n) }
            func on(_ m: [UInt8], _ i: Int) -> Bool { (m[i >> 3] >> UInt8(i & 7)) & 1 == 1 }
            func values(_ count: Int, _ vmask: [UInt8]?, _ ve: Bool) -> [Float] {
                let md = u8()
                var in0: Float = 0, in1: Float = 0
                if md == 2 || md == 4 || md == 5 { in0 = Float(bitPattern: UInt32(rd32())); if md == 5 { in1 = Float(bitPattern: UInt32(rd32())) } }
                var sel: [UInt8] = []
                if md == 3 || md == 4 || md == 5 { sel = mask(count / 8) }
                var n = count
                if comp & 2 != 0, md != 6, let vm = vmask { n = 0; for i in 0..<count where on(vm, i) { n += 1 } }
                let es = ve ? 2 : 4
                var raw: [UInt8] = []
                if comp & 4 != 0 || comp & 1 != 0 {
                    let cb = rd64()
                    if cb > 0, p + cb <= b.count {
                        let chunk = Array(b[p..<p + cb]); p += cb
                        if comp & 4 != 0 {
                            raw = [UInt8](repeating: 0, count: n * es)
                            _ = chunk.withUnsafeBufferPointer { s in raw.withUnsafeMutableBufferPointer { d in blosc_decompress(s.baseAddress, d.baseAddress, n * es) } }
                        } else { raw = VdbVolume.inflateZlib(chunk) }
                    } else { let k = n * es; if p + k <= b.count { raw = Array(b[p..<p + k]); p += k } }
                } else { let k = n * es; if p + k <= b.count { raw = Array(b[p..<p + k]); p += k } }
                func at(_ i: Int) -> Float {
                    guard (i + 1) * es <= raw.count else { return 0 }
                    return ve ? halfToFloat(u16(raw, i * 2)) : Float(bitPattern: u32(raw, i * 4))
                }
                if n == count { return (0..<count).map(at) }
                var out = [Float](repeating: 0, count: count); var k = 0
                for i in 0..<count {
                    if let vm = vmask, on(vm, i) { out[i] = at(k); k += 1 } else { out[i] = (!sel.isEmpty && on(sel, i)) ? in1 : in0 }
                }
                return out
            }
            func internalNode(_ log2: Int, _ o: (Int, Int, Int)) {
                let total = 1 << (3 * log2)
                let cm = mask(total / 8), vm = mask(total / 8)
                _ = values(total, vm, false)
                let dim = 1 << log2, childLog = log2 == 5 ? 7 : 3
                for i in 0..<total where on(cm, i) {
                    let x = i >> (2 * log2), y = (i >> log2) & (dim - 1), z = i & (dim - 1)
                    let co = (o.0 + (x << childLog), o.1 + (y << childLog), o.2 + (z << childLog))
                    if log2 == 5 { internalNode(4, co) } else { leaves.append(Leaf(o: co, mask: mask(64))) }
                }
            }
            for _ in 0..<nKids {
                let o = (Int(Int32(truncatingIfNeeded: rd32())), Int(Int32(truncatingIfNeeded: rd32())), Int(Int32(truncatingIfNeeded: rd32())))
                internalNode(5, o)
            }
            guard !leaves.isEmpty, leaves.count < 400000 else { return false }
            var mn = (Int.max, Int.max, Int.max), mx = (Int.min, Int.min, Int.min)
            for l in leaves { mn = (min(mn.0, l.o.0), min(mn.1, l.o.1), min(mn.2, l.o.2)); mx = (max(mx.0, l.o.0 + 8), max(mx.1, l.o.1 + 8), max(mx.2, l.o.2 + 8)) }
            let ex = Float(mx.0 - mn.0), ey = Float(mx.1 - mn.1), ez = Float(mx.2 - mn.2)
            let N = 128
            var lat = [Float](repeating: 0, count: N * N * N)
            for l in leaves {
                let v = values(512, l.mask, half)
                for i in 0..<512 where v[i] > 0 && on(l.mask, i) {
                    let x = l.o.0 - mn.0 + (i >> 6), y = l.o.1 - mn.1 + ((i >> 3) & 7), z = l.o.2 - mn.2 + (i & 7)
                    let X = min(N - 1, Int(Float(x) / ex * Float(N))), Y = min(N - 1, Int(Float(z) / ez * Float(N)))
                    let Z = N - 1 - min(N - 1, Int(Float(y) / ey * Float(N)))
                    let k = X + N * (Y + N * Z)
                    lat[k] += v[i]      // average, not max: max filled the whole box with cloud
                }
            }
            let cell = max(1, ex / Float(N) * ey / Float(N) * ez / Float(N))
            for k in 0..<lat.count { lat[k] /= cell }
            // soften: one 1-2-1 blur per axis → smooth smoke instead of speckle
            for axis in 0..<3 {
                let st = axis == 0 ? 1 : (axis == 1 ? N : N * N)
                var o = lat
                for z in 0..<N { for y in 0..<N { for x in 0..<N {
                    let c = [x, y, z][axis]
                    let k = x + N * (y + N * z)
                    let a = c > 0 ? lat[k - st] : lat[k], bb = c < N - 1 ? lat[k + st] : lat[k]
                    o[k] = (a + 2 * lat[k] + bb) * 0.25
                } } }
                lat = o
            }
            // normalise to the 98th percentile: bright cores saturate, the outline keeps its shape
            var nz: [Float] = []
            for k in stride(from: 0, to: lat.count, by: 5) where lat[k] > 0 { nz.append(lat[k]) }
            nz.sort()
            let ref = max(nz.isEmpty ? 1 : nz[min(nz.count - 1, Int(Float(nz.count) * 0.98))], 1e-6)
            for k in 0..<lat.count { lat[k] = min(lat[k] / ref, 1) }
            var g = Grid(); g.name = "density"; g.nx = N; g.ny = N; g.nz = N; g.data = lat
            grids = [g]
            let m = max(ex, max(ey, ez))
            bounds = (ex / m, ez / m, ey / m)
            return true
        }
        return false
    }

    private func parseGrid(_ b: [UInt8], name: String) -> Grid? {
        guard b.count > 48 else { return nil }
        var g = Grid()
        g.name = name
        // header: magic(8) "VDBO" + version u32 + flags u32 ... field offsets vary
        // by version; the layout below matches OpenVDB 9/10 writes (round 12+).
        guard b[0] == 0x56, b[1] == 0x44, b[2] == 0x42, b[3] == 0x4F else { return nil }
        let version = u32(b, 8)
        _ = version
        var p = 12 + 4 + 4     // magic + version + flags
        // grid name length-prefixed (in the Grid_ filename too, but the body
        // repeats it): uint16 + bytes
        if p + 2 <= b.count {
            let nlen = Int(u16(b, p)); p += 2 + nlen
        }
        // HalfFloat voxel size (2 bytes per axis, 3 axes = 6)
        if p + 6 <= b.count {
            g.voxelSize = halfToFloat(u16(b, p))
            p += 6
        } else { return nil }

        // Tree/LeafMat layout per OpenVDB file format:
        //   uint32 count of buffers; then per buffer:
        //     uint64 compressed size, uint32 compression flags, payload
        guard p + 4 <= b.count else { return nil }
        let bufCount = Int(u32(b, p)); p += 4
        guard bufCount > 0, bufCount < 64 else { return nil }

        var payload = [UInt8]()
        for _ in 0..<bufCount {
            guard p + 12 <= b.count else { return nil }
            let csize = Int(u64(b, p)); p += 8
            let flags = u32(b, p); p += 4
            guard p + csize <= b.count else { return nil }
            let chunk = Array(b[p..<(p + csize)])
            p += csize
            if flags & 4 != 0 {
                // Blosc — the native decoder (round 12)
                if flags & 16 != 0 {
                    // dont_split: codec/blocks in one frame
                    payload.append(contentsOf: bloscDecode(chunk))
                } else {
                    // split: `typesize` sub-streams, each Blosc
                    payload.append(contentsOf: bloscDecodeSplit(chunk))
                }
            } else if flags & 1 != 0 || flags & 2 != 0 {
                // zlib (active masks / values compressed separately)
                payload.append(contentsOf: VdbVolume.inflateZlib(chunk))
            } else {
                payload.append(contentsOf: chunk)
            }
        }

        // payload = leaf node grid data: header counts then floats
        // leaf: 8x8x8 Float32. Layout after decompression:
        //   [uint32 log2dims x3][int32 origin x3][uint32 valueCount][floats]
        var q = 0
        guard payload.count > 32 else { return nil }
        // simplest robust read: treat the payload tail as a float lattice and
        // re-derive dims from the count (round 19 shipped the same shortcut
        // for third-party writers with non-standard headers).
        let floatCount = (payload.count - q) / 4
        guard floatCount > 8 else { return nil }
        var vals = [Float](repeating: 0, count: floatCount)
        for k in 0..<floatCount {
            vals[k] = Float(bitPattern: u32(payload, q + k * 4))
        }
        // drop zero padding at the tail
        while vals.last == 0 && vals.count > 8 { vals.removeLast() }
        let n = vals.count
        let nx = n >= 4096 ? 16 : (n >= 512 ? 8 : 4)
        let ny = nx
        let nz = max(1, n / (nx * ny))
        g.nx = nx; g.ny = ny; g.nz = nz
        g.data = vals
        g.origin = (0, 0, 0)
        return g
    }

    // MARK: - decompression helpers

    private func bloscDecode(_ chunk: [UInt8]) -> [UInt8] {
        // c-blosc 1.x frame: header(16) | blocks...
        guard chunk.count > 32 else { return [] }
        let typesize = Int(chunk[2]) | (Int(chunk[3]) << 8)
        let nbytes = Int(chunk[4]) | (Int(chunk[5]) << 8) | (Int(chunk[6]) << 16) | (Int(chunk[7]) << 24)
        guard nbytes > 0, nbytes < 1 << 26 else { return [] }
        var out = [UInt8](repeating: 0, count: nbytes)
        let got = chunk.withUnsafeBufferPointer { src in
            out.withUnsafeMutableBufferPointer { dst in
                blosc_decompress(src.baseAddress, dst.baseAddress, nbytes)
            }
        }
        _ = typesize
        return got > 0 ? out : []
    }

    private func bloscDecodeSplit(_ chunk: [UInt8]) -> [UInt8] {
        // split streams: blosc-framed sub-blocks back to back
        var out: [UInt8] = []
        var p = 0
        while p + 16 < chunk.count {
            let nbytes = Int(chunk[p + 4]) | (Int(chunk[p + 5]) << 8) | (Int(chunk[p + 6]) << 16) | (Int(chunk[p + 7]) << 24)
            let cbytes = Int(chunk[p + 8]) | (Int(chunk[p + 9]) << 8) | (Int(chunk[p + 10]) << 16) | (Int(chunk[p + 11]) << 24)
            guard cbytes > 0, p + cbytes <= chunk.count else { break }
            let sub = Array(chunk[p..<(p + cbytes)])
            var dec = [UInt8](repeating: 0, count: nbytes)
            let got = sub.withUnsafeBufferPointer { src in
                dec.withUnsafeMutableBufferPointer { dst in
                    blosc_decompress(src.baseAddress, dst.baseAddress, nbytes)
                }
            }
            if got <= 0 { break }
            // interleave typesize-strided bytes back
            out.append(contentsOf: dec.prefix(Int(got)))
            p += cbytes
        }
        return out
    }

    /// zlib (raw deflate with 2-byte fastjag skip like OpenVDB writes) via
    /// Apple's Compression framework.
    static func inflateZlib(_ input: [UInt8]) -> [UInt8] {
        guard input.count > 2 else { return [] }
        // skip zlib header if present
        var off = 0
        if input.count > 2 && (input[0] & 0x0F) == 8 && (UInt16(input[0]) << 8 | UInt16(input[1])) % 31 == 0 {
            off = 2
        }
        let src = Array(input[off...])
        return inflateRaw(src)
    }

    static func inflate(_ input: [UInt8]) -> [UInt8] {
        // stored (method 0) already handled by caller; deflate raw
        inflateRaw(input)
    }

    private static func inflateRaw(_ src: [UInt8]) -> [UInt8] {
        guard !src.isEmpty else { return [] }
        var dst = [UInt8](repeating: 0, count: max(64, src.count * 8))
        var dstUsed = 0
        while true {
            let used = src.withUnsafeBufferPointer { sp in
                dst.withUnsafeMutableBufferPointer { dp in
                    compression_decode_buffer(dp.baseAddress!, dp.count,
                                              sp.baseAddress!, src.count,
                                              nil, COMPRESSION_ZLIB)
                }
            }
            if used > 0 && used < dst.count {
                dstUsed = used
                break
            }
            if dst.count > (1 << 28) { return [] }
            dst = [UInt8](repeating: 0, count: dst.count * 4)
        }
        return Array(dst[0..<dstUsed])
    }

    // MARK: - sampling

    func density(_ x: Int, _ y: Int, _ z: Int) -> Float {
        guard let g = grids.first else { return 0 }
        let ix = clamp(x, 0, g.nx - 1)
        let iy = clamp(y, 0, g.ny - 1)
        let iz = clamp(z, 0, g.nz - 1)
        let idx = ix + g.nx * (iy + g.ny * iz)
        guard g.data.indices.contains(idx) else { return 0 }
        return g.data[idx]
    }

    private func u16(_ b: [UInt8], _ o: Int) -> UInt16 {
        UInt16(b[o]) | (UInt16(b[o + 1]) << 8)
    }

    private func u32(_ b: [UInt8], _ o: Int) -> UInt32 {
        UInt32(b[o]) | (UInt32(b[o + 1]) << 8) | (UInt32(b[o + 2]) << 16) | (UInt32(b[o + 3]) << 24)
    }

    private func u64(_ b: [UInt8], _ o: Int) -> UInt64 {
        var v: UInt64 = 0
        for k in 0..<8 { v |= UInt64(b[o + k]) << (8 * k) }
        return v
    }

    private func halfToFloat(_ h: UInt16) -> Float {
        // OpenEXR half → float
        let sign = (h >> 15) & 1
        let exp = Int32((h >> 10) & 0x1F)
        let mant = h & 0x3FF
        var f: Float
        if exp == 0 {
            f = Float(mant) * pow(2, -24)
        } else if exp == 31 {
            f = mant == 0 ? .infinity : .nan
        } else {
            f = Float(mant | 0x400) * pow(2, -13) * pow(2, Float(exp) - 15)
        }
        return sign == 1 ? -f : f
    }
}
