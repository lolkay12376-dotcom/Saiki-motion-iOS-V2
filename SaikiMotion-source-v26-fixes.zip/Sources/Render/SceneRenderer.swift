// SceneRenderer.swift — the compositor (Render).
//
// Draws a scene at time `t` into an offscreen target and hands back the
// texture. Pipeline per layer: content (image/video/text/shape/flare/
// particles/model/vdb/adjustment) → effect chain (ping-pong GLSL passes,
// one per applied effect, uniforms from the layer's tracks) → composite
// onto the scene buffer with the blend mode. Motion blur renders the layer
// at sub-times and accumulates. 3D layers and models project through the
// nearest camera above them.
//
// The same renderer drives the live preview, the effect thumbnails and the
// exporter — one look everywhere.

import Foundation
import OpenGLES
import GLKit
import UIKit

// MARK: - video source

/// Frame provider for video layers (preview: async buckets; export: sync).
protocol VideoSource: AnyObject {
    func videoTexture(layerId: Int, path: String, srcTime: Float) -> GLuint
    func videoFrameArrived() -> Bool
}

// MARK: - renderer

final class SceneRenderer {

    let context: EAGLContext
    var isExport = false            // export renders use the full blur sample budget
    var quality = 1                 // 1 full, 2 half, 4 quarter

    // targets (lazily sized)
    private(set) var sceneTarget: Gl.Target?
    private var scratchTarget: Gl.Target?      // composite intermediate
    private var layerA: Gl.Target?
    private var layerB: Gl.Target?
    private var accumTarget: Gl.Target?
    private var groupTarget: Gl.Target?
    private var liveGrp: [Int: (key: String, t: Gl.Target)] = [:]   // flat picture of un-baked groups
    private var groupPool: [Gl.Target] = []     // one offscreen buffer per precomp nesting level
    private var groupDepth = 0
    private var inTargets: [Gl.Target?] = [nil, nil]

    private(set) var width = 576
    private(set) var height = 1024

    // programs
    private var quadProg: GLProgram?          // textured quad (premult)
    private var shapeProg: GLProgram?
    private var flareProg: GLProgram?
    private var particleProg: GLProgram?
    private var particleVBO = GLuint(0)
    private var meshProg: GLProgram?
    private var vdbProg: GLProgram?
    private var compositeProg: GLProgram?

    // caches
    private var imageTex: [String: GLuint] = [:]
    private var imageTexBytes: [String: Int] = [:]
    private var imageTexOrder: [String] = []        // least recently used first
    private var imageTexTotal = 0
    private var imageTexSide = 0
    private let imageTexBudget = 360 * 1_048_576    // GPU memory for image layers
    private var videoSamplers: [Int: VideoFrames.Sampler] = [:]
    private var models: [String: GlbModel] = [:]
    private var volumes: [String: VdbVolume] = [:]
    private var effectProgs: [String: GLProgram] = [:]
    private var failedProgs = Set<String>()

    private var videoSource: VideoSource?

    init(context: EAGLContext) {
        self.context = context
    }

    // MARK: - entry

    /// Working resolution for a project at a preview quality (height 1024/quality).
    static func size(_ project: Project, quality: Int) -> (Int, Int) {
        let ar = Float(project.w) / Float(max(project.h, 1))
        let h = 1024 / max(1, quality)
        return (max(2, Int(Float(h) * ar)), h)
    }

    /// Sizes (or re-sizes) every offscreen buffer for the project; returns the canvas aspect.
    private func ensureTargets(_ project: Project) -> Float {
        let ar = Float(project.w) / Float(max(project.h, 1))
        (width, height) = SceneRenderer.size(project, quality: quality)
        if sceneTarget == nil || sceneTarget!.width != width || sceneTarget!.height != height {
            sceneTarget = Gl.Target(width, height)
            scratchTarget = Gl.Target(width, height)
            layerA = Gl.Target(width, height)
            layerB = Gl.Target(width, height)
            accumTarget = Gl.Target(width, height)
            groupTarget = Gl.Target(width, height)
            groupPool.removeAll()
            preTarget = nil
            let iw = 256
            let ih = max(2, Int(Float(256) / ar))
            inTargets = [Gl.Target(iw, ih), Gl.Target(iw, ih)]
        }
        return ar
    }

    /// Renders `scene` and returns the scene texture (owned by the renderer).
    func draw(project: Project, scene: Scene, time: Float, video: VideoSource?) -> GLuint {
        modelDepthDirty = true
        videoSource = video
        Rig.apply(scene.layers, time)
        let ar = ensureTargets(project)

        EAGLContext.setCurrent(context)
        buildPrograms()

        // clear scene with bg
        sceneTarget!.bind()
        glClearColor(Float((UInt32(bitPattern: scene.bg) >> 16) & 0xFF) / 255,
                     Float((UInt32(bitPattern: scene.bg) >> 8) & 0xFF) / 255,
                     Float(UInt32(bitPattern: scene.bg) & 0xFF) / 255, 1)
        glClear(GLbitfield(GL_COLOR_BUFFER_BIT))

        var visited: [Layer: Bool] = [:]
        for l in scene.layers {
            // a group draws its own children (once, inside its precomp buffer)
            if l.parentId >= 0, let par = scene.layers.first(where: { $0.id == l.parentId }), par.type == .GROUP { continue }
            drawLayer(l, project: project, scene: scene, time: time, target: sceneTarget!, ar: ar,
                      visited: &visited)
        }

        return sceneTarget!.tex
    }

    /// The composited frame as an image (thumbnails / export readback).
    func snapshot() -> UIImage? {
        sceneTarget?.readImage()
    }

    /// Blits a texture to the currently bound framebuffer + viewport (the
    /// preview's drawable). Call with this renderer's context current.
    func present(_ tex: GLuint, flipY: Bool = false) {
        guard let p = quadProg else { return }
        p.use()
        resetQuadState(p)
        p.setFloat("uFlipY", flipY ? 1 : 0)
        p.setVec4("uColor", 1, 1, 1, 1)
        p.setMat3("uMat", [1, 0, 0, 0, 1, 0, 0, 0, 1])
        let ar = Float(width) / Float(max(height, 1))
        p.setVec2("uQuad", ar * 2, 2)
        p.setFloat("uAspect", ar)
        p.setTexture("uTex", tex, 0)
        Gl.drawQuad(p)
    }

    // MARK: - per-layer

    private func drawLayer(_ l: Layer, project: Project, scene: Scene, time: Float,
                           target: Gl.Target, ar: Float, visited: inout [Layer: Bool]) {
        guard l.visible else { return }
        guard time >= l.start - 0.001 && time <= l.end + 0.001 else { return }
        if visited[l] != nil { return }
        visited[l] = true
        defer { visited[l] = nil }

        switch l.type {
        case .AUDIO, .CAMERA, .NULL:
            return
        case .GROUP:
            if l.prerender, PreRender.enabled {
                // a pre-rendered group is a flat plane (like an AE pre-comp): its contents are
                // baked without the scene camera and the plane itself is what the camera sees
                if let tex = preRenderTexture(l, project: project, scene: scene, time: time) {
                    drawBakedPlane(l, tex: tex, scene: scene, time: time, target: target)
                    return
                }
                let kids = scene.layers.filter { $0.parentId == l.id }
                if !kids.isEmpty {                      // not baked yet: same look, rendered live
                    // moving / restyling the group itself never changes its insides: reuse the flat
                    // picture while the signature + frame are unchanged (no re-render, no re-blur)
                    let ckey = PreRender.signature(l, project: project, scene: scene) + "|\(PreRender.frameIndex(time, project.fps))|\(width)x\(height)"
                    if let c = liveGrp[l.id], c.key == ckey {
                        drawBakedPlane(l, tex: c.t.tex, scene: scene, time: time, target: target)
                        return
                    }
                    let savedCam = SceneRenderer.editCam
                    SceneRenderer.editCam = nil
                    Xf.bakingPlane = true; Xf.bakeRoot = l.id
                    let img = (l.mblur && l.mask == 0)
                        ? blurredGroupImage(l, project: project, scene: scene, time: time, ar: ar, visited: &visited)
                        : precompImage(l, children: kids, project: project, scene: scene, time: time, ar: ar, visited: &visited, ownFx: false)
                    Xf.bakingPlane = false; Xf.bakeRoot = -1
                    SceneRenderer.editCam = savedCam
                    if let img = img {
                        var tex = img.tex
                        let ct = (liveGrp[l.id]?.t.width == width && liveGrp[l.id]?.t.height == height)
                            ? liveGrp[l.id]!.t : Gl.Target(width, height)
                        ct.bind()
                        glDisable(GLenum(GL_BLEND)); blit(img.tex); glEnable(GLenum(GL_BLEND))
                        liveGrp[l.id] = (ckey, ct); tex = ct.tex
                        drawBakedPlane(l, tex: tex, scene: scene, time: time, target: target)
                    }
                }
                return
            }
            if (l.mblur || (Xf.camera(for: l)?.mblur ?? false)) && l.mask == 0 {
                drawBlurredGroup(l, project: project, scene: scene, time: time, target: target, ar: ar,
                                 visited: &visited)
            } else {
                drawGroup(l, project: project, scene: scene, time: time, target: target, ar: ar, visited: &visited)
            }
            return
        default:
            break
        }

        // Twitch → Time operator: snaps the layer's footage forward / back a few frames
        let time = twitchRetime(l, project: project, time)
        let opacity = l.p("opacity", l.editTime("opacity", time))
        let moveFx = movingFx(l, time)

        // motion blur: accumulate sub-time renders. A camera with motion blur on
        // blurs every 3D layer below it (so camera moves blur everything).
        let blurOn = l.mblur || (Xf.camera(for: l)?.mblur ?? false)
        var mbSamples = 1
        let hasParticles = l.type == .PARTICLES || (l.fx.contains("particles") && !l.fxOff.contains("particles"))
        let amount = l.p("mbAmount", time)
        let shutter = 0.12 * amount
        if blurOn {
            let cap = min(Int(max(2, l.p("mbSamples", time))), 64)
            let camMoves = (Xf.camera(for: l) != nil) && (l.is3d || l.type == .MODEL || l.type == .PARTICLES)
            let content = l.type == .VIDEO || l.type == .PARTICLES || l.type == .MODEL || l.type == .FLARE || !l.fx.isEmpty || camMoves
            // samples follow the real on-screen travel (projected through the camera VP) so the
            // copies always overlap: ~1 sample per pixel travelled, clamped 8...64
            let px = screenTravel(l, time: time, shutter: shutter)
            if px >= 0.5 {
                mbSamples = min(hasParticles ? (isExport ? 32 : 6) : (isExport ? 64 : 10), max(isExport ? 8 : 4, Int(px.rounded(.up)) / (isExport ? 1 : 2) + 1))
            } else if content && !hasParticles && l.type != .ADJUST && l.type != .IMAGE && l.type != .TEXT && l.type != .SHAPE && l.type != .FLARE && l.type != .MODEL {
                // only video (internal motion) needs sub-frame averaging when nothing moves on screen
                mbSamples = min(cap, isExport ? 6 : 3)
            }
            // adjustment layers act on the already-composited scene: averaging copies of it only
            // costs time and dims glow/bloom, so never blur them
            if l.type == .ADJUST { mbSamples = 1 }
            // movement made by effects (Oscillate, Twitch slide / scale) is blurred by evaluating the
            // effects at every sub-frame sample, so motion blur always works on them
            else if moveFx { mbSamples = max(mbSamples, isExport ? 96 : 12) }
        }
        // Motion Tile on a 3D layer: tile the layer flat, then place the tiled plane in 3D
        if l.is3d && l.type != .MODEL && l.type != .ADJUST,
           l.fx.contains(where: { !l.fxOff.contains($0) && Registry.get($0)?.id == "motiontile" }) {
            let savedCam = SceneRenderer.editCam
            SceneRenderer.editCam = nil
            Xf.flatDraw = true; Xf.bakingPlane = true; Xf.bakeRoot = l.id
            renderLayerContent(l, scene: scene, time: time, ar: ar, visited: &visited, target: target)
            applyEffects(l, time: time)
            Xf.flatDraw = false; Xf.bakingPlane = false; Xf.bakeRoot = -1
            SceneRenderer.editCam = savedCam
            drawPlane(l, src: layerA!.tex, scene: scene, time: time, target: target, opacity: opacity, mode: flareMode(l))
            return
        }
        if mbSamples > 1 {
            let stutter = l.mbStutter
            if hasParticles { particleSimTime = time }
            defer { particleSimTime = nil }
            accumTarget!.bind()
            glClearColor(0, 0, 0, 0)
            glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
            for s in 0..<mbSamples {
                let u = (Float(s) + mbJitter(s, time)) / Float(mbSamples)
                var st = time - shutter * (u - 0.5)
                if stutter { st = time - shutter * 0.5 * round(Float(s) / Float(max(mbSamples - 1, 1)) - 0.5) }
                let clamped = clamp(st, l.start, l.end)
                modelDepthDirty = true
                renderLayerContent(l, scene: scene, time: clamped, ar: ar, visited: &visited,
                                   target: target)
                if moveFx { applyEffects(l, time: clamped) }
                let frac = u - 0.5
                composite(accumTarget!, src: layerA!.tex, alpha: 1 / Float(s + 1), mode: 5,
                          rgbShift: l.mbRgb ? frac * 0.004 * amount : 0)
            }
            if !l.fx.isEmpty && !moveFx {
                // effects run once on the blurred result (was once per sample: far too slow)
                glowBlurComp = 2.4   // blurred content is dimmer: keep Deep Glow's strength
                defer { glowBlurComp = 1 }
                layerA!.bind()
                glDisable(GLenum(GL_BLEND))
                blit(accumTarget!.tex)
                glEnable(GLenum(GL_BLEND))
                applyEffects(l, time: time)
                composite(target, src: layerA!.tex, alpha: opacity, mode: flareMode(l))
            } else {
                composite(target, src: accumTarget!.tex, alpha: opacity, mode: flareMode(l))
            }
        } else if (l.type == .IMAGE || l.type == .VIDEO) && l.blend == 0 && l.mask == 0 && l.fx.isEmpty {
            // Fast path (the common case: a plain image/video layer): one blended quad
            // straight into the scene. The general path below costs four full-screen
            // passes and three render-target switches per layer, which is what made scenes
            // with dozens of layers crawl on a tile-based GPU.
            if opacity <= 0.0005 { return }
            target.bind()
            glEnable(GLenum(GL_BLEND))
            glBlendFunc(GLenum(GL_ONE), GLenum(GL_ONE_MINUS_SRC_ALPHA))
            drawMediaLayer(l, time: time, opacity: opacity)
            glDisable(GLenum(GL_BLEND))
        } else {
            renderLayerContent(l, scene: scene, time: time, ar: ar, visited: &visited, target: target)
            applyEffects(l, time: time)
            cutByNearer3D(l, scene: scene, time: time, ar: ar, visited: &visited, target: target)
            composite(target, src: layerA!.tex, alpha: opacity, mode: flareMode(l))
        }
    }

    /// Occlusion: a 3D layer / model hides the parts of other 3D layers that sit behind it
    /// (layer order no longer decides who is in front). Cuts the layer in `layerA` by the
    /// silhouette of every nearer occluding 3D layer.
    private func cutByNearer3D(_ l: Layer, scene: Scene, time: Float, ar: Float,
                               visited: inout [Layer: Bool], target: Gl.Target) {
        guard l.occlude, l.is3d, l.type != .MODEL, !Xf.flatDraw, let a = layerA, let b = layerB, let c = accumTarget else { return }
        let z = Xf.worldZ(l, time)
        var cut = false
        for o in scene.layers where o !== l && o.visible && o.occlude && (o.is3d || o.type == .MODEL)
            && o.parentId == l.parentId && o.isRenderable() && o.type != .PARTICLES && o.type != .FLARE
            && time >= o.start - 0.001 && time <= o.end + 0.001 && visited[o] == nil
            && Xf.worldZ(o, time) > z + 0.001 && o.p("opacity", time) > 0.5 {
            // snapshot the layer, render the occluder, cut the snapshot by its alpha
            if !cut { c.bind(); glDisable(GLenum(GL_BLEND)); blit(a.tex); glEnable(GLenum(GL_BLEND)); cut = true }
            renderLayerContent(o, scene: scene, time: time, ar: ar, visited: &visited, target: target)
            b.bind(); glClearColor(0, 0, 0, 0); glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
            glDisable(GLenum(GL_BLEND)); blit(a.tex); glEnable(GLenum(GL_BLEND))
            a.bind(); glClearColor(0, 0, 0, 0); glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
            composite(a, src: c.tex, mask: b.tex, maskMode: 2, alpha: 1, mode: 0)
            c.bind(); glDisable(GLenum(GL_BLEND)); blit(a.tex); glEnable(GLenum(GL_BLEND))
        }
    }

    /// True when an enabled effect on `l` moves pixels over time (Oscillate; Twitch slide / scale).
    private func movingFx(_ l: Layer, _ time: Float) -> Bool {
        for e in l.fx where !l.fxOff.contains(e) {
            switch Registry.get(e)?.id {
            case "oscillate", "randisp": return true
            case "motiontile":
                if l.p(e + "__mtScrollX", time) != 0 || l.p(e + "__mtScrollY", time) != 0 { return true }
            case "twitch":
                if l.p(e + "__twEnSlide", time) >= 0.5 || l.p(e + "__twEnScale", time) >= 0.5 { return true }
            default: break
            }
        }
        return false
    }

    /// Twitch "Time" operator: random frame snaps of the layer's own footage.
    private func twitchRetime(_ l: Layer, project: Project, _ time: Float) -> Float {
        guard !l.fx.isEmpty else { return time }
        var t = time
        for e in l.fx where !l.fxOff.contains(e) && Registry.get(e)?.id == "twitch" {
            guard l.p(e + "__twEnTime", time) >= 0.5 else { continue }
            let k = e + "__"
            let step = floor(time * 8 * l.p(k + "twSpeed", time) * l.p(k + "twTmSpeed", time))
            let seed = l.p(k + "twTmSeed", time)
            func h(_ a: Float) -> Float {
                var x = UInt32(truncatingIfNeeded: Int(a * 1000)) &* 2654435761
                x = (x ^ (x >> 15)) &* 2246822519; x ^= x >> 13
                return Float(x & 0xFFFF) / 65536
            }
            guard h(step * 3.1 + seed * 7.7) < l.p(k + "twTmTwitches", time) else { continue }
            let frames = (h(step * 5.3 + seed + 1) * 2 - 1) * l.p(k + "twTmAmount", time) * l.p(k + "twAmount", time)
            t += frames.rounded() / Float(max(1, project.fps))
        }
        return clamp(t, l.start, l.end)
    }

    /// Stable per-frame jitter in [0,1) for stratified blur sampling (hash of sample + frame).
    private func mbJitter(_ s: Int, _ time: Float) -> Float {
        var h = UInt32(truncatingIfNeeded: s &* 73856093) ^ UInt32(truncatingIfNeeded: Int(time * 1000) &* 19349663)
        h = (h ^ (h >> 13)) &* 1274126177
        h ^= h >> 16
        return Float(h & 0xFFFF) / 65536
    }

    /// Max on-screen distance (pixels) any quad corner/centre travels between
    /// time - shutter/2 and time + shutter/2, including camera motion.
    private func screenTravel(_ l: Layer, time: Float, shutter: Float) -> Float {
        var (qw, qh) = Xf.quadSize(l)
        let isPart = l.type == .PARTICLES || l.fx.contains("particles")
        if isPart { qw *= 2.5; qh *= 2.5 }
        let useCam = l.is3d || (isPart && Xf.camera(for: l) != nil)
        let ar = Float(width) / Float(max(height, 1))
        let halfW = Float(width) * 0.5, halfH = Float(height) * 0.5
        func proj(_ t: Float, _ cx: Float, _ cy: Float) -> (Float, Float)? {
            let m = Xf.matrix(l, t)
            let x = cx * qw, y = cy * qh
            let wx = m[0] * x + m[2] * y + m[4]
            let wy = m[1] * x + m[3] * y + m[5]
            if useCam {
                let z = Xf.worldZ(l, t)
                let (vp, has) = cameraVP(l, scene: Editor.scene, time: t)
                if has {
                    let cw = vp[3] * wx + vp[7] * wy + vp[11] * z + vp[15]
                    if cw < 0.02 { return nil }
                    let cxp = vp[0] * wx + vp[4] * wy + vp[8] * z + vp[12]
                    let cyp = vp[1] * wx + vp[5] * wy + vp[9] * z + vp[13]
                    return (cxp / cw, cyp / cw)
                }
                let w = 1 - z / 3
                if w < 0.02 { return nil }
                return (wx / ar / w, wy / w)
            }
            return (wx / ar, wy)
        }
        var best: Float = 0
        let pts: [(Float, Float)] = [(-0.5, -0.5), (0.5, -0.5), (-0.5, 0.5), (0.5, 0.5), (0, 0)]
        for (cx, cy) in pts {
            guard let a = proj(time - shutter * 0.5, cx, cy), let b = proj(time + shutter * 0.5, cx, cy) else { continue }
            let dx = (a.0 - b.0) * halfW, dy = (a.1 - b.1) * halfH
            best = max(best, (dx * dx + dy * dy).squareRoot())
        }
        return best
    }

    /// Motion blur for a whole group: children are rendered at several sub-times
    /// and averaged, so everything inside the group blurs together.
    private func drawBlurredGroup(_ g: Layer, project: Project, scene: Scene, time: Float,
                                  target: Gl.Target, ar: Float, visited: inout [Layer: Bool]) {
        guard let img = blurredGroupImage(g, project: project, scene: scene, time: time, ar: ar,
                                          visited: &visited) else { return }
        composite(target, src: img.tex, alpha: g.p("opacity", time), mode: g.blend)
    }

    /// The motion-blurred picture of a group (before opacity / blend); lives in the accum buffer.
    private func blurredGroupImage(_ g: Layer, project: Project, scene: Scene, time: Float,
                                   ar: Float, visited: inout [Layer: Bool]) -> Gl.Target? {
        let children = scene.layers.filter { $0.parentId == g.id }
        guard !children.isEmpty, let accum = accumTarget, let grp = groupTarget else { return nil }
        let amount = g.p("mbAmount", time)
        let shutter = 0.12 * amount
        var travel: Float = 0
        for c in children { travel = max(travel, screenTravel(c, time: time, shutter: shutter)) }
        let n = travel >= 0.5 ? min(isExport ? 48 : 8, max(isExport ? 8 : 4, Int(travel.rounded(.up)) / (isExport ? 1 : 3) + 1))
                              : min(Int(max(2, g.p("mbSamples", time))), isExport ? 12 : 4)
        accum.bind()
        glClearColor(0, 0, 0, 0)
        glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
        for s in 0..<n {
            let st = clamp(time - shutter * ((Float(s) + mbJitter(s, time)) / Float(n) - 0.5), g.start, g.end)
            modelDepthDirty = true
            grp.bind()
            glClearColor(0, 0, 0, 0)
            glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
            for c in children {
                drawLayer(c, project: project, scene: scene, time: st, target: grp, ar: ar, visited: &visited)
            }
            composite(accum, src: grp.tex, alpha: 1 / Float(s + 1), mode: 5, rgbShift: 0)
        }
        return accum
    }

    // MARK: - content

    private func renderLayerContent(_ l: Layer, scene: Scene, time: Float, ar: Float,
                                    visited: inout [Layer: Bool], target: Gl.Target) {
        layerA!.bind()
        glClearColor(0, 0, 0, 0)
        glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
        glDisable(GLenum(GL_BLEND))

        switch l.type {
        case .IMAGE, .VIDEO:
            drawMediaLayer(l, time: time)
        case .TEXT:
            drawTextLayer(l, time: time)
        case .SHAPE:
            // "Particles" added from the + menu is a Shape layer carrying the particles effect
            if l.fx.contains("particles") && !l.fxOff.contains("particles") {
                if l.p("pShowSrc", l.editTime("pShowSrc", time)) >= 0.5 {
                    drawShapeLayer(l, time: time)
                }
                drawParticleLayer(l, time: time)
            } else {
                drawShapeLayer(l, time: time)
            }
        case .FLARE:
            drawFlareLayer(l, time: time)
        case .PARTICLES:
            if l.p("pShowSrc", l.editTime("pShowSrc", time)) >= 0.5 {
                drawShapeLayer(l, time: time)
            }
            drawParticleLayer(l, time: time)
        case .MODEL:
            drawModelLayer(l, scene: scene, time: time, ar: ar)
        case .ADJUST:
            // content = the current accumulation buffer (scene or group)
            blit(target.tex)
        default:
            break
        }
        glEnable(GLenum(GL_BLEND))
    }

    /// Fullscreen (identity) state for the layer-quad program. blit()/present() draw with the
    /// same program as 3D layers; without this reset they reused the previous layer's
    /// rotation / perspective, so every full-frame copy came out tilted — the diagonal
    /// "cut" across Deep Glow (and any haze) that only showed once something glowed.
    private func resetQuadState(_ p: GLProgram) {
        p.setVec3("uRot", 0, 0, 0)
        p.setFloat("uZ", 0)
        p.setFloat("uInvCam", 0)
        p.setFloat("uUseVP", 0)
    }

    /// Fullscreen copy of `tex` into the currently bound target.
    private func blit(_ tex: GLuint) {
        guard let p = quadProg else { return }
        p.use()
        resetQuadState(p)
        p.setFloat("uFlipY", 0)
        p.setVec4("uColor", 1, 1, 1, 1)
        p.setMat3("uMat", [1, 0, 0, 0, 1, 0, 0, 0, 1])
        p.setVec2("uQuad", Float(width) / Float(max(height, 1)) * 2, 2)
        p.setFloat("uAspect", Float(width) / Float(max(height, 1)))
        p.setTexture("uTex", tex, 0)
        Gl.drawQuad(p)
    }

    private func drawMediaLayer(_ l: Layer, time: Float, opacity: Float = 1) {
        guard let path = l.imagePath else { return }
        var tex: GLuint = 0
        if l.type == .VIDEO {
            let srcT = sourceTime(l, time)
            if let vs = videoSource {
                tex = vs.videoTexture(layerId: l.id, path: path, srcTime: srcT)
            } else {
                let s = samplerFor(l)
                tex = s.texture(at: srcT)
            }
        }
        if tex == 0 {
            tex = imageTexture(path)
        }
        guard tex != 0 else { return }
        if let p = quadProg {
            p.use()
            p.setFloat("uFlipY", 1)
            p.setVec4("uColor", opacity, opacity, opacity, opacity)
            p.setTexture("uTex", tex, 0)
            drawLayerQuad(l, time: time, program: p)
        }
    }

    private func drawTextLayer(_ l: Layer, time: Float) {
        let img = TextRaster.raster(l, time)
        guard img.size.width > 1, img.size.height > 1, let tex = Gl.upload(img) else { return }
        defer { Gl.delete(tex) }
        if let p = quadProg {
            p.use()
            p.setFloat("uFlipY", 1)
            p.setVec4("uColor", 1, 1, 1, 1)
            p.setTexture("uTex", tex, 0)
            drawLayerQuad(l, time: time, program: p)
        }
    }

    private func drawShapeLayer(_ l: Layer, time: Float) {
        guard let p = shapeProg else { return }
        let (qw, qh) = Xf.quadSize(l)
        let m = Xf.matrix(l, time)
        p.use()
        p.setMat3("uMat", m)
        p.setVec2("uQuad", qw, qh)
        p.setFloat("uAspect", Float(width) / Float(max(height, 1)))
        let c = l.color
        p.setVec4("uColor",
                  Float((UInt32(bitPattern: c) >> 16) & 0xFF) / 255,
                  Float((UInt32(bitPattern: c) >> 8) & 0xFF) / 255,
                  Float(UInt32(bitPattern: c) & 0xFF) / 255,
                  Float((UInt32(bitPattern: c) >> 24) & 0xFF) / 255)
        var kind = 0
        switch l.shape {
        case .RECT: kind = 0
        case .ROUND: kind = 1
        case .CIRCLE: kind = 2
        case .TRIANGLE: kind = 3
        case .STAR: kind = 4
        }
        p.setFloat("uKind", Float(kind))
        p.setFloat("uCornerRadius", 0.12)
        Gl.drawQuad(p)
    }

    private func drawFlareLayer(_ l: Layer, time: Float) {
        guard let f = l.flare, let p = flareProg else { return }
        let ar = Float(width) / Float(max(height, 1))
        let lt = l.editTime("x", time)
        var wx = l.p("x", lt), wy = l.p("y", lt)
        var visible: Float = 1
        var sizeMul: Float = 1

        if l.is3d {
            // real 3D light: projected through the camera; grows/shrinks with distance and
            // disappears behind the camera
            let z = Xf.worldZ(l, time)
            let (vp, _) = cameraVP(l, scene: Editor.scene, time: time)
            let (nx, ny, w) = projectPoint(vp, wx, wy, z)
            let (_, _, w0) = projectPoint(vp, 0, 0, 0)
            if w <= 0.01 { visible = 0 }
            sizeMul = 1 + (min(max(w0 / max(w, 0.01), 0.15), 6) - 1) * f.depthScale
            wx = nx * ar; wy = ny
        } else if l.parentId >= 0 {
            let m = Xf.matrix(l, time)
            wx = m[4]; wy = m[5]
        }
        let fx = wx / ar / 2 + 0.5       // 0..1 across the canvas
        let fy = 0.5 - wy / 2
        let intensity = l.p("fIntensity", lt) * visible
        let axis = l.p("fAxis", lt)

        p.use()
        p.setVec2("uLight", fx, fy)
        p.setFloat("uIntensity", intensity)
        p.setFloat("uAxis", axis)
        p.setVec4("uTint",
                  Float((UInt32(bitPattern: f.tint) >> 16) & 0xFF) / 255,
                  Float((UInt32(bitPattern: f.tint) >> 8) & 0xFF) / 255,
                  Float(UInt32(bitPattern: f.tint) & 0xFF) / 255, 1)
        p.setFloat("uSizeMul", sizeMul)
        p.setFloat("uEdgeFade", f.edgeFade)
        p.setFloat("uAspect", ar)
        p.setFloat("uTime", time)
        p.setFloat("uFlicker", f.flicker)
        p.setFloat("uSpeed", f.speed)
        p.setFloat("uRayAmt", f.rayAmt)
        let n = min(f.els.count, FlareEl.MAX)
        p.setFloat("uCount", Float(n))
        for i in 0..<FlareEl.MAX {
            guard i < n else { p.setVec4("uA[\(i)]", -1, 0, 0, 0); continue }
            let e = f.els[i]
            p.setVec4("uA[\(i)]", Float(e.enabled ? e.type : -1), e.pos, e.size, e.rot)
            p.setVec4("uB[\(i)]", e.bright, e.soft, e.thick, max(e.stretch, 0.05))
            p.setVec4("uC[\(i)]", Float(e.sides), Float(e.rays), e.chroma, e.follow ? 1 : 0)
            p.setVec4("uD[\(i)]", e.round, e.star, e.curve, e.grad)
            p.setVec4("uE[\(i)]", e.noise, e.spin, Float(i) * 7.31 + 1.7, e.spread)
            p.setVec4("uCol[\(i)]",
                      Float((UInt32(bitPattern: e.color) >> 16) & 0xFF) / 255,
                      Float((UInt32(bitPattern: e.color) >> 8) & 0xFF) / 255,
                      Float(UInt32(bitPattern: e.color) & 0xFF) / 255, 1)
        }
        if intensity <= 0.0005 { return }          // invisible (behind the camera / zero): skip the heavy shader
        if !isExport && width >= 64 {
            // Preview: flares are smooth light, so shade them at half resolution (4× fewer pixels
            // through the expensive element loop) and upsample. Export stays full resolution.
            if flareHalf == nil || flareHalf!.width != width / 2 || flareHalf!.height != height / 2 {
                flareHalf = Gl.Target(width / 2, height / 2)
            }
            if let ft = flareHalf {
                ft.bind()
                glClearColor(0, 0, 0, 0)
                glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
                glDisable(GLenum(GL_BLEND))
                Gl.drawFull(p)
                layerA!.bind()
                glDisable(GLenum(GL_BLEND))
                blit(ft.tex)
                return
            }
        }
        Gl.drawFull(p)
    }

    private var flareHalf: Gl.Target?

    /// Flares are light: with the default blend they add onto the scene instead of covering it.
    private func flareMode(_ l: Layer) -> Int {
        l.type == .FLARE ? (l.blend == 2 ? 2 : 1) : l.blend
    }

    /// Projects a world point with a column-major 4x4: (screen x, screen y, w).
    /// The preview's renderer, so the editor overlay can project gizmos exactly like the shader.
    static weak var gizmoSource: SceneRenderer?

    /// Layer-local quad points → world (x, y) as drawn on screen (3D layers go through rotX/rotY,
    /// z and the camera, same maths as the quad vertex shader).
    func gizmoProject(_ l: Layer, time: Float, pts: [(Float, Float)]) -> [(Float, Float)] {
        let m = Xf.matrix(l, time)
        guard l.is3d else { return pts.map { Xf.apply(m, $0.0, $0.1) } }
        let lt = l.editTime("x", time)
        let d = Float.pi / 180
        let rx = l.p("rotX", lt) * d, ry = -l.p("rotY", lt) * d
        var z = Xf.worldZ(l, time)
        if !z.isFinite { z = 0 }
        var (vp, has) = cameraVP(l, scene: Editor.scene, time: time)
        if has && !vp.allSatisfy({ $0.isFinite }) { has = false; vp = [] }
        let ar = Float(width) / Float(max(height, 1))
        let cx0 = m[4], cy0 = m[5]
        return pts.map { (pt: (Float, Float)) -> (Float, Float) in
            let w = Xf.apply(m, pt.0, pt.1)
            var ox = w.0 - cx0, oy = w.1 - cy0, oz: Float = 0
            let cy = cos(ry), sy = sin(ry)
            (ox, oz) = (ox * cy + oz * sy, -ox * sy + oz * cy)
            let cx = cos(rx), sx = sin(rx)
            (oy, oz) = (oy * cx - oz * sx, oy * sx + oz * cx)
            let px = cx0 + ox, py = cy0 + oy, pz = oz + z
            if has {
                let cw = max(vp[3] * px + vp[7] * py + vp[11] * pz + vp[15], 0.02)
                let nx = (vp[0] * px + vp[4] * py + vp[8] * pz + vp[12]) / cw
                let ny = (vp[1] * px + vp[5] * py + vp[9] * pz + vp[13]) / cw
                return (nx * ar, ny)
            }
            let wv = max(1 - pz / 3, 0.02)
            return (px / wv, py / wv)
        }
    }

    private func projectPoint(_ vp: [Float], _ x: Float, _ y: Float, _ z: Float) -> (Float, Float, Float) {
        let cx = vp[0] * x + vp[4] * y + vp[8] * z + vp[12]
        let cy = vp[1] * x + vp[5] * y + vp[9] * z + vp[13]
        let cw = vp[3] * x + vp[7] * y + vp[11] * z + vp[15]
        return (cx / max(abs(cw), 0.0001), cy / max(abs(cw), 0.0001), cw)
    }

    /// While set, particle simulation uses this time (camera/layer still use the blur sub-time),
    /// so particles stay crisp and visible under motion blur instead of averaging to nothing.
    private var particleSimTime: Float? = nil

    private func drawParticleLayer(_ l: Layer, time: Float) {
        guard let p = particleProg else { return }
        let ar = Float(width) / Float(max(height, 1))
        let lt = l.editTime("x", time)
        let field = ParticlesSim.field(count: Int(l.p("pCount", lt)), spread: l.p("pSpread", lt),
                                       speed: l.p("pSpeed", lt), gravity: l.p("pGravity", lt),
                                       life: l.p("pLife", lt), seed: l.p("pSeed", lt),
                                       dirX: l.p("pDirX", lt), dirY: l.p("pDirY", lt), t: particleSimTime ?? time, ar: ar,
                                       posX: l.p("pPosX", lt), posY: l.p("pPosY", lt), posZ: l.p("pPosZ", lt),
                                       radX: l.p("pRadX", lt), radY: l.p("pRadY", lt), radZ: l.p("pRadZ", lt),
                                       dirZ: l.p("pDirZ", lt), resist: l.p("pResist", lt),
                                       wobble: l.p("pWobble", lt), sizeVar: l.p("pSizeVar", lt),
                                       sizeEnd: l.p("pSizeEnd", lt), dof: l.p("pDof", lt),
                                       focus: l.p("pFocus", lt),
                                       burst: l.p("pBurst", lt), burstForce: l.p("pBurstForce", lt),
                                       edge: l.p("pSoftEdge", lt))
        let m = Xf.matrix(l, time)
        let scene = Editor.scene
        let (vp, hasCam) = cameraVP(l, scene: scene, time: time)
        let use3D = hasCam || l.is3d
        let occlude = l.p("pOcclude", lt) >= 0.5

        // Occlude: particles behind a 3D layer / model are hidden by it.
        var blockers: [(Float, Float, Float, Float, Float)] = []   // minX, minY, maxX, maxY, z
        if occlude {
            for o in scene.layers where o !== l && o.visible
                && time >= o.start - 0.001 && time <= o.end + 0.001
                && (o.is3d || o.type == .MODEL) && o.isRenderable() && o.type != .PARTICLES {
                let ot = o.editTime("x", time)
                let sc = o.p("scale", ot)
                let (qw, qh) = Xf.quadSize(o)
                let hw = qw * sc * 0.5, hh = qh * sc * 0.5
                let ox = o.p("x", ot), oy = o.p("y", ot), oz = Xf.worldZ(o, time)
                var minX = Float.greatestFiniteMagnitude, minY = minX
                var maxX = -Float.greatestFiniteMagnitude, maxY = maxX
                var ok = true
                for (sx, sy) in [(-hw, -hh), (hw, -hh), (hw, hh), (-hw, hh)] {
                    let (px, py, pw) = projectPoint(vp, ox + sx, oy + sy, oz)
                    if pw <= 0.01 { ok = false; break }
                    minX = min(minX, px); maxX = max(maxX, px)
                    minY = min(minY, py); maxY = max(maxY, py)
                }
                if ok { blockers.append((minX, minY, maxX, maxY, oz)) }
            }
        }

        struct Pt { var x: Float; var y: Float; var z: Float; var size: Float; var life: Float; var soft: Float; var w: Float }
        var list: [Pt] = []
        list.reserveCapacity(field.count)
        let layerZ = Xf.worldZ(l, time)   // Position Z of the layer (and its 3D parents) moves the whole field
        // Rotation X / Y: the whole field turns about the layer origin (Z rotation is in the matrix)
        let pd = Float.pi / 180
        let prx = l.p("rotX", lt) * pd, pry = -l.p("rotY", lt) * pd
        let pcx = cos(prx), psx = sin(prx), pcy = cos(pry), psy = sin(pry)
        let pRot = prx != 0 || pry != 0
        for q0 in field {
            var q = q0
            if pRot {
                let x1 = q.x * pcy + q.z * psy, z1 = -q.x * psy + q.z * pcy
                let y2 = q.y * pcx - z1 * psx, z2 = q.y * psx + z1 * pcx
                q.x = x1; q.y = y2; q.z = z2
            }
            q.z += layerZ
            var wx = m[0] * q.x + m[2] * q.y + m[4]
            var wy = m[1] * q.x + m[3] * q.y + m[5]
            var sz = q.size
            var w: Float = 1
            if use3D {
                let (sx, sy, pw) = projectPoint(vp, wx, wy, q.z)
                if pw <= 0.05 { continue }
                w = pw
                if occlude {
                    var hidden = false
                    for b in blockers where q.z < b.4 - 0.001 && sx >= b.0 && sx <= b.2 && sy >= b.1 && sy <= b.3 {
                        hidden = true; break
                    }
                    if hidden { continue }
                }
            } else {
                let pf = 1 / max(0.2, 1 - q.z / 3)
                wx *= pf; wy *= pf; sz *= pf
                w = 1 / pf
            }
            list.append(Pt(x: wx, y: wy, z: q.z, size: sz, life: q.life, soft: q.soft, w: w))
        }
        if list.isEmpty { return }
        if use3D { list.sort { $0.w > $1.w } }   // far → near; the flat (2D) field needs no sort — saves ~ms per frame

        p.use()
        setMat4(p, "uVP", vp)
        p.setFloat("uAspect", ar)
        p.setFloat("uOrtho", use3D ? 0 : 1)
        p.setFloat("uSize", l.p("pSize", lt))
        p.setFloat("uPx", Float(height) * 0.5)
        // particle opacity × the layer's own opacity, plus birth/death fade
        p.setFloat("uOpacity", l.p("pOpacity", lt) * clamp(l.p("opacity", lt), 0, 1))
        p.setFloat("uFadeIn", max(0.001, l.p("pFadeIn", lt)))
        p.setFloat("uFadeOut", max(0.001, l.p("pFadeOut", lt)))
        func pc(_ k: String, _ def: UInt32) -> (Float, Float, Float, Float) {
            (colorComp(l, key: k + "_r", def: Float((def >> 16) & 0xFF) / 255, time: time),
             colorComp(l, key: k + "_g", def: Float((def >> 8) & 0xFF) / 255, time: time),
             colorComp(l, key: k + "_b", def: Float(def & 0xFF) / 255, time: time),
             colorComp(l, key: k + "_a", def: 1, time: time))
        }
        let ca = pc("pColA", 0xFFFFFFFF), cb = pc("pColB", 0xFFFFFFFF)
        p.setVec4("uColA", ca.0, ca.1, ca.2, ca.3)
        p.setVec4("uColB", cb.0, cb.1, cb.2, cb.3)

        var pts = [Float]()
        pts.reserveCapacity(list.count * 6)
        for q in list {
            pts.append(q.x); pts.append(q.y); pts.append(q.z)
            pts.append(q.size); pts.append(q.life); pts.append(q.soft)
        }
        // one buffer for the renderer's lifetime (was glGenBuffers/glDeleteBuffers every frame)
        if particleVBO == 0 { glGenBuffers(1, &particleVBO) }
        glBindBuffer(GLenum(GL_ARRAY_BUFFER), particleVBO)
        pts.withUnsafeBufferPointer { ptr in
            glBufferData(GLenum(GL_ARRAY_BUFFER), MemoryLayout<Float>.size * pts.count,
                         ptr.baseAddress, GLenum(GL_DYNAMIC_DRAW))
        }
        let stride = GLsizei(MemoryLayout<Float>.size * 6)
        let aPos = glGetAttribLocation(p.handle, "aPos")
        let aData = glGetAttribLocation(p.handle, "aData")
        if aPos >= 0 {
            glEnableVertexAttribArray(GLuint(aPos))
            glVertexAttribPointer(GLuint(aPos), 3, GLenum(GL_FLOAT), GLboolean(GL_FALSE), stride, nil)
        }
        if aData >= 0 {
            glEnableVertexAttribArray(GLuint(aData))
            glVertexAttribPointer(GLuint(aData), 3, GLenum(GL_FLOAT), GLboolean(GL_FALSE), stride,
                                  UnsafeRawPointer(bitPattern: MemoryLayout<Float>.size * 3))
        }
        glEnable(GLenum(GL_BLEND))
        glBlendFunc(GLenum(GL_ONE), GLenum(GL_ONE_MINUS_SRC_ALPHA))
        glDrawArrays(GLenum(GL_POINTS), 0, GLsizei(list.count))
        glDisable(GLenum(GL_BLEND))
        if aPos >= 0 { glDisableVertexAttribArray(GLuint(aPos)) }
        if aData >= 0 { glDisableVertexAttribArray(GLuint(aData)) }
        glBindBuffer(GLenum(GL_ARRAY_BUFFER), 0)
    }

    private func drawModelLayer(_ l: Layer, scene: Scene, time: Float, ar: Float, depthOnly: Bool = false) {
        guard let path = l.imagePath else { return }
        let lower = path.lowercased()
        if lower.hasSuffix(".vdb") {
            drawVdbLayer(l, path: path, scene: scene, time: time)
            return
        }
        guard let model = modelFor(path), let p = meshProg else { return }

        let (vp, _) = cameraVP(l, scene: scene, time: time)
        p.use()
        setMat4(p, "uVP", vp)
        let m = modelMatrix(l, time: time, model: model)
        setMat4(p, "uModel", m)

        // Real depth buffer for the model: the layer targets have none, so without it triangles were
        // drawn in file order and any concave / multi-part model looked scrambled.
        var depthOn = false
        if let tgt = layerA {
            let rb = modelDepthBuffer(tgt.width, tgt.height)
            if rb != 0 {
                glFramebufferTexture2D(GLenum(GL_FRAMEBUFFER), GLenum(GL_DEPTH_ATTACHMENT), GLenum(GL_TEXTURE_2D), rb, 0)
                if glCheckFramebufferStatus(GLenum(GL_FRAMEBUFFER)) == GLenum(GL_FRAMEBUFFER_COMPLETE) {
                    depthOn = true
                    glDisable(GLenum(GL_SCISSOR_TEST))
                    glDepthMask(GLboolean(GL_TRUE))
                    if modelDepthDirty { glClearDepthf(1); glClear(GLbitfield(GL_DEPTH_BUFFER_BIT)); modelDepthDirty = false }
                    glEnable(GLenum(GL_DEPTH_TEST))
                    glDepthFunc(GLenum(GL_LEQUAL))
                } else {
                    glFramebufferTexture2D(GLenum(GL_FRAMEBUFFER), GLenum(GL_DEPTH_ATTACHMENT), GLenum(GL_TEXTURE_2D), 0, 0)
                }
            }
        }
        glDisable(GLenum(GL_CULL_FACE))
        if depthOnly { glColorMask(GLboolean(GL_FALSE), GLboolean(GL_FALSE), GLboolean(GL_FALSE), GLboolean(GL_FALSE)) }
        model.draw(p, eye: GlbModel.eye(fromVP: vp), env: l.m3Env, metal: l.m3Metal, view: l.m3View, ao: l.m3Ao ? 1 : 0)
        if depthOnly { glColorMask(GLboolean(GL_TRUE), GLboolean(GL_TRUE), GLboolean(GL_TRUE), GLboolean(GL_TRUE)) }
        if depthOn {
            glDisable(GLenum(GL_DEPTH_TEST))
            glFramebufferTexture2D(GLenum(GL_FRAMEBUFFER), GLenum(GL_DEPTH_ATTACHMENT), GLenum(GL_TEXTURE_2D), 0, 0)
        }
    }

    /// One depth buffer shared by every model of a frame: models occlude each other per pixel (like Blender),
    /// whatever their layer order. Cleared at frame start and per motion-blur sample.
    private var modelDepthDirty = true
    private var modelDepthRB = GLuint(0)
    private var modelDepthSize = (0, 0)

    /// Depth TEXTURE (so volumes can read it to be hidden behind models).
    private func modelDepthBuffer(_ w: Int, _ h: Int) -> GLuint {
        if modelDepthRB != 0 && modelDepthSize == (w, h) { return modelDepthRB }
        if modelDepthRB != 0 { glDeleteTextures(1, &modelDepthRB); modelDepthRB = 0 }
        var t = GLuint(0)
        glGenTextures(1, &t)
        glBindTexture(GLenum(GL_TEXTURE_2D), t)
        glTexParameteri(GLenum(GL_TEXTURE_2D), GLenum(GL_TEXTURE_MIN_FILTER), GL_NEAREST)
        glTexParameteri(GLenum(GL_TEXTURE_2D), GLenum(GL_TEXTURE_MAG_FILTER), GL_NEAREST)
        glTexParameteri(GLenum(GL_TEXTURE_2D), GLenum(GL_TEXTURE_WRAP_S), GL_CLAMP_TO_EDGE)
        glTexParameteri(GLenum(GL_TEXTURE_2D), GLenum(GL_TEXTURE_WRAP_T), GL_CLAMP_TO_EDGE)
        let es3 = context.api == .openGLES3
        glTexImage2D(GLenum(GL_TEXTURE_2D), 0, es3 ? GLint(0x81A6) : GLint(0x1902), GLsizei(w), GLsizei(h), 0,
                     GLenum(0x1902), GLenum(GL_UNSIGNED_INT), nil)
        modelDepthRB = t
        modelDepthSize = (w, h)
        modelDepthDirty = true
        return t
    }

    private var vdbTex: [String: GLuint] = [:]

    /// Density lattice → 64³ volume packed as an 8×8 atlas of 64×64 slices (ES2 has no 3D textures).
    private func vdbAtlas(_ path: String, _ vol: VdbVolume) -> GLuint {
        if let t = vdbTex[path] { return t }
        guard let g = vol.grids.first, g.nx > 0, g.ny > 0, g.nz > 0 else { return 0 }
        let n = 128
        var mx: Float = 0.000001
        for v in g.data where v.isFinite { mx = max(mx, v) }
        var px = [UInt8](repeating: 0, count: 2048 * 1024)
        for z in 0..<n { for y in 0..<n { for x in 0..<n {
            let d = vol.density(x * g.nx / n, y * g.ny / n, z * g.nz / n)
            let v = d.isFinite ? min(max(d / mx, 0), 1) : 0
            px[(z / 16 * 128 + y) * 2048 + (z % 16) * 128 + x] = UInt8(v.squareRoot() * 255)
        } } }
        var t = GLuint(0)
        glGenTextures(1, &t)
        glBindTexture(GLenum(GL_TEXTURE_2D), t)
        glPixelStorei(GLenum(GL_UNPACK_ALIGNMENT), 1)
        glTexParameteri(GLenum(GL_TEXTURE_2D), GLenum(GL_TEXTURE_MIN_FILTER), GL_LINEAR)
        glTexParameteri(GLenum(GL_TEXTURE_2D), GLenum(GL_TEXTURE_MAG_FILTER), GL_LINEAR)
        glTexParameteri(GLenum(GL_TEXTURE_2D), GLenum(GL_TEXTURE_WRAP_S), GL_CLAMP_TO_EDGE)
        glTexParameteri(GLenum(GL_TEXTURE_2D), GLenum(GL_TEXTURE_WRAP_T), GL_CLAMP_TO_EDGE)
        glTexImage2D(GLenum(GL_TEXTURE_2D), 0, GL_LUMINANCE, 2048, 1024, 0, GLenum(GL_LUMINANCE),
                     GLenum(GL_UNSIGNED_BYTE), px)
        vdbTex[path] = t
        return t
    }

    private func inv4(_ m: [Float]) -> [Float] {
        var inv = [Float](repeating: 0, count: 16)
        inv[0] = m[5]*m[10]*m[15] - m[5]*m[11]*m[14] - m[9]*m[6]*m[15] + m[9]*m[7]*m[14] + m[13]*m[6]*m[11] - m[13]*m[7]*m[10]
        inv[4] = -m[4]*m[10]*m[15] + m[4]*m[11]*m[14] + m[8]*m[6]*m[15] - m[8]*m[7]*m[14] - m[12]*m[6]*m[11] + m[12]*m[7]*m[10]
        inv[8] = m[4]*m[9]*m[15] - m[4]*m[11]*m[13] - m[8]*m[5]*m[15] + m[8]*m[7]*m[13] + m[12]*m[5]*m[11] - m[12]*m[7]*m[9]
        inv[12] = -m[4]*m[9]*m[14] + m[4]*m[10]*m[13] + m[8]*m[5]*m[14] - m[8]*m[6]*m[13] - m[12]*m[5]*m[10] + m[12]*m[6]*m[9]
        inv[1] = -m[1]*m[10]*m[15] + m[1]*m[11]*m[14] + m[9]*m[2]*m[15] - m[9]*m[3]*m[14] - m[13]*m[2]*m[11] + m[13]*m[3]*m[10]
        inv[5] = m[0]*m[10]*m[15] - m[0]*m[11]*m[14] - m[8]*m[2]*m[15] + m[8]*m[3]*m[14] + m[12]*m[2]*m[11] - m[12]*m[3]*m[10]
        inv[9] = -m[0]*m[9]*m[15] + m[0]*m[11]*m[13] + m[8]*m[1]*m[15] - m[8]*m[3]*m[13] - m[12]*m[1]*m[11] + m[12]*m[3]*m[9]
        inv[13] = m[0]*m[9]*m[14] - m[0]*m[10]*m[13] - m[8]*m[1]*m[14] + m[8]*m[2]*m[13] + m[12]*m[1]*m[10] - m[12]*m[2]*m[9]
        inv[2] = m[1]*m[6]*m[15] - m[1]*m[7]*m[14] - m[5]*m[2]*m[15] + m[5]*m[3]*m[14] + m[13]*m[2]*m[7] - m[13]*m[3]*m[6]
        inv[6] = -m[0]*m[6]*m[15] + m[0]*m[7]*m[14] + m[4]*m[2]*m[15] - m[4]*m[3]*m[14] - m[12]*m[2]*m[7] + m[12]*m[3]*m[6]
        inv[10] = m[0]*m[5]*m[15] - m[0]*m[7]*m[13] - m[4]*m[1]*m[15] + m[4]*m[3]*m[13] + m[12]*m[1]*m[7] - m[12]*m[3]*m[5]
        inv[14] = -m[0]*m[5]*m[14] + m[0]*m[6]*m[13] + m[4]*m[1]*m[14] - m[4]*m[2]*m[13] - m[12]*m[1]*m[6] + m[12]*m[2]*m[5]
        inv[3] = -m[1]*m[6]*m[11] + m[1]*m[7]*m[10] + m[5]*m[2]*m[11] - m[5]*m[3]*m[10] - m[9]*m[2]*m[7] + m[9]*m[3]*m[6]
        inv[7] = m[0]*m[6]*m[11] - m[0]*m[7]*m[10] - m[4]*m[2]*m[11] + m[4]*m[3]*m[10] + m[8]*m[2]*m[7] - m[8]*m[3]*m[6]
        inv[11] = -m[0]*m[5]*m[11] + m[0]*m[7]*m[9] + m[4]*m[1]*m[11] - m[4]*m[3]*m[9] - m[8]*m[1]*m[7] + m[8]*m[3]*m[5]
        inv[15] = m[0]*m[5]*m[10] - m[0]*m[6]*m[9] - m[4]*m[1]*m[10] + m[4]*m[2]*m[9] + m[8]*m[1]*m[6] - m[8]*m[2]*m[5]
        let det = m[0]*inv[0] + m[1]*inv[4] + m[2]*inv[8] + m[3]*inv[12]
        if abs(det) < 1e-12 { return identity4() }
        return inv.map { $0 / det }
    }

    /// Ray-marched density volume. "Density" slider (layer.vdbDens) scales how thick it looks.
    private func drawVdbLayer(_ l: Layer, path: String, scene: Scene, time: Float) {
        guard let vol = volumeFor(path), vdbProg != nil else { return }
        let tex = vdbAtlas(path, vol)
        guard tex != 0 else { return }
        // Occlusion: make the shared depth hold every other model first (colour masked off)
        var depthTex = GLuint(0)
        var drew = false
        if l.occlude, let tgt = layerA {
            let ar = Float(width) / Float(max(height, 1))
            for o in scene.layers where o.type == .MODEL && o !== l && o.visible && !(o.imagePath ?? "").lowercased().hasSuffix(".vdb")
                && time >= o.start - 0.001 && time <= o.end + 0.001 && o.p("opacity", time) > 0.05 {
                drawModelLayer(o, scene: scene, time: time, ar: ar, depthOnly: true)
                drew = true
            }
            if drew && !modelDepthDirty { depthTex = modelDepthBuffer(tgt.width, tgt.height) }
        }
        guard let p = vdbProg else { return }
        let (vp, _) = cameraVP(l, scene: scene, time: time)
        let mvp = mul4(vp, modelMatrix(l, time: time, model: nil))
        p.use()
        setMat4(p, "uInv", inv4(mvp))
        setMat4(p, "uMVP", mvp)
        p.setVec3("uB", max(vol.bounds.0, 0.05) * 2, max(vol.bounds.1, 0.05) * 2, max(vol.bounds.2, 0.05) * 2)
        p.setFloat("uDens", l.vdbDens)
        let c = UInt32(bitPattern: l.vdbTint)
        p.setVec4("uColor", Float((c >> 16) & 255) / 255, Float((c >> 8) & 255) / 255, Float(c & 255) / 255, 1)
        p.setTexture("uVol", tex, 0)
        p.setFloat("uUseDepth", depthTex != 0 ? 1 : 0)
        if depthTex != 0 { p.setTexture("uDepth", depthTex, 1) }
        glDisable(GLenum(GL_BLEND))
        glDisable(GLenum(GL_DEPTH_TEST))
        // only shade pixels inside the box's screen bounds (big win with several volumes)
        let hb = [max(vol.bounds.0, 0.05), max(vol.bounds.1, 0.05), max(vol.bounds.2, 0.05)]
        var x0 = Float.greatestFiniteMagnitude, y0 = x0, x1 = -x0, y1 = -x0
        var ok = true
        for i in 0..<8 where ok {
            let x = (i & 1 == 0 ? -1 : 1) * hb[0], y = (i & 2 == 0 ? -1 : 1) * hb[1], z = (i & 4 == 0 ? -1 : 1) * hb[2]
            let w = mvp[3] * x + mvp[7] * y + mvp[11] * z + mvp[15]
            if w < 0.05 { ok = false; continue }
            let px = (mvp[0] * x + mvp[4] * y + mvp[8] * z + mvp[12]) / w
            let py = (mvp[1] * x + mvp[5] * y + mvp[9] * z + mvp[13]) / w
            x0 = min(x0, px); x1 = max(x1, px); y0 = min(y0, py); y1 = max(y1, py)
        }
        if ok {
            let W = Float(width), H = Float(height)
            let sx = max(0, Int((x0 * 0.5 + 0.5) * W) - 3), sy = max(0, Int((y0 * 0.5 + 0.5) * H) - 3)
            let ex = min(width, Int((x1 * 0.5 + 0.5) * W) + 3), ey = min(height, Int((y1 * 0.5 + 0.5) * H) + 3)
            if ex > sx && ey > sy {
                glEnable(GLenum(GL_SCISSOR_TEST)); glScissor(GLint(sx), GLint(sy), GLsizei(ex - sx), GLsizei(ey - sy))
            } else { return }
        }
        Gl.drawQuad(p)
        glDisable(GLenum(GL_SCISSOR_TEST))
        glActiveTexture(GLenum(GL_TEXTURE0))
    }

    /// Loads a freshly imported model / volume right away (on the import toast) so the first
    /// frame doesn't stall while the file is parsed.
    func warm(_ path: String) {
        EAGLContext.setCurrent(context)
        buildPrograms()
        if path.lowercased().hasSuffix(".vdb") { if let v = volumeFor(path) { _ = vdbAtlas(path, v) } }
        else { _ = modelFor(path) }
    }

    // MARK: - groups

    private func poolTarget(_ d: Int) -> Gl.Target? {
        while groupPool.count <= d { groupPool.append(Gl.Target(width, height)) }
        return groupPool[d]
    }

    /// A group is a precomp: its children render into a private transparent buffer (so nothing
    /// outside the children's own pixels is ever touched), then the mask, the group's effects,
    /// opacity and blend mode are applied to that result as one image.
    private func drawGroup(_ g: Layer, project: Project, scene: Scene, time: Float, target: Gl.Target,
                           ar: Float, visited: inout [Layer: Bool]) {
        let children = scene.layers.filter { $0.parentId == g.id }
        guard !children.isEmpty else { return }
        let opacity = g.p("opacity", time)
        let hasFx = !g.fx.isEmpty

        let hasPuppet = (g.puppet?.on ?? false) && !(g.puppet?.pins.isEmpty ?? true)
        guard g.precomp || g.mask != 0 || hasFx || hasPuppet, groupDepth < 4 else {
            // flat group: children composite straight onto the target
            for c in children {
                drawLayer(c, project: project, scene: scene, time: time, target: target, ar: ar, visited: &visited)
            }
            return
        }
        if let img = precompImage(g, children: children, project: project, scene: scene, time: time,
                                  ar: ar, visited: &visited) {
            var src = img.tex
            if hasPuppet, let warped = warpGroupImage(g, img, time: time) { src = warped }
            composite(target, src: src, alpha: opacity, mode: g.blend)
        }
    }

    private var warpProg: GLProgram?
    private var warpTarget: Gl.Target?

    /// Puppet on a group: draws the flattened group image through the pin-deformed mesh.
    private func warpGroupImage(_ g: Layer, _ img: Gl.Target, time: Float) -> GLuint? {
        guard let pp = g.puppet, let pm = PuppetMath.mesh(g, time) else { return nil }
        if warpProg == nil {
            warpProg = GLProgram(vertex: "attribute vec2 aPos; attribute vec2 aUv; varying vec2 vUv;\nvoid main(){ vUv = aUv; gl_Position = vec4(aPos, 0.0, 1.0); }",
                                 fragment: "precision mediump float; varying vec2 vUv; uniform sampler2D uTex;\nvoid main(){ gl_FragColor = texture2D(uTex, vUv); }")
        }
        if warpTarget == nil || warpTarget!.width != width || warpTarget!.height != height { warpTarget = Gl.Target(width, height) }
        guard let p = warpProg, let out = warpTarget else { return nil }
        _ = pp
        out.bind()
        glClearColor(0, 0, 0, 0); glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
        glDisable(GLenum(GL_BLEND))
        p.use()
        p.setTexture("uTex", img.tex, 0)
        Gl.drawMesh(p, pm.pos, pm.uv, pm.idx)
        return out.tex
    }

    /// The finished picture of a precomp group (children → mask → group effects), before the
    /// group's own opacity / blend. Returned buffer is `layerA`.
    private func precompImage(_ g: Layer, children: [Layer], project: Project, scene: Scene, time: Float,
                              ar: Float, visited: inout [Layer: Bool], ownFx: Bool = true) -> Gl.Target? {
        guard groupDepth < 4, let grp = poolTarget(groupDepth) else { return nil }
        groupDepth += 1
        defer { groupDepth -= 1 }

        grp.bind()
        glClearColor(0, 0, 0, 0)
        glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
        for c in children {
            drawLayer(c, project: project, scene: scene, time: time, target: grp, ar: ar, visited: &visited)
        }

        // mask buffer = first child's content
        if g.mask != 0, let first = children.first, first.isRenderable() {
            layerB!.bind()
            glClearColor(0, 0, 0, 0)
            glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
            var v: [Layer: Bool] = [:]
            renderLayerContent(first, scene: scene, time: time, ar: ar, visited: &v, target: grp)
            applyEffects(first, time: time)
            composite(grp, src: grp.tex, mask: layerB!.tex, maskMode: g.mask, alpha: 1, mode: 0)
        }

        // the group's own effects run on the flattened precomp
        layerA!.bind()
        glDisable(GLenum(GL_BLEND))
        blit(grp.tex)
        glEnable(GLenum(GL_BLEND))
        if ownFx && !g.fx.isEmpty { applyEffects(g, time: time) }
        return layerA
    }

    // MARK: - pre-render (baked group frames)

    private var preTarget: Gl.Target?

    /// Uploads the baked frame of `g` nearest to `time` and returns its texture; nil when this
    /// frame is not baked (the group then renders live).
    private func preRenderTexture(_ g: Layer, project: Project, scene: Scene, time: Float) -> GLuint? {
        let sig = PreRender.signature(g, project: project, scene: scene)
        let idx = PreRender.frameIndex(time, project.fps)
        guard let raw = PreRender.load(project.id, g.id, sig, width, height, idx) else { return nil }
        if preTarget == nil { preTarget = Gl.Target(width, height) }
        guard let t = preTarget else { return nil }
        glBindTexture(GLenum(GL_TEXTURE_2D), t.tex)
        raw.withUnsafeBytes { p in
            glTexImage2D(GLenum(GL_TEXTURE_2D), 0, GL_RGBA, GLsizei(width), GLsizei(height), 0,
                         GLenum(GL_RGBA), GLenum(GL_UNSIGNED_BYTE), p.baseAddress)
        }
        return t.tex
    }

    /// Draws a group's flat picture as a plane: straight onto the target, or (3D group / scene
    /// camera present) projected through the camera so zooming scales the plane, never its insides.
    private func drawBakedPlane(_ g: Layer, tex: GLuint, scene: Scene, time: Float, target: Gl.Target) {
        let opacity = g.p("opacity", time)
        guard let p = quadProg, let tmp = layerB, let a = layerA else {
            composite(target, src: tex, alpha: opacity, mode: g.blend); return
        }
        // 1. the group's own effects run live on the baked picture (never part of the bake)
        var src = tex
        if !g.fx.isEmpty {
            a.bind()
            glDisable(GLenum(GL_BLEND))
            blit(tex)
            glEnable(GLenum(GL_BLEND))
            applyEffects(g, time: time)
            src = a.tex
        }
        drawPlane(g, src: src, scene: scene, time: time, target: target, opacity: opacity, mode: g.blend)
    }

    /// Places a flat, layer-space picture into the scene with the layer's transform (move / scale /
    /// rotate, parents included, 3D rotation and camera when present).
    private func drawPlane(_ g: Layer, src: GLuint, scene: Scene, time: Float, target: Gl.Target,
                           opacity: Float, mode: Int) {
        guard let p = quadProg, let tmp = layerB else { composite(target, src: src, alpha: opacity, mode: mode); return }
        let (vp, has) = (g.is3d || Xf.camera(for: g) != nil) ? cameraVP(g, scene: scene, time: time) : ([Float](), false)
        if has && !vp.allSatisfy({ $0.isFinite }) { composite(target, src: src, alpha: opacity, mode: mode); return }
        let ar = Float(width) / Float(max(height, 1))
        tmp.bind()
        glClearColor(0, 0, 0, 0)
        glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
        glDisable(GLenum(GL_BLEND))
        p.use()
        resetQuadState(p)
        p.setFloat("uFlipY", 0)
        p.setVec4("uColor", 1, 1, 1, 1)
        p.setMat3("uMat", Xf.matrix(g, time))
        p.setVec2("uQuad", ar * 2, 2)
        p.setFloat("uAspect", ar)
        if g.is3d {
            let lt = g.editTime("x", time)
            let d = Float.pi / 180
            p.setVec3("uRot", g.p("rotX", lt) * d, -g.p("rotY", lt) * d, 0)
            p.setFloat("uZ", Xf.worldZ(g, time))
        }
        if has { p.setFloat("uUseVP", 1); setMat4(p, "uVP", vp) }
        if g.is3d || has { p.setFloat("uInvCam", 1.0 / 3.0) }
        p.setTexture("uTex", src, 0)
        Gl.drawQuad(p)
        glEnable(GLenum(GL_BLEND))
        composite(target, src: tmp.tex, alpha: opacity, mode: mode)
    }

    /// Renders frame `idx` of group `g` live (ignoring its own flag) and writes it to the
    /// pre-render cache. Returns false when it could not be produced.
    @discardableResult
    func preRenderFrame(_ g: Layer, idx: Int, project: Project, scene: Scene, video: VideoSource?) -> Bool {
        modelDepthDirty = true
        videoSource = video
        let ar = ensureTargets(project)
        EAGLContext.setCurrent(context)
        buildPrograms()
        let sig = PreRender.signature(g, project: project, scene: scene)
        let time = clamp(Float(idx) / Float(max(1, project.fps)), g.start, g.end)
        let savedCam = SceneRenderer.editCam
        SceneRenderer.editCam = nil
        Xf.bakingPlane = true; Xf.bakeRoot = g.id
        defer { Xf.bakingPlane = false; Xf.bakeRoot = -1; SceneRenderer.editCam = savedCam }
        let children = scene.layers.filter { $0.parentId == g.id }
        var visited: [Layer: Bool] = [:]
        visited[g] = true
        let img: Gl.Target?
        if children.isEmpty {
            layerA!.bind(); glClearColor(0, 0, 0, 0); glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
            img = layerA
        } else if (g.mblur || (Xf.camera(for: g)?.mblur ?? false)) && g.mask == 0 {
            img = blurredGroupImage(g, project: project, scene: scene, time: time, ar: ar, visited: &visited)
        } else {
            img = precompImage(g, children: children, project: project, scene: scene, time: time,
                               ar: ar, visited: &visited, ownFx: false)
        }
        guard let t = img else { return false }
        var data = [UInt8](repeating: 0, count: width * height * 4)
        glBindFramebuffer(GLenum(GL_FRAMEBUFFER), t.fbo)
        glReadPixels(0, 0, GLsizei(width), GLsizei(height), GLenum(GL_RGBA), GLenum(GL_UNSIGNED_BYTE), &data)
        PreRender.store(project.id, g.id, sig, width, height, idx, data)
        return true
    }

    /// Bakes every missing frame of every pre-rendered group at this renderer's size
    /// (used by the exporter so the final render plays the baked frames). `step` reports
    /// (done, total) and returns false to cancel.
    func preRenderAll(project: Project, scene: Scene, step: ((Int, Int) -> Bool)? = nil) {
        guard PreRender.enabled else { return }
        _ = ensureTargets(project)
        for g in PreRender.groups(in: scene) {
            let sig = PreRender.signature(g, project: project, scene: scene)
            PreRender.purgeStale(project.id, g.id, keep: sig)
            let (done0, total) = PreRender.progress(g, project: project, scene: scene, size: (width, height))
            var done = done0
            while let idx = PreRender.nextMissing(g, project: project, scene: scene, size: (width, height), from: g.start) {
                guard preRenderFrame(g, idx: idx, project: project, scene: scene, video: nil) else { break }
                done += 1
                if let s = step, !s(done, total) { return }
            }
        }
    }

    // MARK: - effects

    /// Effect programs are context-bound — this renderer compiles and caches
    /// its own copies, recording failures into Registry.errors for the UIs.
    private func effectProgram(_ d: EffectDef) -> GLProgram? {
        if let p = effectProgs[d.id] { return p }
        if failedProgs.contains(d.id) { return nil }
        let (src, _) = Gl.effectShaderSource(d)
        guard let p = GLProgram(vertex: GLProgram.defaultVertex, fragment: src) else {
            Registry.noteError(d.id, Gl.lastShaderLog)
            failedProgs.insert(d.id)
            return nil
        }
        effectProgs[d.id] = p
        return p
    }

    private func applyEffects(_ l: Layer, time: Float) {
        guard !l.fx.isEmpty else { return }
        var readTex = layerA!.tex
        var readIsA = true
        var sawBlurFx = false

        for entry in l.fx {
            if l.fxOff.contains(entry) { continue }
            guard let d = Registry.get(entry) else { continue }
            if d.id == "blur" || d.id == "radialblur" || d.id == "blurmo" { sawBlurFx = true }
            let write = readIsA ? layerB! : layerA!
            if d.id == "deepglow" {
                let saved = glowBlurComp
                if sawBlurFx { glowBlurComp = max(glowBlurComp, 2.4) }
                defer { glowBlurComp = saved }
                if applyDeepGlow(l, entry: entry, def: d, read: readTex, write: write, time: time) {
                    readTex = write.tex
                    readIsA = !readIsA
                }
                continue
            }
            guard let p = effectProgram(d) else { continue }

            p.use()
            p.setTexture("uTex", readTex, 0)
            p.setVec2("uRes", Float(write.width), Float(write.height))
            p.setFloat("uTime", time)
            p.setFloat("uHas0", 0)
            p.setFloat("uHas1", 0)
            do {   // the layer's rectangle in world units (Motion Tile works in layer space)
                let ar = Float(width) / Float(max(height, 1))
                if l.type == .GROUP || l.type == .ADJUST || l.type == .NULL || l.type == .CAMERA {
                    p.setVec2("uLC", 0, 0); p.setVec2("uLX", ar * 2, 0); p.setVec2("uLY", 0, 2)
                } else {
                    let m = Xf.matrix(l, time), (qw, qh) = Xf.quadSize(l)
                    p.setVec2("uLC", m[4], m[5])
                    p.setVec2("uLX", m[0] * qw, m[1] * qw)
                    p.setVec2("uLY", m[2] * qh, m[3] * qh)
                }
            }

            // layer inputs (in0/in1): the referenced layer's content, small
            var keepAlive: [Gl.Target] = []
            for (slot, nm) in d.inputs.enumerated() where slot < 2 {
                let rid = l.inputs[entry + ":" + nm]
                if let rid = rid, let ref = Editor.scene.layers.first(where: { $0.id == rid }),
                   ref.isRenderable(), let t = inTargets[slot] {
                    t.bind()
                    glClearColor(0, 0, 0, 0)
                    glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
                    var v: [Layer: Bool] = [:]
                    renderLayerContent(ref, scene: Editor.scene, time: time,
                                       ar: Float(width) / Float(max(height, 1)),
                                       visited: &v, target: sceneTarget!)
                    p.setTexture(slot == 0 ? "uIn0" : "uIn1", t.tex, GLint(1 + slot))
                    p.setFloat(slot == 0 ? "uHas0" : "uHas1", 1)
                    keepAlive.append(t)
                } else {
                    p.setFloat(slot == 0 ? "uHas0" : "uHas1", 0)
                }
            }
            _ = keepAlive

            // params
            let single = d.kind == 1
            for pd in d.props {
                let key = single ? pd.key : entry + "__" + pd.key
                p.setFloat(Gl.uniformName(pd.key), paramValue(l, key: key, def: pd.def, time: time))
            }
            for cp in d.colors {
                let base = single ? cp.key : entry + "__" + cp.key
                let defC = UInt32(bitPattern: cp.def)
                p.setVec4(Gl.uniformName(cp.key),
                          colorComp(l, key: base + "_r", def: Float((defC >> 16) & 0xFF) / 255, time: time),
                          colorComp(l, key: base + "_g", def: Float((defC >> 8) & 0xFF) / 255, time: time),
                          colorComp(l, key: base + "_b", def: Float(defC & 0xFF) / 255, time: time),
                          colorComp(l, key: base + "_a", def: Float((defC >> 24) & 0xFF) / 255, time: time))
            }

            write.bind()
            glDisable(GLenum(GL_BLEND))
            Gl.drawFull(p)
            glEnable(GLenum(GL_BLEND))

            readTex = write.tex
            readIsA = !readIsA
        }

        // ensure the chain's result is in layerA for compositing
        if readTex != layerA!.tex {
            layerA!.bind()
            glDisable(GLenum(GL_BLEND))
            blit(readTex)
            glEnable(GLenum(GL_BLEND))
        }
    }

    // MARK: - Deep Glow (multi-pass bloom)

    private var glowProgs: [GLProgram] = []          // extract, down, blur, final
    private var glowLevels: [Gl.Target] = []
    private var glowTmp: [Gl.Target] = []
    private var glowBlur: [Gl.Target] = []
    private var glowSize = (0, 0)
    private static let glowN = 7

    private func glowSetup() -> Bool {
        if glowProgs.isEmpty {
            let hdr = "precision highp float;\nprecision highp sampler2D;\nvarying vec2 vUv;\n"
            // the blur chain works on 16-bit float buffers: mediump is plenty and much faster on phones
            let hdrM = "precision mediump float;\nprecision mediump sampler2D;\nvarying vec2 vUv;\n"
            let extract = hdrM + """
uniform sampler2D uTex; uniform vec2 uPx; uniform float uThr, uKnee;
vec4 tap(vec2 uv) {
    vec4 t = min(texture2D(uTex, uv), vec4(16.0));
    // threshold on the premultiplied (over black) brightness: dividing by alpha made every
    // faint pixel of a glow/flare count as full white, which blew the whole area out
    float l = max(max(t.r, t.g), t.b);
    float knee = uThr * uKnee + 0.0001;
    float sf = clamp(l - uThr + knee, 0.0, 2.0 * knee);
    sf = sf * sf / (4.0 * knee);
    float k = max(sf, l - uThr) / max(l, 0.0001);
    return t * clamp(k, 0.0, 1.0);
}
void main() {
    vec2 o = uPx * 0.5;
    vec4 a = tap(vUv + vec2(-o.x, -o.y)) + tap(vUv + vec2(o.x, -o.y))
           + tap(vUv + vec2(-o.x, o.y)) + tap(vUv + vec2(o.x, o.y));
    gl_FragColor = a * 0.25;
}
"""
            let down = hdrM + """
uniform sampler2D uTex; uniform vec2 uPx;
void main() {
    vec2 o = uPx * 0.5;
    gl_FragColor = (texture2D(uTex, vUv + vec2(-o.x, -o.y)) + texture2D(uTex, vUv + vec2(o.x, -o.y))
                  + texture2D(uTex, vUv + vec2(-o.x, o.y)) + texture2D(uTex, vUv + vec2(o.x, o.y))) * 0.25;
}
"""
            let blur = hdrM + """
uniform sampler2D uTex; uniform vec2 uStep;
void main() {
    vec4 c = texture2D(uTex, vUv) * 0.2270270270;
    c += (texture2D(uTex, vUv + uStep * 1.3846153846) + texture2D(uTex, vUv - uStep * 1.3846153846)) * 0.3162162162;
    c += (texture2D(uTex, vUv + uStep * 3.2307692308) + texture2D(uTex, vUv - uStep * 3.2307692308)) * 0.0702702703;
    gl_FragColor = c;
}
"""
            // final: original + (accumulated glow). Only two textures are read.
            let fin = hdr + """
uniform sampler2D uTex; uniform sampler2D uG;
uniform float uGain, uChroma, uOnly, uTintAmt;
uniform vec4 uTintCol;
void main() {
    vec4 c = texture2D(uTex, vUv);
    vec4 g = texture2D(uG, vUv);
    if (uChroma > 0.001) {
        vec2 dir = (vUv - 0.5) * uChroma * 0.04;
        g.r = texture2D(uG, vUv + dir).r;
        g.b = texture2D(uG, vUv - dir).b;
    }
    g = clamp(g * uGain, 0.0, 64.0);
    if (!(g.r == g.r) || !(g.g == g.g) || !(g.b == g.b) || !(g.a == g.a)) { g = vec4(0.0); }
    float gl = max(g.r, max(g.g, g.b));
    g.rgb = mix(g.rgb, uTintCol.rgb * gl, uTintAmt);
    // linear for normal values (slope 1), soft shoulder only for very hot values
    vec3 add = g.rgb / (1.0 + g.rgb * 0.18);
    float n = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715)))) - 0.5;
    add += n * (1.0 / 255.0) * min(1.0, g.a * 4.0);
    add = max(add, 0.0);
    float base = uOnly > 0.5 ? 0.0 : 1.0;
    vec3 rgb = c.rgb * base + add;
    float ga = max(clamp(g.a, 0.0, 1.0), max(add.r, max(add.g, add.b)));
    float a = clamp(c.a * base + ga * (1.0 - c.a * base), 0.0, 1.0);
    gl_FragColor = vec4(rgb, a);
}
"""
            // accumulate: acc[k] = blur[k] * w + upsample(acc[k+1])
            let up = hdrM + """
uniform sampler2D uA; uniform sampler2D uB; uniform float uW;
void main() { gl_FragColor = texture2D(uA, vUv) * uW + texture2D(uB, vUv); }
"""
            let scale = hdrM + """
uniform sampler2D uA; uniform float uW;
void main() { gl_FragColor = texture2D(uA, vUv) * uW; }
"""
            for src in [extract, down, blur, fin, up, scale] {
                guard let p = GLProgram(vertex: GLProgram.defaultVertex, fragment: src) else { return false }
                glowProgs.append(p)
            }
        }
        if glowSize != (width, height) || glowLevels.isEmpty {
            glowLevels = []; glowTmp = []; glowBlur = []
            for k in 0..<SceneRenderer.glowN {
                let div = 2 << k
                let w = max(2, width / div), h = max(2, height / div)
                glowLevels.append(Gl.Target(w, h, half: true))
                glowTmp.append(Gl.Target(w, h, half: true))
                glowBlur.append(Gl.Target(w, h, half: true))
            }
            glowSize = (width, height)
        }
        return true
    }

    /// Deep Glow: threshold → downsample chain → separable Gaussian per level → weighted
    /// recombine. Smooth at every radius (no per-pixel sampling noise).
    /// >1 when the glow input was blurred (motion blur / blur effects dim the bright pass).
    var glowBlurComp: Float = 1

    private func applyDeepGlow(_ l: Layer, entry: String, def d: EffectDef, read: GLuint,
                               write: Gl.Target, time: Float) -> Bool {
        guard glowSetup() else { return false }
        let single = d.kind == 1
        func val(_ key: String, _ def: Float) -> Float {
            paramValue(l, key: single ? key : entry + "__" + key, def: def, time: time)
        }
        let radius = max(0, val("radius", 0.12))
        let intensity = max(0, val("intensity", 1))
        let comp = glowBlurComp
        let thr = min(max(val("threshold", 0.3), 0), 0.999) / comp
        let knee = min(max(val("knee", 0.5), 0), 1)
        let falloff = min(max(val("falloff", 0.5), 0), 1)
        let tintAmt = min(max(val("tintAmt", 0), 0), 1)
        let tintHue = val("tintHue", 0.08)
        let chromaAb = min(max(val("chroma", 0), 0), 1)
        let glowOnly = val("glowOnly", 0)
        let N = SceneRenderer.glowN
        glDisable(GLenum(GL_BLEND))
        glDisable(GLenum(GL_SCISSOR_TEST)); glDisable(GLenum(GL_CULL_FACE)); glDisable(GLenum(GL_DEPTH_TEST))
        glColorMask(GLboolean(GL_TRUE), GLboolean(GL_TRUE), GLboolean(GL_TRUE), GLboolean(GL_TRUE))

        // 1) bright pass → level 0 (half res)
        let ex = glowProgs[0]
        ex.use()
        ex.setTexture("uTex", read, 0)
        ex.setVec2("uPx", 1 / Float(width), 1 / Float(height))
        ex.setFloat("uThr", thr)
        ex.setFloat("uKnee", knee)
        Gl.renderQuad(ex, glowLevels[0])

        // level weights follow the radius continuously (log-space gaussian)
        let sigmaPx = max(radius, 0.0005) * Float(height) * 0.2
        let pos = min(max(log2(max(sigmaPx, 1) / 4), 0), Float(N - 1))
        var w = [Float](repeating: 0, count: N)
        for k in 0..<N {
            let dk = Float(k) - pos
            let sg = 0.55 + falloff * 1.6
            w[k] = exp(-dk * dk / (2 * sg * sg))
        }
        // Normalise to the strongest level (not the sum): dividing by the sum spread the energy
        // over all levels and made the glow collapse as the radius grew.
        let wMax = max(w.max() ?? 1, 0.0001)
        for k in 0..<N { w[k] = w[k] / wMax * 0.9 }
        // levels that contribute < 4% are skipped entirely (no blur, no accumulate); the
        // downsample chain stops at the deepest level that is still used
        let minW: Float = 0.035
        var top = 0
        for k in 0..<N where w[k] > minW { top = k }

        // 2) downsample chain (only as deep as needed)
        let dn = glowProgs[1]
        if top >= 1 {
            for k in 1...top {
                dn.use()
                dn.setTexture("uTex", glowLevels[k - 1].tex, 0)
                dn.setVec2("uPx", 1 / Float(glowLevels[k - 1].width), 1 / Float(glowLevels[k - 1].height))
                Gl.renderQuad(dn, glowLevels[k])
            }
        }

        // 3) separable Gaussian on every used level
        let bl = glowProgs[2]
        for k in 0...top where w[k] > minW || k == 0 {
            let lv = glowLevels[k]
            bl.use()
            bl.setTexture("uTex", lv.tex, 0)
            bl.setVec2("uStep", 1 / Float(lv.width), 0)
            Gl.renderQuad(bl, glowTmp[k])
            bl.setTexture("uTex", glowTmp[k].tex, 0)
            bl.setVec2("uStep", 0, 1 / Float(lv.height))
            Gl.renderQuad(bl, glowBlur[k])
        }

        // 4) accumulate from the deepest used level up (each pass reads at most two textures;
        //    results go into glowTmp, which is free once the blur is done)
        let sc = glowProgs[5], upP = glowProgs[4]
        var acc = -1                                  // glowTmp index holding the running sum
        for k in stride(from: top, through: 0, by: -1) where w[k] > minW || k == 0 {
            if acc < 0 {
                sc.use()
                sc.setTexture("uA", glowBlur[k].tex, 0)
                sc.setFloat("uW", w[k])
                Gl.renderQuad(sc, glowTmp[k])
            } else {
                upP.use()
                upP.setTexture("uA", glowBlur[k].tex, 0)
                upP.setTexture("uB", glowTmp[acc].tex, 1)
                upP.setFloat("uW", w[k])
                Gl.renderQuad(upP, glowTmp[k])
            }
            acc = k
        }

        let f = glowProgs[3]
        f.use()
        f.setTexture("uTex", read, 0)
        f.setTexture("uG", glowTmp[max(acc, 0)].tex, 1)
        f.setFloat("uGain", intensity * 1.6 * (1 + (comp - 1) * 0.6))
        f.setFloat("uChroma", chromaAb)
        f.setFloat("uOnly", glowOnly)
        f.setFloat("uTintAmt", tintAmt)
        var tr: CGFloat = 1, tg: CGFloat = 1, tb: CGFloat = 1, ta: CGFloat = 1
        UIColor(hue: CGFloat(tintHue - floor(tintHue)), saturation: 1, brightness: 1, alpha: 1).getRed(&tr, green: &tg, blue: &tb, alpha: &ta)
        f.setVec4("uTintCol", Float(tr), Float(tg), Float(tb), 1)
        Gl.renderQuad(f, write)
        glEnable(GLenum(GL_BLEND))
        return true
    }

    private func paramValue(_ l: Layer, key: String, def: Float, time: Float) -> Float {
        if let tr = l.props[key] {
            return tr.evalExpr(l.editTime(key, time), time, tr.exprActive() ? Editor.scene.markersByName() : [:])
        }
        return def
    }

    private func colorComp(_ l: Layer, key: String, def: Float, time: Float) -> Float {
        if let tr = l.props[key] {
            return tr.eval(l.editTime(key, time))
        }
        return def
    }

    // MARK: - composite

    /// Composites `src` over `target`'s current content (through the
    /// scratch buffer — never read+write the same texture in one pass).
    private func composite(_ target: Gl.Target, src: GLuint, alpha: Float, mode: Int,
                           rgbShift: Float = 0) {
        composite(target, src: src, mask: 0, maskMode: 0, alpha: alpha, mode: mode, rgbShift: rgbShift)
    }

    private func composite(_ target: Gl.Target, src: GLuint, mask: GLuint, maskMode: Int,
                           alpha: Float, mode: Int, rgbShift: Float = 0) {
        guard let p = compositeProg, let scratch = scratchTarget else { return }
        scratch.bind()
        glDisable(GLenum(GL_BLEND))
        p.use()
        p.setTexture("uScene", target.tex, 0)
        p.setTexture("uSrc", src, 1)
        p.setTexture("uMask", mask, 2)
        p.setFloat("uAlpha", alpha)
        p.setFloat("uMode", Float(mode))
        p.setFloat("uMaskMode", Float(maskMode))
        p.setFloat("uRgbShift", rgbShift)
        Gl.drawFull(p)

        if target !== scratch && target.width == scratch.width && target.height == scratch.height {
            // the result already sits in `scratch`: swap the two buffers instead of copying it
            // back (saves one full-screen pass per composite — the biggest fixed cost per layer)
            swap(&target.tex, &scratch.tex)
            swap(&target.fbo, &scratch.fbo)
        } else {
            target.bind()
            blit(scratch.tex)
        }
    }

    // MARK: - helpers

    /// Image layers → GL textures, kept in a byte-budgeted LRU. (The old cache held 24
    /// textures, evicted without deleting them on the GPU, and so thrashed — re-decoding
    /// PNGs every frame and leaking GPU memory — as soon as a scene had more than 24
    /// images. That was the lag + crash with ~60 layers.)
    private func imageTexture(_ path: String) -> GLuint {
        // textures never need more pixels than the working resolution (plus headroom
        // for zoomed layers); this also keeps decoded size small for big canvases
        let side = max(384, 1536 / max(1, quality))
        if side != imageTexSide { flushImageTextures(); imageTexSide = side }
        if let t = imageTex[path] {
            if imageTexOrder.last != path {
                if let i = imageTexOrder.firstIndex(of: path) { imageTexOrder.remove(at: i) }
                imageTexOrder.append(path)
            }
            return t
        }
        var made: GLuint = 0
        var bytes = 0
        autoreleasepool {
            guard let img = UIImage(contentsOfFile: path) else { return }
            bytes = Gl.uploadBytes(img, maxSide: side)
            made = Gl.upload(img, maxSide: side) ?? 0
        }
        if made == 0 { return 0 }
        imageTex[path] = made
        imageTexBytes[path] = bytes
        imageTexTotal += bytes
        imageTexOrder.append(path)
        while imageTexTotal > imageTexBudget, imageTexOrder.count > 1 {
            let old = imageTexOrder.removeFirst()
            if let t = imageTex.removeValue(forKey: old) { Gl.delete(t) }
            imageTexTotal -= imageTexBytes.removeValue(forKey: old) ?? 0
        }
        return made
    }

    private func flushImageTextures() {
        EAGLContext.setCurrent(context)
        for (_, t) in imageTex { Gl.delete(t) }
        imageTex.removeAll(); imageTexBytes.removeAll(); imageTexOrder.removeAll()
        imageTexTotal = 0
    }

    /// Drops every cached image texture (memory warning / leaving the editor).
    func trimMemory() { flushImageTextures() }

    private func samplerFor(_ l: Layer) -> VideoFrames.Sampler {
        if let s = videoSamplers[l.id] { return s }
        let s = VideoFrames.Sampler(path: l.imagePath ?? "")
        videoSamplers[l.id] = s
        return s
    }

    private var failedModels = Set<String>()

    private func modelFor(_ path: String) -> GlbModel? {
        if let m = models[path] { return m }
        if failedModels.contains(path) { return nil }      // never re-parse a broken file every frame
        let p = GlbModel.validate(path: path)
        guard let m = GlbModel.load(p) else {
            failedModels.insert(path)
            return nil
        }
        models[path] = m
        models[p] = m
        return m
    }

    private func volumeFor(_ path: String) -> VdbVolume? {
        if let v = volumes[path] { return v }
        guard let v = VdbVolume.load(path) else { return nil }
        volumes[path] = v
        return v
    }

    /// Source-media time for a video layer at scene time `t` (remap aware).
    private func sourceTime(_ l: Layer, _ t: Float) -> Float {
        if let tr = l.props["remapT"], !tr.keys.isEmpty {
            return max(0, tr.eval(t) + l.srcOffset)
        }
        let sp = l.props["remapSpeed"]?.eval(t) ?? 1
        return max(0, (t - l.start) * sp + l.srcOffset)
    }

    /// Draws the layer's quad with its world matrix (2D path).
    private func drawLayerQuad(_ l: Layer, time: Float, program: GLProgram) {
        let (qw, qh) = Xf.quadSize(l)
        let m = Xf.matrix(l, time)
        program.setMat3("uMat", m)
        program.setVec2("uQuad", qw, qh)
        program.setFloat("uAspect", Float(width) / Float(max(height, 1)))
        if l.is3d && !Xf.flatDraw {
            let lt = l.editTime("x", time)
            let d = Float.pi / 180
            program.setVec3("uRot", l.p("rotX", lt) * d, -l.p("rotY", lt) * d, 0)
            let zz = Xf.worldZ(l, time)
            program.setFloat("uZ", zz.isFinite ? zz : 0)
            var (vp, hasCam) = cameraVP(l, scene: Editor.scene, time: time)
            if hasCam && !vp.allSatisfy({ $0.isFinite }) { hasCam = false; vp = [] }   // broken camera: draw flat, never vanish
            if hasCam {
                program.setFloat("uUseVP", 1)
                setMat4(program, "uVP", vp)
            } else {
                program.setFloat("uUseVP", 0)
            }
            program.setFloat("uInvCam", 1.0 / 3.0)
        } else {
            program.setFloat("uUseVP", 0)
            program.setVec3("uRot", 0, 0, 0)
            program.setFloat("uZ", 0)
            program.setFloat("uInvCam", 0)
        }
        if let pm = PuppetMath.mesh(l, time) {
            program.setFloat("uMesh", 1)
            Gl.drawMesh(program, pm.pos, pm.uv, pm.idx)
            program.setFloat("uMesh", 0)
        } else {
            program.setFloat("uMesh", 0)
            Gl.drawQuad(program)
        }
    }

    // MARK: - matrices / cameras

    /// Scene Setup mode (the top-bar orbit camera): while set, every 3D layer
    /// is drawn through this editing camera instead of the scene camera. The
    /// active camera layer is never touched, so leaving the mode restores the
    /// exact previous view. Layout: [fov°, eyeX, eyeY, eyeZ, rotX°, rotY°].
    static var editCam: [Float]? = nil

    private func cameraVP(_ l: Layer, scene: Scene, time: Float) -> ([Float], Bool) {
        let ar = Float(width) / Float(max(height, 1))
        if let e = SceneRenderer.editCam {
            return (perspectiveLookAt(e[0], ar, e[1], e[2], e[3],
                                      e[4] * Float.pi / 180, e[5] * Float.pi / 180), true)
        }
        if let cam = Xf.camera(for: l) {
            let ct = cam.editTime("x", time)
            // a missing / zero / NaN field of view made 1/tan(fov) infinite, so every 3D layer
            // below the camera projected to nothing
            var fov = cam.p("fov", ct)
            if !fov.isFinite || fov < 10 { fov = 55 }
            fov = min(fov, 150)
            // z is an offset from the neutral distance at which the z=0 plane exactly fills the
            // comp (visible half-height 1, same as 2D layers) — so adding a camera never zooms
            let neutral = 1 / tan(fov * Float.pi / 360)
            let ex = cam.p("x", ct), ey = cam.p("y", ct), ez = cam.p("z", ct) + neutral
            let rx = cam.p("rotX", ct) * Float.pi / 180
            let ry = cam.p("rotY", ct) * Float.pi / 180
            let rz = cam.p("rotZ", ct) * Float.pi / 180
            return (perspectiveLookAt(fov, ar, ex, ey, ez, rx, ry, rz), true)
        }
        // default: camera at z = 3 looking at origin
        return (perspectiveLookAt(scene.fov, ar, 0, 0, 3, 0, 0), false)
    }

    private func modelMatrix(_ l: Layer, time: Float, model: GlbModel?) -> [Float] {
        let lt = l.editTime("x", time)
        let s = l.p("scale", lt)
        let norm = model?.normalize ?? [1, 0, 0, 0]
        let x = l.p("x", lt)
        let y = l.p("y", lt)
        let z = Xf.worldZ(l, time)
        let rx = l.p("rotX", lt) * Float.pi / 180
        let ry = l.p("rotY", lt) * Float.pi / 180
        let rz = l.p("rotZ", lt) * Float.pi / 180
        let sc = s * norm[0]

        var m = identity4()
        m = mul4(rotY4(ry), m)
        m = mul4(rotX4(rx), m)
        m = mul4(rotZ4(rz), m)
        m = mul4(scale4(sc, sc, sc), m)
        // M = T(pos) * R * S * T(-centre): the model turns around its OWN centre (it used to turn
        // around its file origin, so off-centre models orbited wildly and drifted when rotated)
        let ox = norm[1], oy = norm[2], oz = norm[3]
        m[12] = x + m[0] * ox + m[4] * oy + m[8] * oz
        m[13] = y + m[1] * ox + m[5] * oy + m[9] * oz
        m[14] = z + m[2] * ox + m[6] * oy + m[10] * oz
        return m
    }

    private func perspectiveLookAt(_ fovDeg: Float, _ ar: Float,
                                   _ ex: Float, _ ey: Float, _ ez: Float,
                                   _ rx: Float, _ ry: Float, _ rz: Float = 0) -> [Float] {
        let f = 1 / tan(fovDeg * Float.pi / 360)
        let near: Float = 0.05, far: Float = 100
        let nf = 1 / (near - far)
        var p = identity4()
        p[0] = f / ar
        p[5] = f
        p[10] = (far + near) * nf
        p[11] = -1
        p[14] = 2 * far * near * nf
        p[15] = 0

        var v = identity4()
        // orbit: world yaw first, then pitch, then roll about the view axis
        v = mul4(rotY4(-ry), v)
        v = mul4(rotX4(-rx), v)
        v = mul4(rotZ4(-rz), v)
        v[12] = -ex; v[13] = -ey; v[14] = -ez

        return mul4(p, v)
    }

    private func setMat4(_ p: GLProgram, _ name: String, _ m: [Float]) {
        let l = p.loc(name)
        if l >= 0 {
            m.withUnsafeBufferPointer { ptr in
                glUniformMatrix4fv(l, 1, GLboolean(GL_FALSE), ptr.baseAddress)
            }
        }
    }

    // MARK: - programs

    /// Transforming quad vertex shader (layer matrix, quad size, aspect).
    /// The transform used to sit in the FRAGMENT shader, where gl_Position
    /// does not exist: the shader never compiled and nothing was ever drawn.
    static let layerQuadVertex = """
attribute vec2 aPos;
attribute vec2 aUv;
uniform float uMesh;
uniform mat3 uMat;
uniform vec2 uQuad;
uniform float uAspect;
uniform vec3 uRot;
uniform float uZ;
uniform float uInvCam;
uniform mat4 uVP;
uniform float uUseVP;
varying vec2 vUv;
void main() {
    vec2 pu = aPos * 0.5 + 0.5;
    vUv = uMesh > 0.5 ? aUv : pu;
    vec2 w = (uMat * vec3((pu - 0.5) * uQuad, 1.0)).xy;
    vec2 c = (uMat * vec3(0.0, 0.0, 1.0)).xy;
    vec3 o = vec3(w - c, 0.0);
    float cy = cos(uRot.y), sy = sin(uRot.y);
    o = vec3(o.x * cy + o.z * sy, o.y, -o.x * sy + o.z * cy);
    float cx = cos(uRot.x), sx = sin(uRot.x);
    o = vec3(o.x, o.y * cx - o.z * sx, o.y * sx + o.z * cx);
    vec3 pos = vec3(c + o.xy, o.z + uZ);
    if (uUseVP > 0.5) {
        vec4 cl = uVP * vec4(pos, 1.0);
        if (cl.w < 0.02) { gl_Position = vec4(2.0, 2.0, 0.0, 1.0); }   // behind the camera
        else { gl_Position = vec4(cl.xy, 0.0, cl.w); }
    } else {
        gl_Position = vec4(pos.x / uAspect, pos.y, 0.0, 1.0 - pos.z * uInvCam);
    }
}
"""

    private static let quadVertex = """
attribute vec2 aPos;
varying vec2 vUv;
void main() {
    vUv = aPos * 0.5 + 0.5;
    gl_Position = vec4(aPos, 0.0, 1.0);
}
"""

    /// Builds (once) the pipeline shaders. Call with the context current.
    func buildPrograms() {
        if quadProg != nil { return }

        quadProg = GLProgram(vertex: SceneRenderer.layerQuadVertex, fragment: """
precision mediump float;
varying vec2 vUv;
uniform sampler2D uTex;
uniform float uFlipY;
uniform vec4 uColor;
void main() {
    vec2 p = vec2(vUv.x, mix(vUv.y, 1.0 - vUv.y, uFlipY));
    gl_FragColor = texture2D(uTex, p) * uColor;
}
""")
        if quadProg == nil { CrashLog.note("quadProg FAILED: " + Gl.lastShaderLog) }
        shapeProg = GLProgram(vertex: """
attribute vec2 aPos;
uniform mat3 uMat;
uniform vec2 uQuad;
uniform float uAspect;
varying vec2 vQ;
void main() {
    vec2 lc = (aPos * 0.5 + 0.5 - 0.5) * uQuad;
    vQ = lc;
    vec2 w = (uMat * vec3(lc, 1.0)).xy;
    gl_Position = vec4(w.x / uAspect, w.y, 0.0, 1.0);
}
""", fragment: """
precision mediump float;
varying vec2 vQ;
uniform vec4 uColor;
uniform float uKind;
uniform float uCornerRadius;
uniform vec2 uQuadSize;
void main() {
    vec2 q = vQ;
    float a = 0.0;
    if (uKind < 0.5) { a = 1.0; }
    else if (uKind < 1.5) {
        vec2 d = abs(q) - (uQuadSize * 0.5 - vec2(uCornerRadius));
        float outD = length(max(d, 0.0)) + min(max(d.x, d.y), 0.0) - uCornerRadius;
        a = 1.0 - smoothstep(-0.004, 0.004, outD);
    }
    else if (uKind < 2.5) {
        a = 1.0 - smoothstep(0.48 * min(uQuadSize.x, uQuadSize.y), 0.5 * min(uQuadSize.x, uQuadSize.y), length(q));
    }
    else if (uKind < 3.5) {
        vec2 v1 = vec2(-uQuadSize.x * 0.5, -uQuadSize.y * 0.5) - q;
        vec2 v2 = vec2(uQuadSize.x * 0.5, -uQuadSize.y * 0.5) - q;
        vec2 v3 = q - vec2(-uQuadSize.x * 0.5, -uQuadSize.y * 0.5);
        float s1 = v1.x * v2.y - v1.y * v2.x;
        float s2 = v2.x * v3.y - v2.y * v3.x;
        float s3 = v3.x * -v1.y - v3.y * -v1.x;
        a = ((s1 >= 0.0 && s2 >= 0.0 && s3 >= 0.0) || (s1 <= 0.0 && s2 <= 0.0 && s3 <= 0.0)) ? 1.0 : 0.0;
    }
    else {
        float n = 5.0;
        float a0 = atan(q.y, q.x) + 1.5708;
        float seg = 6.2831 / n;
        float rIn = 0.22 * min(uQuadSize.x, uQuadSize.y);
        float rOut = 0.5 * min(uQuadSize.x, uQuadSize.y);
        float ang = mod(a0, seg) - seg * 0.5;
        float rLim = mix(rOut, rIn, abs(ang) / (seg * 0.5));
        a = 1.0 - smoothstep(rLim - 0.01, rLim + 0.01, length(q));
    }
    gl_FragColor = vec4(uColor.rgb * a, uColor.a * a);
}
""")

        flareProg = GLProgram(vertex: SceneRenderer.quadVertex, fragment: """
precision highp float;
varying vec2 vUv;
uniform vec2 uLight;
uniform float uIntensity, uAxis, uSizeMul, uEdgeFade, uAspect, uCount, uTime, uFlicker, uSpeed, uRayAmt;
uniform vec4 uTint;
uniform vec4 uA[16];
uniform vec4 uB[16];
uniform vec4 uC[16];
uniform vec4 uD[16];
uniform vec4 uE[16];
uniform vec4 uCol[16];

float hn(float x) { return fract(sin(x * 127.1) * 43758.5453); }
float vn(float x) { float i = floor(x); float f = fract(x); f = f * f * (3.0 - 2.0 * f); return mix(hn(i), hn(i + 1.0), f); }
vec3 hsv2rgb(vec3 c) {
    vec3 p = abs(fract(c.xxx + vec3(1.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0);
    return c.z * mix(vec3(1.0), clamp(p - 1.0, 0.0, 1.0), c.y);
}

// procedural iris: radius (vertex = 1) of the polygon / star / flower at angle a
float irisR(float a, float n, float round, float star, float curve) {
    float seg = 6.28318 / n;
    float t = mod(a, seg);
    float hs = seg * 0.5;
    float phi = abs(t - hs);
    float cosH = cos(hs);
    float sinH = sin(hs);
    float inner = mix(cosH, 0.12, star);
    float den = cos(phi) * sinH - sin(phi) * (cosH - inner);
    float r = min(inner * sinH / max(den, 0.05), 2.0);
    float u = phi / hs;
    r *= 1.0 + curve * 0.25 * (1.0 - u * u);
    float rc = (inner + 1.0) * 0.5;
    return mix(r, rc, round);
}

float irisMask(vec2 d, float size, float n, float round, float star, float curve,
               float thick, float soft, float grad) {
    float a = atan(d.y, d.x) + 1.5708;
    float R = irisR(a, n, round, star, curve) * size;
    float x = length(d) / max(R, 0.0001);
    float edge = 0.02 + soft * 0.6;
    float outer = 1.0 - smoothstep(1.0 - edge, 1.0, x);
    float hole = mix(smoothstep(1.0 - thick - edge, 1.0 - thick + 0.001, x), 1.0, step(0.99, thick));
    return outer * hole * mix(1.0, x * x, grad);
}

void main() {
    vec2 asp = vec2(uAspect, 1.0);
    vec2 p = vUv * asp;
    vec2 L = uLight * asp;
    vec2 ax = (vec2(0.5) * asp - L) * uAxis;
    float axLen = length(ax);
    float axAng = atan(ax.y, ax.x);
    vec3 acc = vec3(0.0);

    for (int i = 0; i < 16; i++) {
        float t = uA[i].x;
        if (t < -0.5 || float(i) + 0.5 > uCount) { continue; }
        float pos = uA[i].y;
        float size = min(uA[i].z * uSizeMul, 3.0);
        float bright = uB[i].x;
        float soft = uB[i].y;
        float thick = uB[i].z;
        float stretch = uB[i].w;
        float sides = uC[i].x;
        float rays = uC[i].y;
        float chroma = uC[i].z;
        float follow = uC[i].w;
        float noise = uE[i].x;

        float ang = radians(uA[i].w) + follow * axAng * smoothstep(0.03, 0.3, axLen) + uE[i].y * 1.2 * axLen;
        vec2 d = p - (L + ax * pos);
        float ca = cos(ang);
        float sa = sin(ang);
        d = vec2(ca * d.x + sa * d.y, -sa * d.x + ca * d.y);
        float r = length(d);

        // PERFORMANCE: skip every pixel that is outside the element's reach. Without this each
        // pixel evaluated up to 16 elements (atan/pow/iris x3, multi-iris x8) -> heavy lag.
        bool multi = t > 13.5 && t < 14.5;
        if (!multi && r > size * max(stretch, 1.0) * 2.6 + 0.01) { continue; }
        if (bright * uIntensity < 0.002) { continue; }

        vec3 m = vec3(0.0);
        if (t < 0.5) {                                  // Glow
            vec2 q = vec2(d.x / stretch, d.y);
            float x = length(q) / max(size, 0.001);
            float g = exp(-pow(x, mix(2.0, 0.85, soft)) * 4.5) * (1.0 - smoothstep(0.85, 1.0, x));
            // real lens glare: hot core + long inverse-square wings (like the reference photos)
            float wing = (1.0 / (1.0 + x * x * 24.0)) * (1.0 - smoothstep(0.55, 1.0, x));
            g = mix(g, g * 0.6 + wing * 0.5, soft);
            m = vec3(g);
        } else if (t < 1.5 || (t > 4.5 && t < 5.5) || (t > 12.5 && t < 13.5)) {   // Polygon / Ring polygon / Iris
            float st = 0.0; float rd = 0.0; float cv = 0.0; float gr = uD[i].w; float th = thick; float sf = soft;
            if (t > 12.5) { rd = uD[i].x; st = uD[i].y; cv = uD[i].z; }
            else { th = t < 1.5 ? max(thick, 0.3) : thick; gr = 0.3; sf = 0.12; }
            vec2 q = vec2(d.x / stretch, d.y);
            float k = chroma * 0.07;
            m = vec3(irisMask(q, size * (1.0 + k), sides, rd, st, cv, th, sf, gr),
                     irisMask(q, size, sides, rd, st, cv, th, sf, gr),
                     irisMask(q, size * (1.0 - k), sides, rd, st, cv, th, sf, gr));
            if (chroma > 0.01) { m *= vec3(1.0, 0.85, 1.0); }
        } else if (t < 2.5) {                            // Line
            vec2 s = vec2(size * stretch * 0.5, size * 0.5 * max(thick, 0.01));
            vec2 qq = abs(d) - s;
            float e = 0.004 + soft * 0.03;
            m = vec3(1.0 - smoothstep(-e, e, length(max(qq, 0.0)) + min(max(qq.x, qq.y), 0.0)));
        } else if (t < 3.5) {                            // Rays (soft beams)
            float n = max(rays, 2.0);
            float a = atan(d.y, d.x);
            float beam = pow(abs(cos(a * n * 0.5)), 28.0);
            float rad = exp(-r / max(size * 0.35, 0.001)) * (1.0 - smoothstep(size * 0.6, size, r));
            m = vec3(beam * rad * 0.7 * uRayAmt);
        } else if (t < 4.5) {                            // Ring
            float R = size * 0.5;
            float w = max(thick, 0.01) * R;
            float e = 0.004 + soft * 0.02;
            float k = chroma * 0.06;
            vec3 rr = vec3(r / (1.0 + k), r, r / (1.0 - k));
            if (thick >= 0.95) { m = 1.0 - smoothstep(R * (1.0 - soft * 0.5) - e, R + e, rr); }
            else { m = 1.0 - smoothstep(w * 0.5 - e, w * 0.5 + e, abs(rr - R)); }
        } else if (t < 6.5) {                            // Dot
            float R = size * 0.5;
            m = vec3(1.0 - smoothstep(R * (1.0 - soft * 0.8), R, r));
        } else if (t < 7.5) {                            // Glint: smooth starburst
            float n = max(rays, 2.0);
            float a = atan(d.y, d.x);
            float seg = 6.28318 / n;
            float idx = mod(floor(a / seg + 0.5), n);
            float fr = (fract(a / seg + 0.5) - 0.5) * seg;
            float lenv = mix(1.0, 0.6 + 0.4 * hn(idx * 3.7 + uE[i].z), noise * 0.6);
            float len = size * 0.5 * lenv;
            float w = mix(0.018, 0.075, soft);
            float beam = exp(-(fr * fr) / (w * w));
            float rad = exp(-r / max(len * 0.45, 0.001)) * (1.0 - smoothstep(len * 0.55, len, r));
            float core = exp(-r / max(size * 0.05, 0.001)) * 0.7;
            m = vec3(beam * rad * 0.8 * uRayAmt + core);
        } else if (t < 8.5) {                            // Hoop
            float R = size * 0.5;
            float w = max(thick, 0.02) * R * 0.5;
            float k = chroma * 0.07;
            vec3 rr = vec3(r / (1.0 + k), r, r / (1.0 - k));
            vec3 z = (rr - R) / w;
            m = exp(-z * z * (1.0 + (1.0 - soft) * 3.0));
        } else if (t < 9.5) {                            // Streak (anamorphic)
            float len = size * stretch * 0.5;
            float wy = size * 0.5 * max(thick, 0.01) * 0.35 + 0.002;
            float hx = exp(-abs(d.x) / max(len * (0.12 + 0.5 * soft), 0.001));
            float vy = exp(-(d.y / wy) * (d.y / wy));
            m = vec3(hx * vy * (1.0 - smoothstep(len * 0.8, len * 1.2, abs(d.x))));
        } else if (t < 10.5) {                           // Spike ball: fine smooth spikes
            float n = max(rays, 3.0) * 2.0;
            float a = atan(d.y, d.x);
            float seg = 6.28318 / n;
            float idx = mod(floor(a / seg + 0.5), n);
            float fr = (fract(a / seg + 0.5) - 0.5) * seg;
            float lenv = mix(1.0, 0.45 + 0.55 * hn(idx * 5.3 + uE[i].z), noise * 0.7);
            float len = size * 0.5 * lenv;
            float w = mix(0.012, 0.04, soft);
            float beam = exp(-(fr * fr) / (w * w));
            float rad = exp(-r / max(len * 0.4, 0.001)) * (1.0 - smoothstep(len * 0.6, len, r));
            float core = exp(-pow(r / max(size * 0.12, 0.001), 1.2) * 2.0);
            m = vec3(beam * rad * 0.6 * uRayAmt + core * 0.9);
        } else if (t < 11.5) {                           // Rainbow
            float x = r / max(size * 0.5, 0.001);
            float inner = 1.0 - thick * 0.7;
            float band = smoothstep(inner, inner + 0.12, x) * (1.0 - smoothstep(0.92, 1.0, x));
            vec3 spec = hsv2rgb(vec3(clamp((1.0 - (x - inner) / max(1.0 - inner, 0.05)) * 0.75, 0.0, 0.8), 0.9, 1.0));
            m = band * mix(vec3(1.0), spec, 0.25 + 0.75 * chroma);
        } else if (t > 14.5) {                           // Arc: partial lens ring with colour fringe
            float R = size * 0.5;
            float w = max(thick, 0.02) * R * 0.5;
            float k = chroma * 0.07;
            vec3 rr = vec3(r / (1.0 + k), r, r / (1.0 - k));
            vec3 z = (rr - R) / w;
            float aa = atan(d.y, d.x);
            float hs = clamp(uE[i].w, 0.02, 1.0) * 3.14159;
            float am = 1.0 - smoothstep(hs * (1.0 - soft), hs, abs(aa));
            m = exp(-z * z * (1.0 + (1.0 - soft) * 3.0)) * am;
        } else if (t > 13.5) {                           // Multi iris: a chain of ghost irises
            float cnt = clamp(rays, 2.0, 8.0);
            vec3 mm = vec3(0.0);
            for (int k = 0; k < 8; k++) {
                float fk = float(k);
                if (fk + 0.5 > cnt) { break; }
                float h1 = hn(fk * 12.9 + uE[i].z);
                float h2 = hn(fk * 7.7 + uE[i].z + 3.0);
                vec2 dk = p - (L + ax * (pos + fk * uE[i].w));
                dk = vec2(ca * dk.x + sa * dk.y, -sa * dk.x + ca * dk.y);
                float szk = size * (1.0 - noise * 0.6 * h1) * (1.0 - 0.06 * fk);
                float mk = irisMask(vec2(dk.x / stretch, dk.y), szk, sides, uD[i].x, uD[i].y, uD[i].z,
                                    max(thick, 0.05), soft, uD[i].w);
                vec3 spec = hsv2rgb(vec3(fract(0.08 + fk * 0.17 + h2 * 0.1), 0.65, 1.0));
                vec3 tk = mix(vec3(1.0), spec, chroma * 0.9);
                mm += mk * tk * (0.55 + 0.45 * h2) / (1.0 + 0.12 * fk);
            }
            m = mm;
        } else {                                         // Shimmer
            float x = r / max(size, 0.001);
            float a = atan(d.y, d.x);
            float g = exp(-pow(x, 1.2) * 3.5) * (1.0 - smoothstep(0.9, 1.0, x));
            float nz = vn(a * rays * 0.35 + 20.0 + uTime * uSpeed * 1.2) * 0.7
                     + vn(a * rays * 0.9 + uTime * uSpeed * 2.3) * 0.5;
            m = vec3(g * (0.45 + nz * 1.1 * (0.25 + noise)));
        }

        float fl = 1.0 + uFlicker * (vn(uTime * uSpeed * 9.0 + float(i) * 3.1) - 0.5) * 0.7;
        acc += uCol[i].rgb * uTint.rgb * m * bright * fl;
    }

    // the whole flare fades as the light leaves the frame
    vec2 lp = uLight;
    float outside = max(max(-lp.x, lp.x - 1.0), max(-lp.y, lp.y - 1.0));
    outside = max(outside - 0.12, 0.0);                 // never fades while the light is on or near the frame
    float vis = 1.0 - smoothstep(0.0, max(uEdgeFade, 0.05) + 0.25, outside);
    acc = clamp(acc, 0.0, 60.0) * uIntensity * vis;

    // soft highlight roll-off keeps hot colours from clipping to flat white
    vec3 o = vec3(1.0) - exp(-acc * 1.1);
    float lum = max(o.r, max(o.g, o.b));
    o = mix(o, vec3(lum), smoothstep(0.55, 1.0, lum) * 0.45);   // hot cores bleed to white like film
    float dn = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715)))) - 0.5;
    o = max(o + dn * (1.0 / 255.0) * step(0.002, o), 0.0);
    gl_FragColor = vec4(o, max(o.r, max(o.g, o.b)));
}
""")

        particleProg = GLProgram(vertex: """
attribute vec3 aPos;
attribute vec3 aData;
uniform mat4 uVP;
uniform float uAspect;
uniform float uOrtho;
uniform float uSize;
uniform float uPx;
uniform float uOpacity;
uniform float uFadeIn;
uniform float uFadeOut;
uniform vec4 uColA;
uniform vec4 uColB;
varying vec4 vCol;
varying float vLife;
varying float vOp;
varying float vSoft;
varying float vFi;
varying float vFo;
varying float vPS;
void main() {
    vOp = uOpacity;
    vFi = uFadeIn;
    vFo = uFadeOut;
    float k = 1.0;
    if (uOrtho > 0.5) {
        gl_Position = vec4(aPos.x / uAspect, aPos.y, 0.0, 1.0);
    } else {
        vec4 c = uVP * vec4(aPos, 1.0);
        gl_Position = c;
        k = 3.0 / max(c.w, 0.05);
    }
    vSoft = aData.z;
    float ps = max(4.0, uSize * uPx * aData.x * k * (1.0 + aData.z * 0.35));
    gl_PointSize = ps;
    vPS = ps;
    vLife = aData.y;
    vCol = mix(uColA, uColB, clamp(aData.y, 0.0, 1.0));
}
""", fragment: """
precision mediump float;
varying vec4 vCol;
varying float vLife;
varying float vOp;
varying float vSoft;
varying float vFi;
varying float vFo;
varying float vPS;
void main() {
    vec2 c = gl_PointCoord - 0.5;
    float d = length(c);
    float aa = 1.5 / max(vPS, 3.0);
    float a = 1.0 - smoothstep(mix(0.5 - aa, 0.0, vSoft), 0.5, d);   // edge0 < edge1 (reversed edges are undefined in GLSL)
    float fade = smoothstep(0.0, vFi, vLife) * (1.0 - smoothstep(1.0 - vFo, 1.0, vLife));
    a *= fade * vOp * vCol.a;
    gl_FragColor = vec4(vCol.rgb * a, a);
}
""")

        meshProg = GLProgram(vertex: GlbModel.vertexSource, fragment: GlbModel.fragmentSource)

        vdbProg = GLProgram(vertex: SceneRenderer.quadVertex, fragment: """
precision highp float;
varying vec2 vUv;
uniform mat4 uInv;
uniform mat4 uMVP;
uniform vec3 uB;
uniform sampler2D uVol;
uniform sampler2D uDepth;
uniform float uDens;
uniform float uUseDepth;
uniform vec4 uColor;
float samp(vec3 q) {
    q = clamp(q, 0.0, 1.0);
    float fz = q.z * 127.0;
    float z0 = floor(fz);
    float z1 = min(z0 + 1.0, 127.0);
    vec2 xy = q.xy * 127.0 + 0.5;
    vec2 t0 = (vec2(mod(z0, 16.0), floor(z0 / 16.0)) * 128.0 + xy) / vec2(2048.0, 1024.0);
    vec2 t1 = (vec2(mod(z1, 16.0), floor(z1 / 16.0)) * 128.0 + xy) / vec2(2048.0, 1024.0);
    float s = mix(texture2D(uVol, t0).r, texture2D(uVol, t1).r, fz - z0);
    vec3 e3 = min(q, 1.0 - q);
    float fade = smoothstep(0.0, 0.1, min(e3.x, min(e3.y, e3.z)));   // soft box edges: no square cut-off
    return s * s * fade;
}
void main() {
    vec2 ndc = vUv * 2.0 - 1.0;
    vec4 n4 = uInv * vec4(ndc, -1.0, 1.0);
    vec4 f4 = uInv * vec4(ndc, 1.0, 1.0);
    vec3 o = n4.xyz / n4.w;
    vec3 d = f4.xyz / f4.w - o;
    vec3 h = uB * 0.5;
    vec3 id = 1.0 / (d + vec3(1e-6));
    vec3 t1 = (-h - o) * id;
    vec3 t2 = (h - o) * id;
    vec3 tn = min(t1, t2);
    vec3 tf = max(t1, t2);
    float t0 = max(max(max(tn.x, tn.y), tn.z), 0.0);
    float t3 = min(min(tf.x, tf.y), tf.z);
    if (t3 <= t0) { gl_FragColor = vec4(0.0); return; }
    float sceneZ = uUseDepth > 0.5 ? texture2D(uDepth, vUv).r : 1.0;
    float dt = (t3 - t0) / 56.0;
    float seg = dt * length(d) / max(max(uB.x, uB.y), uB.z) * 8.0;
    float jit = 0.5;
    vec3 L = normalize(vec3(0.3, 1.0, 0.4)) * 0.06;
    float T = 1.0;
    vec3 col = vec3(0.0);
    for (int i = 0; i < 56; i++) {
        vec3 pos = o + d * (t0 + (float(i) + jit) * dt);
        if (sceneZ < 1.0) {
            vec4 c = uMVP * vec4(pos, 1.0);
            if (c.z / c.w * 0.5 + 0.5 > sceneZ) { break; }
        }
        vec3 q = pos / uB + 0.5;
        float den = samp(q) * uDens;
        if (den > 0.002) {
            float lt = samp(q + L * 1.5) + samp(q + L * 4.0);
            float sh = exp(-lt * uDens * 2.4);
            float ex = exp(-den * seg);
            col += T * (1.0 - ex) * uColor.rgb * (0.3 + 0.8 * sh);
            T *= ex;
            if (T < 0.02) { break; }
        }
    }
    gl_FragColor = vec4(col, 1.0 - T);
}
""")

        compositeProg = GLProgram(vertex: SceneRenderer.quadVertex, fragment: """
precision highp float;
varying vec2 vUv;
uniform sampler2D uScene;
uniform sampler2D uSrc;
uniform sampler2D uMask;
uniform float uAlpha;
uniform float uMode;      // 0 normal 1 add 2 screen 3 multiply 4 accumulate 5 running average
uniform float uMaskMode;  // 0 none 1 alpha 2 inv alpha 3 luma 4 inv luma
uniform float uRgbShift;
void main() {
    vec4 s = texture2D(uSrc, vUv);
    if (uRgbShift != 0.0) {
        s.r = texture2D(uSrc, clamp(vUv + vec2(uRgbShift, 0.0), 0.0, 1.0)).r;
        s.b = texture2D(uSrc, clamp(vUv - vec2(uRgbShift, 0.0), 0.0, 1.0)).b;
    }
    vec4 sRaw = s;
    s *= uAlpha;
    if (uMode > 4.5) {
        // running average: acc = mix(acc, sample, 1/(i+1)). Keeps full precision in 8-bit
        // targets (additive 1/N accumulation rounds dim pixels to 0 → visible opacity steps)
        gl_FragColor = mix(texture2D(uScene, vUv), sRaw, uAlpha);
        return;
    }
    if (uMaskMode > 0.5) {
        vec4 mk = texture2D(uMask, vUv);
        float m = 1.0;
        if (uMaskMode < 1.5) { m = mk.a; }
        else if (uMaskMode < 2.5) { m = 1.0 - mk.a; }
        else if (uMaskMode < 3.5) { m = dot(mk.rgb, vec3(0.299, 0.587, 0.114)); }
        else { m = 1.0 - dot(mk.rgb, vec3(0.299, 0.587, 0.114)); }
        s *= m;
    }
    vec4 d = texture2D(uScene, vUv);
    if (uMode < 0.5) {
        gl_FragColor = s + d * (1.0 - s.a);
    } else if (uMode < 1.5) {
        gl_FragColor = d + s;
    } else if (uMode < 2.5) {
        vec3 scr = 1.0 - (1.0 - d.rgb) * (1.0 - s.rgb);
        gl_FragColor = mix(d, vec4(scr, max(d.a, s.a)), s.a);
    } else if (uMode < 3.5) {
        vec3 mul = d.rgb * s.rgb;
        gl_FragColor = mix(d, vec4(mul, d.a * s.a), s.a);
    } else {
        gl_FragColor = d + s;
    }
}
""")
    }

    // MARK: - math

    private func identity4() -> [Float] {
        [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]
    }

    private func scale4(_ x: Float, _ y: Float, _ z: Float) -> [Float] {
        [x, 0, 0, 0, 0, y, 0, 0, 0, 0, z, 0, 0, 0, 0, 1]
    }

    private func rotX4(_ a: Float) -> [Float] {
        let c = cos(a), s = sin(a)
        return [1, 0, 0, 0, 0, c, s, 0, 0, -s, c, 0, 0, 0, 0, 1]
    }

    private func rotY4(_ a: Float) -> [Float] {
        let c = cos(a), s = sin(a)
        return [c, 0, -s, 0, 0, 1, 0, 0, s, 0, c, 0, 0, 0, 0, 1]
    }

    private func rotZ4(_ a: Float) -> [Float] {
        let c = cos(a), s = sin(a)
        return [c, s, 0, 0, -s, c, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]
    }

    /// a * b (column-major, OpenGL order).
    private func mul4(_ a: [Float], _ b: [Float]) -> [Float] {
        var o = [Float](repeating: 0, count: 16)
        for c in 0..<4 {
            for r in 0..<4 {
                var s: Float = 0
                for k in 0..<4 {
                    s += a[k * 4 + r] * b[c * 4 + k]
                }
                o[c * 4 + r] = s
            }
        }
        return o
    }
}

// MARK: - mat3 upload

extension GLProgram {
    func setMat3(_ name: String, _ m0: [Float]) {
        let l = loc(name)
        // Xf matrices are 2D affines [a b c d tx ty]; GL needs 9 floats
        // (column-major). Passing 6 made GL read garbage => the skew.
        let m: [Float] = m0.count == 6
            ? [m0[0], m0[1], 0, m0[2], m0[3], 0, m0[4], m0[5], 1] : m0
        if l >= 0 {
            m.withUnsafeBufferPointer { ptr in
                glUniformMatrix3fv(l, 1, GLboolean(GL_FALSE), ptr.baseAddress)
            }
        }
    }
}
