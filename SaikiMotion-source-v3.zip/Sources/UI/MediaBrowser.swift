// MediaBrowser.swift — custom photo/video browser in the editor's own style (orange accent).
// Compact grid inside the Media panel + a full-screen version with preview and video playback.

import UIKit
import Photos
import AVFoundation

private let ACC = argbToUIColor(C.GREEN)
private let BGC = argbToUIColor(C.BG)
private let CARDC = argbToUIColor(C.CARD)
private let CARD2C = argbToUIColor(C.CARD2)

enum MediaFilter: Int { case all, photos, videos }

// MARK: - Grid + album/filter header

final class MediaBrowserView: UIView, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    var onPick: ((PHAsset) -> Void)?
    var onExpand: (() -> Void)?
    var highlighted: String?

    private var albums: [(String, PHAssetCollection?)] = []
    private var albumIdx = 0
    private var filter: MediaFilter = .all
    private var assets: PHFetchResult<PHAsset>?
    private let cache = PHCachingImageManager()
    private let albumBtn = UIButton(type: .system)
    private var chips: [UIButton] = []
    private let grid: UICollectionView
    private let empty = UILabel()
    private let cols: CGFloat

    init(columns: CGFloat = 4, showExpand: Bool = true) {
        cols = columns
        let lay = UICollectionViewFlowLayout()
        lay.minimumInteritemSpacing = 2; lay.minimumLineSpacing = 2
        grid = UICollectionView(frame: .zero, collectionViewLayout: lay)
        super.init(frame: .zero)
        backgroundColor = .clear

        albumBtn.setTitleColor(.white, for: .normal)
        albumBtn.titleLabel?.font = .boldSystemFont(ofSize: 14)
        albumBtn.backgroundColor = CARD2C; albumBtn.layer.cornerRadius = 16
        albumBtn.contentEdgeInsets = UIEdgeInsets(top: 0, left: 12, bottom: 0, right: 12)
        albumBtn.showsMenuAsPrimaryAction = true
        albumBtn.tintColor = .white

        let bar = UIStackView(); bar.axis = .horizontal; bar.spacing = 6; bar.alignment = .center
        bar.addArrangedSubview(albumBtn)
        for (i, n) in ["All", "Photos", "Videos"].enumerated() {
            let b = UIButton(type: .system); b.setTitle(n, for: .normal)
            b.titleLabel?.font = .boldSystemFont(ofSize: 13); b.layer.cornerRadius = 16
            b.contentEdgeInsets = UIEdgeInsets(top: 0, left: 12, bottom: 0, right: 12)
            b.tag = i; b.addTarget(self, action: #selector(chipTap(_:)), for: .touchUpInside)
            chips.append(b); bar.addArrangedSubview(b)
        }
        let sp = UIView(); sp.setContentHuggingPriority(.defaultLow, for: .horizontal); bar.addArrangedSubview(sp)
        if showExpand {
            let ex = UIButton(type: .system)
            ex.setImage(UIImage(systemName: "square.grid.2x2.fill"), for: .normal)
            ex.tintColor = C_ONDARK; ex.backgroundColor = ACC; ex.layer.cornerRadius = 16
            ex.addTarget(self, action: #selector(expandTap), for: .touchUpInside)
            ex.widthAnchor.constraint(equalToConstant: 40).isActive = true
            bar.addArrangedSubview(ex)
        }
        for v in bar.arrangedSubviews { v.heightAnchor.constraint(equalToConstant: 32).isActive = true }
        bar.translatesAutoresizingMaskIntoConstraints = false
        addSubview(bar)

        grid.backgroundColor = .clear; grid.dataSource = self; grid.delegate = self
        grid.register(MediaCell.self, forCellWithReuseIdentifier: "c")
        grid.translatesAutoresizingMaskIntoConstraints = false
        addSubview(grid)
        empty.textColor = argbToUIColor(C.DIM); empty.font = .systemFont(ofSize: 13); empty.textAlignment = .center
        empty.numberOfLines = 0; empty.translatesAutoresizingMaskIntoConstraints = false
        addSubview(empty)
        NSLayoutConstraint.activate([
            bar.topAnchor.constraint(equalTo: topAnchor), bar.leadingAnchor.constraint(equalTo: leadingAnchor),
            bar.trailingAnchor.constraint(lessThanOrEqualTo: trailingAnchor),
            grid.topAnchor.constraint(equalTo: bar.bottomAnchor, constant: 8),
            grid.leadingAnchor.constraint(equalTo: leadingAnchor), grid.trailingAnchor.constraint(equalTo: trailingAnchor),
            grid.bottomAnchor.constraint(equalTo: bottomAnchor),
            empty.centerXAnchor.constraint(equalTo: grid.centerXAnchor), empty.centerYAnchor.constraint(equalTo: grid.centerYAnchor),
            empty.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20), empty.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20)])
        restyleChips()
        authorizeAndLoad()
    }
    required init?(coder: NSCoder) { fatalError() }

    private let C_ONDARK = UIColor(red: 0.05, green: 0.05, blue: 0.06, alpha: 1)

    @objc private func expandTap() { onExpand?() }
    @objc private func chipTap(_ b: UIButton) { filter = MediaFilter(rawValue: b.tag) ?? .all; restyleChips(); reload() }

    private func restyleChips() {
        for b in chips {
            let on = b.tag == filter.rawValue
            b.backgroundColor = on ? ACC : CARD2C
            b.setTitleColor(on ? C_ONDARK : .white, for: .normal)
        }
    }

    private func authorizeAndLoad() {
        let st = PHPhotoLibrary.authorizationStatus(for: .readWrite)
        if st == .notDetermined {
            PHPhotoLibrary.requestAuthorization(for: .readWrite) { [weak self] _ in DispatchQueue.main.async { self?.authorizeAndLoad() } }
            return
        }
        guard st == .authorized || st == .limited else {
            empty.text = "Allow photo access in Settings to browse your library."; return
        }
        loadAlbums(); reload()
    }

    private func loadAlbums() {
        albums = [("All", nil)]
        let subs: [PHAssetCollectionSubtype] = [.smartAlbumFavorites, .smartAlbumVideos, .smartAlbumScreenshots, .smartAlbumSelfPortraits,
                                                .smartAlbumLivePhotos, .smartAlbumRecentlyAdded, .smartAlbumSlomoVideos, .smartAlbumTimelapses]
        for s in subs {
            let r = PHAssetCollection.fetchAssetCollections(with: .smartAlbum, subtype: s, options: nil)
            r.enumerateObjects { c, _, _ in if PHAsset.fetchAssets(in: c, options: nil).count > 0 { self.albums.append((c.localizedTitle ?? "Album", c)) } }
        }
        let u = PHAssetCollection.fetchAssetCollections(with: .album, subtype: .any, options: nil)
        u.enumerateObjects { c, _, _ in self.albums.append((c.localizedTitle ?? "Album", c)) }
        let actions = albums.enumerated().map { (i, a) in
            UIAction(title: a.0, state: i == albumIdx ? .on : .off) { [weak self] _ in
                self?.albumIdx = i; self?.loadAlbums(); self?.reload() }
        }
        albumBtn.menu = UIMenu(children: actions)
        albumBtn.setTitle(albums[min(albumIdx, albums.count - 1)].0 + " ▾", for: .normal)
    }

    private func reload() {
        let o = PHFetchOptions()
        o.sortDescriptors = [NSSortDescriptor(key: "creationDate", ascending: false)]
        switch filter {
        case .photos: o.predicate = NSPredicate(format: "mediaType == %d", PHAssetMediaType.image.rawValue)
        case .videos: o.predicate = NSPredicate(format: "mediaType == %d", PHAssetMediaType.video.rawValue)
        case .all: o.predicate = NSPredicate(format: "mediaType == %d OR mediaType == %d", PHAssetMediaType.image.rawValue, PHAssetMediaType.video.rawValue)
        }
        if let c = albums[min(albumIdx, albums.count - 1)].1 { assets = PHAsset.fetchAssets(in: c, options: o) }
        else { assets = PHAsset.fetchAssets(with: o) }
        empty.text = (assets?.count ?? 0) == 0 ? "Nothing here yet" : nil
        grid.reloadData()
    }

    func collectionView(_ cv: UICollectionView, numberOfItemsInSection s: Int) -> Int { assets?.count ?? 0 }
    func collectionView(_ cv: UICollectionView, cellForItemAt i: IndexPath) -> UICollectionViewCell {
        let cell = cv.dequeueReusableCell(withReuseIdentifier: "c", for: i) as! MediaCell
        if let a = assets?[i.item] { cell.show(a, cache, selected: a.localIdentifier == highlighted) }
        return cell
    }
    func collectionView(_ cv: UICollectionView, layout l: UICollectionViewLayout, sizeForItemAt i: IndexPath) -> CGSize {
        let w = floor((cv.bounds.width - 2 * (cols - 1)) / cols); return CGSize(width: w, height: w)
    }
    func collectionView(_ cv: UICollectionView, didSelectItemAt i: IndexPath) {
        guard let a = assets?[i.item] else { return }
        highlighted = a.localIdentifier; cv.reloadData(); onPick?(a)
    }
    override func layoutSubviews() { super.layoutSubviews(); grid.collectionViewLayout.invalidateLayout() }
}

private final class MediaCell: UICollectionViewCell {
    let img = UIImageView(); let dur = UILabel(); var rid: PHImageRequestID = PHInvalidImageRequestID
    override init(frame: CGRect) {
        super.init(frame: frame)
        img.contentMode = .scaleAspectFill; img.clipsToBounds = true; img.backgroundColor = CARDC
        img.frame = bounds; img.autoresizingMask = [.flexibleWidth, .flexibleHeight]; contentView.addSubview(img)
        dur.font = .boldSystemFont(ofSize: 11); dur.textColor = .white
        dur.frame = CGRect(x: 4, y: bounds.height - 18, width: bounds.width - 8, height: 14)
        dur.autoresizingMask = [.flexibleWidth, .flexibleTop]; dur.textAlignment = .right; contentView.addSubview(dur)
        contentView.layer.borderColor = ACC.cgColor
    }
    required init?(coder: NSCoder) { fatalError() }
    func show(_ a: PHAsset, _ m: PHCachingImageManager, selected: Bool) {
        contentView.layer.borderWidth = selected ? 3 : 0
        dur.text = a.mediaType == .video ? String(format: "%d:%02d", Int(a.duration) / 60, Int(a.duration) % 60) : nil
        if rid != PHInvalidImageRequestID { m.cancelImageRequest(rid) }
        let s = UIScreen.main.scale * 140
        rid = m.requestImage(for: a, targetSize: CGSize(width: s, height: s), contentMode: .aspectFill, options: nil) { [weak self] i, _ in self?.img.image = i }
    }
}

// MARK: - Full-screen browser with preview

final class MediaBrowserViewController: UIViewController {
    var onAdd: ((PHAsset) -> Void)?
    private var selected: PHAsset?
    private let preview = UIImageView(); private var player: AVPlayer?; private var layerP: AVPlayerLayer?
    private let playBtn = UIButton(type: .system); private let addBtn = UIButton(type: .system)
    private let title_ = UILabel()
    private var browser: MediaBrowserView!

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = BGC
        let x = UIButton(type: .system); x.setImage(UIImage(systemName: "xmark"), for: .normal); x.tintColor = .white
        x.addTarget(self, action: #selector(close), for: .touchUpInside)
        title_.text = "Media"; title_.textColor = .white; title_.font = .boldSystemFont(ofSize: 17)
        addBtn.setTitle("Add", for: .normal); addBtn.setTitleColor(UIColor(white: 0.05, alpha: 1), for: .normal)
        addBtn.titleLabel?.font = .boldSystemFont(ofSize: 15); addBtn.backgroundColor = ACC; addBtn.layer.cornerRadius = 17
        addBtn.alpha = 0.4; addBtn.isEnabled = false
        addBtn.addTarget(self, action: #selector(add), for: .touchUpInside)
        preview.contentMode = .scaleAspectFit; preview.backgroundColor = .black; preview.clipsToBounds = true
        playBtn.setImage(UIImage(systemName: "play.circle.fill"), for: .normal); playBtn.tintColor = ACC
        playBtn.imageView?.contentMode = .scaleAspectFit
        playBtn.contentHorizontalAlignment = .fill; playBtn.contentVerticalAlignment = .fill; playBtn.isHidden = true
        playBtn.addTarget(self, action: #selector(togglePlay), for: .touchUpInside)
        browser = MediaBrowserView(columns: 4, showExpand: false)
        browser.onPick = { [weak self] a in self?.select(a) }
        for v in [x, title_, addBtn, preview, playBtn, browser!] as [UIView] { v.translatesAutoresizingMaskIntoConstraints = false; view.addSubview(v) }
        let g = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            x.topAnchor.constraint(equalTo: g.topAnchor, constant: 8), x.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 12),
            x.widthAnchor.constraint(equalToConstant: 40), x.heightAnchor.constraint(equalToConstant: 34),
            title_.centerYAnchor.constraint(equalTo: x.centerYAnchor), title_.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            addBtn.centerYAnchor.constraint(equalTo: x.centerYAnchor), addBtn.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -12),
            addBtn.widthAnchor.constraint(equalToConstant: 72), addBtn.heightAnchor.constraint(equalToConstant: 34),
            preview.topAnchor.constraint(equalTo: x.bottomAnchor, constant: 8),
            preview.leadingAnchor.constraint(equalTo: view.leadingAnchor), preview.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            preview.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.36),
            playBtn.centerXAnchor.constraint(equalTo: preview.centerXAnchor), playBtn.centerYAnchor.constraint(equalTo: preview.centerYAnchor),
            playBtn.widthAnchor.constraint(equalToConstant: 56), playBtn.heightAnchor.constraint(equalToConstant: 56),
            browser.topAnchor.constraint(equalTo: preview.bottomAnchor, constant: 10),
            browser.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 8), browser.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -8),
            browser.bottomAnchor.constraint(equalTo: view.bottomAnchor)])
    }

    override func viewDidLayoutSubviews() { super.viewDidLayoutSubviews(); layerP?.frame = preview.bounds }

    private func select(_ a: PHAsset) {
        selected = a; addBtn.alpha = 1; addBtn.isEnabled = true
        player?.pause(); player = nil; layerP?.removeFromSuperlayer(); layerP = nil
        let o = PHImageRequestOptions(); o.deliveryMode = .highQualityFormat; o.isNetworkAccessAllowed = true
        let s = UIScreen.main.scale * 500
        PHImageManager.default().requestImage(for: a, targetSize: CGSize(width: s, height: s), contentMode: .aspectFit, options: o) { [weak self] i, _ in
            self?.preview.image = i }
        playBtn.isHidden = a.mediaType != .video
        playBtn.setImage(UIImage(systemName: "play.circle.fill"), for: .normal)
        title_.text = a.mediaType == .video ? "Video" : "Photo"
    }

    @objc private func togglePlay() {
        guard let a = selected, a.mediaType == .video else { return }
        if let p = player {
            if p.timeControlStatus == .paused { p.play(); playBtn.setImage(UIImage(systemName: "pause.circle.fill"), for: .normal) }
            else { p.pause(); playBtn.setImage(UIImage(systemName: "play.circle.fill"), for: .normal) }
            return
        }
        let o = PHVideoRequestOptions(); o.isNetworkAccessAllowed = true
        PHImageManager.default().requestPlayerItem(forVideo: a, options: o) { [weak self] item, _ in
            DispatchQueue.main.async {
                guard let self = self, let item = item else { return }
                let p = AVPlayer(playerItem: item); self.player = p
                let l = AVPlayerLayer(player: p); l.videoGravity = .resizeAspect; l.frame = self.preview.bounds
                self.preview.layer.addSublayer(l); self.layerP = l
                NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: item, queue: .main) { [weak self] _ in
                    self?.player?.seek(to: .zero); self?.playBtn.setImage(UIImage(systemName: "play.circle.fill"), for: .normal) }
                p.play(); self.playBtn.setImage(UIImage(systemName: "pause.circle.fill"), for: .normal)
            }
        }
    }

    @objc private func add() { guard let a = selected else { return }; player?.pause(); dismiss(animated: true) { self.onAdd?(a) } }
    @objc private func close() { player?.pause(); dismiss(animated: true) }
}

// MARK: - 3D import sheet (custom, not the iOS action sheet)

final class Import3DSheet: UIView {
    var onModel: (() -> Void)?; var onVdb: (() -> Void)?
    private let card = UIView(); private let dim = UIView()

    static func show(in host: UIView, model: @escaping () -> Void, vdb: @escaping () -> Void) {
        let s = Import3DSheet(frame: host.bounds); s.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        s.onModel = model; s.onVdb = vdb; host.addSubview(s); s.animateIn()
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        dim.backgroundColor = UIColor(white: 0, alpha: 0.55); dim.frame = bounds; dim.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        dim.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(dismissSheet))); addSubview(dim)
        card.backgroundColor = argbToUIColor(C.PANEL); card.layer.cornerRadius = 22
        card.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        let t = UILabel(); t.text = "3D"; t.textColor = .white; t.font = .boldSystemFont(ofSize: 17)
        let st = UIStackView(arrangedSubviews: [t, row("cube", "Import 3D model", ".glb  .gltf  .obj  .abc", #selector(tapModel)),
                                                row("cloud", "Import VDB", "OpenVDB volume (.vdb)", #selector(tapVdb))])
        st.axis = .vertical; st.spacing = 10
        let cancel = UIButton(type: .system); cancel.setTitle("Cancel", for: .normal); cancel.setTitleColor(argbToUIColor(C.DIM), for: .normal)
        cancel.titleLabel?.font = .boldSystemFont(ofSize: 15); cancel.addTarget(self, action: #selector(dismissSheet), for: .touchUpInside)
        st.addArrangedSubview(cancel)
        st.translatesAutoresizingMaskIntoConstraints = false; card.addSubview(st); card.translatesAutoresizingMaskIntoConstraints = false; addSubview(card)
        NSLayoutConstraint.activate([
            card.leadingAnchor.constraint(equalTo: leadingAnchor), card.trailingAnchor.constraint(equalTo: trailingAnchor),
            card.bottomAnchor.constraint(equalTo: bottomAnchor),
            st.topAnchor.constraint(equalTo: card.topAnchor, constant: 18), st.leadingAnchor.constraint(equalTo: card.leadingAnchor, constant: 16),
            st.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -16),
            st.bottomAnchor.constraint(equalTo: card.bottomAnchor, constant: -34)])
    }
    required init?(coder: NSCoder) { fatalError() }

    private func row(_ icon: String, _ title: String, _ sub: String, _ sel: Selector) -> UIView {
        let b = UIControl(); b.backgroundColor = CARDC; b.layer.cornerRadius = 14
        b.heightAnchor.constraint(equalToConstant: 64).isActive = true
        b.addTarget(self, action: sel, for: .touchUpInside)
        let iv = UIImageView(image: UIImage(systemName: icon == "cube" ? "cube" : "cloud.fill")); iv.tintColor = ACC
        iv.contentMode = .scaleAspectFit; iv.isUserInteractionEnabled = false
        let a = UILabel(); a.text = title; a.textColor = .white; a.font = .boldSystemFont(ofSize: 15)
        let c = UILabel(); c.text = sub; c.textColor = argbToUIColor(C.DIM); c.font = .systemFont(ofSize: 12)
        let tx = UIStackView(arrangedSubviews: [a, c]); tx.axis = .vertical; tx.isUserInteractionEnabled = false
        let go = UIImageView(image: UIImage(systemName: "chevron.right")); go.tintColor = ACC
        for v in [iv, tx, go] as [UIView] { v.translatesAutoresizingMaskIntoConstraints = false; b.addSubview(v) }
        NSLayoutConstraint.activate([
            iv.leadingAnchor.constraint(equalTo: b.leadingAnchor, constant: 16), iv.centerYAnchor.constraint(equalTo: b.centerYAnchor),
            iv.widthAnchor.constraint(equalToConstant: 28), iv.heightAnchor.constraint(equalToConstant: 28),
            tx.leadingAnchor.constraint(equalTo: iv.trailingAnchor, constant: 14), tx.centerYAnchor.constraint(equalTo: b.centerYAnchor),
            go.trailingAnchor.constraint(equalTo: b.trailingAnchor, constant: -16), go.centerYAnchor.constraint(equalTo: b.centerYAnchor)])
        return b
    }

    private func animateIn() {
        layoutIfNeeded(); card.transform = CGAffineTransform(translationX: 0, y: 300); dim.alpha = 0
        UIView.animate(withDuration: 0.25) { self.card.transform = .identity; self.dim.alpha = 1 }
    }
    @objc func dismissSheet() {
        UIView.animate(withDuration: 0.2, animations: { self.card.transform = CGAffineTransform(translationX: 0, y: 300); self.dim.alpha = 0 }) { _ in self.removeFromSuperview() }
    }
    @objc private func tapModel() { removeFromSuperview(); onModel?() }
    @objc private func tapVdb() { removeFromSuperview(); onVdb?() }
}

// MARK: - Editor glue

extension EditorViewController {
    func openFullMediaBrowser() {
        let vc = MediaBrowserViewController()
        vc.modalPresentationStyle = .fullScreen
        vc.onAdd = { [weak self] a in self?.importPHAsset(a) }
        present(vc, animated: true)
    }

    func importPHAsset(_ a: PHAsset) {
        toast("Importing...")
        if a.mediaType == .video {
            let o = PHVideoRequestOptions(); o.isNetworkAccessAllowed = true; o.deliveryMode = .highQualityFormat
            PHImageManager.default().requestAVAsset(forVideo: a, options: o) { [weak self] av, _, _ in
                guard let u = (av as? AVURLAsset)?.url else {
                    DispatchQueue.main.async { self?.toast("Could not read the video") }; return }
                self?.importPickedVideo(u)         // copies synchronously, then adds the layer
            }
        } else {
            let o = PHImageRequestOptions(); o.isNetworkAccessAllowed = true; o.deliveryMode = .highQualityFormat; o.isSynchronous = false
            PHImageManager.default().requestImageDataAndOrientation(for: a, options: o) { [weak self] data, _, _, _ in
                DispatchQueue.main.async {
                    guard let self = self, let d = data, let img = UIImage(data: d),
                          let jpg = img.jpegData(compressionQuality: 0.95) else { self?.toast("Could not read the photo"); return }
                    let f = Projects.mediaDir().appendingPathComponent("\(Int(Date().timeIntervalSince1970 * 1000))_photo.jpg")
                    do { try jpg.write(to: f, options: .atomic) } catch { self.toast("Import failed"); return }
                    self.addMedia(f.path, .IMAGE)
                }
            }
        }
    }
}
