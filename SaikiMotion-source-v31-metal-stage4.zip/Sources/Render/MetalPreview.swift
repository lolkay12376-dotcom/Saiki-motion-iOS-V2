//  MetalPreview.swift
//  Metal migration stage 4 (part 3): the on-screen path. A CAMetalLayer-backed view that sits on
//  top of the GL preview (PreviewView) and is shown only for frames MetalSceneRenderer rendered.
//  Frames it cannot render (3D, particles, GL-only effects...) fall through to GL underneath.

import UIKit
import QuartzCore
import Metal

final class MetalPreviewView: UIView {
    override class var layerClass: AnyClass { CAMetalLayer.self }
    private var metalLayer: CAMetalLayer { layer as! CAMetalLayer }

    /// Last frame's fallback reason ("" = rendered by Metal). For the debug screen.
    private(set) var lastFallback = ""

    init() {
        super.init(frame: .zero)
        isUserInteractionEnabled = false          // touches go to the GL view / editor gizmos below
        isOpaque = true
        backgroundColor = .black
        isHidden = true
        let l = metalLayer
        l.device = MetalCore.shared?.device
        l.pixelFormat = .bgra8Unorm
        l.framebufferOnly = true
        l.isOpaque = true
        l.maximumDrawableCount = 3
        contentScaleFactor = UIScreen.main.scale
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    override func layoutSubviews() {
        super.layoutSubviews()
        let s = max(1, contentScaleFactor)
        metalLayer.drawableSize = CGSize(width: max(1, bounds.width * s), height: max(1, bounds.height * s))
    }

    /// Renders and presents one frame. false = the caller must render this frame in GL.
    func render(project: Project, scene: Scene, time: Float, quality: Int) -> Bool {
        guard bounds.width > 1, bounds.height > 1, metalLayer.drawableSize.width > 1,
              let r = MetalSceneRenderer.shared else { lastFallback = "no Metal / not laid out"; return false }
        r.quality = quality
        guard r.renderFrame(project: project, scene: scene, time: time) else {
            lastFallback = r.lastFallbackReason
            return false
        }
        lastFallback = ""
        return r.presentFrame(to: metalLayer)
    }
}
