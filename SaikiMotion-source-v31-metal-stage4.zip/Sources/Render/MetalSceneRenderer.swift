//  MetalSceneRenderer.swift
//  Metal migration stage 4 (part 2): 2D scene renderer (image / video / text / shape layers,
//  flat + precomp groups, group mattes, adjustment layers, blend modes, effect chains).
//
//  Used only when RenderBackend.useMetal is true AND the whole frame is "2D-eligible"
//  (see ineligibleReason). Otherwise the caller renders that frame with SceneRenderer (GL).
//
//  Frame life cycle (one command buffer per frame):
//    renderFrame(...)  -> encodes everything, returns false if the frame must go to GL
//    presentFrame(to:) -> blits the scene to a CAMetalLayer drawable, commits   (preview)
//    snapshotFrame()   -> commits, waits, returns a UIImage                      (thumbnails)
//    discardFrame()    -> drops an encoded frame that nobody will present

import Foundation
import Metal
import QuartzCore
import UIKit

final class MetalSceneRenderer {
    static let shared: MetalSceneRenderer? = MetalSceneRenderer()
    /// Set by the preview: called on the main thread when a video layer got a fresh frame.
    static var onVideoFrame: (() -> Void)?

    /// Effects that need GL-only machinery (multi-pass glow, time/jitter movers, tiling, layer inputs).
    static let glOnlyEffects: Set<String> = ["deepglow", "oscillate", "randisp", "motiontile", "twitch"]

    let core: MetalCore
    let passes: MetalPasses
    let fx: MetalEffects
    var quality = 1
    private(set) var width = 576
    private(set) var height = 1024
    /// Why the last renderFrame() returned false ("" when it rendered).
    private(set) var lastFallbackReason = ""
    private(set) var buildError: String?

    private var lib: MTLLibrary?
    private var psos: [String: MTLRenderPipelineState] = [:]
    private var sceneT: MetalTarget?
    private var scratchT: MetalTarget?
    private var layerA: MetalTarget?
    private var layerB: MetalTarget?
    private var groupPool: [MetalTarget] = []
    private var groupDepth = 0
    private let images: MetalImageCache
    private var samplers: [Int: MetalVideoSampler] = [:]
    private var cb: MTLCommandBuffer?
    private var keep: [MTLTexture] = []      // per-frame textures (text) that must outlive encoding

    private init?() {
        guard let c = MetalCore.shared, let p = MetalPasses.shared, let f = MetalEffects.shared else { return nil }
        core = c; passes = p; fx = f
        images = MetalImageCache(c)
        do {
            lib = try c.device.makeLibrary(source: MetalSceneSL.source, options: nil)
        } catch {
            buildError = String(String(describing: error).prefix(400))
        }
    }

    var ready: Bool { lib != nil && passes.buildError == nil }

    func trimMemory() { images.flush() }
    func releaseVideos() { samplers.removeAll() }

    // MARK: - eligibility

    /// nil when the whole frame can render in Metal; otherwise the reason it must go to GL.
    func ineligibleReason(_ scene: Scene, _ time: Float) -> String? {
        for l in scene.layers where l.visible && time >= l.start - 0.001 && time <= l.end + 0.001 {
            switch l.type {
            case .MODEL, .PARTICLES, .FLARE: return "layer type \(l.type.rawValue)"
            default: break
            }
            if l.is3d { return "3D layer \(l.name)" }
            if l.mblur { return "motion blur \(l.name)" }
            if l.type == .SHAPE, l.fx.contains("particles"), !l.fxOff.contains("particles") { return "particles fx" }
            if l.type == .GROUP {
                if l.prerender { return "pre-rendered group" }
                if (l.puppet?.on ?? false) && !(l.puppet?.pins.isEmpty ?? true) { return "group puppet" }
            } else if PuppetMath.mesh(l, time) != nil {
                return "puppet mesh \(l.name)"
            }
            for entry in l.fx where !l.fxOff.contains(entry) {
                guard let d = Registry.get(entry) else { continue }
                if MetalSceneRenderer.glOnlyEffects.contains(d.id) { return "GL-only effect \(d.id)" }
                if !d.inputs.isEmpty { return "effect with layer inputs \(d.id)" }
                if !fx.canRun(d) { return "effect \(d.id) has no Metal shader" }
            }
        }
        return nil
    }

    // MARK: - frame entry

    /// Encodes the whole frame. false = render this frame in GL (see lastFallbackReason).
    func renderFrame(project: Project, scene: Scene, time: Float) -> Bool {
        discardFrame()
        guard ready else { lastFallbackReason = "Metal scene shaders not ready"; return false }
        Rig.apply(scene.layers, time)
        if let r = ineligibleReason(scene, time) { lastFallbackReason = r; return false }
        ensureTargets(project)
        guard let st = sceneT, let buf = core.queue.makeCommandBuffer() else {
            lastFallbackReason = "no command buffer"; return false
        }
        buf.label = "SaikiMotion.frame"
        cb = buf
        keep.removeAll(keepingCapacity: true)
        groupDepth = 0

        let bg = UInt32(bitPattern: scene.bg)
        clear(st, MTLClearColor(red: Double((bg >> 16) & 0xFF) / 255, green: Double((bg >> 8) & 0xFF) / 255,
                                blue: Double(bg & 0xFF) / 255, alpha: 1))
        var visited = Set<ObjectIdentifier>()
        for l in scene.layers {
            if l.parentId >= 0, let par = scene.layers.first(where: { $0.id == l.parentId }), par.type == .GROUP { continue }
            drawLayer(l, project: project, scene: scene, time: time, target: st, visited: &visited)
        }
        lastFallbackReason = ""
        return true
    }

    /// Blits the encoded frame into the layer's next drawable and commits. false = nothing shown.
    func presentFrame(to layer: CAMetalLayer) -> Bool {
        guard let buf = cb, let st = sceneT else { return false }
        guard let drawable = layer.nextDrawable(),
              let pso = passes.pipeline(fragment: "blitFragment", format: drawable.texture.pixelFormat) else {
            discardFrame(); return false
        }
        let pd = MTLRenderPassDescriptor()
        pd.colorAttachments[0].texture = drawable.texture
        pd.colorAttachments[0].loadAction = .clear
        pd.colorAttachments[0].clearColor = MTLClearColor(red: 0, green: 0, blue: 0, alpha: 1)
        pd.colorAttachments[0].storeAction = .store
        guard let enc = buf.makeRenderCommandEncoder(descriptor: pd) else { discardFrame(); return false }
        enc.setRenderPipelineState(pso)
        enc.setFragmentTexture(st.tex, index: 0)
        enc.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 3)
        enc.endEncoding()
        buf.present(drawable)
        finish(buf)
        return true
    }

    /// Commits the encoded frame, waits for the GPU and returns it as an image (offscreen path).
    func snapshotFrame() -> UIImage? {
        guard let buf = cb, let st = sceneT else { return nil }
        finish(buf)
        buf.waitUntilCompleted()
        return st.readImage()
    }

    func discardFrame() {
        // an encoded-but-never-committed buffer is simply dropped (Metal allows this)
        cb = nil
        keep.removeAll(keepingCapacity: true)
    }

    /// One-shot offscreen render for thumbnails / the frame cache. nil = use GL.
    static func thumbnail(project: Project, scene: Scene, time: Float, quality: Int) -> UIImage? {
        guard let r = shared else { return nil }
        r.quality = quality
        guard r.renderFrame(project: project, scene: scene, time: time) else { return nil }
        return r.snapshotFrame()
    }

    private func finish(_ buf: MTLCommandBuffer) {
        let k = keep
        buf.addCompletedHandler { _ in _ = k.count }     // retain per-frame textures until the GPU is done
        buf.commit()
        cb = nil
    }

    // MARK: - targets

    private func ensureTargets(_ project: Project) {
        (width, height) = SceneRenderer.size(project, quality: quality)
        if sceneT == nil || sceneT!.width != width || sceneT!.height != height {
            sceneT = MetalTarget(core, width, height)
            scratchT = MetalTarget(core, width, height)
            layerA = MetalTarget(core, width, height)
            layerB = MetalTarget(core, width, height)
            groupPool.removeAll()
        }
    }

    private func poolTarget(_ d: Int) -> MetalTarget {
        while groupPool.count <= d { groupPool.append(MetalTarget(core, width, height)) }
        return groupPool[d]
    }

    private func clear(_ t: MetalTarget, _ c: MTLClearColor = MTLClearColor(red: 0, green: 0, blue: 0, alpha: 0)) {
        guard let buf = cb, let enc = buf.makeRenderCommandEncoder(descriptor: t.passDescriptor(clear: c)) else { return }
        enc.endEncoding()
    }

    // MARK: - per layer (port of SceneRenderer.drawLayer, 2D subset)

    private func drawLayer(_ l: Layer, project: Project, scene: Scene, time: Float, target: MetalTarget,
                           visited: inout Set<ObjectIdentifier>) {
        guard l.visible, time >= l.start - 0.001, time <= l.end + 0.001 else { return }
        let id = ObjectIdentifier(l)
        if visited.contains(id) { return }
        visited.insert(id)
        defer { visited.remove(id) }

        switch l.type {
        case .AUDIO, .CAMERA, .NULL:
            return
        case .GROUP:
            drawGroup(l, project: project, scene: scene, time: time, target: target, visited: &visited)
            return
        default:
            break
        }

        let opacity = l.p("opacity", l.editTime("opacity", time))
        if (l.type == .IMAGE || l.type == .VIDEO) && l.blend == 0 && l.mask == 0 && l.fx.isEmpty {
            // fast path: one blended quad straight into the target
            if opacity <= 0.0005 { return }
            _ = drawMedia(l, time: time, opacity: opacity, into: target, clear: false, blend: true)
        } else {
            renderLayerContent(l, time: time, target: target)
            applyEffects(l, time: time)
            composite(target, src: layerA!.tex, alpha: opacity, mode: l.blend)
        }
    }

    /// Port of drawGroup: a precomp renders its children into a private buffer, then mask, group
    /// effects, opacity and blend are applied to that one image.
    private func drawGroup(_ g: Layer, project: Project, scene: Scene, time: Float, target: MetalTarget,
                           visited: inout Set<ObjectIdentifier>) {
        let children = scene.layers.filter { $0.parentId == g.id }
        guard !children.isEmpty else { return }
        let opacity = g.p("opacity", time)
        let hasFx = !g.fx.isEmpty
        guard g.precomp || g.mask != 0 || hasFx, groupDepth < 4 else {
            for c in children {
                drawLayer(c, project: project, scene: scene, time: time, target: target, visited: &visited)
            }
            return
        }
        if let img = precompImage(g, children: children, project: project, scene: scene, time: time, visited: &visited) {
            composite(target, src: img.tex, alpha: opacity, mode: g.blend)
        }
    }

    /// Port of precompImage. NOTE (matte): the matte is the first child's finished content (layerA
    /// after its effects). The GL code composites with layerB.tex, which only holds that content
    /// when the matte child's effect chain happens to end in layerB (e.g. exactly one effect).
    private func precompImage(_ g: Layer, children: [Layer], project: Project, scene: Scene, time: Float,
                              visited: inout Set<ObjectIdentifier>) -> MetalTarget? {
        guard groupDepth < 4, let a = layerA, let cbuf = cb else { return nil }
        let grp = poolTarget(groupDepth)
        groupDepth += 1
        defer { groupDepth -= 1 }

        clear(grp)
        for c in children {
            drawLayer(c, project: project, scene: scene, time: time, target: grp, visited: &visited)
        }

        if g.mask != 0, let first = children.first, first.isRenderable() {
            renderLayerContent(first, time: time, target: grp)
            applyEffects(first, time: time)
            composite(grp, src: grp.tex, mask: a.tex, maskMode: g.mask, alpha: 1, mode: 0)
        }

        _ = passes.blit(cbuf, src: grp.tex, to: a)
        if !g.fx.isEmpty { applyEffects(g, time: time) }
        return a
    }

    /// Port of renderLayerContent: draws the layer's own content into layerA (cleared first).
    private func renderLayerContent(_ l: Layer, time: Float, target: MetalTarget) {
        guard let a = layerA, let cbuf = cb else { return }
        var drew = false
        switch l.type {
        case .IMAGE, .VIDEO:
            drew = drawMedia(l, time: time, opacity: 1, into: a, clear: true, blend: false)
        case .TEXT:
            drew = drawText(l, time: time, into: a)
        case .SHAPE:
            drew = drawShape(l, time: time, into: a)
        case .ADJUST:
            drew = passes.blit(cbuf, src: target.tex, to: a)     // content = the buffer below
        default:
            break
        }
        if !drew { clear(a) }
    }

    // MARK: - drawing primitives

    private func composite(_ target: MetalTarget, src: MTLTexture, mask: MTLTexture? = nil, maskMode: Int = 0,
                           alpha: Float, mode: Int) {
        guard let buf = cb, let scratch = scratchT else { return }
        _ = passes.composite(buf, target: target, scratch: scratch, src: src, mask: mask,
                             alpha: alpha, mode: mode, maskMode: maskMode)
    }

    private func pso(_ fragment: String, blend: Bool, format: MTLPixelFormat) -> MTLRenderPipelineState? {
        let key = "\(fragment)/\(blend)/\(format.rawValue)"
        if let p = psos[key] { return p }
        guard let lib = lib, let vf = lib.makeFunction(name: "quadVertex"),
              let ff = lib.makeFunction(name: fragment) else { return nil }
        let d = MTLRenderPipelineDescriptor()
        d.vertexFunction = vf
        d.fragmentFunction = ff
        let ca = d.colorAttachments[0]!
        ca.pixelFormat = format
        if blend {                              // glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA)
            ca.isBlendingEnabled = true
            ca.sourceRGBBlendFactor = .one
            ca.destinationRGBBlendFactor = .oneMinusSourceAlpha
            ca.sourceAlphaBlendFactor = .one
            ca.destinationAlphaBlendFactor = .oneMinusSourceAlpha
        }
        guard let p = try? core.device.makeRenderPipelineState(descriptor: d) else { return nil }
        psos[key] = p
        return p
    }

    private func quadUniforms(_ l: Layer, time: Float) -> QuadU {
        let (qw, qh) = Xf.quadSize(l)
        let m = Xf.matrix(l, time)
        var u = QuadU()
        u.abcd = SIMD4<Float>(m[0], m[1], m[2], m[3])
        u.t = SIMD2<Float>(m[4], m[5])
        u.quad = SIMD2<Float>(qw, qh)
        u.aspect = Float(width) / Float(max(height, 1))
        return u
    }

    @discardableResult
    private func drawQuadPass(_ frag: String, blend: Bool, into t: MetalTarget, clear doClear: Bool,
                              u: QuadU, tex: MTLTexture?) -> Bool {
        guard let buf = cb, let p = pso(frag, blend: blend, format: t.tex.pixelFormat) else { return false }
        let pd = t.passDescriptor(clear: doClear ? MTLClearColor(red: 0, green: 0, blue: 0, alpha: 0) : nil)
        guard let enc = buf.makeRenderCommandEncoder(descriptor: pd) else { return false }
        var uu = u
        enc.setRenderPipelineState(p)
        enc.setVertexBytes(&uu, length: MemoryLayout<QuadU>.stride, index: 0)
        enc.setFragmentBytes(&uu, length: MemoryLayout<QuadU>.stride, index: 0)
        if let tx = tex { enc.setFragmentTexture(tx, index: 0) }
        enc.drawPrimitives(type: .triangleStrip, vertexStart: 0, vertexCount: 4)
        enc.endEncoding()
        return true
    }

    private func drawMedia(_ l: Layer, time: Float, opacity: Float, into t: MetalTarget,
                           clear: Bool, blend: Bool) -> Bool {
        guard let path = l.imagePath else { return false }
        var tex: MTLTexture?
        if l.type == .VIDEO { tex = sampler(for: l, path: path).texture(at: sourceTime(l, time)) }
        if tex == nil { tex = images.texture(path: path, quality: quality) }
        guard let tx = tex else { return false }
        var u = quadUniforms(l, time: time)
        u.color = SIMD4<Float>(opacity, opacity, opacity, opacity)
        u.flipY = 1
        return drawQuadPass("quadFragment", blend: blend, into: t, clear: clear, u: u, tex: tx)
    }

    private func drawText(_ l: Layer, time: Float, into t: MetalTarget) -> Bool {
        let img = TextRaster.raster(l, time)
        guard img.size.width > 1, img.size.height > 1,
              let up = MetalImageUpload.texture(core, img, maxSide: 4096) else { return false }
        keep.append(up.tex)
        var u = quadUniforms(l, time: time)
        u.flipY = 1
        return drawQuadPass("quadFragment", blend: false, into: t, clear: true, u: u, tex: up.tex)
    }

    private func drawShape(_ l: Layer, time: Float, into t: MetalTarget) -> Bool {
        var u = quadUniforms(l, time: time)
        let c = UInt32(bitPattern: l.color)
        u.color = SIMD4<Float>(Float((c >> 16) & 0xFF) / 255, Float((c >> 8) & 0xFF) / 255,
                               Float(c & 0xFF) / 255, Float((c >> 24) & 0xFF) / 255)
        switch l.shape {
        case .RECT: u.kind = 0
        case .ROUND: u.kind = 1
        case .CIRCLE: u.kind = 2
        case .TRIANGLE: u.kind = 3
        case .STAR: u.kind = 4
        }
        u.corner = 0.12
        return drawQuadPass("shapeFragment", blend: false, into: t, clear: true, u: u, tex: nil)
    }

    private func sampler(for l: Layer, path: String) -> MetalVideoSampler {
        if let s = samplers[l.id] { return s }
        let s = MetalVideoSampler(path: path, device: core.device)
        s.onFrame = { MetalSceneRenderer.onVideoFrame?() }
        samplers[l.id] = s
        return s
    }

    /// Source-media time for a video layer at scene time `t` (remap aware) — copy of SceneRenderer.sourceTime.
    private func sourceTime(_ l: Layer, _ t: Float) -> Float {
        if let tr = l.props["remapT"], !tr.keys.isEmpty {
            return max(0, tr.eval(t) + l.srcOffset)
        }
        let sp = l.props["remapSpeed"]?.eval(t) ?? 1
        return max(0, (t - l.start) * sp + l.srcOffset)
    }

    // MARK: - effects (port of SceneRenderer.applyEffects through MetalEffects)

    private func paramValue(_ l: Layer, key: String, def: Float, time: Float) -> Float {
        if let tr = l.props[key] {
            return tr.evalExpr(l.editTime(key, time), time, tr.exprActive() ? Editor.scene.markersByName() : [:])
        }
        return def
    }

    private func colorComp(_ l: Layer, key: String, def: Float, time: Float) -> Float {
        if let tr = l.props[key] { return tr.eval(l.editTime(key, time)) }
        return def
    }

    private func effectSteps(_ l: Layer, time: Float) -> [MetalEffects.Step] {
        var out: [MetalEffects.Step] = []
        for entry in l.fx where !l.fxOff.contains(entry) {
            guard let d = Registry.get(entry) else { continue }
            let single = d.kind == 1
            var props: [Float] = []
            for pd in d.props {
                let key = single ? pd.key : entry + "__" + pd.key
                props.append(paramValue(l, key: key, def: pd.def, time: time))
            }
            var cols: [SIMD4<Float>] = []
            for cp in d.colors {
                let base = single ? cp.key : entry + "__" + cp.key
                let c = UInt32(bitPattern: cp.def)
                let r = colorComp(l, key: base + "_r", def: Float((c >> 16) & 0xFF) / 255, time: time)
                let g = colorComp(l, key: base + "_g", def: Float((c >> 8) & 0xFF) / 255, time: time)
                let b = colorComp(l, key: base + "_b", def: Float(c & 0xFF) / 255, time: time)
                let a = colorComp(l, key: base + "_a", def: Float((c >> 24) & 0xFF) / 255, time: time)
                cols.append(SIMD4<Float>(r, g, b, a))
            }
            out.append(MetalEffects.Step(def: d, props: props, colors: cols))
        }
        return out
    }

    /// Runs the layer's effect chain on layerA; the result ends up in layerA.
    private func applyEffects(_ l: Layer, time: Float) {
        guard !l.fx.isEmpty, let buf = cb, let a = layerA, let b = layerB else { return }
        let steps = effectSteps(l, time: time)
        guard !steps.isEmpty else { return }
        var rect: (c: SIMD2<Float>, x: SIMD2<Float>, y: SIMD2<Float>)? = nil
        if l.type != .GROUP && l.type != .ADJUST {          // the layer's rectangle in world units
            let m = Xf.matrix(l, time)
            let (qw, qh) = Xf.quadSize(l)
            rect = (SIMD2<Float>(m[4], m[5]), SIMD2<Float>(m[0] * qw, m[1] * qw), SIMD2<Float>(m[2] * qh, m[3] * qh))
        }
        let result = fx.applyChain(buf, steps: steps, a: a, b: b, time: time, rect: rect)
        if result !== a { swap(&a.tex, &b.tex) }
    }
}
