/* SaikiMotion ABC (Alembic/Ogawa) -> GLB transcoder.
 * Freestanding C (no libc): all OS services arrive via struct Host function
 * pointers supplied by the injected trampoline. One translation unit, no
 * globals, no recursion, no adrp-to-own-data -> the emitted arm64 object has
 * zero relocations and can be copied into the __PATCH segment verbatim.
 *
 * Entry: abc_hook(path_utf8, path_len, host)
 *   - path is the UTF-8 bytes of a Swift String (large/heap form), rewritten
 *     IN PLACE (".abc" -> ".glb", same length) when transcoding succeeds.
 *   - returns 1 when the file was transcoded, 0 when not handled.
 */

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;
typedef unsigned long long u64;
typedef long long i64;
typedef int b32;

struct Host {
    void* (*fopen)(const char*, const char*);
    int   (*fclose)(void*);
    unsigned long (*fread)(void*, unsigned long, unsigned long, void*);
    unsigned long (*fwrite)(const void*, unsigned long, unsigned long, void*);
    void* (*malloc)(unsigned long);
    void  (*free)(void*);
};

#define MAX_MESHES 32
#define MAX_DEPTH 24
#define MAX_PROPS 64

static u64 rd_u64(const u8* p) {
    return (u64)p[0] | ((u64)p[1] << 8) | ((u64)p[2] << 16) | ((u64)p[3] << 24)
         | ((u64)p[4] << 32) | ((u64)p[5] << 40) | ((u64)p[6] << 48) | ((u64)p[7] << 56);
}
static u32 rd_u32(const u8* p) {
    return (u32)p[0] | ((u32)p[1] << 8) | ((u32)p[2] << 16) | ((u32)p[3] << 24);
}
static u16 rd_u16(const u8* p) { return (u16)(p[0] | (p[1] << 8)); }
static float rd_f32(const u8* p) {
    u32 v = rd_u32(p);
    return *(float*)&v;   /* freestanding alias-safe enough on arm64 */
}

/* ---- file vector (growable byte buffer) ---- */
struct Buf {
    u8* data;
    u64 len, cap;
    struct Host* h;
};
static b32 buf_reserve(struct Buf* b, u64 extra) {
    if (b->len + extra <= b->cap) return 1;
    u64 nc = b->cap ? b->cap * 2 : 4096;
    while (nc < b->len + extra) nc *= 2;
    u8* nd = (u8*)b->h->malloc(nc);
    if (!nd) return 0;
    for (u64 i = 0; i < b->len; i++) nd[i] = b->data[i];
    if (b->data) b->h->free(b->data);
    b->data = nd;
    b->cap = nc;
    return 1;
}
static b32 buf_u8(struct Buf* b, u8 v) { if (!buf_reserve(b, 1)) return 0; b->data[b->len++] = v; return 1; }
static b32 buf_bytes(struct Buf* b, const u8* p, u64 n) {
    if (!buf_reserve(b, n)) return 0;
    for (u64 i = 0; i < n; i++) b->data[b->len + i] = p[i];
    b->len += n;
    return 1;
}
static b32 buf_str(struct Buf* b, const char* s) {
    while (*s) { if (!buf_u8(b, (u8)*s)) return 0; s++; }
    return 1;
}
static b32 buf_u32le(struct Buf* b, u32 v) {
    return buf_u8(b, (u8)v) && buf_u8(b, (u8)(v >> 8)) && buf_u8(b, (u8)(v >> 16)) && buf_u8(b, (u8)(v >> 24));
}

/* ---- tiny number formatting (replaces printf) ---- */
static b32 buf_int(struct Buf* b, i64 v) {
    char tmp[24];
    int n = 0;
    if (v < 0) { if (!buf_u8(b, '-')) return 0; v = -v; }
    if (v == 0) tmp[n++] = '0';
    while (v > 0) { tmp[n++] = (char)('0' + (v % 10)); v /= 10; }
    for (int i = n - 1; i >= 0; i--) if (!buf_u8(b, (u8)tmp[i])) return 0;
    return 1;
}
static b32 buf_float(struct Buf* b, float f) {
    /* 6 significant digits, plain decimal — good enough for glTF JSON */
    if (f < 0.0f) { if (!buf_u8(b, '-')) return 0; f = -f; }
    i64 ip = (i64)f;
    float fr = f - (float)ip;
    /* round to 5 decimals */
    i64 fr5 = (i64)((fr * 100000.0f) + 0.5f);
    if (fr5 >= 100000) { ip += 1; fr5 = 0; }
    if (!buf_int(b, ip)) return 0;
    if (fr5 == 0) return 1;
    if (!buf_u8(b, '.')) return 0;
    char d[6];
    for (int i = 4; i >= 0; i--) { d[i] = (char)('0' + (fr5 % 10)); fr5 /= 10; }
    int last = 4;
    while (last > 0 && d[last] == '0') last--;
    for (int i = 0; i <= last; i++) if (!buf_u8(b, (u8)d[i])) return 0;
    return 1;
}

/* ---- Ogawa reading ---- */
struct Abc {
    u8* d;
    u64 n;
};

/* resolve child i of group at off: kind 0=none 1=group 2=data */
static int og_child(struct Abc* a, u64 group, u64 i, u64* out_off, u64* out_size) {
    if (group + 8 > a->n) return 0;
    u64 cnt = rd_u64(a->d + group);
    if (i >= cnt) return 0;
    u64 enc = rd_u64(a->d + group + 8 + 8 * i);
    if (enc == 0) return 0;
    u64 off = enc & 0x7FFFFFFFFFFFFFFFULL;
    if (enc >> 63) {
        if (off + 8 > a->n) return 0;
        u64 sz = rd_u64(a->d + off);
        if (off + 8 + sz > a->n) return 0;
        *out_off = off + 8;
        *out_size = sz;
        return 2;
    }
    *out_off = off;
    *out_size = 0;
    return 1;
}

/* ---- property header ---- */
struct Prop {
    u32 ptype;   /* 0 compound 1 scalar 2 array */
    u32 pod;     /* 10 = f32, 6 = i32 */
    u32 extent;
    u64 next, first, last;
    u32 tsidx;
    const u8* name;
    u32 name_len;
};

static b32 parse_headers_ex(struct Abc* a, u64 off, u64 size, struct Prop* props, u32* count, int tsw4, int strict, int cskip) {
    u64 pos = off;
    u64 end = off + size;
    u32 n = 0;
    while (pos + 4 <= end && n < MAX_PROPS) {
        u32 info = rd_u32(a->d + pos); pos += 4;
        u32 ptype = info & 3;
        u32 hint = (info >> 2) & 3;
        u32 meta_idx = (info >> 20) & 0xFF;
        u32 ws[3] = {1, 2, 4};
        u32 w = ws[hint];
        if (pos + w > end) return 0;
        /* helper macro-ish reads */
        u64 next = 0, first = 0, last = 0; u32 tsidx = 0;
        int skipSamples = (cskip && ptype == 0);   /* compounds carry no sample fields */
        /* next_sample_index */
        if (!skipSamples) {
        if (pos + w > end) return 0;
        next = hint == 0 ? a->d[pos] : hint == 1 ? rd_u16(a->d + pos) : rd_u32(a->d + pos);
        pos += w;
        }
        if (skipSamples) {
        } else if (info & 0x200) {
            if (pos + 2 * w > end) return 0;
            first = hint == 0 ? a->d[pos] : hint == 1 ? rd_u16(a->d + pos) : rd_u32(a->d + pos);
            pos += w;
            last = hint == 0 ? a->d[pos] : hint == 1 ? rd_u16(a->d + pos) : rd_u32(a->d + pos);
            pos += w;
        } else if (info & 0x800) {
            first = 0; last = 0;
        } else {
            first = 1; last = next ? next - 1 : 0;
        }
        if (!skipSamples && (info & 0x100)) {
            u32 tw = tsw4 ? 4 : w;           /* some writers store it as a full u32 */
            if (pos + tw > end) return 0;
            tsidx = tw == 4 ? rd_u32(a->d + pos) : (w == 1 ? a->d[pos] : rd_u16(a->d + pos));
            pos += tw; /* time_sampling_index */
        }
        if (pos + w > end) return 0;
        u64 name_size = hint == 0 ? a->d[pos] : hint == 1 ? rd_u16(a->d + pos) : rd_u32(a->d + pos);
        pos += w;
        if (pos + name_size > end) return 0;
        if (strict) {
            if (name_size == 0 || name_size > 200) return 0;
            for (u64 q = 0; q < name_size; q++) if (a->d[pos + q] < 0x20 || a->d[pos + q] > 0x7E) return 0;
            if (ptype == 3) return 0;
        }
        props[n].ptype = ptype;
        props[n].pod = (info >> 4) & 0xF;
        props[n].extent = (info >> 12) & 0xFF;
        props[n].next = next;
        props[n].first = first;
        props[n].last = last;
        props[n].tsidx = tsidx;
        props[n].name = a->d + pos;
        props[n].name_len = (u32)name_size;
        pos += name_size;
        if (meta_idx == 0xFF) {
            if (pos + w > end) return 0;
            u64 msz = hint == 0 ? a->d[pos] : hint == 1 ? rd_u16(a->d + pos) : rd_u32(a->d + pos);
            pos += w;
            if (pos + msz > end) return 0;
            pos += msz;
        }
        n++;
    }
    if (strict && n < MAX_PROPS && pos != end) return 0;
    *count = n;
    return 1;
}

static b32 parse_headers(struct Abc* a, u64 off, u64 size, struct Prop* props, u32* count) {
    if (parse_headers_ex(a, off, size, props, count, 0, 1, 1)) return 1;
    if (parse_headers_ex(a, off, size, props, count, 1, 1, 1)) return 1;
    if (parse_headers_ex(a, off, size, props, count, 0, 1, 0)) return 1;
    if (parse_headers_ex(a, off, size, props, count, 1, 1, 0)) return 1;
    if (parse_headers_ex(a, off, size, props, count, 0, 0, 1)) return 1;
    return parse_headers_ex(a, off, size, props, count, 0, 0, 0);
}

static u64 verify_index(u64 i, u64 first, u64 last) {
    if (i < first) return 0;
    if (first == last && first == 0) return 0;
    if (i >= last) return last - first + 1;
    return i - first + 1;
}

static b32 name_is(struct Prop* p, const char* s) {
    u32 i = 0;
    while (s[i] && i < p->name_len) { if (p->name[i] != (u8)s[i]) return 0; i++; }
    return s[i] == 0 && i == p->name_len;
}

/* one collected mesh */
struct Mesh {
    const float* pos;
    u64 pos_count;
    const u32* idx;   /* stored as i32 in file; widened here */
    u64 idx_count;
    u32* idx_wide;    /* malloc'd widened copy (needed >65535 support) */
    /* animation: P sample i is read straight from the file */
    u64 pgroup; struct Prop pprop; u64 nsamples; int pdbl;
    /* uv (optional): vals + optional per-corner indices */
    const u8* uv; u64 uv_count; const u8* uvi; u64 uvi_count;
    u32 tsidx; u64 ncorner;
    u32* src;         /* per output vertex: source point index (corner unrolled) */
    float* uvout;     /* per output vertex uv (glTF orientation) or 0 */
};

/* get array sample 0 payload for property sub-group */
static b32 array_sample(struct Abc* a, struct Prop* p, u64 group, u64 si,
                         const u8** out, u64* out_len, u64* out_count) {
    u64 sidx = verify_index(si, p->first, p->last) * 2;
    u64 off, sz;
    int k = og_child(a, group, sidx, &off, &sz);
    if (k != 2 || sz < 16) return 0;
    const u8* payload = a->d + off + 16;
    u64 plen = sz - 16;
    u64 cnt = 0;
    u64 doff, dsz;
    int dk = og_child(a, group, sidx + 1, &doff, &dsz);
    if (dk == 2 && dsz >= 8) {
        cnt = rd_u64(a->d + doff);
    } else {
        u32 pods = p->pod == 10 ? 4 : p->pod == 11 ? 8 : p->pod == 6 ? 4 : p->pod == 5 ? 4 : 4;
        u64 ext = p->extent ? p->extent : 1;
        cnt = plen / (pods * ext);
    }
    *out = payload;
    *out_len = plen;
    *out_count = cnt;
    return 1;
}

static b32 array_sample0(struct Abc* a, struct Prop* p, u64 group,
                         const u8** out, u64* out_len, u64* out_count) {
    return array_sample(a, p, group, 0, out, out_len, out_count);
}

/* scan a compound group for a polymesh (P + .faceIndices + .faceCounts) */
static b32 scan_compound(struct Abc* a, u64 group, struct Mesh* m, struct Host* h);

/* crude rsqrt without libm (classic Quake fast inverse sqrt + Newton step) */
static float rsqrt_est(float x) {
    u32 i = *(u32*)&x;
    i = 0x5F3759DF - (i >> 1);
    float y = *(float*)&i;
    if (y <= 0.0f) return 1.0f;
    y = y * (1.5f - 0.5f * x * y * y);   /* one Newton-Raphson refinement */
    return y;
}

struct WalkFrame { u64 group; };

static b32 walk_objects(struct Abc* a, u64 group, struct Mesh* meshes, u32* mesh_count,
                        struct Host* h, int depth) {
    if (depth > MAX_DEPTH) return 1;
    if (*mesh_count >= MAX_MESHES) return 1;
    u64 off, sz;
    int k = og_child(a, group, 0, &off, &sz);
    if (k == 1) {
        /* child 0: the object's properties compound */
        if (scan_compound(a, off, &meshes[*mesh_count], h)) {
            (*mesh_count)++;
        }
    }
    u64 cnt = rd_u64(a->d + group);
    if (cnt < 2) return 1;
    /* children 1 .. cnt-2 are objects (child cnt-1 holds headers) */
    for (u64 i = 1; i + 1 < cnt; i++) {
        u64 ooff, osz;
        int ok = og_child(a, group, i, &ooff, &osz);
        if (ok == 1) {
            walk_objects(a, ooff, meshes, mesh_count, h, depth + 1);
            if (*mesh_count >= MAX_MESHES) return 1;
        }
    }
    return 1;
}

/* scan compound: descend into sub-compounds looking for the mesh trio */
static b32 scan_compound(struct Abc* a, u64 group, struct Mesh* m, struct Host* h) {
    u64 cnt = rd_u64(a->d + group);
    if (cnt < 1) return 0;
    u64 hoff, hsz;
    int k = og_child(a, group, cnt - 1, &hoff, &hsz);
    if (k != 2) return 0;
    struct Prop props[MAX_PROPS];
    u32 pn = 0;
    if (!parse_headers(a, hoff, hsz, props, &pn)) return 0;
    b32 hasP = 0, hasFI = 0, hasFC = 0;
    u64 iP = 0, iFI = 0, iFC = 0;
    for (u32 i = 0; i < pn; i++) {
        if (props[i].ptype == 2 && name_is(&props[i], "P")) { hasP = 1; iP = i; }
        if (props[i].ptype == 2 && name_is(&props[i], ".faceIndices")) { hasFI = 1; iFI = i; }
        if (props[i].ptype == 2 && name_is(&props[i], ".faceCounts")) { hasFC = 1; iFC = i; }
    }
    if (hasP && hasFI && hasFC) {
        u64 goff, gsz;
        const u8 *P = 0, *FI = 0, *FC = 0;
        u64 Plen = 0, FIlen = 0, FClen = 0, Pcnt = 0, FIcnt = 0, FCcnt = 0;
        int kk = og_child(a, group, iP, &goff, &gsz);
        if (kk != 1 || !array_sample0(a, &props[iP], goff, &P, &Plen, &Pcnt)) return 0;
        kk = og_child(a, group, iFI, &goff, &gsz);
        if (kk != 1 || !array_sample0(a, &props[iFI], goff, &FI, &FIlen, &FIcnt)) return 0;
        kk = og_child(a, group, iFC, &goff, &gsz);
        if (kk != 1 || !array_sample0(a, &props[iFC], goff, &FC, &FClen, &FCcnt)) return 0;
        if (Pcnt == 0 || FIcnt == 0) return 0;
        int dbl = props[iP].pod == 11;
        if (Plen < Pcnt * (dbl ? 24 : 12)) return 0;
        /* polygons -> triangle fans using .faceCounts (quads / n-gons are common in exports) */
        u64 outCount = FIcnt;
        b32 fan = 0;
        if (FCcnt > 0 && FClen >= FCcnt * 4) {
            u64 sum = 0, tris = 0; b32 any = 0;
            for (u64 f = 0; f < FCcnt; f++) {
                int c = (int)rd_u32(FC + 4 * f);
                if (c < 3) { any = 0; sum = 0; break; }
                sum += (u64)c; tris += (u64)(c - 2);
                if (c != 3) any = 1;
            }
            if (sum == FIcnt && any) { fan = 1; outCount = tris * 3; }
        }
        u64 extra = dbl ? Pcnt * 3 : 0;
        u32* wide = (u32*)h->malloc((outCount + extra) * 4);
        if (!wide) return 0;
        u32* cor = (u32*)h->malloc(outCount * 4 + 4);
        if (!cor) { h->free(wide); return 0; }
        #define VIDX(k) ({ i64 v_ = (i64)(int)rd_u32(FI + 4 * (k)); (v_ >= 0 && (u64)v_ < Pcnt) ? (u32)v_ : 0u; })
        if (fan) {
            u64 o = 0, s0 = 0;
            for (u64 f = 0; f < FCcnt; f++) {
                u64 c = (u64)(int)rd_u32(FC + 4 * f);
                for (u64 k = 1; k + 1 < c; k++) {
                    cor[o] = (u32)s0; wide[o++] = VIDX(s0); cor[o] = (u32)(s0 + k); wide[o++] = VIDX(s0 + k); cor[o] = (u32)(s0 + k + 1); wide[o++] = VIDX(s0 + k + 1);
                }
                s0 += c;
            }
        } else {
            for (u64 i = 0; i < FIcnt; i++) { cor[i] = (u32)i; wide[i] = VIDX(i); }
        }
        #undef VIDX
        if (dbl) {
            float* pf = (float*)(wide + outCount);   /* freed together with the index block */
            for (u64 i = 0; i < Pcnt * 3; i++) {
                union { u64 u; double d; } cv; cv.u = rd_u64(P + 8 * i);
                pf[i] = (float)cv.d;
            }
            m->pos = pf;
        } else {
            m->pos = (const float*)P;
        }
        m->pgroup = 0; m->pprop = props[iP]; m->nsamples = props[iP].next; m->pdbl = dbl; m->tsidx = props[iP].tsidx;
        { u64 g2, s2; if (og_child(a, group, iP, &g2, &s2) == 1) m->pgroup = g2; }
        m->uv = 0; m->uv_count = 0; m->uvi = 0; m->uvi_count = 0;
        for (u32 i = 0; i < pn; i++) {
            if (!name_is(&props[i], "uv")) continue;
            u64 ug, us2; if (og_child(a, group, i, &ug, &us2) != 1) break;
            if (props[i].ptype == 2) {            /* plain array of float2 */
                u64 l2; array_sample0(a, &props[i], ug, &m->uv, &l2, &m->uv_count);
            } else if (props[i].ptype == 0) {     /* geom param compound: .vals (+ .indices) */
                u64 uc = rd_u64(a->d + ug), ho, hs;
                struct Prop up[8]; u32 un = 0;
                if (uc < 1 || og_child(a, ug, uc - 1, &ho, &hs) != 2 || !parse_headers(a, ho, hs, up, &un)) break;
                for (u32 j = 0; j < un && j < 8; j++) {
                    u64 jg, js2, l2;
                    if (up[j].ptype != 2 || og_child(a, ug, j, &jg, &js2) != 1) continue;
                    if (name_is(&up[j], ".vals")) array_sample0(a, &up[j], jg, &m->uv, &l2, &m->uv_count);
                    else if (name_is(&up[j], ".indices")) array_sample0(a, &up[j], jg, &m->uvi, &l2, &m->uvi_count);
                }
            }
            break;
        }
        m->pos_count = Pcnt;
        m->idx_wide = wide;
        m->src = cor; m->ncorner = FIcnt;
        m->idx_count = outCount;
        return 1;
    }
    /* not a mesh: descend into sub-compounds */
    for (u32 i = 0; i < pn; i++) {
        if (props[i].ptype != 0) continue;
        u64 goff, gsz;
        int kk = og_child(a, group, i, &goff, &gsz);
        if (kk == 1) {
            if (scan_compound(a, goff, m, h)) return 1;
        }
    }
    return 0;
}

/* ---- animation helpers ---- */
static void get_frame(struct Abc* a, struct Mesh* m, u64 f, float* out) {
    u64 nv = m->pos_count;
    u64 si = f < m->nsamples ? f : (m->nsamples ? m->nsamples - 1 : 0);
    const u8* P = 0; u64 pl = 0, pc = 0;
    int ok = m->pgroup && array_sample(a, &m->pprop, m->pgroup, si, &P, &pl, &pc)
             && pc == nv && pl >= nv * (m->pdbl ? 24 : 12);
    if (!ok) {                                   /* topology change / bad sample: hold frame 0 */
        const u8* b = (const u8*)m->pos;
        for (u64 i = 0; i < nv * 3; i++) out[i] = rd_f32(b + 4 * i);
        return;
    }
    if (m->pdbl) {
        for (u64 i = 0; i < nv * 3; i++) { union { u64 u; double d; } cv; cv.u = rd_u64(P + 8 * i); out[i] = (float)cv.d; }
    } else {
        for (u64 i = 0; i < nv * 3; i++) out[i] = rd_f32(P + 4 * i);
    }
}

static void calc_nrm(const float* pos, const u32* idx, u64 ni, u64 nv, float* nrm) {
    for (u64 v = 0; v < nv * 3; v++) nrm[v] = 0.0f;
    for (u64 t = 0; t + 2 < ni; t += 3) {
        u32 a = idx[t], b2 = idx[t + 1], c2 = idx[t + 2];
        if (a >= nv || b2 >= nv || c2 >= nv) continue;
        float ux = pos[b2*3] - pos[a*3], uy = pos[b2*3+1] - pos[a*3+1], uz = pos[b2*3+2] - pos[a*3+2];
        float vx = pos[c2*3] - pos[a*3], vy = pos[c2*3+1] - pos[a*3+1], vz = pos[c2*3+2] - pos[a*3+2];
        float nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
        nrm[a*3] += nx; nrm[a*3+1] += ny; nrm[a*3+2] += nz;
        nrm[b2*3] += nx; nrm[b2*3+1] += ny; nrm[b2*3+2] += nz;
        nrm[c2*3] += nx; nrm[c2*3+1] += ny; nrm[c2*3+2] += nz;
    }
    for (u64 v = 0; v < nv; v++) {
        float x = nrm[v*3], y = nrm[v*3+1], z = nrm[v*3+2];
        float l2 = x * x + y * y + z * z;
        if (l2 > 1e-20f) { float inv = rsqrt_est(l2); x *= inv; y *= inv; z *= inv; } else { x = 0; y = 1; z = 0; }
        nrm[v*3] = x; nrm[v*3+1] = y; nrm[v*3+2] = z;
    }
}

/* frames per second from the archive's time-sampling table (root child 4); 24 when unknown */
static float ts_fps(struct Abc* a, u64 root, u32 tsidx) {
    u64 off, sz;
    if (og_child(a, root, 4, &off, &sz) != 2) return 24.0f;
    u64 pos = 0; u32 idx = 0;
    while (pos + 16 <= sz) {
        double tpc; u32 ns = rd_u32(a->d + off + pos + 12);
        union { u64 u; double d; } cv; cv.u = rd_u64(a->d + off + pos + 4); tpc = cv.d;
        pos += 16;
        if (pos + (u64)ns * 8 > sz || ns > 1000000) break;
        if (idx == tsidx) {
            double dt = tpc;
            if (ns >= 2) { union { u64 u; double d; } t0, t1; t0.u = rd_u64(a->d + off + pos); t1.u = rd_u64(a->d + off + pos + 8); dt = t1.d - t0.d; }
            if (tpc > 1e100 && ns < 2) dt = 0;
            if (dt > 0.001 && dt < 1.0 && ns < 2) return (float)(1.0 / dt);
            if (dt > 0.001 && dt <= 1.0) return (float)(1.0 / dt);
            return 24.0f;
        }
        pos += (u64)ns * 8; idx++;
    }
    return 24.0f;
}

static b32 fw_u32(struct Host* h, void* f, u32 v) { return h->fwrite(&v, 1, 4, f) == 4; }

/* ---- GLB assembly ---- */
/* Every mesh is unrolled to one vertex per triangle corner so UVs (per face-vertex) survive; vertex k
 * of the output reads point idx_wide[k] and corner src[k]. */
static b32 build_glb(struct Buf* out, struct Mesh* meshes, u32 mesh_count, struct Host* h, struct Abc* abc) {
    struct Buf bin = {0};
    bin.h = h;
    struct { u64 off[4], len[4], nv, ni; float mn[3], mx[3]; } M[MAX_MESHES];
    for (u32 mi = 0; mi < mesh_count; mi++) {
        struct Mesh* m = &meshes[mi];
        u64 np = m->pos_count, nv = m->idx_count;
        M[mi].nv = nv; M[mi].ni = nv;
        float* fp = (float*)h->malloc(np * 12 + 4);
        float* nrm = (float*)h->malloc(np * 12 + 4);
        if (!fp || !nrm) return 0;
        get_frame(abc, m, 0, fp);
        calc_nrm(fp, m->idx_wide, nv, np, nrm);
        /* positions */
        while (bin.len & 3) if (!buf_u8(&bin, 0)) return 0;
        M[mi].off[0] = bin.len; M[mi].len[0] = nv * 12;
        for (u64 k = 0; k < nv; k++) {
            u32 p = m->idx_wide[k];
            for (int c = 0; c < 3; c++) {
                float f = fp[p * 3 + c];
                if (k == 0) { M[mi].mn[c] = f; M[mi].mx[c] = f; }
                else { if (f < M[mi].mn[c]) M[mi].mn[c] = f; if (f > M[mi].mx[c]) M[mi].mx[c] = f; }
                if (!buf_u32le(&bin, *(u32*)&f)) return 0;
            }
        }
        M[mi].off[1] = bin.len; M[mi].len[1] = nv * 12;
        for (u64 k = 0; k < nv; k++) {
            u32 p = m->idx_wide[k];
            for (int c = 0; c < 3; c++) { float f = nrm[p * 3 + c]; if (!buf_u32le(&bin, *(u32*)&f)) return 0; }
        }
        M[mi].off[2] = bin.len; M[mi].len[2] = nv * 8;
        for (u64 k = 0; k < nv; k++) {
            float u = 0, v = 0;
            u64 corner = m->src[k], ui = (u64)-1;
            if (m->uv) {
                if (m->uvi && corner < m->uvi_count) ui = rd_u32(m->uvi + 4 * corner);
                else if (!m->uvi && m->uv_count == m->ncorner) ui = corner;
                else if (!m->uvi && m->uv_count == np) ui = m->idx_wide[k];
                if (ui < m->uv_count) { u = rd_f32(m->uv + 8 * ui); v = 1.0f - rd_f32(m->uv + 8 * ui + 4); }
            }
            if (!buf_u32le(&bin, *(u32*)&u) || !buf_u32le(&bin, *(u32*)&v)) return 0;
        }
        M[mi].off[3] = bin.len; M[mi].len[3] = nv * 4;
        for (u64 k = 0; k < nv; k++) if (!buf_u32le(&bin, (u32)k)) return 0;
        h->free(fp); h->free(nrm);
    }

    struct Buf js = {0};
    js.h = h;
    if (!buf_str(&js, "{\"asset\":{\"version\":\"2.0\",\"generator\":\"SaikiMotion ABC Import\"},\"scene\":0,\"scenes\":[{\"nodes\":[")) return 0;
    for (u32 mi = 0; mi < mesh_count; mi++) { if (mi && !buf_u8(&js, ',')) return 0; if (!buf_int(&js, mi)) return 0; }
    if (!buf_str(&js, "]}],\"nodes\":[")) return 0;
    for (u32 mi = 0; mi < mesh_count; mi++) {
        if (mi && !buf_u8(&js, ',')) return 0;
        if (!buf_str(&js, "{\"mesh\":") || !buf_int(&js, mi) || !buf_str(&js, "}")) return 0;
    }
    if (!buf_str(&js, "],\"meshes\":[")) return 0;
    for (u32 mi = 0; mi < mesh_count; mi++) {
        if (mi && !buf_u8(&js, ',')) return 0;
        if (!buf_str(&js, "{\"primitives\":[{\"attributes\":{\"POSITION\":") || !buf_int(&js, mi * 4)
            || !buf_str(&js, ",\"NORMAL\":") || !buf_int(&js, mi * 4 + 1)
            || !buf_str(&js, ",\"TEXCOORD_0\":") || !buf_int(&js, mi * 4 + 2)
            || !buf_str(&js, "},\"indices\":") || !buf_int(&js, mi * 4 + 3)
            || !buf_str(&js, ",\"material\":0}]}")) return 0;
    }
    if (!buf_str(&js, "],\"materials\":[{\"doubleSided\":true,\"pbrMetallicRoughness\":{\"baseColorFactor\":[0.78,0.82,0.86,1],\"metallicFactor\":0,\"roughnessFactor\":0.55}}],\"accessors\":[")) return 0;
    for (u32 mi = 0; mi < mesh_count; mi++) {
        if (mi && !buf_u8(&js, ',')) return 0;
        i64 b = (i64)mi * 4;
        if (!buf_str(&js, "{\"bufferView\":") || !buf_int(&js, b)
           || !buf_str(&js, ",\"componentType\":5126,\"count\":") || !buf_int(&js, (i64)M[mi].nv)
           || !buf_str(&js, ",\"type\":\"VEC3\",\"min\":[")
           || !buf_float(&js, M[mi].mn[0]) || !buf_u8(&js, ',') || !buf_float(&js, M[mi].mn[1]) || !buf_u8(&js, ',') || !buf_float(&js, M[mi].mn[2])
           || !buf_str(&js, "],\"max\":[")
           || !buf_float(&js, M[mi].mx[0]) || !buf_u8(&js, ',') || !buf_float(&js, M[mi].mx[1]) || !buf_u8(&js, ',') || !buf_float(&js, M[mi].mx[2])
           || !buf_str(&js, "]},{\"bufferView\":") || !buf_int(&js, b + 1)
           || !buf_str(&js, ",\"componentType\":5126,\"count\":") || !buf_int(&js, (i64)M[mi].nv)
           || !buf_str(&js, ",\"type\":\"VEC3\"},{\"bufferView\":") || !buf_int(&js, b + 2)
           || !buf_str(&js, ",\"componentType\":5126,\"count\":") || !buf_int(&js, (i64)M[mi].nv)
           || !buf_str(&js, ",\"type\":\"VEC2\"},{\"bufferView\":") || !buf_int(&js, b + 3)
           || !buf_str(&js, ",\"componentType\":5125,\"count\":") || !buf_int(&js, (i64)M[mi].ni)
           || !buf_str(&js, ",\"type\":\"SCALAR\"}")) return 0;
    }
    if (!buf_str(&js, "],\"bufferViews\":[")) return 0;
    for (u32 mi = 0; mi < mesh_count; mi++) {
        for (int k = 0; k < 4; k++) {
            if ((mi || k) && !buf_u8(&js, ',')) return 0;
            if (!buf_str(&js, "{\"buffer\":0,\"byteOffset\":") || !buf_int(&js, (i64)M[mi].off[k])
               || !buf_str(&js, ",\"byteLength\":") || !buf_int(&js, (i64)M[mi].len[k])
               || !buf_str(&js, k == 3 ? ",\"target\":34963}" : ",\"target\":34962}")) return 0;
        }
    }
    if (!buf_str(&js, "],\"buffers\":[{\"byteLength\":") || !buf_int(&js, (i64)bin.len) || !buf_str(&js, "}]}")) return 0;

    while (js.len & 3) if (!buf_u8(&js, ' ')) return 0;
    while (bin.len & 3) if (!buf_u8(&bin, 0)) return 0;
    u64 total = 12 + 8 + js.len + 8 + bin.len;
    if (!buf_u32le(out, 0x46546C67) || !buf_u32le(out, 2) || !buf_u32le(out, (u32)total)
        || !buf_u32le(out, (u32)js.len) || !buf_u32le(out, 0x4E4F534A) || !buf_bytes(out, js.data, js.len)
        || !buf_u32le(out, (u32)bin.len) || !buf_u32le(out, 0x004E4942) || !buf_bytes(out, bin.data, bin.len)) return 0;
    if (js.data) h->free(js.data);
    if (bin.data) h->free(bin.data);
    return 1;
}

/* Sidecar "<glb>.anim": magic 'SABA', nframes, fps, nmesh, per-mesh vertex count, then per frame and
 * per mesh: positions (nv*3 f32) + normals (nv*3 f32), all in the unrolled glb vertex order. */
static void write_anim(struct Abc* abc, u64 root, struct Mesh* meshes, u32 mc, struct Host* h, const char* path) {
    u64 ns = 1, per = 0;
    for (u32 i = 0; i < mc; i++) { if (meshes[i].nsamples > ns) ns = meshes[i].nsamples; per += meshes[i].idx_count * 24; }
    if (ns < 2 || per == 0) return;
    u64 stride = 1, budget = 300ull << 20;
    while ((ns / stride) * per > budget) stride++;
    u64 nf = (ns + stride - 1) / stride;
    float fps = ts_fps(abc, root, meshes[0].tsidx) / (float)stride;
    void* f = h->fopen(path, "wb");
    if (!f) return;
    b32 ok = fw_u32(h, f, 0x41424153) && fw_u32(h, f, (u32)nf) && h->fwrite(&fps, 1, 4, f) == 4 && fw_u32(h, f, mc);
    for (u32 i = 0; ok && i < mc; i++) ok = fw_u32(h, f, (u32)meshes[i].idx_count);
    for (u64 fr = 0; ok && fr < nf; fr++) {
        for (u32 mi = 0; ok && mi < mc; mi++) {
            struct Mesh* m = &meshes[mi];
            u64 np = m->pos_count, nv = m->idx_count;
            float* fp = (float*)h->malloc(np * 12 + 4); float* nrm = (float*)h->malloc(np * 12 + 4);
            float* op = (float*)h->malloc(nv * 12 + 4); float* on = (float*)h->malloc(nv * 12 + 4);
            if (!fp || !nrm || !op || !on) ok = 0;
            else {
                get_frame(abc, m, fr * stride, fp);
                calc_nrm(fp, m->idx_wide, nv, np, nrm);
                for (u64 k = 0; k < nv; k++) {
                    u32 p = m->idx_wide[k];
                    op[k*3] = fp[p*3]; op[k*3+1] = fp[p*3+1]; op[k*3+2] = fp[p*3+2];
                    on[k*3] = nrm[p*3]; on[k*3+1] = nrm[p*3+1]; on[k*3+2] = nrm[p*3+2];
                }
                ok = h->fwrite(op, 4, nv * 3, f) == nv * 3 && h->fwrite(on, 4, nv * 3, f) == nv * 3;
            }
            if (fp) { h->free(fp); } if (nrm) { h->free(nrm); } if (op) { h->free(op); } if (on) { h->free(on); }
        }
    }
    h->fclose(f);
}

int abc_hook(unsigned char* path, unsigned long path_len, struct Host* host) {
    if (path_len < 5) return 0;
    /* must end with .abc (case-insensitive) */
    u8* tail = path + path_len - 4;
    if (!((tail[0] == '.') && ((tail[1] == 'a' || tail[1] == 'A'))
          && ((tail[2] == 'b' || tail[2] == 'B')) && ((tail[3] == 'c' || tail[3] == 'C'))))
        return 0;

    /* read the file */
    void* f = host->fopen((const char*)path, "rb");
    if (!f) return 0;
    u64 cap = 1 << 20;
    u8* data = (u8*)host->malloc(cap);
    if (!data) { host->fclose(f); return 0; }
    u64 len = 0;
    for (;;) {
        if (len == cap) {
            u64 nc = cap * 2;
            u8* nd = (u8*)host->malloc(nc);
            if (!nd) { host->free(data); host->fclose(f); return 0; }
            for (u64 i = 0; i < len; i++) nd[i] = data[i];
            host->free(data);
            data = nd;
            cap = nc;
        }
        unsigned long got = host->fread(data + len, 1, (unsigned long)(cap - len), f);
        if (got == 0) break;
        len += got;
    }
    host->fclose(f);
    if (len < 32 || len > (700u << 20)) { host->free(data); return 0; }

    /* Ogawa magic */
    if (!(data[0] == 'O' && data[1] == 'g' && data[2] == 'a' && data[3] == 'w' && data[4] == 'a')) {
        host->free(data);
        return 0;
    }

    struct Abc abc;
    abc.d = data;
    abc.n = len;
    u64 root = rd_u64(data + 8);
    if (root + 8 > len || root < 16) { host->free(data); return 0; }

    /* root child 2 = top object data */
    u64 topoff, topsz;
    if (og_child(&abc, root, 2, &topoff, &topsz) != 1) { host->free(data); return 0; }

    struct Mesh meshes[MAX_MESHES];
    u32 mesh_count = 0;
    walk_objects(&abc, topoff, meshes, &mesh_count, host, 0);
    if (mesh_count == 0) { host->free(data); return 0; }

    /* build GLB */
    struct Buf glb = {0};
    glb.h = host;
    if (!build_glb(&glb, meshes, mesh_count, host, &abc)) {
        if (glb.data) host->free(glb.data);
        for (u32 i = 0; i < mesh_count; i++) { host->free(meshes[i].idx_wide); host->free(meshes[i].src); }
        host->free(data);
        return 0;
    }

    /* write <path minus .abc> + .glb */
    tail[1] = 'g'; tail[2] = 'l'; tail[3] = 'b';
    void* wf = host->fopen((const char*)path, "wb");
    if (!wf) {
        host->free(glb.data);
        for (u32 i = 0; i < mesh_count; i++) { host->free(meshes[i].idx_wide); host->free(meshes[i].src); }
        host->free(data);
        return 0;
    }
    unsigned long wrote = host->fwrite(glb.data, 1, (unsigned long)glb.len, wf);
    host->fclose(wf);
    host->free(glb.data);
    { char ap[1200]; u64 n2 = path_len; if (n2 < 1190) { for (u64 q = 0; q < n2; q++) ap[q] = (char)path[q]; const char* sx = ".anim"; for (int q = 0; q < 6; q++) ap[n2 + q] = sx[q]; write_anim(&abc, root, meshes, mesh_count, host, ap); } }
    for (u32 i = 0; i < mesh_count; i++) { host->free(meshes[i].idx_wide); host->free(meshes[i].src); }
    host->free(data);
    return wrote == glb.len ? 1 : 0;
}
