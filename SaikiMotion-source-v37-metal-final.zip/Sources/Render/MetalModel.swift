import Foundation
import Metal
import UIKit
import OpenGLES

//  Stage 6b: GLB / glTF / OBJ / animated-ABC models in Metal (port of GlbModel.draw + the GL PBR shader).
//  GlbModel is loaded with cpuOnly = true (no GL calls); this file uploads its CPU data to Metal.
//  VDB volumes stay in GL.

enum MetalModelSL {
    /// Port of GlbModel.vertexSource / fragmentSource. Clip z is remapped from the GL range [-w, w]
    /// to Metal's [0, w]. Vertices are read from a plain float buffer (12 floats per vertex).
    static let source = MetalSL.header + """
struct ModelU {
    float4 vp0; float4 vp1; float4 vp2; float4 vp3;     // uVP columns
    float4 m0; float4 m1; float4 m2; float4 m3;         // uModel columns
    float4 color;     // uColor
    float4 emis;      // uEmis.xyz
    float4 eye;       // uEye.xyz
    float4 prm;       // metal, rough, cutoff, unlit
    float4 has;       // base, metal-rough, emissive, occlusion texture present
    float4 opt;       // env, metallic reflectivity, view mode, ao strength
};
struct MOut { float4 pos [[position]]; float psize [[point_size]]; float3 n; float3 w; float2 uv; float4 col; };

vertex MOut modelVertex(uint vid [[vertex_id]], constant ModelU& u [[buffer(0)]],
                        const device float* vb [[buffer(1)]]) {
    uint b = vid * 12u;
    float3 aPos = float3(vb[b], vb[b + 1u], vb[b + 2u]);
    float3 aNormal = float3(vb[b + 3u], vb[b + 4u], vb[b + 5u]);
    float2 aUv = float2(vb[b + 6u], vb[b + 7u]);
    float4 aCol = float4(vb[b + 8u], vb[b + 9u], vb[b + 10u], vb[b + 11u]);
    float4 wp = u.m0 * aPos.x + u.m1 * aPos.y + u.m2 * aPos.z + u.m3;
    float4 c = u.vp0 * wp.x + u.vp1 * wp.y + u.vp2 * wp.z + u.vp3 * wp.w;
    c.z = (c.z + c.w) * 0.5;
    MOut o;
    o.pos = c;
    o.psize = 3.0;
    o.w = wp.xyz;
    float3 n = u.m0.xyz * aNormal.x + u.m1.xyz * aNormal.y + u.m2.xyz * aNormal.z;
    o.n = dot(n, n) > 1e-8 ? normalize(n) : float3(0.0, 1.0, 0.0);
    o.uv = aUv;
    o.col = aCol;
    return o;
}

constant float mPI = 3.14159265;
constant float3 mL1 = float3(0.4170, 0.6672, 0.6672);
constant float3 mL2 = float3(-0.8704, 0.2176, 0.4352);

inline float3 mEnv(float3 d, float r) {
    float h = d.y * 0.5 + 0.5;
    float3 c = mix(float3(0.14, 0.13, 0.15), float3(0.78, 0.80, 0.84), smoothstep(0.0, 0.5, h));
    c = mix(c, float3(0.55, 0.68, 0.95), smoothstep(0.5, 1.0, h));
    float sun = pow(max(dot(d, mL1), 0.0), mix(150.0, 5.0, r)) * mix(8.0, 0.6, r);
    return c + float3(1.0, 0.93, 0.82) * sun;
}

inline float3 mBrdf(float3 N, float3 V, float3 L, float3 diffC, float3 F0, float r) {
    float3 H = normalize(V + L);
    float NdL = max(dot(N, L), 0.0);
    float NdV = max(dot(N, V), 0.001);
    float NdH = max(dot(N, H), 0.0);
    float VdH = max(dot(V, H), 0.0);
    float a = r * r;
    float a2 = a * a;
    float dd = NdH * NdH * (a2 - 1.0) + 1.0;
    float D = a2 / (mPI * dd * dd + 0.0001);
    float k = (r + 1.0) * (r + 1.0) / 8.0;
    float G = (NdL / (NdL * (1.0 - k) + k)) * (NdV / (NdV * (1.0 - k) + k));
    float3 F = F0 + (1.0 - F0) * pow(1.0 - VdH, 5.0);
    float3 spec = D * G * F / max(4.0 * NdV * NdL, 0.001);
    return ((1.0 - F) * diffC / mPI + spec) * NdL;
}

fragment float4 modelFragment(MOut in [[stage_in]], constant ModelU& u [[buffer(0)]],
                              texture2d<float> tBase [[texture(0)]], texture2d<float> tMR [[texture(1)]],
                              texture2d<float> tEm [[texture(2)]], texture2d<float> tOcc [[texture(3)]],
                              sampler sBase [[sampler(0)]], sampler sMR [[sampler(1)]],
                              sampler sEm [[sampler(2)]], sampler sOcc [[sampler(3)]]) {
    float a = u.color.a * in.col.a;
    float3 tint = u.color.rgb * pow(max(in.col.rgb, float3(0.0)), float3(2.2));
    float3 alb = tint;
    if (u.has.x > 0.5) {
        float4 t = tBase.sample(sBase, in.uv);
        a *= t.a;
        alb *= pow(clamp(t.rgb / max(t.a, 0.001), 0.0, 1.0), float3(2.2));
    }
    if (u.prm.z >= 0.0) {
        if (a < u.prm.z) { discard_fragment(); }
        a = 1.0;
    }
    float metal = u.prm.x * u.opt.y;
    float rough = u.prm.y;
    float ao = 1.0;
    if (u.has.w > 0.5) { ao = mix(1.0, tOcc.sample(sOcc, in.uv).r, u.opt.w); }
    if (u.has.y > 0.5) {
        float4 m = tMR.sample(sMR, in.uv);
        rough *= m.g;
        metal *= m.b * u.opt.y;
    }
    rough = clamp(rough, 0.04, 1.0);
    metal = clamp(metal, 0.0, 1.0);

    float3 N = normalize(in.n);
    float3 V = normalize(u.eye.xyz - in.w);
    if (dot(N, V) < 0.0) { N = -N; }
    float NdV = max(dot(N, V), 0.001);

    float3 F0 = mix(float3(0.04), alb, metal);
    float3 diffC = alb * (1.0 - metal);
    float3 col = mBrdf(N, V, mL1, diffC, F0, rough) * float3(3.2, 3.0, 2.8) * 1.0
               + mBrdf(N, V, mL2, diffC, F0, rough) * float3(0.9, 1.0, 1.3);
    float3 R = reflect(-V, N);
    float3 Fr = F0 + (max(float3(1.0 - rough), F0) - F0) * pow(1.0 - NdV, 5.0);
    if (u.opt.x > 0.5) {
        col += diffC * mEnv(N, 1.0) * 0.8 * ao;
        col += mEnv(R, rough) * Fr * (1.0 - 0.5 * rough) * ao;
    } else {
        col += diffC * 0.3 * ao;
    }
    float3 em = u.emis.xyz;
    if (u.has.z > 0.5) { em *= pow(tEm.sample(sEm, in.uv).rgb, float3(2.2)); }
    col += em;
    col = mix(col, alb + em, u.prm.w);
    if (u.opt.z > 0.5) {
        float3 v = alb;
        if (u.opt.z > 1.5) { v = float3(rough); }
        if (u.opt.z > 2.5) { v = float3(metal); }
        if (u.opt.z > 3.5) { v = float3(ao); }
        if (u.opt.z > 4.5) { v = em; }
        return float4(pow(max(v, float3(0.0)), float3(1.0 / 2.2)) * a, a);
    }
    col = col * (1.0 + col / 6.0) / (1.0 + col);
    col = pow(max(col, float3(0.0)), float3(1.0 / 2.2));
    return float4(col * a, a);
}
"""
}

/// Must match ModelU in MSL (14 x float4 = 224 bytes).
struct ModelU {
    var vp0 = SIMD4<Float>(0, 0, 0, 0), vp1 = SIMD4<Float>(0, 0, 0, 0)
    var vp2 = SIMD4<Float>(0, 0, 0, 0), vp3 = SIMD4<Float>(0, 0, 0, 0)
    var m0 = SIMD4<Float>(0, 0, 0, 0), m1 = SIMD4<Float>(0, 0, 0, 0)
    var m2 = SIMD4<Float>(0, 0, 0, 0), m3 = SIMD4<Float>(0, 0, 0, 0)
    var color = SIMD4<Float>(1, 1, 1, 1)
    var emis = SIMD4<Float>(0, 0, 0, 0)
    var eye = SIMD4<Float>(0, 0, 3, 0)
    var prm = SIMD4<Float>(0, 0.8, -1, 0)
    var has = SIMD4<Float>(0, 0, 0, 0)
    var opt = SIMD4<Float>(1, 1, 0, 1)
}

/// GPU copy of one GlbModel (loaded with GlbModel.cpuOnly).
final class MetalModel {
    struct P {
        var vbuf: MTLBuffer?
        var ibuf: MTLBuffer
        var count: Int
        var idx32: Bool
        var points: Bool
        var srcIndex: Int            // index into src.prims
        var tex: [MTLTexture?]       // base, metal-rough, emissive, occlusion
        var clamp: [Bool]
    }
    let src: GlbModel
    private(set) var prims: [P] = []

    init?(_ src: GlbModel, core: MetalCore) {
        self.src = src
        var texById: [UInt32: MTLTexture] = [:]
        var used: [UInt32] = []
        func tex(_ id: UInt32) -> (MTLTexture?, Bool) {
            guard id != 0, let e = GlbModel.cpuImages[id] else { return (nil, false) }
            used.append(id)
            if let t = texById[id] { return (t, e.clamp) }
            guard let t = MetalModel.makeTexture(core, e.img) else { return (nil, e.clamp) }
            texById[id] = t
            return (t, e.clamp)
        }
        for (si, sp) in src.prims.enumerated() {
            guard !sp.verts.isEmpty, !sp.cpuIdx.isEmpty else { continue }
            let idx32 = sp.indexType != GLenum(GL_UNSIGNED_SHORT)
            let ib: MTLBuffer?
            if idx32 {
                ib = sp.cpuIdx.withUnsafeBytes { core.device.makeBuffer(bytes: $0.baseAddress!, length: $0.count, options: .storageModeShared) }
            } else {
                let small = sp.cpuIdx.map { UInt16(truncatingIfNeeded: $0) }
                ib = small.withUnsafeBytes { core.device.makeBuffer(bytes: $0.baseAddress!, length: $0.count, options: .storageModeShared) }
            }
            guard let ibuf = ib else { continue }
            let t0 = tex(UInt32(sp.texBase)), t1 = tex(UInt32(sp.texMR)), t2 = tex(UInt32(sp.texEm)), t3 = tex(UInt32(sp.texOcc))
            prims.append(P(vbuf: nil, ibuf: ibuf, count: sp.cpuIdx.count, idx32: idx32,
                           points: sp.mode == GLenum(GL_POINTS), srcIndex: si,
                           tex: [t0.0, t1.0, t2.0, t3.0], clamp: [t0.1, t1.1, t2.1, t3.1]))
        }
        for id in used { GlbModel.cpuImages[id] = nil }       // CPU copies are no longer needed
        if prims.isEmpty { return nil }
    }

    /// RGBA8 premultiplied texture with a mip chain (GL generated mipmaps on ES3).
    static func makeTexture(_ core: MetalCore, _ image: UIImage) -> MTLTexture? {
        guard let cg = image.cgImage, cg.width > 0, cg.height > 0 else { return nil }
        let sc = min(1.0, 2048.0 / Double(max(cg.width, cg.height)))
        let w = max(1, Int(Double(cg.width) * sc)), h = max(1, Int(Double(cg.height) * sc))
        var data = [UInt8](repeating: 0, count: w * h * 4)
        let drew: Bool = data.withUnsafeMutableBytes { raw -> Bool in
            guard let ctx = CGContext(data: raw.baseAddress, width: w, height: h, bitsPerComponent: 8,
                                      bytesPerRow: w * 4, space: CGColorSpaceCreateDeviceRGB(),
                                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            ctx.setBlendMode(.copy)
            ctx.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h))
            return true
        }
        guard drew else { return nil }
        let d = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .rgba8Unorm, width: w, height: h, mipmapped: true)
        d.usage = .shaderRead
        d.storageMode = .shared
        guard let t = core.device.makeTexture(descriptor: d) else { return nil }
        data.withUnsafeBytes {
            t.replace(region: MTLRegionMake2D(0, 0, w, h), mipmapLevel: 0, withBytes: $0.baseAddress!, bytesPerRow: w * 4)
        }
        if t.mipmapLevelCount > 1, let cbuf = core.queue.makeCommandBuffer(), let blit = cbuf.makeBlitCommandEncoder() {
            blit.generateMipmaps(for: t)
            blit.endEncoding()
            cbuf.commit()
        }
        return t
    }
}

/// Draws model layers into a layer target with a shared depth buffer (GL drawModelLayer).
final class MetalModelRenderer {
    private let core: MetalCore
    private var lib: MTLLibrary?
    private var psos: [String: MTLRenderPipelineState] = [:]
    private var dsWrite: MTLDepthStencilState?
    private var dsNoWrite: MTLDepthStencilState?
    private var smpRepeat: MTLSamplerState?
    private var smpClamp: MTLSamplerState?
    private var dummy: MTLTexture?
    private var depthTex: MTLTexture?
    private var cache: [String: MetalModel] = [:]
    private var failed = Set<String>()
    /// Cleared at frame start and per motion-blur sample: the next model draw clears the depth buffer.
    var depthDirty = true

    init(_ core: MetalCore) {
        self.core = core
        lib = try? core.device.makeLibrary(source: MetalModelSL.source, options: nil)
        let dw = MTLDepthStencilDescriptor()
        dw.depthCompareFunction = .lessEqual; dw.isDepthWriteEnabled = true
        dsWrite = core.device.makeDepthStencilState(descriptor: dw)
        let dn = MTLDepthStencilDescriptor()
        dn.depthCompareFunction = .lessEqual; dn.isDepthWriteEnabled = false
        dsNoWrite = core.device.makeDepthStencilState(descriptor: dn)
        func sampler(_ clamp: Bool) -> MTLSamplerState? {
            let d = MTLSamplerDescriptor()
            d.minFilter = .linear; d.magFilter = .linear; d.mipFilter = .linear
            d.sAddressMode = clamp ? .clampToEdge : .repeat
            d.tAddressMode = clamp ? .clampToEdge : .repeat
            d.maxAnisotropy = 4
            return core.device.makeSamplerState(descriptor: d)
        }
        smpRepeat = sampler(false); smpClamp = sampler(true)
        let td = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .rgba8Unorm, width: 1, height: 1, mipmapped: false)
        td.usage = .shaderRead
        dummy = core.device.makeTexture(descriptor: td)
        var px: [UInt8] = [255, 255, 255, 255]
        dummy?.replace(region: MTLRegionMake2D(0, 0, 1, 1), mipmapLevel: 0, withBytes: &px, bytesPerRow: 4)
    }

    var ready: Bool { lib != nil && dsWrite != nil && dsNoWrite != nil && smpRepeat != nil && smpClamp != nil && dummy != nil }

    func trimMemory() { cache.removeAll(); depthTex = nil }

    /// The shared depth buffer when a model has drawn since the last clear (volume occlusion), else nil.
    func occlusionDepth() -> MTLTexture? { depthDirty ? nil : depthTex }

    private func loadModel(for path: String) -> MetalModel? {
        if let m = cache[path] { return m }
        if failed.contains(path) { return nil }
        let p = GlbModel.validate(path: path)
        GlbModel.cpuOnly = true
        defer { GlbModel.cpuOnly = false }
        guard let g = GlbModel.load(p), let m = MetalModel(g, core: core) else {
            failed.insert(path)
            return nil
        }
        cache[path] = m
        cache[p] = m
        return m
    }

    private func pso(blend: Bool, format: MTLPixelFormat) -> MTLRenderPipelineState? {
        let key = "\(blend)/\(format.rawValue)"
        if let p = psos[key] { return p }
        guard let lib = lib, let vf = lib.makeFunction(name: "modelVertex"),
              let ff = lib.makeFunction(name: "modelFragment") else { return nil }
        let d = MTLRenderPipelineDescriptor()
        d.vertexFunction = vf
        d.fragmentFunction = ff
        d.colorAttachments[0].pixelFormat = format
        d.depthAttachmentPixelFormat = .depth32Float
        if blend {
            let c = d.colorAttachments[0]!
            c.isBlendingEnabled = true
            c.sourceRGBBlendFactor = .one; c.destinationRGBBlendFactor = .oneMinusSourceAlpha
            c.sourceAlphaBlendFactor = .one; c.destinationAlphaBlendFactor = .oneMinusSourceAlpha
        }
        guard let p = try? core.device.makeRenderPipelineState(descriptor: d) else { return nil }
        psos[key] = p
        return p
    }

    private func depth(_ w: Int, _ h: Int) -> MTLTexture? {
        if let t = depthTex, t.width == w, t.height == h { return t }
        let d = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .depth32Float, width: w, height: h, mipmapped: false)
        d.usage = [.renderTarget, .shaderRead]
        d.storageMode = .private
        depthTex = core.device.makeTexture(descriptor: d)
        depthDirty = true
        return depthTex
    }

    /// Draws model layer `l` (glb / gltf / obj / abc) into `target` (which the caller has cleared).
    func draw(_ l: Layer, time: Float, fov: Float, into target: MetalTarget, cb: MTLCommandBuffer) {
        guard ready, let path = l.imagePath, let model = loadModel(for: path),
              let dtex = depth(target.width, target.height) else { return }
        model.src.setAnimTime(max(0, time - l.start))
        let vp = MetalCam.vpForModel(l, fov: fov, time: time, width: target.width, height: target.height)
        let mm = MetalCam.modelMatrix(l, time: time, normalize: model.src.normalize)
        let eye = GlbModel.eye(fromVP: vp)
        guard vp.count == 16, mm.count == 16 else { return }

        var base = ModelU()
        base.vp0 = SIMD4(vp[0], vp[1], vp[2], vp[3]); base.vp1 = SIMD4(vp[4], vp[5], vp[6], vp[7])
        base.vp2 = SIMD4(vp[8], vp[9], vp[10], vp[11]); base.vp3 = SIMD4(vp[12], vp[13], vp[14], vp[15])
        base.m0 = SIMD4(mm[0], mm[1], mm[2], mm[3]); base.m1 = SIMD4(mm[4], mm[5], mm[6], mm[7])
        base.m2 = SIMD4(mm[8], mm[9], mm[10], mm[11]); base.m3 = SIMD4(mm[12], mm[13], mm[14], mm[15])
        base.eye = SIMD4(eye[0], eye[1], eye[2], 0)
        base.opt = SIMD4(l.m3Env ? 1 : 0, l.m3Metal ? 1 : 0, Float(l.m3View), l.m3Ao ? 1 : 0)

        let pd = MTLRenderPassDescriptor()
        pd.colorAttachments[0].texture = target.tex
        pd.colorAttachments[0].loadAction = .load
        pd.colorAttachments[0].storeAction = .store
        pd.depthAttachment.texture = dtex
        pd.depthAttachment.loadAction = depthDirty ? .clear : .load
        pd.depthAttachment.clearDepth = 1
        pd.depthAttachment.storeAction = .store
        depthDirty = false
        guard let enc = cb.makeRenderCommandEncoder(descriptor: pd) else { return }
        enc.setCullMode(.none)

        let animated = model.src.isAnimated
        for (i, p) in model.prims.enumerated() where p.srcIndex < model.src.prims.count {
            let sp = model.src.prims[p.srcIndex]
            guard let ps = pso(blend: sp.blend, format: target.tex.pixelFormat) else { continue }
            // animated prims get a fresh vertex buffer per draw: several poses can be encoded in one frame
            var vbuf = p.vbuf
            if vbuf == nil || (animated && sp.slot >= 0) {
                vbuf = sp.verts.withUnsafeBytes { core.device.makeBuffer(bytes: $0.baseAddress!, length: $0.count, options: .storageModeShared) }
            }
            guard let vb = vbuf else { continue }
            if p.vbuf == nil && !(animated && sp.slot >= 0) { model.setVBuf(i, vb) }

            var u = base
            u.color = SIMD4(sp.color[0], sp.color[1], sp.color[2], sp.color[3])
            u.emis = SIMD4(sp.emissive[0], sp.emissive[1], sp.emissive[2], 0)
            u.prm = SIMD4(sp.metal, sp.rough, sp.cutoff, sp.unlit)
            u.has = SIMD4(p.tex[0] != nil ? 1 : 0, p.tex[1] != nil ? 1 : 0, p.tex[2] != nil ? 1 : 0, p.tex[3] != nil ? 1 : 0)
            enc.setRenderPipelineState(ps)
            enc.setDepthStencilState(sp.blend ? dsNoWrite : dsWrite)
            enc.setVertexBytes(&u, length: MemoryLayout<ModelU>.stride, index: 0)
            enc.setFragmentBytes(&u, length: MemoryLayout<ModelU>.stride, index: 0)
            enc.setVertexBuffer(vb, offset: 0, index: 1)
            for k in 0..<4 {
                enc.setFragmentTexture(p.tex[k] ?? dummy, index: k)
                enc.setFragmentSamplerState(p.clamp[k] ? smpClamp : smpRepeat, index: k)
            }
            enc.drawIndexedPrimitives(type: p.points ? .point : .triangle, indexCount: p.count,
                                      indexType: p.idx32 ? .uint32 : .uint16, indexBuffer: p.ibuf, indexBufferOffset: 0)
        }
        enc.endEncoding()
    }
}

extension MetalModel {
    /// Caches the static vertex buffer of prim `i`.
    func setVBuf(_ i: Int, _ b: MTLBuffer) {
        guard i < prims.count else { return }
        prims[i].vbuf = b
    }
}
