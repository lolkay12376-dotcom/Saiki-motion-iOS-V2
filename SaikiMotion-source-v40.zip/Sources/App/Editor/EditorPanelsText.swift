// EditorPanelsText.swift — property-panel framework + Media/Shapes/Edit/Text panels + the color rows.

import UIKit
import UniformTypeIdentifiers
import PhotosUI

extension EditorViewController {
    /// Sweep-gradient circle that opens the full color picker (Android GradientDrawable SWEEP_GRADIENT).
    private final class RainbowCircleView: TapView {
        override func draw(_ rect: CGRect) {
            guard let c = UIGraphicsGetCurrentContext() else { return }
            let r = min(bounds.width, bounds.height) / 2 - 1
            c.saveGState()
            c.translateBy(x: bounds.width / 2, y: bounds.height / 2)
            let n = 36
            for i in 0..<n {
                let a0 = CGFloat(i) / CGFloat(n) * 2 * .pi
                let a1 = CGFloat(i + 1) / CGFloat(n) * 2 * .pi
                c.setFillColor(UIColor(hue: CGFloat(i) / CGFloat(n), saturation: 1, brightness: 1, alpha: 1).cgColor)
                c.move(to: .zero)
                c.addArc(center: .zero, radius: r, startAngle: a0, endAngle: a1, clockwise: false)
                c.closePath()
                c.fillPath()
            }
            c.restoreGState()
        }
    }


        // ================================================================ panels

        func refreshPanel() {
            panelList.arrangedSubviews.forEach { $0.removeFromSuperview() }
            rows.removeAll()
            if panel == P_NONE { return }
            if panel == P_MEDIA { buildMedia() }
            else if panel == P_SHAPES { buildShapes() }
            else {
                guard let l = selected() else { closePanel(); return }
                switch panel {
                case P_EDIT: buildEdit(l)
                case P_XFORM: buildXform(l)
                case P_FX: buildFx(l)
                case P_BLEND: buildBlend(l)
                case P_SPEED: buildSpeed(l)
                case P_GRAPH: buildGraph(l)
                case P_PUPPET: buildPuppet(l)
                case P_RIGANIM: buildRigAnim(l)
                default: break
                }
            }
            syncRows()
        }

        func addRow(_ parent: UIStackView, _ l: Layer, _ d: PropDef, _ label: String? = nil) {
            if d.options != nil { addOptionRow(parent, l, d); return }
            let tr = l.track(d.key)
            let s = RulerSlider(frame: .zero)
            s.label = label ?? d.label
            s.lo = d.min; s.hi = d.max; s.dec = d.dec
            s.infinite = d.inf
            s.span = d.span > 0 ? d.span : 1
            s.onExprIcon = { [weak self] in self?.showExpression(l, d) }
            s.value = tr.eval(l.editTime(d.key, Editor.time))
            s.onBegin = { [weak self] in
                guard let self = self else { return }
                self.pushUndo()
                self.selKey = d.key
                self.syncRows(s)
            }
            s.onChange = { [weak self] v in
                guard let self = self else { return }
                if d.key == "anchorX" || d.key == "anchorY" {
                    // move only the pivot: shift x/y so the media stays put
                    let t = l.editTime("anchorX", Editor.time)
                    let ax = d.key == "anchorX" ? v : l.p("anchorX", t)
                    let ay = d.key == "anchorY" ? v : l.p("anchorY", t)
                    self.setAnchorKeepVisual(l, ax, ay)
                } else {
                    tr.set(l.editTime(d.key, Editor.time), v, self.autoKeyOn)
                }
                self.syncRows(s)
                self.render()
            }
            s.onLabelTap = { [weak self] in
                guard let self = self else { return }
                self.selKey = d.key
                self.syncRows()
                // tapping a parameter name opens its graph
                if tr.keys.count >= 2 {
                    self.graphProp = d.key; self.graphKey = 0
                    self.openPanel(P_GRAPH)
                } else {
                    self.toast("Add 2 keyframes to \(d.label) to edit its graph")
                }
            }
            s.onLabelLong = { [weak self] in self?.showExpression(l, d) }
            put(parent, s, 60)
            rows.append(Row(s, d, l))
        }

        func addOptionRow(_ parent: UIStackView, _ l: Layer, _ d: PropDef) {
            let tr = l.track(d.key)
            let opts = d.options ?? []
            if opts.count == 2 {
                let sw = SwitchRow()
                sw.label = d.label
                sw.on = tr.base >= 0.5
                sw.captionOff = opts[0]; sw.captionOn = opts[1]
                sw.onToggle = { [weak self] v in
                    guard let self = self else { return }
                    self.pushUndo()
                    tr.set(l.editTime(d.key, Editor.time), v ? 1 : 0, self.autoKeyOn)
                    self.render()
                }
                put(parent, sw, 52)
                return
            }
            text(parent, d.label, C.TEXT, 14, true)
            parent.addArrangedSubview(chipRow(opts, ktInt(tr.base)) { [weak self] i in
                guard let self = self else { return }
                self.pushUndo()
                tr.set(l.editTime(d.key, Editor.time), Float(i), self.autoKeyOn)
                self.refreshPanel()
                self.render()
            })
        }

        /// Numeric parameter that owns a keyframe track (key = unique id), shown as a normal row.
        func addKeyedRow(_ parent: UIStackView, _ l: Layer, _ key: String, _ label: String,
                         _ lo: Float, _ hi: Float, _ def: Float, _ dec: Int, _ stored: Float) {
            let d = PropDef(key, label, lo, hi, def, dec)
            Registry.dyn[key] = d
            if l.props[key] == nil { l.props[key] = Track(stored) }
            addRow(parent, l, d)
        }

        /// Colour with a keyframe button: tap it to key the colour at the playhead.
        func addKeyedColor(_ parent: UIStackView, _ l: Layer, _ name: String, _ field: Int32,
                           _ set: @escaping (Int32) -> Void) {
            let base = "tc_" + name
            let sfx = ["_r", "_g", "_b", "_a"]
            let animated = sfx.contains { !(l.props[base + $0]?.keys.isEmpty ?? true) }
            let cur = TextRaster.col(l, name, field, Editor.time)
            func write(_ c: Int32, key: Bool) {
                let vals: [Float] = [Float(colorRed(c)), Float(colorGreen(c)), Float(colorBlue(c)), Float(colorAlpha(c))].map { $0 / 255 }
                for (i, sf) in sfx.enumerated() {
                    let tr = l.track(base + sf)
                    if key {
                        let tt = Editor.time
                        if tr.keyAt(tt) == nil { tr.toggleKey(tt) }
                        tr.set(tt, vals[i], true)
                    } else {
                        tr.base = vals[i]
                    }
                }
            }
            addColorRow(parent, cur) { [weak self] c in
                guard let self = self else { return }
                self.pushUndo()
                set(c)
                if l.props[base + "_r"] != nil { write(c, key: animated) }
                self.render()
            }
            put(parent, pill(animated ? "Key color here (\(name))" : "Keyframe this color", "diamond") { [weak self] in
                guard let self = self else { return }
                self.pushUndo()
                write(cur, key: true)
                set(cur)
                self.refreshPanel(); self.render()
            }, 38)
            if animated {
                put(parent, pill("Remove color keyframes", "close") { [weak self] in
                    guard let self = self else { return }
                    self.pushUndo()
                    for sf in sfx { l.props.removeValue(forKey: base + sf) }
                    set(cur)
                    self.refreshPanel(); self.render()
                }, 38)
            }
        }

        func addPlain(_ parent: UIStackView, _ label: String, _ lo: Float, _ hi: Float, _ v: Float,
                              _ dec: Int, _ onChange: @escaping (Float) -> Void) {
            let s = RulerSlider(frame: .zero)
            s.label = label; s.lo = lo; s.hi = hi; s.value = v; s.dec = dec; s.canKey = false
            s.onBegin = { [weak self] in self?.pushUndo() }
            s.onChange = onChange
            put(parent, s, 60)
        }

        func syncRows(_ except: RulerSlider? = nil) {
            for r in rows {
                let tr = r.layer.track(r.d.key)
                let t = r.layer.editTime(r.d.key, Editor.time)
                if r.slider !== except { r.slider.value = tr.eval(t) }
                r.slider.hasKey = tr.keyAt(t) != nil
                r.slider.hasAnim = !tr.keys.isEmpty
                r.slider.hasExpr = tr.exprActive()
                r.slider.rowSelected = r.d.key == selKey
                r.slider.setNeedsDisplay()
            }
            diamondSide.set("diamond_f",
                            rows.contains(where: { $0.d.key == selKey && $0.slider.hasKey }) ? C.GREEN
                            : (rows.contains(where: { $0.d.key == selKey }) ? C.TEXT : C.DIM))
        }

        /** Adds or removes a keyframe on the parameter that was tapped last. */
        func keySelected() {
            guard let r = rows.first(where: { $0.d.key == selKey }) else {
                toast("Tap a parameter first, then tap the keyframe button")
                return
            }
            pushUndo()
            r.layer.track(r.d.key).toggleKey(r.layer.editTime(r.d.key, Editor.time))
            syncRows(); render()
        }

        /** Full color picker: saturation, hue, opacity, hex and an eyedropper that samples the preview. */
        func showColorPicker(_ initial: Int32, _ onPick: @escaping (Int32) -> Void) {
            let box = vStack()
            box.isLayoutMarginsRelativeArrangement = true
            box.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 4, leading: 4, bottom: 4, trailing: 4)
            let cp = ColorPickerView(frame: .zero)
            cp.setColor(initial)
            put(box, cp, 250, 0, 0)
            let row = hRow()
            row.isLayoutMarginsRelativeArrangement = true
            row.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 10, leading: 0, bottom: 6, trailing: 0)
            let hex = makeField("")
            hex.font = monoFont(14)
            hex.text = String(format: "%08X", UInt32(bitPattern: initial))
            hex.placeholder = "#RRGGBB"
            let sw = UIView()
            sw.backgroundColor = argbToUIColor(initial)
            var lock = false
            cp.onChange = { c in
                sw.backgroundColor = argbToUIColor(c)
                lock = true
                hex.text = String(format: "%08X", UInt32(bitPattern: c))
                lock = false
                onPick(c)
            }
            bind(hex) { s in
                if lock { return }
                var t = s.trimmingCharacters(in: .whitespaces)
                if t.hasPrefix("#") { t.removeFirst() }
                var v: Int32? = nil
                if t.count == 6, let u = UInt64(t, radix: 16) {
                    v = Int32(bitPattern: UInt32(0xFF000000) | UInt32(u))
                } else if t.count == 8, let u = UInt64(t, radix: 16) {
                    v = Int32(bitPattern: UInt32(u))
                }
                if let v = v {
                    cp.setColor(v)
                    sw.backgroundColor = argbToUIColor(v)
                    onPick(v)
                }
            }
            row.addArrangedSubview(wrap(hex, 0, 40, 0, 0, 0, 0))
            row.addArrangedSubview(wrap(sw, 52, 40, 0, 0, 0, 0))
            box.addArrangedSubview(row)
            var ref: Dlg? = nil
            put(box, pill("Pen: pick a color from the preview", "pipette") { [weak self] in
                ref?.dismiss()
                self?.startEyedropper { c in
                    self?.showColorPicker(c, onPick)
                    onPick(c)
                }
            }, 44, 6, 6)
            pushUndo()
            ref = Dlg(self).setTitle("Color").setView(box).setPositiveButton("Done") { [weak self] _, _ in
                // never leave the eyedropper armed after the dialog is gone —
                // it used to hijack the next preview tap
                self?.overlay.pick = nil
            }.show()
        }

        func startEyedropper(_ cb: @escaping (Int32) -> Void) {
            toast("Tap the preview to pick a color")
            overlay.pick = { [weak self] x, y in
                guard let self = self else { return }
                self.overlay.pick = nil   // one shot
                let w = Int(self.preview.bounds.width)
                let h = Int(self.preview.bounds.height)
                guard w > 0, h > 0 else { return }
                // PORT NOTE: PixelCopy.request → drawHierarchy snapshot read through a 1x1 context.
                let fmt = UIGraphicsImageRendererFormat()
                fmt.scale = 1
                let r = UIGraphicsImageRenderer(size: CGSize(width: w, height: h), format: fmt)
                let img = r.image { _ in self.preview.drawHierarchy(in: self.preview.bounds, afterScreenUpdates: false) }
                guard img.cgImage != nil else { self.toast("Could not read the preview"); return }
                let px = UnsafeMutablePointer<UInt8>.allocate(capacity: 4)
                px.initialize(repeating: 0, count: 4)
                defer { px.deallocate() }
                if let ctx = CGContext(data: px, width: 1, height: 1, bitsPerComponent: 8, bytesPerRow: 4,
                                       space: CGColorSpaceCreateDeviceRGB(),
                                       bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) {
                    ctx.interpolationQuality = .none
                    let ix = clamp(Int(x), 0, w - 1)
                    let iy = clamp(Int(y), 0, h - 1)
                    UIGraphicsPushContext(ctx)
                    img.draw(in: CGRect(x: -CGFloat(ix), y: -CGFloat(iy), width: CGFloat(w), height: CGFloat(h)))
                    UIGraphicsPopContext()
                    cb(argbColor(255, Int(px[0]), Int(px[1]), Int(px[2])))
                } else {
                    self.toast("Eyedropper is not available here")
                }
            }
            // and a timeout: if the user never taps the preview, stand down
            DispatchQueue.main.asyncAfter(deadline: .now() + 10) { [weak self] in
                self?.overlay.pick = nil
            }
        }

        func colorRow(_ cur: Int32, _ onPick: @escaping (Int32) -> Void) -> UIView {
            let colors: [Int32] = [Int32(bitPattern: 0xFFFFFFFF), Int32(bitPattern: 0xFF000000),
                                   Int32(bitPattern: 0xFFF44336), Int32(bitPattern: 0xFFFF9800),
                                   Int32(bitPattern: 0xFFFFEB3B), Int32(bitPattern: 0xFF22C55E),
                                   Int32(bitPattern: 0xFF00E5FF), Int32(bitPattern: 0xFF2979FF),
                                   Int32(bitPattern: 0xFF7C4DFF), Int32(bitPattern: 0xFFFF4081)]
            let row = hRow()
            let now = TapView()
            now.backgroundColor = argbToUIColor(cur)
            now.onClick = { [weak self] in self?.showColorPicker(cur, onPick) }
            row.addArrangedSubview(wrap(now, 44, 36, 4, 6, 10, 6))
            for col in colors {
                let v = TapView()
                v.backgroundColor = argbToUIColor(col)
                v.onClick = { onPick(col) }
                row.addArrangedSubview(wrap(v, 32, 32, 3, 6, 3, 6))
            }
            let more = RainbowCircleView()
            more.onClick = { [weak self] in self?.showColorPicker(cur, onPick) }
            row.addArrangedSubview(wrap(more, 36, 36, 8, 4, 4, 4))
            let sv = UIScrollView()
            sv.showsHorizontalScrollIndicator = false
            row.translatesAutoresizingMaskIntoConstraints = false
            sv.addSubview(row)
            NSLayoutConstraint.activate([
                row.leadingAnchor.constraint(equalTo: sv.contentLayoutGuide.leadingAnchor),
                row.trailingAnchor.constraint(equalTo: sv.contentLayoutGuide.trailingAnchor),
                row.topAnchor.constraint(equalTo: sv.contentLayoutGuide.topAnchor),
                row.bottomAnchor.constraint(equalTo: sv.contentLayoutGuide.bottomAnchor),
                row.heightAnchor.constraint(equalTo: sv.frameLayoutGuide.heightAnchor)
            ])
            return sv
        }

        func addColorRow(_ parent: UIStackView, _ cur: Int32, _ onPick: @escaping (Int32) -> Void) {
            parent.addArrangedSubview(wrap(colorRow(cur, onPick), 0, 48, 0, 0, 0, 0))
        }

        func setColorParam(_ l: Layer, _ cp: ColorParam, _ col: Int32) {
            let vals: [(String, Int)] = [("_r", colorRed(col)), ("_g", colorGreen(col)),
                                         ("_b", colorBlue(col)), ("_a", colorAlpha(col))]
            for (suffix, v) in vals {
                let tr = l.track(cp.key + suffix)
                tr.keys.removeAll()
                tr.base = Float(v) / 255
            }
        }

        func addColorParam(_ parent: UIStackView, _ l: Layer, _ cp: ColorParam) {
            func cur() -> Int32 {
                // no track yet → show the effect's real default colour (it used to read as black)
                let d = UInt32(bitPattern: cp.def)
                func comp(_ suffix: String, _ shift: UInt32) -> Int {
                    if let tr = l.props[cp.key + suffix] { return ktInt(tr.eval(Editor.time) * 255) }
                    return Int((d >> shift) & 0xFF)
                }
                return argbColor(comp("_a", 24), comp("_r", 16), comp("_g", 8), comp("_b", 0))
            }
            let row = hRow()
            row.alignment = .fill
            row.backgroundColor = argbToUIColor(C.CARD)
            row.isLayoutMarginsRelativeArrangement = true
            row.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 14, bottom: 0, trailing: 10)
            let tv = UILabel()
            tv.text = cp.label
            tv.textColor = argbToUIColor(C.TEXT)
            tv.font = boldFont(15)
            tv.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
            row.addArrangedSubview(tv)
            let sw = TapView()
            sw.backgroundColor = argbToUIColor(cur())
            sw.onClick = { [weak self] in
                self?.showColorPicker(cur()) { col in
                    self?.pushUndo()
                    self?.setColorParam(l, cp, col)
                    sw.backgroundColor = argbToUIColor(col)
                    self?.render()
                }
            }
            row.addArrangedSubview(wrap(sw, 72, 34, 0, 0, 0, 0))
            put(parent, row, 52)
        }

        // ---------------------------------------------------------------- media + shapes

        func buildMedia() {
            let p: UIStackView = panelList
            text(p, "Media", C.TEXT, 16, true)
            let browser = MediaBrowserView(columns: 4, showExpand: true)
            browser.onPick = { [weak self] a in self?.importPHAsset(a) }
            browser.onExpand = { [weak self] in self?.openFullMediaBrowser() }
            put(p, browser, 300)
            put(p, pill("Import video from Files", "import") { [weak self] in self?.pickFile(R_VIDEO, [.movie, .audiovisualContent]) }, 44)
            put(p, pill("Import image from Files", "import") { [weak self] in self?.pickFile(R_IMAGE, [.image]) }, 44)
            put(p, pill("Import audio", "import") { [weak self] in self?.pickMedia(R_AUDIOFILE, [.audio]) }, 44)
            put(p, pill("Beat markers from an audio file", "graph") { [weak self] in self?.pickFile(R_BEAT, [.audio]) }, 44)
            var files: [URL] = (try? FileManager.default.contentsOfDirectory(
                at: Projects.mediaDir(), includingPropertiesForKeys: [.contentModificationDateKey])) ?? []
            files.sort { a, b in
                let da = (try? a.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate)?.timeIntervalSince1970 ?? 0
                let db = (try? b.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate)?.timeIntervalSince1970 ?? 0
                return da > db
            }
            files = Array(files.prefix(12))
            if !files.isEmpty { text(p, "Recent media", C.DIM, 13) }
            for f in files {
                let ext = f.pathExtension.lowercased()
                let type: LayerType
                if ext == "glb" || ext == "vdb" { type = .MODEL }
                else if ["mp4", "mov", "mkv", "webm", "3gp", "m4v"].contains(ext) { type = .VIDEO }
                else if ["m4a", "mp3", "aac", "wav", "ogg", "flac"].contains(ext) { type = .AUDIO }
                else { type = .IMAGE }
                let ic = type == .VIDEO ? "media" : (type == .MODEL ? "cube" : "media")
                put(p, pill(afterFirst(f.lastPathComponent, "_"), ic) { [weak self] in
                    self?.addMedia(f.path, type)
                }, 40)
            }
        }

        func buildShapes() {
            text(panelList, "Add shape", C.TEXT, 16, true)
            let all: [ShapeKind] = [.RECT, .ROUND, .CIRCLE, .TRIANGLE, .STAR]
            let names = all.map { cap($0.rawValue.lowercased()) }
            panelList.addArrangedSubview(chipRow(names, -1) { [weak self] i in
                guard let self = self else { return }
                let l = self.addLayer(.SHAPE)
                l.shape = all[i]
                self.render()
            })
        }

        // ---------------------------------------------------------------- edit

        func buildEdit(_ l: Layer) {
            let p: UIStackView = panelList
            switch l.type {
            case .TEXT:
                buildText(p, l)
            case .SHAPE:
                text(p, "Shape", C.TEXT, 16, true)
                let all: [ShapeKind] = [.RECT, .ROUND, .CIRCLE, .TRIANGLE, .STAR]
                let names = all.map { cap($0.rawValue.lowercased()) }
                p.addArrangedSubview(chipRow(names, all.firstIndex(of: l.shape) ?? 0) { [weak self] i in
                    guard let self = self else { return }
                    self.pushUndo()
                    l.shape = all[i]
                    self.refreshPanel(); self.render()
                })
                text(p, "Color", C.DIM)
                addKeyedColor(p, l, "color", l.color) { l.color = $0 }
            case .GROUP:
                text(p, "Group", C.TEXT, 16, true)
                text(p, "Put layers inside with Parent in their Transform panel. Tap the ^ arrow in the timeline to open or close the group. Groups can have effects, and 3D layers inside a group keep their 3D look.", C.DIM, 12)
                text(p, "Mask", C.GREEN, 13, true)
                text(p, "The top layer inside the group masks the layers beneath it.", C.DIM, 12)
                p.addArrangedSubview(chipRow(["None", "Alpha", "Inverted alpha", "Luma", "Inverted luma"], l.mask) { [weak self] i in
                    guard let self = self else { return }
                    self.pushUndo()
                    l.mask = i
                    self.refreshPanel(); self.render()
                })
            case .AUDIO:
                text(p, "Audio", C.TEXT, 16, true)
                text(p, l.name)
                addRow(p, l, Defs.audio[0])
                put(p, pill("Beat markers from this audio", "graph") { [weak self] in
                    self?.beatsFrom(l.imagePath ?? "", l.start)
                }, 42)
                text(p, "Plays during preview and is mixed into the render (the first audio layer; AAC or MP3 files work best).", C.DIM, 12)
            case .FLARE:
                text(p, "Optical Flare", C.TEXT, 16, true)
                put(p, pill("Customize", "edit", C.GREEN, C.ONDARK) { [weak self] in
                    self?.openFlareEditor(l)
                }, 48)
                for d in Defs.flare { addRow(p, l, d) }
                text(p, "Move the light with the Transform panel or drag it in the preview. Turn the 3D cube on and it follows a camera and shrinks with distance.", C.DIM, 12)
            case .ADJUST:
                text(p, "Adjustment layer", C.TEXT, 16, true)
                text(p, "Add effects to it in the Effects panel. They apply to everything below it for as long as the layer lasts.")
            case .CAMERA:
                text(p, "Camera", C.TEXT, 16, true)
                addRow(p, l, Defs.camera[0])
                let rtSw = SwitchRow(); rtSw.label = "Ray tracing"; rtSw.on = l.rtOn
                rtSw.onToggle = { [weak self] v in self?.pushUndo(); l.rtOn = v; self?.refreshPanel(); self?.render() }
                put(p, rtSw, 46)
                if l.rtOn {
                    let ri = RulerSlider(frame: .zero)
                    ri.label = "Ray tracing intensity"; ri.lo = 0; ri.hi = 1; ri.dec = 2; ri.value = l.rtInt
                    ri.onBegin = { [weak self] in self?.pushUndo() }
                    ri.onChange = { [weak self] v in l.rtInt = v; self?.render() }
                    put(p, ri, 90)
                    let rr = RulerSlider(frame: .zero)
                    rr.label = "Occlusion radius"; rr.lo = 0.05; rr.hi = 2; rr.dec = 2; rr.value = l.rtRad
                    rr.onBegin = { [weak self] in self?.pushUndo() }
                    rr.onChange = { [weak self] v in l.rtRad = v; self?.render() }
                    put(p, rr, 90)
                    text(p, "Traced shadows and ambient occlusion (needs an iPhone with ray tracing, A13 or newer).", C.DIM, 12)
                }
                text(p, "Position and rotate it in Transform. It controls every layer whose 3D cube is on.")
            case .NULL:
                text(p, "Null object", C.TEXT, 16, true)
                text(p, "An invisible layer. Turn its 3D cube on, then pick it as Parent in other layers' Transform panel.")
            default:
                text(p, cap(l.type.rawValue.lowercased()), C.TEXT, 16, true)
                text(p, l.name)
                if l.type == .VIDEO {
                    text(p, "Length: " + String(format: "%.1f", l.srcDur) + " s. Decoded with the system decoder.")
                    put(p, pill("Extract audio", "export") { [weak self] in self?.extractAudio(l) }, 42)
                    put(p, pill("Beat markers from this video", "graph") { [weak self] in
                        self?.beatsFrom(l.imagePath ?? "", l.start)
                    }, 42)
                }
                if l.type == .IMAGE {
                    put(p, pill("Direct Drawing Editor", "edit", C.GREEN, C.ONDARK) { [weak self] in self?.openDirectDrawing(l) }, 46)
                    text(p, "Draw on this picture, press Save, and it replaces the image here. Position, effects and animation stay as they are.", C.DIM, 12)
                }
                if l.type == .MODEL, (l.imagePath ?? "").lowercased().hasSuffix(".vdb") {
                    text(p, "Volume (VDB)", C.TEXT, 14, true)
                    let ds = RulerSlider(frame: .zero)
                    ds.label = "Density"; ds.lo = 0; ds.hi = 8; ds.dec = 2
                    ds.value = l.vdbDens
                    ds.onBegin = { [weak self] in self?.pushUndo() }
                    ds.onChange = { [weak self] v in l.vdbDens = v; self?.render() }
                    put(p, ds, 90)
                    text(p, "Tint", C.DIM, 13)
                    p.addArrangedSubview(wrap(colorRow(l.vdbTint) { [weak self] c in
                        self?.pushUndo(); l.vdbTint = c; self?.render()
                    }, 0, 48, 0, 0, 0, 0))
                    let bs = RulerSlider(frame: .zero)
                    bs.label = "Brightness"; bs.lo = 0; bs.hi = 4; bs.dec = 2
                    bs.value = l.vdbBright
                    bs.onBegin = { [weak self] in self?.pushUndo() }
                    bs.onChange = { [weak self] v in l.vdbBright = v; self?.render() }
                    put(p, bs, 90)
                    let ev = SwitchRow(); ev.label = "Enable environment"; ev.on = l.vdbEnv
                    ev.onToggle = { [weak self] v in self?.pushUndo(); l.vdbEnv = v; self?.refreshPanel(); self?.render() }
                    put(p, ev, 46)
                    if l.vdbEnv {
                        put(p, pill(l.vdbEnvPath == nil ? "Import image / HDR / EXR" : "Change environment image", "export") { [weak self] in
                            self?.pickFile(R_VDBENV, envTypes())
                        }, 42)
                        let sv = SwitchRow(); sv.label = "Use surroundings (no image)"; sv.on = l.vdbSurround
                        sv.onToggle = { [weak self] v in self?.pushUndo(); l.vdbSurround = v; self?.render() }
                        put(p, sv, 46)
                    }
                    let oc = SwitchRow(); oc.label = "Occlusion (hidden behind models)"; oc.on = l.occlude
                    oc.onToggle = { [weak self] v in self?.pushUndo(); l.occlude = v; self?.render() }
                    put(p, oc, 46)
                }
                if l.type == .MODEL, !(l.imagePath ?? "").lowercased().hasSuffix(".vdb") {
                    text(p, "3D settings", C.TEXT, 14, true)
                    put(p, pill("Texture (image for this model)", "export") { [weak self] in
                        self?.pickFile(R_MODELTEX, [.image])
                    }, 42)
                    let rows: [(String, Bool, (Bool) -> Void)] = [
                        ("Environment light", l.m3Env, { l.m3Env = $0 }),
                        ("Metallic reflectivity", l.m3Metal, { l.m3Metal = $0 }),
                        ("Ambient occlusion (texture)", l.m3Ao, { l.m3Ao = $0 })]
                    for (name, on, set) in rows {
                        let r = SwitchRow(); r.label = name; r.on = on
                        r.onToggle = { [weak self] v in self?.pushUndo(); set(v); self?.render() }
                        put(p, r, 46)
                    }
                    let rtSw = SwitchRow(); rtSw.label = "Ray tracing"; rtSw.on = l.rtOn
                    rtSw.onToggle = { [weak self] v in self?.pushUndo(); l.rtOn = v; self?.refreshPanel(); self?.render() }
                    put(p, rtSw, 46)
                    if l.rtOn {
                        let ri = RulerSlider(frame: .zero)
                        ri.label = "Ray tracing intensity"; ri.lo = 0; ri.hi = 1; ri.dec = 2; ri.value = l.rtInt
                        ri.onBegin = { [weak self] in self?.pushUndo() }
                        ri.onChange = { [weak self] v in l.rtInt = v; self?.render() }
                        put(p, ri, 90)
                        let rr = RulerSlider(frame: .zero)
                        rr.label = "Occlusion radius"; rr.lo = 0.05; rr.hi = 2; rr.dec = 2; rr.value = l.rtRad
                        rr.onBegin = { [weak self] in self?.pushUndo() }
                        rr.onChange = { [weak self] v in l.rtRad = v; self?.render() }
                        put(p, rr, 90)
                        text(p, "Traced shadows and ambient occlusion (needs an iPhone with ray tracing, A13 or newer).", C.DIM, 12)
                    }
                    p.addArrangedSubview(chipRow(["Final", "Base", "Rough", "Metal", "Occl", "Emis"], l.m3View) { [weak self] i in
                        self?.pushUndo(); l.m3View = i; self?.refreshPanel(); self?.render()
                    })
                    text(p, "Chips show the PBR textures: base colour, roughness, metalness, occlusion, emissive.", C.DIM, 12)
                }
                if l.type == .MODEL {
                    text(p, "Static mesh with PBR materials, textures and vertex colours (.glb / .gltf / .obj). Node transforms are baked on load; the model is centred and drawn with a real depth buffer.")
                }
            }
        }

        func buildText(_ p: UIStackView, _ l: Layer) {
            text(p, "Text", C.TEXT, 16, true)
            p.addArrangedSubview(chipRow(["Text", "Style", "Animate"], textTab) { [weak self] i in
                guard let self = self else { return }
                self.textTab = i
                self.refreshPanel()
            })
            switch textTab {
            case 0:
                let et = makeField(l.text)
                bind(et) { [weak self] s in
                    l.text = s
                    self?.render()
                }
                put(p, et, 44)
                text(p, "Alignment", C.GREEN, 13, true)
                p.addArrangedSubview(chipRow(["Left", "Center", "Right"], l.align) { [weak self] i in
                    guard let self = self else { return }
                    self.pushUndo()
                    l.align = i
                    self.render()
                })
                text(p, "Letter case", C.GREEN, 13, true)
                p.addArrangedSubview(chipRow(["As typed", "UPPER", "lower"], l.caps) { [weak self] i in
                    guard let self = self else { return }
                    self.pushUndo()
                    l.caps = i
                    self.render()
                })
                let sb = SwitchRow()
                sb.label = "Bold"; sb.on = l.bold
                sb.onToggle = { [weak self] v in self?.pushUndo(); l.bold = v; self?.render() }
                put(p, sb, 52)
                let si = SwitchRow()
                si.label = "Italic"; si.on = l.italic
                si.onToggle = { [weak self] v in self?.pushUndo(); l.italic = v; self?.render() }
                put(p, si, 52)
                let su = SwitchRow()
                su.label = "Underline"; su.on = l.underline
                su.onToggle = { [weak self] v in self?.pushUndo(); l.underline = v; self?.render() }
                put(p, su, 52)
                let ss = SwitchRow()
                ss.label = "Strikethrough"; ss.on = l.strike
                ss.onToggle = { [weak self] v in self?.pushUndo(); l.strike = v; self?.render() }
                put(p, ss, 52)
                addRow(p, l, Defs.text[4])
                text(p, "Font", C.GREEN, 13, true)
                let fams = ["sans-serif", "serif", "monospace", "cursive", "casual", "sans-serif-condensed",
                            "sans-serif-light", "sans-serif-medium", "sans-serif-black", "serif-monospace"]
                let names = ["Sans", "Serif", "Mono", "Cursive", "Casual", "Condensed", "Light", "Medium", "Black", "Typewriter"]
                let sel = l.fontPath != nil ? -1 : (fams.firstIndex(of: l.font) ?? -1)
                p.addArrangedSubview(chipRow(names, sel) { [weak self] i in
                    guard let self = self else { return }
                    self.pushUndo()
                    l.font = fams[i]
                    l.fontPath = nil
                    self.refreshPanel(); self.render()
                })
                let curName = l.fontPath.flatMap { fp in FontLibrary.fonts.first { FontLibrary.resolve(FontLibrary.path($0)) == FontLibrary.resolve(fp) }?.name }
                put(p, pill(l.fontPath != nil ? "Font: " + (curName ?? "custom") + "  ·  Browse" : "Font library — import, folders, ZIP packs",
                            "folder") { [weak self] in
                    guard let self = self else { return }
                    let vc = FontBrowserViewController()
                    vc.currentPath = l.fontPath
                    vc.onPick = { [weak self] f in
                        self?.pushUndo()
                        l.fontPath = FontLibrary.path(f)
                        self?.refreshPanel(); self?.render()
                    }
                    let nav = UINavigationController(rootViewController: vc)
                    nav.setNavigationBarHidden(true, animated: false)
                    nav.modalPresentationStyle = .pageSheet
                    self.present(nav, animated: true)
                }, 42)
                put(p, pill("Import a single font file (.ttf or .otf)", "import") { [weak self] in
                    self?.pickFile(R_FONT, [.data]) }, 42)
                text(p, "Color", C.GREEN, 13, true)
                addKeyedColor(p, l, "color", l.color) { l.color = $0 }
                addRow(p, l, Defs.transform[2], "Size")
            case 1:
                text(p, "Stroke", C.GREEN, 13, true)
                addRow(p, l, Defs.text[0])
                addKeyedColor(p, l, "strokeColor", l.strokeColor) { l.strokeColor = $0 }
                text(p, "Stroke position", C.DIM, 12)
                p.addArrangedSubview(chipRow(["Outside", "Center", "Inside"], l.strokePos) { [weak self] i in
                    guard let self = self else { return }
                    self.pushUndo()
                    l.strokePos = i
                    self.render()
                })
                text(p, "Corners", C.DIM, 12)
                p.addArrangedSubview(chipRow(["Round", "Sharp"], l.strokeJoin) { [weak self] i in
                    guard let self = self else { return }
                    self.pushUndo()
                    l.strokeJoin = i
                    self.render()
                })
                text(p, "Second stroke (outside the first)", C.GREEN, 13, true)
                addRow(p, l, Defs.text[8])
                addKeyedColor(p, l, "stroke2Color", l.stroke2Color) { l.stroke2Color = $0 }
                text(p, "Border box", C.GREEN, 13, true)
                addRow(p, l, Defs.text[1])
                addRow(p, l, Defs.text[2])
                addRow(p, l, Defs.text[9])
                addKeyedColor(p, l, "borderColor", l.borderColor) { l.borderColor = $0 }
                let bd = SwitchRow()
                bd.label = "Dashed border"; bd.on = l.borderDash
                bd.onToggle = { [weak self] v in self?.pushUndo(); l.borderDash = v; self?.render() }
                put(p, bd, 52)
                text(p, "Box fill", C.DIM, 12)
                addKeyedColor(p, l, "borderFill", colorAlpha(l.borderFill) == 0 ? Int32(bitPattern: 0xFF000000) : l.borderFill) { l.borderFill = $0 }
                put(p, pill("No box fill", "close") { [weak self] in
                    self?.pushUndo(); l.borderFill = 0; for sf in ["_r", "_g", "_b", "_a"] { l.props.removeValue(forKey: "tc_borderFill" + sf) }; self?.refreshPanel(); self?.render()
                }, 40)
                text(p, "Shadow", C.GREEN, 13, true)
                let sh = SwitchRow()
                sh.label = "Shadow"; sh.on = l.shadowOn
                sh.onToggle = { [weak self] v in
                    guard let self = self else { return }
                    self.pushUndo()
                    l.shadowOn = v
                    self.refreshPanel(); self.render()
                }
                put(p, sh, 52)
                if l.shadowOn {
                    addKeyedColor(p, l, "shadowColor", l.shadowColor) { l.shadowColor = $0 }
                    addRow(p, l, Defs.text[5])
                    addRow(p, l, Defs.text[6])
                    addRow(p, l, Defs.text[7])
                }
                text(p, "Spacing", C.GREEN, 13, true)
                addRow(p, l, Defs.text[3])
            default:
                buildTextAnim(p, l)
            }
        }

        func buildTextAnim(_ p: UIStackView, _ l: Layer) {
            // presets: each one builds a normal custom animation the user can keep editing
            func fxOf(_ kind: Int, _ vals: [Float]) -> TextFx { let f = TextFx(kind); for (i, x) in vals.enumerated() where i < f.v.count { f.v[i] = x }; return f }
            let presets: [(String, () -> TextAnim)] = [
                ("Slide up", { let a = TextAnim(12); a.fx = [fxOf(0, [0, 0.3, 1, 0, 0])]; return a }),
                ("Slide down", { let a = TextAnim(12); a.fx = [fxOf(0, [0, -0.3, 1, 0, 0])]; return a }),
                ("Fade in", { let a = TextAnim(12); a.fx = [fxOf(0, [0, 0, 1, 0, 0])]; return a }),
                ("Pop", { let a = TextAnim(12); a.ease = 3; a.fx = [fxOf(0, [0, 0, 0, 0, 0])]; return a }),
                ("Typewriter", { let a = TextAnim(12); a.dur = 0.05; a.stagger = 0.08; a.fx = [fxOf(0, [0, 0, 1, 0, 0])]; return a }),
                ("Rotate in", { let a = TextAnim(12); a.fx = [fxOf(0, [0, 0, 1, 90, 0])]; return a }),
                ("Slide up out", { let a = TextAnim(12, 1); a.start = 1; a.fx = [fxOf(0, [0, -0.3, 1, 0, 0])]; return a }),
                ("Slide down out", { let a = TextAnim(12, 1); a.start = 1; a.fx = [fxOf(0, [0, 0.3, 1, 0, 0])]; return a }),
                ("Bounce in", { let a = TextAnim(12); a.ease = 3; a.fx = [fxOf(0, [0, 0.3, 1, 0, 0])]; return a }),
                ("Fade out", { let a = TextAnim(12, 1); a.fx = [fxOf(0, [0, 0, 1, 0, 0])]; return a }),
            ]
            put(p, pill("Add preset", "plus", C.GREEN, C.ONDARK) { [weak self] in
                guard let self = self else { return }
                Dlg(self).setTitle("Add preset").setItems(presets.map { $0.0 }) { [weak self] _, w in
                    guard let self = self else { return }
                    self.pushUndo()
                    let a = presets[w].1()
                    if a.mode == 1 { a.start = 1 }
                    l.anims.append(a)
                    self.expanded.insert("anim:\(l.id):\(l.anims.count - 1)")
                    self.refreshPanel(); self.render()
                }.show()
            }, 46)
            put(p, pill("Animate — new custom animation", "plus", C.GREEN, C.ONDARK) { [weak self] in
                guard let self = self else { return }
                self.pushUndo()
                let a = TextAnim(12)
                a.start = 0; a.dur = 1
                l.anims.append(a)
                self.expanded.insert("anim:\(l.id):\(l.anims.count - 1)")
                self.refreshPanel(); self.render()
            }, 46)
            if l.anims.isEmpty {
                text(p, "Tap Animate to build your own: set a start and end, then add animation types (Transform, Wiggle, 3D, Tracking, Skew) and tune every value. Presets are just starting points you can edit.", C.DIM, 12)
            }
            for (i, a) in l.anims.enumerated() {
                let key = "anim:\(l.id):\(i)"
                let isOpen = expanded.contains(key)
                let card = vStack()
                let bar = hRow()
                bar.backgroundColor = argbToUIColor(C.CARD)
                bar.isLayoutMarginsRelativeArrangement = true
                bar.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 14, bottom: 0, trailing: 2)
                let tv = UILabel()
                tv.text = a.name()
                tv.textColor = argbToUIColor(C.TEXT)
                tv.font = boldFont(16)
                tv.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
                bar.addArrangedSubview(tv)
                let chev = IconView(isOpen ? "chev_up" : "chev_down", C.DIM, 20)
                chev.onClick = { [weak self] in
                    guard let self = self else { return }
                    if self.expanded.contains(key) { self.expanded.remove(key) } else { self.expanded.insert(key) }
                    self.refreshPanel()
                }
                bar.addArrangedSubview(wrap(chev, 40, 48, 0, 0, 0, 0))
                let del = IconView("trash", C.RED, 20)
                del.onClick = { [weak self] in
                    guard let self = self else { return }
                    self.pushUndo()
                    l.anims.removeAll { $0 === a }
                    for k in Array(l.props.keys) where k.hasPrefix("an_\(a.id)_") || a.fx.contains(where: { k.hasPrefix("fx_\($0.id)_") }) { l.props.removeValue(forKey: k) }
                    self.refreshPanel(); self.render()
                }
                bar.addArrangedSubview(wrap(del, 40, 48, 0, 0, 0, 0))
                card.addArrangedSubview(bar)
                if isOpen {
                    if a.type == 12 {
                        addKeyedRow(card, l, "an_\(a.id)_start", "Start (s)", 0, 30, 0, 2, a.start)
                        addKeyedRow(card, l, "an_\(a.id)_end", "End (s)", 0.05, 30, 1, 2, a.start + a.dur)
                        addKeyedRow(card, l, "an_\(a.id)_stag", "Delay per letter (s)", 0, 0.5, 0.04, 2, a.stagger)
                        card.addArrangedSubview(chipRow(["In", "Out", "Loop"], a.mode) { [weak self] m in
                            guard let self = self else { return }
                            self.pushUndo(); a.mode = m; self.refreshPanel(); self.render()
                        })
                        text(card, "Easing", C.DIM, 12)
                        card.addArrangedSubview(chipRow(["Linear", "Ease out", "Ease in-out", "Bounce", "Custom curve"], a.ease) { [weak self] e in
                            guard let self = self else { return }
                            self.pushUndo(); a.ease = e
                            if e == 4 { a.curve.ease = Ease.CUSTOM }
                            self.refreshPanel(); self.render()
                        })
                        if a.ease == 4 {
                            let gv = GraphView(frame: .zero)
                            gv.key = a.curve
                            gv.onBegin = { [weak self] in self?.pushUndo() }
                            gv.onChange = { [weak self] in self?.render() }
                            put(card, gv, 200)
                        }
                        for (fi, fx) in a.fx.enumerated() {
                            let hdr = hRow()
                            let tl = UILabel(); tl.text = fx.name(); tl.textColor = argbToUIColor(C.GREEN); tl.font = boldFont(14)
                            tl.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
                            hdr.addArrangedSubview(tl)
                            let dl = IconView("trash", C.RED, 18)
                            dl.onClick = { [weak self] in
                                guard let self = self else { return }
                                self.pushUndo(); a.fx.remove(at: fi)
                                for k in Array(l.props.keys) where k.hasPrefix("fx_\(fx.id)_") { l.props.removeValue(forKey: k) }
                                self.refreshPanel(); self.render()
                            }
                            hdr.addArrangedSubview(wrap(dl, 40, 40, 0, 0, 0, 0))
                            put(card, hdr, 40)
                            for (vi, pd) in TextFx.PARAMS[fx.kind].enumerated() {
                                addKeyedRow(card, l, "fx_\(fx.id)_\(vi)", pd.0 + " · " + fx.name(), pd.1, pd.2, pd.3, pd.4, fx.v[vi])
                            }
                        }
                        put(card, pill("Add animation type", "plus") { [weak self] in
                            guard let self = self else { return }
                            Dlg(self).setTitle("Animation type").setItems(TextFx.KINDS) { [weak self] _, w in
                                guard let self = self else { return }
                                self.pushUndo(); a.fx.append(TextFx(w)); self.refreshPanel(); self.render()
                            }.show()
                        }, 42)
                    } else {
                    card.addArrangedSubview(chipRow(["In", "Out", "Loop"], a.mode) { [weak self] m in
                        guard let self = self else { return }
                        self.pushUndo()
                        a.mode = m
                        self.refreshPanel(); self.render()
                    })
                    addPlain(card, "Start (s)", 0, 10, a.start, 2) { [weak self] v in a.start = v; self?.render() }
                    addPlain(card, "Duration (s)", 0.05, 5, a.dur, 2) { [weak self] v in a.dur = v; self?.render() }
                    addPlain(card, "Delay per letter (s)", 0, 0.5, a.stagger, 2) { [weak self] v in a.stagger = v; self?.render() }
                    addPlain(card, "Distance", 0, 3, a.distance, 2) { [weak self] v in a.distance = v; self?.render() }
                    addPlain(card, "Scale from", 0, 3, a.scaleFrom, 2) { [weak self] v in a.scaleFrom = v; self?.render() }
                    addPlain(card, "Rotate from (deg)", -360, 360, a.rotFrom, 0) { [weak self] v in a.rotFrom = v; self?.render() }
                    addPlain(card, "Speed (loops)", 0, 10, a.speed, 1) { [weak self] v in a.speed = v; self?.render() }
                    text(card, "Easing", C.DIM, 12)
                    card.addArrangedSubview(chipRow(["Linear", "Ease out", "Ease in-out", "Bounce", "Custom curve"], a.ease) { [weak self] e in
                        guard let self = self else { return }
                        self.pushUndo()
                        a.ease = e
                        if e == 4 { a.curve.ease = Ease.CUSTOM }
                        self.refreshPanel(); self.render()
                    })
                    if a.ease == 4 {
                        let gv = GraphView(frame: .zero)
                        gv.key = a.curve
                        gv.onBegin = { [weak self] in self?.pushUndo() }
                        gv.onChange = { [weak self] in self?.render() }
                        put(card, gv, 200)
                    }
                    let sf = SwitchRow()
                    sf.label = "Fade while moving"; sf.on = a.fade
                    sf.onToggle = { [weak self] v in self?.pushUndo(); a.fade = v; self?.render() }
                    put(card, sf, 52)
                    }
                }
                put(p, card, 0, 3, 6)
            }
        }
}
