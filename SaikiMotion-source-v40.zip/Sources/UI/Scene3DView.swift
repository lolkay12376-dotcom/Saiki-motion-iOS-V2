// Scene3DView.swift — the "Scene 3D" screen opened from the cube button beside the preview.
//
// A SceneKit viewport that mirrors every 3D thing in the main editor (model layers, 3D-cube
// layers, camera layers) at the editor's current time. Modes (left toolbar):
//   Still  — look around only (orbit / pan / zoom). Nothing can be selected or edited.
//   Move   — tap selects; drag the selected layer (gizmo arrows constrain to an axis).
//   Scale  — tap selects; drag up / down on it to scale.
// "+" menu: Import Model, 3D Scene (sync on/off), Grid, Timeline, Gizmo.
// Edits write the same x / y / z / scale tracks the main editor uses (auto-key aware, undoable).
// Camera: 1 finger orbits (on empty space in edit modes), 2 fingers pan, pinch dollies.

import UIKit
import SceneKit
import OpenGLES

final class Scene3DView: UIView, UIGestureRecognizerDelegate {

    enum Mode: Int { case still = 0, move, scale }

    // MARK: state
    private weak var host: EditorViewController?
    private let scn = SCNScene()
    private let sv = SCNView()
    private let cam = SCNNode()
    private let world = SCNNode()
    private let gridNode = SCNNode()
    private let gizmo = SCNNode()
    private var nodes: [Int: SCNNode] = [:]
    private var sig = ""
    private var link: CADisplayLink?
    private var mode = Mode.move
    private var selected = -1
    private var lastHostSel = -2
    private var showGrid = true, showGizmo = true, showTimeline = true, syncScene = true
    private var yaw: Float = 0.6, pitch: Float = 0.35, dist: Float = 6
    private var target = simd_float3(0, 0, 0)
    private var drag = false, dragAxis = -1, sliding = false

    // UI
    private var modeBtns: [UIButton] = []
    private let chip = UILabel()
    private let plus = UIButton(type: .system)
    private let tl = UIView()
    private let playBtn = UIButton(type: .system)
    private let timeLbl = UILabel()
    private let slider = UISlider()
    private let accent = UIColor(red: 0.04, green: 0.52, blue: 1, alpha: 1)

    // MARK: entry
    static func present(in host: EditorViewController) {
        if host.view.subviews.contains(where: { $0 is Scene3DView }) { return }
        let v = Scene3DView(host: host)
        v.translatesAutoresizingMaskIntoConstraints = false
        host.view.addSubview(v)
        NSLayoutConstraint.activate([
            v.leadingAnchor.constraint(equalTo: host.view.leadingAnchor),
            v.trailingAnchor.constraint(equalTo: host.view.trailingAnchor),
            v.topAnchor.constraint(equalTo: host.view.topAnchor),
            v.bottomAnchor.constraint(equalTo: host.view.bottomAnchor)])
    }

    init(host: EditorViewController) {
        self.host = host
        super.init(frame: .zero)
        backgroundColor = .black
        buildScene()
        buildUI()
        applyCam()
        updateModeUI()
        rebuildMenu()
        link = CADisplayLink(target: self, selector: #selector(tick))
        link?.preferredFramesPerSecond = 30
        link?.add(to: .main, forMode: .common)
    }
    required init?(coder: NSCoder) { fatalError() }

    override func willMove(toSuperview newSuperview: UIView?) {
        if newSuperview == nil { link?.invalidate(); link = nil }
    }

    @objc private func close() { removeFromSuperview() }

    // MARK: scene
    private func buildScene() {
        scn.background.contents = UIColor.black
        let c = SCNCamera(); c.fieldOfView = 50; c.zNear = 0.05; c.zFar = 300
        cam.camera = c
        scn.rootNode.addChildNode(cam)
        scn.rootNode.addChildNode(world)
        scn.rootNode.addChildNode(gridNode)
        scn.rootNode.addChildNode(gizmo)
        let amb = SCNNode(); amb.light = SCNLight(); amb.light?.type = .ambient; amb.light?.intensity = 650
        let sun = SCNNode(); sun.light = SCNLight(); sun.light?.type = .directional; sun.light?.intensity = 900
        sun.eulerAngles = SCNVector3(-0.8, 0.6, 0)
        scn.rootNode.addChildNode(amb); scn.rootNode.addChildNode(sun)

        // floor grid + red X / blue Z axes (like the inspiration screenshot)
        var g: [SCNVector3] = []
        for i in -10...10 where i != 0 {
            let f = Float(i)
            g += [SCNVector3(f, 0, -10), SCNVector3(f, 0, 10), SCNVector3(-10, 0, f), SCNVector3(10, 0, f)]
        }
        gridNode.addChildNode(lines(g, UIColor(white: 0.28, alpha: 1)))
        gridNode.addChildNode(lines([SCNVector3(-10, 0, 0), SCNVector3(10, 0, 0)], UIColor(red: 0.85, green: 0.25, blue: 0.25, alpha: 1)))
        gridNode.addChildNode(lines([SCNVector3(0, 0, -10), SCNVector3(0, 0, 10)], UIColor(red: 0.25, green: 0.5, blue: 0.95, alpha: 1)))
        buildGizmo()
    }

    private func lines(_ pts: [SCNVector3], _ color: UIColor) -> SCNNode {
        let src = SCNGeometrySource(vertices: pts)
        let el = SCNGeometryElement(indices: (0..<Int32(pts.count)).map { $0 }, primitiveType: .line)
        let geo = SCNGeometry(sources: [src], elements: [el])
        let m = SCNMaterial(); m.diffuse.contents = color; m.lightingModel = .constant
        geo.materials = [m]
        return SCNNode(geometry: geo)
    }

    private func buildGizmo() {
        gizmo.childNodes.forEach { $0.removeFromParentNode() }
        let cols = [UIColor(red: 1, green: 0.3, blue: 0.3, alpha: 1), UIColor(red: 0.3, green: 0.9, blue: 0.4, alpha: 1), UIColor(red: 0.3, green: 0.55, blue: 1, alpha: 1)]
        let rots = [SCNVector3(0, 0, -Float.pi / 2), SCNVector3(0, 0, 0), SCNVector3(Float.pi / 2, 0, 0)]
        for i in 0..<3 {
            let axis = SCNNode(); axis.eulerAngles = rots[i]
            let mat = SCNMaterial(); mat.diffuse.contents = cols[i]; mat.lightingModel = .constant; mat.readsFromDepthBuffer = false
            let shaft = SCNNode(geometry: SCNCylinder(radius: 0.025, height: 1)); shaft.position.y = 0.5
            let tipGeo: SCNGeometry = mode == .scale ? SCNBox(width: 0.14, height: 0.14, length: 0.14, chamferRadius: 0) : SCNCone(topRadius: 0, bottomRadius: 0.08, height: 0.24)
            let tip = SCNNode(geometry: tipGeo); tip.position.y = 1.1
            for n in [shaft, tip] { n.geometry?.materials = [mat]; n.name = "ax\(i)"; n.renderingOrder = 1000; axis.addChildNode(n) }
            gizmo.addChildNode(axis)
        }
    }

    // MARK: sync with the main editor
    private func is3dContent(_ l: Layer) -> Bool { l.type == .MODEL || l.type == .CAMERA || l.is3d }
    private func layer(_ id: Int) -> Layer? { Editor.scene.layers.first { $0.id == id } }

    private func rebuild() {
        world.childNodes.forEach { $0.removeFromParentNode() }
        nodes = [:]
        for l in Editor.scene.layers where is3dContent(l) {
            let root = SCNNode(); root.name = "L\(l.id)"
            switch l.type {
            case .CAMERA: root.addChildNode(camShape())
            case .MODEL: root.addChildNode(modelNode(l))
            default: root.addChildNode(planeNode(l))
            }
            world.addChildNode(root)
            nodes[l.id] = root
        }
        if selected >= 0, nodes[selected] == nil { selected = -1 }
        if mode != .still { tint(nodes[selected], true) }
    }

    private func camShape() -> SCNNode {
        let w: Float = 0.35, h: Float = 0.2, d: Float = -0.5
        let a = SCNVector3(-w, h, d), b = SCNVector3(w, h, d), c = SCNVector3(w, -h, d), e = SCNVector3(-w, -h, d), o = SCNVector3Zero
        return lines([o, a, o, b, o, c, o, e, a, b, b, c, c, e, e, a], UIColor.orange)
    }

    private func planeNode(_ l: Layer) -> SCNNode {
        let (qw, qh) = Xf.quadSize(l)
        let p = SCNPlane(width: CGFloat(max(qw, 0.05)), height: CGFloat(max(qh, 0.05)))
        let m = SCNMaterial(); m.isDoubleSided = true; m.lightingModel = .constant
        if let path = l.imagePath, let img = UIImage(contentsOfFile: path) { m.diffuse.contents = img }
        else { m.diffuse.contents = UIColor(white: 0.8, alpha: 0.35) }
        p.materials = [m]
        return SCNNode(geometry: p)
    }

    private func modelNode(_ l: Layer) -> SCNNode {
        let holder = SCNNode()
        let old = GlbModel.cpuOnly
        GlbModel.cpuOnly = true
        let model = l.imagePath.flatMap { GlbModel.load($0) }
        GlbModel.cpuOnly = old
        var built = false
        if let m = model {
            for p in m.prims where !p.verts.isEmpty && p.mode == GLenum(GL_TRIANGLES) {
                let vc = p.verts.count / 12
                let data = p.verts.withUnsafeBufferPointer { Data(buffer: $0) }
                func src(_ s: SCNGeometrySource.Semantic, _ comps: Int, _ off: Int) -> SCNGeometrySource {
                    SCNGeometrySource(data: data, semantic: s, vectorCount: vc, usesFloatComponents: true,
                                      componentsPerVector: comps, bytesPerComponent: 4, dataOffset: off * 4, dataStride: 48)
                }
                let idx: [UInt32] = p.cpuIdx.isEmpty ? (0..<UInt32(vc)).map { $0 } : p.cpuIdx
                let el = SCNGeometryElement(data: idx.withUnsafeBufferPointer { Data(buffer: $0) },
                                            primitiveType: .triangles, primitiveCount: idx.count / 3, bytesPerIndex: 4)
                let geo = SCNGeometry(sources: [src(.vertex, 3, 0), src(.normal, 3, 3), src(.texcoord, 2, 6)], elements: [el])
                let mat = SCNMaterial(); mat.isDoubleSided = true
                if p.texBase != 0, let img = GlbModel.cpuImages[p.texBase]?.img {
                    mat.diffuse.contents = img
                    mat.diffuse.contentsTransform = SCNMatrix4Translate(SCNMatrix4MakeScale(1, -1, 1), 0, 1, 0)
                    mat.diffuse.wrapS = .repeat; mat.diffuse.wrapT = .repeat
                } else {
                    mat.diffuse.contents = UIColor(red: CGFloat(p.color[0]), green: CGFloat(p.color[1]), blue: CGFloat(p.color[2]), alpha: 1)
                }
                geo.materials = [mat]
                holder.addChildNode(SCNNode(geometry: geo))
                built = true
            }
            // renderer-space normalisation: S(n0) · T(offset)
            let n = m.normalize
            holder.simdTransform = S(n[0]) * T(n[1], n[2], n[3])
        }
        if !built {   // .vdb / animated / unreadable: a placeholder box so it can still be placed
            let b = SCNBox(width: 1, height: 1, length: 1, chamferRadius: 0)
            let m = SCNMaterial(); m.diffuse.contents = UIColor(white: 0.7, alpha: 0.3); m.fillMode = .lines; m.lightingModel = .constant
            b.materials = [m]
            holder.addChildNode(SCNNode(geometry: b))
        }
        return holder
    }

    // matrix helpers
    private func T(_ x: Float, _ y: Float, _ z: Float) -> simd_float4x4 { var m = matrix_identity_float4x4; m.columns.3 = simd_float4(x, y, z, 1); return m }
    private func S(_ s: Float) -> simd_float4x4 { simd_float4x4(diagonal: simd_float4(s, s, s, 1)) }
    private func R(_ deg: Float, _ axis: simd_float3) -> simd_float4x4 { simd_float4x4(simd_quatf(angle: deg * .pi / 180, axis: axis)) }

    /// Same maths as MetalCam.modelMatrix: T(pos) · Rz · Rx · Ry · S(scale).
    private func xform(_ l: Layer, _ t: Float) -> simd_float4x4 {
        let lt = l.editTime("x", t)
        let x = l.p("x", lt), y = l.p("y", lt)
        var z = Xf.worldZ(l, t)
        let rot = R(l.p("rotZ", lt), simd_float3(0, 0, 1)) * R(l.p("rotX", lt), simd_float3(1, 0, 0)) * R(l.p("rotY", lt), simd_float3(0, 1, 0))
        if l.type == .CAMERA {
            var fov = l.p("fov", lt); if !fov.isFinite || fov < 10 { fov = 55 }
            z += 1 / tan(min(fov, 150) * Float.pi / 360)
            return T(x, y, z) * rot
        }
        return T(x, y, z) * rot * S(l.p("scale", lt))
    }

    @objc private func tick() {
        guard let host = host else { return }
        let s = Editor.scene.layers.filter(is3dContent).map { "\($0.id)|\($0.type.rawValue)|\($0.imagePath ?? "")" }.joined(separator: ",")
        if s != sig { sig = s; rebuild() }
        if host.selId != lastHostSel {
            lastHostSel = host.selId
            if mode != .still { select(nodes[host.selId] != nil ? host.selId : -1, notifyHost: false) }
        }
        let t = Editor.time
        for l in Editor.scene.layers {
            guard let n = nodes[l.id] else { continue }
            n.isHidden = !syncScene || !l.visible || t < l.start || t > l.end
            n.simdTransform = xform(l, t)
        }
        gridNode.isHidden = !showGrid
        updateGizmo()
        tl.isHidden = !showTimeline
        let dur = max(Editor.scene.duration, 0.1)
        slider.maximumValue = dur
        if !sliding { slider.value = min(t, dur) }
        timeLbl.text = String(format: "%.2fs / %.1fs", t, dur)
        playBtn.setImage(UIImage(systemName: host.playing ? "pause.fill" : "play.fill"), for: .normal)
    }

    private func updateGizmo() {
        guard mode != .still, showGizmo, let n = nodes[selected], !n.isHidden else { gizmo.isHidden = true; return }
        gizmo.isHidden = false
        gizmo.simdPosition = n.simdWorldPosition
        let s = simd_length(gizmo.simdPosition - cam.simdWorldPosition) * 0.14
        gizmo.simdScale = simd_float3(repeating: max(s, 0.05))
    }

    // MARK: selection
    private func tint(_ n: SCNNode?, _ on: Bool) {
        n?.enumerateChildNodes { c, _ in
            c.geometry?.materials.forEach { $0.emission.contents = on ? UIColor(red: 0, green: 0.22, blue: 0.5, alpha: 1) : UIColor.black }
        }
    }

    private func select(_ id: Int, notifyHost: Bool = true) {
        tint(nodes[selected], false)
        selected = id
        if mode != .still { tint(nodes[id], true) }
        if notifyHost, id >= 0 { lastHostSel = id; host?.onSelect(id) }
    }

    private func pick(_ p: CGPoint) -> (Int, Int)? {
        let hits = sv.hitTest(p, options: [.searchMode: SCNHitTestSearchMode.all.rawValue])
        var axis = -1
        var lid: Int? = nil
        for h in hits {
            var n: SCNNode? = h.node
            while let c = n {
                if let nm = c.name {
                    if nm.hasPrefix("ax"), selected >= 0, axis < 0 { axis = Int(nm.dropFirst(2)) ?? -1 }
                    if nm.hasPrefix("L"), lid == nil, let i = Int(nm.dropFirst()) { lid = i }
                }
                n = c.parent
            }
        }
        if axis >= 0 && selected >= 0 { return (selected, axis) }
        if let l = lid { return (l, -1) }
        return nil
    }

    // MARK: camera + gestures
    private func applyCam() {
        let cp = cosf(pitch), sp = sinf(pitch)
        cam.simdPosition = target + dist * simd_float3(cp * sinf(yaw), sp, cp * cosf(yaw))
        cam.simdLook(at: target, up: simd_float3(0, 1, 0), localFront: simd_float3(0, 0, -1))
    }

    private func installGestures() {
        let p1 = UIPanGestureRecognizer(target: self, action: #selector(pan1(_:))); p1.maximumNumberOfTouches = 1
        let p2 = UIPanGestureRecognizer(target: self, action: #selector(pan2(_:))); p2.minimumNumberOfTouches = 2; p2.maximumNumberOfTouches = 2
        let pc = UIPinchGestureRecognizer(target: self, action: #selector(pinch(_:)))
        let tp = UITapGestureRecognizer(target: self, action: #selector(tapped(_:)))
        for g in [p1, p2, pc, tp] { g.delegate = self; sv.addGestureRecognizer(g) }
    }

    func gestureRecognizer(_ a: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith b: UIGestureRecognizer) -> Bool { true }

    @objc private func pan1(_ g: UIPanGestureRecognizer) {
        switch g.state {
        case .began:
            drag = false; dragAxis = -1
            if mode != .still {
                let p = g.location(in: sv), tr = g.translation(in: sv)
                if let h = pick(CGPoint(x: p.x - tr.x, y: p.y - tr.y)) {
                    if h.0 != selected { select(h.0) }
                    dragAxis = h.1; drag = true
                    host?.pushUndo()
                }
            }
        case .changed:
            let d = g.translation(in: sv); g.setTranslation(.zero, in: sv)
            if drag { applyDrag(d) } else {
                yaw -= Float(d.x) * 0.01
                pitch = max(-1.5, min(1.5, pitch + Float(d.y) * 0.01))
                applyCam()
            }
        default:
            if drag { drag = false; host?.render(); host?.refreshPanel() }
        }
    }

    @objc private func pan2(_ g: UIPanGestureRecognizer) {
        guard g.state == .changed else { return }
        let d = g.translation(in: sv); g.setTranslation(.zero, in: sv)
        let k = 2 * dist * tanf(Float(cam.camera?.fieldOfView ?? 50) * .pi / 360) / Float(max(sv.bounds.height, 1))
        target += (-cam.simdWorldRight * Float(d.x) + cam.simdWorldUp * Float(d.y)) * k
        applyCam()
    }

    @objc private func pinch(_ g: UIPinchGestureRecognizer) {
        guard g.state == .changed else { return }
        dist = max(0.5, min(60, dist / Float(max(g.scale, 0.01))))
        g.scale = 1
        applyCam()
    }

    @objc private func tapped(_ g: UITapGestureRecognizer) {
        guard mode != .still else { return }
        if let h = pick(g.location(in: sv)) { select(h.0) } else { select(-1); host?.onSelect(-1) }
    }

    private func applyDrag(_ d: CGPoint) {
        guard let l = layer(selected), let n = nodes[selected] else { return }
        let t = Editor.time, ak = host?.autoKeyOn ?? false
        if mode == .scale {
            let f = 1 - Float(d.y) * 0.006
            l.track("scale").set(t, max(0.01, l.p("scale", t) * f), ak)
            return
        }
        let pos = n.simdWorldPosition
        var dw = simd_float3(0, 0, 0)
        if dragAxis >= 0 {
            let dir = [simd_float3(1, 0, 0), simd_float3(0, 1, 0), simd_float3(0, 0, 1)][dragAxis]
            let a = sv.projectPoint(SCNVector3(pos)), b = sv.projectPoint(SCNVector3(pos + dir))
            let sx = CGFloat(b.x - a.x), sy = CGFloat(b.y - a.y)
            let den = Float(sx * sx + sy * sy)
            if den > 1e-4 { dw = dir * Float(d.x * sx + d.y * sy) / den }
        } else {
            let dd = simd_length(pos - cam.simdWorldPosition)
            let k = 2 * dd * tanf(Float(cam.camera?.fieldOfView ?? 50) * .pi / 360) / Float(max(sv.bounds.height, 1))
            dw = cam.simdWorldRight * Float(d.x) * k - cam.simdWorldUp * Float(d.y) * k
        }
        l.track("x").set(t, l.p("x", t) + dw.x, ak)
        l.track("y").set(t, l.p("y", t) + dw.y, ak)
        l.track("z").set(t, l.p("z", t) + dw.z, ak)
    }

    // MARK: UI
    private func sym(_ name: String, _ size: CGFloat = 20) -> UIImage? {
        UIImage(systemName: name, withConfiguration: UIImage.SymbolConfiguration(pointSize: size, weight: .regular))
    }

    private func btn(_ name: String, _ sel: Selector) -> UIButton {
        let b = UIButton(type: .system)
        b.setImage(sym(name), for: .normal); b.tintColor = .white
        b.addTarget(self, action: sel, for: .touchUpInside)
        return b
    }

    private func buildUI() {
        // header
        let back = btn("chevron.left", #selector(close))
        let cube = UIImageView(image: sym("cube", 22)); cube.tintColor = .white
        let title = UILabel(); title.text = "Scene 3D"; title.textColor = .white; title.font = .systemFont(ofSize: 22, weight: .bold)
        let x = btn("xmark", #selector(close))
        let header = UIStackView(arrangedSubviews: [back, cube, title, UIView(), x])
        header.spacing = 12; header.alignment = .center
        header.isLayoutMarginsRelativeArrangement = true
        header.layoutMargins = UIEdgeInsets(top: 0, left: 14, bottom: 0, right: 14)
        header.translatesAutoresizingMaskIntoConstraints = false
        addSubview(header)

        // viewport
        sv.scene = scn; sv.pointOfView = cam
        sv.backgroundColor = .black; sv.antialiasingMode = .multisampling4X
        sv.layer.cornerRadius = 22; sv.layer.masksToBounds = true
        sv.rendersContinuously = true
        installGestures()

        // bottom bar: mode chip (left) + plus menu (right)
        chip.textColor = .white; chip.font = .systemFont(ofSize: 17)
        let bar = UIView()
        plus.setImage(sym("plus", 22), for: .normal); plus.tintColor = .white
        plus.backgroundColor = accent; plus.layer.cornerRadius = 14
        plus.showsMenuAsPrimaryAction = true
        plus.translatesAutoresizingMaskIntoConstraints = false; chip.translatesAutoresizingMaskIntoConstraints = false
        bar.addSubview(chip); bar.addSubview(plus)
        NSLayoutConstraint.activate([
            chip.leadingAnchor.constraint(equalTo: bar.leadingAnchor, constant: 8), chip.centerYAnchor.constraint(equalTo: bar.centerYAnchor),
            plus.trailingAnchor.constraint(equalTo: bar.trailingAnchor), plus.centerYAnchor.constraint(equalTo: bar.centerYAnchor),
            plus.widthAnchor.constraint(equalToConstant: 64), plus.heightAnchor.constraint(equalToConstant: 46),
            bar.heightAnchor.constraint(equalToConstant: 52)])

        // timeline panel
        playBtn.tintColor = .white; playBtn.addTarget(self, action: #selector(playTap), for: .touchUpInside)
        let prev = btn("backward.end.fill", #selector(prevTap)), next = btn("forward.end.fill", #selector(nextTap))
        let key = btn("diamond", #selector(keyTap)); key.tintColor = accent
        timeLbl.textColor = .lightGray; timeLbl.font = .monospacedDigitSystemFont(ofSize: 13, weight: .medium)
        let row = UIStackView(arrangedSubviews: [playBtn, prev, next, UIView(), timeLbl, key])
        row.spacing = 18; row.alignment = .center
        slider.minimumTrackTintColor = accent
        slider.addTarget(self, action: #selector(slid), for: .valueChanged)
        slider.addTarget(self, action: #selector(slideStart), for: .touchDown)
        slider.addTarget(self, action: #selector(slideEnd), for: [.touchUpInside, .touchUpOutside, .touchCancel])
        let col = UIStackView(arrangedSubviews: [row, slider]); col.axis = .vertical; col.spacing = 10
        col.translatesAutoresizingMaskIntoConstraints = false
        tl.backgroundColor = UIColor(white: 0.08, alpha: 1); tl.layer.cornerRadius = 16
        tl.addSubview(col)
        NSLayoutConstraint.activate([
            col.leadingAnchor.constraint(equalTo: tl.leadingAnchor, constant: 14), col.trailingAnchor.constraint(equalTo: tl.trailingAnchor, constant: -14),
            col.centerYAnchor.constraint(equalTo: tl.centerYAnchor), tl.heightAnchor.constraint(equalToConstant: 92)])

        let stack = UIStackView(arrangedSubviews: [sv, bar, tl]); stack.axis = .vertical; stack.spacing = 8
        stack.translatesAutoresizingMaskIntoConstraints = false
        addSubview(stack)

        // left mode toolbar over the viewport
        let icons = ["hand.raised", "arrow.up.and.down.and.arrow.left.and.right", "arrow.up.left.and.arrow.down.right"]
        let tools = UIStackView(); tools.axis = .vertical; tools.spacing = 6
        tools.backgroundColor = UIColor(white: 0.1, alpha: 0.9); tools.layer.cornerRadius = 16
        tools.isLayoutMarginsRelativeArrangement = true; tools.layoutMargins = UIEdgeInsets(top: 6, left: 6, bottom: 6, right: 6)
        for (i, ic) in icons.enumerated() {
            let b = UIButton(type: .system); b.setImage(sym(ic), for: .normal); b.tintColor = .white
            b.layer.cornerRadius = 12; b.tag = i
            b.addTarget(self, action: #selector(modeTap(_:)), for: .touchUpInside)
            b.widthAnchor.constraint(equalToConstant: 48).isActive = true
            b.heightAnchor.constraint(equalToConstant: 48).isActive = true
            tools.addArrangedSubview(b); modeBtns.append(b)
        }
        tools.translatesAutoresizingMaskIntoConstraints = false
        addSubview(tools)

        NSLayoutConstraint.activate([
            header.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor), header.heightAnchor.constraint(equalToConstant: 52),
            header.leadingAnchor.constraint(equalTo: leadingAnchor), header.trailingAnchor.constraint(equalTo: trailingAnchor),
            stack.topAnchor.constraint(equalTo: header.bottomAnchor, constant: 4),
            stack.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 12), stack.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -12),
            stack.bottomAnchor.constraint(equalTo: safeAreaLayoutGuide.bottomAnchor, constant: -6),
            tools.leadingAnchor.constraint(equalTo: sv.leadingAnchor, constant: 8),
            tools.topAnchor.constraint(equalTo: sv.topAnchor, constant: 12)])
    }

    private func updateModeUI() {
        for (i, b) in modeBtns.enumerated() { b.backgroundColor = i == mode.rawValue ? accent : .clear }
        chip.text = mode == .still ? "Still  ·  view only" : (mode == .move ? "Edit Viewport  ·  Move" : "Edit Viewport  ·  Scale")
        if mode == .still { tint(nodes[selected], false); gizmo.isHidden = true }
        else { tint(nodes[selected], true) }
        buildGizmo()
    }

    @objc private func modeTap(_ b: UIButton) { mode = Mode(rawValue: b.tag) ?? .move; updateModeUI() }

    private func rebuildMenu() {
        func item(_ title: String, _ img: String, _ on: Bool?, _ h: @escaping () -> Void) -> UIAction {
            UIAction(title: title, image: UIImage(systemName: img), state: on == true ? .on : .off) { _ in h() }
        }
        plus.menu = UIMenu(children: [
            item("Import Model", "square.and.arrow.down", nil) { [weak self] in self?.host?.pickFile(R_GLB, glbTypes()) },
            item("3D Scene", "cube.transparent", syncScene) { [weak self] in self?.syncScene.toggle(); self?.rebuildMenu() },
            item("Grid", "grid", showGrid) { [weak self] in self?.showGrid.toggle(); self?.rebuildMenu() },
            item("Timeline", "timeline.selection", showTimeline) { [weak self] in self?.showTimeline.toggle(); self?.rebuildMenu() },
            item("Gizmo", "move.3d", showGizmo) { [weak self] in self?.showGizmo.toggle(); self?.rebuildMenu() }
        ])
    }

    // MARK: timeline actions (drive the main editor's playhead)
    @objc private func playTap() { host?.togglePlay() }
    @objc private func prevTap() { host?.onSeek(max(0, Editor.time - 1 / 30)) }
    @objc private func nextTap() { host?.onSeek(min(Editor.scene.duration, Editor.time + 1 / 30)) }
    @objc private func slideStart() { sliding = true }
    @objc private func slideEnd() { sliding = false }
    @objc private func slid() { host?.onSeek(slider.value) }

    /// Diamond: key the selected layer's position + scale at the playhead.
    @objc private func keyTap() {
        guard mode != .still, let l = layer(selected) else { return }
        host?.pushUndo()
        let t = Editor.time
        for k in ["x", "y", "z", "scale"] { l.track(k).set(t, l.p(k, t), true) }
        host?.render(); host?.refreshPanel()
    }
}
