// Scene3DView.swift — the "Scene 3D" screen opened from the cube button beside the preview.
//
// A SceneKit viewport that mirrors every 3D thing in the main editor (model layers, 3D-cube
// layers, camera layers) at the editor's current time. Modes (left toolbar):
//   Still  — look around only (orbit / pan / zoom). Nothing can be selected or edited.
//   Move   — tap selects; drag the selected layer (gizmo arrows constrain to an axis).
//   Scale  — tap selects; drag up / down on it to scale.
// "+" menu: Import Model, 3D Scene (sync on/off), Grid, Timeline (panel), Gizmo.
// Bottom panel: Timeline (tracks + keyframes) or Properties (Layer / Global settings).
// Edits write the same x / y / z / scale tracks the main editor uses (auto-key aware, undoable).
// Camera: 1 finger orbits (on empty space in edit modes), 2 fingers pan, pinch dollies.

import UIKit
import SceneKit
import OpenGLES

final class Scene3DView: UIView, UIGestureRecognizerDelegate {

    enum Mode: Int { case still = 0, move, scale }

    // MARK: state
    private weak var host: EditorViewController?
    private let scn = SCNScene()
    private let sv = SCNView()
    private let cam = SCNNode()
    private let world = SCNNode()
    private let gridNode = SCNNode()
    private let gizmo = SCNNode()
    private var nodes: [Int: SCNNode] = [:]
    private var sig = ""
    private var link: CADisplayLink?
    private var mode = Mode.move
    private var selected = -1
    private var lastHostSel = -2
    private var showGrid = true, showGizmo = true, showTimeline = true, syncScene = true
    private var yaw: Float = 0.6, pitch: Float = 0.35, dist: Float = 6
    private var target = simd_float3(0, 0, 0)
    private var drag = false, dragAxis = -1
    private var vdbSig = ""
    private var scLayer = -1
    private var lastTris: [Scatter.Tri] = []
    private var surfaceTris: [Int: [Scatter.Tri]] = [:]
    private var scInst: [Int: [SCNNode]] = [:]

    // UI
    private var modeBtns: [UIButton] = []
    private let chip = UILabel()
    private let plus = UIButton(type: .system)
    private let tl = UIView()                       // bottom panel (timeline or properties)
    private let timeLbl = UILabel()
    private let playBtn = UIButton(type: .system)
    private let canvas = TLCanvas()
    private let tlBox = UIView()
    private let propScroll = UIScrollView()
    private let propStack = UIStackView()
    private let tabSeg = UISegmentedControl(items: ["Timeline", "Properties", "Scatter"])
    private let scopeSeg = UISegmentedControl(items: ["Layer", "Global"])
    private var header = UIStackView()
    private var fullscreen = false
    private var known = Set<Int>(), built = false
    private var propKey = ""
    private var fsBtn: UIButton?
    private lazy var headerH: NSLayoutConstraint = header.heightAnchor.constraint(equalToConstant: 52)
    private var stackRef: UIStackView?
    private var vdbMats: [Int: SCNMaterial] = [:]
    private var panelH: NSLayoutConstraint!
    private let accent = UIColor(red: 1, green: 0.55, blue: 0.08, alpha: 1)

    // MARK: entry
    static func present(in host: EditorViewController) {
        if host.view.subviews.contains(where: { $0 is Scene3DView }) { return }
        let v = Scene3DView(host: host)
        v.translatesAutoresizingMaskIntoConstraints = false
        host.view.addSubview(v)
        NSLayoutConstraint.activate([
            v.leadingAnchor.constraint(equalTo: host.view.leadingAnchor),
            v.trailingAnchor.constraint(equalTo: host.view.trailingAnchor),
            v.topAnchor.constraint(equalTo: host.view.topAnchor),
            v.bottomAnchor.constraint(equalTo: host.view.bottomAnchor)])
    }

    init(host: EditorViewController) {
        self.host = host
        super.init(frame: .zero)
        backgroundColor = .black
        buildScene()
        buildUI()
        applyCam()
        updateModeUI()
        rebuildMenu()
        link = CADisplayLink(target: self, selector: #selector(tick))
        link?.preferredFramesPerSecond = 30
        link?.add(to: .main, forMode: .common)
    }
    required init?(coder: NSCoder) { fatalError() }

    override func willMove(toSuperview newSuperview: UIView?) {
        if newSuperview == nil { link?.invalidate(); link = nil }
    }

    @objc private func close() { removeFromSuperview() }

    // MARK: scene
    private func buildScene() {
        scn.background.contents = UIColor.black
        let c = SCNCamera(); c.fieldOfView = 50; c.zNear = 0.05; c.zFar = 300
        cam.camera = c
        scn.rootNode.addChildNode(cam)
        scn.rootNode.addChildNode(world)
        scn.rootNode.addChildNode(gridNode)
        scn.rootNode.addChildNode(gizmo)
        let amb = SCNNode(); amb.light = SCNLight(); amb.light?.type = .ambient; amb.light?.intensity = 650
        let sun = SCNNode(); sun.light = SCNLight(); sun.light?.type = .directional; sun.light?.intensity = 900
        sun.eulerAngles = SCNVector3(-0.8, 0.6, 0)
        scn.rootNode.addChildNode(amb); scn.rootNode.addChildNode(sun)

        // floor grid + red X / blue Z axes (like the inspiration screenshot)
        var g: [SCNVector3] = []
        for i in -10...10 where i != 0 {
            let f = Float(i)
            g += [SCNVector3(f, 0, -10), SCNVector3(f, 0, 10), SCNVector3(-10, 0, f), SCNVector3(10, 0, f)]
        }
        gridNode.addChildNode(lines(g, UIColor(white: 0.28, alpha: 1)))
        gridNode.addChildNode(lines([SCNVector3(-10, 0, 0), SCNVector3(10, 0, 0)], UIColor(red: 0.85, green: 0.25, blue: 0.25, alpha: 1)))
        gridNode.addChildNode(lines([SCNVector3(0, 0, -10), SCNVector3(0, 0, 10)], UIColor(red: 0.25, green: 0.5, blue: 0.95, alpha: 1)))
        buildGizmo()
    }

    private func lines(_ pts: [SCNVector3], _ color: UIColor) -> SCNNode {
        let src = SCNGeometrySource(vertices: pts)
        let el = SCNGeometryElement(indices: (0..<Int32(pts.count)).map { $0 }, primitiveType: .line)
        let geo = SCNGeometry(sources: [src], elements: [el])
        let m = SCNMaterial(); m.diffuse.contents = color; m.lightingModel = .constant
        geo.materials = [m]
        return SCNNode(geometry: geo)
    }

    private func buildGizmo() {
        gizmo.childNodes.forEach { $0.removeFromParentNode() }
        let cols = [UIColor(red: 1, green: 0.3, blue: 0.3, alpha: 1), UIColor(red: 0.3, green: 0.9, blue: 0.4, alpha: 1), UIColor(red: 0.3, green: 0.55, blue: 1, alpha: 1)]
        let rots = [SCNVector3(0, 0, -Float.pi / 2), SCNVector3(0, 0, 0), SCNVector3(Float.pi / 2, 0, 0)]
        for i in 0..<3 {
            let axis = SCNNode(); axis.eulerAngles = rots[i]
            let mat = SCNMaterial(); mat.diffuse.contents = cols[i]; mat.lightingModel = .constant; mat.readsFromDepthBuffer = false
            let shaft = SCNNode(geometry: SCNCylinder(radius: 0.025, height: 1)); shaft.position.y = 0.5
            let tipGeo: SCNGeometry = mode == .scale ? SCNBox(width: 0.14, height: 0.14, length: 0.14, chamferRadius: 0) : SCNCone(topRadius: 0, bottomRadius: 0.08, height: 0.24)
            let tip = SCNNode(geometry: tipGeo); tip.position.y = 1.1
            for n in [shaft, tip] { n.geometry?.materials = [mat]; n.name = "ax\(i)"; n.renderingOrder = 1000; axis.addChildNode(n) }
            gizmo.addChildNode(axis)
        }
    }

    // MARK: sync with the main editor
    private func is3dContent(_ l: Layer) -> Bool { l.type == .MODEL || l.type == .CAMERA || l.is3d }
    private func layer(_ id: Int) -> Layer? { Editor.scene.layers.first { $0.id == id } }

    private func rebuild() {
        world.childNodes.forEach { $0.removeFromParentNode() }
        nodes = [:]; vdbMats = [:]; scInst = [:]; surfaceTris = [:]
        for l in Editor.scene.layers where is3dContent(l) {
            let root = SCNNode(); root.name = "L\(l.id)"
            switch l.type {
            case .CAMERA: root.addChildNode(camShape())
            case .MODEL: lastTris = []; root.addChildNode(isVdb(l) ? vdbNode(l) : modelNode(l))
            default: lastTris = []; root.addChildNode(planeNode(l))
            }
            world.addChildNode(root)
            nodes[l.id] = root
            if l.type == .MODEL && !isVdb(l) || (l.type != .CAMERA && l.type != .MODEL) { surfaceTris[l.id] = lastTris }
        }
        if selected >= 0, nodes[selected] == nil { selected = -1 }
        let fresh = Set(nodes.keys).subtracting(known)
        known = Set(nodes.keys)
        if built, let id = fresh.first {              // just imported / added: show it
            if let l = layer(id) { nodes[id]?.simdTransform = xform(l, Editor.time) }
            if mode != .still { select(id, notifyHost: false) }
            frame(id)
        }
        built = true
        if mode != .still { tint(nodes[selected], true) }
    }

    private func camShape() -> SCNNode {
        let w: Float = 0.35, h: Float = 0.2, d: Float = -0.5
        let a = SCNVector3(-w, h, d), b = SCNVector3(w, h, d), c = SCNVector3(w, -h, d), e = SCNVector3(-w, -h, d), o = SCNVector3Zero
        return lines([o, a, o, b, o, c, o, e, a, b, b, c, c, e, e, a], UIColor.orange)
    }

    private func planeNode(_ l: Layer) -> SCNNode {
        let (qw, qh) = Xf.quadSize(l)
        let p = SCNPlane(width: CGFloat(max(qw, 0.05)), height: CGFloat(max(qh, 0.05)))
        let m = SCNMaterial(); m.isDoubleSided = true; m.lightingModel = .constant
        if let path = l.imagePath, let img = UIImage(contentsOfFile: path) { m.diffuse.contents = img }
        else { m.diffuse.contents = UIColor(white: 0.8, alpha: 0.35) }
        p.materials = [m]
        lastTris = Scatter.quad(Float(qw), Float(qh))
        return SCNNode(geometry: p)
    }

    private func modelNode(_ l: Layer) -> SCNNode {
        let holder = SCNNode()
        let old = GlbModel.cpuOnly
        GlbModel.cpuOnly = true
        let model = l.imagePath.flatMap { GlbModel.load(GlbModel.validate(path: $0)) }
        GlbModel.cpuOnly = old
        var built = false
        if let m = model {
            lastTris = Scatter.tris(m)
            for p in m.prims where !p.verts.isEmpty && p.mode != GLenum(GL_TRIANGLES) {   // point / line prims -> points
                let n = p.verts.count / 12
                let pts = (0..<n).map { SCNVector3(p.verts[$0 * 12], p.verts[$0 * 12 + 1], p.verts[$0 * 12 + 2]) }
                let g = SCNGeometry(sources: [SCNGeometrySource(vertices: pts)], elements: [SCNGeometryElement(indices: (0..<Int32(n)).map { $0 }, primitiveType: .point)])
                g.elements.first?.pointSize = 3; g.elements.first?.minimumPointScreenSpaceRadius = 1.5; g.elements.first?.maximumPointScreenSpaceRadius = 4
                let mt = SCNMaterial(); mt.diffuse.contents = UIColor.white; mt.lightingModel = .constant; g.materials = [mt]
                holder.addChildNode(SCNNode(geometry: g)); built = true
            }
            for p in m.prims where !p.verts.isEmpty && p.mode == GLenum(GL_TRIANGLES) {
                let vc = p.verts.count / 12
                let data = p.verts.withUnsafeBufferPointer { Data(buffer: $0) }
                func src(_ s: SCNGeometrySource.Semantic, _ comps: Int, _ off: Int) -> SCNGeometrySource {
                    SCNGeometrySource(data: data, semantic: s, vectorCount: vc, usesFloatComponents: true,
                                      componentsPerVector: comps, bytesPerComponent: 4, dataOffset: off * 4, dataStride: 48)
                }
                let idx: [UInt32] = p.cpuIdx.isEmpty ? (0..<UInt32(vc)).map { $0 } : p.cpuIdx
                let el = SCNGeometryElement(data: idx.withUnsafeBufferPointer { Data(buffer: $0) },
                                            primitiveType: .triangles, primitiveCount: idx.count / 3, bytesPerIndex: 4)
                let geo = SCNGeometry(sources: [src(.vertex, 3, 0), src(.normal, 3, 3), src(.texcoord, 2, 6)], elements: [el])
                let mat = SCNMaterial(); mat.isDoubleSided = true
                if p.texBase != 0, let img = GlbModel.cpuImages[p.texBase]?.img {
                    mat.diffuse.contents = img
                    mat.diffuse.contentsTransform = SCNMatrix4Translate(SCNMatrix4MakeScale(1, -1, 1), 0, 1, 0)
                    mat.diffuse.wrapS = .repeat; mat.diffuse.wrapT = .repeat
                } else {
                    mat.diffuse.contents = UIColor(red: CGFloat(p.color[0]), green: CGFloat(p.color[1]), blue: CGFloat(p.color[2]), alpha: 1)
                }
                geo.materials = [mat]
                holder.addChildNode(SCNNode(geometry: geo))
                built = true
            }
            // renderer-space normalisation: S(n0) · T(offset)
            let n = m.normalize
            holder.simdTransform = S(n[0]) * T(n[1], n[2], n[3])
        }
        if !built {   // .vdb / animated / unreadable: a placeholder box so it can still be placed
            let b = SCNBox(width: 1, height: 1, length: 1, chamferRadius: 0)
            let m = SCNMaterial(); m.diffuse.contents = UIColor(white: 0.7, alpha: 0.3); m.fillMode = .lines; m.lightingModel = .constant
            b.materials = [m]
            holder.addChildNode(SCNNode(geometry: b))
        }
        return holder
    }

    private func isVdb(_ l: Layer) -> Bool { (l.imagePath ?? "").lowercased().hasSuffix(".vdb") }

    /// VDB preview: the density lattice as a point cloud (density threshold + point budget are global settings).
    private func vdbNode(_ l: Layer) -> SCNNode {
        let node = SCNNode()
        guard let path = l.imagePath, let vol = VdbVolume.load(path), let g = vol.grids.first, g.nx > 0, g.ny > 0, g.nz > 0 else {
            let b = SCNBox(width: 1, height: 1, length: 1, chamferRadius: 0)
            let m = SCNMaterial(); m.diffuse.contents = UIColor.orange; m.fillMode = .lines; m.lightingModel = .constant; b.materials = [m]
            node.addChildNode(SCNNode(geometry: b)); return node
        }
        let mx = max(g.data.max() ?? 1, 1e-6)
        let maxPts = Int(90000 * R3D.g("vpPts", 1))
        let step = max(1, Int(ceil(cbrt(Double(g.nx * g.ny * g.nz) / Double(max(maxPts, 1000))))))
        let th = R3D.g("vpThresh", 0.06)
        var pos: [SCNVector3] = [], col: [Float] = []
        let b = vol.bounds
        for z in stride(from: 0, to: g.nz, by: step) { for y in stride(from: 0, to: g.ny, by: step) { for x in stride(from: 0, to: g.nx, by: step) {
            let d = g.data[x + g.nx * (y + g.ny * z)] / mx
            if d > th {
                pos.append(SCNVector3((Float(x) + 0.5) / Float(g.nx) * 2 * max(b.0, 0.05) - max(b.0, 0.05),
                                      (Float(y) + 0.5) / Float(g.ny) * 2 * max(b.1, 0.05) - max(b.1, 0.05),
                                      (Float(z) + 0.5) / Float(g.nz) * 2 * max(b.2, 0.05) - max(b.2, 0.05)))
                let c = min(1, sqrt(d)); col += [c, c, c, c]
            }
        } } }
        if pos.isEmpty { return node }
        let colData = col.withUnsafeBufferPointer { Data(buffer: $0) }
        let colSrc = SCNGeometrySource(data: colData, semantic: .color, vectorCount: pos.count, usesFloatComponents: true,
                                       componentsPerVector: 4, bytesPerComponent: 4, dataOffset: 0, dataStride: 16)
        let el = SCNGeometryElement(indices: (0..<Int32(pos.count)).map { $0 }, primitiveType: .point)
        el.pointSize = 2; el.minimumPointScreenSpaceRadius = 1.5; el.maximumPointScreenSpaceRadius = 5
        let geo = SCNGeometry(sources: [SCNGeometrySource(vertices: pos), colSrc], elements: [el])
        let m = SCNMaterial(); m.lightingModel = .constant; m.blendMode = .add; m.writesToDepthBuffer = false; m.isDoubleSided = true
        geo.materials = [m]
        node.addChildNode(SCNNode(geometry: geo))
        vdbMats[l.id] = m
        styleVdb(m, l)
        return node
    }

    private func styleVdb(_ m: SCNMaterial, _ l: Layer) {
        let c = UInt32(bitPattern: l.vdbTint)
        let br = CGFloat(l.vdbBright * R3D.g("vdbBright", 1))
        m.diffuse.contents = UIColor(red: CGFloat((c >> 16) & 255) / 255 * br, green: CGFloat((c >> 8) & 255) / 255 * br, blue: CGFloat(c & 255) / 255 * br, alpha: 1)
        m.transparency = CGFloat(min(1, 0.25 * l.vdbDens * R3D.g("vdbDens", 1) * l.xf("vdbOpacity", 1)))
    }

    /// Centre the orbit camera on a layer.
    private func frame(_ id: Int) {
        guard let n = nodes[id] else { return }
        target = n.simdWorldPosition
        dist = 3.5
        applyCam()
    }

    /// Scatter preview: clones of each scattered model, placed exactly like the renderer places them.
    private func updateScatter(_ t: Float) {
        for l in Editor.scene.layers where l.type == .MODEL && !isVdb(l) {
            guard let root = nodes[l.id] else { continue }
            var mats: [simd_float4x4]? = nil
            if syncScene, l.xf("scOn", 0) > 0.5, let tl = layer(Int(l.xf("scTarget", -1))), tl.id != l.id,
               let tn = nodes[tl.id], let tris = surfaceTris[tl.id] {
                let norm = tl.type == .MODEL ? (tn.childNodes.first?.simdTransform ?? matrix_identity_float4x4) : matrix_identity_float4x4
                mats = Scatter.instances(l, target: tl, tris: tris, targetM: xform(tl, t) * norm, time: t)
            }
            var pool = scInst[l.id] ?? []
            guard let m = mats, let holder = root.childNodes.first else {
                pool.forEach { $0.removeFromParentNode() }; scInst[l.id] = nil; continue
            }
            let visible = syncScene && l.visible && t >= l.start && t <= l.end
            if l.xf("scKeep", 0) < 0.5 { root.isHidden = true }
            while pool.count > m.count { pool.removeLast().removeFromParentNode() }
            while pool.count < m.count {
                let n = SCNNode(); n.addChildNode(holder.clone()); world.addChildNode(n); pool.append(n)
                if mode != .still, l.id == selected { tint(n, true) }
            }
            for (i, n) in pool.enumerated() { n.simdTransform = m[i]; n.isHidden = !visible }
            scInst[l.id] = pool
        }
    }

    // matrix helpers
    private func T(_ x: Float, _ y: Float, _ z: Float) -> simd_float4x4 { var m = matrix_identity_float4x4; m.columns.3 = simd_float4(x, y, z, 1); return m }
    private func S(_ s: Float) -> simd_float4x4 { simd_float4x4(diagonal: simd_float4(s, s, s, 1)) }
    private func R(_ deg: Float, _ axis: simd_float3) -> simd_float4x4 { simd_float4x4(simd_quatf(angle: deg * .pi / 180, axis: axis)) }

    /// Same maths as MetalCam.modelMatrix: T(pos) · Rz · Rx · Ry · S(scale).
    private func xform(_ l: Layer, _ t: Float) -> simd_float4x4 {
        let lt = l.editTime("x", t)
        let x = l.p("x", lt), y = l.p("y", lt)
        var z = Xf.worldZ(l, t)
        let rot = R(l.p("rotZ", lt), simd_float3(0, 0, 1)) * R(l.p("rotX", lt), simd_float3(1, 0, 0)) * R(l.p("rotY", lt), simd_float3(0, 1, 0))
        if l.type == .CAMERA {
            var fov = l.p("fov", lt); if !fov.isFinite || fov < 10 { fov = 55 }
            z += 1 / tan(min(fov, 150) * Float.pi / 360)
            return T(x, y, z) * rot
        }
        let sc = l.p("scale", lt)
        return T(x, y, z) * rot * simd_float4x4(diagonal: simd_float4(sc, sc, sc * (l.type == .MODEL ? l.p("scaleZ", lt) : 1), 1))
    }

    @objc private func tick() {
        guard let host = host else { return }
        let s = Editor.scene.layers.filter(is3dContent).map { "\($0.id)|\($0.type.rawValue)|\($0.imagePath ?? "")" }.joined(separator: ",") + "|\(R3D.g("vpPts", 1))|\(R3D.g("vpThresh", 0.06))"
        if s != sig { sig = s; rebuild() }
        if host.selId != lastHostSel {
            lastHostSel = host.selId
            if mode != .still { select(nodes[host.selId] != nil ? host.selId : -1, notifyHost: false) }
        }
        let t = Editor.time
        for l in Editor.scene.layers {
            guard let n = nodes[l.id] else { continue }
            n.isHidden = !syncScene || !l.visible || t < l.start || t > l.end
            n.simdTransform = xform(l, t)
        }
        updateScatter(t)
        gridNode.isHidden = !showGrid
        updateGizmo()
        tl.isHidden = !showTimeline || fullscreen
        let dur = max(Editor.scene.duration, 0.1)
        timeLbl.text = String(format: "%.2f / %.1fs", t, dur)
        playBtn.setImage(UIImage(systemName: host.playing ? "pause.fill" : "play.fill"), for: .normal)
        cam.camera?.fieldOfView = CGFloat(R3D.g("vpFov", 50))
        if !tl.isHidden {
            if tabSeg.selectedSegmentIndex == 0 {
                canvas.rows = Editor.scene.layers.filter(is3dContent)
                canvas.selected = selected; canvas.time = t; canvas.dur = dur
                canvas.setNeedsDisplay()
            } else {
                let k = "\(tabSeg.selectedSegmentIndex)|\(scopeSeg.selectedSegmentIndex)|\(selected)|\(scLayer)"
                if k != propKey { propKey = k; rebuildProps() }
            }
        }
        for (id, m) in vdbMats { if let l = layer(id) { styleVdb(m, l) } }
    }

    private func updateGizmo() {
        guard mode != .still, showGizmo, let n = nodes[selected], !n.isHidden else { gizmo.isHidden = true; return }
        gizmo.isHidden = false
        gizmo.simdPosition = n.simdWorldPosition
        let s = simd_length(gizmo.simdPosition - cam.simdWorldPosition) * R3D.g("vpGizmo", 0.14)
        gizmo.simdScale = simd_float3(repeating: max(s, 0.05))
    }

    // MARK: selection
    private func tint(_ n: SCNNode?, _ on: Bool) {
        n?.enumerateChildNodes { c, _ in
            c.geometry?.materials.forEach { $0.emission.contents = on ? UIColor(red: 0, green: 0.22, blue: 0.5, alpha: 1) : UIColor.black }
        }
    }

    private func select(_ id: Int, notifyHost: Bool = true) {
        tint(nodes[selected], false)
        selected = id
        if mode != .still { tint(nodes[id], true) }
        if notifyHost, id >= 0 { lastHostSel = id; host?.onSelect(id) }
    }

    private func pick(_ p: CGPoint) -> (Int, Int)? {
        let hits = sv.hitTest(p, options: [.searchMode: SCNHitTestSearchMode.all.rawValue])
        var axis = -1
        var lid: Int? = nil
        for h in hits {
            var n: SCNNode? = h.node
            while let c = n {
                if let nm = c.name {
                    if nm.hasPrefix("ax"), selected >= 0, axis < 0 { axis = Int(nm.dropFirst(2)) ?? -1 }
                    if nm.hasPrefix("L"), lid == nil, let i = Int(nm.dropFirst()) { lid = i }
                }
                n = c.parent
            }
        }
        if axis >= 0 && selected >= 0 { return (selected, axis) }
        if let l = lid { return (l, -1) }
        return nil
    }

    // MARK: camera + gestures
    private func applyCam() {
        let cp = cosf(pitch), sp = sinf(pitch)
        cam.simdPosition = target + dist * simd_float3(cp * sinf(yaw), sp, cp * cosf(yaw))
        cam.simdLook(at: target, up: simd_float3(0, 1, 0), localFront: simd_float3(0, 0, -1))
    }

    private func installGestures() {
        let p1 = UIPanGestureRecognizer(target: self, action: #selector(pan1(_:))); p1.maximumNumberOfTouches = 1
        let p2 = UIPanGestureRecognizer(target: self, action: #selector(pan2(_:))); p2.minimumNumberOfTouches = 2; p2.maximumNumberOfTouches = 2
        let pc = UIPinchGestureRecognizer(target: self, action: #selector(pinch(_:)))
        let tp = UITapGestureRecognizer(target: self, action: #selector(tapped(_:)))
        for g in [p1, p2, pc, tp] { g.delegate = self; sv.addGestureRecognizer(g) }
    }

    func gestureRecognizer(_ a: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith b: UIGestureRecognizer) -> Bool { true }

    @objc private func pan1(_ g: UIPanGestureRecognizer) {
        switch g.state {
        case .began:
            drag = false; dragAxis = -1
            if mode != .still {
                let p = g.location(in: sv), tr = g.translation(in: sv)
                if let h = pick(CGPoint(x: p.x - tr.x, y: p.y - tr.y)) {
                    if h.0 != selected { select(h.0) }
                    dragAxis = h.1; drag = true
                    host?.pushUndo()
                }
            }
        case .changed:
            let d = g.translation(in: sv); g.setTranslation(.zero, in: sv)
            if drag { applyDrag(d) } else {
                yaw -= Float(d.x) * 0.01
                pitch = max(-1.5, min(1.5, pitch + Float(d.y) * 0.01))
                applyCam()
            }
        default:
            if drag { drag = false; host?.render(); host?.refreshPanel() }
        }
    }

    @objc private func pan2(_ g: UIPanGestureRecognizer) {
        guard g.state == .changed else { return }
        let d = g.translation(in: sv); g.setTranslation(.zero, in: sv)
        let k = 2 * dist * tanf(Float(cam.camera?.fieldOfView ?? 50) * .pi / 360) / Float(max(sv.bounds.height, 1))
        target += (-cam.simdWorldRight * Float(d.x) + cam.simdWorldUp * Float(d.y)) * k
        applyCam()
    }

    @objc private func pinch(_ g: UIPinchGestureRecognizer) {
        guard g.state == .changed else { return }
        dist = max(0.5, min(60, dist / Float(max(g.scale, 0.01))))
        g.scale = 1
        applyCam()
    }

    @objc private func tapped(_ g: UITapGestureRecognizer) {
        guard mode != .still else { return }
        if let h = pick(g.location(in: sv)) { select(h.0) } else { select(-1); host?.onSelect(-1) }
    }

    private func applyDrag(_ d: CGPoint) {
        guard let l = layer(selected), let n = nodes[selected] else { return }
        let t = Editor.time, ak = host?.autoKeyOn ?? false
        if mode == .scale {
            let f = 1 - Float(d.y) * 0.006
            l.track("scale").set(t, max(0.01, l.p("scale", t) * f), ak)
            return
        }
        let pos = n.simdWorldPosition
        var dw = simd_float3(0, 0, 0)
        if dragAxis >= 0 {
            let dir = [simd_float3(1, 0, 0), simd_float3(0, 1, 0), simd_float3(0, 0, 1)][dragAxis]
            let a = sv.projectPoint(SCNVector3(pos)), b = sv.projectPoint(SCNVector3(pos + dir))
            let sx = CGFloat(b.x - a.x), sy = CGFloat(b.y - a.y)
            let den = Float(sx * sx + sy * sy)
            if den > 1e-4 { dw = dir * Float(d.x * sx + d.y * sy) / den }
        } else {
            let dd = simd_length(pos - cam.simdWorldPosition)
            let k = 2 * dd * tanf(Float(cam.camera?.fieldOfView ?? 50) * .pi / 360) / Float(max(sv.bounds.height, 1))
            dw = cam.simdWorldRight * Float(d.x) * k - cam.simdWorldUp * Float(d.y) * k
        }
        l.track("x").set(t, l.p("x", t) + dw.x, ak)
        l.track("y").set(t, l.p("y", t) + dw.y, ak)
        l.track("z").set(t, l.p("z", t) + dw.z, ak)
    }

    // MARK: UI
    private func sym(_ name: String, _ size: CGFloat = 20) -> UIImage? {
        UIImage(systemName: name, withConfiguration: UIImage.SymbolConfiguration(pointSize: size, weight: .regular))
    }

    private func btn(_ name: String, _ sel: Selector) -> UIButton {
        let b = UIButton(type: .system)
        b.setImage(sym(name), for: .normal); b.tintColor = .white
        b.addTarget(self, action: sel, for: .touchUpInside)
        return b
    }

    private func buildUI() {
        // header
        let back = btn("chevron.left", #selector(close))
        let cube = UIImageView(image: sym("cube", 22)); cube.tintColor = .white
        let title = UILabel(); title.text = "Scene 3D"; title.textColor = .white; title.font = .systemFont(ofSize: 22, weight: .bold)
        let x = btn("xmark", #selector(close))
        header = UIStackView(arrangedSubviews: [back, cube, title, UIView(), x])
        header.spacing = 12; header.alignment = .center
        header.isLayoutMarginsRelativeArrangement = true
        header.layoutMargins = UIEdgeInsets(top: 0, left: 14, bottom: 0, right: 14)
        header.translatesAutoresizingMaskIntoConstraints = false
        addSubview(header)

        // viewport
        sv.scene = scn; sv.pointOfView = cam
        sv.backgroundColor = .black; sv.antialiasingMode = .multisampling4X
        sv.layer.cornerRadius = 22; sv.layer.masksToBounds = true
        sv.rendersContinuously = true
        installGestures()

        // bottom bar: mode chip (left) + plus menu (right)
        chip.textColor = .white; chip.font = .systemFont(ofSize: 17)
        let bar = UIView()
        plus.setImage(sym("plus", 22), for: .normal); plus.tintColor = .white
        plus.backgroundColor = accent; plus.layer.cornerRadius = 14
        plus.showsMenuAsPrimaryAction = true
        plus.translatesAutoresizingMaskIntoConstraints = false; chip.translatesAutoresizingMaskIntoConstraints = false
        bar.addSubview(chip); bar.addSubview(plus)
        NSLayoutConstraint.activate([
            chip.leadingAnchor.constraint(equalTo: bar.leadingAnchor, constant: 8), chip.centerYAnchor.constraint(equalTo: bar.centerYAnchor),
            plus.trailingAnchor.constraint(equalTo: bar.trailingAnchor), plus.centerYAnchor.constraint(equalTo: bar.centerYAnchor),
            plus.widthAnchor.constraint(equalToConstant: 64), plus.heightAnchor.constraint(equalToConstant: 46),
            bar.heightAnchor.constraint(equalToConstant: 52)])

        // bottom panel: timeline or properties
        tabSeg.selectedSegmentIndex = 0
        tabSeg.selectedSegmentTintColor = accent
        tabSeg.setTitleTextAttributes([.foregroundColor: UIColor.black], for: .selected)
        tabSeg.setTitleTextAttributes([.foregroundColor: UIColor.white], for: .normal)
        tabSeg.addAction(UIAction { [weak self] _ in self?.tabChanged() }, for: .valueChanged)
        tabSeg.translatesAutoresizingMaskIntoConstraints = false
        bar.addSubview(tabSeg)
        NSLayoutConstraint.activate([tabSeg.centerXAnchor.constraint(equalTo: bar.centerXAnchor), tabSeg.centerYAnchor.constraint(equalTo: bar.centerYAnchor), tabSeg.widthAnchor.constraint(equalToConstant: 250)])
        chip.isHidden = true

        playBtn.tintColor = .white; playBtn.addTarget(self, action: #selector(playTap), for: .touchUpInside)
        let prev = btn("backward.end.fill", #selector(prevKey)), next = btn("forward.end.fill", #selector(nextKey))
        let key = btn("diamond", #selector(keyTap)); key.tintColor = accent
        let del = btn("diamond.fill", #selector(delKey)); del.tintColor = .systemRed
        timeLbl.textColor = .lightGray; timeLbl.font = .monospacedDigitSystemFont(ofSize: 13, weight: .medium)
        let row = UIStackView(arrangedSubviews: [playBtn, prev, next, UIView(), timeLbl, key, del])
        row.spacing = 18; row.alignment = .center
        canvas.onSeek = { [weak self] t in self?.host?.onSeek(t) }
        canvas.onSelect = { [weak self] id in self?.select(id) }
        canvas.backgroundColor = UIColor(white: 0.05, alpha: 1); canvas.layer.cornerRadius = 10; canvas.clipsToBounds = true
        let col = UIStackView(arrangedSubviews: [row, canvas]); col.axis = .vertical; col.spacing = 8
        col.translatesAutoresizingMaskIntoConstraints = false
        tlBox.addSubview(col); tlBox.translatesAutoresizingMaskIntoConstraints = false
        scopeSeg.selectedSegmentIndex = 0
        scopeSeg.selectedSegmentTintColor = accent
        scopeSeg.setTitleTextAttributes([.foregroundColor: UIColor.black], for: .selected)
        scopeSeg.setTitleTextAttributes([.foregroundColor: UIColor.white], for: .normal)
        scopeSeg.addAction(UIAction { [weak self] _ in self?.propKey = "" }, for: .valueChanged)
        propStack.axis = .vertical; propStack.spacing = 10
        propStack.translatesAutoresizingMaskIntoConstraints = false; propScroll.translatesAutoresizingMaskIntoConstraints = false
        propScroll.addSubview(propStack); propScroll.isHidden = true
        scopeSeg.isHidden = true; scopeSeg.translatesAutoresizingMaskIntoConstraints = false
        tl.addSubview(tlBox); tl.addSubview(scopeSeg); tl.addSubview(propScroll)
        tl.backgroundColor = UIColor(white: 0.08, alpha: 1); tl.layer.cornerRadius = 16
        panelH = tl.heightAnchor.constraint(equalToConstant: 300)
        NSLayoutConstraint.activate([
            panelH,
            col.leadingAnchor.constraint(equalTo: tlBox.leadingAnchor), col.trailingAnchor.constraint(equalTo: tlBox.trailingAnchor),
            col.topAnchor.constraint(equalTo: tlBox.topAnchor), col.bottomAnchor.constraint(equalTo: tlBox.bottomAnchor),
            tlBox.leadingAnchor.constraint(equalTo: tl.leadingAnchor, constant: 12), tlBox.trailingAnchor.constraint(equalTo: tl.trailingAnchor, constant: -12),
            tlBox.topAnchor.constraint(equalTo: tl.topAnchor, constant: 10), tlBox.bottomAnchor.constraint(equalTo: tl.bottomAnchor, constant: -10),
            scopeSeg.topAnchor.constraint(equalTo: tl.topAnchor, constant: 10), scopeSeg.centerXAnchor.constraint(equalTo: tl.centerXAnchor), scopeSeg.widthAnchor.constraint(equalToConstant: 200),
            propScroll.topAnchor.constraint(equalTo: scopeSeg.bottomAnchor, constant: 8), propScroll.bottomAnchor.constraint(equalTo: tl.bottomAnchor),
            propScroll.leadingAnchor.constraint(equalTo: tl.leadingAnchor), propScroll.trailingAnchor.constraint(equalTo: tl.trailingAnchor),
            propStack.topAnchor.constraint(equalTo: propScroll.contentLayoutGuide.topAnchor), propStack.bottomAnchor.constraint(equalTo: propScroll.contentLayoutGuide.bottomAnchor, constant: -16),
            propStack.leadingAnchor.constraint(equalTo: propScroll.frameLayoutGuide.leadingAnchor, constant: 14), propStack.trailingAnchor.constraint(equalTo: propScroll.frameLayoutGuide.trailingAnchor, constant: -14),
            propStack.widthAnchor.constraint(equalTo: propScroll.frameLayoutGuide.widthAnchor, constant: -28)])

        // viewport corner buttons: fullscreen + frame selected
        let fs = btn("arrow.up.left.and.arrow.down.right", #selector(toggleFull)); fs.tag = 77
        let fr = btn("scope", #selector(frameSel))
        let corner = UIStackView(arrangedSubviews: [fs, fr]); corner.axis = .vertical; corner.spacing = 4
        corner.backgroundColor = UIColor(white: 0.1, alpha: 0.9); corner.layer.cornerRadius = 14
        for b in [fs, fr] { b.widthAnchor.constraint(equalToConstant: 44).isActive = true; b.heightAnchor.constraint(equalToConstant: 44).isActive = true }
        corner.translatesAutoresizingMaskIntoConstraints = false
        addSubview(corner)
        NSLayoutConstraint.activate([corner.trailingAnchor.constraint(equalTo: sv.trailingAnchor, constant: -8), corner.topAnchor.constraint(equalTo: sv.topAnchor, constant: 12)])
        fsBtn = fs

        let stack = UIStackView(arrangedSubviews: [sv, bar, tl]); stack.axis = .vertical; stack.spacing = 8
        stackRef = stack
        stack.translatesAutoresizingMaskIntoConstraints = false
        addSubview(stack)

        // left mode toolbar over the viewport
        let icons = ["hand.raised", "arrow.up.and.down.and.arrow.left.and.right", "arrow.up.left.and.arrow.down.right"]
        let tools = UIStackView(); tools.axis = .vertical; tools.spacing = 6
        tools.backgroundColor = UIColor(white: 0.1, alpha: 0.9); tools.layer.cornerRadius = 16
        tools.isLayoutMarginsRelativeArrangement = true; tools.layoutMargins = UIEdgeInsets(top: 6, left: 6, bottom: 6, right: 6)
        for (i, ic) in icons.enumerated() {
            let b = UIButton(type: .system); b.setImage(sym(ic), for: .normal); b.tintColor = .white
            b.layer.cornerRadius = 12; b.tag = i
            b.addTarget(self, action: #selector(modeTap(_:)), for: .touchUpInside)
            b.widthAnchor.constraint(equalToConstant: 48).isActive = true
            b.heightAnchor.constraint(equalToConstant: 48).isActive = true
            tools.addArrangedSubview(b); modeBtns.append(b)
        }
        tools.translatesAutoresizingMaskIntoConstraints = false
        addSubview(tools)

        NSLayoutConstraint.activate([
            header.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor), headerH,
            header.leadingAnchor.constraint(equalTo: leadingAnchor), header.trailingAnchor.constraint(equalTo: trailingAnchor),
            stack.topAnchor.constraint(equalTo: header.bottomAnchor, constant: 4),
            stack.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 12), stack.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -12),
            stack.bottomAnchor.constraint(equalTo: safeAreaLayoutGuide.bottomAnchor, constant: -6),
            tools.leadingAnchor.constraint(equalTo: sv.leadingAnchor, constant: 8),
            tools.topAnchor.constraint(equalTo: sv.topAnchor, constant: 12)])
    }

    private func updateModeUI() {
        for (i, b) in modeBtns.enumerated() { b.backgroundColor = i == mode.rawValue ? accent : .clear }
        chip.text = mode == .still ? "Still  ·  view only" : (mode == .move ? "Edit Viewport  ·  Move" : "Edit Viewport  ·  Scale")
        if mode == .still { tint(nodes[selected], false); gizmo.isHidden = true }
        else { tint(nodes[selected], true) }
        buildGizmo()
    }

    @objc private func modeTap(_ b: UIButton) { mode = Mode(rawValue: b.tag) ?? .move; updateModeUI() }

    private func rebuildMenu() {
        func item(_ title: String, _ img: String, _ on: Bool?, _ h: @escaping () -> Void) -> UIAction {
            UIAction(title: title, image: UIImage(systemName: img), state: on == true ? .on : .off) { _ in h() }
        }
        plus.menu = UIMenu(children: [
            item("Import Model", "square.and.arrow.down", nil) { [weak self] in self?.host?.pickFile(R_GLB, glbTypes()) },
            item("3D Scene", "cube.transparent", syncScene) { [weak self] in self?.syncScene.toggle(); self?.rebuildMenu() },
            item("Grid", "grid", showGrid) { [weak self] in self?.showGrid.toggle(); self?.rebuildMenu() },
            item("Timeline", "timeline.selection", showTimeline) { [weak self] in self?.showTimeline.toggle(); self?.rebuildMenu() },
            item("Gizmo", "move.3d", showGizmo) { [weak self] in self?.showGizmo.toggle(); self?.rebuildMenu() }
        ])
    }

    // MARK: timeline actions (drive the main editor's playhead)
    @objc private func playTap() { host?.togglePlay() }

    private func keyTimes(_ l: Layer) -> [Float] {
        var ts = Set<Float>()
        for k in ["x", "y", "z", "scale", "rotX", "rotY", "rotZ", "fov"] { for key in l.track(k).keys { ts.insert((key.t * 1000).rounded() / 1000) } }
        return ts.sorted()
    }
    @objc private func prevKey() {
        let t = Editor.time
        if let l = layer(selected), let k = keyTimes(l).last(where: { $0 < t - 0.01 }) { host?.onSeek(k) } else { host?.onSeek(max(0, t - 1 / 30)) }
    }
    @objc private func nextKey() {
        let t = Editor.time
        if let l = layer(selected), let k = keyTimes(l).first(where: { $0 > t + 0.01 }) { host?.onSeek(k) } else { host?.onSeek(min(Editor.scene.duration, t + 1 / 30)) }
    }

    /// Diamond: key the selected layer's position + scale + rotation at the playhead.
    @objc private func keyTap() {
        guard mode != .still, let l = layer(selected) else { return }
        host?.pushUndo()
        let t = Editor.time
        let ks = l.type == .CAMERA ? ["x", "y", "z", "rotX", "rotY", "rotZ", "fov"] 
            : ["x", "y", "z", "scale", "rotX", "rotY", "rotZ"] + (l.type == .MODEL ? ["scaleZ"] : [])
        for k in ks { l.track(k).set(t, l.p(k, t), true) }
        host?.render(); host?.refreshPanel()
    }
    @objc private func delKey() {
        guard let l = layer(selected) else { return }
        host?.pushUndo()
        let t = Editor.time
        for k in ["x", "y", "z", "scale", "rotX", "rotY", "rotZ", "fov"] { l.track(k).keys.removeAll { abs($0.t - t) < 0.03 } }
        host?.render(); host?.refreshPanel()
    }

    // MARK: fullscreen / panel
    @objc private func toggleFull() {
        fullscreen.toggle()
        header.isHidden = fullscreen; headerH.constant = fullscreen ? 0 : 52
        sv.layer.cornerRadius = fullscreen ? 0 : 22
        fsBtn?.setImage(sym(fullscreen ? "arrow.down.right.and.arrow.up.left" : "arrow.up.left.and.arrow.down.right"), for: .normal)
        UIView.animate(withDuration: 0.2) { self.layoutIfNeeded() }
    }
    @objc private func frameSel() { frame(selected >= 0 ? selected : (nodes.keys.first ?? -1)) }

    private func tabChanged() {
        let i = tabSeg.selectedSegmentIndex, p = i != 0
        tlBox.isHidden = p; propScroll.isHidden = !p; scopeSeg.isHidden = i != 1
        propKey = ""
    }
}

// MARK: - Properties panel (Layer / Global)

extension Scene3DView {

    fileprivate func rebuildProps() {
        propStack.arrangedSubviews.forEach { propStack.removeArrangedSubview($0); $0.removeFromSuperview() }
        if tabSeg.selectedSegmentIndex == 2 { scatterProps(); return }
        if scopeSeg.selectedSegmentIndex == 1 { globalProps(); return }
        guard let l = layer(selected) else { add(note("Select a 3D layer (tap it in Move / Scale mode, or in the timeline).")); return }
        let t = Editor.time
        let vdb = isVdbLayer(l)
        add(head("\(l.name)  ·  \(vdb ? "VDB volume" : l.type.rawValue.capitalized)"))
        add(sw("Visible", l.visible) { [weak self] v in self?.host?.pushUndo(); l.visible = v; self?.host?.render() })

        add(head("Transform"))
        let ak = { [weak self] in self?.host?.autoKeyOn ?? false }
        func tr(_ n: String, _ k: String, _ lo: Float, _ hi: Float) {
            add(sl(n, lo, hi, l.p(k, t)) { l.track(k).set(Editor.time, $0, ak()) })
        }
        tr("Position X", "x", -4, 4); tr("Position Y", "y", -4, 4); tr("Position Z", "z", -10, 10)
        if l.type != .CAMERA {
            // log slider: 0.01 ... 100000 (the on-screen drag and the main editor are unbounded too)
            func logRow(_ n: String, _ k: String) {
                let cur = max(abs(l.p(k, t)), 0.01)
                add(sl(n, 0, 7, log10(cur / 0.01), "%.2f") { l.track(k).set(Editor.time, 0.01 * powf(10, $0), ak()) })
            }
            logRow("Scale (log, 0.01 – 100000)", "scale")
            if l.type == .MODEL { logRow("Scale Z / depth (log)", "scaleZ") }
        }
        tr("Rotate X", "rotX", -180, 180); tr("Rotate Y", "rotY", -180, 180); tr("Rotate Z", "rotZ", -180, 180)
        if l.type == .CAMERA { tr("Field of view", "fov", 10, 150) }

        add(head("Timing"))
        let dur = max(Editor.scene.duration, 1)
        add(sl("Start (s)", 0, dur, l.start) { l.start = min($0, l.end - 0.05) })
        add(sl("End (s)", 0, dur, l.end) { l.end = max($0, l.start + 0.05) })

        if l.type == .MODEL && !vdb {
            add(head("Material & light"))
            add(seg("View", ["Final", "Base", "Rough", "Metal", "Occl", "Emis"], l.m3View) { [weak self] i in self?.host?.pushUndo(); l.m3View = i; self?.host?.render() })
            add(sw("Environment light", l.m3Env) { [weak self] v in self?.host?.pushUndo(); l.m3Env = v; self?.host?.render() })
            add(sw("Metallic reflectivity", l.m3Metal) { [weak self] v in self?.host?.pushUndo(); l.m3Metal = v; self?.host?.render() })
            add(sw("Ambient occlusion texture", l.m3Ao) { [weak self] v in self?.host?.pushUndo(); l.m3Ao = v; self?.host?.render() })
            add(sw("Occluded by other models", l.occlude) { [weak self] v in self?.host?.pushUndo(); l.occlude = v; self?.host?.render() })
            add(sl("Light intensity", 0, 3, l.xf("light", 1)) { l.xset("light", $0) })
            add(sl("Environment intensity", 0, 3, l.xf("env", 1)) { l.xset("env", $0) })
            add(sl("Exposure", 0.2, 3, l.xf("exposure", 1)) { l.xset("exposure", $0) })
        }
        if vdb {
            add(head("VDB volume"))
            add(sl("Density", 0, 5, l.vdbDens) { l.vdbDens = $0 })
            add(sl("Brightness", 0, 5, l.vdbBright) { l.vdbBright = $0 })
            add(sl("Opacity", 0, 1, l.xf("vdbOpacity", 1)) { l.xset("vdbOpacity", $0) })
            add(sl("Contrast", 0.2, 3, l.xf("vdbContrast", 1)) { l.xset("vdbContrast", $0) })
            add(sl("Self-shadow", 0, 2, l.xf("vdbShadow", 1)) { l.xset("vdbShadow", $0) })
            add(sl("Quality (ray steps)", 16, 160, l.xf("vdbSteps", 56), "%.0f") { l.xset("vdbSteps", $0) })
            add(colorRow("Tint", l.vdbTint) { l.vdbTint = $0 })
            add(sw("Environment lighting", l.vdbEnv) { [weak self] v in self?.host?.pushUndo(); l.vdbEnv = v; self?.host?.render() })
            add(sw("Light from surrounding scene", l.vdbSurround) { [weak self] v in self?.host?.pushUndo(); l.vdbSurround = v; self?.host?.render() })
            if let p = l.vdbEnvPath, !p.isEmpty {
                add(btnRow("Remove environment image (\((p as NSString).lastPathComponent))") { [weak self] in l.vdbEnvPath = nil; self?.host?.render(); self?.propKey = "" })
            }
        }
        if l.type == .MODEL || l.type == .CAMERA || l.is3d {
            add(head("Ray tracing"))
            add(sw("Ray tracing", l.rtOn) { [weak self] v in self?.host?.pushUndo(); l.rtOn = v; self?.host?.render(); self?.propKey = "" })
            if l.rtOn { rtRows(l) }
        }
    }

    private func rtRows(_ l: Layer) {
        add(sl("Intensity (master)", 0, 1, l.rtInt) { l.rtInt = $0 })
        add(sl("Shadow strength", 0, 1, l.xf("rtShadow", 1)) { l.xset("rtShadow", $0) })
        add(sl("Ambient occlusion strength", 0, 1, l.xf("rtAo", 1)) { l.xset("rtAo", $0) })
        add(sl("Occlusion radius", 0.05, 2, l.rtRad) { l.rtRad = $0 })
        rtStatusRow()
    }

    private func rtStatusRow() {
        let st = MetalModelRenderer.rtStatus
        add(note(st.isEmpty ? "Ray tracing ready (traced shadows + ambient occlusion on models, via Metal)." : st, st.isEmpty ? .gray : .systemRed))
    }

    private func globalProps() {
        add(head("Viewport"))
        add(sw("Grid", showGrid) { [weak self] v in self?.showGrid = v; self?.rebuildMenu() })
        add(sw("Gizmo", showGizmo) { [weak self] v in self?.showGizmo = v; self?.rebuildMenu() })
        add(sw("Show 3D scene", syncScene) { [weak self] v in self?.syncScene = v; self?.rebuildMenu() })
        add(sl("Viewport field of view", 20, 90, R3D.g("vpFov", 50), "%.0f") { R3D.set("vpFov", $0) })
        add(sl("Gizmo size", 0.05, 0.3, R3D.g("vpGizmo", 0.14)) { R3D.set("vpGizmo", $0) })
        add(sl("Background", 0, 0.4, R3D.g("vpBg", 0)) { [weak self] v in R3D.set("vpBg", v); self?.scn.background.contents = UIColor(white: CGFloat(v), alpha: 1) })
        add(sl("VDB preview density cut", 0.01, 0.5, R3D.g("vpThresh", 0.06)) { R3D.set("vpThresh", $0) })
        add(sl("VDB preview point budget", 0.2, 3, R3D.g("vpPts", 1)) { R3D.set("vpPts", $0) })

        add(head("Rendering (all layers)"))
        add(sl("Exposure", 0.2, 3, R3D.g("exposure", 1)) { R3D.set("exposure", $0) })
        add(sl("Light intensity", 0, 3, R3D.g("light", 1)) { R3D.set("light", $0) })
        add(sl("Environment intensity", 0, 3, R3D.g("env", 1)) { R3D.set("env", $0) })
        add(sw("Ray trace every model", R3D.g("rtAll", 0) > 0.5) { [weak self] v in R3D.set("rtAll", v ? 1 : 0); self?.host?.render() })
        add(sl("Ray tracing intensity (global)", 0, 1, R3D.g("rtMul", 1)) { R3D.set("rtMul", $0) })
        rtStatusRow()

        add(head("VDB (all volumes)"))
        add(sl("Density ×", 0, 3, R3D.g("vdbDens", 1)) { R3D.set("vdbDens", $0) })
        add(sl("Brightness ×", 0, 3, R3D.g("vdbBright", 1)) { R3D.set("vdbBright", $0) })
        add(sl("Quality ×", 0.4, 2.5, R3D.g("vdbQuality", 1)) { R3D.set("vdbQuality", $0) })
        add(btnRow("Reset global settings") { [weak self] in
            for k in ["vpFov", "vpGizmo", "vpBg", "vpThresh", "vpPts", "exposure", "light", "env", "rtAll", "rtMul", "vdbDens", "vdbBright", "vdbQuality"] { UserDefaults.standard.removeObject(forKey: "r3d." + k) }
            self?.propKey = ""; self?.host?.render()
        })
    }

    fileprivate func isVdbLayer(_ l: Layer) -> Bool { (l.imagePath ?? "").lowercased().hasSuffix(".vdb") }

    // ---- row builders
    private func add(_ v: UIView) { propStack.addArrangedSubview(v) }

    private func head(_ t: String) -> UIView {
        let l = UILabel(); l.text = t.uppercased(); l.font = .systemFont(ofSize: 12, weight: .bold)
        l.textColor = UIColor(red: 1, green: 0.55, blue: 0.08, alpha: 1); return l
    }
    private func note(_ t: String, _ c: UIColor = .gray) -> UIView {
        let l = UILabel(); l.text = t; l.font = .systemFont(ofSize: 12); l.textColor = c; l.numberOfLines = 0; return l
    }
    private func sw(_ t: String, _ on: Bool, _ f: @escaping (Bool) -> Void) -> UIView {
        let l = UILabel(); l.text = t; l.textColor = .white; l.font = .systemFont(ofSize: 15)
        let s = UISwitch(); s.isOn = on; s.onTintColor = UIColor(red: 1, green: 0.55, blue: 0.08, alpha: 1)
        s.addAction(UIAction { _ in f(s.isOn) }, for: .valueChanged)
        let r = UIStackView(arrangedSubviews: [l, s]); r.alignment = .center; return r
    }
    private func sl(_ t: String, _ lo: Float, _ hi: Float, _ v: Float, _ fmt: String = "%.2f", _ f: @escaping (Float) -> Void) -> UIView {
        let name = UILabel(); name.text = t; name.textColor = .white; name.font = .systemFont(ofSize: 14)
        let val = UILabel(); val.textColor = .lightGray; val.font = .monospacedDigitSystemFont(ofSize: 13, weight: .regular)
        val.text = String(format: fmt, v); val.textAlignment = .right
        let s = UISlider(); s.minimumValue = lo; s.maximumValue = hi; s.value = min(max(v, lo), hi)
        s.minimumTrackTintColor = UIColor(red: 1, green: 0.55, blue: 0.08, alpha: 1)
        s.addAction(UIAction { _ in f(s.value); val.text = String(format: fmt, s.value) }, for: .valueChanged)
        s.addAction(UIAction { [weak self] _ in self?.host?.pushUndo() }, for: .touchDown)
        s.addAction(UIAction { [weak self] _ in self?.host?.render(); self?.host?.refreshPanel() }, for: [.touchUpInside, .touchUpOutside])
        let top = UIStackView(arrangedSubviews: [name, val])
        let c = UIStackView(arrangedSubviews: [top, s]); c.axis = .vertical; c.spacing = 2; return c
    }
    private func seg(_ t: String, _ items: [String], _ sel: Int, _ f: @escaping (Int) -> Void) -> UIView {
        let s = UISegmentedControl(items: items); s.selectedSegmentIndex = sel
        s.selectedSegmentTintColor = UIColor(red: 1, green: 0.55, blue: 0.08, alpha: 1)
        s.setTitleTextAttributes([.foregroundColor: UIColor.black], for: .selected)
        s.setTitleTextAttributes([.foregroundColor: UIColor.white], for: .normal)
        s.addAction(UIAction { _ in f(s.selectedSegmentIndex) }, for: .valueChanged); return s
    }
    private func colorRow(_ t: String, _ argb: Int32, _ f: @escaping (Int32) -> Void) -> UIView {
        let l = UILabel(); l.text = t; l.textColor = .white; l.font = .systemFont(ofSize: 15)
        let c = UInt32(bitPattern: argb)
        let w = UIColorWell(); w.supportsAlpha = false
        w.selectedColor = UIColor(red: CGFloat((c >> 16) & 255) / 255, green: CGFloat((c >> 8) & 255) / 255, blue: CGFloat(c & 255) / 255, alpha: 1)
        w.addAction(UIAction { [weak self, weak w] _ in
            guard let col = w?.selectedColor else { return }
            var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0; col.getRed(&r, green: &g, blue: &b, alpha: &a)
            self?.host?.pushUndo()
            f(Int32(bitPattern: 0xFF000000 | UInt32(r * 255) << 16 | UInt32(g * 255) << 8 | UInt32(b * 255))); self?.host?.render()
        }, for: .valueChanged)
        let r = UIStackView(arrangedSubviews: [l, w]); r.alignment = .center; return r
    }
    private func btnRow(_ t: String, _ f: @escaping () -> Void) -> UIView {
        let b = UIButton(type: .system); b.setTitle(t, for: .normal); b.setTitleColor(.white, for: .normal)
        b.backgroundColor = UIColor(white: 0.18, alpha: 1); b.layer.cornerRadius = 10
        b.heightAnchor.constraint(equalToConstant: 40).isActive = true
        b.addAction(UIAction { _ in f() }, for: .touchUpInside); return b
    }
}

// MARK: - Timeline canvas (ruler, one row per 3D layer, keyframe diamonds, playhead)

final class TLCanvas: UIView {
    var rows: [Layer] = []
    var selected = -1
    var time: Float = 0
    var dur: Float = 5
    var onSeek: ((Float) -> Void)?
    var onSelect: ((Int) -> Void)?
    private var pps: CGFloat = 70           // pixels per second
    private var offX: CGFloat = 0, offY: CGFloat = 0
    private var scrub = false
    private let rowH: CGFloat = 32, top: CGFloat = 26
    private let orange = UIColor(red: 1, green: 0.55, blue: 0.08, alpha: 1)

    override init(frame: CGRect) {
        super.init(frame: frame)
        addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(pan(_:))))
        addGestureRecognizer(UIPinchGestureRecognizer(target: self, action: #selector(pinch(_:))))
        addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(tap(_:))))
        contentMode = .redraw
    }
    required init?(coder: NSCoder) { fatalError() }

    private func tx(_ t: Float) -> CGFloat { CGFloat(t) * pps - offX + 8 }
    private func tt(_ x: CGFloat) -> Float { Float(max(0, min(CGFloat(dur), (x + offX - 8) / pps))) }

    @objc private func pan(_ g: UIPanGestureRecognizer) {
        if g.state == .began { scrub = (g.location(in: self).y - g.translation(in: self).y) < top }
        let d = g.translation(in: self); g.setTranslation(.zero, in: self)
        if scrub { onSeek?(tt(g.location(in: self).x)) }
        else {
            offX = max(0, min(offX - d.x, max(0, CGFloat(dur) * pps - bounds.width + 40)))
            offY = max(0, min(offY - d.y, max(0, CGFloat(rows.count) * rowH - (bounds.height - top))))
            setNeedsDisplay()
        }
    }
    @objc private func pinch(_ g: UIPinchGestureRecognizer) {
        guard g.state == .changed else { return }
        pps = max(20, min(400, pps * g.scale)); g.scale = 1; setNeedsDisplay()
    }
    @objc private func tap(_ g: UITapGestureRecognizer) {
        let p = g.location(in: self)
        if p.y < top { onSeek?(tt(p.x)); return }
        let i = Int((p.y - top + offY) / rowH)
        if i >= 0 && i < rows.count { onSelect?(rows[i].id) } else { onSelect?(-1) }
    }

    override func draw(_ r: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let attr: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 11, weight: .medium), .foregroundColor: UIColor.white]
        let dim: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 10), .foregroundColor: UIColor.gray]
        // rows
        c.saveGState(); c.clip(to: CGRect(x: 0, y: top, width: bounds.width, height: bounds.height - top))
        if rows.isEmpty { ("No 3D layers yet. Use + > Import Model" as NSString).draw(at: CGPoint(x: 12, y: top + 12), withAttributes: dim) }
        for (i, l) in rows.enumerated() {
            let y = top + CGFloat(i) * rowH - offY
            if y + rowH < top || y > bounds.height { continue }
            if i % 2 == 0 { UIColor(white: 1, alpha: 0.03).setFill(); c.fill(CGRect(x: 0, y: y, width: bounds.width, height: rowH)) }
            let x0 = tx(l.start), x1 = tx(l.end)
            let bar = CGRect(x: x0, y: y + 4, width: max(6, x1 - x0), height: rowH - 8)
            (l.id == selected ? orange : orange.withAlphaComponent(0.35)).setFill()
            UIBezierPath(roundedRect: bar, cornerRadius: 6).fill()
            (l.name as NSString).draw(at: CGPoint(x: max(bar.minX, 0) + 6, y: y + 9), withAttributes: attr)
            var ts = Set<Float>()
            for k in ["x", "y", "z", "scale", "rotX", "rotY", "rotZ", "fov"] { for key in l.track(k).keys { ts.insert((key.t * 1000).rounded() / 1000) } }
            UIColor.white.setFill()
            for t in ts {
                let x = tx(t), my = y + rowH / 2
                let d = UIBezierPath(); d.move(to: CGPoint(x: x, y: my - 6)); d.addLine(to: CGPoint(x: x + 5, y: my))
                d.addLine(to: CGPoint(x: x, y: my + 6)); d.addLine(to: CGPoint(x: x - 5, y: my)); d.close(); d.fill()
            }
        }
        c.restoreGState()
        // ruler
        UIColor(white: 0.11, alpha: 1).setFill(); c.fill(CGRect(x: 0, y: 0, width: bounds.width, height: top))
        let stepT: Float = pps > 140 ? 0.5 : (pps > 40 ? 1 : 5)
        var t: Float = 0
        while t <= dur + 0.001 {
            let x = tx(t)
            if x > -30 && x < bounds.width + 30 {
                UIColor.gray.setFill(); c.fill(CGRect(x: x, y: top - 8, width: 1, height: 8))
                (String(format: stepT < 1 ? "%.1f" : "%.0f", t) as NSString).draw(at: CGPoint(x: x + 3, y: 5), withAttributes: dim)
            }
            t += stepT
        }
        // end-of-timeline marker
        UIColor(white: 0, alpha: 0.5).setFill(); c.fill(CGRect(x: tx(dur), y: top, width: max(0, bounds.width - tx(dur)), height: bounds.height))
        // playhead
        let px = tx(time)
        orange.setFill(); c.fill(CGRect(x: px - 1, y: 0, width: 2, height: bounds.height))
        let head = UIBezierPath(roundedRect: CGRect(x: px - 9, y: 2, width: 18, height: 16), cornerRadius: 5); orange.setFill(); head.fill()
    }
}

// MARK: - Scatter tab

extension Scene3DView {

    fileprivate func scatterProps() {
        let objs = Editor.scene.layers.filter { $0.type == .MODEL && !isVdbLayer($0) }
        if layer(scLayer).map({ !objs.contains($0) }) ?? true {
            scLayer = objs.first(where: { $0.id == selected })?.id ?? objs.first?.id ?? -1
        }
        sadd(shead("Scatter"))
        sadd(snote("Copies a 3D model over the surface of a target (a model, or a media layer with the 3D cube on). Pick which is which, then tune it. It renders in the final video too."))
        guard let l = layer(scLayer) else { sadd(snote("Import a 3D model first (+ > Import Model).", .systemRed)); return }
        sadd(picker("Scatter object", l.name, objs.map { ($0.name, $0.id) }) { [weak self] id in self?.scLayer = id; self?.propKey = "" })
        let tgts = Editor.scene.layers.filter { is3dContent($0) && $0.id != l.id && !isVdbLayer($0) }
        let cur = layer(Int(l.xf("scTarget", -1)))
        sadd(picker("Target surface", cur?.name ?? "None", tgts.map { ($0.name, $0.id) }) { [weak self] id in
            self?.host?.pushUndo(); l.xset("scTarget", Float(id)); l.xset("scOn", 1); self?.host?.render(); self?.propKey = ""
        })
        if let s = layer(selected), s.id != l.id {
            sadd(sbtn("Use selected layer (\(s.name)) as target") { [weak self] in
                self?.host?.pushUndo(); l.xset("scTarget", Float(s.id)); l.xset("scOn", 1); self?.host?.render(); self?.propKey = ""
            })
        }
        if let s = layer(selected), s.type == .MODEL, !isVdbLayer(s), s.id != l.id {
            sadd(sbtn("Use selected layer as scatter object") { [weak self] in self?.scLayer = s.id; self?.propKey = "" })
        }
        sadd(ssw("Scatter on", l.xf("scOn", 0) > 0.5) { [weak self] v in self?.host?.pushUndo(); l.xset("scOn", v ? 1 : 0); self?.host?.render() })
        sadd(ssw("Keep the original model too", l.xf("scKeep", 0) > 0.5) { [weak self] v in l.xset("scKeep", v ? 1 : 0); self?.host?.render() })
        func f(_ n: String, _ k: String, _ lo: Float, _ hi: Float, _ d: Float, _ fmt: String = "%.2f") {
            sadd(ssl(n, lo, hi, l.xf(k, d), fmt) { l.xset(k, $0) })
        }
        sadd(shead("Amount"))
        f("Count", "scCount", 1, 1500, 60, "%.0f"); f("Seed", "scSeed", 1, 999, 1, "%.0f"); f("Jitter", "scJitter", 0, 1, 0)
        sadd(sbtn("Re-roll seed") { [weak self] in self?.host?.pushUndo(); l.xset("scSeed", Float(Int.random(in: 1...999))); self?.host?.render(); self?.propKey = "" })
        sadd(shead("Distribution"))
        sadd(sseg(["Random", "Even spacing"], Int(l.xf("scMode", 0))) { i in l.xset("scMode", Float(i)) })
        f("Minimum distance (even)", "scMinDist", 0.01, 2, 0.2)
        sadd(shead("Scale"))
        f("Scale", "scScale", 0.05, 3, 1); f("Random scale", "scScaleRnd", 0, 1, 0.3); f("Squash / stretch", "scSquash", 0, 1, 0)
        sadd(shead("Rotation"))
        f("Align to surface", "scAlign", 0, 1, 1); f("Random yaw", "scYaw", 0, 360, 360, "%.0f"); f("Random tilt", "scTilt", 0, 90, 0, "%.0f")
        f("Offset X", "scRotX", -180, 180, 0, "%.0f"); f("Offset Y", "scRotY", -180, 180, 0, "%.0f"); f("Offset Z", "scRotZ", -180, 180, 0, "%.0f")
        sadd(shead("Placement"))
        f("Lift along normal", "scLift", -1, 1, 0); f("Random lift", "scLiftRnd", 0, 1, 0)
        sadd(ssw("Flip surface normals", l.xf("scFlip", 0) > 0.5) { v in l.xset("scFlip", v ? 1 : 0) })
        sadd(shead("Filters"))
        f("Min slope (0 = flat up)", "scSlopeMin", 0, 180, 0, "%.0f"); f("Max slope", "scSlopeMax", 0, 180, 180, "%.0f")
        f("Min height", "scHMin", -10, 10, -10); f("Max height", "scHMax", -10, 10, 10)
        sadd(shead("Noise mask (clumps)"))
        f("Noise scale", "scNoiseScale", 0.2, 20, 3); f("Noise threshold", "scNoiseThr", 0, 1, 0)
        sadd(shead("Animation"))
        f("Grow-in duration (s)", "scGrow", 0, 5, 0); f("Grow stagger", "scStagger", 0, 1, 0.5)
        f("Sway angle", "scSway", 0, 30, 0, "%.1f"); f("Sway speed", "scSwaySpeed", 0, 4, 1)
        sadd(sbtn("Reset scatter settings") { [weak self] in
            self?.host?.pushUndo()
            l.x3s = l.x3s.split(separator: ";").filter { !$0.hasPrefix("sc") }.joined(separator: ";")
            self?.host?.render(); self?.propKey = ""
        })
    }

    private func sadd(_ v: UIView) { propStack.addArrangedSubview(v) }
    private func shead(_ t: String) -> UIView { let l = UILabel(); l.text = t.uppercased(); l.font = .systemFont(ofSize: 12, weight: .bold); l.textColor = accent; return l }
    private func snote(_ t: String, _ c: UIColor = .gray) -> UIView { let l = UILabel(); l.text = t; l.font = .systemFont(ofSize: 12); l.textColor = c; l.numberOfLines = 0; return l }
    private func sbtn(_ t: String, _ f: @escaping () -> Void) -> UIView {
        let b = UIButton(type: .system); b.setTitle(t, for: .normal); b.setTitleColor(.white, for: .normal)
        b.backgroundColor = UIColor(white: 0.18, alpha: 1); b.layer.cornerRadius = 10
        b.heightAnchor.constraint(equalToConstant: 40).isActive = true
        b.addAction(UIAction { _ in f() }, for: .touchUpInside); return b
    }
    private func picker(_ title: String, _ cur: String, _ opts: [(String, Int)], _ f: @escaping (Int) -> Void) -> UIView {
        let b = UIButton(type: .system)
        b.setTitle("\(title):  \(cur)  ▾", for: .normal); b.setTitleColor(.white, for: .normal)
        b.backgroundColor = accent.withAlphaComponent(0.35); b.layer.cornerRadius = 10
        b.heightAnchor.constraint(equalToConstant: 42).isActive = true
        b.menu = UIMenu(children: opts.map { o in UIAction(title: o.0) { _ in f(o.1) } })
        b.showsMenuAsPrimaryAction = true; return b
    }
    private func ssw(_ t: String, _ on: Bool, _ f: @escaping (Bool) -> Void) -> UIView {
        let l = UILabel(); l.text = t; l.textColor = .white; l.font = .systemFont(ofSize: 15)
        let s = UISwitch(); s.isOn = on; s.onTintColor = accent
        s.addAction(UIAction { _ in f(s.isOn) }, for: .valueChanged)
        let r = UIStackView(arrangedSubviews: [l, s]); r.alignment = .center; return r
    }
    private func sseg(_ items: [String], _ sel: Int, _ f: @escaping (Int) -> Void) -> UIView {
        let s = UISegmentedControl(items: items); s.selectedSegmentIndex = sel; s.selectedSegmentTintColor = accent
        s.setTitleTextAttributes([.foregroundColor: UIColor.black], for: .selected)
        s.setTitleTextAttributes([.foregroundColor: UIColor.white], for: .normal)
        s.addAction(UIAction { _ in f(s.selectedSegmentIndex) }, for: .valueChanged); return s
    }
    private func ssl(_ t: String, _ lo: Float, _ hi: Float, _ v: Float, _ fmt: String, _ f: @escaping (Float) -> Void) -> UIView {
        let name = UILabel(); name.text = t; name.textColor = .white; name.font = .systemFont(ofSize: 14)
        let val = UILabel(); val.textColor = .lightGray; val.font = .monospacedDigitSystemFont(ofSize: 13, weight: .regular)
        val.text = String(format: fmt, v); val.textAlignment = .right
        let s = UISlider(); s.minimumValue = lo; s.maximumValue = hi; s.value = min(max(v, lo), hi); s.minimumTrackTintColor = accent
        s.addAction(UIAction { _ in f(s.value); val.text = String(format: fmt, s.value) }, for: .valueChanged)
        s.addAction(UIAction { [weak self] _ in self?.host?.pushUndo() }, for: .touchDown)
        s.addAction(UIAction { [weak self] _ in self?.host?.render() }, for: [.touchUpInside, .touchUpOutside])
        let c = UIStackView(arrangedSubviews: [UIStackView(arrangedSubviews: [name, val]), s]); c.axis = .vertical; c.spacing = 2; return c
    }
}
