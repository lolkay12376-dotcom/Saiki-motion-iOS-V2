// Rig.swift — rig group data (Model).
//
// A rig group is a GROUP layer with a `Rig`. Parameters are tracks on that
// group ("rp<id>"), so they can be keyframed in the main editor too. A binding
// maps a parameter to one property of a member layer through keyforms
// (parameter value → output), interpolated linearly. The output is ADDED to the
// property ("x", "rotZ", "opacity", or a mesh pin "pp<id>x"/"pp<id>y").

import Foundation

final class RigParam {
    var id: Int
    var name: String
    var lo: Float
    var hi: Float
    var def: Float
    init(_ id: Int, _ name: String, _ lo: Float, _ hi: Float, _ def: Float) {
        self.id = id; self.name = name; self.lo = lo; self.hi = hi; self.def = def
    }
    var key: String { "rp\(id)" }
}

final class RigBinding {
    var id: Int
    var paramId: Int
    var layerId: Int
    var key: String
    var keys: [(Float, Float)]      // (parameter value, output), sorted by parameter value
    init(_ id: Int, _ paramId: Int, _ layerId: Int, _ key: String, _ keys: [(Float, Float)] = []) {
        self.id = id; self.paramId = paramId; self.layerId = layerId; self.key = key; self.keys = keys
    }

    func eval(_ v: Float) -> Float {
        guard let f = keys.first, let l = keys.last else { return 0 }
        if v <= f.0 { return f.1 }
        if v >= l.0 { return l.1 }
        for i in 1..<keys.count where v <= keys[i].0 {
            let a = keys[i - 1], b = keys[i]
            let d = b.0 - a.0
            return d < 1e-6 ? b.1 : a.1 + (b.1 - a.1) * (v - a.0) / d
        }
        return l.1
    }

    func setKey(_ pv: Float, _ out: Float) {
        if let i = keys.firstIndex(where: { abs($0.0 - pv) < 1e-3 }) { keys[i].1 = out }
        else { keys.append((pv, out)); keys.sort { $0.0 < $1.0 } }
    }
}

final class Rig {
    var params: [RigParam] = []
    var bindings: [RigBinding] = []
    var members: [Int] = []         // layer ids imported into this rig group
    var nextId = 1

    func param(_ id: Int) -> RigParam? { params.first { $0.id == id } }

    @discardableResult
    func addParam(_ name: String, _ lo: Float, _ hi: Float, _ def: Float, on g: Layer) -> RigParam {
        let p = RigParam(nextId, name, lo, hi, def); nextId += 1
        params.append(p)
        g.track(p.key).base = def
        return p
    }

    func value(_ p: RigParam, _ g: Layer, _ t: Float) -> Float { g.p(p.key, t) }

    /// Existing binding for (param, layer, key) or a new one with a zero key at the default.
    func binding(_ p: RigParam, _ layerId: Int, _ key: String, create: Bool) -> RigBinding? {
        if let b = bindings.first(where: { $0.paramId == p.id && $0.layerId == layerId && $0.key == key }) { return b }
        guard create else { return nil }
        let b = RigBinding(nextId, p.id, layerId, key, [(p.def, 0)]); nextId += 1
        bindings.append(b)
        return b
    }

    func removeLayer(_ id: Int) {
        members.removeAll { $0 == id }
        bindings.removeAll { $0.layerId == id }
    }

    // MARK: apply (called before every frame is drawn)

    static func apply(_ layers: [Layer], _ t: Float) {
        var any = false
        for l in layers where l.rig != nil { any = true; break }
        if !any {
            for l in layers where !l.rigOff.isEmpty { l.rigOff.removeAll() }
            return
        }
        for l in layers { if !l.rigOff.isEmpty { l.rigOff.removeAll(keepingCapacity: true) } }
        var byId = [Int: Layer]()
        for l in layers { byId[l.id] = l }
        for g in layers {
            guard let r = g.rig else { continue }
            for b in r.bindings {
                guard let p = r.param(b.paramId), let target = byId[b.layerId] else { continue }
                target.rigOff[b.key, default: 0] += b.eval(g.p(p.key, t))
            }
        }
    }

    // MARK: json

    func toJson() -> JObj {
        let o = JObj()
        o.put("nextId", Int64(nextId))
        let pa = JArr()
        for p in params {
            _ = pa.put(JObj().put("id", Int64(p.id)).put("name", p.name)
                .put("lo", Double(p.lo)).put("hi", Double(p.hi)).put("def", Double(p.def)))
        }
        o.put("params", pa)
        let ba = JArr()
        for b in bindings {
            let ka = JArr()
            for k in b.keys { _ = ka.put(JObj().put("v", Double(k.0)).put("o", Double(k.1))) }
            _ = ba.put(JObj().put("id", Int64(b.id)).put("param", Int64(b.paramId))
                .put("layer", Int64(b.layerId)).put("key", b.key).put("keys", ka))
        }
        o.put("bindings", ba)
        let ma = JArr(); for m in members { _ = ma.put(Int64(m)) }
        o.put("members", ma)
        return o
    }

    static func fromJson(_ o: JObj) -> Rig {
        let r = Rig()
        r.nextId = max(1, o.optInt("nextId", 1))
        if let pa = o.optJSONArray("params") {
            for i in 0..<pa.count {
                guard let p = pa.optJSONObject(i) else { continue }
                r.params.append(RigParam(p.optInt("id"), p.optString("name", "Param"),
                                         p.optFloat("lo", 0), p.optFloat("hi", 1), p.optFloat("def", 0)))
            }
        }
        if let ba = o.optJSONArray("bindings") {
            for i in 0..<ba.count {
                guard let b = ba.optJSONObject(i) else { continue }
                var ks = [(Float, Float)]()
                if let ka = b.optJSONArray("keys") {
                    for j in 0..<ka.count {
                        if let k = ka.optJSONObject(j) { ks.append((k.optFloat("v"), k.optFloat("o"))) }
                    }
                }
                r.bindings.append(RigBinding(b.optInt("id"), b.optInt("param"), b.optInt("layer"),
                                             b.optString("key", "x"), ks))
            }
        }
        if let ma = o.optJSONArray("members") {
            for i in 0..<ma.count { r.members.append(ma.optInt(i)) }
        }
        return r
    }
}
