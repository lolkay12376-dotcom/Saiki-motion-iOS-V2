// RigEditor.swift — "Cubism Editor": live 2D rig editor for a rig group (UI).
//
// Tabs: Parameters (create / connect), Hierarchy (parenting inside the rig),
// Mesh (warp pins keyed per parameter value), Rotate (rotation + pivot).
// Everything is custom UIKit + the app's own Dlg — no system pickers.

import UIKit

// MARK: - canvas

final class RigCanvas: UIView {
    var group: Layer!
    var selId = -1
    var mode = 0                                  // 0 params, 1 hierarchy, 2 mesh, 3 rotate
    var onSelect: ((Int) -> Void)?
    var onBeginEdit: (() -> Void)?
    var onPin: ((Layer, PuppetPin, Float, Float, Bool) -> Void)?   // desired total offset, ended
    var onPivot: ((Layer, Float, Float) -> Void)?

    private var zoom: CGFloat = 1
    private var pan = CGPoint.zero
    private var dragPin: PuppetPin?
    private var dragPivot = false
    private static var imgCache: [String: CGImage] = [:]

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = argbToUIColor(C.BG)
        contentMode = .redraw
        clipsToBounds = true
        isMultipleTouchEnabled = true
        let pi = UIPinchGestureRecognizer(target: self, action: #selector(pinch(_:)))
        let pa = UIPanGestureRecognizer(target: self, action: #selector(panned(_:)))
        pa.minimumNumberOfTouches = 2
        addGestureRecognizer(pi); addGestureRecognizer(pa)
    }
    required init?(coder: NSCoder) { fatalError() }

    @objc private func pinch(_ g: UIPinchGestureRecognizer) {
        zoom = min(6, max(0.3, zoom * g.scale)); g.scale = 1; setNeedsDisplay()
    }
    @objc private func panned(_ g: UIPanGestureRecognizer) {
        let t = g.translation(in: self); pan.x += t.x; pan.y += t.y
        g.setTranslation(.zero, in: self); setNeedsDisplay()
    }

    // MARK: geometry
    private var members: [Layer] {
        guard let r = group?.rig else { return [] }
        return Editor.scene.layers.filter { r.members.contains($0.id) }
    }
    private var ar: CGFloat { CGFloat(Editor.project.w) / CGFloat(max(Editor.project.h, 1)) }
    private var sc: CGFloat { min(bounds.height / 2, bounds.width / (2 * ar)) * 0.92 * zoom }
    private var cx: CGFloat { bounds.midX + pan.x }
    private var cy: CGFloat { bounds.midY + pan.y }
    private func scr(_ x: Float, _ y: Float) -> CGPoint { CGPoint(x: cx + CGFloat(x) * sc, y: cy - CGFloat(y) * sc) }
    private func world(_ p: CGPoint) -> (Float, Float) { (Float((p.x - cx) / sc), Float(-(p.y - cy) / sc)) }
    private func toScr(_ m: [Float], _ x: Float, _ y: Float) -> CGPoint { let w = Xf.apply(m, x, y); return scr(w.0, w.1) }
    private func local(_ l: Layer, _ p: CGPoint) -> (Float, Float)? {
        guard let inv = Xf.invert(Xf.matrix(l, Editor.time)) else { return nil }
        let w = world(p); return Xf.apply(inv, w.0, w.1)
    }
    private func cg(_ l: Layer) -> CGImage? {
        guard l.type == .IMAGE, let path = l.imagePath else { return nil }
        if let c = Self.imgCache[path] { return c }
        guard let ui = UIImage(contentsOfFile: path) else { return nil }
        let mx: CGFloat = 640, k = min(1, mx / max(ui.size.width, ui.size.height))
        let sz = CGSize(width: max(1, ui.size.width * k), height: max(1, ui.size.height * k))
        let f = UIGraphicsImageRendererFormat(); f.scale = 1
        let out = UIGraphicsImageRenderer(size: sz, format: f).image { _ in ui.draw(in: CGRect(origin: .zero, size: sz)) }
        if let c = out.cgImage { Self.imgCache[path] = c; return c }
        return nil
    }

    // MARK: draw
    override func draw(_ rect: CGRect) {
        guard let ctx = UIGraphicsGetCurrentContext(), group?.rig != nil else { return }
        Rig.apply(Editor.scene.layers, Editor.time)
        let t = Editor.time
        let a = Float(ar)
        let tl = scr(-a, 1), br = scr(a, -1)
        ctx.setFillColor(argbToUIColor(C.CARD).cgColor)
        ctx.fill(CGRect(x: tl.x, y: tl.y, width: br.x - tl.x, height: br.y - tl.y))
        for l in members where l.visible { drawLayer(ctx, l, t) }
        guard let s = members.first(where: { $0.id == selId }) else { return }
        let m = Xf.matrix(s, t); let (qw, qh) = Xf.quadSize(s)
        let q = [(-qw / 2, -qh / 2), (qw / 2, -qh / 2), (qw / 2, qh / 2), (-qw / 2, qh / 2)].map { toScr(m, $0.0, $0.1) }
        ctx.setStrokeColor(argbToUIColor(C.GREEN).cgColor); ctx.setLineWidth(1.5)
        ctx.addLines(between: q + [q[0]]); ctx.strokePath()
        if mode == 2, let pp = s.puppet {
            for pin in pp.pins {
                let o = pinOffset(s, pin, t)
                let c = toScr(m, (pin.rx + o.0) * qw / 2, (pin.ry + o.1) * qh / 2)
                ctx.setFillColor(argbToUIColor(pin === dragPin ? C.TEXT : C.GREEN).cgColor)
                ctx.fillEllipse(in: CGRect(x: c.x - 7, y: c.y - 7, width: 14, height: 14))
            }
        }
        if mode == 3 {
            let c = pivotScreen(s)
            ctx.setStrokeColor(UIColor.cyan.cgColor); ctx.setLineWidth(2)
            ctx.strokeEllipse(in: CGRect(x: c.x - 11, y: c.y - 11, width: 22, height: 22))
            ctx.move(to: CGPoint(x: c.x - 16, y: c.y)); ctx.addLine(to: CGPoint(x: c.x + 16, y: c.y))
            ctx.move(to: CGPoint(x: c.x, y: c.y - 16)); ctx.addLine(to: CGPoint(x: c.x, y: c.y + 16))
            ctx.strokePath()
        }
    }

    private func pinOffset(_ l: Layer, _ pin: PuppetPin, _ t: Float) -> (Float, Float) {
        ((l.props["pp\(pin.id)x"]?.eval(t) ?? 0) + (l.rigOff["pp\(pin.id)x"] ?? 0),
         (l.props["pp\(pin.id)y"]?.eval(t) ?? 0) + (l.rigOff["pp\(pin.id)y"] ?? 0))
    }
    private func pivotScreen(_ l: Layer) -> CGPoint {
        let (qw, qh) = Xf.quadSize(l)
        let ax = l.p("anchorX", Editor.time), ay = l.p("anchorY", Editor.time)
        return toScr(Xf.matrix(l, Editor.time), (ax - 50) / 100 * qw, -(ay - 50) / 100 * qh)
    }

    private func drawLayer(_ ctx: CGContext, _ l: Layer, _ t: Float) {
        let m = Xf.matrix(l, t); let (qw, qh) = Xf.quadSize(l)
        ctx.saveGState()
        ctx.translateBy(x: cx, y: cy); ctx.scaleBy(x: sc, y: -sc)
        ctx.concatenate(CGAffineTransform(a: CGFloat(m[0]), b: CGFloat(m[1]), c: CGFloat(m[2]),
                                          d: CGFloat(m[3]), tx: CGFloat(m[4]), ty: CGFloat(m[5])))
        ctx.setAlpha(CGFloat(max(0, min(1, l.p("opacity", t)))))
        let hw = CGFloat(qw) / 2, hh = CGFloat(qh) / 2
        if let img = cg(l) {
            if let mesh = PuppetMath.mesh(l, t) {
                let W = CGFloat(img.width), H = CGFloat(img.height)
                var i = 0
                while i + 2 < mesh.idx.count {
                    let ids = [Int(mesh.idx[i]), Int(mesh.idx[i + 1]), Int(mesh.idx[i + 2])]; i += 3
                    let d = ids.map { CGPoint(x: CGFloat(mesh.pos[2 * $0]) * hw, y: CGFloat(mesh.pos[2 * $0 + 1]) * hh) }
                    let s = ids.map { CGPoint(x: CGFloat(mesh.uv[2 * $0]) * W, y: CGFloat(mesh.uv[2 * $0 + 1]) * H) }
                    let e1 = CGPoint(x: s[1].x - s[0].x, y: s[1].y - s[0].y), e2 = CGPoint(x: s[2].x - s[0].x, y: s[2].y - s[0].y)
                    let f1 = CGPoint(x: d[1].x - d[0].x, y: d[1].y - d[0].y), f2 = CGPoint(x: d[2].x - d[0].x, y: d[2].y - d[0].y)
                    let det = e1.x * e2.y - e1.y * e2.x
                    if abs(det) < 1e-6 { continue }
                    let a = (f1.x * e2.y - f2.x * e1.y) / det, c = (f2.x * e1.x - f1.x * e2.x) / det
                    let b = (f1.y * e2.y - f2.y * e1.y) / det, dd = (f2.y * e1.x - f1.y * e2.x) / det
                    let tx = d[0].x - (a * s[0].x + c * s[0].y), ty = d[0].y - (b * s[0].x + dd * s[0].y)
                    ctx.saveGState()
                    ctx.move(to: d[0]); ctx.addLine(to: d[1]); ctx.addLine(to: d[2]); ctx.closePath(); ctx.clip()
                    ctx.concatenate(CGAffineTransform(a: a, b: b, c: c, d: dd, tx: tx, ty: ty))
                    ctx.draw(img, in: CGRect(x: 0, y: 0, width: W, height: H))
                    ctx.restoreGState()
                }
            } else {
                ctx.draw(img, in: CGRect(x: -hw, y: -hh, width: hw * 2, height: hh * 2))
            }
        } else {
            ctx.setFillColor(argbToUIColor(C.CARD2).cgColor)
            ctx.fill(CGRect(x: -hw, y: -hh, width: hw * 2, height: hh * 2))
        }
        ctx.restoreGState()
    }

    // MARK: touch
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard touches.count == 1, let tc = touches.first else { return }
        let p = tc.location(in: self)
        let sel = members.first { $0.id == selId }
        if mode == 2, let s = sel, let pp = s.puppet {
            let m = Xf.matrix(s, Editor.time); let (qw, qh) = Xf.quadSize(s)
            var best: (PuppetPin, CGFloat)? = nil
            for pin in pp.pins {
                let o = pinOffset(s, pin, Editor.time)
                let c = toScr(m, (pin.rx + o.0) * qw / 2, (pin.ry + o.1) * qh / 2)
                let d = hypot(c.x - p.x, c.y - p.y)
                if d < 28 && d < (best?.1 ?? .infinity) { best = (pin, d) }
            }
            if let b = best { dragPin = b.0; onBeginEdit?(); setNeedsDisplay(); return }
        }
        if mode == 3, let s = sel, hypot(pivotScreen(s).x - p.x, pivotScreen(s).y - p.y) < 30 {
            dragPivot = true; onBeginEdit?(); return
        }
        for l in members.reversed() where l.visible {
            let (qw, qh) = Xf.quadSize(l)
            if let q = local(l, p), abs(q.0) <= qw / 2, abs(q.1) <= qh / 2 { onSelect?(l.id); return }
        }
        onSelect?(-1)
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard touches.count == 1, let tc = touches.first, let s = members.first(where: { $0.id == selId }) else { return }
        let p = tc.location(in: self)
        guard let q = local(s, p) else { return }
        let (qw, qh) = Xf.quadSize(s)
        if let pin = dragPin {
            onPin?(s, pin, q.0 / (qw / 2) - pin.rx, q.1 / (qh / 2) - pin.ry, false)
        } else if dragPivot {
            onPivot?(s, min(100, max(0, q.0 / qw * 100 + 50)), min(100, max(0, 50 - q.1 / qh * 100)))
        }
        setNeedsDisplay()
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let pin = dragPin, let s = members.first(where: { $0.id == selId }),
           let tc = touches.first, let q = local(s, tc.location(in: self)) {
            let (qw, qh) = Xf.quadSize(s)
            onPin?(s, pin, q.0 / (qw / 2) - pin.rx, q.1 / (qh / 2) - pin.ry, true)
        }
        dragPin = nil; dragPivot = false; setNeedsDisplay()
    }
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        dragPin = nil; dragPivot = false; setNeedsDisplay()
    }
}

// MARK: - controller

final class RigEditorViewController: UIViewController {
    private let group: Layer
    private weak var host: EditorViewController?
    private var curTab = 0
    private var selId = -1
    private var activeParam = -1
    private let canvas = RigCanvas()
    private let stack = UIStackView()
    private let scroll = UIScrollView()
    private var tabButtons: [UIButton] = []
    private var angleSlider: RulerSlider?
    private var rig: Rig { group.rig! }

    init(group: Layer, host: EditorViewController) {
        self.group = group; self.host = host
        super.init(nibName: nil, bundle: nil)
        modalPresentationStyle = .fullScreen
        activeParam = group.rig?.params.first?.id ?? -1
    }
    required init?(coder: NSCoder) { fatalError() }

    override var prefersStatusBarHidden: Bool { false }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = argbToUIColor(C.BG)
        let done = btn("Done", C.GREEN, C.BG) { [weak self] in self?.close() }
        let title = UILabel(); title.text = "Cubism Editor — \(group.name)"
        title.textColor = argbToUIColor(C.TEXT); title.font = .systemFont(ofSize: 15, weight: .bold)
        let top = UIStackView(arrangedSubviews: [title, UIView(), done]); top.alignment = .center; top.spacing = 8
        let names = ["Params", "Hierarchy", "Mesh", "Rotate"]
        let tabs = UIStackView(); tabs.distribution = .fillEqually; tabs.spacing = 6
        for (i, n) in names.enumerated() {
            let b = btn(n) { [weak self] in self?.curTab = i; self?.reload() }
            tabButtons.append(b); tabs.addArrangedSubview(b)
        }
        canvas.group = group
        canvas.onSelect = { [weak self] id in self?.selId = id; self?.reload() }
        canvas.onBeginEdit = { [weak self] in self?.host?.pushUndo() }
        canvas.onPin = { [weak self] l, pin, ox, oy, end in self?.pinMoved(l, pin, ox, oy, end) }
        canvas.onPivot = { [weak self] l, ax, ay in self?.host?.setAnchorKeepVisual(l, ax, ay); self?.host?.render() }
        stack.axis = .vertical; stack.spacing = 10
        scroll.addSubview(stack); scroll.alwaysBounceVertical = true
        for v in [top, tabs, canvas, scroll] as [UIView] { v.translatesAutoresizingMaskIntoConstraints = false; view.addSubview(v) }
        stack.translatesAutoresizingMaskIntoConstraints = false
        let g = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            top.topAnchor.constraint(equalTo: g.topAnchor, constant: 6),
            top.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 12),
            top.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -12),
            tabs.topAnchor.constraint(equalTo: top.bottomAnchor, constant: 8),
            tabs.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 12),
            tabs.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -12),
            canvas.topAnchor.constraint(equalTo: tabs.bottomAnchor, constant: 8),
            canvas.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            canvas.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            canvas.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.38),
            scroll.topAnchor.constraint(equalTo: canvas.bottomAnchor, constant: 8),
            scroll.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scroll.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scroll.bottomAnchor.constraint(equalTo: g.bottomAnchor),
            stack.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor),
            stack.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor, constant: -30),
            stack.leadingAnchor.constraint(equalTo: scroll.frameLayoutGuide.leadingAnchor, constant: 12),
            stack.trailingAnchor.constraint(equalTo: scroll.frameLayoutGuide.trailingAnchor, constant: -12),
            stack.widthAnchor.constraint(equalTo: scroll.frameLayoutGuide.widthAnchor, constant: -24)])
        reload()
    }

    private func close() {
        dismiss(animated: true) { [weak host] in host?.refreshToolbar(); host?.refreshPanel(); host?.render() }
    }

    // MARK: helpers
    private func btn(_ title: String, _ fill: Int32 = C.CARD2, _ tc: Int32 = C.TEXT, _ act: @escaping () -> Void) -> UIButton {
        let b = UIButton(type: .system)
        b.setTitle(title, for: .normal); b.setTitleColor(argbToUIColor(tc), for: .normal)
        b.titleLabel?.font = .systemFont(ofSize: 14, weight: .semibold)
        b.backgroundColor = argbToUIColor(fill); b.layer.cornerRadius = 10
        b.contentEdgeInsets = UIEdgeInsets(top: 8, left: 12, bottom: 8, right: 12)
        b.addAction(UIAction { _ in act() }, for: .touchUpInside)
        b.heightAnchor.constraint(greaterThanOrEqualToConstant: 38).isActive = true
        return b
    }
    private func lbl(_ s: String, _ size: CGFloat = 14, _ color: Int32 = C.TEXT, bold: Bool = false) -> UILabel {
        let l = UILabel(); l.text = s; l.numberOfLines = 0; l.textColor = argbToUIColor(color)
        l.font = .systemFont(ofSize: size, weight: bold ? .bold : .regular); return l
    }
    private func slider(_ name: String, _ lo: Float, _ hi: Float, _ v: Float, _ dec: Int = 2,
                        _ change: @escaping (Float) -> Void) -> RulerSlider {
        let s = RulerSlider(frame: .zero)
        s.label = name; s.lo = lo; s.hi = hi; s.dec = dec; s.value = v; s.canKey = false
        s.onBegin = { [weak self] in self?.host?.pushUndo() }
        s.onChange = change
        s.heightAnchor.constraint(equalToConstant: 60).isActive = true
        return s
    }
    private func ask(_ title: String, _ items: [String], _ pick: @escaping (Int) -> Void) {
        _ = Dlg(self).setTitle(title).setItems(items) { _, i in pick(i) }.show()
    }
    private func fmt(_ v: Float) -> String { String(format: "%.2f", v) }
    private func card(_ views: [UIView]) -> UIView {
        let c = UIView(); c.backgroundColor = argbToUIColor(C.CARD); c.layer.cornerRadius = 12
        let s = UIStackView(arrangedSubviews: views); s.axis = .vertical; s.spacing = 6
        s.translatesAutoresizingMaskIntoConstraints = false; c.addSubview(s)
        NSLayoutConstraint.activate([s.topAnchor.constraint(equalTo: c.topAnchor, constant: 10),
            s.bottomAnchor.constraint(equalTo: c.bottomAnchor, constant: -10),
            s.leadingAnchor.constraint(equalTo: c.leadingAnchor, constant: 10),
            s.trailingAnchor.constraint(equalTo: c.trailingAnchor, constant: -10)])
        return c
    }
    private func members() -> [Layer] { Editor.scene.layers.filter { rig.members.contains($0.id) } }
    private func layer(_ id: Int) -> Layer? { Editor.scene.layers.first { $0.id == id } }
    private var sel: Layer? { rig.members.contains(selId) ? layer(selId) : nil }
    private var active: RigParam? { rig.param(activeParam) }
    private func redraw() { canvas.setNeedsDisplay(); host?.render() }

    static let propList: [(String, String)] = [("Position X", "x"), ("Position Y", "y"),
                                               ("Rotate", "rotZ"), ("Scale", "scale"), ("Opacity", "opacity")]
    private func propName(_ k: String) -> String {
        if let p = Self.propList.first(where: { $0.1 == k }) { return p.0 }
        return k.hasPrefix("pp") ? "Mesh pin " + k.dropFirst(2) : k
    }
    private func propRange(_ k: String) -> (Float, Float) {
        switch k { case "rotZ": return (-180, 180); case "opacity", "scale": return (-1, 1); default: return (-2, 2) }
    }

    // MARK: panel
    private func reload() {
        for (i, b) in tabButtons.enumerated() {
            b.backgroundColor = argbToUIColor(i == curTab ? C.GREEN : C.CARD2)
            b.setTitleColor(argbToUIColor(i == curTab ? C.BG : C.TEXT), for: .normal)
        }
        canvas.mode = curTab == 0 ? 0 : curTab == 1 ? 1 : curTab == 2 ? 2 : 3
        canvas.selId = selId
        for v in stack.arrangedSubviews { stack.removeArrangedSubview(v); v.removeFromSuperview() }
        angleSlider = nil
        switch curTab {
        case 0: buildParams()
        case 1: buildHierarchy()
        case 2: buildMesh()
        default: buildRotate()
        }
        canvas.setNeedsDisplay()
    }

    private func activeSection() {
        guard let p = active else { stack.addArrangedSubview(lbl("Add a parameter in the Params tab first.", 13, C.DIM)); return }
        let pick = btn("Parameter: \(p.name)  ▾") { [weak self] in
            guard let self = self else { return }
            self.ask("Active parameter", self.rig.params.map { $0.name }) { i in
                self.activeParam = self.rig.params[i].id; self.reload()
            }
        }
        stack.addArrangedSubview(pick)
        stack.addArrangedSubview(slider(p.name, p.lo, p.hi, rig.value(p, group, Editor.time)) { [weak self] v in
            guard let self = self else { return }
            self.group.track(p.key).set(Editor.time, v, false)
            self.syncAngle(); self.redraw()
        })
    }

    private func syncAngle() {
        guard let s = angleSlider, let p = active, let l = sel else { return }
        s.value = rig.binding(p, l.id, "rotZ", create: false)?.eval(rig.value(p, group, Editor.time)) ?? 0
    }

    // ---- params
    private func buildParams() {
        stack.addArrangedSubview(btn("+ Add parameter", C.GREEN, C.BG) { [weak self] in self?.addParamDialog() })
        if rig.params.isEmpty { stack.addArrangedSubview(lbl("No parameters yet. Add one (e.g. Angle X, range -30 to 30), then connect it to layers.", 13, C.DIM)) }
        for p in rig.params {
            var rows: [UIView] = []
            let head = UIStackView(arrangedSubviews: [
                lbl(p.name, 15, C.TEXT, bold: true), UIView(),
                btn("Connect") { [weak self] in self?.connectDialog(p) },
                btn("✕", C.CARD2, C.DIM) { [weak self] in
                    guard let self = self else { return }
                    self.host?.pushUndo()
                    self.rig.params.removeAll { $0.id == p.id }
                    self.rig.bindings.removeAll { $0.paramId == p.id }
                    self.group.props[p.key] = nil
                    if self.activeParam == p.id { self.activeParam = self.rig.params.first?.id ?? -1 }
                    self.reload(); self.redraw() }])
            head.spacing = 6; head.alignment = .center
            rows.append(head)
            rows.append(slider("Value  (\(fmt(p.lo)) … \(fmt(p.hi)))", p.lo, p.hi, rig.value(p, group, Editor.time)) { [weak self] v in
                guard let self = self else { return }
                self.group.track(p.key).set(Editor.time, v, false); self.redraw() })
            for b in rig.bindings where b.paramId == p.id {
                let name = layer(b.layerId)?.name ?? "?"
                let h = UIStackView(arrangedSubviews: [
                    lbl("\(name) · \(propName(b.key))", 13, C.GREEN, bold: true), UIView(),
                    btn("+ Key") { [weak self] in
                        guard let self = self else { return }
                        let pv = self.rig.value(p, self.group, Editor.time)
                        self.host?.pushUndo(); b.setKey(pv, b.eval(pv)); self.reload() },
                    btn("✕", C.CARD2, C.DIM) { [weak self] in
                        self?.host?.pushUndo(); self?.rig.bindings.removeAll { $0.id == b.id }
                        self?.reload(); self?.redraw() }])
                h.spacing = 6; h.alignment = .center
                rows.append(h)
                let r = propRange(b.key)
                for (i, k) in b.keys.enumerated() {
                    rows.append(slider("at \(fmt(k.0))", r.0, r.1, k.1) { [weak self] v in
                        if i < b.keys.count { b.keys[i].1 = v }; self?.redraw() })
                }
            }
            stack.addArrangedSubview(card(rows))
        }
    }

    private func addParamDialog() {
        func field(_ ph: String, _ text: String, _ num: Bool) -> UITextField {
            let f = UITextField(); f.placeholder = ph; f.text = text
            f.textColor = argbToUIColor(C.TEXT); f.backgroundColor = argbToUIColor(C.CARD2)
            f.layer.cornerRadius = 8; f.keyboardType = num ? .numbersAndPunctuation : .default
            f.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: 10)); f.leftViewMode = .always
            f.heightAnchor.constraint(equalToConstant: 40).isActive = true; return f
        }
        let n = field("Name", "Param \(rig.nextId)", false)
        let lo = field("Min", "-30", true), hi = field("Max", "30", true), df = field("Default", "0", true)
        let sv = UIStackView(arrangedSubviews: [n, lo, hi, df]); sv.axis = .vertical; sv.spacing = 8
        _ = Dlg(self).setTitle("New parameter").setView(sv)
            .setPositiveButton("Add") { [weak self] _, _ in
                guard let self = self else { return }
                var a = Float(lo.text ?? "") ?? -30, b = Float(hi.text ?? "") ?? 30
                if a > b { swap(&a, &b) }
                if b - a < 0.001 { b = a + 1 }
                let d = min(b, max(a, Float(df.text ?? "") ?? 0))
                self.host?.pushUndo()
                let p = self.rig.addParam((n.text ?? "").isEmpty ? "Param" : n.text!, a, b, d, on: self.group)
                self.activeParam = p.id
                self.reload()
            }.setNegativeButton("Cancel", nil).show()
    }

    private func connectDialog(_ p: RigParam) {
        let ms = members()
        if ms.isEmpty { host?.toast("Import layers into this rig first (main editor: tap image → To Rig)"); return }
        ask("Connect \(p.name) to layer", ms.map { $0.name }) { [weak self] i in
            guard let self = self else { return }
            let l = ms[i]
            self.ask("Drive which property?", Self.propList.map { $0.0 }) { j in
                let key = Self.propList[j].1
                self.host?.pushUndo()
                let b = self.rig.binding(p, l.id, key, create: true)!
                let d: Float = key == "rotZ" ? 30 : key == "scale" ? 0.3 : 0.2
                if key == "opacity" { b.keys = [(p.lo, -1), (p.hi, 0)] }
                else { b.setKey(p.lo, -d); b.setKey(p.hi, d) }
                self.reload(); self.redraw()
            }
        }
    }

    // ---- hierarchy
    private func buildHierarchy() {
        stack.addArrangedSubview(lbl("Tap a layer here or in the canvas to select it. To bring layers in: main editor → tap the image → To Rig → pick this rig group.", 12, C.DIM))
        let ms = members()
        let ids = Set(ms.map { $0.id })
        var order: [(Layer, Int)] = []
        func walk(_ l: Layer, _ d: Int) { order.append((l, d)); for c in ms where c.parentId == l.id { walk(c, d + 1) } }
        for l in ms where !ids.contains(l.parentId) { walk(l, 0) }
        if ms.isEmpty { stack.addArrangedSubview(lbl("This rig group is empty.", 13, C.DIM)) }
        for (l, d) in order {
            let name = lbl(String(repeating: "   ", count: d) + (d > 0 ? "↳ " : "") + l.name, 14,
                           l.id == selId ? C.GREEN : C.TEXT, bold: l.id == selId)
            let row = UIStackView(arrangedSubviews: [name, UIView(),
                btn(l.visible ? "Hide" : "Show") { [weak self] in l.visible.toggle(); self?.reload(); self?.redraw() },
                btn("Parent") { [weak self] in self?.parentDialog(l, ms) },
                btn("Remove", C.CARD2, C.DIM) { [weak self] in
                    guard let self = self else { return }
                    self.host?.pushUndo(); self.rig.removeLayer(l.id)
                    for c in self.members() where c.parentId == l.id { c.parentId = self.group.id }
                    l.parentId = -1; if self.selId == l.id { self.selId = -1 }
                    self.reload(); self.redraw() }])
            row.spacing = 6; row.alignment = .center
            let tap = UITapGestureRecognizer(target: self, action: #selector(rowTap(_:)))
            name.isUserInteractionEnabled = true; name.addGestureRecognizer(tap); name.tag = l.id
            stack.addArrangedSubview(card([row]))
        }
    }
    @objc private func rowTap(_ g: UITapGestureRecognizer) { selId = g.view?.tag ?? -1; reload() }

    private func parentDialog(_ l: Layer, _ ms: [Layer]) {
        func isDesc(_ c: Layer) -> Bool {
            var cur: Layer? = c; var n = 0
            while let x = cur, n < 64 { if x.id == l.id { return true }; cur = layer(x.parentId); n += 1 }
            return false
        }
        let cands = ms.filter { !isDesc($0) }
        ask("Parent of \(l.name)", ["Rig group (root)"] + cands.map { $0.name }) { [weak self] i in
            guard let self = self else { return }
            self.host?.pushUndo()
            l.parentId = i == 0 ? self.group.id : cands[i - 1].id
            self.reload(); self.redraw()
        }
    }

    // ---- mesh
    private func buildMesh() {
        guard let l = sel else { stack.addArrangedSubview(lbl("Select an image layer (tap it in the canvas or Hierarchy).", 13, C.DIM)); return }
        stack.addArrangedSubview(lbl("Mesh deformer — \(l.name)", 15, C.TEXT, bold: true))
        if l.type != .IMAGE { stack.addArrangedSubview(lbl("Mesh deformers need an image layer.", 13, C.DIM)); return }
        guard let pp = l.puppet, !pp.pins.isEmpty else {
            stack.addArrangedSubview(btn("Create mesh (4×4 points)", C.GREEN, C.BG) { [weak self] in
                self?.host?.pushUndo()
                let pu = l.puppet ?? Puppet(); pu.on = true; pu.density = 1
                for j in 0..<4 { for i in 0..<4 {
                    pu.pins.append(PuppetPin(pu.nextId, -0.9 + 1.8 * Float(i) / 3, -0.9 + 1.8 * Float(j) / 3)); pu.nextId += 1 } }
                l.puppet = pu; self?.reload(); self?.redraw() })
            return
        }
        activeSection()
        stack.addArrangedSubview(lbl("Move the parameter slider to a pose, then drag mesh points in the canvas. Each drag is stored as a keyform at that parameter value.", 12, C.DIM))
        stack.addArrangedSubview(slider("Softness (falloff)", 0.5, 6, pp.stiffness, 1) { [weak self] v in pp.stiffness = v; self?.redraw() })
        let row = UIStackView(arrangedSubviews: [
            btn("Clear keys of this parameter") { [weak self] in
                guard let self = self, let p = self.active else { return }
                self.host?.pushUndo()
                self.rig.bindings.removeAll { $0.paramId == p.id && $0.layerId == l.id && $0.key.hasPrefix("pp") }
                self.redraw() },
            btn("Remove mesh", C.CARD2, C.DIM) { [weak self] in
                guard let self = self else { return }
                self.host?.pushUndo()
                self.rig.bindings.removeAll { $0.layerId == l.id && $0.key.hasPrefix("pp") }
                l.puppet = nil; self.reload(); self.redraw() }])
        row.spacing = 8; row.distribution = .fillEqually
        stack.addArrangedSubview(row)
    }

    private func pinMoved(_ l: Layer, _ pin: PuppetPin, _ ox: Float, _ oy: Float, _ ended: Bool) {
        let t = Editor.time
        let bx = l.props["pp\(pin.id)x"]?.eval(t) ?? 0, by = l.props["pp\(pin.id)y"]?.eval(t) ?? 0
        guard let p = active else { host?.toast("Add / pick a parameter first"); return }
        let (ex, ey) = (ox - bx, oy - by)
        if !ended { l.rigOff["pp\(pin.id)x"] = ex; l.rigOff["pp\(pin.id)y"] = ey; host?.render(); return }
        let pv = rig.value(p, group, t)
        rig.binding(p, l.id, "pp\(pin.id)x", create: true)?.setKey(pv, ex)
        rig.binding(p, l.id, "pp\(pin.id)y", create: true)?.setKey(pv, ey)
        redraw()
    }

    // ---- rotate
    private func buildRotate() {
        guard let l = sel else { stack.addArrangedSubview(lbl("Select a layer (tap it in the canvas or Hierarchy).", 13, C.DIM)); return }
        stack.addArrangedSubview(lbl("Rotate deformer — \(l.name)", 15, C.TEXT, bold: true))
        activeSection()
        guard let p = active else { return }
        let cur = rig.binding(p, l.id, "rotZ", create: false)?.eval(rig.value(p, group, Editor.time)) ?? 0
        let s = slider("Rotation at this parameter value (°)", -180, 180, cur, 1) { [weak self] v in
            guard let self = self else { return }
            let pv = self.rig.value(p, self.group, Editor.time)
            self.rig.binding(p, l.id, "rotZ", create: true)?.setKey(pv, v)
            self.redraw()
        }
        angleSlider = s; stack.addArrangedSubview(s)
        stack.addArrangedSubview(lbl("Drag the cyan pivot in the canvas to set the point it rotates around (the layer itself stays put).", 12, C.DIM))
        stack.addArrangedSubview(btn("Reset pivot to center") { [weak self] in
            self?.host?.pushUndo(); self?.host?.setAnchorKeepVisual(l, 50, 50); self?.redraw() })
        stack.addArrangedSubview(lbl("Tip: set the parameter to its min and max and set an angle at each — a key is stored per value.", 12, C.DIM))
    }
}
