//
//  PlyImport.swift — .ply / .spz point maps (+ optional collider mesh) -> .glb.
//  The GLB goes through the normal GlbModel / Metal path: a POINTS primitive with vertex colours,
//  and (optionally) a triangle mesh named "SaikiCollider" that the renderer uses as an invisible
//  depth occluder (points / objects behind a wall are hidden) and a physics-style collision surface.
//
//  Supported: PLY ascii / binary little+big endian (xyz, rgb, 3D-Gaussian-splat f_dc + opacity, faces),
//  SPZ v1-v3 (gzip). Points are shuffled once, so the first N points are a uniform random subset —
//  that is what makes the "Density" slider cheap (it just draws fewer).
//
import Foundation
import simd

enum PlyImport {
    static var lastError = ""
    private static var sawSplat = false
    static let balanced = 600_000, low = 150_000, fullCap = 3_000_000
    static let maxPoints = balanced
    static let colliderName = "SaikiCollider"

    struct Cloud { var pos: [Float] = []; var col: [Float] = [] }          // xyz*n, rgba*n
    struct Mesh { var pos: [Float] = []; var idx: [UInt32] = [] }

    /// Layer path -> is a converted point map?
    static func isPointMap(_ path: String?) -> Bool { (path ?? "").contains("_ply") && (path ?? "").hasSuffix(".glb") }

    // MARK: entry points

    struct Loaded { var cloud: Cloud; var mesh: Mesh?; var splat: Bool; var count: Int { cloud.pos.count / 3 } }

    /// Step 1: parse the file (no thinning yet) so the UI can ask about quality when it is big.
    static func load(_ path: String) -> Loaded? {
        lastError = ""
        guard let data = FileManager.default.contents(atPath: path), data.count > 16 else { lastError = "Could not read the file"; return nil }
        let ext = (path as NSString).pathExtension.lowercased()
        sawSplat = false
        var cloud: Cloud, mesh: Mesh? = nil
        if ext == "spz" || (data[0] == 0x1f && data[1] == 0x8b) {
            guard let c = parseSpz([UInt8](data)) else { return nil }
            cloud = c; sawSplat = true
        } else {
            guard let (c, m) = parsePly([UInt8](data)) else { return nil }
            cloud = c; mesh = m
        }
        guard cloud.pos.count >= 3 else { lastError = lastError.isEmpty ? "No points found in this file" : lastError; return nil }
        return Loaded(cloud: cloud, mesh: mesh, splat: sawSplat)
    }

    /// Step 2: thin to `limit` points and write the .glb (a mesh inside the PLY becomes the collider).
    static func finish(_ ld: Loaded, path: String, limit: Int) -> String? {
        var cloud = ld.cloud
        shuffleAndCap(&cloud, limit: limit)
        let stem = (path as NSString).deletingPathExtension
        try? savePoints(cloud, to: stem + "_pts.bin")
        if ld.splat { try? Data().write(to: URL(fileURLWithPath: stem + "_flip.flag")) } else { try? FileManager.default.removeItem(atPath: stem + "_flip.flag") }
        return writeGlb(cloud, ld.mesh, stem: stem)
    }

    static func convert(_ path: String, limit: Int = balanced) -> String? {
        guard let ld = load(path) else { return nil }
        return finish(ld, path: path, limit: limit)
    }

    /// Properties tab: attach a collider mesh (.ply with faces, or .obj) to an imported point map.
    /// Returns the NEW .glb path (new path, so cached models are never stale).
    static func attachCollider(_ colliderFile: String, toPointMap glb: String) -> String? {
        lastError = ""
        guard let data = FileManager.default.contents(atPath: colliderFile) else { lastError = "Could not read the collider file"; return nil }
        let ext = (colliderFile as NSString).pathExtension.lowercased()
        var mesh: Mesh? = nil
        if ext == "obj" { mesh = parseObj(data) }
        else if let (_, m) = parsePly([UInt8](data), meshOnly: true) { mesh = m }
        if var fm = mesh, FileManager.default.fileExists(atPath: baseStem(glb) + "_flip.flag") {      // same Y-down frame as the splat
            for i in 0..<(fm.pos.count / 3) { fm.pos[i * 3 + 1] = -fm.pos[i * 3 + 1]; fm.pos[i * 3 + 2] = -fm.pos[i * 3 + 2] }
            mesh = fm
        }
        guard let m = mesh, !m.idx.isEmpty else { lastError = lastError.isEmpty ? "No faces found: the collider needs a triangle mesh" : lastError; return nil }
        let stem = baseStem(glb)
        guard let cloud = loadPoints(stem + "_pts.bin") else { lastError = "Point data missing, re-import the point map"; return nil }
        return writeGlb(cloud, m, stem: stem)
    }

    /// Removes the collider (rebuilds the GLB with points only).
    static func removeCollider(fromPointMap glb: String) -> String? {
        let stem = baseStem(glb)
        guard let cloud = loadPoints(stem + "_pts.bin") else { return nil }
        return writeGlb(cloud, nil, stem: stem)
    }

    static func hasCollider(_ glb: String) -> Bool { FileManager.default.fileExists(atPath: baseStem(glb) + "_col.flag") && glbHasCollider(glb) }
    private static func glbHasCollider(_ glb: String) -> Bool {
        guard let h = FileHandle(forReadingAtPath: glb) else { return false }
        defer { try? h.close() }
        let d = h.readData(ofLength: 4096)
        return d.range(of: Data(colliderName.utf8)) != nil
    }
    static func pointCount(_ glb: String) -> Int {
        guard let a = try? FileManager.default.attributesOfItem(atPath: baseStem(glb) + "_pts.bin"), let s = a[.size] as? Int else { return 0 }
        return max(0, (s - 4) / 28)
    }

    // MARK: stem / sidecar helpers

    private static func baseStem(_ glb: String) -> String {
        var s = (glb as NSString).deletingPathExtension
        if let r = s.range(of: "_ply", options: .backwards) { s = String(s[s.startIndex..<r.lowerBound]) }
        return s
    }
    private static func savePoints(_ c: Cloud, to path: String) throws {
        var d = Data()
        var n = UInt32(c.pos.count / 3); d.append(Data(bytes: &n, count: 4))
        for i in 0..<Int(n) {
            var r = [c.pos[i * 3], c.pos[i * 3 + 1], c.pos[i * 3 + 2], c.col[i * 4], c.col[i * 4 + 1], c.col[i * 4 + 2], c.col[i * 4 + 3]]
            d.append(Data(bytes: &r, count: 28))
        }
        try d.write(to: URL(fileURLWithPath: path))
    }
    private static func loadPoints(_ path: String) -> Cloud? {
        guard let d = FileManager.default.contents(atPath: path), d.count >= 4 else { return nil }
        let n = d.withUnsafeBytes { Int($0.loadUnaligned(fromByteOffset: 0, as: UInt32.self)) }
        guard d.count >= 4 + n * 28 else { return nil }
        var c = Cloud(); c.pos.reserveCapacity(n * 3); c.col.reserveCapacity(n * 4)
        d.withUnsafeBytes { rb in
            for i in 0..<n {
                let o = 4 + i * 28
                for k in 0..<3 { c.pos.append(rb.loadUnaligned(fromByteOffset: o + k * 4, as: Float.self)) }
                for k in 3..<7 { c.col.append(rb.loadUnaligned(fromByteOffset: o + k * 4, as: Float.self)) }
            }
        }
        return c
    }

    private static func shuffleAndCap(_ c: inout Cloud, limit: Int) {
        let n = c.pos.count / 3
        var order = Array(0..<n)
        var rng = SplitMix(seed: 0x5A1C1)
        for i in stride(from: n - 1, to: 0, by: -1) { order.swapAt(i, Int(rng.next() % UInt64(i + 1))) }
        let m = min(n, max(1000, limit))
        var p = [Float](), q = [Float]()
        p.reserveCapacity(m * 3); q.reserveCapacity(m * 4)
        for k in 0..<m {
            let i = order[k]
            p.append(c.pos[i * 3]); p.append(c.pos[i * 3 + 1]); p.append(c.pos[i * 3 + 2])
            q.append(c.col[i * 4]); q.append(c.col[i * 4 + 1]); q.append(c.col[i * 4 + 2]); q.append(c.col[i * 4 + 3])
        }
        c.pos = p; c.col = q
    }
    private struct SplitMix { var s: UInt64; init(seed: UInt64) { s = seed }
        mutating func next() -> UInt64 { s &+= 0x9E3779B97F4A7C15; var z = s; z = (z ^ (z >> 30)) &* 0xBF58476D1CE4E5B9; z = (z ^ (z >> 27)) &* 0x94D049BB133111EB; return z ^ (z >> 31) } }

    // MARK: PLY

    private enum T { case i8, u8, i16, u16, i32, u32, f32, f64
        var size: Int { switch self { case .i8, .u8: return 1; case .i16, .u16: return 2; case .i32, .u32, .f32: return 4; case .f64: return 8 } }
        static func from(_ s: String) -> T? {
            switch s { case "char", "int8": return .i8; case "uchar", "uint8": return .u8; case "short", "int16": return .i16
            case "ushort", "uint16": return .u16; case "int", "int32": return .i32; case "uint", "uint32": return .u32
            case "float", "float32": return .f32; case "double", "float64": return .f64; default: return nil } }
    }
    private struct Prop { var name: String; var t: T; var listCount: T? = nil }
    private struct Elem { var name: String; var count: Int; var props: [Prop] = [] }

    private static func parsePly(_ b: [UInt8], meshOnly: Bool = false) -> (Cloud, Mesh?)? {
        // header
        guard let hEnd = findHeaderEnd(b) else { lastError = "Not a valid PLY file"; return nil }
        let header = String(decoding: b[0..<hEnd.text], as: UTF8.self)
        var fmt = "ascii", elems: [Elem] = []
        for raw in header.split(whereSeparator: { $0 == "\n" || $0 == "\r" }) {
            let w = raw.split(separator: " ").map(String.init)
            guard let k = w.first else { continue }
            if k == "format", w.count > 1 { fmt = w[1] }
            else if k == "element", w.count > 2 { elems.append(Elem(name: w[1], count: Int(w[2]) ?? 0)) }
            else if k == "property", !elems.isEmpty {
                if w.count >= 5, w[1] == "list", let ct = T.from(w[2]), let it = T.from(w[3]) { elems[elems.count - 1].props.append(Prop(name: w[4], t: it, listCount: ct)) }
                else if w.count >= 3, let t = T.from(w[1]) { elems[elems.count - 1].props.append(Prop(name: w[2], t: t)) }
            }
        }
        guard elems.contains(where: { $0.name == "vertex" }) else { lastError = "PLY has no vertices"; return nil }
        let big = fmt == "binary_big_endian"
        var cloud = Cloud(), mesh = Mesh()
        var pos = hEnd.data

        if fmt == "ascii" {
            let body = String(decoding: b[pos...], as: UTF8.self)
            var lines = body.split(whereSeparator: { $0 == "\n" || $0 == "\r" }).makeIterator()
            for e in elems {
                for _ in 0..<e.count {
                    guard let ln = lines.next() else { break }
                    let tok = ln.split(separator: " ")
                    if e.name == "vertex" { readVertexASCII(e, tok, &cloud) }
                    else if e.name == "face", let f = e.props.firstIndex(where: { $0.listCount != nil }) {
                        var t = 0
                        for (pi, p) in e.props.enumerated() {
                            if p.listCount != nil {
                                let c = Int(tok[safe: t] ?? "0") ?? 0; t += 1
                                if pi == f { var v: [UInt32] = []; for k in 0..<c { v.append(UInt32(tok[safe: t + k] ?? "0") ?? 0) }; fan(v, &mesh) }
                                t += c
                            } else { t += 1 }
                        }
                    }
                }
            }
        } else {
            for e in elems {
                let fixed = !e.props.contains { $0.listCount != nil }
                let stride = e.props.reduce(0) { $0 + $1.t.size }
                if e.name == "vertex" {
                    guard fixed else { lastError = "Unsupported vertex layout"; return nil }
                    guard pos + stride * e.count <= b.count else { lastError = "PLY file is truncated"; return nil }
                    readVertexBinary(e, b, pos, stride, big, &cloud)
                    pos += stride * e.count
                } else if e.name == "face" {
                    for _ in 0..<e.count {
                        for p in e.props {
                            if let ct = p.listCount {
                                guard pos + ct.size <= b.count else { break }
                                let c = Int(rd(b, pos, ct, big)); pos += ct.size
                                var v: [UInt32] = []
                                for _ in 0..<c { guard pos + p.t.size <= b.count else { break }; v.append(UInt32(max(0, rd(b, pos, p.t, big)))); pos += p.t.size }
                                if p.name == "vertex_indices" || p.name == "vertex_index" { fan(v, &mesh) }
                            } else { pos += p.t.size }
                        }
                    }
                } else if fixed { pos += stride * e.count }
                else { break }      // unknown list element: stop, vertices/faces are already read
            }
        }
        if !meshOnly && cloud.pos.isEmpty { lastError = "PLY has no vertices"; return nil }
        // mesh vertices = the vertex element positions
        if !mesh.idx.isEmpty {
            mesh.pos = cloud.pos
            let n = UInt32(cloud.pos.count / 3)
            if mesh.idx.contains(where: { $0 >= n }) { mesh = Mesh() }
        }
        return (cloud, mesh.idx.isEmpty ? nil : mesh)
    }

    private static func fan(_ v: [UInt32], _ m: inout Mesh) {
        guard v.count >= 3 else { return }
        for i in 1..<(v.count - 1) { m.idx.append(v[0]); m.idx.append(v[i]); m.idx.append(v[i + 1]) }
    }
    private static func findHeaderEnd(_ b: [UInt8]) -> (text: Int, data: Int)? {
        let key = Array("end_header".utf8)
        guard b.count > 12 else { return nil }
        var i = 0
        while i + key.count < min(b.count, 65536) {
            if b[i] == key[0], Array(b[i..<(i + key.count)]) == key {
                var j = i + key.count
                if j < b.count, b[j] == 13 { j += 1 }
                if j < b.count, b[j] == 10 { j += 1 }
                return (i, j)
            }
            i += 1
        }
        return nil
    }
    @inline(__always) private static func rd(_ b: [UInt8], _ o: Int, _ t: T, _ big: Bool) -> Float {
        return b.withUnsafeBufferPointer { p -> Float in
            let r = UnsafeRawPointer(p.baseAddress! + o)
            switch t {
            case .i8: return Float(Int8(bitPattern: p[o]))
            case .u8: return Float(p[o])
            case .i16: let v = r.loadUnaligned(as: Int16.self); return Float(big ? Int16(bigEndian: v) : Int16(littleEndian: v))
            case .u16: let v = r.loadUnaligned(as: UInt16.self); return Float(big ? UInt16(bigEndian: v) : UInt16(littleEndian: v))
            case .i32: let v = r.loadUnaligned(as: Int32.self); return Float(big ? Int32(bigEndian: v) : Int32(littleEndian: v))
            case .u32: let v = r.loadUnaligned(as: UInt32.self); return Float(big ? UInt32(bigEndian: v) : UInt32(littleEndian: v))
            case .f32: let v = r.loadUnaligned(as: UInt32.self); return Float(bitPattern: big ? UInt32(bigEndian: v) : UInt32(littleEndian: v))
            case .f64: let v = r.loadUnaligned(as: UInt64.self); return Float(Double(bitPattern: big ? UInt64(bigEndian: v) : UInt64(littleEndian: v)))
            }
        }
    }

    private struct VMap { var x = -1, y = -1, z = -1, r = -1, g = -1, b = -1, a = -1, dc0 = -1, dc1 = -1, dc2 = -1, op = -1; var intColor = false }
    private static func map(_ e: Elem) -> VMap {
        var m = VMap()
        for (i, p) in e.props.enumerated() {
            switch p.name {
            case "x": m.x = i; case "y": m.y = i; case "z": m.z = i
            case "red", "r", "diffuse_red": m.r = i; m.intColor = p.t != .f32 && p.t != .f64
            case "green", "g", "diffuse_green": m.g = i; case "blue", "b", "diffuse_blue": m.b = i
            case "alpha": m.a = i
            case "f_dc_0": m.dc0 = i; case "f_dc_1": m.dc1 = i; case "f_dc_2": m.dc2 = i
            case "opacity": m.op = i
            default: break
            }
        }
        return m
    }
    /// Appends one point; returns nothing. `v` gives property i's value.
    private static func addPoint(_ m: VMap, _ v: (Int) -> Float, _ c: inout Cloud) {
        guard m.x >= 0, m.y >= 0, m.z >= 0 else { return }
        let x = v(m.x); var y = v(m.y), z = v(m.z)
        var rgb: (Float, Float, Float) = (0.85, 0.87, 0.92), al: Float = 1
        let splat = m.dc0 >= 0 && m.dc1 >= 0 && m.dc2 >= 0
        if splat {
            let k: Float = 0.28209479
            rgb = (min(1, max(0, 0.5 + k * v(m.dc0))), min(1, max(0, 0.5 + k * v(m.dc1))), min(1, max(0, 0.5 + k * v(m.dc2))))
            if m.op >= 0 { al = 1 / (1 + exp(-v(m.op))); if al < 0.06 { return } }      // drop near-transparent splats
            y = -y; z = -z; sawSplat = true                                              // 3DGS is Y-down
        } else if m.r >= 0, m.g >= 0, m.b >= 0 {
            let s: Float = m.intColor ? 1 / 255 : 1
            rgb = (v(m.r) * s, v(m.g) * s, v(m.b) * s)
        }
        guard x.isFinite, y.isFinite, z.isFinite else { return }
        c.pos.append(x); c.pos.append(y); c.pos.append(z)
        c.col.append(rgb.0); c.col.append(rgb.1); c.col.append(rgb.2); c.col.append(al)
    }
    private static func readVertexBinary(_ e: Elem, _ b: [UInt8], _ start: Int, _ stride: Int, _ big: Bool, _ c: inout Cloud) {
        let m = map(e)
        var offs = [Int](), o = 0
        for p in e.props { offs.append(o); o += p.t.size }
        c.pos.reserveCapacity(e.count * 3); c.col.reserveCapacity(e.count * 4)
        for i in 0..<e.count {
            let base = start + i * stride
            addPoint(m, { rd(b, base + offs[$0], e.props[$0].t, big) }, &c)
        }
    }
    private static func readVertexASCII(_ e: Elem, _ tok: [Substring], _ c: inout Cloud) {
        let m = map(e)
        addPoint(m, { Float(tok[safe: $0] ?? "0") ?? 0 }, &c)
    }

    // MARK: OBJ (collider only)

    private static func parseObj(_ data: Data) -> Mesh? {
        guard let s = String(data: data, encoding: .utf8) else { return nil }
        var m = Mesh()
        for ln in s.split(whereSeparator: { $0 == "\n" || $0 == "\r" }) {
            let w = ln.split(separator: " ")
            if w.first == "v", w.count >= 4 { for k in 1...3 { m.pos.append(Float(w[k]) ?? 0) } }
            else if w.first == "f", w.count >= 4 {
                let n = m.pos.count / 3
                let v: [UInt32] = w.dropFirst().compactMap { t in
                    guard var i = Int(t.split(separator: "/", omittingEmptySubsequences: false).first ?? "") else { return nil }
                    if i < 0 { i = n + i + 1 }
                    return i >= 1 && i <= n ? UInt32(i - 1) : nil
                }
                fan(v, &m)
            }
        }
        return m.idx.isEmpty ? nil : m
    }

    // MARK: SPZ (gzip'd, Niantic format v1-v3)

    private static func parseSpz(_ gz: [UInt8]) -> Cloud? {
        var raw = gz
        if gz.count > 18, gz[0] == 0x1f, gz[1] == 0x8b {
            var off = 10
            let flg = gz[3]
            if flg & 4 != 0, off + 2 <= gz.count { off += 2 + Int(gz[off]) + Int(gz[off + 1]) << 8 }
            if flg & 8 != 0 { while off < gz.count, gz[off] != 0 { off += 1 }; off += 1 }
            if flg & 16 != 0 { while off < gz.count, gz[off] != 0 { off += 1 }; off += 1 }
            if flg & 2 != 0 { off += 2 }
            guard off < gz.count - 8 else { lastError = "Invalid .spz file"; return nil }
            raw = VdbVolume.inflate(Array(gz[off..<(gz.count - 8)]))
        }
        guard raw.count > 16 else { lastError = "Could not decompress this .spz file"; return nil }
        func u32(_ o: Int) -> UInt32 { UInt32(raw[o]) | UInt32(raw[o + 1]) << 8 | UInt32(raw[o + 2]) << 16 | UInt32(raw[o + 3]) << 24 }
        guard u32(0) == 0x5053474e else { lastError = "Not an .spz file (bad header)"; return nil }
        let ver = Int(u32(4)), n = Int(u32(8)), frac = Int(raw[13])
        guard n > 0, n < 40_000_000, (1...3).contains(ver) else { lastError = "Unsupported .spz version"; return nil }
        let posBytes = ver == 1 ? 6 : 9
        guard raw.count >= 16 + n * (posBytes + 4) else { lastError = "The .spz file is truncated"; return nil }
        let pO = 16, aO = pO + n * posBytes, cO = aO + n
        var c = Cloud(); c.pos.reserveCapacity(n * 3); c.col.reserveCapacity(n * 4)
        let sc = Float(1 << frac)
        func half(_ lo: UInt8, _ hi: UInt8) -> Float {
            let h = UInt16(lo) | UInt16(hi) << 8
            let s: Float = h & 0x8000 != 0 ? -1 : 1, e = Int((h >> 10) & 31), f = Float(h & 1023)
            if e == 0 { return s * f * 5.9604645e-8 }
            if e == 31 { return 0 }
            return s * (1 + f / 1024) * Float(pow(2.0, Double(e - 15)))
        }
        for i in 0..<n {
            var p = [Float](repeating: 0, count: 3)
            for k in 0..<3 {
                if ver == 1 { let o = pO + i * 6 + k * 2; p[k] = half(raw[o], raw[o + 1]) }
                else {
                    let o = pO + i * 9 + k * 3
                    var v = Int32(raw[o]) | Int32(raw[o + 1]) << 8 | Int32(raw[o + 2]) << 16
                    if v & 0x800000 != 0 { v |= ~0xFFFFFF }
                    p[k] = Float(v) / sc
                }
            }
            let al = Float(raw[aO + i]) / 255
            if al < 0.06 { continue }
            let kk: Float = 0.28209479
            func cc(_ k: Int) -> Float { min(1, max(0, 0.5 + kk * ((Float(raw[cO + i * 3 + k]) / 255 - 0.5) / 0.15))) }
            c.pos.append(p[0]); c.pos.append(-p[1]); c.pos.append(-p[2])
            c.col.append(cc(0)); c.col.append(cc(1)); c.col.append(cc(2)); c.col.append(al)
        }
        return c
    }

    // MARK: GLB writer

    private static func writeGlb(_ cloud: Cloud, _ mesh: Mesh?, stem: String) -> String? {
        let n = cloud.pos.count / 3
        guard n > 0 else { return nil }
        var bin = Data()
        func pad() { while bin.count % 4 != 0 { bin.append(0) } }
        func add<T>(_ a: [T]) -> (off: Int, len: Int) { pad(); let o = bin.count; a.withUnsafeBytes { bin.append(contentsOf: $0) }; return (o, a.count * MemoryLayout<T>.stride) }
        func bounds(_ p: [Float]) -> ([Float], [Float]) {
            var lo = [Float](repeating: .greatestFiniteMagnitude, count: 3), hi = [Float](repeating: -.greatestFiniteMagnitude, count: 3)
            for i in 0..<(p.count / 3) { for k in 0..<3 { lo[k] = min(lo[k], p[i * 3 + k]); hi[k] = max(hi[k], p[i * 3 + k]) } }
            return (lo, hi)
        }
        var views: [String] = [], accs: [String] = []
        func view(_ r: (off: Int, len: Int), _ target: Int) -> Int {
            views.append("{\"buffer\":0,\"byteOffset\":\(r.off),\"byteLength\":\(r.len),\"target\":\(target)}"); return views.count - 1
        }
        func acc(_ v: Int, _ ct: Int, _ count: Int, _ type: String, _ extra: String = "") -> Int {
            accs.append("{\"bufferView\":\(v),\"componentType\":\(ct),\"count\":\(count),\"type\":\"\(type)\"\(extra)}"); return accs.count - 1
        }
        func arr(_ a: [Float]) -> String { "[" + a.map { String($0) }.joined(separator: ",") + "]" }

        let (lo, hi) = bounds(cloud.pos)
        let aP = acc(view(add(cloud.pos), 34962), 5126, n, "VEC3", ",\"min\":\(arr(lo)),\"max\":\(arr(hi))")
        let aC = acc(view(add(cloud.col), 34962), 5126, n, "VEC4")
        var meshes = ["{\"name\":\"SaikiPoints\",\"primitives\":[{\"attributes\":{\"POSITION\":\(aP),\"COLOR_0\":\(aC)},\"mode\":0}]}"]
        var nodes = ["{\"mesh\":0}"], sceneNodes = "0"
        var materials = ""
        if let m = mesh, !m.idx.isEmpty {
            let mp = m.pos
            let (l2, h2) = bounds(mp)
            let vP = acc(view(add(mp), 34962), 5126, mp.count / 3, "VEC3", ",\"min\":\(arr(l2)),\"max\":\(arr(h2))")
            let vI = acc(view(add(m.idx), 34963), 5125, m.idx.count, "SCALAR")
            meshes.append("{\"name\":\"\(colliderName)\",\"primitives\":[{\"attributes\":{\"POSITION\":\(vP)},\"indices\":\(vI),\"material\":0,\"mode\":4}]}")
            nodes.append("{\"mesh\":1}"); sceneNodes = "0,1"
            materials = ",\"materials\":[{\"name\":\"collider\",\"alphaMode\":\"BLEND\",\"pbrMetallicRoughness\":{\"baseColorFactor\":[0.35,0.75,1,0.28],\"metallicFactor\":0,\"roughnessFactor\":1}}]"
            try? Data().write(to: URL(fileURLWithPath: stem + "_col.flag"))
        } else {
            try? FileManager.default.removeItem(atPath: stem + "_col.flag")
        }
        pad()
        let json = "{\"asset\":{\"version\":\"2.0\",\"generator\":\"SaikiMotion PlyImport\"},\"scene\":0,\"scenes\":[{\"nodes\":[\(sceneNodes)]}],\"nodes\":[\(nodes.joined(separator: ","))],\"meshes\":[\(meshes.joined(separator: ","))]\(materials),\"buffers\":[{\"byteLength\":\(bin.count)}],\"bufferViews\":[\(views.joined(separator: ","))],\"accessors\":[\(accs.joined(separator: ","))]}"
        var jd = Data(json.utf8)
        while jd.count % 4 != 0 { jd.append(0x20) }
        func le(_ v: UInt32) -> Data { var x = v.littleEndian; return Data(bytes: &x, count: 4) }
        var out = Data()
        out.append(le(0x46546C67)); out.append(le(2)); out.append(le(UInt32(12 + 8 + jd.count + 8 + bin.count)))
        out.append(le(UInt32(jd.count))); out.append(le(0x4E4F534A)); out.append(jd)
        out.append(le(UInt32(bin.count))); out.append(le(0x004E4942)); out.append(bin)
        let dest = stem + "_ply\(Int(Date().timeIntervalSince1970 * 1000) % 100_000_000).glb"
        do { try out.write(to: URL(fileURLWithPath: dest)) } catch { lastError = "Could not write the converted model"; return nil }
        return dest
    }
}

private extension Array {
    subscript(safe i: Int) -> Element? { i >= 0 && i < count ? self[i] : nil }
}
