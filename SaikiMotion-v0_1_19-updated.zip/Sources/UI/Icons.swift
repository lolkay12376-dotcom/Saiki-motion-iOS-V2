// Icons.swift — the vector icon kit (24x24 path icons) + the IconView button.

import UIKit
import Foundation

// MARK: - Icons

/// Vector icons drawn with Paths on a 24x24 grid. No emoji or font glyphs are used anywhere in the UI.
enum Icons {
    static func draw(_ c: CGContext, _ name: String, _ cx: CGFloat, _ cy: CGFloat,
                     _ size: CGFloat, _ color: Int32) {
        c.saveGState()
        c.translateBy(x: cx - size / 2, y: cy - size / 2)
        c.scaleBy(x: size / 24, y: size / 24)

        let col = argbToUIColor(color)
        var p = CGMutablePath()

        func strokePaint() {
            c.setStrokeColor(col.cgColor)
            c.setLineWidth(2)
            c.setLineCap(.round)
            c.setLineJoin(.round)
        }
        func fillPaint() { c.setFillColor(col.cgColor) }
        func strokePath() { c.addPath(p); c.strokePath(); p = CGMutablePath() }
        func fillPath() { c.addPath(p); c.fillPath(); p = CGMutablePath() }
        func circleFill(_ x: CGFloat, _ y: CGFloat, _ r: CGFloat) {
            fillPaint(); c.fillEllipse(in: CGRect(x: x - r, y: y - r, width: 2 * r, height: 2 * r))
        }
        func circleStroke(_ x: CGFloat, _ y: CGFloat, _ r: CGFloat) {
            strokePaint(); c.strokeEllipse(in: CGRect(x: x - r, y: y - r, width: 2 * r, height: 2 * r))
        }
        func rrStroke(_ rect: CGRect, _ rad: CGFloat) {
            strokePaint()
            c.addPath(CGPath(roundedRect: rect, cornerWidth: rad, cornerHeight: rad, transform: nil))
            c.strokePath()
        }
        func rrFill(_ rect: CGRect, _ rad: CGFloat) {
            fillPaint()
            c.addPath(CGPath(roundedRect: rect, cornerWidth: rad, cornerHeight: rad, transform: nil))
            c.fillPath()
        }
        func line(_ x0: CGFloat, _ y0: CGFloat, _ x1: CGFloat, _ y1: CGFloat) {
            strokePaint()
            c.move(to: CGPoint(x: x0, y: y0))
            c.addLine(to: CGPoint(x: x1, y: y1))
            c.strokePath()
        }
        func rectFill(_ rect: CGRect) { fillPaint(); c.fill(rect) }
        func mv(_ x: CGFloat, _ y: CGFloat) { p.move(to: CGPoint(x: x, y: y)) }
        func lt(_ x: CGFloat, _ y: CGFloat) { p.addLine(to: CGPoint(x: x, y: y)) }
        func closeP() { p.closeSubpath() }
        func quad(_ cx1: CGFloat, _ cy1: CGFloat, _ x: CGFloat, _ y: CGFloat) {
            p.addQuadCurve(to: CGPoint(x: x, y: y), control: CGPoint(x: cx1, y: cy1))
        }
        func cubic(_ c1x: CGFloat, _ c1y: CGFloat, _ c2x: CGFloat, _ c2y: CGFloat, _ x: CGFloat, _ y: CGFloat) {
            p.addCurve(to: CGPoint(x: x, y: y), control1: CGPoint(x: c1x, y: c1y), control2: CGPoint(x: c2x, y: c2y))
        }

        switch name {
        case "back":
            strokePaint(); mv(15, 5); lt(8, 12); lt(15, 19); strokePath()
        case "cube":
            strokePaint()
            mv(12, 3); lt(20, 7.5); lt(20, 16.5); lt(12, 21); lt(4, 16.5); lt(4, 7.5); closeP()
            mv(4, 7.5); lt(12, 12); lt(20, 7.5)
            mv(12, 12); lt(12, 21)
            strokePath()
        case "cmd":
            rrStroke(CGRect(x: 3, y: 4, width: 18, height: 16), 3)
            strokePaint(); mv(7, 9); lt(11, 12); lt(7, 15); strokePath()
            mv(13, 15.5); lt(17, 15.5); strokePath()
        case "dots":
            for i in 0..<3 { for j in 0..<3 { circleFill(6 + CGFloat(i) * 6, 6 + CGFloat(j) * 6, 1.5) } }
        case "dup":
            rrStroke(CGRect(x: 3, y: 3, width: 11, height: 11), 2)
            rrStroke(CGRect(x: 10, y: 10, width: 11, height: 11), 2)
        case "more":
            circleFill(12, 5, 1.8); circleFill(12, 12, 1.8); circleFill(12, 19, 1.8)
        case "grid":
            rrStroke(CGRect(x: 3, y: 3, width: 18, height: 18), 2)
            strokePaint()
            mv(9, 3); lt(9, 21); mv(15, 3); lt(15, 21)
            mv(3, 9); lt(21, 9); mv(3, 15); lt(21, 15)
            strokePath()
        case "bookmark", "bookmark_f":
            if name == "bookmark_f" { fillPaint() } else { strokePaint() }
            mv(6, 3); lt(18, 3); lt(18, 21); lt(12, 16.5); lt(6, 21); closeP()
            if name == "bookmark_f" { fillPath() } else { strokePath() }
        case "prev":
            strokePaint()
            mv(18, 5); lt(8, 12); lt(18, 19); closeP()
            mv(5, 5); lt(5, 19)
            strokePath()
        case "next":
            strokePaint()
            mv(6, 5); lt(16, 12); lt(6, 19); closeP()
            mv(19, 5); lt(19, 19)
            strokePath()
        case "play":
            fillPaint(); mv(7, 4); lt(20, 12); lt(7, 20); closeP(); fillPath()
        case "pause":
            rectFill(CGRect(x: 6, y: 4, width: 4, height: 16))
            rectFill(CGRect(x: 14, y: 4, width: 4, height: 16))
        case "layers":
            fillPaint(); mv(12, 3); lt(22, 9); lt(12, 15); lt(2, 9); closeP(); fillPath()
            strokePaint(); mv(2, 13); lt(12, 19); lt(22, 13); strokePath()
        case "undo", "redo":
            strokePaint()
            if name == "redo" { c.translateBy(x: 24, y: 0); c.scaleBy(x: -1, y: 1) }
            mv(9, 5); lt(4, 10); lt(9, 15)
            mv(4, 10); lt(14, 10)
            cubic(18.5, 10, 21, 12.5, 21, 17)
            strokePath()
        case "eye", "eye_off":
            strokePaint()
            mv(2, 12); quad(12, 3, 22, 12); quad(12, 21, 2, 12); closeP()
            strokePath()
            circleFill(12, 12, 3)
            if name == "eye_off" {
                strokePaint(); mv(4, 4); lt(20, 20); strokePath()
            }
        case "chev_down":
            strokePaint(); mv(6, 9); lt(12, 15); lt(18, 9); strokePath()
        case "chev_up":
            strokePaint(); mv(6, 15); lt(12, 9); lt(18, 15); strokePath()
        case "trash":
            fillPaint(); mv(6, 8); lt(18, 8); lt(17, 21); lt(7, 21); closeP(); fillPath()
            strokePaint()
            mv(4, 6); lt(20, 6)
            mv(9, 6); lt(9, 3); lt(15, 3); lt(15, 6)
            strokePath()
        case "close":
            strokePaint(); mv(5, 5); lt(19, 19); mv(19, 5); lt(5, 19); strokePath()
        case "plus":
            strokePaint(); mv(12, 4); lt(12, 20); mv(4, 12); lt(20, 12); strokePath()
        case "diamond", "diamond_f":
            if name == "diamond_f" { fillPaint() } else { strokePaint() }
            mv(12, 3); lt(21, 12); lt(12, 21); lt(3, 12); closeP()
            if name == "diamond_f" { fillPath() } else { strokePath() }
        case "graph":
            strokePaint(); mv(3, 18); lt(9, 11); lt(13, 15); lt(21, 6); strokePath()
        case "box":
            rrStroke(CGRect(x: 3, y: 3, width: 18, height: 18), 3)
            strokePaint()
            mv(7, 9); lt(11, 12); lt(7, 15)
            mv(13, 16); lt(17, 16)
            strokePath()
        case "handle":
            strokePaint(); mv(4, 9); lt(20, 9); mv(4, 15); lt(20, 15); strokePath()
        case "media":
            rrStroke(CGRect(x: 3, y: 5, width: 18, height: 14), 2)
            strokePaint(); mv(5, 17); lt(10, 11); lt(14, 15); lt(16, 13); lt(19, 17); strokePath()
            circleFill(16.5, 9.5, 1.6)
        case "text":
            strokePaint()
            mv(5, 6); lt(19, 6)
            mv(12, 6); lt(12, 19)
            mv(9, 19); lt(15, 19)
            strokePath()
        case "shape":
            circleStroke(9, 9, 5.5)
            rrStroke(CGRect(x: 11, y: 11, width: 9, height: 9), 1.5)
        case "camera":
            rrStroke(CGRect(x: 3, y: 7, width: 13, height: 10), 2)
            strokePaint(); mv(16, 10); lt(21, 7); lt(21, 17); lt(16, 14); strokePath()
        case "prerender":      // a camera inside a frame: bake this group to frames
            rrStroke(CGRect(x: 3, y: 3, width: 18, height: 18), 4)
            rrStroke(CGRect(x: 6.5, y: 9, width: 6, height: 6), 1)
            strokePaint(); mv(12.5, 11); lt(17, 9); lt(17, 15); lt(12.5, 13); strokePath()
        case "nullobj":
            circleStroke(12, 12, 5)
            strokePaint()
            mv(12, 2); lt(12, 7); mv(12, 17); lt(12, 22)
            mv(2, 12); lt(7, 12); mv(17, 12); lt(22, 12)
            strokePath()
        case "particles":
            circleFill(7, 7, 1.8); circleFill(15, 6, 1.2); circleFill(11, 12, 2.2)
            circleFill(18, 14, 1.6); circleFill(6, 17, 1.4); circleFill(14, 19, 1.8)
        case "edit":
            strokePaint()
            mv(4, 20); lt(5, 15); lt(16, 4); lt(20, 8); lt(9, 19); closeP()
            mv(14, 6); lt(18, 10)
            strokePath()
        case "puppet":
            strokePaint()
            mv(12, 3); lt(18, 9); lt(12, 15); lt(6, 9); closeP()
            mv(12, 15); lt(12, 21)
            strokePath()
        case "move":
            strokePaint()
            mv(12, 3); lt(12, 21); mv(3, 12); lt(21, 12)
            mv(9, 6); lt(12, 3); lt(15, 6); mv(9, 18); lt(12, 21); lt(15, 18)
            mv(6, 9); lt(3, 12); lt(6, 15); mv(18, 9); lt(21, 12); lt(18, 15)
            strokePath()
        case "sparkle":
            fillPaint()
            mv(12, 3); lt(14, 10); lt(21, 12); lt(14, 14); lt(12, 21)
            lt(10, 14); lt(3, 12); lt(10, 10); closeP()
            fillPath()
        case "drop":
            strokePaint()
            mv(12, 3)
            cubic(12, 3, 5, 10, 5, 15)
            cubic(5, 19, 8, 21, 12, 21)
            cubic(16, 21, 19, 19, 19, 15)
            cubic(19, 10, 12, 3, 12, 3)
            closeP()
            strokePath()
        case "speed":
            strokePaint()
            mv(5, 5); lt(12, 12); lt(5, 19)
            mv(13, 5); lt(20, 12); lt(13, 19)
            strokePath()
        case "import":
            strokePaint()
            mv(12, 3); lt(12, 15)
            mv(7, 10); lt(12, 15); lt(17, 10)
            mv(4, 19); lt(20, 19)
            strokePath()
        case "export":
            strokePaint()
            mv(12, 15); lt(12, 3)
            mv(7, 8); lt(12, 3); lt(17, 8)
            mv(4, 19); lt(20, 19)
            strokePath()
        case "check":
            strokePaint(); mv(5, 12); lt(10, 17); lt(19, 7); strokePath()
        case "solid":
            rrFill(CGRect(x: 4, y: 4, width: 16, height: 16), 3)
        case "anime":
            // character pulled apart into hair, face and shoulders, with a sparkle
            strokePaint()
            mv(5, 9.6); cubic(5, 3.2, 19, 3.2, 19, 9.6)                 // hair cap
            lt(15.5, 7.8); lt(12, 9.6); lt(8.5, 7.8); closeP()
            strokePath()
            mv(6.6, 12.4); cubic(6.6, 16.6, 9, 18.4, 12, 18.4)         // face
            cubic(15, 18.4, 17.4, 16.6, 17.4, 12.4)
            strokePath()
            circleFill(9.7, 14.6, 1.05)
            circleFill(14.3, 14.6, 1.05)
            mv(3.5, 22.8); cubic(3.5, 21.2, 7, 20.7, 12, 20.7)         // shoulders
            cubic(17, 20.7, 20.5, 21.2, 20.5, 22.8)
            strokePath()
            fillPaint()
            mv(21, 1.6); lt(21.6, 3.2); lt(23.2, 3.8); lt(21.6, 4.4); lt(21, 6)
            lt(20.4, 4.4); lt(18.8, 3.8); lt(20.4, 3.2); closeP()
            fillPath()
        case "gear":
            circleStroke(12, 12, 3.2)
            circleStroke(12, 12, 7)
            strokePaint()
            for k in 0..<8 {
                let a = CGFloat(k) * .pi / 4
                mv(12 + 7.5 * cos(a), 12 + 7.5 * sin(a))
                lt(12 + 10 * cos(a), 12 + 10 * sin(a))
            }
            strokePath()
        case "adjust":
            line(4, 7, 20, 7); line(4, 12, 20, 12); line(4, 17, 20, 17)
            circleFill(9, 7, 2.4); circleFill(15, 12, 2.4); circleFill(8, 17, 2.4)
        // ---- audio effect icons (one per effect, drawn as a tiny picture of what the effect does to the sound)
        case "afx_flanger":      // two sweeping, offset waves = moving comb
            strokePaint()
            mv(2, 9); cubic(5, 3, 9, 3, 12, 9); cubic(15, 15, 19, 15, 22, 9)
            mv(2, 15); cubic(5, 9, 9, 9, 12, 15); cubic(15, 21, 19, 21, 22, 15)
            strokePath()
        case "afx_chorus":       // three detuned copies
            strokePaint()
            for k in 0..<3 {
                let y = CGFloat(5 + k * 7), sh = CGFloat(k) * 2
                mv(2, y); quad(6 + sh, y - 4, 11, y); quad(16 - sh, y + 4, 22, y)
            }
            strokePath()
        case "afx_phaser":       // notches
            strokePaint()
            mv(2, 7); lt(6, 7); quad(8, 21, 10, 7); lt(13, 7); quad(15, 21, 17, 7); lt(22, 7)
            strokePath()
        case "afx_modulator":    // amplitude wobble
            strokePaint()
            mv(2, 12); lt(6, 5); lt(10, 19); lt(14, 8); lt(18, 16); lt(22, 12)
            strokePath()
        case "afx_pan":
            strokePaint()
            mv(3, 12); lt(21, 12); mv(7, 8); lt(3, 12); lt(7, 16); mv(17, 8); lt(21, 12); lt(17, 16)
            strokePath()
            circleFill(12, 12, 2.2)
        case "afx_reverb":       // expanding rings
            strokePaint()
            mv(8, 8); quad(4, 12, 8, 16); mv(12, 5); quad(6, 12, 12, 19); mv(16, 3); quad(8, 12, 16, 21)
            strokePath()
            circleFill(19.5, 12, 2)
        case "afx_muffle":       // low-pass roll-off
            strokePaint()
            mv(2, 7); lt(10, 7); cubic(14, 7, 15, 11, 17, 19); lt(22, 19)
            strokePath()
        case "afx_tone":         // tilt around a pivot
            strokePaint()
            mv(2, 17); lt(22, 7); mv(12, 4); lt(12, 20)
            strokePath()
            circleFill(12, 12, 2.2)
        case "afx_eq":           // faders
            strokePaint()
            mv(6, 4); lt(6, 20); mv(12, 4); lt(12, 20); mv(18, 4); lt(18, 20)
            strokePath()
            circleFill(6, 15, 2.4); circleFill(12, 8, 2.4); circleFill(18, 13, 2.4)
        case "afx_echo":         // fading repeats
            strokePaint()
            mv(4, 5); lt(4, 19); mv(9.5, 7); lt(9.5, 17); mv(15, 9.5); lt(15, 14.5); mv(20, 11); lt(20, 13)
            strokePath()
        case "afx_dist":         // clipped wave
            strokePaint()
            mv(2, 19); cubic(5, 19, 6, 6, 9, 6); lt(15, 6); cubic(18, 6, 19, 19, 22, 19)
            strokePath()
        case "afx_wah":          // moving band-pass peak
            strokePaint()
            mv(2, 19); cubic(7, 19, 8, 5, 12, 5); cubic(16, 5, 17, 19, 22, 19)
            mv(6, 12); lt(3, 12); mv(18, 12); lt(21, 12)
            strokePath()
        case "afx_crush":        // staircase
            strokePaint()
            mv(2, 20); lt(2, 16); lt(7, 16); lt(7, 11); lt(12, 11); lt(12, 7); lt(17, 7); lt(17, 3); lt(22, 3)
            strokePath()
        case "afx_comp":         // transfer curve with a knee
            strokePaint()
            mv(3, 3); lt(3, 21); lt(21, 21)
            mv(5, 19); lt(11, 13); quad(14, 10, 20, 9)
            strokePath()
        case "audio":
            strokePaint()
            let hs: [CGFloat] = [3, 7, 10, 6, 4]
            for k in 0..<5 {
                let x = 4 + CGFloat(k) * 4
                mv(x, 12 - hs[k]); lt(x, 12 + hs[k])
            }
            strokePath()
        case "split":
            strokePaint()
            mv(12, 3); lt(12, 21)
            mv(8, 8); lt(4, 12); lt(8, 16)
            mv(16, 8); lt(20, 12); lt(16, 16)
            strokePath()
        case "trimin":
            strokePaint()
            mv(4, 4); lt(4, 20)
            mv(8, 12); lt(20, 12)
            mv(16, 8); lt(20, 12); lt(16, 16)
            strokePath()
        case "trimout":
            strokePaint()
            mv(20, 4); lt(20, 20)
            mv(16, 12); lt(4, 12)
            mv(8, 8); lt(4, 12); lt(8, 16)
            strokePath()
        case "pipette":
            circleStroke(17, 7, 3.2)
            strokePaint(); mv(15, 9); lt(5, 19); lt(4, 20); strokePath()
        case "link":
            rrStroke(CGRect(x: 2, y: 8.5, width: 12, height: 7), 3.5)
            rrStroke(CGRect(x: 10, y: 8.5, width: 12, height: 7), 3.5)
        case "unlink":
            rrStroke(CGRect(x: 1.5, y: 8.5, width: 8.5, height: 7), 3.5)
            rrStroke(CGRect(x: 14, y: 8.5, width: 8.5, height: 7), 3.5)
            strokePaint(); mv(9, 18.5); lt(15, 5.5); strokePath()
        case "flare":
            circleStroke(12, 12, 3.2)
            strokePaint()
            mv(12, 2.5); lt(12, 6.5); mv(12, 17.5); lt(12, 21.5)
            mv(2.5, 12); lt(6.5, 12); mv(17.5, 12); lt(21.5, 12)
            mv(5.5, 5.5); lt(8.3, 8.3); mv(15.7, 15.7); lt(18.5, 18.5)
            mv(18.5, 5.5); lt(15.7, 8.3); mv(8.3, 15.7); lt(5.5, 18.5)
            strokePath()
        case "mask":
            rrStroke(CGRect(x: 4, y: 4, width: 16, height: 16), 3)
            circleStroke(12, 12, 4.5)
        case "mask_invert":
            rrFill(CGRect(x: 4, y: 4, width: 16, height: 16), 3)
            c.setFillColor(UIColor.clear.cgColor)
            c.setBlendMode(.clear)
            c.fillEllipse(in: CGRect(x: 7.5, y: 7.5, width: 9, height: 9))
            c.setBlendMode(.normal)
        case "chev_left":
            strokePaint(); mv(15, 5); lt(8, 12); lt(15, 19); strokePath()
        case "chev_right":
            strokePaint(); mv(9, 5); lt(16, 12); lt(9, 19); strokePath()
        case "minus":
            line(5, 12, 19, 12)
        case "circle":
            circleStroke(12, 12, 8)
        case "folder":
            fillPaint()
            mv(3, 6); lt(10, 6); lt(12, 8.5); lt(21, 8.5); lt(21, 19); lt(3, 19); closeP(); fillPath()
        case "folder_open":
            strokePaint()
            mv(3, 18); lt(3, 6); lt(10, 6); lt(12, 8.5); lt(20, 8.5); lt(20, 11)
            mv(3, 18); lt(6, 11); lt(22, 11); lt(19, 18); closeP(); strokePath()
        case "file":
            strokePaint()
            mv(6, 3); lt(14, 3); lt(19, 8); lt(19, 21); lt(6, 21); closeP()
            mv(14, 3); lt(14, 8); lt(19, 8); strokePath()
        case "file_plus":
            strokePaint()
            mv(6, 3); lt(14, 3); lt(19, 8); lt(19, 21); lt(6, 21); closeP()
            mv(12.5, 12); lt(12.5, 18); mv(9.5, 15); lt(15.5, 15); strokePath()
        case "folder_plus":
            strokePaint()
            mv(3, 18); lt(3, 6); lt(10, 6); lt(12, 8.5); lt(21, 8.5); lt(21, 18); closeP()
            mv(12, 11.5); lt(12, 16); mv(9.75, 13.75); lt(14.25, 13.75); strokePath()
        case "save":
            strokePaint()
            mv(4, 4); lt(17, 4); lt(20, 7); lt(20, 20); lt(4, 20); closeP()
            mv(8, 4); lt(8, 9); lt(15, 9); lt(15, 4); mv(8, 20); lt(8, 14); lt(16, 14); lt(16, 20); strokePath()
        case "align_l":
            strokePaint(); mv(4, 3); lt(4, 21); strokePath()
            rectFill(CGRect(x: 7, y: 6, width: 11, height: 4)); rectFill(CGRect(x: 7, y: 14, width: 6, height: 4))
        case "align_hc":
            strokePaint(); mv(12, 3); lt(12, 21); strokePath()
            rectFill(CGRect(x: 5, y: 6, width: 14, height: 4)); rectFill(CGRect(x: 8, y: 14, width: 8, height: 4))
        case "align_r":
            strokePaint(); mv(20, 3); lt(20, 21); strokePath()
            rectFill(CGRect(x: 6, y: 6, width: 11, height: 4)); rectFill(CGRect(x: 11, y: 14, width: 6, height: 4))
        case "align_t":
            strokePaint(); mv(3, 4); lt(21, 4); strokePath()
            rectFill(CGRect(x: 6, y: 7, width: 4, height: 11)); rectFill(CGRect(x: 14, y: 7, width: 4, height: 6))
        case "align_vc":
            strokePaint(); mv(3, 12); lt(21, 12); strokePath()
            rectFill(CGRect(x: 6, y: 5, width: 4, height: 14)); rectFill(CGRect(x: 14, y: 8, width: 4, height: 8))
        case "align_b":
            strokePaint(); mv(3, 20); lt(21, 20); strokePath()
            rectFill(CGRect(x: 6, y: 6, width: 4, height: 11)); rectFill(CGRect(x: 14, y: 11, width: 4, height: 6))
        case "brush":
            fillPaint()
            mv(11, 11); lt(14, 14); quad(14, 19.5, 5, 20.5); quad(5.5, 15.5, 11, 11); closeP(); fillPath()
            strokePaint(); mv(20.5, 3.5); lt(13, 12); strokePath()
        case "eraser":
            strokePaint()
            mv(4.5, 15); lt(13, 6.5); lt(19, 12.5); lt(12, 19.5); lt(8, 19.5); closeP()
            mv(9, 10.5); lt(15.5, 17); strokePath()
            line(12, 19.5, 21, 19.5)
        case "smudge":
            strokePaint()
            mv(3.5, 17); cubic(7, 8, 11, 22, 15, 13); strokePath()
            mv(6, 20.5); cubic(9.5, 15, 12.5, 23, 17, 17.5); strokePath()
            circleFill(19, 8, 2.6)
        case "wand":
            strokePaint(); mv(4, 20); lt(14, 10); strokePath()
            fillPaint(); mv(17, 3); lt(18.2, 5.8); lt(21, 7); lt(18.2, 8.2); lt(17, 11); lt(15.8, 8.2); lt(13, 7); lt(15.8, 5.8); closeP(); fillPath()
            circleFill(6, 6, 1.3)
        case "select":
            strokePaint(); c.setLineDash(phase: 0, lengths: [3, 3])
            c.stroke(CGRect(x: 4, y: 4, width: 16, height: 16)); c.setLineDash(phase: 0, lengths: [])
        case "copy":
            rrStroke(CGRect(x: 8.5, y: 8.5, width: 12, height: 12), 2)
            strokePaint(); mv(15.5, 5.5); lt(15.5, 4.5); lt(4.5, 4.5); lt(4.5, 15.5); lt(5.5, 15.5); strokePath()
        case "paste":
            rrStroke(CGRect(x: 4.5, y: 5.5, width: 15, height: 16), 2)
            rrFill(CGRect(x: 8.5, y: 2.5, width: 7, height: 5), 1.5)
        case "cut":
            circleStroke(7, 18, 2.8); circleStroke(17, 18, 2.8)
            strokePaint(); mv(8.5, 15.6); lt(16, 3.5); mv(15.5, 15.6); lt(8, 3.5); strokePath()
        case "fit":
            strokePaint()
            mv(4, 9); lt(4, 4); lt(9, 4)
            mv(15, 4); lt(20, 4); lt(20, 9)
            mv(20, 15); lt(20, 20); lt(15, 20)
            mv(9, 20); lt(4, 20); lt(4, 15)
            strokePath()
        case "pan":        // open hand-ish: four fingers + palm
            strokePaint()
            mv(8, 12); lt(8, 5); mv(11, 11); lt(11, 3.5); mv(14, 11); lt(14, 4.5); mv(17, 12); lt(17, 7)
            mv(8, 12); quad(8, 18, 12, 20); quad(18, 20, 18, 14); lt(17, 12)
            strokePath()
        case "rotate":     // circular arrow
            strokePaint()
            mv(19, 12); cubic(19, 16, 16, 19, 12, 19); cubic(8, 19, 5, 16, 5, 12); cubic(5, 8, 8, 5, 12, 5); cubic(14, 5, 16, 6, 17.5, 7.5)
            mv(18, 3.5); lt(18, 8); lt(13.5, 8)
            strokePath()
        case "scale":      // box with diagonal expand arrow
            strokePaint()
            rrStroke(CGRect(x: 3, y: 10, width: 11, height: 11), 1.5)
            mv(13, 11); lt(21, 3); mv(15, 3); lt(21, 3); lt(21, 9)
            strokePath()
        case "timeline":   // bars on a ruler
            strokePaint()
            mv(3, 6); lt(21, 6); mv(3, 12); lt(14, 12); mv(10, 18); lt(21, 18)
            strokePath()
            circleFill(17, 12, 1.8)
        case "gizmo":      // three axes from a point
            strokePaint()
            mv(12, 12); lt(12, 3); mv(12, 12); lt(20, 16); mv(12, 12); lt(4, 16)
            mv(10, 5); lt(12, 3); lt(14, 5)
            strokePath()
            circleFill(12, 12, 2)
        case "terrain":    // mountains
            strokePaint()
            mv(2, 19); lt(9, 7); lt(14, 15); lt(17, 11); lt(22, 19); closeP()
            strokePath()
        case "light":      // bulb
            strokePaint()
            circleStroke(12, 10, 5.5)
            mv(9.5, 18); lt(14.5, 18); mv(10.5, 21); lt(13.5, 21)
            strokePath()
        case "env":        // sun + horizon
            strokePaint()
            circleStroke(12, 12, 3.5)
            mv(12, 3); lt(12, 5); mv(12, 19); lt(12, 21); mv(3, 12); lt(5, 12); mv(19, 12); lt(21, 12)
            mv(5.6, 5.6); lt(7, 7); mv(17, 17); lt(18.4, 18.4); mv(18.4, 5.6); lt(17, 7); mv(7, 17); lt(5.6, 18.4)
            strokePath()
        case "sim":        // wave + droplet
            strokePaint()
            mv(3, 15); quad(6, 9, 9, 15); quad(12, 21, 15, 15); quad(18, 9, 21, 15)
            strokePath()
            circleFill(12, 6, 2)
        case "person":
            strokePaint()
            circleStroke(12, 7, 3.5)
            mv(5, 21); quad(5, 13, 12, 13); quad(19, 13, 19, 21)
            strokePath()
        case "bone":       // two joints joined by a bone
            strokePaint()
            mv(7.5, 16.5); lt(16.5, 7.5)
            strokePath()
            circleStroke(6, 18, 2.5); circleStroke(18, 6, 2.5)
        case "xray":       // see-through cube: outline, hidden edges drawn through the faces
            strokePaint()
            mv(12, 2.5); lt(20.5, 7.25); lt(20.5, 16.75); lt(12, 21.5); lt(3.5, 16.75); lt(3.5, 7.25); closeP()
            strokePath()
            mv(3.5, 7.25); lt(12, 12); lt(20.5, 7.25); mv(12, 12); lt(12, 21.5)
            strokePath()
            circleFill(12, 12, 1.6)
        case "pose":       // stick figure
            strokePaint()
            circleStroke(12, 4.5, 2)
            mv(12, 7); lt(12, 14); mv(5, 10); lt(12, 8.5); lt(19, 10); mv(12, 14); lt(8, 21); mv(12, 14); lt(16, 21)
            strokePath()
        default:
            break
        }
        c.restoreGState()
    }
}

extension Icons {
    /// A vector icon as a UIImage (menus / alerts that need an image instead of a draw call).
    static func image(_ name: String, size: CGFloat = 22, color: Int32 = C.TEXT) -> UIImage {
        UIGraphicsImageRenderer(size: CGSize(width: size, height: size)).image { r in
            Icons.draw(r.cgContext, name, size / 2, size / 2, size, color)
        }.withRenderingMode(.alwaysOriginal)
    }
}

// MARK: - IconView

/// Plain icon button.
final class IconView: TapView {
    var icon: String
    var tint: Int32
    private let sizePt: CGFloat
    var onLong: (() -> Void)? = nil
    private var longFired = false

    init(_ icon: String, _ tint: Int32 = C.TEXT, _ size: CGFloat = 22) {
        self.icon = icon
        self.tint = tint
        self.sizePt = size
        super.init(frame: .zero)
        isOpaque = false
        backgroundColor = .clear
        contentMode = .redraw
        clearsContextBeforeDrawing = true
        // PORT NOTE: Android long-click timeout is 400ms; the recognizer must not
        // cancel the touch stream so normal clicks still work when onLong == nil.
        let lp = UILongPressGestureRecognizer(target: self, action: #selector(longPressed(_:)))
        lp.minimumPressDuration = 0.4
        lp.cancelsTouchesInView = false
        addGestureRecognizer(lp)
    }

    @objc private func longPressed(_ g: UILongPressGestureRecognizer) {
        if g.state == .began && onLong != nil { longFired = true; onLong?() }
    }

    func set(_ name: String, _ color: Int32) {
        icon = name; tint = color; setNeedsDisplay()
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        isHighlighted = false
        if !longFired, let t = touches.first, bounds.contains(t.location(in: self)) { onClick?() }
        longFired = false
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        isHighlighted = false
        longFired = false
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        c.clear(bounds)   // stale play-triangle pixels used to show under the pause bars
        let col: Int32 = isHighlighted
            ? Int32(bitPattern: UInt32(bitPattern: tint) | 0x80000000)
            : tint
        Icons.draw(c, icon, bounds.width / 2, bounds.height / 2, sizePt, col)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}


// MARK: - own replacements for the system (SF Symbols) icon set — no Apple icons anywhere
extension Icons {
    /// Maps an old system symbol name to one of our own vector icons.
    static func ownName(_ sf: String) -> String {
        let n = sf
        let table: [(String, String)] = [
            ("xray", "xray"), ("hand", "pan"), ("rotate", "rotate"), ("arrow.up.left.and.arrow.down.right", "scale"), ("timeline", "timeline"),
            ("move.3d", "gizmo"), ("mountain", "terrain"), ("lightbulb", "light"), ("sun.max", "env"), ("cloud.sun", "sim"),
            ("person", "person"), ("figure", "pose"), ("bone", "bone"), ("cube.transparent", "cube"),
            ("xmark", "close"), ("plus.diamond", "plus"), ("plus.magnifyingglass", "plus"), ("plus.square.on.square", "dup"),
            ("plus", "plus"), ("minus", "minus"), ("trash", "trash"), ("eye.slash", "eye_off"), ("eye", "eye"),
            ("chevron.up", "chev_up"), ("chevron.down", "chev_down"), ("arrowtriangle.down", "chev_down"),
            ("chevron.left", "chev_left"), ("chevron.right", "chev_right"),
            ("backward.end", "prev"), ("forward.end", "next"), ("play", "play"), ("pause", "pause"),
            ("photo", "media"), ("square.grid", "grid"), ("grid", "grid"), ("cube", "cube"), ("folder", "folder"),
            ("gear", "gear"), ("pencil", "edit"), ("checkmark", "check"), ("bookmark", "bookmark"), ("camera", "camera"),
            ("diamond", "diamond"), ("drop", "drop"), ("waveform", "audio"), ("wave", "audio"),
            ("wand", "sparkle"), ("sun", "sparkle"), ("cloud", "sparkle"), ("lightbulb", "sparkle"), ("flashlight", "sparkle"),
            ("square.and.arrow", "export"), ("doc.on", "dup"), ("square.stack", "layers"), ("slider", "adjust"),
            ("circle", "circle"), ("hand", "move"), ("arrow", "move"),
        ]
        for (k, v) in table where n.hasPrefix(k) { return v }
        return "shape"
    }

    /// Drop-in for UIImage(systemName:): our own vector icon as a template image (tintColor works).
    static func sf(_ name: String, withConfiguration cfg: UIImage.SymbolConfiguration? = nil) -> UIImage? {
        let own = ownName(name)
        let size: CGFloat = 24
        let img = UIGraphicsImageRenderer(size: CGSize(width: size, height: size)).image { r in
            Icons.draw(r.cgContext, own, size / 2, size / 2, size, Int32(bitPattern: 0xFFFFFFFF))
        }
        return img.withRenderingMode(.alwaysTemplate)
    }
}
