// PlusMenu.swift — the 3D editor's "+" menu: a custom grouped popover (replaces the stock iOS pull-down menu).
// Top level is four short rows; each opens its own small page, so nothing is a 15-item wall.

import UIKit

struct PlusItem {
    var title: String
    var icon: String
    var checked: Bool? = nil          // non-nil = toggle row (menu stays open)
    var children: [PlusItem]? = nil   // non-nil = opens a page
    var action: (() -> Void)? = nil
}

final class PlusMenuView: UIView {
    private let card = UIView()
    private let stack = UIStackView()
    private var root: [PlusItem] = []
    private var path: [Int] = []
    private var rebuilt: (() -> [PlusItem])?
    private let accent: UIColor
    private weak var anchorView: UIView?

    init(accent: UIColor) {
        self.accent = accent
        super.init(frame: .zero)
        backgroundColor = UIColor(white: 0, alpha: 0.001)       // catches outside taps
        addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(outside)))
        card.backgroundColor = UIColor(white: 0.13, alpha: 0.98)
        card.layer.cornerRadius = 18; card.layer.borderWidth = 1; card.layer.borderColor = UIColor(white: 1, alpha: 0.08).cgColor
        card.layer.shadowColor = UIColor.black.cgColor; card.layer.shadowOpacity = 0.45; card.layer.shadowRadius = 18; card.layer.shadowOffset = CGSize(width: 0, height: 6)
        stack.axis = .vertical; stack.spacing = 0
        stack.translatesAutoresizingMaskIntoConstraints = false
        card.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.topAnchor.constraint(equalTo: card.topAnchor, constant: 6), stack.bottomAnchor.constraint(equalTo: card.bottomAnchor, constant: -6),
            stack.leadingAnchor.constraint(equalTo: card.leadingAnchor, constant: 6), stack.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -6)])
        addSubview(card)
        card.translatesAutoresizingMaskIntoConstraints = false
    }
    required init?(coder: NSCoder) { fatalError() }

    /// Shows the menu above `anchor`, right-aligned to it. `items` is re-read after every toggle so checks stay current.
    func present(in host: UIView, from anchor: UIView, items: @escaping () -> [PlusItem]) {
        rebuilt = items; root = items(); path = []; anchorView = anchor
        frame = host.bounds; autoresizingMask = [.flexibleWidth, .flexibleHeight]
        host.addSubview(self)
        let a = anchor.convert(anchor.bounds, to: host)
        NSLayoutConstraint.activate([
            card.widthAnchor.constraint(equalToConstant: 270),
            card.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -(host.bounds.width - a.maxX)),
            card.bottomAnchor.constraint(equalTo: topAnchor, constant: a.minY - 8)])
        fill()
        card.alpha = 0; card.transform = CGAffineTransform(scaleX: 0.92, y: 0.92).translatedBy(x: 0, y: 12)
        UIView.animate(withDuration: 0.16, delay: 0, options: .curveEaseOut) { self.card.alpha = 1; self.card.transform = .identity }
    }

    func dismiss() {
        UIView.animate(withDuration: 0.12, animations: { self.card.alpha = 0 }, completion: { _ in self.removeFromSuperview() })
    }
    @objc private func outside() { dismiss() }

    private func current() -> (title: String?, items: [PlusItem]) {
        var items = root; var title: String? = nil
        for i in path { guard i < items.count, let ch = items[i].children else { break }; title = items[i].title; items = ch }
        return (title, items)
    }

    private func fill() {
        stack.arrangedSubviews.forEach { $0.removeFromSuperview() }
        let (title, items) = current()
        if let t = title { stack.addArrangedSubview(row(title: t, icon: "chev_left", trailing: nil, header: true) { [weak self] in self?.path.removeLast(); self?.fill() }) }
        for (i, it) in items.enumerated() {
            stack.addArrangedSubview(row(title: it.title, icon: it.icon, trailing: it, header: false) { [weak self] in self?.tap(i) })
        }
    }

    private func tap(_ i: Int) {
        let (_, items) = current(); guard i < items.count else { return }
        let it = items[i]
        if it.children != nil { path.append(rootIndex(i)); fill(); return }
        it.action?()
        if it.checked != nil, let r = rebuilt { root = r(); fill() } else { dismiss() }
    }
    /// Index of item `i` of the current page inside its parent's children, expressed for `path` (path stores per-level indexes).
    private func rootIndex(_ i: Int) -> Int { i }

    private func row(title: String, icon: String, trailing: PlusItem?, header: Bool, _ onTap: @escaping () -> Void) -> UIView {
        let v = PlusRow(onTap)
        v.heightAnchor.constraint(equalToConstant: 46).isActive = true
        v.layer.cornerRadius = 12
        let iv = UIImageView(image: Icons.image(icon, size: 22, color: header ? Int32(bitPattern: 0xFFB0B0B0) : Int32(bitPattern: 0xFFFFFFFF)))
        let lb = UILabel(); lb.text = title; lb.textColor = .white
        lb.font = .systemFont(ofSize: header ? 15 : 16, weight: header ? .semibold : .regular)
        v.addSubview(iv); v.addSubview(lb)
        iv.translatesAutoresizingMaskIntoConstraints = false; lb.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            iv.leadingAnchor.constraint(equalTo: v.leadingAnchor, constant: 12), iv.centerYAnchor.constraint(equalTo: v.centerYAnchor),
            iv.widthAnchor.constraint(equalToConstant: 22), iv.heightAnchor.constraint(equalToConstant: 22),
            lb.leadingAnchor.constraint(equalTo: iv.trailingAnchor, constant: 12), lb.centerYAnchor.constraint(equalTo: v.centerYAnchor)])
        if let t = trailing {
            let end: UIView
            if let on = t.checked { end = PlusSwitch(on: on, accent: accent) }
            else if t.children != nil { end = UIImageView(image: Icons.image("chev_right", size: 18, color: Int32(bitPattern: 0xFF909090))) }
            else { end = UIView() }
            v.addSubview(end); end.translatesAutoresizingMaskIntoConstraints = false
            let w: CGFloat = t.checked != nil ? 40 : 18, h: CGFloat = t.checked != nil ? 24 : 18
            NSLayoutConstraint.activate([end.trailingAnchor.constraint(equalTo: v.trailingAnchor, constant: -12), end.centerYAnchor.constraint(equalTo: v.centerYAnchor),
                                         end.widthAnchor.constraint(equalToConstant: w), end.heightAnchor.constraint(equalToConstant: h),
                                         lb.trailingAnchor.constraint(lessThanOrEqualTo: end.leadingAnchor, constant: -8)])
            end.isUserInteractionEnabled = false
        }
        return v
    }
}

private final class PlusRow: UIControl {
    private let onTap: () -> Void
    init(_ f: @escaping () -> Void) { onTap = f; super.init(frame: .zero); addTarget(self, action: #selector(go), for: .touchUpInside) }
    required init?(coder: NSCoder) { fatalError() }
    @objc private func go() { onTap() }
    override var isHighlighted: Bool { didSet { backgroundColor = isHighlighted ? UIColor(white: 1, alpha: 0.10) : .clear } }
}

/// Small custom on/off switch (drawn, not UISwitch).
private final class PlusSwitch: UIView {
    init(on: Bool, accent: UIColor) {
        super.init(frame: .zero)
        backgroundColor = on ? accent : UIColor(white: 0.30, alpha: 1)
        layer.cornerRadius = 12
        let knob = UIView(frame: CGRect(x: on ? 19 : 3, y: 3, width: 18, height: 18))
        knob.backgroundColor = .white; knob.layer.cornerRadius = 9
        addSubview(knob)
    }
    required init?(coder: NSCoder) { fatalError() }
}
