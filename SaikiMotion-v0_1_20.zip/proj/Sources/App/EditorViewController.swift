// iOS port of EditorActivity.kt — SaikiMotion (the editor shell)
//
// The editor used to be one 4,200-line file. It is now split by feature so
// each screen is easy to find and debug — this file holds the class itself:
// stored state, lifecycle, the UI skeleton (top bar / preview / transport /
// timeline / toolbar / panel rail), playback, undo-redo and the EditHost /
// TimelineHost glue. Everything else lives in Sources/App/Editor/:
//
//   EditorAudio.swift        AVAudioPlayer plumbing
//   EditorFlare.swift        Optical Flare library + customization overlay
//   EditorDialogs.swift      motion blur / parent / expressions / scene setup / render
//   EditorLayers.swift       add, clone, copy, paste, group, split, trim, menus
//   EditorImport.swift       every picker (video/image/audio/glb/vdb/font/fx/preset)
//   EditorPanelsText.swift   panel framework + Media/Shapes/Edit/Text + color rows
//   EditorTransform.swift    Transform panel, anchor & align, parenting
//   EditorBlendSpeed.swift   Blending + Speed panels, time remap
//   EditorEffects.swift      Effects panel: applied / browse / presets / custom
//   EditorGraph.swift        the graph editor panel
//   EditorSceneSetup.swift   Scene Setup mode (orbit editing camera)
//   EditorHelpers.swift      field binding, string helpers, pretty JSON
//
// PORT NOTES (lifecycle + platform):
//  - Activity → UIViewController built 100% programmatically. onCreate → viewDidLoad,
//    onResume → viewWillAppear, onPause → viewWillDisappear, onDestroy → deinit.
//  - onBackPressed → onBack(): closes the panel / deselects / pops or dismisses the VC.
//    The navigation bar is hidden while the editor is on screen (the editor has its own top bar).
//  - onConfigurationChanged (full buildUi() rebuild) → RootLayout computes the portrait and
//    landscape layouts dynamically in layoutSubviews, so no rebuild is needed on rotation.
//  - windowSoftInputMode adjustResize → UIResponder.keyboardWillShow/Hide notifications that
//    shrink the root layout (and the full-screen Effects panel) above the keyboard.
//  - Choreographer.postFrameCallback → CADisplayLink on .main/.common with a weak proxy target
//    (the link retains the proxy, the proxy does not retain the VC, so deinit can invalidate).
//  - android.media.MediaPlayer → AVAudioPlayer: players are created + prepared on a background
//    thread (prepareAsync parity); SEEK_CLOSEST → currentTime assignment; drift window 140 ms.
//  - ACTION_GET_CONTENT → UIDocumentPickerViewController(asCopy: true); the Kotlin
//    ContentResolver copies go through ProjectIO.copyMediaIntoSandbox (same "<ts>_<name>"
//    and "<ts>_font.ttf" naming).
//  - MediaMetadataRetriever duration → AVAsset.duration, loaded off the main thread.
//  - PixelCopy.request(preview, ...) → a drawHierarchy snapshot of the GLKView read through a
//    1x1 bitmap context (eyedropper).
//  - MediaStore Downloads/Music writes → <Documents>/SaikiMotion (ProjectIO convention; the
//    location string in the toasts mirrors it).
//  - onSaveInstanceState/savedInstanceState: iOS does not restore editor state after a kill;
//    the selected layer only survives within a session (selId is a plain property).
//  - Kotlin `selectedId` / `autoKey` properties renamed selId / autoKeyOn (the TimelineHost /
//    EditHost protocols require methods with those exact names; a stored property with the same
//    name as a method is not a safe Swift pattern).
//  - Dlg is an overlay on the key window (not a presented VC), so the Kotlin
//    `setView(ScrollView(box))` wrappers are dropped — Dlg wraps long content in its own
//    CapScroll already.

import UIKit
import AVFoundation
import CoreMedia
import UniformTypeIdentifiers
import PhotosUI


// Panel ids (Kotlin P_*) and picker request codes (Kotlin R_*), at file scope so closures with
// [weak self] capture lists can reference them without an implicit-self error.
let P_NONE = 0; let P_MEDIA = 1; let P_SHAPES = 2; let P_EDIT = 3
let P_XFORM = 4; let P_FX = 5; let P_BLEND = 6; let P_SPEED = 7; let P_GRAPH = 8; let P_PUPPET = 9; let P_RIGANIM = 10
let R_VIDEO = 51; let R_IMAGE = 52; let R_GLB = 53; let R_FX = 54; let R_PRESET = 55
let R_VDBENV = 60; let R_MODELTEX = 61
let R_BEAT = 57; let R_AUDIOFILE = 58; let R_FONT = 59
let R_PBRMAP = 60; let R_PBRALL = 61; let R_COLLIDER = 70
var gPbrKey = ""      // which PBR map slot the file picker is filling

/// Kotlin ACTION_GET_CONTENT "*/*" for the .glb picker: any file, GLB files first.
func glbTypes() -> [UTType] {
    // any file is selectable (the loader sniffs the content); known 3D types are listed first
    var ts: [UTType] = [.data, .threeDContent]
    for e in ["abc", "obj", "fbx", "gltf", "glb", "vrm", "pmx", "mmd", "vmd", "ply", "spz"] {
        if let g = UTType(filenameExtension: e) { ts.insert(g, at: 0) }
    }
    return ts
}

func mmdTypes() -> [UTType] {
    var ts: [UTType] = [.data, .zip]
    for e in ["vmd", "mmd", "pmx"] { if let g = UTType(filenameExtension: e) { ts.insert(g, at: 0) } }
    return ts
}
func vrmTypes() -> [UTType] {
    var ts: [UTType] = [.data, .zip]
    if let g = UTType(filenameExtension: "vrm") { ts.insert(g, at: 0) }
    return ts
}

/// Same shape for OpenVDB volumes: any file, .vdb files first.
func envTypes() -> [UTType] {
    var ts: [UTType] = [.image]
    for e in ["hdr", "exr"] { if let t = UTType(filenameExtension: e) { ts.insert(t, at: 0) } }
    return ts
}
func colliderTypes() -> [UTType] {
    var ts: [UTType] = [.data]
    for e in ["obj", "ply"] { if let t = UTType(filenameExtension: e) { ts.insert(t, at: 0) } }
    return ts
}
func vdbTypes() -> [UTType] {
    var ts: [UTType] = [.data]
    if let v = UTType(filenameExtension: "vdb") { ts.insert(v, at: 0) }
    return ts
}

/// CADisplayLink target that does not retain the view controller (see PORT NOTES above).
private final class DisplayLinkProxy: NSObject {
    weak var vc: EditorViewController?
    @objc func tick(_ link: CADisplayLink) { vc?.doFrame() }
}

/// LinearLayout-with-weights replacement for the editor root. Lays out the fixed-height rows
/// and the two weighted areas (preview 1.0 / timeline 1.15); landscape splits the width
/// 46% / 54% exactly like the Kotlin orientation branch. panelBox height -1 = dynamic
/// (300 pt portrait / 220 pt landscape, like the Kotlin per-orientation LayoutParams).
/// Hidden views and views that were re-parented (the full-screen Effects panel) are skipped.
private final class RootLayout: UIView {
    var top: UIView? = nil
    var previewBox: UIView? = nil
    var tr: UIView? = nil
    var timeline: UIView? = nil
    var toolbarBox: UIView? = nil
    var panelBox: UIView? = nil

    override init(frame: CGRect) { super.init(frame: frame) }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    private func panelH() -> CGFloat { bounds.width > bounds.height ? (Dev.isPad ? 340 : 220) : (Dev.isPad ? 420 : 300) }

    private func lay(_ its: [(UIView?, CGFloat, Float)], _ r: CGRect) {
        let vis: [(UIView, CGFloat, Float)] = its.compactMap { it in
            guard let v = it.0, v.superview === self, !v.isHidden else { return nil }
            return (v, it.1, it.2)
        }
        var fixed: CGFloat = 0
        var tw: Float = 0
        for (_, h, w) in vis {
            let hh = h < 0 ? panelH() : h
            if hh > 0 { fixed += hh } else { tw += w }
        }
        let free = max(0, r.height - fixed)
        var y = r.minY
        for (v, h, w) in vis {
            let hh: CGFloat
            if h < 0 { hh = panelH() }
            else if h > 0 { hh = h }
            else { hh = tw > 0 ? free * CGFloat(w / tw) : 0 }
            v.frame = CGRect(x: r.minX, y: y, width: r.width, height: hh)
            y += hh
        }
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        let area = CGRect(x: 0, y: 0, width: bounds.width, height: bounds.height)
        if bounds.width > bounds.height {
            let lw = floor(area.width * 0.46)
            lay([(top, 52, 0), (previewBox, 0, 1), (tr, 48, 0)],
                CGRect(x: 0, y: 0, width: lw, height: area.height))
            lay([(timeline, 0, 1.15), (toolbarBox, 76, 0), (panelBox, -1, 0)],
                CGRect(x: lw, y: 0, width: area.width - lw, height: area.height))
        } else {
            lay([(top, 52, 0), (previewBox, 0, 1), (tr, 48, 0), (timeline, 0, 1.15),
                 (toolbarBox, 76, 0), (panelBox, -1, 0)], area)
        }
    }
}

final class EditorViewController: UIViewController, EditHost, TimelineHost, UIDocumentPickerDelegate, PHPickerViewControllerDelegate {
    var projectId: String
    var preview: PreviewView!
    var overlay: OverlayView!
    var aspect: AspectLayout!
    var timeline: TimelineView!
    var titleView: UILabel!
    var subView: UILabel!
    var playIcon: IconView!
    var markIcon: IconView!
    var cubeIcon: IconView!
    var mbToggle: PillToggle!
    var parentIcon: IconView!
    var preIcon: IconView!
    var moreIcon: IconView!
    var gearIcon: IconView!
    var sceneSetupBtn: IconView!
    var renderBtn: UIView!
    var preRenderBtn: UIView!           // top-bar Pre-render pill: replaces Render while a group is selected
    var preRenderPill: PillButton!
    var actionBar: UIView!
    var qualityChip: ChipView!
    var toolbarBox: UIScrollView!
    var toolbarRow: UIStackView!
    var panelBox: UIView!
    var panelList: UIStackView!
    var diamondSide: IconView!
    var xformTab = 0
    var scaleLinked = true
    var sepDims = true
    var moveMode = false

    var selId = -1                 // PORT NOTE: Kotlin `selectedId` property
    var panel = 0
    var fxTab = 0
    var fxCatName = ""             // effect browser category filter ("" = all)
    var fxCat = 0                  // kept for parity (unused in Kotlin too)
    var playing = false { didSet { FrameCache.playing = playing } }
    var scrubEndWork: DispatchWorkItem?
    // live render cache (see Editor/EditorLiveCache.swift)
    var liveTimer: Timer? = nil
    var lastActivity: CFAbsoluteTime = 0
    var liveNextAt: CFAbsoluteTime = 0
    var liveBusy = false
    var preNextAt: CFAbsoluteTime = 0   // pre-render (see EditorLiveCache.swift)
    var preBurst = false
    var preBadge: UILabel!              // "PRE-RENDERED ✓" / "PRE-RENDER n/m" chip on the preview
    var lastTimelineRefresh: CFAbsoluteTime = 0
    var lastTs: Double = 0
    var autoKeyOn = false          // PORT NOTE: Kotlin `autoKey` property
    var quality = 1
    var graphProp = ""
    var curveClip: Key? = nil
    var graphKey = 0
    var graphTab = 1               // graph editor view: 0 ease / 1 value / 2 speed
    var selKey = ""
    var screen: UIView!
    fileprivate var rootLayout: RootLayout!    // Kotlin `panelHome` (panelBox's non-full parent)
    var textTab = 0
    var players: [Int: AVAudioPlayer] = [:]
    var playerFx: [Int: String] = [:]      // effect-chain key each player was loaded with ("" = dry file)
    var fxRefreshWork: DispatchWorkItem?
    let liveFx = AudioFxLive()
    var startingAudio = Set<Int>()
    var prepared = Set<Int>()
    let audioLead = 110
    var multi: [Int] = []          // LinkedHashSet semantics: ordered + unique
    var multiMode = false
    var clipboard: [Layer] = []
    var propsClip: Layer? = nil          // Layers > Properties

    var expanded = Set<String>()
    final class Row {
        let slider: RulerSlider
        let d: PropDef
        let layer: Layer
        init(_ slider: RulerSlider, _ d: PropDef, _ layer: Layer) {
            self.slider = slider; self.d = d; self.layer = layer
        }
    }
    var rows: [Row] = []
    var undoStack: [String] = []   // Kotlin `undo`
    var redoStack: [String] = []   // Kotlin `redo`

    var fxQuery = ""
    final class FxSnap {
        let id: String
        let tracks: [(String, JObj)]
        let inputs: [String: Int]
        let off: Bool
        init(_ id: String, _ tracks: [(String, JObj)], _ inputs: [String: Int], _ off: Bool) {
            self.id = id; self.tracks = tracks; self.inputs = inputs; self.off = off
        }
    }
    var fxClip: [FxSnap] = []

    var pendingPick = 0
    var kbInset: CGFloat = 0
    var rootBottom: NSLayoutConstraint? = nil
    var displayLink: CADisplayLink? = nil
    fileprivate var linkProxy: DisplayLinkProxy? = nil

    // ---- autosave architecture (rounds 11/14/19) ----
    var dirty = false                   // unsaved edits exist
    var lastEditTs: CFAbsoluteTime = 0  // when the last edit landed
    var saveWork: DispatchWorkItem? = nil
    var lastSavedText = ""
    var idleSaving = false              // re-entry guard (IDLE_SAVE lesson)

    var flareLayer: Layer? = nil
    var flareBackup: JObj? = nil
    var flareOverlay: UIView? = nil
    var flareContent: UIStackView? = nil
    var flareTabs: TabBar? = nil
    var flTab = 0
    var flSel = 0
    var flBrowse = false
    var flIsNew = false
    var flareParent: UIView? = nil
    var flareDriver: FlareDriver? = nil
    var flareSweepBase: (Float, Float)? = nil

    // ================================================================ init / lifecycle

    init(projectId: String) {
        self.projectId = projectId
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(forName: EffectGuard.doneNote, object: nil, queue: .main) { [weak self] n in
            if let m = n.userInfo?["msg"] as? String { self?.toast(m) }
            self?.refreshPanel(); self?.preview.requestDraw()
        }
        NotificationCenter.default.addObserver(forName: MetalEffects.readyNote, object: nil, queue: .main) { [weak self] _ in self?.preview.requestDraw() }
        Rig.onLiveTick = { [weak self] in self?.render() }     // live (slider-driven) physics keeps re-rendering while it settles
        Registry.initialize()      // Kotlin: Registry.init(this)
        CrashLog.install()         // R19: signal-safe crash logger, before any UI work
        FreezeWatchdog.start()     // R15/R19: freeze detection (heartbeat-change rule)
        // Kotlin also installs CrashLog here; HomeViewController owns the single install on iOS
        // (NSSetUncaughtExceptionHandler is idempotent anyway) — PORT NOTE.
        if let p = Projects.load(projectId) {
            Editor.project = p
        } else {
            Editor.project = Project(name: "Untitled")
            Editor.project.id = projectId
            // never silently replace a file that exists but could not be read
            let u = Projects.fileURL(projectId)
            if FileManager.default.fileExists(atPath: u.path) {
                try? FileManager.default.copyItem(at: u, to: u.deletingPathExtension().appendingPathExtension("corrupt"))
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { Snack.show("Project file was unreadable — a copy was kept as .corrupt") }
            }
        }
        lastSavedText = Editor.project.toJson().toString()
        Editor.sceneIndex = 0
        Editor.time = 0
        selId = -1
        buildUi()
        refreshAll()
        safe("previews") {
            // cards pick thumbnails up from the cache themselves — no full panel rebuild
            EffectThumbs.generate(self, preview) { }
        }
        NotificationCenter.default.addObserver(self, selector: #selector(saveNow),
                                               name: UIApplication.willResignActiveNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(saveNow),
                                               name: UIApplication.didEnterBackgroundNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(saveNow),
                                               name: UIApplication.willTerminateNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(kbChanged(_:)),
                                               name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(kbChanged(_:)),
                                               name: UIResponder.keyboardWillHideNotification, object: nil)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
        preview.requestDraw()      // Kotlin: preview.onResume() (GLKView has no pause; redraw)
        FrameCache.suspended = false
        startLiveCache()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
        playing = false
        stopAudio()
        displayLink?.isPaused = true
        playIcon.set("play", C.GREEN)
        saveThumbnail()
        preview.releaseVideos()    // Kotlin: preview.onPause()
        saveWork?.cancel()
        FrameCache.playing = false
        stopLiveCache()
        Projects.save(projectId, Editor.project)
        dirty = false              // the explicit save above covers everything
        FreezeWatchdog.setDirty(false)
    }

    // ================================================================ autosave (rounds 11/14/19)

    /// Every edit funnels through pushUndo()/beginEdit(), so this is the one
    /// place that marks the project dirty. Saving is fully decoupled from
    /// editing — see maybeIdleSave().
    func markDirty() {
        dirty = true
        lastActivity = CFAbsoluteTimeGetCurrent()
        FrameCache.bump()              // every edit makes cached frames stale
        if !PreRender.groups(in: Editor.scene).isEmpty {
            preBurst = true; preNextAt = 0   // re-bake right away, not only after the idle save
            updatePreBadge()                 // badge must stop claiming "PRE-RENDERED ✓" at once
            if let l = selected(), l.type == .GROUP { refreshTitle() }
        }
        lastEditTs = CFAbsoluteTimeGetCurrent()
        scheduleSave()
        FreezeWatchdog.setDirty(true)
        CrashLog.note("edit")
    }

    /// Round-19 freeze fix: edits NEVER save synchronously. (The shipped
    /// binary ran the whole project serialization inside refreshTitle() on
    /// the main thread every second edit — the "anything I do freezes" bug.)
    /// Instead the render path — already on the main thread — saves once
    /// after the user has been idle ~10 s. Explicit save paths are untouched.
    /// Save fix: the old code only saved from the render path after 10 s idle, but
    /// nothing renders while the user is idle — so edits were never written.
    /// Now a debounced save fires ~1.5 s after the last edit, and the project is also
    /// saved whenever the app leaves the foreground.
    func scheduleSave() {
        saveWork?.cancel()
        let w = DispatchWorkItem { [weak self] in self?.saveNow() }
        saveWork = w
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4, execute: w)
    }

    /// Saves whenever the serialized project differs from what is on disk. This does not
    /// depend on every edit path remembering to call markDirty() (colour pickers, sliders
    /// and others did not), so even the slightest change is written.
    @objc func saveNow() {
        saveWork?.cancel()
        guard !idleSaving else { return }
        idleSaving = true
        defer { idleSaving = false }
        // updatedAt is rewritten by every save, so it must not take part in the comparison:
        // it made every save look like an edit and wiped the frame cache each time the
        // playhead moved or Play was pressed.
        let stamp = Editor.project.updatedAt
        Editor.project.updatedAt = Date(timeIntervalSince1970: 0)
        let text = Editor.project.toJson().toString()
        Editor.project.updatedAt = stamp
        if text == lastSavedText { dirty = false; FreezeWatchdog.setDirty(false); return }
        let firstSave = lastSavedText.isEmpty
        lastSavedText = text
        if !firstSave {
            FrameCache.bump()                 // the picture changed → cached frames are stale
            if !PreRender.groups(in: Editor.scene).isEmpty { preBurst = true; preNextAt = 0 }   // re-bake pre-rendered groups
        }
        CrashLog.note("save")
        Projects.save(projectId, Editor.project)
        if let e = Projects.lastError { toast("Save failed: " + e); lastSavedText = "" }
        dirty = Projects.lastError != nil
        FreezeWatchdog.setDirty(false)
    }

    func maybeIdleSave() {
        guard dirty, !idleSaving else { return }
        guard CFAbsoluteTimeGetCurrent() - lastEditTs >= 10.0 else { return }
        idleSaving = true
        CrashLog.note("save")
        Projects.save(projectId, Editor.project)
        dirty = false
        FreezeWatchdog.setDirty(false)
        idleSaving = false
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        applyFullPanelFrame()
    }

    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        // Kotlin onConfigurationChanged → buildUi() + refreshAll(); RootLayout recomputes both
        // orientations itself, so only a relayout pass is needed.
        rootLayout.setNeedsLayout()
        coordinator.animate(alongsideTransition: nil) { [weak self] _ in
            self?.applyFullPanelFrame()
        }
    }

    deinit {
        displayLink?.invalidate()
        NotificationCenter.default.removeObserver(self)
        releaseAudio()             // Kotlin: onDestroy → releaseAudio()
    }

    func toast(_ s: String) { Snack.show(self, s) }

    /// Snapshot of the comp for the My Playground card.
    func saveThumbnail() {
        guard preview.bounds.width > 1, preview.bounds.height > 1 else { return }
        let fmt = UIGraphicsImageRendererFormat(); fmt.scale = 1; fmt.opaque = true
        let w: CGFloat = 360, h = max(1, w * preview.bounds.height / preview.bounds.width)
        let img = UIGraphicsImageRenderer(size: CGSize(width: w, height: h), format: fmt).image { _ in
            preview.drawHierarchy(in: CGRect(x: 0, y: 0, width: w, height: h), afterScreenUpdates: false)
        }
        if let d = img.jpegData(compressionQuality: 0.8) { try? d.write(to: Projects.thumbURL(projectId), options: .atomic) }
    }

    func safe(_ step: String, _ block: () throws -> Void) {
        do { try block() } catch {
            var m = (error as? LocalizedError)?.errorDescription ?? (error as NSError).localizedDescription
            if m.isEmpty { m = String(describing: type(of: error)) }
            toast(step + ": " + m)
        }
    }

    // ================================================================ UI skeleton

    @discardableResult
    func icon(_ name: String, _ tint: Int32 = C.TEXT, click: @escaping () -> Void = {}) -> IconView {
        let v = IconView(name, tint)
        v.onClick = click
        return v
    }

    func hRow() -> UIStackView {
        let r = UIStackView()
        r.axis = .horizontal
        r.alignment = .center
        r.spacing = 0
        return r
    }

    func vStack() -> UIStackView {
        let r = UIStackView()
        r.axis = .vertical
        r.spacing = 0
        r.alignment = .fill
        return r
    }

    func spacer() -> UIView {
        let v = UIView()
        v.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
        return v
    }

    func addIcon(_ parent: UIStackView, _ v: IconView, _ w: CGFloat = 44, _ h: CGFloat = 48) {
        parent.addArrangedSubview(wrap(v, w, h, 0, 0, 0, 0))
    }

    func buildUi() {
        screen = view
        screen.backgroundColor = argbToUIColor(C.BG)

        // ---- top bar
        let top = hRow()
        top.isLayoutMarginsRelativeArrangement = true
        top.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 4, bottom: 0, trailing: 8)
        addIcon(top, icon("back", C.GREEN) { [weak self] in self?.onBack() }, 40)
        let tcol = vStack()
        titleView = UILabel()
        titleView.textColor = argbToUIColor(C.TEXT)
        titleView.font = boldFont(17)
        titleView.numberOfLines = 1
        // never let the trailing icons crush the title into an unreadable sliver
        titleView.adjustsFontSizeToFitWidth = true
        titleView.minimumScaleFactor = 0.55
        titleView.setContentCompressionResistancePriority(UILayoutPriority(749), for: .horizontal)
        subView = UILabel()
        subView.textColor = argbToUIColor(C.GREEN)
        subView.font = monoTimeFont(11)
        subView.adjustsFontSizeToFitWidth = true
        subView.minimumScaleFactor = 0.6
        subView.numberOfLines = 1
        tcol.addArrangedSubview(titleView)
        tcol.addArrangedSubview(subView)
        tcol.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
        top.addArrangedSubview(tcol)
        // The tool icons live in a horizontal strip so a narrow phone scrolls them instead of
        // squeezing (and losing) the Render button; Render itself is pinned outside the strip.
        let iconRow = hRow()
        let iconScroll = TopIconScroll()
        iconScroll.showsHorizontalScrollIndicator = false
        iconScroll.alwaysBounceHorizontal = false
        iconRow.translatesAutoresizingMaskIntoConstraints = false
        iconScroll.addSubview(iconRow)
        NSLayoutConstraint.activate([
            iconRow.leadingAnchor.constraint(equalTo: iconScroll.contentLayoutGuide.leadingAnchor),
            iconRow.trailingAnchor.constraint(equalTo: iconScroll.contentLayoutGuide.trailingAnchor),
            iconRow.topAnchor.constraint(equalTo: iconScroll.contentLayoutGuide.topAnchor),
            iconRow.bottomAnchor.constraint(equalTo: iconScroll.contentLayoutGuide.bottomAnchor),
            iconRow.heightAnchor.constraint(equalTo: iconScroll.frameLayoutGuide.heightAnchor),
            iconScroll.widthAnchor.constraint(greaterThanOrEqualToConstant: 148)
        ])
        iconScroll.setContentCompressionResistancePriority(UILayoutPriority(1), for: .horizontal)
        iconScroll.setContentHuggingPriority(UILayoutPriority(251), for: .horizontal)
        tcol.setContentCompressionResistancePriority(UILayoutPriority(740), for: .horizontal)
        cubeIcon = icon("cube") { [weak self] in self?.toggle3d() }
        addIcon(iconRow, cubeIcon, 40)
        mbToggle = PillToggle()
        mbToggle.onClick = { [weak self] in
            guard let self = self, let l = self.selected() else { return }
            self.pushUndo()
            l.mblur = !l.mblur
            self.mbToggle.on = l.mblur
            self.refreshPanel(); self.render()
        }
        mbToggle.onLong = { [weak self] in
            guard let self = self, let l = self.selected() else { return }
            self.showMotionBlurSettings(l)
        }
        iconRow.addArrangedSubview(wrap(mbToggle, 52, 40, 0, 0, 0, 0))
        parentIcon = icon("dup") { [weak self] in
            guard let self = self, let l = self.selected() else { return }
            self.showParentPopup(l, self.parentIcon)
        }
        addIcon(iconRow, parentIcon, 40)
        // Pre-render (groups only): bake the group to frames; playback + render use those
        preIcon = icon("prerender") { [weak self] in
            guard let self = self, let l = self.selected(), l.type == .GROUP else { return }
            self.togglePreRender(l)
        }
        addIcon(iconRow, preIcon, 40)
        moreIcon = icon("more") { [weak self] in self?.showLayersMenu() }
        addIcon(iconRow, moreIcon, 40)
        gearIcon = icon("gear") { [weak self] in self?.showSceneDialog() }
        addIcon(iconRow, gearIcon, 40)
        sceneSetupBtn = icon("camera") { [weak self] in self?.toggleSceneSetup() }
        addIcon(iconRow, sceneSetupBtn, 40)
        top.addArrangedSubview(iconScroll)
        renderBtn = wrap(pill("Render", "export", C.GREEN, C.ONDARK) { [weak self] in
            self?.showRenderDialog()
        }, 104, 38, 0, 0, 0, 0)
        renderBtn.setContentCompressionResistancePriority(UILayoutPriority(1000), for: .horizontal)
        renderBtn.setContentHuggingPriority(UILayoutPriority(1000), for: .horizontal)
        top.addArrangedSubview(renderBtn)
        preRenderPill = pill("Pre-render", "prerender", C.GREEN, C.ONDARK) { [weak self] in
            guard let self = self, let l = self.selected(), l.type == .GROUP else { return }
            self.togglePreRender(l)
        }
        preRenderBtn = wrap(preRenderPill, 128, 38, 0, 0, 0, 0)
        preRenderBtn.setContentCompressionResistancePriority(UILayoutPriority(1000), for: .horizontal)
        preRenderBtn.setContentHuggingPriority(UILayoutPriority(1000), for: .horizontal)
        preRenderBtn.isHidden = true
        top.addArrangedSubview(preRenderBtn)

        // ---- preview area
        let previewBox = UIView()
        previewBox.backgroundColor = argbToUIColor(Int32(bitPattern: 0xFF161618))
        aspect = AspectLayout()
        preview = PreviewView()
        overlay = OverlayView(self, self)
        aspect.addSubview(preview)
        aspect.addSubview(overlay)
        previewBox.addSubview(aspect)
        aspect.enableViewportGestures(chipHost: previewBox)     // two-finger zoom / pan of the comp view
        preBadge = UILabel()
        preBadge.font = monoTimeFont(10)
        preBadge.textColor = .black
        preBadge.layer.cornerRadius = 5
        preBadge.layer.masksToBounds = true
        preBadge.isHidden = true
        preBadge.isUserInteractionEnabled = false
        preBadge.translatesAutoresizingMaskIntoConstraints = false
        previewBox.addSubview(preBadge)
        NSLayoutConstraint.activate([
            preBadge.leadingAnchor.constraint(equalTo: previewBox.leadingAnchor, constant: 8),
            preBadge.topAnchor.constraint(equalTo: previewBox.topAnchor, constant: 6),
            preBadge.heightAnchor.constraint(equalToConstant: 16)])
        aspect.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        // ---- right-edge tool column: cube button opens the Scene 3D editor
        let s3Icon = IconView("cube", C.GREEN, 22)
        s3Icon.onClick = { [weak self] in if let self = self { Scene3DView.present(in: self) } }
        s3Icon.translatesAutoresizingMaskIntoConstraints = false
        let s3Box = UIView()
        s3Box.backgroundColor = UIColor(white: 0.1, alpha: 0.85)
        s3Box.layer.cornerRadius = 12
        s3Box.translatesAutoresizingMaskIntoConstraints = false
        s3Box.addSubview(s3Icon)
        previewBox.addSubview(s3Box)
        NSLayoutConstraint.activate([
            s3Icon.centerXAnchor.constraint(equalTo: s3Box.centerXAnchor), s3Icon.centerYAnchor.constraint(equalTo: s3Box.centerYAnchor),
            s3Icon.widthAnchor.constraint(equalToConstant: 26), s3Icon.heightAnchor.constraint(equalToConstant: 26),
            s3Box.widthAnchor.constraint(equalToConstant: 40), s3Box.heightAnchor.constraint(equalToConstant: 40),
            s3Box.trailingAnchor.constraint(equalTo: previewBox.trailingAnchor, constant: -6),
            s3Box.topAnchor.constraint(equalTo: previewBox.topAnchor, constant: 8)])

        // zoom lock + move lock (2D comp view): sit right under the cube button
        func lockBtn(_ sym: String, below: UIView, _ toggle: @escaping (UIButton) -> Void) -> UIButton {
            let b = UIButton(type: .system)
            b.setImage(Icons.sf( sym), for: .normal)
            b.tintColor = .white
            b.backgroundColor = UIColor(white: 0.1, alpha: 0.85)
            b.layer.cornerRadius = 12
            b.translatesAutoresizingMaskIntoConstraints = false
            b.addAction(UIAction { _ in toggle(b) }, for: .touchUpInside)
            previewBox.addSubview(b)
            NSLayoutConstraint.activate([
                b.widthAnchor.constraint(equalToConstant: 40), b.heightAnchor.constraint(equalToConstant: 40),
                b.trailingAnchor.constraint(equalTo: s3Box.trailingAnchor), b.topAnchor.constraint(equalTo: below.bottomAnchor, constant: 6)])
            return b
        }
        func paint(_ b: UIButton, _ on: Bool) {
            b.tintColor = on ? argbToUIColor(C.GREEN) : .white
            b.backgroundColor = on ? UIColor(white: 0.22, alpha: 0.95) : UIColor(white: 0.1, alpha: 0.85)
            b.layer.borderWidth = on ? 1.5 : 0; b.layer.borderColor = argbToUIColor(C.GREEN).cgColor
        }
        let zoomLockBtn = lockBtn("plus.magnifyingglass", below: s3Box) { [weak self] b in
            guard let self = self else { return }
            self.aspect.zoomLocked.toggle(); paint(b, self.aspect.zoomLocked)
            self.toast(self.aspect.zoomLocked ? "Zoom locked" : "Zoom unlocked")
        }
        _ = lockBtn("arrow.up.and.down.and.arrow.left.and.right", below: zoomLockBtn) { [weak self] b in
            guard let self = self else { return }
            self.aspect.moveLocked.toggle(); paint(b, self.aspect.moveLocked)
            self.toast(self.aspect.moveLocked ? "Movement locked" : "Movement unlocked")
        }

        // ---- transport row (green-editor layout: utilities left, playback
        // centered in a subtle pill group, history right — even spacing,
        // nothing can overlap)
        let tr = hRow()
        tr.isLayoutMarginsRelativeArrangement = true
        tr.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 6, bottom: 0, trailing: 6)
        addIcon(tr, icon("fit") { [weak self] in self?.timeline.fitToScene() }, 34)
        qualityChip = ChipView("Full")
        qualityChip.onClick = { [weak self] in self?.cycleQuality() }
        tr.addArrangedSubview(wrap(qualityChip, 48, 48, 0, 0, 0, 0))
        markIcon = icon("bookmark") { [weak self] in self?.toggleMarker() }
        markIcon.onLong = { [weak self] in self?.nameMarker() }
        addIcon(tr, markIcon, 34)
        tr.addArrangedSubview(spacer())
        let playGroup = hRow()
        playGroup.spacing = 0
        let prev = icon("prev") { [weak self] in self?.jump(-1) }
        prev.onLong = { [weak self] in self?.stepFrame(-1) }
        playGroup.addArrangedSubview(wrap(prev, 34, 44, 0, 0, 0, 0))
        playIcon = IconView("play", C.GREEN, 30)
        playIcon.onClick = { [weak self] in self?.togglePlay() }
        playGroup.addArrangedSubview(wrap(playIcon, 40, 44, 0, 0, 0, 0))
        let next = icon("next") { [weak self] in self?.jump(1) }
        next.onLong = { [weak self] in self?.stepFrame(1) }
        playGroup.addArrangedSubview(wrap(next, 34, 44, 0, 0, 0, 0))
        let playPill = UIView()
        playPill.backgroundColor = argbToUIColor(Int32(bitPattern: 0xFF241A12))
        playPill.layer.cornerRadius = 21
        playPill.layer.borderWidth = 1
        playPill.layer.borderColor = argbToUIColor(Int32(bitPattern: 0xFF4A3018)).cgColor
        playPill.addSubview(playGroup)
        playGroup.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            // size the pill to its buttons — it used to have no width, so the
            // play button sat OUTSIDE the pill's bounds and never got touches
            playGroup.centerYAnchor.constraint(equalTo: playPill.centerYAnchor),
            playGroup.leadingAnchor.constraint(equalTo: playPill.leadingAnchor, constant: 6),
            playGroup.trailingAnchor.constraint(equalTo: playPill.trailingAnchor, constant: -6),
        ])
        tr.addArrangedSubview(wrap(playPill, 0, 44, 0, 2, 0, 2))
        tr.addArrangedSubview(spacer())
        addIcon(tr, icon("layers") { [weak self] in self?.showLayersMenu() }, 34)
        addIcon(tr, icon("undo") { [weak self] in self?.doUndo() }, 34)
        addIcon(tr, icon("redo") { [weak self] in self?.doRedo() }, 34)

        timeline = TimelineView(self, self)

        // The floating action bar over the timeline: trim in / split / trim out / delete.
        // It appears only while a layer is selected, which keeps the main toolbar clean.
        let tlBox = UIView()
        tlBox.clipsToBounds = true          // the playhead / ruler must not bleed over the panels
        timeline.clipsToBounds = true
        tlBox.addSubview(timeline)
        let abar = UIStackView()
        abar.axis = .horizontal
        abar.alignment = .center
        abar.spacing = 0
        abar.backgroundColor = argbToUIColor(Int32(bitPattern: 0xF01E1E22)).withAlphaComponent(0.94)
        abar.layer.cornerRadius = 26
        abar.layer.borderWidth = 1
        abar.layer.borderColor = argbToUIColor(Int32(bitPattern: 0xFF3A3A42)).cgColor
        abar.isLayoutMarginsRelativeArrangement = true
        abar.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 8, bottom: 0, trailing: 8)
        addIcon(abar, icon("trimin") { [weak self] in self?.trimTo(true) }, 52, 48)
        addIcon(abar, icon("split") { [weak self] in self?.splitAtPlayhead(false) }, 52, 48)
        addIcon(abar, icon("trimout") { [weak self] in self?.trimTo(false) }, 52, 48)
        addIcon(abar, icon("trash", C.RED) { [weak self] in self?.deleteLayer() }, 52, 48)
        actionBar = abar
        actionBar.isHidden = true
        tlBox.addSubview(abar)
        abar.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            abar.centerXAnchor.constraint(equalTo: tlBox.centerXAnchor),
            abar.bottomAnchor.constraint(equalTo: tlBox.bottomAnchor, constant: -8),
            abar.heightAnchor.constraint(equalToConstant: 48)
        ])

        // ---- bottom tool bar
        toolbarBox = UIScrollView()
        toolbarBox.showsHorizontalScrollIndicator = false
        toolbarBox.backgroundColor = argbToUIColor(C.PANEL)
        toolbarRow = hRow()
        toolbarRow.translatesAutoresizingMaskIntoConstraints = false
        toolbarBox.addSubview(toolbarRow)
        NSLayoutConstraint.activate([
            toolbarRow.topAnchor.constraint(equalTo: toolbarBox.contentLayoutGuide.topAnchor),
            toolbarRow.bottomAnchor.constraint(equalTo: toolbarBox.contentLayoutGuide.bottomAnchor),
            toolbarRow.leadingAnchor.constraint(equalTo: toolbarBox.contentLayoutGuide.leadingAnchor),
            toolbarRow.trailingAnchor.constraint(equalTo: toolbarBox.contentLayoutGuide.trailingAnchor),
            toolbarRow.heightAnchor.constraint(equalTo: toolbarBox.frameLayoutGuide.heightAnchor)
        ])

        // ---- property panel (side rail + scroll)
        panelBox = UIView()
        panelBox.backgroundColor = argbToUIColor(C.PANEL)
        let ph = hRow()
        ph.alignment = .fill
        ph.spacing = 0
        let side = UIStackView()
        side.axis = .vertical
        side.alignment = .center
        side.spacing = 0
        side.addArrangedSubview(wrap(icon("close") { [weak self] in self?.closePanel() }, 48, 48, 0, 0, 0, 0))
        side.addArrangedSubview(wrap(icon("plus", C.GREEN) { [weak self] in
            guard let self = self else { return }
            self.fxTab = 1; self.openPanel(P_FX)
        }, 48, 44, 0, 0, 0, 0))
        diamondSide = icon("diamond_f", C.DIM) { [weak self] in self?.keySelected() }
        side.addArrangedSubview(wrap(diamondSide, 48, 44, 0, 0, 0, 0))
        side.addArrangedSubview(wrap(icon("graph", C.DIM) { [weak self] in
            guard let self = self else { return }
            if let l = self.selected(), !self.selKey.isEmpty, l.track(self.selKey).keys.count >= 2 { self.graphProp = self.selKey; self.graphKey = 0 }
            self.openPanel(P_GRAPH)
        }, 48, 44, 0, 0, 0, 0))
        side.addArrangedSubview(wrap(icon("cmd", C.DIM) { [weak self] in self?.exprSelected() }, 48, 44, 0, 0, 0, 0))
        side.addArrangedSubview(wrap(icon("box", C.DIM) { [weak self] in
            guard let self = self else { return }
            self.fxTab = 2; self.openPanel(P_FX)
        }, 48, 44, 0, 0, 0, 0))
        side.addArrangedSubview(wrap(icon("more", C.DIM) { [weak self] in self?.showPanelMenu() }, 48, 44, 0, 0, 0, 0))
        ph.addArrangedSubview(fixedWidth(side, 52))
        let panelSv = UIScrollView()
        panelSv.keyboardDismissMode = .onDrag
        panelList = vStack()
        panelList.isLayoutMarginsRelativeArrangement = true
        panelList.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 6, leading: 4, bottom: 16, trailing: 8)
        panelList.translatesAutoresizingMaskIntoConstraints = false
        panelSv.addSubview(panelList)
        NSLayoutConstraint.activate([
            panelList.topAnchor.constraint(equalTo: panelSv.contentLayoutGuide.topAnchor),
            panelList.bottomAnchor.constraint(equalTo: panelSv.contentLayoutGuide.bottomAnchor),
            panelList.leadingAnchor.constraint(equalTo: panelSv.contentLayoutGuide.leadingAnchor),
            panelList.trailingAnchor.constraint(equalTo: panelSv.contentLayoutGuide.trailingAnchor),
            panelList.widthAnchor.constraint(equalTo: panelSv.frameLayoutGuide.widthAnchor)
        ])
        ph.addArrangedSubview(panelSv)
        ph.translatesAutoresizingMaskIntoConstraints = false
        panelBox.addSubview(ph)
        NSLayoutConstraint.activate([
            ph.topAnchor.constraint(equalTo: panelBox.topAnchor),
            ph.bottomAnchor.constraint(equalTo: panelBox.bottomAnchor),
            ph.leadingAnchor.constraint(equalTo: panelBox.leadingAnchor),
            ph.trailingAnchor.constraint(equalTo: panelBox.trailingAnchor)
        ])

        timeline.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        tlBox.clipsToBounds = true

        // ---- root (the Kotlin LinearLayout with orientation branches)
        rootLayout = RootLayout()
        rootLayout.translatesAutoresizingMaskIntoConstraints = false
        rootLayout.top = top
        rootLayout.previewBox = previewBox
        rootLayout.tr = tr
        rootLayout.timeline = tlBox
        rootLayout.toolbarBox = toolbarBox
        rootLayout.panelBox = panelBox
        // The slots must actually live in the hierarchy — RootLayout.lay() only frames
        // views whose superview is itself (placePanel() re-parents panelBox later, so it
        // is appended last here to keep it on top of the weighted stack).
        rootLayout.addSubview(top)
        rootLayout.addSubview(previewBox)
        rootLayout.addSubview(tr)
        rootLayout.addSubview(tlBox)
        rootLayout.addSubview(toolbarBox)
        rootLayout.addSubview(panelBox)
        screen.addSubview(rootLayout)
        rootBottom = rootLayout.bottomAnchor.constraint(equalTo: screen.safeAreaLayoutGuide.bottomAnchor)
        NSLayoutConstraint.activate([
            rootLayout.topAnchor.constraint(equalTo: screen.safeAreaLayoutGuide.topAnchor),
            rootLayout.leadingAnchor.constraint(equalTo: screen.safeAreaLayoutGuide.leadingAnchor),
            rootLayout.trailingAnchor.constraint(equalTo: screen.safeAreaLayoutGuide.trailingAnchor),
            rootBottom!
        ])

        toolbarBox.isHidden = false
        panelBox.isHidden = true
    }

    // ================================================================ small helpers

    func selected() -> Layer? { Editor.scene.layers.first { $0.id == selId } }

    func render() {
        FreezeWatchdog.beat()          // main thread is alive (R15/R19)
        lastActivity = CFAbsoluteTimeGetCurrent()
        if !playing { scheduleSave() } // any visible change → saved shortly after
        if playing {
            preview.requestDraw()
            overlay.setNeedsDisplay()
        } else {
            // draw preview and gizmo together in the same pass so the gizmo never trails the picture
            preview.display()
            overlay.setNeedsDisplay()
            overlay.layer.displayIfNeeded()
        }
        timeline.setNeedsDisplay()
        updatePreBadge()
    }

    @discardableResult
    func pill(_ text: String, _ icon: String? = nil, _ fill: Int32 = C.CARD2, _ tc: Int32 = C.TEXT,
                      click: @escaping () -> Void) -> PillButton {
        let b = PillButton(text, icon, fill, tc)
        b.onClick = click
        return b
    }

    /// Kotlin put(parent, v, hDp, mT, mB): adds with top/bottom margins; h>0 → fixed height.
    @discardableResult
    func put(_ parent: UIStackView, _ v: UIView, _ h: CGFloat = 0, _ mT: CGFloat = 3, _ mB: CGFloat = 3) -> UIView {
        parent.addArrangedSubview(pad(v, mT, 0, mB, 0))
        if h > 0 { v.heightAnchor.constraint(equalToConstant: v is RulerSlider ? h * Dev.k : h).isActive = true }
        return v
    }

    /// Wraps a view in padding (Android view.setPadding / layout margins).
    func pad(_ v: UIView, _ t: CGFloat, _ l: CGFloat, _ b: CGFloat, _ r: CGFloat) -> UIView {
        let w = UIView()
        w.translatesAutoresizingMaskIntoConstraints = false
        v.translatesAutoresizingMaskIntoConstraints = false
        w.addSubview(v)
        NSLayoutConstraint.activate([
            v.topAnchor.constraint(equalTo: w.topAnchor, constant: t),
            v.bottomAnchor.constraint(equalTo: w.bottomAnchor, constant: -b),
            v.leadingAnchor.constraint(equalTo: w.leadingAnchor, constant: l),
            v.trailingAnchor.constraint(equalTo: w.trailingAnchor, constant: -r)
        ])
        return w
    }

    /// Wraps a view with explicit size + margins (Android LayoutParams with setMargins).
    func wrap(_ v: UIView, _ w: CGFloat, _ h: CGFloat, _ l: CGFloat, _ t: CGFloat, _ r: CGFloat, _ b: CGFloat) -> UIView {
        let box = pad(v, t, l, b, r)
        if w > 0 { v.widthAnchor.constraint(equalToConstant: w).isActive = true }
        if h > 0 { v.heightAnchor.constraint(equalToConstant: h).isActive = true }
        return box
    }

    /// Wrapper that pins the child to the edges but fixes the wrapper width (the 52pt side rail).
    func fixedWidth(_ v: UIView, _ w: CGFloat) -> UIView {
        let box = UIView()
        box.translatesAutoresizingMaskIntoConstraints = false
        v.translatesAutoresizingMaskIntoConstraints = false
        box.addSubview(v)
        NSLayoutConstraint.activate([
            v.topAnchor.constraint(equalTo: box.topAnchor),
            v.bottomAnchor.constraint(equalTo: box.bottomAnchor),
            v.leadingAnchor.constraint(equalTo: box.leadingAnchor),
            v.trailingAnchor.constraint(equalTo: box.trailingAnchor),
        ])
        box.widthAnchor.constraint(equalToConstant: w).isActive = true
        return box
    }

    @discardableResult
    func text(_ parent: UIStackView, _ t: String, _ color: Int32 = C.DIM,
                      _ size: CGFloat = 13, _ bold: Bool = false) -> UILabel {
        let tv = UILabel()
        tv.text = t
        tv.textColor = argbToUIColor(color)
        tv.font = bold ? boldFont(size) : sysFont(size)
        tv.numberOfLines = 0
        parent.addArrangedSubview(pad(tv, 6, 6, 4, 6))
        return tv
    }

    func refreshAll() {
        aspect.ratio = CGFloat(Float(Editor.project.w) / Float(Editor.project.h))
        if selected() == nil { selId = -1 }
        safe("title") { refreshTitle() }
        safe("toolbar") { refreshToolbar() }
        safe("panel") { showBottom() }
        safe("panel") { refreshPanel() }
        safe("time") { onTimeChanged() }
        safe("audio") { ensureAudio() }
    }

    /// Hide a top-bar icon AND its fixed-width wrapper, so hidden icons don't leave blank slots
    /// that push the visible ones (e.g. Scene Setup) out of the scrolling strip.
    func hideSlot(_ v: UIView, _ hidden: Bool) {
        v.isHidden = hidden
        if let w = v.superview, !(w is UIStackView) { w.isHidden = hidden }
    }

    func refreshTitle() {
        let l = selected()
        titleView.text = l?.name ?? Editor.project.name
        let on = l != nil && (l!.is3d || l!.type == .MODEL || l!.type == .CAMERA || Xf.isParticles(l!))
        cubeIcon.set("cube", on ? C.GREEN : C.TEXT)
        let sel = l != nil
        hideSlot(cubeIcon, !sel)
        hideSlot(mbToggle, !sel || l!.type == .AUDIO)
        hideSlot(parentIcon, !sel)
        hideSlot(preIcon, !(sel && l!.type == .GROUP))
        if let l = l, l.type == .GROUP {
            var col = C.TEXT
            if l.prerender && PreRender.enabled {
                let sz = SceneRenderer.size(Editor.project, quality: preview.quality)
                let baked = PreRender.nextMissing(l, project: Editor.project, scene: Editor.scene, size: sz, from: l.start) == nil
                col = baked ? C.GREEN : C.AMBER
            }
            preIcon.set("prerender", col)
        }
        updatePreBadge()
        hideSlot(moreIcon, !sel)
        hideSlot(gearIcon, sel)
        hideSlot(sceneSetupBtn, sel)
        sceneSetupBtn.set("camera", sceneSetupOn ? C.GREEN : C.TEXT)
        let isGroup = sel && l!.type == .GROUP
        renderBtn.isHidden = sel
        preRenderBtn.isHidden = !isGroup
        if isGroup, let g = l {
            let on = g.prerender && PreRender.enabled
            preRenderPill.text = on ? "Un-bake" : "Pre-render"
            preRenderPill.fillColor = on ? C.AMBER : C.GREEN
        }
        if let l = l {
            mbToggle.on = l.mblur
            parentIcon.set("dup", l.parentId >= 0 ? C.GREEN : C.TEXT)
        }
        actionBar.isHidden = !sel
    }

    /** The Effects panel covers the whole screen; every other panel sits under the timeline. */
    func placePanel(_ full: Bool) {
        let cur = panelBox.superview
        if full {
            if cur !== screen {
                panelBox.removeFromSuperview()
                screen.addSubview(panelBox)
            }
            panelBox.autoresizingMask = []
            screen.bringSubviewToFront(panelBox)
            applyFullPanelFrame()
            rootLayout.setNeedsLayout()
        } else if cur !== rootLayout {
            panelBox.removeFromSuperview()
            panelBox.autoresizingMask = []
            rootLayout.addSubview(panelBox)   // re-appended last — its layout slot
            rootLayout.setNeedsLayout()
        }
    }

    func applyFullPanelFrame() {
        guard panelBox.superview === screen else { return }
        var f = screen.safeAreaLayoutGuide.layoutFrame
        f.size.height = max(0, f.height - kbInset)
        panelBox.frame = f
    }

    func showBottom() {
        placePanel(panel == P_FX && fxTab == 1)
        toolbarBox.isHidden = panel != P_NONE
        panelBox.isHidden = panel == P_NONE
        rootLayout.setNeedsLayout()   // visibility changes must re-flow the weighted layout
    }

    func onTimeChanged() {
        syncRows()
        subView.text = timeline.timecode(Editor.time) + " / " + timeline.timecode(Editor.scene.duration)
        let has = Editor.scene.markers.contains { abs($0 - Editor.time) < 0.02 }
        markIcon.set(has ? "bookmark_f" : "bookmark", has ? C.BLUE : C.TEXT)
        render()
    }

    func onBack() {
        if panel != P_NONE {
            closePanel()
        } else if selId != -1 {
            onSelect(-1)
        } else if let nav = navigationController {
            nav.popViewController(animated: true)
        } else {
            dismiss(animated: true)
        }
    }

    func openPanel(_ p: Int) {
        if p != P_MEDIA && p != P_SHAPES && selected() == nil { toast("Select a layer first"); return }
        panel = p
        showBottom(); refreshPanel()
    }

    func closePanel() { panel = P_NONE; showBottom() }

    // ================================================================ keyboard (adjustResize)

    @objc private func kbChanged(_ n: Notification) {
        guard let info = n.userInfo else { return }
        let show = n.name == UIResponder.keyboardWillShowNotification
        let dur = (info[UIResponder.keyboardAnimationDurationUserInfoKey] as? Double) ?? 0.25
        var endH: CGFloat = 0
        if show, let f = (info[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
            endH = max(0, f.height - view.safeAreaInsets.bottom)
        }
        kbInset = endH
        UIView.animate(withDuration: dur) {
            self.rootBottom?.constant = self.kbInset
            if self.panelBox.superview === self.view {
                var fr = self.view.safeAreaLayoutGuide.layoutFrame
                fr.size.height = max(0, fr.height - self.kbInset)
                self.panelBox.frame = fr
            }
            self.view.layoutIfNeeded()
        }
    }

    // ================================================================ tool bar

    func refreshToolbar() {
        toolbarRow.arrangedSubviews.forEach { $0.removeFromSuperview() }
        func tool(_ ic: String, _ label: String, _ tint: Int32 = C.TEXT, _ click: @escaping () -> Void) {
            let b = ToolButton(ic, label)
            b.tint = tint
            b.onClick = click
            toolbarRow.addArrangedSubview(wrap(b, 76, 76, 0, 0, 0, 0))
        }
        guard let l = selected() else {
            tool("media", "Media") { [weak self] in self?.openPanel(P_MEDIA) }
            tool("text", "Text") { [weak self] in self?.addLayer(.TEXT) }
            tool("solid", "Solid") { [weak self] in self?.addSolid() }
            tool("adjust", "Adjustment") { [weak self] in self?.addLayer(.ADJUST) }
            tool("audio", "Audio") { [weak self] in self?.showAudioLibrary() }
            tool("nullobj", "Null") { [weak self] in self?.addLayer(.NULL) }
            tool("shape", "Shape") { [weak self] in self?.openPanel(P_SHAPES) }
            tool("shape", "Vector Pen") { [weak self] in self?.openPenEditor() }
            tool("camera", "Camera") { [weak self] in self?.addLayer(.CAMERA) }
            tool("particles", "Particles") { [weak self] in self?.addParticles() }
            tool("flare", "Optical Flare") { [weak self] in self?.showFlareLibrary() }
            tool("layers", "Group") { [weak self] in self?.addLayer(.GROUP) }
            tool("puppet", "Create Rig") { [weak self] in self?.createRig() }
            tool("cube", "3D") { [weak self] in self?.show3DImport() }
            return
        }
        toolbarRow.addArrangedSubview(wrap(icon("back", C.GREEN) { [weak self] in self?.onSelect(-1) }, 44, 76, 0, 0, 0, 0))
        if l.type == .VIDEO { tool("audio", "Extract audio") { [weak self] in self?.extractAudio(l) } }
        if l.type == .GROUP && l.rig != nil {
            tool("puppet", "Cubism Editor", C.GREEN) { [weak self] in self?.openRigEditor(l) }
            tool("sparkle", "Animate Rig", C.GREEN) { [weak self] in self?.openPanel(P_RIGANIM) }
        }
        tool("edit", "Edit") { [weak self] in self?.openPanel(P_EDIT) }
        tool("edit", "Rename") { [weak self] in self?.renameLayer(l) }
        tool("move", "Transform") { [weak self] in self?.openPanel(P_XFORM) }
        if l.isRenderable() || l.type == .GROUP || l.type == .ADJUST {
            tool("sparkle", "Effects") { [weak self] in self?.openPanel(P_FX) }
            tool("drop", "Blending") { [weak self] in self?.openPanel(P_BLEND) }
            tool("speed", "Speed") { [weak self] in self?.openPanel(P_SPEED) }
            if l.type == .IMAGE || l.type == .VIDEO || l.type == .TEXT || l.type == .GROUP {
                tool("puppet", "Puppet") { [weak self] in self?.openPuppet() }
            }
        }
        if l.type == .AUDIO || l.type == .NULL {       // audio: audio effects only · null: movement effects only
            tool("sparkle", "Effects") { [weak self] in self?.openPanel(P_FX) }
        }
        if l.isRenderable() && l.rig == nil && l.deformer == 0 {
            tool("layers", "To Rig") { [weak self] in self?.importToRig(l) }     // last: rarely needed now
        }
    }

    // ================================================================ playback (Choreographer → CADisplayLink)

    func doFrame() {
        FreezeWatchdog.beat()          // playback frames count as liveness
        if !playing { return }
        let ts = CACurrentMediaTime()
        if lastTs != 0 && ts > lastTs {
            var t = Editor.time + Float(ts - lastTs)
            var wrapped = false
            if t >= Editor.scene.duration { t = 0; wrapped = true }
            Editor.time = t
            if wrapped { startAudio() } else { tickAudio() }
            onTimeChanged()
        }
        lastTs = ts
    }

    func togglePlay() {
        CrashLog.note("play")
        playing = !playing
        playIcon.set(playing ? "pause" : "play", C.GREEN)
        if playing {
            lastTs = 0
            if displayLink == nil {
                let proxy = DisplayLinkProxy()
                proxy.vc = self
                let link = CADisplayLink(target: proxy, selector: #selector(DisplayLinkProxy.tick(_:)))
                link.add(to: .main, forMode: .common)
                linkProxy = proxy
                displayLink = link
            }
            displayLink?.isPaused = false
            startAudio()
        } else {
            displayLink?.isPaused = true
            stopAudio()
        }
    }

    func stepFrame(_ dir: Int) {
        Editor.time = clamp(Editor.time + Float(dir) / Float(Editor.project.fps), 0, Editor.scene.duration)
        onTimeChanged()
    }

    func jump(_ dir: Int) {
        // stops: start + end of the comp, the user's markers, and the selected layer's keyframes
        var times: [Float] = [0, Editor.scene.duration]
        times.append(contentsOf: Editor.scene.markers)
        if let l = selected() {
            for (_, tr) in l.props { for k in tr.keys { times.append(k.t) } }
        }
        times = times.filter { $0 >= 0 && $0 <= Editor.scene.duration }.sorted()
        let now = Editor.time
        let target = dir > 0 ? times.first { $0 > now + 0.02 } : times.last { $0 < now - 0.02 }
        if let target = target { Editor.time = target; onTimeChanged() }
    }

    func toggleMarker() {
        var ms = Editor.scene.markers
        let ex = ms.first { abs($0 - Editor.time) < 0.02 }
        pushUndo()
        if let ex = ex {
            Editor.scene.setMarkerName(ex, "")
            ms.removeAll { $0 == ex }
        } else {
            ms.append(Editor.time)
        }
        Editor.scene.markers = ms
        onTimeChanged()
    }

    func nameMarker() {
        var ms = Editor.scene.markers
        var m: Float? = ms.first { abs($0 - Editor.time) < 0.02 }
        if m == nil {
            pushUndo()
            ms.append(Editor.time)
            m = Editor.time
            Editor.scene.markers = ms
            onTimeChanged()
        }
        guard let tm = m else { return }
        let box = vStack()
        box.isLayoutMarginsRelativeArrangement = true
        box.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 4, leading: 4, bottom: 4, trailing: 4)
        text(box, timeline.timecode(tm), C.DIM, 13)
        let et = makeField("")
        et.placeholder = "Marker name"
        et.text = Editor.scene.markerName(tm) ?? ""
        box.addArrangedSubview(wrap(et, 0, 44, 0, 0, 0, 0))
        text(box, "Expressions can reach this marker by name:  marker.key(\"name\")", C.DIM, 12)
        Dlg(self).setTitle("Name marker").setView(box).setPositiveButton("Save") { [weak self] _, _ in
            guard let self = self else { return }
            self.pushUndo()
            Editor.scene.setMarkerName(tm, et.text ?? "")
            self.timeline.setNeedsDisplay()
            self.render()
        }.setNegativeButton("Cancel", nil).show()
    }

    func cycleQuality() {
        quality = quality == 1 ? 2 : (quality == 2 ? 4 : 1)
        preview.quality = quality
        qualityChip.text = quality == 1 ? "Full" : (quality == 2 ? "1/2" : "1/4")
        qualityChip.setNeedsDisplay()
        render()
    }

    // ================================================================ undo / redo

    func snapshot() -> String { Editor.project.toJson().toString() }

    func pushUndo() {
        markDirty()                    // every edit passes through here (R11/R19)
        let s = snapshot()
        if undoStack.last == s { return }
        undoStack.append(s)
        if undoStack.count > 40 { undoStack.removeFirst() }
        redoStack.removeAll()
    }

    func restore(_ js: String) {
        FrameCache.bump()
        markDirty()
        if let o = try? JObj(json: js) { Editor.project = Project.fromJson(o) }
        // a restored project with zero scenes must not wedge sceneIndex at -1
        if Editor.project.scenes.isEmpty {
            Editor.project.scenes = [Scene("Scene 1")]
        }
        Editor.sceneIndex = clamp(Editor.sceneIndex, 0, Editor.project.scenes.count - 1)
        Editor.time = clamp(Editor.time, 0, Editor.scene.duration)
        refreshAll()
    }

    func doUndo() {
        if undoStack.isEmpty { toast("Nothing to undo"); return }
        redoStack.append(snapshot())
        let js = undoStack.removeLast()
        restore(js)
    }

    func doRedo() {
        if redoStack.isEmpty { toast("Nothing to redo"); return }
        undoStack.append(snapshot())
        let js = redoStack.removeLast()
        restore(js)
    }

    // ================================================================ hosts

    func selectedLayer() -> Layer? { selected() }
    func autoKey() -> Bool { autoKeyOn }
    func beginEdit() { pushUndo() }
    func onEdited() { syncRows(); render() }
    func selectedId() -> Int { selId }
    func isSelected(_ id: Int) -> Bool { id == selId || multi.contains(id) }
    func onSeek(_ t: Float) {
        FrameCache.scrubbing = true
        Editor.time = t
        onTimeChanged()
        scrubEndWork?.cancel()
        let w = DispatchWorkItem { FrameCache.scrubbing = false }
        scrubEndWork = w
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.35, execute: w)
    }

    func onSelect(_ id: Int) {
        if multiMode && id >= 0 {
            if let i = multi.firstIndex(of: id) { multi.remove(at: i) } else { multi.append(id) }
            selId = id
            panel = P_NONE
            refreshTitle(); refreshToolbar(); showBottom(); refreshPanel(); render()
            return
        }
        if !multiMode { multi.removeAll() }
        selId = id
        panel = id >= 0 && selected()?.type == .TEXT ? P_EDIT : P_NONE
        refreshTitle(); refreshToolbar(); showBottom(); refreshPanel(); render()
    }

    func onToggleVisible(_ l: Layer) {
        pushUndo()
        l.visible = !l.visible
        render()
    }

    func onTimingChanged() { render() }

    func onReorder(_ l: Layer, _ listIndex: Int) {
        pushUndo()
        var ls = Editor.scene.layers
        ls.removeAll { $0 === l }
        ls.insert(l, at: clamp(listIndex, 0, ls.count))
        Editor.scene.layers = ls
        render()
    }

    func onKeyTap(_ l: Layer, _ key: String, _ idx: Int) {
        selId = l.id
        graphProp = key
        graphKey = idx
        let ks = l.track(key).keys
        if ks.indices.contains(idx) { Editor.time = ks[idx].t }
        // Tapping a keyframe only selects it and moves the playhead; it no longer forces the
        // graph panel open (use the graph button). If the graph is already open it follows.
        selKey = key
        if panel == P_GRAPH { refreshTitle(); refreshToolbar(); showBottom(); refreshPanel() }
        onTimeChanged()
    }
}


/// Scroll view whose intrinsic width is its content width (so it hugs the icons when there is room).
final class TopIconScroll: UIScrollView {
    override var intrinsicContentSize: CGSize {
        layoutIfNeeded()
        return CGSize(width: contentSize.width, height: UIView.noIntrinsicMetric)
    }
    override func layoutSubviews() { super.layoutSubviews(); invalidateIntrinsicContentSize() }
}
