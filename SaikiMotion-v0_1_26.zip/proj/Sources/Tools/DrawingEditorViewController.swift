// DrawingEditorViewController.swift — the paint screen of the Drawing Editor.
// Ibis-Paint-style layout in the editor's dark / orange theme: top bar (undo / redo / send to
// editor), canvas, two sliders (size + opacity), bottom bar (tool, color, layers).
// Long-press on the canvas = eyedropper. Layer panel: add, folder, rename, duplicate, merge,
// reorder, opacity, background.

import UIKit
import PhotosUI
import Photos
import UniformTypeIdentifiers

// MARK: - small widgets -----------------------------------------------------------------

final class DrawBtn: TapView {
    var icon: String? { didSet { setNeedsDisplay() } }
    var symbol: String? { didSet { setNeedsDisplay() } }
    var title: String? { didSet { setNeedsDisplay() } }
    var tint: Int32 = C.TEXT { didSet { setNeedsDisplay() } }
    var active = false { didSet { setNeedsDisplay() } }

    override init(frame: CGRect) { super.init(frame: frame); backgroundColor = .clear }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    convenience init(icon: String? = nil, symbol: String? = nil, title: String? = nil, _ action: (() -> Void)? = nil) {
        self.init(frame: .zero)
        self.icon = icon; self.symbol = symbol; self.title = title; self.onClick = action
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let col = (isHighlighted || active) ? C.GREEN : tint
        let hasGlyph = icon != nil || symbol != nil
        let gy = (title != nil && hasGlyph) ? bounds.midY - 8 : bounds.midY
        if let i = icon { Icons.draw(c, i, bounds.midX, gy, 22, col) }
        else if let s = symbol, let img = Icons.sf( s)?
            .withTintColor(argbToUIColor(col), renderingMode: .alwaysOriginal) {
            let k = 22 / max(img.size.width, img.size.height)
            let sz = CGSize(width: img.size.width * k, height: img.size.height * k)
            img.draw(in: CGRect(x: bounds.midX - sz.width / 2, y: gy - sz.height / 2, width: sz.width, height: sz.height))
        }
        if let t = title {
            if hasGlyph { drawText(t, bounds.midX, bounds.maxY - 7, color: col, size: 10, bold: true, align: .center) }
            else { drawText(t, bounds.midX, bounds.midY + 5, color: col, size: 13, bold: true, align: .center) }
        }
    }
}

private final class DrawSliderRow: UIView {
    let label = UILabel()
    let minus = DrawBtn(title: "−")
    let plus = DrawBtn(title: "+")
    let slider = UISlider()
    var onChange: ((Float) -> Void)?
    var onTouch: ((Bool) -> Void)?
    var format: (Float) -> String = { String(Int($0 * 100)) }

    override init(frame: CGRect) {
        super.init(frame: frame)
        label.font = .monospacedDigitSystemFont(ofSize: 15, weight: .semibold)
        label.textColor = argbToUIColor(C.TEXT)
        label.textAlignment = .right
        slider.minimumTrackTintColor = argbToUIColor(C.GREEN)
        slider.maximumTrackTintColor = argbToUIColor(C.CARD2)
        slider.thumbTintColor = .white
        slider.addTarget(self, action: #selector(changed), for: .valueChanged)
        slider.addTarget(self, action: #selector(down), for: .touchDown)
        slider.addTarget(self, action: #selector(up), for: [.touchUpInside, .touchUpOutside, .touchCancel])
        for b in [minus, plus] {
            b.backgroundColor = argbToUIColor(C.CARD2); b.layer.cornerRadius = 15
            b.tint = C.TEXT
        }
        minus.onClick = { [weak self] in self?.nudge(-0.02) }
        plus.onClick = { [weak self] in self?.nudge(0.02) }
        [label, minus, slider, plus].forEach { addSubview($0) }
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    func set(_ v: Float) { slider.value = v; label.text = format(v) }
    private func nudge(_ d: Float) { set(max(0, min(1, slider.value + d))); onChange?(slider.value) }
    @objc private func changed() { label.text = format(slider.value); onChange?(slider.value) }
    @objc private func down() { onTouch?(true) }
    @objc private func up() { onTouch?(false) }

    override func layoutSubviews() {
        super.layoutSubviews()
        let h = bounds.height
        label.frame = CGRect(x: 8, y: 0, width: 46, height: h)
        minus.frame = CGRect(x: 60, y: (h - 30) / 2, width: 30, height: 30)
        plus.frame = CGRect(x: bounds.width - 40, y: (h - 30) / 2, width: 30, height: 30)
        slider.frame = CGRect(x: 98, y: 0, width: bounds.width - 98 - 48, height: h)
    }
}

private final class LayerCell: UITableViewCell {
    let eye = DrawBtn(icon: "eye")
    let thumb = UIImageView()
    let name = UILabel()
    let info = UILabel()
    let chev = DrawBtn(icon: "chev_down")
    var indent: CGFloat = 0

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .clear
        selectionStyle = .none
        thumb.layer.cornerRadius = 6; thumb.clipsToBounds = true; thumb.contentMode = .scaleAspectFit
        thumb.backgroundColor = argbToUIColor(C.CARD2)
        name.font = .systemFont(ofSize: 15, weight: .semibold); name.textColor = argbToUIColor(C.TEXT)
        info.font = .systemFont(ofSize: 11); info.textColor = argbToUIColor(C.DIM)
        [eye, thumb, name, info, chev].forEach { contentView.addSubview($0) }
        layer.cornerRadius = 10
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    override func layoutSubviews() {
        super.layoutSubviews()
        let h = contentView.bounds.height, w = contentView.bounds.width
        eye.frame = CGRect(x: 2, y: 0, width: 40, height: h)
        thumb.frame = CGRect(x: 46 + indent, y: 7, width: h - 14, height: h - 14)
        let tx = thumb.frame.maxX + 10
        name.frame = CGRect(x: tx, y: 9, width: w - tx - 48, height: 20)
        info.frame = CGRect(x: tx, y: 31, width: w - tx - 48, height: 16)
        chev.frame = CGRect(x: w - 44, y: 0, width: 40, height: h)
    }
}

// MARK: - editor -------------------------------------------------------------------------

final class DrawingEditorViewController: UIViewController, PHPickerViewControllerDelegate,
                                         UITableViewDataSource, UITableViewDelegate,
                                         UITableViewDragDelegate, UITableViewDropDelegate,
                                         UIDocumentPickerDelegate {
    private let doc: DrawDoc
    /// Direct-edit mode (from the video editor): "Save" hands the flattened picture back through this.
    var onApply: ((UIImage) -> Void)?
    private let canvas = DrawingCanvasView()
    private let top = UIView(), bottom = UIView(), sliders = UIView(), xfBar = UIView()
    private let titleBtn = DrawBtn()
    private let undoBtn = DrawBtn(icon: "undo"), redoBtn = DrawBtn(icon: "redo")
    private let brushBtn = DrawBtn(), eraserBtn = DrawBtn()
    private var brushStyle = BrushStyle()
    private var eraserStyle = BrushStyle.eraserPresets[0]
    private var curStyle: BrushStyle {
        get { tool == .eraser ? eraserStyle : brushStyle }
        set { if tool == .eraser { eraserStyle = newValue } else { brushStyle = newValue } }
    }
    private var curPresets: [BrushStyle] { tool == .eraser ? BrushStyle.eraserPresets : BrushStyle.presets }
    private let selBadge = UILabel()
    private var dropInto = false
    private let toolBtn = DrawBtn(), colorBtn = TapView(), layersBtn = DrawBtn(), fitBtn = DrawBtn(icon: "fit")
    private let sizeRow = DrawSliderRow(), opRow = DrawSliderRow(), blurRow = DrawSliderRow()
    private let dot = UIView()
    private var dotTimer: Timer?
    private let dim = UIControl()
    private var panel: UIView?
    private var panelKind = 0                  // 0 none, 1 tools, 2 color, 3 layers, 4 brush, 5 selection
    private var table: UITableView?
    private var rows: [(PixLayer, Int)] = []
    private var thumbs: [String: UIImage] = [:]
    private var tool: DrawTool = .brush
    private var curColor: Int32 = C.TEXT
    private var sizeNorm: Float = 0.2
    private var opNorm: Float = 1
    private var layerOpSlider: UISlider?
    private var layerOpLabel: UILabel?

    init(item: DrawItem) {
        doc = DrawDoc(item)
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    // MARK: lifecycle

    override func viewDidLoad() {
        canvas.lockAlpha = false                          // brush paints transparent pixels (toggle in Tools to lock)
        super.viewDidLoad()
        view.backgroundColor = argbToUIColor(C.BG)
        let ud = UserDefaults.standard
        curColor = ud.object(forKey: "draw.color") != nil ? Int32(truncatingIfNeeded: ud.integer(forKey: "draw.color")) : argbColor(255, 0, 0, 0)
        if ud.object(forKey: "draw.size") != nil { sizeNorm = ud.float(forKey: "draw.size") }
        if ud.object(forKey: "draw.op") != nil { opNorm = ud.float(forKey: "draw.op") }

        if let d = ud.data(forKey: "draw.style"), let st = try? JSONDecoder().decode(BrushStyle.self, from: d) { brushStyle = st }
        if let d = ud.data(forKey: "draw.estyle"), let st = try? JSONDecoder().decode(BrushStyle.self, from: d) { eraserStyle = st }
        canvas.style = brushStyle
        canvas.eraserStyle = eraserStyle
        canvas.doc = doc
        view.addSubview(canvas)
        canvas.onColorPicked = { [weak self] c in self?.setColor(argbFrom(c), remember: false) }
        canvas.onChanged = { [weak self] in self?.afterEdit() }
        canvas.onTransformState = { [weak self] on in self?.refreshXf(on) }
        canvas.onBlocked = { msg in Toast.show(msg) }
        canvas.onSelectionChanged = { [weak self] in self?.refreshSelUI() }
        selBadge.font = .systemFont(ofSize: 12, weight: .bold); selBadge.textColor = .white
        selBadge.backgroundColor = UIColor(red: 0.2, green: 0.4, blue: 1, alpha: 0.9)
        selBadge.textAlignment = .center; selBadge.layer.cornerRadius = 11; selBadge.clipsToBounds = true
        selBadge.isHidden = true; selBadge.isUserInteractionEnabled = false
        view.addSubview(selBadge)

        dot.layer.borderColor = UIColor.white.cgColor; dot.layer.borderWidth = 1.5
        dot.backgroundColor = UIColor(white: 0, alpha: 0.25); dot.isHidden = true; dot.isUserInteractionEnabled = false
        view.addSubview(dot)

        buildTop(); buildBottom(); buildSliders(); buildXfBar()
        setTool(.brush)
        setColor(curColor, remember: false)
        applyBrushValues()
        afterEdit()
        NotificationCenter.default.addObserver(self, selector: #selector(saveQuiet),
                                               name: UIApplication.willResignActiveNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(saveQuiet),
                                               name: UIApplication.didReceiveMemoryWarningNotification, object: nil)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }

    override var prefersStatusBarHidden: Bool { false }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let w = view.bounds.width, sa = view.safeAreaInsets
        let topH: CGFloat = 52 + sa.top
        let botH: CGFloat = 62 + max(sa.bottom, 6)
        top.frame = CGRect(x: 0, y: 0, width: w, height: topH)
        bottom.frame = CGRect(x: 0, y: view.bounds.height - botH, width: w, height: botH)
        sliders.frame = CGRect(x: 0, y: bottom.frame.minY - 130, width: w, height: 130)
        xfBar.frame = sliders.frame
        canvas.frame = CGRect(x: 0, y: topH, width: w, height: sliders.frame.minY - topH)

        let bt = top.bounds
        let y = sa.top
        for (i, b) in [backBtn, undoBtn, redoBtn].enumerated() { b.frame = CGRect(x: 6 + CGFloat(i) * 46, y: y + 4, width: 44, height: 44) }
        moreBtn.frame = CGRect(x: bt.width - 50, y: y + 4, width: 44, height: 44)
        sendBtn.frame = CGRect(x: bt.width - 96, y: y + 4, width: 44, height: 44)
        titleBtn.frame = CGRect(x: 150, y: y + 4, width: bt.width - 150 - 100, height: 44)

        let bw = bottom.bounds.width
        let bwid = bw / 6
        brushBtn.frame = CGRect(x: 0, y: 4, width: bwid, height: 54)
        eraserBtn.frame = CGRect(x: bwid, y: 4, width: bwid, height: 54)
        colorBtn.frame = CGRect(x: 2 * bwid + (bwid - 44) / 2, y: 9, width: 44, height: 44)
        toolBtn.frame = CGRect(x: 3 * bwid, y: 4, width: bwid, height: 54)
        fitBtn.frame = CGRect(x: 4 * bwid, y: 4, width: bwid, height: 54)
        layersBtn.frame = CGRect(x: 5 * bwid, y: 4, width: bwid, height: 54)

        sizeRow.frame = CGRect(x: 0, y: 4, width: w, height: 40)
        opRow.frame = CGRect(x: 0, y: 46, width: w, height: 40)
        blurRow.frame = CGRect(x: 0, y: 88, width: w, height: 40)
        let bounds = xfBar.bounds
        xfCancel.frame = CGRect(x: 20, y: 22, width: bounds.width / 2 - 30, height: 44)
        xfApply.frame = CGRect(x: bounds.width / 2 + 10, y: 22, width: bounds.width / 2 - 30, height: 44)
        dim.frame = view.bounds
        selBadge.frame = CGRect(x: 12, y: canvas.frame.minY + 8, width: min(w - 24, 330), height: 22)
        layoutPanel()
    }

    // MARK: building

    private let backBtn = DrawBtn(icon: "back"), moreBtn = DrawBtn(icon: "more"), sendBtn = DrawBtn(icon: "export")
    private let xfCancel = UIButton(type: .system), xfApply = UIButton(type: .system)

    private func buildTop() {
        top.backgroundColor = argbToUIColor(C.PANEL)
        view.addSubview(top)
        backBtn.onClick = { [weak self] in self?.goBack() }
        undoBtn.onClick = { [weak self] in self?.canvas.undo() }
        redoBtn.onClick = { [weak self] in self?.canvas.redo() }
        sendBtn.onClick = { [weak self] in self?.sendToEditor() }
        moreBtn.onClick = { [weak self] in self?.moreMenu() }
        titleBtn.onClick = { [weak self] in self?.renameArt() }
        for b in [backBtn, undoBtn, redoBtn, titleBtn, sendBtn, moreBtn] { top.addSubview(b) }
        sendBtn.tint = C.GREEN
        if onApply != nil { sendBtn.icon = nil; sendBtn.title = "Save" }     // direct mode: Save = apply to comp
    }

    private func buildBottom() {
        bottom.backgroundColor = argbToUIColor(C.PANEL)
        view.addSubview(bottom)
        brushBtn.icon = "brush"; brushBtn.title = "Brush"
        brushBtn.onClick = { [weak self] in
            guard let s = self else { return }
            if s.tool == .brush { s.togglePanel(4) } else { s.closePanel(); s.setTool(.brush) }
        }
        eraserBtn.icon = "eraser"; eraserBtn.title = "Eraser"
        eraserBtn.onClick = { [weak self] in
            guard let s = self else { return }
            if s.tool == .eraser { s.togglePanel(4) } else { s.closePanel(); s.setTool(.eraser) }
        }
        toolBtn.onClick = { [weak self] in self?.togglePanel(1) }
        colorBtn.onClick = { [weak self] in self?.togglePanel(2) }
        colorBtn.layer.cornerRadius = 10; colorBtn.layer.borderWidth = 2
        colorBtn.layer.borderColor = UIColor(white: 1, alpha: 0.85).cgColor
        layersBtn.icon = "layers"; layersBtn.title = "Layers"
        layersBtn.onClick = { [weak self] in self?.togglePanel(3) }
        fitBtn.title = "Fit"
        fitBtn.onClick = { [weak self] in self?.canvas.fit() }
        for b in [brushBtn, eraserBtn, colorBtn, toolBtn, fitBtn, layersBtn] as [UIView] { bottom.addSubview(b) }
    }

    private func buildSliders() {
        sliders.backgroundColor = argbToUIColor(C.PANEL).withAlphaComponent(0.96)
        view.addSubview(sliders)
        sizeRow.format = { [weak self] v in String(format: "%.0f", self?.sizeFor(v) ?? 0) }
        sizeRow.onChange = { [weak self] v in self?.sizeNorm = v; self?.applyBrushValues(); self?.showDot() }
        sizeRow.onTouch = { [weak self] on in if on { self?.showDot() } }
        opRow.onChange = { [weak self] v in self?.opNorm = v; self?.applyBrushValues() }
        blurRow.onChange = { [weak self] v in
            guard let s = self else { return }
            s.curStyle.hardness = CGFloat(v); s.curStyle.name = "Custom"; s.applyStyle()
        }
        let cap = UILabel(); cap.text = "BLUR"; cap.font = .systemFont(ofSize: 9, weight: .bold)
        cap.textColor = argbToUIColor(C.DIM); cap.frame = CGRect(x: 10, y: 0, width: 44, height: 12); cap.textAlignment = .right
        blurRow.addSubview(cap)
        sliders.addSubview(sizeRow); sliders.addSubview(opRow); sliders.addSubview(blurRow)
        blurRow.set(Float(curStyle.hardness))
        sizeRow.set(sizeNorm); opRow.set(opNorm)
    }

    private func buildXfBar() {
        xfBar.backgroundColor = argbToUIColor(C.PANEL)
        xfBar.isHidden = true
        view.addSubview(xfBar)
        for (b, t, bg) in [(xfCancel, "Cancel", C.CARD2), (xfApply, "Apply", C.GREEN)] {
            b.setTitle(t, for: .normal)
            b.titleLabel?.font = .boldSystemFont(ofSize: 16)
            b.setTitleColor(bg == C.GREEN ? argbToUIColor(C.ONDARK) : argbToUIColor(C.TEXT), for: .normal)
            b.backgroundColor = argbToUIColor(bg); b.layer.cornerRadius = 12
            xfBar.addSubview(b)
        }
        xfCancel.addTarget(self, action: #selector(xfCancelTap), for: .touchUpInside)
        xfApply.addTarget(self, action: #selector(xfApplyTap), for: .touchUpInside)
        let hint = UILabel()
        hint.text = "Drag to move · pinch to scale · rotate with two fingers"
        hint.font = .systemFont(ofSize: 11); hint.textColor = argbToUIColor(C.DIM)
        hint.textAlignment = .center
        hint.frame = CGRect(x: 0, y: 2, width: 600, height: 18)
        hint.autoresizingMask = [.flexibleWidth]
        xfBar.addSubview(hint)
    }

    @objc private func xfCancelTap() { canvas.cancelTransform() }
    @objc private func xfApplyTap() { canvas.applyTransform() }
    private func refreshXf(_ on: Bool) { xfBar.isHidden = tool != .transform; sliders.isHidden = tool == .transform }

    // MARK: tool / color / values

    private func sizeFor(_ n: Float) -> Float { 1 + powf(n, 2.2) * 399 }

    private func applyBrushValues() {
        canvas.brushSize = CGFloat(sizeFor(sizeNorm))
        canvas.opacity = CGFloat(opNorm)
        sizeRow.set(sizeNorm); opRow.set(opNorm)
        UserDefaults.standard.set(sizeNorm, forKey: "draw.size")
        UserDefaults.standard.set(opNorm, forKey: "draw.op")
    }

    private func showDot() {
        let d = max(4, min(260, canvas.brushSize * canvas.zoomScale))
        dot.bounds = CGRect(x: 0, y: 0, width: d, height: d)
        dot.layer.cornerRadius = d / 2
        dot.center = canvas.center
        dot.isHidden = false
        dotTimer?.invalidate()
        dotTimer = Timer.scheduledTimer(withTimeInterval: 0.8, repeats: false) { [weak self] _ in self?.dot.isHidden = true }
    }

    private func setSelectionMode(_ on: Bool) {
        canvas.selectionMode = on
        if on && ![.brush, .eraser, .wand].contains(tool) { setTool(.brush) }
        refreshSelUI()
        if panelKind == 3 { reloadRows() }
    }

    private func refreshSelUI() {
        let has = doc.selHas
        selBadge.isHidden = !canvas.selectionMode
        selBadge.text = "SELECTION LAYER · " + (has ? "Existing" : "No Selection") + " · blue paint"
        if panelKind == 3 { updateSelRow() }
        if panelKind == 5 { updateSelPanel() }
    }

    private func setTool(_ t: DrawTool) {
        if (t == .smudge || t == .transform) && canvas.selectionMode { setSelectionMode(false) }
        tool = t
        canvas.tool = t
        let names: [DrawTool: (String, String)] = [
            .brush: ("brush", "Brush"), .eraser: ("eraser", "Eraser"),
            .smudge: ("smudge", "Smudge"), .eyedropper: ("pipette", "Pick"),
            .transform: ("move", "Transform"), .wand: ("wand", "Wand"),
        ]
        brushBtn.active = t == .brush
        eraserBtn.active = t == .eraser
        if t == .brush || t == .eraser { blurRow.set(Float(curStyle.hardness)) }
        if t == .brush || t == .eraser { toolBtn.symbol = nil; toolBtn.icon = "more"; toolBtn.title = "Tools" }
        else if t == .wand { toolBtn.symbol = nil; toolBtn.icon = "wand"; toolBtn.title = "Wand" }
        else { toolBtn.symbol = nil; toolBtn.icon = names[t]?.0; toolBtn.title = names[t]?.1 }
        toolBtn.tint = C.TEXT
        refreshXf(false)
        if t == .transform && doc.active == nil { Toast.show("Select a layer first") }
    }

    private func setColor(_ c: Int32, remember: Bool) {
        curColor = c | Int32(bitPattern: 0xFF000000)
        canvas.color = argbToUIColor(curColor)
        colorBtn.backgroundColor = argbToUIColor(curColor)
        UserDefaults.standard.set(Int(curColor), forKey: "draw.color")
        if remember {
            var r = (UserDefaults.standard.array(forKey: "draw.recent") as? [Int]) ?? []
            r.removeAll { $0 == Int(curColor) }
            r.insert(Int(curColor), at: 0)
            UserDefaults.standard.set(Array(r.prefix(12)), forKey: "draw.recent")
        }
    }

    private func afterEdit() {
        undoBtn.alpha = canvas.canUndo ? 1 : 0.35
        redoBtn.alpha = canvas.canRedo ? 1 : 0.35
        titleBtn.title = doc.item.name
        layersBtn.title = "Layers · \(doc.layers.filter { !$0.meta.isFolder }.count)"
        if let a = doc.active { thumbs[a.meta.id] = nil }
        if panelKind == 3 { reloadRows() }
        refreshSelUI()
    }

    // MARK: panels

    private func togglePanel(_ k: Int) {
        let was = panelKind
        closePanel()
        if was == k { return }
        panelKind = k
        dim.backgroundColor = .clear
        dim.addTarget(self, action: #selector(dimTap), for: .touchUpInside)
        view.insertSubview(dim, belowSubview: top)
        dim.frame = view.bounds
        let p = UIView()
        p.backgroundColor = argbToUIColor(C.CARD)
        p.layer.cornerRadius = 16
        p.layer.borderWidth = 1; p.layer.borderColor = argbToUIColor(C.LINE).cgColor
        p.clipsToBounds = true
        view.addSubview(p)
        panel = p
        switch k {
        case 1: buildToolsPanel(p)
        case 2: buildColorPanel(p)
        case 4: buildBrushPanel(p)
        case 5: buildSelPanel(p)
        default: buildLayersPanel(p)
        }
        layoutPanel()
    }

    @objc private func dimTap() { closePanel() }

    private func closePanel() {
        panel?.removeFromSuperview(); panel = nil; table = nil
        dim.removeFromSuperview(); dim.removeTarget(nil, action: nil, for: .allEvents)
        panelKind = 0
    }

    private func layoutPanel() {
        guard let p = panel else { return }
        let w = view.bounds.width
        let bottomY = bottom.frame.minY - 6
        switch panelKind {
        case 1: p.frame = CGRect(x: 10, y: bottomY - 360, width: min(260, w - 20), height: 360)
        case 5: p.frame = CGRect(x: 10, y: bottomY - 450, width: w - 20, height: 450)
        case 2: p.frame = CGRect(x: 10, y: bottomY - 360, width: w - 20, height: 360)
        case 4: let hh = min(bottomY - top.frame.maxY - 8, 462); p.frame = CGRect(x: 10, y: bottomY - hh, width: w - 20, height: hh)
        default:
            let h = min(view.bounds.height * 0.62, 520)
            p.frame = CGRect(x: 10, y: bottomY - h, width: w - 20, height: h)
        }
        if panelKind == 3 { layoutLayerPanel(p) }
        if panelKind == 2 { layoutColorPanel(p) }
        if panelKind == 1 { layoutToolsPanel(p) }
        if panelKind == 4 { layoutBrushPanel(p) }
        if panelKind == 5 { layoutSelPanel(p) }
    }

    // tools ------------------------------------------------------------------------------

    private let toolDefs: [(DrawTool, String, String)] = [
        (.brush, "brush", "Brush"), (.eraser, "eraser", "Eraser"),
        (.smudge, "smudge", "Smudge"), (.eyedropper, "pipette", "Eyedropper"),
        (.transform, "move", "Transform"), (.wand, "wand", "Magic Wand"),
        (.brush, "select", "Selection"),
    ]
    private func buildToolsPanel(_ p: UIView) {
        for (i, d) in toolDefs.enumerated() {
            let isSelBtn = d.2 == "Selection"
            let b = DrawBtn(icon: d.1, title: d.2) { [weak self] in
                guard let s = self else { return }
                s.closePanel()
                if isSelBtn { s.togglePanel(5) } else { s.setTool(d.0) }
            }
            b.active = !isSelBtn && d.0 == tool
            b.tag = 100 + i
            p.addSubview(b)
        }
        let lk = DrawBtn(icon: "layers", title: canvas.lockAlpha ? "Transparent pixels: Locked" : "Transparent pixels: Paintable") { [weak self] in
            guard let s = self else { return }
            s.canvas.lockAlpha.toggle()
            Toast.show(s.canvas.lockAlpha ? "Transparent pixels are locked — brush and smudge keep the shape" : "Transparent pixels can be painted")
            s.closePanel()
        }
        lk.active = canvas.lockAlpha
        lk.tag = 98
        p.addSubview(lk)
        let hint = UILabel()
        hint.text = "Hold the canvas to pick a color"
        hint.font = .systemFont(ofSize: 11); hint.textColor = argbToUIColor(C.DIM)
        hint.tag = 99; hint.textAlignment = .center
        p.addSubview(hint)
    }
    private func layoutToolsPanel(_ p: UIView) {
        let cw = p.bounds.width / 2
        for i in 0..<toolDefs.count {
            if let b = p.viewWithTag(100 + i) {
                b.frame = CGRect(x: CGFloat(i % 2) * cw, y: 8 + CGFloat(i / 2) * 64, width: cw, height: 62)
            }
        }
        p.viewWithTag(98)?.frame = CGRect(x: 0, y: 8 + CGFloat((toolDefs.count + 1) / 2) * 64, width: p.bounds.width, height: 46)
        p.viewWithTag(99)?.frame = CGRect(x: 0, y: p.bounds.height - 30, width: p.bounds.width, height: 20)
    }

    // brush panel ------------------------------------------------------------------------

    private func applyStyle() {
        canvas.style = brushStyle
        canvas.eraserStyle = eraserStyle
        if let d = try? JSONEncoder().encode(brushStyle) { UserDefaults.standard.set(d, forKey: "draw.style") }
        if let d = try? JSONEncoder().encode(eraserStyle) { UserDefaults.standard.set(d, forKey: "draw.estyle") }
    }

    private let styleNames = ["Radius blur", "Spacing", "Scatter", "Grain", "Size jitter", "Pressure size",
                              "Pressure opacity", "Tip start", "Tip end"]

    private func styleValue(_ i: Int) -> Float {
        let st = curStyle
        switch i {
        case 0: return Float(st.hardness)
        case 1: return Float(min(1, max(0, (st.spacing - 0.03) / 0.6)))
        case 2: return Float(st.scatter)
        case 3: return Float(st.grain)
        case 4: return Float(st.sizeJitter)
        case 5: return Float(st.pressureSize)
        case 6: return Float(st.pressureOpacity)
        case 7: return Float(st.tipStart)
        default: return Float(st.tipEnd)
        }
    }

    private func setStyleValue(_ i: Int, _ v: Float) {
        let c = CGFloat(v)
        switch i {
        case 0: curStyle.hardness = c
        case 1: curStyle.spacing = 0.03 + c * 0.6
        case 2: curStyle.scatter = c
        case 3: curStyle.grain = c
        case 4: curStyle.sizeJitter = c
        case 5: curStyle.pressureSize = c
        case 6: curStyle.pressureOpacity = c
        case 7: curStyle.tipStart = c
        default: curStyle.tipEnd = c
        }
        curStyle.name = "Custom"
        applyStyle()
        if i == 0 { blurRow.set(v) }
    }

    private func buildBrushPanel(_ p: UIView) {
        for (i, ps) in curPresets.enumerated() {
            let b = DrawBtn(title: ps.name) { [weak self] in
                guard let s = self else { return }
                s.curStyle = ps; s.applyStyle(); s.blurRow.set(Float(ps.hardness)); s.closePanel(); s.togglePanel(4)
            }
            b.tag = 400 + i
            b.active = ps.name == curStyle.name
            b.layer.cornerRadius = 10; b.backgroundColor = argbToUIColor(C.CARD2)
            p.addSubview(b)
        }
        let sq = DrawBtn(title: curStyle.square ? "Tip: Square  (tap for Round)" : "Tip: Round  (tap for Square)") { [weak self] in
            guard let s = self else { return }
            s.curStyle.square.toggle(); s.curStyle.name = "Custom"; s.applyStyle(); s.closePanel(); s.togglePanel(4)
        }
        sq.tag = 420
        sq.layer.cornerRadius = 10; sq.backgroundColor = argbToUIColor(C.CARD2)
        p.addSubview(sq)
        for (i, n) in styleNames.enumerated() {
            let l = UILabel(); l.text = n; l.tag = 430 + i
            l.font = .systemFont(ofSize: 12, weight: .semibold); l.textColor = argbToUIColor(C.TEXT)
            p.addSubview(l)
            let r = DrawSliderRow(); r.tag = 440 + i
            r.set(styleValue(i))
            r.onChange = { [weak self] v in self?.setStyleValue(i, v) }
            p.addSubview(r)
        }
    }

    private func layoutBrushPanel(_ p: UIView) {
        let w = p.bounds.width
        let n = curPresets.count
        let perRow = 4
        let cw = (w - 16) / CGFloat(perRow)
        for i in 0..<n {
            p.viewWithTag(400 + i)?.frame = CGRect(x: 8 + CGFloat(i % perRow) * cw + 2, y: 8 + CGFloat(i / perRow) * 40, width: cw - 4, height: 36)
        }
        let rows = (n + perRow - 1) / perRow
        let y0 = 8 + CGFloat(rows) * 40 + 2
        p.viewWithTag(420)?.frame = CGRect(x: 10, y: y0, width: w - 20, height: 32)
        for i in 0..<styleNames.count {
            let y = y0 + 38 + CGFloat(i) * 34
            p.viewWithTag(430 + i)?.frame = CGRect(x: 12, y: y, width: 92, height: 34)
            p.viewWithTag(440 + i)?.frame = CGRect(x: 100, y: y, width: w - 108, height: 34)
        }
    }

    // selection panel ---------------------------------------------------------------------

    private func selBtn(_ p: UIView, _ tag: Int, _ title: String, _ act: @escaping () -> Void) {
        let b = DrawBtn(title: title) { act() }
        b.tag = tag; b.layer.cornerRadius = 10; b.backgroundColor = argbToUIColor(C.CARD2)
        p.addSubview(b)
    }

    private func buildSelPanel(_ p: UIView) {
        let t = UILabel(); t.tag = 500; t.font = .boldSystemFont(ofSize: 16); t.textColor = argbToUIColor(C.TEXT); p.addSubview(t)
        let hint = UILabel(); hint.tag = 501; hint.numberOfLines = 0
        hint.font = .systemFont(ofSize: 11); hint.textColor = argbToUIColor(C.DIM)
        hint.text = "On the Selection Layer: Brush paints blue selection, Eraser removes it, Wand adds to it. On any other layer, painting only affects the selected area."
        p.addSubview(hint)
        selBtn(p, 510, "") { [weak self] in
            guard let s = self else { return }
            s.setSelectionMode(!s.canvas.selectionMode); s.updateSelPanel()
        }
        selBtn(p, 511, "Magic Wand") { [weak self] in self?.closePanel(); self?.setTool(.wand) }
        selBtn(p, 512, "Invert Selection") { [weak self] in self?.canvas.invertSelection() }
        selBtn(p, 513, "Remove Selection") { [weak self] in self?.canvas.removeSelection() }
        selBtn(p, 514, "Clear Layer") { [weak self] in self?.canvas.clearLayer() }
        selBtn(p, 515, "Select Opacity") { [weak self] in self?.canvas.selectOpacity() }
        selBtn(p, 518, "Cut") { [weak self] in self?.clipAction(cut: true) }
        selBtn(p, 519, "Copy") { [weak self] in self?.clipAction(cut: false) }
        selBtn(p, 522, "Paste") { [weak self] in self?.pasteAction() }
        selBtn(p, 516, "") { [weak self] in
            guard let s = self else { return }
            s.canvas.wandContiguous.toggle(); s.updateSelPanel()
        }
        selBtn(p, 517, "") { [weak self] in
            guard let s = self else { return }
            s.canvas.wandSubtract.toggle(); s.updateSelPanel()
        }
        let tl = UILabel(); tl.tag = 520; tl.text = "Wand tolerance"
        tl.font = .systemFont(ofSize: 12, weight: .semibold); tl.textColor = argbToUIColor(C.TEXT); p.addSubview(tl)
        let r = DrawSliderRow(); r.tag = 521
        r.format = { String(Int($0 * 128)) }
        r.set(Float(canvas.wandTolerance) / 128)
        r.onChange = { [weak self] v in self?.canvas.wandTolerance = Int(v * 128) }
        p.addSubview(r)
        updateSelPanel()
    }

    private func clipAction(cut: Bool) {
        if canvas.copySelection(cut: cut) { Toast.show(cut ? "Cut" : "Copied") }
    }

    private func pasteAction() {
        guard DrawingCanvasView.clipboard != nil else { Toast.show("Nothing to paste"); return }
        let l = doc.addLayer(name: "Pasted")
        canvas.paste(into: l)
        reloadRows(); afterEdit()
    }

    private func updateSelPanel() {
        guard let p = panel, panelKind == 5 else { return }
        (p.viewWithTag(500) as? UILabel)?.text = "Selection Layer: " + (doc.selHas ? "Existing" : "No Selection")
        (p.viewWithTag(510) as? DrawBtn)?.title = canvas.selectionMode ? "Editing Selection Layer (tap to leave)" : "Edit Selection Layer (blue paint)"
        (p.viewWithTag(510) as? DrawBtn)?.active = canvas.selectionMode
        (p.viewWithTag(516) as? DrawBtn)?.title = canvas.wandContiguous ? "Wand: Same area only" : "Wand: Whole layer (Color Range)"
        (p.viewWithTag(517) as? DrawBtn)?.title = canvas.wandSubtract ? "Wand mode: Subtract" : "Wand mode: Add"
    }

    private func layoutSelPanel(_ p: UIView) {
        let w = p.bounds.width, half = (w - 30) / 2
        p.viewWithTag(500)?.frame = CGRect(x: 14, y: 10, width: w - 28, height: 24)
        p.viewWithTag(501)?.frame = CGRect(x: 14, y: 36, width: w - 28, height: 48)
        p.viewWithTag(510)?.frame = CGRect(x: 10, y: 90, width: w - 20, height: 40)
        p.viewWithTag(511)?.frame = CGRect(x: 10, y: 136, width: w - 20, height: 40)
        let grid: [(Int, Int, Int)] = [(512, 0, 0), (513, 1, 0), (514, 0, 1), (515, 1, 1)]
        for (tag, c, r) in grid {
            p.viewWithTag(tag)?.frame = CGRect(x: 10 + CGFloat(c) * (half + 10), y: 182 + CGFloat(r) * 46, width: half, height: 40)
        }
        let third = (w - 40) / 3
        for (i, tag) in [518, 519, 522].enumerated() {
            p.viewWithTag(tag)?.frame = CGRect(x: 10 + CGFloat(i) * (third + 10), y: 274, width: third, height: 40)
        }
        p.viewWithTag(516)?.frame = CGRect(x: 10, y: 320, width: w - 20, height: 36)
        p.viewWithTag(517)?.frame = CGRect(x: 10, y: 360, width: w - 20, height: 36)
        p.viewWithTag(520)?.frame = CGRect(x: 12, y: 402, width: 90, height: 34)
        p.viewWithTag(521)?.frame = CGRect(x: 100, y: 402, width: w - 108, height: 34)
    }

    // color ------------------------------------------------------------------------------

    private let colorPicker = ColorPickerView()
    private func buildColorPanel(_ p: UIView) {
        colorPicker.setColor(curColor)
        colorPicker.onChange = { [weak self] c in self?.setColor(c, remember: false) }
        p.addSubview(colorPicker)
        let recent = (UserDefaults.standard.array(forKey: "draw.recent") as? [Int]) ?? []
        for (i, c) in recent.enumerated() {
            let sw = TapView()
            sw.tag = 200 + i
            sw.backgroundColor = argbToUIColor(Int32(truncatingIfNeeded: c))
            sw.layer.cornerRadius = 8; sw.layer.borderWidth = 1; sw.layer.borderColor = UIColor(white: 1, alpha: 0.3).cgColor
            sw.onClick = { [weak self] in
                self?.setColor(Int32(truncatingIfNeeded: c), remember: false)
                self?.colorPicker.setColor(Int32(truncatingIfNeeded: c))
            }
            p.addSubview(sw)
        }
        let done = DrawBtn(title: "Save color") { [weak self] in
            guard let s = self else { return }
            s.setColor(s.curColor, remember: true)
            s.closePanel()
        }
        done.tint = C.GREEN; done.tag = 190
        p.addSubview(done)
    }
    private func layoutColorPanel(_ p: UIView) {
        colorPicker.frame = CGRect(x: 14, y: 14, width: p.bounds.width - 28, height: 250)
        let n = (UserDefaults.standard.array(forKey: "draw.recent") as? [Int])?.count ?? 0
        let size: CGFloat = 30, gap: CGFloat = 8
        for i in 0..<n {
            p.viewWithTag(200 + i)?.frame = CGRect(x: 14 + CGFloat(i) * (size + gap), y: 278, width: size, height: size)
        }
        p.viewWithTag(190)?.frame = CGRect(x: p.bounds.width - 130, y: p.bounds.height - 48, width: 120, height: 40)
    }

    // layers -----------------------------------------------------------------------------

    private func buildLayersPanel(_ p: UIView) {
        let hdr = UILabel(); hdr.text = "Layer"; hdr.tag = 300
        hdr.font = .boldSystemFont(ofSize: 17); hdr.textColor = argbToUIColor(C.TEXT)
        p.addSubview(hdr)
        let t = UITableView(frame: .zero, style: .plain)
        t.backgroundColor = .clear; t.separatorStyle = .none
        t.dataSource = self; t.delegate = self
        t.dragDelegate = self; t.dropDelegate = self; t.dragInteractionEnabled = true
        t.register(LayerCell.self, forCellReuseIdentifier: "c")
        t.rowHeight = 58
        p.addSubview(t); table = t

        let acts: [(String, String, () -> Void)] = [
            ("plus", "Layer", { [weak self] in self?.plusMenu() }),
            ("folder", "Folder", { [weak self] in self?.addLayer(folder: true) }),
            ("dup", "Copy", { [weak self] in self?.dupLayer() }),
            ("chev_up", "Up", { [weak self] in self?.moveLayer(1) }),
            ("chev_down", "Down", { [weak self] in self?.moveLayer(-1) }),
            ("trash", "Delete", { [weak self] in self?.deleteLayer() }),
        ]
        for (i, a) in acts.enumerated() {
            let b = DrawBtn(icon: a.0, title: a.1, a.2); b.tag = 310 + i
            if a.1 == "Delete" { b.tint = C.RED }
            p.addSubview(b)
        }
        let op = UISlider()
        op.minimumTrackTintColor = argbToUIColor(C.GREEN); op.thumbTintColor = .white
        op.addTarget(self, action: #selector(layerOpChanged(_:)), for: .valueChanged)
        op.tag = 330; p.addSubview(op); layerOpSlider = op
        let ol = UILabel(); ol.font = .monospacedDigitSystemFont(ofSize: 13, weight: .semibold)
        ol.textColor = argbToUIColor(C.TEXT); ol.tag = 331; p.addSubview(ol); layerOpLabel = ol
        let bg = UILabel(); bg.text = "Background"; bg.font = .systemFont(ofSize: 12, weight: .semibold)
        bg.textColor = argbToUIColor(C.DIM); bg.tag = 340; p.addSubview(bg)
        for (i, white) in [true, false].enumerated() {
            let sw = TapView(); sw.tag = 341 + i
            sw.backgroundColor = white ? .white : argbToUIColor(C.CARD2)
            sw.layer.cornerRadius = 8; sw.layer.borderWidth = (doc.item.paperWhite == white) ? 3 : 1
            sw.layer.borderColor = argbToUIColor(doc.item.paperWhite == white ? C.GREEN : C.LINE).cgColor
            sw.onClick = { [weak self] in
                guard let s = self else { return }
                s.doc.item.paperWhite = white
                s.canvas.invalidateCaches(); s.closePanel(); s.togglePanel(3)
            }
            if !white {
                let l = UILabel(); l.text = "▦"; l.textAlignment = .center; l.textColor = argbToUIColor(C.DIM)
                l.frame = CGRect(x: 0, y: 0, width: 44, height: 30); sw.addSubview(l)
            }
            p.addSubview(sw)
        }
        let sr = TapView(); sr.tag = 350
        sr.layer.cornerRadius = 10
        sr.onClick = { [weak self] in
            guard let s = self else { return }
            s.setSelectionMode(!s.canvas.selectionMode)
        }
        let sw = IconView("select", Int32(bitPattern: 0xFF3366FF), 30); sw.tag = 351; sw.isUserInteractionEnabled = false
        let sn = UILabel(); sn.tag = 352; sn.text = "Selection Layer"
        sn.font = .systemFont(ofSize: 15, weight: .semibold); sn.textColor = argbToUIColor(C.TEXT)
        let si = UILabel(); si.tag = 353; si.font = .systemFont(ofSize: 12); si.textColor = argbToUIColor(C.DIM)
        for v in [sw, sn, si] { sr.addSubview(v) }
        p.addSubview(sr)
        selBtn(p, 354, "Invert") { [weak self] in self?.canvas.invertSelection() }
        selBtn(p, 355, "Clear") { [weak self] in self?.canvas.removeSelection() }
        updateSelRow()
        reloadRows()
    }

    private func updateSelRow() {
        guard let p = panel, let sr = p.viewWithTag(350) else { return }
        sr.backgroundColor = canvas.selectionMode ? UIColor(red: 0.2, green: 0.4, blue: 1, alpha: 0.28) : argbToUIColor(C.CARD2)
        (sr.viewWithTag(353) as? UILabel)?.text = (doc.selHas ? "Existing" : "No Selection") + (canvas.selectionMode ? " · editing" : " · tap to edit")
    }

    private func layoutLayerPanel(_ p: UIView) {
        let w = p.bounds.width, h = p.bounds.height
        p.viewWithTag(300)?.frame = CGRect(x: 16, y: 10, width: 120, height: 28)
        let footer: CGFloat = 54 + 44 + 44
        p.viewWithTag(350)?.frame = CGRect(x: 8, y: 40, width: w - 16, height: 52)
        p.viewWithTag(351)?.frame = CGRect(x: 8, y: 8, width: 36, height: 36)
        p.viewWithTag(352)?.frame = CGRect(x: 54, y: 5, width: w - 190, height: 22)
        p.viewWithTag(353)?.frame = CGRect(x: 54, y: 27, width: w - 190, height: 18)
        p.viewWithTag(354)?.frame = CGRect(x: w - 130, y: 46, width: 56, height: 40)
        p.viewWithTag(355)?.frame = CGRect(x: w - 70, y: 46, width: 56, height: 40)
        table?.frame = CGRect(x: 6, y: 98, width: w - 12, height: h - 98 - footer)
        let bw = (w - 12) / 6
        for i in 0..<6 { p.viewWithTag(310 + i)?.frame = CGRect(x: 6 + CGFloat(i) * bw, y: h - footer + 2, width: bw, height: 50) }
        p.viewWithTag(330)?.frame = CGRect(x: 16, y: h - footer + 56, width: w - 90, height: 30)
        p.viewWithTag(331)?.frame = CGRect(x: w - 66, y: h - footer + 56, width: 56, height: 30)
        p.viewWithTag(340)?.frame = CGRect(x: 16, y: h - 42, width: 100, height: 30)
        p.viewWithTag(341)?.frame = CGRect(x: 120, y: h - 42, width: 44, height: 30)
        p.viewWithTag(342)?.frame = CGRect(x: 172, y: h - 42, width: 44, height: 30)
    }

    private func reloadRows() {
        rows.removeAll()
        func add(_ parent: String?, _ depth: Int) {
            for l in doc.layers.reversed() where l.meta.parent == parent {
                rows.append((l, depth))
                if l.meta.isFolder && l.meta.expanded { add(l.meta.id, depth + 1) }
            }
        }
        add(nil, 0)
        // orphans (parent folder missing) show at the root
        for l in doc.layers.reversed() where l.meta.parent != nil && doc.layer(l.meta.parent!) == nil && !rows.contains(where: { $0.0 === l }) {
            rows.append((l, 0))
        }
        table?.reloadData()
        syncLayerOpacity()
    }

    private func syncLayerOpacity() {
        let l = doc.layers.first { $0.meta.id == doc.activeId }
        layerOpSlider?.value = l?.meta.opacity ?? 1
        layerOpLabel?.text = "\(Int((l?.meta.opacity ?? 1) * 100))%"
    }

    @objc private func layerOpChanged(_ s: UISlider) {
        guard let l = doc.layers.first(where: { $0.meta.id == doc.activeId }) else { return }
        l.meta.opacity = s.value
        layerOpLabel?.text = "\(Int(s.value * 100))%"
        canvas.invalidateCaches()
        table?.reloadData()
    }

    func tableView(_ t: UITableView, numberOfRowsInSection s: Int) -> Int { rows.count }

    func tableView(_ t: UITableView, cellForRowAt ip: IndexPath) -> UITableViewCell {
        let cell = t.dequeueReusableCell(withIdentifier: "c", for: ip) as! LayerCell
        let (l, depth) = rows[ip.row]
        cell.indent = CGFloat(depth) * 18
        cell.name.text = l.meta.name
        let pct = Int(l.meta.opacity * 100)
        cell.info.text = l.meta.isFolder ? "Folder · \(doc.layers.filter { $0.meta.parent == l.meta.id }.count) items" : "\(pct)% · Normal"
        cell.eye.icon = l.meta.visible ? "eye" : "eye_off"
        cell.eye.tint = l.meta.visible ? C.TEXT : C.DIM
        cell.eye.onClick = { [weak self] in
            l.meta.visible.toggle(); self?.canvas.invalidateCaches(); self?.reloadRows()
        }
        cell.chev.isHidden = !l.meta.isFolder
        cell.chev.icon = l.meta.expanded ? "chev_down" : "chev_up"
        cell.chev.onClick = { [weak self] in l.meta.expanded.toggle(); self?.reloadRows() }
        if l.meta.isFolder {
            cell.thumb.image = Icons.image("folder", size: 30, color: C.GREEN)
            cell.thumb.contentMode = .center
            cell.thumb.backgroundColor = argbToUIColor(C.GREEN).withAlphaComponent(0.18)
        }
        else { cell.thumb.contentMode = .scaleAspectFit; cell.thumb.backgroundColor = argbToUIColor(C.CARD2); cell.thumb.image = thumb(l) }
        cell.backgroundColor = (l.meta.id == doc.activeId && !canvas.selectionMode) ? argbToUIColor(C.GREEN).withAlphaComponent(0.18) : .clear
        cell.setNeedsLayout()
        return cell
    }

    func tableView(_ t: UITableView, didSelectRowAt ip: IndexPath) {
        let l = rows[ip.row].0
        if canvas.selectionMode { setSelectionMode(false); doc.activeId = l.meta.id; canvas.invalidateCaches(); reloadRows(); return }
        if doc.activeId == l.meta.id { layerMenu(l); return }   // tap the selected layer again for its menu
        doc.activeId = l.meta.id
        canvas.invalidateCaches()
        reloadRows()
    }

    // drag to reorder / drop onto a folder ------------------------------------------------

    func tableView(_ t: UITableView, itemsForBeginning session: UIDragSession, at ip: IndexPath) -> [UIDragItem] {
        guard ip.row < rows.count else { return [] }
        let l = rows[ip.row].0
        let item = UIDragItem(itemProvider: NSItemProvider(object: l.meta.id as NSString))
        item.localObject = l
        return [item]
    }

    func tableView(_ t: UITableView, canHandle session: UIDropSession) -> Bool { session.localDragSession != nil }

    func tableView(_ t: UITableView, dropSessionDidUpdate session: UIDropSession,
                   withDestinationIndexPath dip: IndexPath?) -> UITableViewDropProposal {
        dropInto = false
        guard session.localDragSession != nil else { return UITableViewDropProposal(operation: .cancel) }
        if let dip = dip, dip.row < rows.count, rows[dip.row].0.meta.isFolder {
            let r = t.rectForRow(at: dip), y = session.location(in: t).y
            if y > r.minY + r.height * 0.25 && y < r.maxY - r.height * 0.25 {
                dropInto = true
                return UITableViewDropProposal(operation: .move, intent: .insertIntoDestinationIndexPath)
            }
        }
        return UITableViewDropProposal(operation: .move, intent: .insertAtDestinationIndexPath)
    }

    func tableView(_ t: UITableView, performDropWith coordinator: UITableViewDropCoordinator) {
        guard let item = coordinator.items.first, let l = item.dragItem.localObject as? PixLayer else { return }
        let row = coordinator.destinationIndexPath?.row ?? rows.count
        if dropInto, row < rows.count {
            let f = rows[row].0
            if f === l || doc.parentChain(f).contains(where: { $0 === l }) { Toast.show("Can't move a folder into itself"); return }
            let kids = doc.layers.filter { $0.meta.parent == f.meta.id && $0 !== l }
            place(l, parent: f.meta.id, above: kids.last ?? f)
            f.meta.expanded = true
        } else if row < rows.count {
            let ref = rows[row].0
            if ref === l { return }
            if doc.parentChain(ref).contains(where: { $0 === l }) { Toast.show("Can't move a folder into itself"); return }
            place(l, parent: ref.meta.parent, above: ref)
        } else {
            place(l, parent: nil, above: nil)
        }
        canvas.invalidateCaches(); reloadRows(); afterEdit()
        if let n = rows.firstIndex(where: { $0.0 === l }) {
            coordinator.drop(item.dragItem, toRowAt: IndexPath(row: n, section: 0))
        }
    }

    /// Puts `l` in `parent`, directly above `ref` in the stack (bottom of the stack when nil).
    private func place(_ l: PixLayer, parent: String?, above ref: PixLayer?) {
        doc.layers.removeAll { $0 === l }
        l.meta.parent = parent
        if let r = ref, let i = doc.layers.firstIndex(where: { $0 === r }) { doc.layers.insert(l, at: i + 1) }
        else { doc.layers.insert(l, at: 0) }
    }

    private func thumb(_ l: PixLayer) -> UIImage? {
        if let t = thumbs[l.meta.id] { return t }
        guard let cg = l.liveImage() else { return nil }
        let s: CGFloat = 96
        let k = min(s / CGFloat(l.w), s / CGFloat(l.h))
        let sz = CGSize(width: max(1, CGFloat(l.w) * k), height: max(1, CGFloat(l.h) * k))
        let img = UIGraphicsImageRenderer(size: sz).image { _ in
            Checker.fill(CGRect(origin: .zero, size: sz), cell: 8)
            UIImage(cgImage: cg).draw(in: CGRect(origin: .zero, size: sz))
        }
        thumbs[l.meta.id] = img
        doc.trim(keep: nil)
        return img
    }

    @objc private func rowLong(_ g: UILongPressGestureRecognizer) {
        guard g.state == .began, let t = table, let ip = t.indexPathForRow(at: g.location(in: t)) else { return }
        layerMenu(rows[ip.row].0)
    }

    private func layerMenu(_ l: PixLayer) {
        doc.activeId = l.meta.id; canvas.invalidateCaches()
        let sheet = UIAlertController(title: l.meta.name, message: nil, preferredStyle: .actionSheet)
        sheet.addAction(UIAlertAction(title: "Rename", style: .default) { [weak self] _ in
            self?.prompt("Rename", l.meta.name) { l.meta.name = $0; self?.reloadRows(); self?.afterEdit() }
        })
        if !l.meta.isFolder {
            sheet.addAction(UIAlertAction(title: "Duplicate", style: .default) { [weak self] _ in self?.dupLayer() })
            sheet.addAction(UIAlertAction(title: "Merge down", style: .default) { [weak self] _ in
                guard let s = self else { return }
                if !s.doc.mergeDown(l) { Toast.show("Nothing below to merge into") }
                s.thumbs.removeAll(); s.canvas.invalidateCaches(); s.reloadRows(); s.afterEdit()
            })
            sheet.addAction(UIAlertAction(title: "Clear layer", style: .destructive) { [weak self] _ in
                // asks first and goes through the canvas so it can be undone (it used to wipe the layer for good)
                let ask = UIAlertController(title: "Clear “\(l.meta.name)”?", message: "Everything on this layer is erased. Undo brings it back.", preferredStyle: .alert)
                ask.addAction(UIAlertAction(title: "Cancel", style: .cancel))
                ask.addAction(UIAlertAction(title: "Clear", style: .destructive) { [weak self] _ in
                    guard let s = self else { return }
                    s.doc.activeId = l.meta.id
                    s.canvas.clearLayer()
                    s.thumbs[l.meta.id] = nil; s.canvas.invalidateCaches(); s.reloadRows()
                })
                self?.present(ask, animated: true)
            })
        }
        for f in doc.layers where f.meta.isFolder && f !== l && f.meta.id != l.meta.parent {
            sheet.addAction(UIAlertAction(title: "Move into “\(f.meta.name)”", style: .default) { [weak self] _ in
                l.meta.parent = f.meta.id; f.meta.expanded = true; self?.reloadRows()
            })
        }
        if l.meta.parent != nil {
            sheet.addAction(UIAlertAction(title: "Move out of folder", style: .default) { [weak self] _ in
                l.meta.parent = nil; self?.reloadRows()
            })
        }
        sheet.addAction(UIAlertAction(title: "Delete", style: .destructive) { [weak self] _ in self?.deleteLayer() })
        sheet.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(sheet, anchor: table ?? view)
    }

    private func addLayer(folder: Bool) {
        doc.addLayer(folder: folder)
        canvas.invalidateCaches(); reloadRows(); afterEdit()
    }
    private func dupLayer() {
        guard let l = doc.active else { return }
        doc.duplicate(l); canvas.invalidateCaches(); reloadRows(); afterEdit()
    }
    private func moveLayer(_ d: Int) {
        guard let l = doc.layers.first(where: { $0.meta.id == doc.activeId }) else { return }
        doc.move(l, by: d); canvas.invalidateCaches(); reloadRows()
    }
    private func deleteLayer() {
        guard let l = doc.layers.first(where: { $0.meta.id == doc.activeId }) else { return }
        if !l.meta.isFolder && doc.pixelLayerCount <= 1 {
            Toast.show("Can't delete the only layer — use “Clear layer” instead"); return
        }
        let a = UIAlertController(title: "Delete “\(l.meta.name)”?", message: l.meta.isFolder ? "The layers inside are kept and moved out." : nil, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        a.addAction(UIAlertAction(title: "Delete", style: .destructive) { [weak self] _ in
            guard let s = self else { return }
            s.doc.remove(l); s.thumbs.removeAll(); s.canvas.invalidateCaches(); s.reloadRows(); s.afterEdit()
        })
        present(a, animated: true)
    }

    // MARK: menus / actions

    private func prompt(_ title: String, _ text: String, _ done: @escaping (String) -> Void) {
        let a = UIAlertController(title: title, message: nil, preferredStyle: .alert)
        a.addTextField { $0.text = text; $0.clearButtonMode = .whileEditing; $0.autocapitalizationType = .sentences }
        a.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in
            let t = a.textFields?.first?.text?.trimmingCharacters(in: .whitespaces) ?? ""
            if !t.isEmpty { done(t) }
        })
        present(a, animated: true)
    }

    private func present(_ a: UIAlertController, anchor: UIView) {
        if let pc = a.popoverPresentationController { pc.sourceView = anchor; pc.sourceRect = anchor.bounds }
        present(a, animated: true)
    }

    private func renameArt() { prompt("Rename artwork", doc.item.name) { [weak self] in self?.doc.item.name = $0; self?.afterEdit() } }

    private func moreMenu() {
        let s = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        s.addAction(UIAlertAction(title: "Rename", style: .default) { [weak self] _ in self?.renameArt() })
        s.addAction(UIAlertAction(title: "Import picture as layer", style: .default) { [weak self] _ in self?.pickPicture() })
        s.addAction(UIAlertAction(title: "Save to Photos", style: .default) { [weak self] _ in self?.saveToPhotos() })
        s.addAction(UIAlertAction(title: "Export PNG", style: .default) { [weak self] _ in self?.exportPNG() })
        s.addAction(UIAlertAction(title: "Export PSD (layers)", style: .default) { [weak self] _ in self?.exportPSD() })
        s.addAction(UIAlertAction(title: "Save as .saikidrawing", style: .default) { [weak self] _ in self?.exportDrawingFile() })
        if onApply == nil {
            s.addAction(UIAlertAction(title: "Send to video editor", style: .default) { [weak self] _ in self?.sendToEditor() })
        }
        s.addAction(UIAlertAction(title: "Save", style: .default) { [weak self] _ in self?.saveNow(); Toast.show("Saved") })
        s.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(s, anchor: moreBtn)
    }

    private func plusMenu() {
        let s = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        s.addAction(UIAlertAction(title: "New layer", style: .default) { [weak self] _ in self?.addLayer(folder: false) })
        s.addAction(UIAlertAction(title: "Import image from Photos", style: .default) { [weak self] _ in self?.pickPicture() })
        s.addAction(UIAlertAction(title: "Import image from Files", style: .default) { [weak self] _ in self?.pickFile() })
        s.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(s, anchor: (panel?.viewWithTag(310)) ?? view)
    }

    private func pickPicture() {
        var cfg = PHPickerConfiguration(); cfg.filter = .images; cfg.selectionLimit = 1
        let p = PHPickerViewController(configuration: cfg); p.delegate = self
        present(p, animated: true)
    }

    private func pickFile() {
        let p = UIDocumentPickerViewController(forOpeningContentTypes: [.image], asCopy: true)
        p.delegate = self
        present(p, animated: true)
    }

    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let u = urls.first, let img = UIImage(contentsOfFile: u.path) else { Toast.show("Couldn't read that image"); return }
        importImage(img)
    }

    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        picker.dismiss(animated: true)
        guard let prov = results.first?.itemProvider, prov.canLoadObject(ofClass: UIImage.self) else { return }
        prov.loadObject(ofClass: UIImage.self) { [weak self] obj, _ in
            guard let img = obj as? UIImage else { return }
            DispatchQueue.main.async { self?.importImage(img) }
        }
    }

    /// Puts a picture on a new layer, fitted and centred (EXIF orientation applied).
    private func importImage(_ img: UIImage) {
        let fixed = UIGraphicsImageRenderer(size: img.size, format: { let f = UIGraphicsImageRendererFormat(); f.scale = 1; return f }())
            .image { _ in img.draw(at: .zero) }
        guard let cg = fixed.cgImage else { return }
        let l = doc.addLayer(name: "Picture")
        if let c = l.ctx {
            let k = min(CGFloat(doc.w) / CGFloat(cg.width), CGFloat(doc.h) / CGFloat(cg.height))
            let sw = CGFloat(cg.width) * k, sh = CGFloat(cg.height) * k
            c.interpolationQuality = .high
            c.draw(cg, in: CGRect(x: (CGFloat(doc.w) - sw) / 2, y: (CGFloat(doc.h) - sh) / 2, width: sw, height: sh))
        }
        l.dirty = true
        thumbs.removeAll()
        canvas.invalidateCaches(); afterEdit()
        if panelKind == 3 { reloadRows() }
    }

    // MARK: save to Photos / PSD

    private func saveToPhotos() {
        guard let cg = doc.flatten(withPaper: true), let data = UIImage(cgImage: cg).pngData() else { Toast.show("Nothing to save"); return }
        PHPhotoLibrary.requestAuthorization(for: .addOnly) { st in
            DispatchQueue.main.async {
                guard st == .authorized || st == .limited else { Toast.show("Allow Photos access in Settings to save"); return }
                PHPhotoLibrary.shared().performChanges({
                    PHAssetCreationRequest.forAsset().addResource(with: .photo, data: data, options: nil)
                }) { ok, _ in DispatchQueue.main.async { Toast.show(ok ? "Saved to Photos" : "Couldn't save to Photos") } }
            }
        }
    }

    private func exportPSD() {
        saveNow()
        Toast.show("Building PSD…")
        let w = doc.w, h = doc.h
        // snapshot the pixels on the main thread (layers are not thread-safe), encode off it
        struct Snap { var name: String; var px: [UInt8]; var visible: Bool; var alpha: CGFloat; var group: String }
        var snaps: [Snap] = []
        for l in doc.layers where !l.meta.isFolder {
            let px = Array(UnsafeBufferPointer(start: l.buf, count: w * h * 4))
            let grp = doc.parentChain(l).first?.meta.name ?? ""
            snaps.append(Snap(name: l.meta.name, px: px, visible: doc.shown(l), alpha: doc.alpha(l), group: grp))
        }
        let paper = doc.item.paperWhite
        let name = doc.item.name
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            var out: [DecomposedLayer] = []
            for (i, sn) in snaps.enumerated() {
                var minX = w, minY = h, maxX = -1, maxY = -1
                sn.px.withUnsafeBufferPointer { b in
                    for y in 0..<h { for x in 0..<w where b[(y * w + x) * 4 + 3] != 0 {
                        if x < minX { minX = x }; if x > maxX { maxX = x }
                        if y < minY { minY = y }; if y > maxY { maxY = y }
                    } }
                }
                var bx = 0, by = 0, bw = 1, bh = 1
                var rgba = [UInt8](repeating: 0, count: 4)
                if maxX >= minX {
                    bx = minX; by = minY; bw = maxX - minX + 1; bh = maxY - minY + 1
                    rgba = [UInt8](repeating: 0, count: bw * bh * 4)
                    for y in 0..<bh { for x in 0..<bw {
                        let o = ((by + y) * w + bx + x) * 4, d = (y * bw + x) * 4
                        let a = Int(sn.px[o + 3])
                        if a == 0 { continue }
                        rgba[d] = UInt8(min(255, Int(sn.px[o]) * 255 / a))          // un-premultiply
                        rgba[d + 1] = UInt8(min(255, Int(sn.px[o + 1]) * 255 / a))
                        rgba[d + 2] = UInt8(min(255, Int(sn.px[o + 2]) * 255 / a))
                        rgba[d + 3] = UInt8(max(0, min(255, Int((CGFloat(a) * sn.alpha).rounded()))))
                    } }
                }
                out.append(DecomposedLayer(name: sn.name, x: bx, y: by, w: bw, h: bh, rgba: rgba,
                                           visible: sn.visible, area: bw * bh, group: sn.group, order: i))
            }
            if paper {
                let white = [UInt8](repeating: 255, count: w * h * 4)
                out.insert(DecomposedLayer(name: "Paper", x: 0, y: 0, w: w, h: h, rgba: white, visible: true,
                                           area: w * h, group: "", order: -1), at: 0)
            }
            let comp = AnimeDecomposer.composite(out, width: w, height: h)
            let data = PSDWriter.write(width: w, height: h, layers: out, composite: comp)
            let url = FileManager.default.temporaryDirectory.appendingPathComponent("\(name).psd")
            try? FileManager.default.removeItem(at: url)
            let ok = (try? data.write(to: url, options: .atomic)) != nil
            DispatchQueue.main.async {
                guard let self = self else { return }
                guard ok else { Toast.show("PSD export failed"); return }
                let a = UIActivityViewController(activityItems: [url], applicationActivities: nil)
                a.popoverPresentationController?.sourceView = self.moreBtn
                self.present(a, animated: true)
            }
        }
    }

    private func exportDrawingFile() {
        saveNow()
        guard let url = DrawingArchive.export(doc.item.id) else { Toast.show("Export failed"); return }
        let a = UIActivityViewController(activityItems: [url], applicationActivities: nil)
        a.popoverPresentationController?.sourceView = moreBtn
        present(a, animated: true)
    }

    private func exportPNG() {
        guard let cg = doc.flatten(withPaper: true), let data = UIImage(cgImage: cg).pngData() else { return }
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("\(doc.item.name).png")
        try? data.write(to: url, options: .atomic)
        let a = UIActivityViewController(activityItems: [url], applicationActivities: nil)
        a.popoverPresentationController?.sourceView = moreBtn
        present(a, animated: true)
    }

    // MARK: save / leave

    private func saveNow() { canvas.cancelTransform(); doc.save() }
    @objc private func saveQuiet() { if isViewLoaded { doc.save() } }

    private func goBack() {
        if onApply != nil {                       // direct mode: back = discard the temporary copy
            let id = doc.item.id
            navigationController?.popViewController(animated: true)
            DrawStore.delete(id)
            return
        }
        Toast.show("Saving…")
        DispatchQueue.main.async { [weak self] in
            self?.saveNow()
            self?.navigationController?.popViewController(animated: true)
        }
    }

    private func sendToEditor() {
        if let apply = onApply {
            canvas.cancelTransform()
            guard let cg = doc.flatten(withPaper: false) else { Toast.show("Could not render the drawing"); return }
            let id = doc.item.id
            navigationController?.popViewController(animated: true)
            apply(UIImage(cgImage: cg))
            DrawStore.delete(id)
            return
        }
        Toast.show("Creating project…")
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            self.saveNow()
            DrawExport.toProject(self.doc.item) { id in
                guard let id = id else { Toast.show("Export failed"); return }
                Toast.show("Project created")
                self.navigationController?.pushViewController(EditorViewController(projectId: id), animated: true)
            }
        }
    }
}

// MARK: - helpers --------------------------------------------------------------------------

func argbFrom(_ c: UIColor) -> Int32 {
    var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
    c.getRed(&r, green: &g, blue: &b, alpha: &a)
    return argbColor(255, Int((r * 255).rounded()), Int((g * 255).rounded()), Int((b * 255).rounded()))
}

/// Drawing → a new video-editor project (one full-canvas image layer per drawing layer,
/// folders become group layers).
enum DrawExport {
    static func toProject(_ item: DrawItem, done: @escaping (String?) -> Void) {
        DispatchQueue.global(qos: .userInitiated).async {
            let project = Project(name: item.name, w: item.w, h: item.h, fps: 30)
            let scene = project.scenes[0]
            var ok = true
            var groups: [String: Layer] = [:]
            var groupOrder: [String] = []
            func group(_ pid: String) -> Layer? {
                if let g = groups[pid] { return g }
                guard let fm = item.layers.first(where: { $0.id == pid }) else { return nil }
                let ng = Layer(project.nextId, fm.name, .GROUP)
                project.nextId += 1
                ng.end = scene.duration
                ng.visible = fm.visible
                ng.track("opacity").base = fm.opacity
                groups[pid] = ng; groupOrder.append(pid)
                if let pp = fm.parent, let pg = group(pp) { ng.parentId = pg.id }
                return ng
            }
            func addImage(_ png: Data, _ name: String, visible: Bool, parent: String?, opacity: Float = 1) {
                guard let path = ProjectIO.writeDataIntoSandbox(png, name: "\(scene.layers.count + 1)_\(name).png") else { ok = false; return }
                let l = Layer(project.nextId, name, .IMAGE)
                project.nextId += 1
                l.imagePath = path
                l.end = scene.duration
                l.visible = visible
                l.track("opacity").base = opacity
                if let pid = parent, let g = group(pid) { l.parentId = g.id }
                scene.layers.append(l)
            }
            if item.paperWhite {
                let r = UIGraphicsImageRenderer(size: CGSize(width: item.w, height: item.h),
                                                format: { let f = UIGraphicsImageRendererFormat(); f.scale = 1; f.opaque = true; return f }())
                let img = r.image { c in UIColor.white.setFill(); c.fill(CGRect(x: 0, y: 0, width: item.w, height: item.h)) }
                if let png = img.pngData() { addImage(png, "Paper", visible: true, parent: nil) }
            }
            for m in item.layers where !m.isFolder {
                guard let data = try? Data(contentsOf: DrawStore.layerURL(item.id, m.id)) else { continue }
                addImage(data, m.name, visible: m.visible, parent: m.parent, opacity: m.opacity)
                if !ok { break }
            }
            for pid in groupOrder { if let g = groups[pid] { scene.layers.append(g) } }
            DispatchQueue.main.async {
                guard ok else { done(nil); return }
                var saved = project
                Projects.save(&saved)
                done(saved.id)
            }
        }
    }
}
