// WelcomeViewController.swift — the launch "What's New" card.

import UIKit

// MARK: - What's New ---------------------------------------------------------------------

/// The original's launch card, rebuilt 1:1 from the shipped binary's
/// WelcomeViewController.viewDidLoad: black full-screen, scrollable stack
/// with the splash art at top, the kerned "SAIKI MOTION" wordmark, a big
/// "Welcome", the bordered disclaimer card (NOT A MOD / paragraph /
/// Developers / TikTok credits), the "What's New" changelog list and the
/// two-button row. Shown on every launch until "Don't show again".
final class WelcomeViewController: UIViewController {

    /// The changelog: this version's changes first, then the original's
    /// shipped UPDATES list (kept verbatim below the divider entry).
    static let UPDATES: [String] = [
        "FIX — Export: videos with Chroma Key (and any video layer) no longer export fully black; each frame is now decoded before it is drawn",
        "FIX — Graph editor: opens as a large panel over the lower part of the screen with the preview still visible above, bigger knobs, property chips on top",
        "FIX — Optical Flare: if the flare shader cannot run, the flare is now drawn by the Metal renderer instead of disappearing",
        "Saiki Motion is currently in BETA — expect rough edges, and please report anything that breaks",
        "This is the beginning of Saiki Motion. We are building it into a powerful editing app, and there is much more to come",
        "FIX — Audio: no more doubled audio when playback lags; a late-loading player can no longer play on top of another one",
        "FIX — Projects: a project can no longer be overwritten by, or turn into, another project when you switch between them",
        "FIX — Chroma Key / Luma Key: clean edges, and exports no longer come out black, stop early or skip the effect",
        "NEW — Volume: video layers now have a Volume slider too (keyframe it like any other value) and keyframed volume is heard in the export",
        "FIX — Groups: copying a layer out of a group now pastes it outside the group, and copying a group brings its contents",
        "FIX — Adjustment layers: Shake and Motion Tile now replace the picture below instead of showing a second copy",
        "FIX — Drawing editor: transparent pixels are now locked by default in Direct Drawing (Tools → Transparent pixels), so brush and smudge can no longer paint over or wipe out the transparent area of a cut-out picture; Clear layer now asks first and can be undone",
        "FIX — Parenting: the Parent button in Transform keeps the layer where it is and can no longer create loops; Parent Lock (movement) now freezes the whole parent chain",
        "NEW — Import: .ply and .spz files are now supported, with Gaussian splatting so you can bring splat scenes straight into your project",
        "NEW — Rig editor: a redesigned rig editor that makes building, selecting and adjusting bones and joints faster and clearer",
        "NEW — 3D scene UI: a cleaner, easier to use 3D scene interface with improved layout and controls",
        "NEW — Lighting: improved 3D lighting with ray tracing, now affecting PBR materials for more realistic shadows, reflections and highlights",
        "NEW — Rigging physics: rigs now react to basic transformations such as moving, rotating and scaling, so motion feels natural",
        "COMING SOON — The Android version of Saiki Motion will be developed in the next few days",
        "NEW — My Playground: project thumbnails, folders (create, rename, delete, move projects in and out) — all with our own icons, no emojis or system icons",
        "NEW — 3D editor: fixed the gizmo lagging behind when you move things, including the camera. The gizmo and the preview now update on the same frame",
        "NEW — Export screen: all settings sit above Cancel / Export — Quality, Frames per second (parameter slider + FPS presets), Bitrate, Include audio and Export project file",
        "NEW — Project settings: Duration removed; Aspect ratio and Background color are now at the top under Canvas",
    ]

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = argbToUIColor(Int32(bitPattern: 0xFF000000))
        isModalInPresentation = true

        // scroll + content stack (fills width, vertical, zero spacing)
        let scroll = UIScrollView()
        scroll.alwaysBounceVertical = true
        scroll.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scroll)

        let stack = UIStackView()
        stack.axis = .vertical
        stack.alignment = .fill
        stack.spacing = 0
        stack.isLayoutMarginsRelativeArrangement = true
        stack.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 28, leading: 22, bottom: 24, trailing: 22)
        stack.translatesAutoresizingMaskIntoConstraints = false
        scroll.addSubview(stack)
        NSLayoutConstraint.activate([
            scroll.topAnchor.constraint(equalTo: view.topAnchor),
            scroll.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            scroll.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scroll.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            stack.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor),
            stack.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor),
            stack.leadingAnchor.constraint(equalTo: scroll.contentLayoutGuide.leadingAnchor),
            stack.trailingAnchor.constraint(equalTo: scroll.contentLayoutGuide.trailingAnchor),
            stack.widthAnchor.constraint(equalTo: scroll.frameLayoutGuide.widthAnchor),
        ])

        // 1 - splash art (bundle image, file fallback — same as the original)
        let artImage = UIImage(named: "splash_chibi")
            ?? Bundle.main.url(forResource: "splash_chibi", withExtension: "png")
                .flatMap { UIImage(contentsOfFile: $0.path) }
        let art = UIImageView(image: artImage)
        art.contentMode = .scaleAspectFit
        stack.addArrangedSubview(art)
        art.heightAnchor.constraint(equalToConstant: 288).isActive = true

        // 2 - kerned wordmark
        let mark = UILabel()
        mark.attributedText = kerned("SAIKI MOTION", 14, C.GREEN, 0.3)
        mark.textAlignment = .center
        stack.addArrangedSubview(pad(mark, 14, 0, 0, 0))

        // 3 - Welcome
        let welcome = UILabel()
        welcome.text = "Welcome"
        welcome.textColor = argbToUIColor(Int32(bitPattern: 0xFFF2F2F2))
        welcome.font = .boldSystemFont(ofSize: 32)
        welcome.textAlignment = .center
        stack.addArrangedSubview(pad(welcome, 4, 0, 18, 0))

        // 4 - disclaimer card
        let card = UIView()
        card.backgroundColor = argbToUIColor(Int32(bitPattern: 0xFF1C2121))
        card.layer.cornerRadius = 20
        card.layer.borderWidth = 1
        card.layer.borderColor = argbToUIColor(Int32(bitPattern: 0xFF2A2A30)).cgColor
        let inner = UIStackView()
        inner.axis = .vertical
        inner.spacing = 0
        inner.isLayoutMarginsRelativeArrangement = true
        inner.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 16, leading: 18, bottom: 16, trailing: 18)
        inner.translatesAutoresizingMaskIntoConstraints = false
        card.addSubview(inner)
        NSLayoutConstraint.activate([
            inner.topAnchor.constraint(equalTo: card.topAnchor),
            inner.bottomAnchor.constraint(equalTo: card.bottomAnchor),
            inner.leadingAnchor.constraint(equalTo: card.leadingAnchor),
            inner.trailingAnchor.constraint(equalTo: card.trailingAnchor),
        ])

        let notMod = UILabel()
        notMod.text = "THIS APP IS NOT A MOD OF KEYFLOW."
        notMod.textColor = argbToUIColor(C.GREEN)
        notMod.font = .boldSystemFont(ofSize: 16)
        notMod.numberOfLines = 0
        inner.addArrangedSubview(notMod)

        let disclaimer = UILabel()
        disclaimer.attributedText = lineSpaced(
            "Saiki Motion is an independent app. We built it with a similar interface and feature set to Keyflow by Angkin, and it is free for all users. We are currently in development and we are excited for the future of Saiki Motion.",
            14, 1.2, Int32(bitPattern: 0xFFFFFFFF))
        disclaimer.numberOfLines = 0
        inner.addArrangedSubview(pad(disclaimer, 10, 0, 14, 0))

        let devs = UILabel()
        devs.text = "Developers"
        devs.textColor = argbToUIColor(Int32(bitPattern: 0xFF8C8C96))
        devs.font = .boldSystemFont(ofSize: 12)
        inner.addArrangedSubview(devs)

        let tiktok = UILabel()
        tiktok.text = "TikTok  @quintsuxf\nTikTok  @naviya903"
        tiktok.textColor = argbToUIColor(Int32(bitPattern: 0xFFFFFFFF))
        tiktok.font = .systemFont(ofSize: 15)
        tiktok.numberOfLines = 0
        inner.addArrangedSubview(pad(tiktok, 4, 0, 0, 0))

        stack.addArrangedSubview(card)

        // 5 - What's New header
        let header = UILabel()
        header.text = "What's New"
        header.textColor = argbToUIColor(C.GREEN)
        header.font = .boldSystemFont(ofSize: 13)
        stack.addArrangedSubview(pad(header, 22, 4, 0, 6))

        // 6 - changelog lines
        for u in WelcomeViewController.UPDATES {
            let line = UILabel()
            line.text = "\u{2022}  " + u
            line.textColor = argbToUIColor(Int32(bitPattern: 0xFFFFFFFF))
            line.font = .systemFont(ofSize: 14)
            line.numberOfLines = 0
            stack.addArrangedSubview(pad(line, 3, 4, 3, 4))
        }

        // 7 - button row
        let row = UIStackView()
        row.axis = .horizontal
        row.alignment = .fill
        row.distribution = .fillEqually
        row.spacing = 8

        let never = PillButton("Don't show again", nil, C.CARD2, Int32(bitPattern: 0xFFFFFFFF))
        never.onClick = { [weak self] in
            UserDefaults.standard.set(true, forKey: "hideWelcome")
            self?.dismiss(animated: true)
        }
        row.addArrangedSubview(never)
        never.heightAnchor.constraint(equalToConstant: 50).isActive = true

        let close = PillButton("Close", nil, C.GREEN, C.ONDARK)
        close.onClick = { [weak self] in
            self?.dismiss(animated: true)
        }
        row.addArrangedSubview(close)
        close.heightAnchor.constraint(equalToConstant: 50).isActive = true

        stack.addArrangedSubview(pad(row, 26, 0, 0, 0))
    }

    /// Letter-spaced bold label text (the wordmark).
    private func kerned(_ s: String, _ size: CGFloat, _ color: Int32, _ spacing: CGFloat) -> NSAttributedString {
        NSAttributedString(string: s, attributes: [
            .kern: spacing,
            .font: UIFont.boldSystemFont(ofSize: size),
            .foregroundColor: argbToUIColor(color),
        ])
    }

    /// Line-height-multiplied paragraph (the disclaimer card's body).
    private func lineSpaced(_ s: String, _ size: CGFloat, _ line: CGFloat, _ color: Int32) -> NSAttributedString {
        let p = NSMutableParagraphStyle()
        p.minimumLineHeight = size * line
        return NSAttributedString(string: s, attributes: [
            .paragraphStyle: p,
            .font: UIFont.systemFont(ofSize: size),
            .foregroundColor: argbToUIColor(color),
        ])
    }

    /// Wraps a view with directional insets so the stack stays zero-spacing.
    private func pad(_ v: UIView, _ t: CGFloat, _ l: CGFloat, _ b: CGFloat, _ r: CGFloat) -> UIView {
        let wrap = UIView()
        wrap.translatesAutoresizingMaskIntoConstraints = false
        v.translatesAutoresizingMaskIntoConstraints = false
        wrap.addSubview(v)
        NSLayoutConstraint.activate([
            v.topAnchor.constraint(equalTo: wrap.topAnchor, constant: t),
            v.bottomAnchor.constraint(equalTo: wrap.bottomAnchor, constant: -b),
            v.leadingAnchor.constraint(equalTo: wrap.leadingAnchor, constant: l),
            v.trailingAnchor.constraint(equalTo: wrap.trailingAnchor, constant: -r),
        ])
        return wrap
    }
}
