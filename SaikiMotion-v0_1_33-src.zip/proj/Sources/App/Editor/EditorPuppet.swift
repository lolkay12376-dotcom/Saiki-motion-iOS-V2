// EditorPuppet.swift — Puppet panel (Pin / Mesh / Sway tabs). Pins are placed and
// dragged right in the viewport (see OverlayView); this file is the panel.

import UIKit

extension PuppetEdit { static var tab = 0 }

extension EditorViewController {

    func puppetPanelOpen() -> Bool { panel == P_PUPPET }
    func gradientKnobsOn() -> Bool { panel == P_EDIT }

    /// Moves only the pivot; position is compensated so the media stays put.
    func moveAnchor(_ l: Layer, _ ax: Float, _ ay: Float) { setAnchorKeepVisual(l, ax, ay); onEdited() }

    // ---- rig

    func createRig() {
        let g = addLayer(.GROUP)
        g.name = "Rig Group \(g.id)"
        g.rig = Rig()
        refreshToolbar(); render()
        toast("Rig group created — tap Cubism Editor")
    }

    func openRigEditor(_ g: Layer) {
        guard g.rig != nil else { return }
        pushUndo()
        present(RigEditorViewController(group: g, host: self), animated: true)
    }

    /// Imports the selected layer into a rig group chosen from the app's own list.
    func importToRig(_ l: Layer) {
        let groups = Editor.scene.layers.filter { $0.rig != nil }
        if groups.isEmpty { toast("No rig group yet — tap Create Rig first"); return }
        _ = Dlg(self).setTitle("Import to rig group").setItems(groups.map { $0.name }) { [weak self] _, i in
            guard let self = self else { return }
            let g = groups[i]
            self.pushUndo()
            if !(g.rig!.members.contains(l.id)) { g.rig!.members.append(l.id) }
            l.parentId = g.id
            self.toast("\(l.name) added to \(g.name)")
            self.render()
        }.show()
    }

    /// Animate Rig panel: every rig parameter as a keyframe-able slider (same rows as any property).
    func buildRigAnim(_ l: Layer) {
        guard let r = l.rig else { return }
        let p: UIStackView = panelList
        if r.params.isEmpty {
            text(p, "No parameters yet. Open the Cubism Editor and add some (Angle X, Eye open…).", C.DIM, 13)
            return
        }
        text(p, "Move a slider, then press its keyframe button to animate the rig on the timeline.", C.DIM, 12)
        for q in r.params {
            addRow(p, l, PropDef(q.key, q.name, q.lo, q.hi, q.def, 2))
        }
    }

    func openPuppet() {
        guard let l = selected() else { return }
        if l.puppet == nil { pushUndo(); l.puppet = Puppet() }
        PuppetEdit.sel = []
        PuppetEdit.onChange = { [weak self] in
            if let id = PuppetEdit.sel.last { self?.selKey = "pp\(id)x" }
            self?.refreshPanel(); self?.render()
        }
        openPanel(P_PUPPET)
    }

    func buildPuppet(_ l: Layer) {
        guard let pp = l.puppet else { return }
        let p: UIStackView = panelList
        put(p, TabBar(["Pin", "Mesh", "Sway", "Bend"], PuppetEdit.tab) { [weak self] i in
            PuppetEdit.tab = i; self?.refreshPanel(); self?.render()
        }, 44)
        switch PuppetEdit.tab {
        case 0: puppetPinTab(l, pp)
        case 1: puppetMeshTab(l, pp)
        case 2: puppetSwayTab(l, pp)
        default: puppetBendTab(l, pp)
        }
    }

    // ---------------------------------------------------------------- helpers

    private func fixed(_ v: UIView, _ w: CGFloat, _ h: CGFloat) -> UIView {
        v.translatesAutoresizingMaskIntoConstraints = false
        if w > 0 { v.widthAnchor.constraint(equalToConstant: w).isActive = true }
        if h > 0 { v.heightAnchor.constraint(equalToConstant: h).isActive = true }
        return v
    }

    private func pspacer() -> UIView {
        let s = UIView()
        s.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
        s.setContentCompressionResistancePriority(UILayoutPriority(1), for: .horizontal)
        return s
    }

    private func btnRow(_ spacing: CGFloat = 8) -> UIStackView {
        let r = hRow(); r.spacing = spacing; return r
    }

    private func puppetBtn(_ text: String, _ icon: String?, on: Bool = false, enabled: Bool = true,
                           _ click: @escaping () -> Void) -> PillButton {
        let b = PillButton(text, icon, on ? C.GREEN : (enabled ? C.CARD2 : C.CARD),
                           on ? C.ONDARK : (enabled ? C.TEXT : C.DIM))
        b.onClick = enabled ? click : {}
        return b
    }

    private func puppetEdit(_ body: () -> Void) {
        pushUndo(); body(); PuppetEdit.onChange?()
    }

    // ---------------------------------------------------------------- Pin tab

    private func puppetPinTab(_ l: Layer, _ pp: Puppet) {
        let p: UIStackView = panelList
        let has = !PuppetEdit.sel.isEmpty

        let top = btnRow()
        let sw = SwitchRow()
        sw.label = "Puppet"; sw.on = pp.on; sw.captionOn = "on"; sw.captionOff = "off"
        sw.onToggle = { [weak self] v in self?.pushUndo(); pp.on = v; self?.render() }
        top.addArrangedSubview(fixed(sw, 190, 48))
        top.addArrangedSubview(pspacer())
        top.addArrangedSubview(fixed(puppetBtn("Auto-key", nil, on: autoKeyOn) { [weak self] in
            guard let self = self else { return }
            self.autoKeyOn.toggle(); self.refreshPanel()
        }, 104, 44))
        top.addArrangedSubview(fixed(puppetBtn("⋮", nil) { [weak self] in self?.puppetMenu(l, pp) }, 48, 44))
        put(p, top, 0, 6, 4)

        let modes = btnRow()
        modes.addArrangedSubview(fixed(puppetBtn("Add", "plus", on: PuppetEdit.mode == 0) {
            PuppetEdit.mode = 0; PuppetEdit.onChange?()
        }, 112, 44))
        modes.addArrangedSubview(fixed(puppetBtn("Select", nil, on: PuppetEdit.mode == 1) {
            PuppetEdit.mode = 1; PuppetEdit.onChange?()
        }, 112, 44))
        modes.addArrangedSubview(fixed(puppetBtn("Multi", nil, on: PuppetEdit.mode == 2) {
            PuppetEdit.mode = 2; PuppetEdit.onChange?()
        }, 100, 44))
        modes.addArrangedSubview(fixed(puppetBtn(pp.showMesh ? "Mesh: on" : "Mesh: off", nil, on: pp.showMesh) { [weak self] in
            pp.showMesh.toggle(); self?.refreshPanel(); self?.render()
        }, 104, 44))
        modes.addArrangedSubview(pspacer())
        put(p, modes, 0, 4, 4)
        if PuppetEdit.sel.count >= 2 {            // multi-select pins -> Create Bend (first selected = pivot)
            let cb = btnRow()
            cb.addArrangedSubview(fixed(puppetBtn("Create Bend (\(PuppetEdit.sel.count) pins)", nil, on: true) { [weak self] in
                guard let self = self else { return }
                self.pushUndo()
                let b = BendLayer(); b.applyPreset(0); b.pins = PuppetEdit.sel
                pp.bends.append(b); pp.bendSel = pp.bends.count - 1
                PuppetEdit.tab = 3; self.refreshPanel(); self.render()
            }, 240, 44))
            cb.addArrangedSubview(pspacer())
            put(p, cb, 0, 2, 4)
        }

        let nav = btnRow()
        func step(_ d: Int) {
            guard !pp.pins.isEmpty else { return }
            let cur = PuppetEdit.sel.last.flatMap { id in pp.pins.firstIndex { $0.id == id } } ?? (d > 0 ? -1 : 0)
            let n = (cur + d + pp.pins.count) % pp.pins.count
            PuppetEdit.sel = [pp.pins[n].id]; PuppetEdit.onChange?()
        }
        nav.addArrangedSubview(fixed(puppetBtn("", "prev") { step(-1) }, 58, 44))
        let lab = UILabel()
        lab.textAlignment = .center
        lab.textColor = argbToUIColor(C.TEXT)
        lab.font = boldFont(15)
        if let id = PuppetEdit.sel.last, pp.pin(id) != nil {
            lab.text = PuppetEdit.sel.count > 1 ? "\(PuppetEdit.sel.count) pins selected" : "Pin \(pp.number(id))"
        } else {
            lab.text = pp.pins.isEmpty ? "Tap the picture to add a pin" : "Tap a pin to select it"
        }
        nav.addArrangedSubview(lab)
        nav.addArrangedSubview(fixed(puppetBtn("", "next") { step(1) }, 58, 44))
        put(p, nav, 0, 4, 4)

        let acts = btnRow()
        acts.distribution = .fillEqually
        acts.addArrangedSubview(puppetBtn("Duplicate pin", "dup", enabled: has) { [weak self] in
            self?.puppetEdit {
                var made: [Int] = []
                for id in PuppetEdit.sel {
                    guard let src = pp.pin(id) else { continue }
                    let n = PuppetPin(pp.nextId, src.rx, src.ry); pp.nextId += 1
                    pp.pins.append(n)
                    l.track("pp\(n.id)x").base = (l.props["pp\(id)x"]?.eval(Editor.time) ?? 0) + 0.08
                    l.track("pp\(n.id)y").base = (l.props["pp\(id)y"]?.eval(Editor.time) ?? 0) - 0.08
                    made.append(n.id)
                }
                PuppetEdit.sel = made
            }
        })
        acts.addArrangedSubview(puppetBtn("Reset to rest", "undo", enabled: has) { [weak self] in
            guard let self = self else { return }
            self.puppetEdit {
                for id in PuppetEdit.sel {
                    l.track("pp\(id)x").set(Editor.time, 0, self.autoKeyOn)
                    l.track("pp\(id)y").set(Editor.time, 0, self.autoKeyOn)
                }
            }
        })
        acts.addArrangedSubview(puppetBtn("Delete pin", "trash", enabled: has) { [weak self] in
            self?.puppetEdit {
                for id in PuppetEdit.sel {
                    pp.pins.removeAll { $0.id == id }
                    l.props["pp\(id)x"] = nil; l.props["pp\(id)y"] = nil
                    for w in pp.sways { w.chain.removeAll { $0 == id } }
                }
                PuppetEdit.sel = []
            }
        })
        put(p, acts, 46, 4, 4)

        // Every pin can be animated: select one or many (or all) and each selected pin gets its own keyable X / Y.
        let all = btnRow()
        all.distribution = .fillEqually
        all.addArrangedSubview(puppetBtn("Select all pins", nil, enabled: !pp.pins.isEmpty) {
            PuppetEdit.sel = pp.pins.map { $0.id }; PuppetEdit.onChange?()
        })
        all.addArrangedSubview(puppetBtn("Key all pins", nil, enabled: !pp.pins.isEmpty) { [weak self] in
            self?.puppetEdit {
                for q in pp.pins {
                    for k in ["pp\(q.id)x", "pp\(q.id)y"] { let tk = l.track(k); tk.set(Editor.time, tk.eval(Editor.time), true) }
                }
            }
        })
        put(p, all, 46, 4, 4)
        let shown = PuppetEdit.sel.filter { pp.pin($0) != nil }
        for id in shown.prefix(8) {                       // cap keeps the panel from overcrowding
            let n = pp.number(id)
            addRow(p, l, PropDef("pp\(id)x", "Pin \(n) X", -2, 2, 0, 3))
            addRow(p, l, PropDef("pp\(id)y", "Pin \(n) Y", -2, 2, 0, 3))
        }
        if shown.count > 8 { text(p, "+\(shown.count - 8) more selected pins move together. Use Key all pins to keyframe them.", C.DIM, 12) }

        let fine = btnRow()
        fine.addArrangedSubview(pspacer())
        fine.addArrangedSubview(fixed(puppetBtn("Fine", nil, on: PuppetEdit.fine) {
            PuppetEdit.fine.toggle(); PuppetEdit.onChange?()
        }, 90, 40))
        put(p, fine, 0, 4, 4)
        text(p, "Fine slows dragging to a quarter so small moves are easy. Auto-key records each move as a keyframe.", C.DIM, 12)
    }

    private func puppetMenu(_ l: Layer, _ pp: Puppet) {
        let a = UIAlertController(title: "Puppet", message: nil, preferredStyle: .actionSheet)
        a.addAction(UIAlertAction(title: "Reset all pins to rest", style: .default) { [weak self] _ in
            guard let self = self else { return }
            self.puppetEdit { for q in pp.pins {
                l.track("pp\(q.id)x").set(Editor.time, 0, self.autoKeyOn)
                l.track("pp\(q.id)y").set(Editor.time, 0, self.autoKeyOn)
            } }
        })
        a.addAction(UIAlertAction(title: "Delete all pins", style: .destructive) { [weak self] _ in
            self?.puppetEdit {
                for q in pp.pins { l.props["pp\(q.id)x"] = nil; l.props["pp\(q.id)y"] = nil }
                pp.pins = []; pp.sways = []; PuppetEdit.sel = []
            }
        })
        a.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        a.popoverPresentationController?.sourceView = view
        a.popoverPresentationController?.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.maxY - 60, width: 1, height: 1)
        present(a, animated: true)
    }

    // ---------------------------------------------------------------- Mesh tab

    private func puppetMeshTab(_ l: Layer, _ pp: Puppet) {
        let p: UIStackView = panelList
        let sm = SwitchRow()
        sm.label = "Show mesh"; sm.on = pp.showMesh
        sm.onToggle = { [weak self] v in pp.showMesh = v; self?.render() }
        put(p, sm, 52)
        text(p, "Mesh detail", C.TEXT, 14, true)
        p.addArrangedSubview(chipRow(["Low", "Medium", "High", "Ultra"], pp.density) { [weak self] i in
            guard let self = self else { return }
            self.pushUndo(); pp.density = i; self.refreshPanel(); self.render()
        })
        text(p, "Stiffness — higher keeps the bend close to each pin", C.TEXT, 14, true)
        let fs = FillSlider()
        fs.lo = 1; fs.hi = 4; fs.value = pp.stiffness; fs.suffix = ""
        fs.onBegin = { [weak self] in self?.pushUndo() }
        fs.onChange = { [weak self] v in pp.stiffness = v; self?.render() }
        put(p, fs, 44)
    }

    // ---------------------------------------------------------------- Sway tab

    private func puppetSwayTab(_ l: Layer, _ pp: Puppet) {
        let p: UIStackView = panelList
        let row = btnRow()
        row.distribution = .fillEqually
        let a = SwitchRow(); a.label = "Auto Sway"; a.on = pp.swayOn
        a.onToggle = { [weak self] v in
            guard let self = self else { return }
            self.pushUndo(); pp.swayOn = v
            if v && pp.sways.isEmpty && !pp.pins.isEmpty {
                let w = SwayLayer(); w.chain = pp.pins.map { $0.id }; pp.sways = [w]; pp.swaySel = 0
            }
            self.refreshPanel(); self.render()
        }
        let r = SwitchRow(); r.label = "Lock root"; r.on = pp.lockRoot
        r.onToggle = { [weak self] v in self?.pushUndo(); pp.lockRoot = v; self?.render() }
        row.addArrangedSubview(a); row.addArrangedSubview(r)
        put(p, row, 52)

        // ---- the list of sway effects on this layer (any mix of Wave and Physics)
        pp.swaySel = min(max(pp.swaySel, 0), max(pp.sways.count - 1, 0))
        let list = UIScrollView(); list.showsHorizontalScrollIndicator = false
        var x: CGFloat = 3
        for (i, w) in pp.sways.enumerated() {
            let sel = i == pp.swaySel
            let nm = (w.kind == 0 ? "Wave " : "Physics ") + "\(i + 1)" + (w.on ? "" : " (off)")
            let b = PillButton(nm, nil, sel ? C.GREEN : C.CARD2, sel ? C.ONDARK : C.TEXT)
            b.onClick = { [weak self] in pp.swaySel = i; self?.refreshPanel() }
            b.frame = CGRect(x: x, y: 4, width: 112, height: 38); list.addSubview(b); x += 118
        }
        func adder(_ title: String, _ kind: Int) {
            let b = PillButton(title, nil, C.CARD2, C.TEXT)
            b.onClick = { [weak self] in
                guard let self = self else { return }
                self.pushUndo()
                let w = SwayLayer(); w.kind = kind; w.chain = pp.pins.map { $0.id }
                pp.sways.append(w); pp.swaySel = pp.sways.count - 1; pp.swayOn = true
                self.refreshPanel(); self.render()
            }
            b.frame = CGRect(x: x, y: 4, width: 104, height: 38); list.addSubview(b); x += 110
        }
        adder("+ Wave", 0); adder("+ Physics", 1)
        list.contentSize = CGSize(width: x + 6, height: 46)
        put(p, list, 46)

        guard pp.sways.indices.contains(pp.swaySel) else {
            text(p, "Tap + Wave or + Physics. You can stack as many as you like on one layer.", C.DIM, 13)
            return
        }
        let idx = pp.swaySel, w = pp.sways[idx]

        p.addArrangedSubview(chipRow(["Wave", "Physics"], w.kind) { [weak self] i in
            guard let self = self else { return }
            self.pushUndo(); w.kind = i; self.refreshPanel(); self.render()
        })
        p.addArrangedSubview(chipRow(["Normal", "Hair", "Skirt", "Breeze"], w.style) { [weak self] i in
            guard let self = self else { return }
            self.pushUndo(); w.applyStyle(i); self.refreshPanel(); self.render()
        })
        if w.kind == 0 {
            let preset = w.deg < 15 ? 0 : (w.deg < 28 ? 1 : 2)
            p.addArrangedSubview(chipRow(["Light", "Medium", "Heavy"], preset) { [weak self] i in
                guard let self = self else { return }
                self.pushUndo(); w.deg = [10, 20, 35][i]; self.refreshPanel(); self.render()
            })
        } else {
            // link: a Wave sway drives this physics (wave = the intention, physics = the follow-through)
            let waves = pp.sways.enumerated().filter { $0.element.kind == 0 }.map { $0.offset }
            text(p, "Driven by", C.DIM, 12)
            p.addArrangedSubview(chipRow(["Movement only"] + waves.map { "Wave \($0 + 1)" },
                                         (waves.firstIndex(of: w.link) ?? -1) + 1) { [weak self] i in
                guard let self = self else { return }
                self.pushUndo(); w.link = i == 0 ? -1 : waves[i - 1]; self.refreshPanel(); self.render()
            })
            if waves.isEmpty { text(p, "Add a + Wave to link it: the wave moves the chain, the physics adds lag and overshoot.", C.DIM, 12) }
            else if w.link >= 0 { text(p, "Linked: Wave \(w.link + 1) drives the chain and this Physics follows it with weight, lag and overshoot.", C.DIM, 12) }
            p.addArrangedSubview(chipRow(["Light", "Medium", "Heavy"], w.weight) { [weak self] i in
                guard let self = self else { return }
                self.pushUndo(); w.weight = i; self.refreshPanel(); self.render()
            })
            text(p, "Physics follows motion: parent this layer to another layer (like normal). It hangs on the parent, follows the parent\u{2019}s puppet pins too, and the chain swings after any movement.", C.DIM, 12)
        }

        if pp.pins.isEmpty {
            text(p, "Add pins on the Pin tab first.", C.DIM, 12)
        } else {
            if w.chain.count < 2 { text(p, "Pick at least 2 pins", C.AMBER, 13) }
            let sv = UIScrollView(); sv.showsHorizontalScrollIndicator = false
            let content = UIView()
            let allOn = w.chain.count == pp.pins.count
            let bAll = PillButton("All in order", nil, allOn ? C.GREEN : C.CARD2, allOn ? C.ONDARK : C.TEXT)
            bAll.onClick = { [weak self] in
                guard let self = self else { return }
                self.pushUndo(); w.chain = pp.pins.map { $0.id }; pp.swayOn = true
                self.refreshPanel(); self.render()
            }
            bAll.frame = CGRect(x: 3, y: 4, width: 110, height: 38); content.addSubview(bAll)
            let bClr = PillButton("Clear", nil, C.CARD2, C.TEXT)
            bClr.onClick = { [weak self] in
                guard let self = self else { return }
                self.pushUndo(); w.chain = []; self.refreshPanel(); self.render()
            }
            bClr.frame = CGRect(x: 119, y: 4, width: 70, height: 38); content.addSubview(bClr)
            for (i, q) in pp.pins.enumerated() {
                let k = w.chain.firstIndex(of: q.id)
                let nm = "Pin \(i + 1)"
                let b = PillButton(k != nil ? "\(k! + 1) · \(nm)" : nm, nil,
                                   k != nil ? C.GREEN : C.CARD2, k != nil ? C.ONDARK : C.TEXT)
                b.onClick = { [weak self] in
                    guard let self = self else { return }
                    self.pushUndo()
                    if let k = w.chain.firstIndex(of: q.id) { w.chain.remove(at: k) } else { w.chain.append(q.id) }
                    self.refreshPanel(); self.render()
                }
                b.frame = CGRect(x: 195 + CGFloat(i) * 106, y: 4, width: 100, height: 38)
                content.addSubview(b)
            }
            content.frame = CGRect(x: 0, y: 0, width: 195 + CGFloat(pp.pins.count) * 106 + 6, height: 46)
            sv.addSubview(content); sv.contentSize = content.frame.size
            put(p, sv, 46)
        }

        /// `key` set → also writes a layer track so keyframes / expressions can drive the value.
        func slider(_ label: String, _ lo: Float, _ hi: Float, _ dec: Int, _ v: Float, key: String? = nil,
                    _ set: @escaping (Float) -> Void) {
            let s = RulerSlider(frame: .zero)
            s.label = label; s.lo = lo; s.hi = hi; s.dec = dec; s.value = v
            s.canKey = false
            s.onBegin = { [weak self] in self?.pushUndo() }
            s.onChange = { [weak self] x in
                set(x)
                if let k = key, let tr = l.props[k] { tr.base = x }
                self?.render()
            }
            put(p, s, 60)
        }
        if w.kind == 0 {
            slider("Speed (/s)", 0.1, 3, 2, w.speed) { w.speed = $0 }
            slider("Strength (°)", 0, 90, 0, w.deg) { w.deg = $0 }
            slider("Wave", 0, 3, 2, w.wave) { w.wave = $0 }
            slider("Tip weight", 0.2, 4, 2, w.tip) { w.tip = $0 }
            slider("Randomness (%)", 0, 100, 0, w.rand * 100) { w.rand = $0 / 100 }
            slider("Seed", 0, 99, 0, Float(w.seed)) { w.seed = Int($0.rounded()) }
        } else {
            slider("Stiffness", 0, 100, 0, w.stiff, key: "sw\(idx)stiff") { w.stiff = $0 }
            slider("Damping", 0, 100, 0, w.damp, key: "sw\(idx)damp") { w.damp = $0 }
            slider("Gravity", 0, 100, 0, w.grav, key: "sw\(idx)grav") { w.grav = $0 }
            slider("Wind (%)", -100, 100, 0, w.wind, key: "sw\(idx)wind") { w.wind = $0 }
            slider("Strength (°)", 0, 90, 0, w.deg) { w.deg = $0 }
            // link a value to keyframes / an expression: creates the layer track the physics reads
            let link = btnRow(); link.distribution = .fillEqually
            for (nm, k, v) in [("Link stiffness", "stiff", w.stiff), ("Link damping", "damp", w.damp),
                               ("Link gravity", "grav", w.grav), ("Link wind", "wind", w.wind)] {
                let key = "sw\(idx)\(k)"
                let on = l.props[key] != nil
                let b = PillButton(on ? "✓ " + nm : nm, nil, on ? C.GREEN : C.CARD2, on ? C.ONDARK : C.TEXT)
                b.onClick = { [weak self] in
                    guard let self = self else { return }
                    self.pushUndo()
                    if on { l.props[key] = nil } else { l.track(key).base = v }
                    self.refreshPanel(); self.render()
                }
                link.addArrangedSubview(b)
            }
            put(p, link, 46)
            slider("Mass x", 0.2, 4, 2, w.massMul) { w.massMul = $0 }
            slider("Wind speed (Hz)", 0.05, 3, 2, w.windFreq) { w.windFreq = $0 }
            slider("Max stretch", 0.05, 3, 2, w.limit) { w.limit = $0 }
            text(p, "A linked value becomes a track named sw\(idx)stiff / damp / grav / wind. Keyframe it or add an expression to it in the graph editor.", C.DIM, 11)
        }

        // ---- link to another layer's Wave: this sway moves with it (back skirt follows front skirt)
        var cands: [(String, Int, Int)] = []
        for o in Editor.scene.layers where o.id != l.id {
            if let op = o.puppet, op.swayOn { for (j, ow) in op.sways.enumerated() where ow.kind == 0 && ow.on { cands.append(("\(o.name) · Wave \(j + 1)", o.id, j)) } }
        }
        let fl = btnRow(); fl.distribution = .fillEqually
        let cur = cands.first { $0.1 == w.followId && $0.2 == w.followIdx }?.0
        let fb = PillButton(cur != nil ? "Follows: " + cur! : "Follow another layer's wave", nil, cur != nil ? C.GREEN : C.CARD2, cur != nil ? C.ONDARK : C.TEXT)
        fb.onClick = { [weak self] in
            guard let self = self else { return }
            let a = UIAlertController(title: "Follow wave", message: cands.isEmpty ? "No other layer has a Wave yet." : nil, preferredStyle: .actionSheet)
            a.addAction(UIAlertAction(title: "None", style: .default) { _ in self.pushUndo(); w.followId = -1; self.refreshPanel(); self.render() })
            for c in cands { a.addAction(UIAlertAction(title: c.0, style: .default) { _ in
                self.pushUndo(); w.followId = c.1; w.followIdx = c.2; self.refreshPanel(); self.render() }) }
            a.addAction(UIAlertAction(title: "Cancel", style: .cancel))
            a.popoverPresentationController?.sourceView = self.view
            a.popoverPresentationController?.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.maxY - 60, width: 1, height: 1)
            self.present(a, animated: true)
        }
        fl.addArrangedSubview(fb)
        put(p, fl, 46)
        if w.followId >= 0 {
            slider("Follow strength", 0, 2, 2, w.followAmt) { w.followAmt = $0 }
            slider("Follow delay (s)", 0, 2, 2, w.delay) { w.delay = $0 }
        }

        let del = btnRow(); del.distribution = .fillEqually
        let en = PillButton(w.on ? "Disable this sway" : "Enable this sway", nil, C.CARD2, C.TEXT)
        en.onClick = { [weak self] in self?.pushUndo(); w.on.toggle(); self?.refreshPanel(); self?.render() }
        let rm = PillButton("Delete this sway", nil, C.CARD2, C.TEXT)
        rm.onClick = { [weak self] in
            guard let self = self else { return }
            self.pushUndo(); pp.sways.remove(at: idx); pp.swaySel = max(0, idx - 1)
            self.refreshPanel(); self.render()
        }
        del.addArrangedSubview(en); del.addArrangedSubview(rm)
        put(p, del, 46)
    }

    // ---------------------------------------------------------------- Bend tab

    private func puppetBendTab(_ l: Layer, _ pp: Puppet) {
        let p: UIStackView = panelList
        pp.bendSel = min(max(pp.bendSel, 0), max(pp.bends.count - 1, 0))
        guard pp.bends.indices.contains(pp.bendSel) else {
            text(p, "Pin tab: switch to Multi, tap 2+ pins (first = pivot), then tap Create Bend.", C.DIM, 13)
            return
        }
        let idx = pp.bendSel, b = pp.bends[idx]
        let list = UIScrollView(); list.showsHorizontalScrollIndicator = false
        var x: CGFloat = 3
        for (i, bd) in pp.bends.enumerated() {
            let sel = i == idx
            let bt = PillButton(bd.name + (bd.on ? "" : " (off)"), nil, sel ? C.GREEN : C.CARD2, sel ? C.ONDARK : C.TEXT)
            bt.onClick = { [weak self] in pp.bendSel = i; self?.refreshPanel() }
            bt.frame = CGRect(x: x, y: 4, width: 130, height: 38); list.addSubview(bt); x += 136
        }
        list.contentSize = CGSize(width: x + 6, height: 46)
        put(p, list, 46)
        text(p, "Presets", C.DIM, 12)
        p.addArrangedSubview(chipRow(BendLayer.presetNames, BendLayer.presetNames.firstIndex(of: b.name) ?? -1) { [weak self] i in
            guard let self = self else { return }
            self.pushUndo(); b.applyPreset(i); self.refreshPanel(); self.render()
        })
        func slider(_ label: String, _ lo: Float, _ hi: Float, _ dec: Int, _ v: Float, key: String? = nil, _ set: @escaping (Float) -> Void) {
            let s = RulerSlider(frame: .zero)
            s.label = label; s.lo = lo; s.hi = hi; s.dec = dec; s.value = v
            s.canKey = false
            s.onBegin = { [weak self] in self?.pushUndo() }
            s.onChange = { [weak self] x in
                set(x)
                if let k = key, let tr = l.props[k] { tr.base = x }
                self?.render()
            }
            put(p, s, 60)
        }
        slider("Amount (0 = flat, 1 = full)", 0, 1, 2, b.amt, key: "bnd\(idx)amt") { b.amt = $0 }
        slider(b.mode == 0 ? "Angle (°)" : "Strength (%)", b.mode == 0 ? -180 : -150, b.mode == 0 ? 180 : 150, 0, b.angle) { b.angle = $0 }
        slider("Smoothness", 0, 1, 2, b.smooth) { b.smooth = $0 }
        slider("Falloff", 0.2, 4, 2, b.tip) { b.tip = $0 }
        p.addArrangedSubview(chipRow(["Bend", "Eyelid"], b.mode) { [weak self] i in
            guard let self = self else { return }
            self.pushUndo(); b.mode = i; self.refreshPanel(); self.render()
        })
        let key = "bnd\(idx)amt", keyed = l.props[key] != nil
        let row = btnRow(); row.distribution = .fillEqually
        let kb = PillButton(keyed ? "✓ Amount keyable" : "Make amount keyable", nil, keyed ? C.GREEN : C.CARD2, keyed ? C.ONDARK : C.TEXT)
        kb.onClick = { [weak self] in
            guard let self = self else { return }
            self.pushUndo(); if keyed { l.props[key] = nil } else { l.track(key).base = b.amt }
            self.refreshPanel(); self.render()
        }
        let us = PillButton("Use selected pins", nil, C.CARD2, C.TEXT)
        us.onClick = { [weak self] in
            guard let self = self, PuppetEdit.sel.count >= 2 else { return }
            self.pushUndo(); b.pins = PuppetEdit.sel; self.refreshPanel(); self.render()
        }
        row.addArrangedSubview(kb); row.addArrangedSubview(us)
        put(p, row, 46)
        let row2 = btnRow(); row2.distribution = .fillEqually
        let en = PillButton(b.on ? "Disable" : "Enable", nil, C.CARD2, C.TEXT)
        en.onClick = { [weak self] in self?.pushUndo(); b.on.toggle(); self?.refreshPanel(); self?.render() }
        let rm = PillButton("Delete bend", nil, C.CARD2, C.TEXT)
        rm.onClick = { [weak self] in
            guard let self = self else { return }
            self.pushUndo(); l.props[key] = nil; pp.bends.remove(at: idx); pp.bendSel = max(0, idx - 1)
            self.refreshPanel(); self.render()
        }
        row2.addArrangedSubview(en); row2.addArrangedSubview(rm)
        put(p, row2, 46)
        text(p, "Pins bend around the first selected pin; order = root to tip. Eyelid squashes pins to their centre line (Eye Close / Eye Open). Key Amount to animate.", C.DIM, 11)
    }
}
