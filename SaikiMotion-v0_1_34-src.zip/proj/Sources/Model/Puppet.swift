// Puppet.swift — puppet pin warp (Model + math).
// Pins live in the layer's quad space (-1...1, y up, same space as the
// renderer's aPos). Each pin's motion is two ordinary tracks on the layer
// ("pp<id>x" / "pp<id>y" = offset from rest), so keyframes, auto-key,
// undo, save and export all work with no special cases. Auto-sway adds a
// procedural wave on top, scaled root→tip along a chain of pins.

import Foundation
import OpenGLES

final class PuppetPin {
    var id: Int
    var rx: Float
    var ry: Float
    init(_ id: Int, _ rx: Float, _ ry: Float) { self.id = id; self.rx = rx; self.ry = ry }
}

/// One sway effect on a puppet. A puppet can hold several; kind 0 = Wave (procedural),
/// kind 1 = Physics (reacts to the layer's / parents' movement, gravity and wind).
/// Physics values can be linked to keyframes or expressions: put a track on
/// "sw<index>stiff", "sw<index>damp", "sw<index>grav" or "sw<index>wind".
final class SwayLayer {
    var kind = 0
    var link = -1                        // physics: index of a Wave sway that drives it (-1 = movement only)
    var style = 0                        // 0 Normal, 1 Hair, 2 Skirt, 3 Breeze (a preset of the values below)
    var chain: [Int] = []
    var speed: Float = 0.8, deg: Float = 20, wave: Float = 0.5, tip: Float = 1.5, rand: Float = 0
    var seed = 1
    var weight = 1                       // physics: 0 light, 1 medium, 2 heavy
    var stiff: Float = 45, damp: Float = 40, grav: Float = 0, wind: Float = 0
    var on = true
    // extra physics customisation + linking to another layer's Wave (e.g. back skirt follows front skirt)
    var followId = -1, followIdx = 0     // layer id / sway index of the Wave to follow (-1 = none)
    var followAmt: Float = 1             // multiplier on the followed wave's strength
    var delay: Float = 0                 // seconds the followed wave is late by
    var windFreq: Float = 0.7            // gust speed (Hz)
    var limit: Float = 1.2               // max stretch (x of layer size)
    var massMul: Float = 1               // extra mass multiplier on top of Light/Medium/Heavy
    /// Applies a sway type: Normal, Hair (long, lagging, loose), Skirt (hem swings together, slow), Breeze (soft gusts).
    func applyStyle(_ st: Int) {
        style = st
        if kind == 0 {
            let v: [(Float, Float, Float, Float, Float)] = [(0.8, 20, 0.5, 1.5, 0), (0.7, 14, 0.9, 2.2, 0.25), (0.55, 12, 0.25, 1.0, 0.1), (0.35, 8, 1.6, 1.8, 0.5)]
            let a = v[max(0, min(3, st))]
            speed = a.0; deg = a.1; wave = a.2; tip = a.3; rand = a.4
        } else {
            let v: [(Float, Float, Float, Float, Float)] = [(45, 40, 0, 0, 20), (30, 25, 25, 0, 25), (55, 45, 10, 0, 18), (40, 35, 0, 35, 15)]
            let a = v[max(0, min(3, st))]
            stiff = a.0; damp = a.1; grav = a.2; wind = a.3; deg = a.4
        }
    }
    func toJson() -> JObj {
        let o = JObj()
        o.put("style", Int64(style)).put("link", Int64(link))
        o.put("kind", Int64(kind)).put("on", on).put("speed", Double(speed)).put("deg", Double(deg))
        o.put("wave", Double(wave)).put("tip", Double(tip)).put("rand", Double(rand)).put("seed", Int64(seed))
        o.put("weight", Int64(weight)).put("stiff", Double(stiff)).put("damp", Double(damp))
        o.put("grav", Double(grav)).put("wind", Double(wind))
        o.put("followId", Int64(followId)).put("followIdx", Int64(followIdx)).put("followAmt", Double(followAmt))
        o.put("delay", Double(delay)).put("windFreq", Double(windFreq)).put("limit", Double(limit)).put("massMul", Double(massMul))
        let ca = JArr(); for c in chain { _ = ca.put(Int64(c)) }
        o.put("chain", ca)
        return o
    }
    static func fromJson(_ o: JObj) -> SwayLayer {
        let s = SwayLayer()
        s.style = clamp(o.optInt("style", 0), 0, 3); s.link = o.optInt("link", -1); s.kind = clamp(o.optInt("kind", 0), 0, 1); s.on = o.optBool("on", true)
        s.speed = o.optFloat("speed", 0.8); s.deg = o.optFloat("deg", 20); s.wave = o.optFloat("wave", 0.5)
        s.tip = o.optFloat("tip", 1.5); s.rand = o.optFloat("rand", 0); s.seed = o.optInt("seed", 1)
        s.weight = clamp(o.optInt("weight", 1), 0, 2)
        s.stiff = o.optFloat("stiff", 45); s.damp = o.optFloat("damp", 40)
        s.grav = o.optFloat("grav", 0); s.wind = o.optFloat("wind", 0)
        s.followId = o.optInt("followId", -1); s.followIdx = o.optInt("followIdx", 0); s.followAmt = o.optFloat("followAmt", 1)
        s.delay = o.optFloat("delay", 0); s.windFreq = o.optFloat("windFreq", 0.7)
        s.limit = o.optFloat("limit", 1.2); s.massMul = o.optFloat("massMul", 1)
        if let ca = o.optJSONArray("chain") { for i in 0..<ca.count { s.chain.append(ca.optInt(i)) } }
        return s
    }
}

/// A smooth bend made from several selected pins. mode 0 = Bend (pins rotate about the first pin, more toward the last),
/// mode 1 = Close/Open (pins squash toward their centre line, like an eyelid). `amt` can be keyframed: track "bnd<i>amt".
final class BendLayer {
    var name = "Bend"
    var pins: [Int] = []
    var mode = 0
    var angle: Float = 45        // mode 0: degrees at the tip; mode 1: closing strength in % (negative = opens wider)
    var smooth: Float = 0.7      // 0 linear ... 1 very smooth ease in/out
    var tip: Float = 1.0         // falloff exponent root -> tip
    var amt: Float = 1           // 0...1 how much the bend is applied (animate this)
    var target: Float = 0        // where the bend hinges along the pin order: 0 = at the first pin, 0.5 = in the middle
    var affectWave = false       // waves on these pins swing around the bent shape
    var affectPhys = false       // physics on these pins reacts to (lags behind) the bend
    var on = true
    static let presetNames = ["Classic Bend", "Soft Bend", "Middle Bend", "Eye Close", "Eye Open"]
    func applyPreset(_ i: Int) {
        switch i {
        case 0: name = "Classic Bend"; mode = 0; angle = 45; smooth = 0.5; tip = 1.2; target = 0
        case 1: name = "Soft Bend"; mode = 0; angle = 25; smooth = 1; tip = 1.0; target = 0
        case 2: name = "Middle Bend"; mode = 0; angle = 60; smooth = 0.8; tip = 1; target = 0.5
        case 3: name = "Eye Close"; mode = 1; angle = 100; smooth = 0.8; tip = 1
        default: name = "Eye Open"; mode = 1; angle = -40; smooth = 0.8; tip = 1
        }
    }
    func toJson() -> JObj {
        let o = JObj(); let a = JArr(); for c in pins { _ = a.put(Int64(c)) }
        o.put("name", name).put("mode", Int64(mode)).put("angle", Double(angle)).put("smooth", Double(smooth))
        o.put("tip", Double(tip)).put("amt", Double(amt)).put("on", on).put("pins", a)
        o.put("target", Double(target)).put("affectWave", affectWave).put("affectPhys", affectPhys)
        return o
    }
    static func fromJson(_ o: JObj) -> BendLayer {
        let b = BendLayer()
        b.name = o.optString("name", "Bend"); b.mode = clamp(o.optInt("mode", 0), 0, 1)
        b.angle = o.optFloat("angle", 45); b.smooth = o.optFloat("smooth", 0.7); b.tip = o.optFloat("tip", 1)
        b.amt = o.optFloat("amt", 1); b.on = o.optBool("on", true)
        b.target = o.optFloat("target", 0); b.affectWave = o.optBool("affectWave", false); b.affectPhys = o.optBool("affectPhys", false)
        if let a = o.optJSONArray("pins") { for i in 0..<a.count { b.pins.append(a.optInt(i)) } }
        return b
    }
}

final class Puppet {
    var bends: [BendLayer] = []
    var bendSel = 0                 // editor only
    var on = true
    var pins: [PuppetPin] = []
    var nextId = 1
    var density = 1                 // 0 low, 1 medium, 2 high
    var showMesh = true
    var stiffness: Float = 2        // falloff power (higher = more local)
    var swayOn = false
    var lockRoot = true
    var swayStrength = 1            // 0 gentle, 1 medium, 2 strong
    var swayChain: [Int] = []       // pin ids, root first
    var swaySpeed: Float = 0.8      // cycles per second
    var swayDeg: Float = 20         // swing angle at the tip (degrees)
    var swayWave: Float = 0.5       // phase lag per pin (radians)
    var swayTip: Float = 1.5        // root→tip weight exponent
    var swayRand: Float = 0         // 0...1
    var swaySeed = 1
    var sways: [SwayLayer] = []     // every wave / physics effect on this layer
    var swaySel = 0                 // editor only

    func pin(_ id: Int) -> PuppetPin? { pins.first { $0.id == id } }
    func number(_ id: Int) -> Int { (pins.firstIndex { $0.id == id } ?? 0) + 1 }

    func toJson() -> JObj {
        let o = JObj()
        o.put("on", on).put("nextId", Int64(nextId)).put("density", Int64(density))
        o.put("showMesh", showMesh).put("stiffness", Double(stiffness))
        o.put("swayOn", swayOn).put("lockRoot", lockRoot)
        o.put("swayStrength", Int64(swayStrength)).put("swaySpeed", Double(swaySpeed))
        o.put("swayDeg", Double(swayDeg)).put("swayWave", Double(swayWave)).put("swayTip", Double(swayTip))
        o.put("swayRand", Double(swayRand)).put("swaySeed", Int64(swaySeed))
        let pa = JArr()
        for p in pins {
            pa.put(JObj().put("id", Int64(p.id)).put("rx", Double(p.rx)).put("ry", Double(p.ry)))
        }
        o.put("pins", pa)
        let sa = JArr(); for w in sways { _ = sa.put(w.toJson()) }
        o.put("sways", sa)
        let ba = JArr(); for b in bends { _ = ba.put(b.toJson()) }
        o.put("bends", ba)
        let ca = JArr(); for c in swayChain { _ = ca.put(Int64(c)) }
        o.put("chain", ca)
        return o
    }

    static func fromJson(_ o: JObj) -> Puppet {
        let p = Puppet()
        p.on = o.optBool("on", true)
        p.nextId = max(1, o.optInt("nextId", 1))
        p.density = clamp(o.optInt("density", 1), 0, 3)
        p.showMesh = o.optBool("showMesh", true)
        p.stiffness = o.optFloat("stiffness", 2)
        p.swayOn = o.optBool("swayOn")
        p.lockRoot = o.optBool("lockRoot", true)
        p.swayStrength = clamp(o.optInt("swayStrength", 1), 0, 2)
        p.swaySpeed = o.optFloat("swaySpeed", 0.8)
        p.swayDeg = o.optFloat("swayDeg", 20); p.swayWave = o.optFloat("swayWave", 0.5)
        p.swayTip = o.optFloat("swayTip", 1.5); p.swayRand = o.optFloat("swayRand", 0)
        p.swaySeed = o.optInt("swaySeed", 1)
        if let pa = o.optJSONArray("pins") {
            for i in 0..<pa.count {
                if let po = pa.optJSONObject(i) {
                    p.pins.append(PuppetPin(po.optInt("id"), po.optFloat("rx"), po.optFloat("ry")))
                }
            }
        }
        if let ca = o.optJSONArray("chain") {
            for i in 0..<ca.count { p.swayChain.append(ca.optInt(i)) }
        }
        if let ba = o.optJSONArray("bends") {
            for i in 0..<ba.count { if let bo = ba.optJSONObject(i) { p.bends.append(BendLayer.fromJson(bo)) } }
        }
        if let sa = o.optJSONArray("sways") {
            for i in 0..<sa.count { if let so = sa.optJSONObject(i) { p.sways.append(SwayLayer.fromJson(so)) } }
        } else if p.swayOn && !p.swayChain.isEmpty {
            let w = SwayLayer()
            w.chain = p.swayChain; w.speed = p.swaySpeed; w.deg = p.swayDeg; w.wave = p.swayWave
            w.tip = p.swayTip; w.rand = p.swayRand; w.seed = p.swaySeed
            p.sways = [w]
        }
        return p
    }
}

/// Shared state between the Puppet panel and the viewport overlay.
enum PuppetEdit {
    static var mode = 0              // 0 add, 1 select, 2 multi
    static var sel: [Int] = []       // selected pin ids (last = primary)
    static var fine = false
    static var onChange: (() -> Void)? = nil
}

enum PuppetMath {
    static let segs = [7, 12, 18, 28]
    private static let lock = NSLock()
    private static var gCaches: [Int: (key: [Float], out: [Float])] = [:]

    static func rnd(_ seed: Int, _ k: Int) -> Float {
        var x = UInt32(truncatingIfNeeded: seed &* 7919 &+ k &* 104729 &+ 12345)
        x = x &* 1664525 &+ 1013904223
        x ^= x >> 13
        x = x &* 1664525 &+ 1013904223
        return Float(x >> 8) / Float(1 << 24) * 2 - 1
    }

    /// Wave sway: each chained pin swings around the root pin, more toward the tip.
    static func waveOffset(_ p: Puppet, _ s: SwayLayer, _ pin: PuppetPin, _ t: Float,
                           _ qs: (Float, Float), _ lay: Layer? = nil) -> (Float, Float) {
        guard let k = s.chain.firstIndex(of: pin.id), let root = p.pin(s.chain[0]) else { return (0, 0) }
        let ext = extWave(s), g = ext ?? s                      // follow another layer's Wave (back skirt <- front skirt)
        let amt0: Float = ext != nil ? s.followAmt : 1
        let tw = ext != nil ? t - s.delay : t
        let n = s.chain.count
        let base: Float = p.lockRoot ? (n > 1 ? Float(k) / Float(n - 1) : 0) : Float(k + 1) / Float(n)
        let w = base <= 0 ? 0 : pow(base, max(g.tip, 0.1))
        let r = rnd(g.seed, k)
        let ph = 2 * Float.pi * g.speed * tw - Float(k) * g.wave + g.rand * r * Float.pi
        let amp = 1 + g.rand * r * 0.5
        let gdeg = g.deg * amt0
        if k == 0 { return p.lockRoot ? (0, 0) : (0.03 * gdeg / 20 * w * sin(ph), 0) }
        let ang = gdeg * Float.pi / 180 * w * sin(ph) * amp
        var bp: (Float, Float) = (0, 0), br: (Float, Float) = (0, 0)      // bends set to "affect waves" shape the swing
        if let lay = lay, !p.bends.isEmpty { bp = bendShift(lay, p, pin, t, qs, phys: false); br = bendShift(lay, p, root, t, qs, phys: false) }
        let vx = (pin.rx + bp.0 - root.rx - br.0) * qs.0, vy = (pin.ry + bp.1 - root.ry - br.1) * qs.1
        let c = cos(ang), sn = sin(ang)
        let rx = vx * c - vy * sn, ry = vx * sn + vy * c
        return ((rx - vx) / max(qs.0, 0.0001), (ry - vy) / max(qs.1, 0.0001))
    }

    /// The Wave on another layer this sway follows, or nil.
    static func extWave(_ s: SwayLayer) -> SwayLayer? {
        guard s.followId >= 0, let fl = Editor.scene.layers.first(where: { $0.id == s.followId }),
              let fp = fl.puppet, fp.swayOn, fp.sways.indices.contains(s.followIdx) else { return nil }
        let w = fp.sways[s.followIdx]
        return (w.kind == 0 && w.on) ? w : nil
    }

    /// Bend parameter: the stored number, or the layer track (keyframes / expression) "bnd<i><name>" when one exists.
    static func bv(_ l: Layer, _ idx: Int, _ name: String, _ v: Float, _ t: Float) -> Float {
        let k = "bnd\(idx)\(name)"
        return l.props[k] != nil ? l.p(k, t) : v
    }

    /// Smooth bend / eyelid offset of one pin.
    static func bendOffset(_ l: Layer, _ p: Puppet, _ b: BendLayer, _ idx: Int, _ pin: PuppetPin, _ t: Float,
                           _ qs: (Float, Float)) -> (Float, Float) {
        guard let k = b.pins.firstIndex(of: pin.id), b.pins.count > 1 else { return (0, 0) }
        let amt = max(0, min(1, bv(l, idx, "amt", b.amt, t)))
        if amt <= 0 { return (0, 0) }
        let angle = bv(l, idx, "ang", b.angle, t), tip = bv(l, idx, "tip", b.tip, t)
        let n = b.pins.count
        let sm = max(0, min(1, bv(l, idx, "smo", b.smooth, t)))
        func ease(_ x: Float) -> Float { let c = max(0, min(1, x)); let e = c * c * c * (c * (c * 6 - 15) + 10); return c + (e - c) * sm }
        if b.mode == 0 {
            // hinge point along the pin order: target 0 = first pin, 0.5 = middle. Pins before it stay put,
            // pins after it swing around it, easing in so the bend is smooth.
            let tg = max(0, min(0.98, bv(l, idx, "tgt", b.target, t)))
            let pos = tg * Float(n - 1), kf = Float(k)
            if kf <= pos { return (0, 0) }
            let i0 = Int(pos), i1 = min(i0 + 1, n - 1), fr = pos - Float(i0)
            guard let a0 = p.pin(b.pins[i0]), let a1 = p.pin(b.pins[i1]) else { return (0, 0) }
            let px = a0.rx + (a1.rx - a0.rx) * fr, py = a0.ry + (a1.ry - a0.ry) * fr
            let w = pow(ease((kf - pos) / max(Float(n - 1) - pos, 0.0001)), max(tip, 0.1))
            let ang = angle * Float.pi / 180 * amt * w
            let vx = (pin.rx - px) * qs.0, vy = (pin.ry - py) * qs.1
            let c = cos(ang), sn = sin(ang)
            return (((vx * c - vy * sn) - vx) / max(qs.0, 0.0001), ((vx * sn + vy * c) - vy) / max(qs.1, 0.0001))
        }
        // eyelid: squash toward the pins' centre line, strongest in the middle (smooth = rounder lid)
        let ps = b.pins.compactMap { p.pin($0) }
        guard !ps.isEmpty else { return (0, 0) }
        let cy = ps.reduce(0) { $0 + $1.ry } / Float(ps.count)
        let minX = ps.map { $0.rx }.min() ?? 0, maxX = ps.map { $0.rx }.max() ?? 0
        let u = maxX > minX ? (pin.rx - minX) / (maxX - minX) : 0.5
        let mid = 1 - abs(u * 2 - 1)                                  // 0 at corners, 1 in the middle
        let w = (1 - sm) + sm * ease(mid)
        return (0, (cy - pin.ry) * (angle / 100) * amt * w)
    }

    /// Sum of the bends that are set to affect waves (phys = false) or physics (phys = true) on this pin.
    static func bendShift(_ l: Layer, _ p: Puppet, _ pin: PuppetPin, _ t: Float, _ qs: (Float, Float),
                          phys: Bool) -> (Float, Float) {
        if p.bends.isEmpty { return (0, 0) }
        var sx: Float = 0, sy: Float = 0
        for (i, b) in p.bends.enumerated() where b.on && (phys ? b.affectPhys : b.affectWave) && b.pins.contains(pin.id) {
            let o = bendOffset(l, p, b, i, pin, t, qs); sx += o.0; sy += o.1
        }
        return (sx, sy)
    }

    /// Value of a physics setting: the stored number, or the layer track (keyframes / expression) when one exists.
    private static func pv(_ l: Layer, _ idx: Int, _ key: String, _ v: Float, _ t: Float) -> Float {
        l.props["sw\(idx)\(key)"] != nil ? l.p("sw\(idx)\(key)", t) : v
    }

    private static var physCache: [Int: (key: [Float], out: [Int: (Float, Float)])] = [:]

    /// Physics sway for every chained pin. Stateless: a spring/damper is integrated over the last
    /// ~1.2 s of the layer's own motion (including its parents), so scrubbing and export agree.
    static func physicsOffsets(_ l: Layer, _ p: Puppet, _ s: SwayLayer, _ idx: Int, _ t: Float,
                               _ qs: (Float, Float)) -> [Int: (Float, Float)] {
        // FREEZE FIX: a physics layer's anchor reads its parent's mesh, which used to run the parent's own full
        // physics sim for every sub-step (cost multiplied per link -> endless freeze on long chains / cycles).
        // Nested calls now return no physics (parent's keyed + wave motion still carries the child), so cost is bounded.
        let td = Thread.current.threadDictionary
        let depth = (td["puppetPhysDepth"] as? Int) ?? 0
        if depth >= 1 || s.chain.count < 2 { return [:] }
        td["puppetPhysDepth"] = depth + 1
        defer { td["puppetPhysDepth"] = depth }
        let stiff = pv(l, idx, "stiff", s.stiff, t), damp = pv(l, idx, "damp", s.damp, t)
        let grav = pv(l, idx, "grav", s.grav, t), wind = pv(l, idx, "wind", s.wind, t)
        let m0 = Xf.matrix(l, t), m1 = Xf.matrix(l, t - 0.25), m2 = Xf.matrix(l, t - 0.6)
        var key: [Float] = [Float(l.id), t, stiff, damp, grav, wind, Float(s.weight), s.deg, qs.0, qs.1]
        key += m0 + m1 + m2
        let ext = extWave(s)
        let drv: SwayLayer? = (s.link >= 0 && s.link < p.sways.count && p.sways[s.link].kind == 0 && p.sways[s.link].on) ? p.sways[s.link] : (ext != nil ? s : nil)
        if let d = drv { key += [Float(s.link), d.speed, d.deg, d.wave, d.tip, d.rand, Float(d.seed), Float(d.chain.count)] }
        if let e = extWave(drv ?? s) { key += [Float(s.followId), e.speed, e.deg, e.wave, e.tip, e.rand, Float(e.seed), s.followAmt, s.delay] }
        key += [s.windFreq, s.limit, s.massMul]
        let par = followsParentPuppet(l) ? parentLayer(l) : nil
        if let par = par {            // the parent's puppet motion over the last second is part of the cache key
            for i in 0..<4 {
                let tk = t - Float(i) * 0.3; let o = Xf.apply(Xf.matrix(l, tk), 0, 0)
                let f = follow(pctx(par, tk), o.0, o.1); key += [f.0, f.1]
            }
        }
        for id in s.chain { if let q = p.pin(id) {
            key += [Float(id), q.rx, q.ry]
            let bs = bendShift(l, p, q, t, qs, phys: true); key += [bs.0, bs.1]
        } }
        let ck = l.id &* 64 &+ idx
        if let c = physCache[ck], c.key == key { return c.out }
        var out: [Int: (Float, Float)] = [:]
        let n = s.chain.count
        let mass: Float = [0.6, 1, 1.7][s.weight] * max(s.massMul, 0.1)
        let dt: Float = 1.0 / 30                       // one anchor sample per 1/30 s, two spring sub-steps each
        let w2 = min((20 + stiff * 8) / mass, 3.2 / (dt * dt / 4)), c = 1 + damp * 0.4
        let g = grav * 0.06 * mass, wd = wind * 0.05
        let steps = 36, t0 = max(0, t - Float(steps) * dt)
        let hw = qs.0 / 2, hh = qs.1 / 2
        let det = m0[0] * m0[3] - m0[1] * m0[2]
        guard abs(det) > 1e-8 else { return out }
        // LAG FIX: everything that does not depend on the pin (layer matrix, parent mesh, step times) is computed ONCE
        // per step here instead of once per pin per step.
        struct Step { var tt: Float; var h: Float; var mt: [Float]; var ctx: PCtx?; var fo: (Float, Float) }
        var stepsData: [Step] = []
        func mk(_ tt: Float, _ h: Float) -> Step {
            let mt = Xf.matrix(l, tt)
            guard let par = par else { return Step(tt: tt, h: h, mt: mt, ctx: nil, fo: (0, 0)) }
            let ctx = pctx(par, tt), o = Xf.apply(mt, 0, 0)
            return Step(tt: tt, h: h, mt: mt, ctx: ctx, fo: follow(ctx, o.0, o.1))
        }
        stepsData.append(mk(t0, 0))
        var tt0 = t0
        while tt0 < t - 1e-5 { let h = min(dt, t - tt0); tt0 += h; stepsData.append(mk(tt0, h)) }
        for (k, id) in s.chain.enumerated() {
            guard let pin = p.pin(id), !(k == 0 && p.lockRoot) else { continue }
            let base: Float = n > 1 ? Float(k + (p.lockRoot ? 0 : 1)) / Float(p.lockRoot ? n - 1 : n) : 1
            let wt = pow(max(base, 0), max(s.tip, 0.1))
            func anchor(_ st: Step) -> (Float, Float) {
                // a linked Wave drives the anchor, so the physics adds follow-through (lag, overshoot) to the wave
                let wo = drv.map { waveOffset(p, $0, pin, st.tt, qs, l) } ?? (0, 0)
                let bs = bendShift(l, p, pin, st.tt, qs, phys: true)       // bends with "Affect physics" move the anchor
                let a = Xf.apply(st.mt, (pin.rx + wo.0 + bs.0) * hw, (pin.ry + wo.1 + bs.1) * hh)
                if st.ctx == nil { return a }
                let fp = follow(st.ctx, a.0, a.1)
                return (a.0 + fp.0 - st.fo.0, a.1 + fp.1 - st.fo.1)
            }
            var x = anchor(stepsData[0]), v: (Float, Float) = (0, 0)
            for i in 1..<stepsData.count {
                let st = stepsData[i], a = anchor(st), h = st.h
                let gust = 1 + 0.5 * sin(2 * Float.pi * s.windFreq * st.tt + Float(k))
                for _ in 0..<2 {
                    let hh2 = h / 2
                    let ax = w2 * (a.0 - x.0) - c * v.0 + wd * gust * wt
                    let ay = w2 * (a.1 - x.1) - c * v.1 - g * wt
                    v.0 += ax * hh2; v.1 += ay * hh2
                    x.0 += v.0 * hh2; x.1 += v.1 * hh2
                }
            }
            let a = anchor(stepsData[stepsData.count - 1])
            let k2 = s.deg / 20                      // Strength scales how far the pin may lag
            var dx = (x.0 - a.0) * k2, dy = (x.1 - a.1) * k2
            let lim = max(hw, hh) * max(s.limit, 0.05), len = (dx * dx + dy * dy).squareRoot()
            if len > lim { dx *= lim / len; dy *= lim / len }
            let lx = (m0[3] * dx - m0[2] * dy) / det, ly = (-m0[1] * dx + m0[0] * dy) / det
            out[id] = (lx / max(hw, 0.0001), ly / max(hh, 0.0001))
        }
        if physCache.count > 200 { physCache.removeAll() }
        physCache[ck] = (key, out)
        return out
    }

    // one parent's mesh state at one time, reused for every pin
    struct PCtx { let pm: [Float]; let inv: [Float]; let hw: Float; let hh: Float; let pins: [(Float, Float, Float, Float)]; let stiff: Float }
    static func pctx(_ parent: Layer, _ t: Float) -> PCtx? {
        guard parent.type != .GROUP, let pp = parent.puppet, pp.on, !pp.pins.isEmpty else { return nil }
        let pm = Xf.matrix(parent, t)
        guard let inv = Xf.invert(pm) else { return nil }
        let qs = Xf.puppetQuad(parent)
        return PCtx(pm: pm, inv: inv, hw: max(qs.0 / 2, 0.0001), hh: max(qs.1 / 2, 0.0001),
                    pins: activePins(parent, pp, t), stiff: pp.stiffness)
    }
    static func follow(_ c: PCtx?, _ wx: Float, _ wy: Float) -> (Float, Float) {
        guard let c = c else { return (0, 0) }
        let lp = Xf.apply(c.inv, wx, wy)
        let d = disp(c.pins, c.stiff, lp.0 / c.hw, lp.1 / c.hh)
        let w1 = Xf.apply(c.pm, lp.0 + d.0 * c.hw, lp.1 + d.1 * c.hh)
        return (w1.0 - wx, w1.1 - wy)
    }

    // ---- parent puppet follow (used by Physics sway) --------------------------------------------
    /// A layer with an enabled Physics sway and a parent follows the parent's puppet: the point where it hangs on the
    /// parent moves with the parent's deformed mesh (pins keyed, dragged or swaying), not only with its transform.
    static func followsParentPuppet(_ l: Layer) -> Bool {
        guard l.parentId >= 0, let p = l.puppet, p.on, p.swayOn else { return false }
        return p.sways.contains { $0.on && $0.kind == 1 }
    }
    static func parentLayer(_ l: Layer) -> Layer? {
        guard l.parentId >= 0, l.parentId != l.id else { return nil }
        var seen: Set<Int> = [l.id], cur = l.parentId     // stop on parent cycles
        while cur >= 0 {
            if seen.contains(cur) { return nil }
            seen.insert(cur)
            cur = Editor.scene.layers.first(where: { $0.id == cur })?.parentId ?? -1
        }
        return Editor.scene.layers.first(where: { $0.id == l.parentId })
    }
    /// World-space displacement the parent's puppet mesh gives to the world point (wx, wy) at time t.
    static func parentFollow(_ parent: Layer, _ t: Float, _ wx: Float, _ wy: Float) -> (Float, Float) {
        follow(pctx(parent, t), wx, wy)
    }

    /// Offset from rest of one pin at time t (keyed tracks + every sway layer).
    static func offset(_ l: Layer, _ p: Puppet, _ pin: PuppetPin, _ t: Float,
                       _ qs: (Float, Float)? = nil, phys: [Int: [Int: (Float, Float)]]? = nil) -> (Float, Float) {
        var ox = (l.props["pp\(pin.id)x"]?.eval(t) ?? 0) + (l.rigOff["pp\(pin.id)x"] ?? 0)
        var oy = (l.props["pp\(pin.id)y"]?.eval(t) ?? 0) + (l.rigOff["pp\(pin.id)y"] ?? 0)
        let hasSway = p.swayOn && !p.sways.isEmpty
        if !hasSway && p.bends.isEmpty { return (ox, oy) }
        let q = qs ?? Xf.quadSize(l)
        if hasSway {
            for (i, s) in p.sways.enumerated() where s.on && s.chain.contains(pin.id) {
                if s.kind == 0 { let o = waveOffset(p, s, pin, t, q, l); ox += o.0; oy += o.1 }
                else if let o = (phys?[i] ?? physicsOffsets(l, p, s, i, t, q))[pin.id] { ox += o.0; oy += o.1 }
            }
        }
        for (i, b) in p.bends.enumerated() where b.on && b.pins.contains(pin.id) {
            let o = bendOffset(l, p, b, i, pin, t, q); ox += o.0; oy += o.1
        }
        return (ox, oy)
    }

    static func pinPos(_ l: Layer, _ p: Puppet, _ pin: PuppetPin, _ t: Float,
                       _ qs: (Float, Float)? = nil) -> (Float, Float) {
        let o = offset(l, p, pin, t, qs)
        return (pin.rx + o.0, pin.ry + o.1)
    }

    @inline(__always) static func wgt(_ d2: Float, _ pw: Float) -> Float {
        let e = d2 + 0.00001
        return pw == 2 ? 1 / e : pow(e, -pw * 0.5)
    }

    /// Displacement of a rest point (inverse-distance weighted, with a hold
    /// weight so far-away points stay put).
    static func disp(_ pins: [(Float, Float, Float, Float)], _ pw: Float, _ x: Float, _ y: Float) -> (Float, Float) {
        var sx: Float = 0, sy: Float = 0, sw = pow(1.4, -pw)
        for q in pins {
            let dx = x - q.0, dy = y - q.1
            let w = wgt(dx * dx + dy * dy, pw)
            sx += w * q.2; sy += w * q.3; sw += w
        }
        return (sx / sw, sy / sw)
    }

    static func activePins(_ l: Layer, _ p: Puppet, _ t: Float) -> [(Float, Float, Float, Float)] {
        let swOn = p.swayOn && !p.sways.isEmpty
        let qs = (swOn || !p.bends.isEmpty) ? Xf.quadSize(l) : (1, 1)
        var ph: [Int: [Int: (Float, Float)]] = [:]          // each physics sway is solved once for all pins, not once per pin
        if swOn { for (i, s) in p.sways.enumerated() where s.on && s.kind == 1 { ph[i] = physicsOffsets(l, p, s, i, t, qs) } }
        return p.pins.map { let o = offset(l, p, $0, t, qs, phys: ph); return ($0.rx, $0.ry, o.0, o.1) }
    }

    /// Deformed grid vertex positions (aPos space), row-major, (n+1)² points. Cached so the
    /// renderer and the overlay share one computation per change.
    static func gridPositions(_ l: Layer, _ p: Puppet, _ t: Float) -> [Float] {
        let n = segs[p.density]
        let pins = activePins(l, p, t)
        var key: [Float] = [Float(l.id), Float(n), p.stiffness]
        for q in pins { key.append(q.0); key.append(q.1); key.append(q.2); key.append(q.3) }
        let ck = l.id &* 8 &+ p.density
        lock.lock()
        if let c = gCaches[ck], c.key == key { lock.unlock(); return c.out }
        lock.unlock()
        var out = [Float](); out.reserveCapacity((n + 1) * (n + 1) * 2)
        for j in 0...n {
            let y = -1 + 2 * Float(j) / Float(n)
            for i in 0...n {
                let x = -1 + 2 * Float(i) / Float(n)
                let d = disp(pins, p.stiffness, x, y)
                out.append(x + d.0); out.append(y + d.1)
            }
        }
        lock.lock()
        if gCaches.count > 400 { gCaches.removeAll() }
        gCaches[ck] = (key, out); lock.unlock()
        return out
    }

    private static var topoCache: [Int: ([Float], [UInt16])] = [:]
    static func topology(_ n: Int) -> ([Float], [UInt16]) {
        if let c = topoCache[n] { return c }
        var uv = [Float](), idx = [UInt16]()
        for j in 0...n { for i in 0...n { uv.append(Float(i) / Float(n)); uv.append(Float(j) / Float(n)) } }
        for j in 0..<n { for i in 0..<n {
            let a = UInt16(j * (n + 1) + i), b = a + 1, c = a + UInt16(n + 1), d = c + 1
            idx += [a, b, c, b, d, c]
        } }
        topoCache[n] = (uv, idx)
        return (uv, idx)
    }

    /// Mesh for the renderer, or nil when the layer has no active puppet.
    static func mesh(_ l: Layer, _ t: Float) -> (pos: [Float], uv: [Float], idx: [UInt16])? {
        guard let p = l.puppet, p.on, !p.pins.isEmpty else { return nil }
        let (uv, idx) = topology(segs[p.density])
        return (gridPositions(l, p, t), uv, idx)
    }
}

extension Gl {
    /// Draws an indexed triangle mesh: aPos = deformed quad-space position, aUv = rest uv.
    static func drawMesh(_ program: GLProgram, _ pos: [Float], _ uv: [Float], _ idx: [UInt16]) {
        program.use()
        glBindBuffer(GLenum(GL_ARRAY_BUFFER), 0)
        glBindBuffer(GLenum(GL_ELEMENT_ARRAY_BUFFER), 0)
        let aPos = glGetAttribLocation(program.handle, "aPos")
        let aUv = glGetAttribLocation(program.handle, "aUv")
        guard aPos >= 0, aUv >= 0 else { return }
        glEnableVertexAttribArray(GLuint(aPos))
        glEnableVertexAttribArray(GLuint(aUv))
        pos.withUnsafeBufferPointer { pp in
            uv.withUnsafeBufferPointer { up in
                idx.withUnsafeBufferPointer { ip in
                    glVertexAttribPointer(GLuint(aPos), 2, GLenum(GL_FLOAT), GLboolean(GL_FALSE), 8, pp.baseAddress)
                    glVertexAttribPointer(GLuint(aUv), 2, GLenum(GL_FLOAT), GLboolean(GL_FALSE), 8, up.baseAddress)
                    glDrawElements(GLenum(GL_TRIANGLES), GLsizei(idx.count), GLenum(GL_UNSIGNED_SHORT), ip.baseAddress)
                }
            }
        }
        glDisableVertexAttribArray(GLuint(aPos))
        glDisableVertexAttribArray(GLuint(aUv))
    }
}
