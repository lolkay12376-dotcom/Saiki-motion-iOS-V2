// EditorLayers.swift — layer management: add/clone/copy/paste/group/split/trim/menus.

import UIKit

extension EditorViewController {
        @discardableResult
        func addLayer(_ type: LayerType) -> Layer {
            pushUndo()
            let p = Editor.project
            let s = Editor.scene
            let id = p.nextId
            p.nextId += 1
            let nm: String
            switch type {
            case .SHAPE: nm = "Shape"
            case .TEXT: nm = "Text"
            case .IMAGE: nm = "Image"
            case .VIDEO: nm = "Video"
            case .CAMERA: nm = "Camera"
            case .NULL: nm = "Null"
            case .MODEL: nm = "Model"
            case .PARTICLES: nm = "Particles"
            case .GROUP: nm = "Group"
            case .ADJUST: nm = "Adjustment"
            case .AUDIO: nm = "Audio"
            case .FLARE: nm = "Optical Flare"
            }
            let l = Layer(id, "\(nm) \(id)", type)
            l.end = s.duration
            if type == .TEXT { l.color = Int32(bitPattern: 0xFFFFFFFF); if l.text.isEmpty { l.text = "Saiki Text" } }
            if type == .MODEL || type == .CAMERA { l.is3d = true }
            s.layers.append(l)
            if type == .NULL { toast("Turn on the 3D cube (top bar) so this Null can drive other layers") }
            if type == .CAMERA { toast("The camera affects layers below it that have the 3D cube on") }
            onSelect(id)
            return l
        }

        @discardableResult
        func addLight(type: Int = 0, color: UInt32 = 0xFFFFF2D8) -> Layer {
            let l = addLayer(.NULL)
            l.name = "\(Lights.types[type]) Light \(l.id)"
            l.is3d = true
            l.xset("isLight", 1); l.xset("lightInt", 8); l.xset("lightInf", 1); l.xset("lightRad", 0.5); l.xset("lightType", Float(type)); l.xset("lightTemp", 6500)
            l.xset("lightPitch", type == 1 ? -50 : -60); l.xset("lightCone", 40)
            l.xset("atmAmt", 0.3); l.xset("atmCol", Float(0x6688FF))
            l.vdbTint = Int32(bitPattern: color)
            l.track("y").set(Editor.time, 1, false)
            render(); refreshPanel()
            return l
        }

        /// "Particles": an invisible solid carrying the Particular effect (3D, camera-aware, occluded by 3D layers).
        func addParticles() {
            let l = addLayer(.SHAPE)
            l.name = "Particles \(l.id)"
            l.shape = .RECT
            l.is3d = true
            let ar = Float(Editor.project.w) / Float(Editor.project.h)
            l.track("scale").base = min(max(2 * ar, 2) / 0.8 / 0.84 * 1.02, 8)
            l.fx.append("particular")
            l.track("ptShowSrc").base = 0
            expanded.insert("\(l.id):particular")
            fxTab = 0
            panel = P_FX
            showBottom(); refreshPanel()
            openParticularDesigner(l)
        }

        func addStrands() {
            let l = addLayer(.SHAPE)
            l.name = "Organic Strands \(l.id)"
            l.shape = .CIRCLE
            l.is3d = true
            l.fx.append("bccstrands")
            l.track("stShowSrc").base = 0
            expanded.insert("\(l.id):bccstrands")
            fxTab = 0
            panel = P_FX
            showBottom(); refreshPanel()
        }

        func cloneLayer(_ l: Layer, _ suffix: String) -> Layer {
            let c = Layer(Editor.project.nextId, l.name + suffix, l.type)
            Editor.project.nextId += 1
            c.text = l.text; c.color = l.color; c.color2 = l.color2; c.shape = l.shape; c.imagePath = l.imagePath
            c.bold = l.bold; c.italic = l.italic; c.font = l.font; c.fontPath = l.fontPath
            c.strokeW = l.strokeW; c.strokeColor = l.strokeColor; c.spacing = l.spacing
            c.borderW = l.borderW; c.borderColor = l.borderColor; c.borderPad = l.borderPad
            for an in l.anims { c.anims.append(an.copy()) }
            c.start = l.start; c.end = l.end; c.is3d = l.is3d; c.parentId = l.parentId
            c.lockRot = l.lockRot; c.lockScale = l.lockScale; c.lockMove = l.lockMove
            c.blend = l.blend; c.srcDur = l.srcDur; c.visible = l.visible; c.srcOffset = l.srcOffset
            c.vpath = l.vpath; c.mask = l.mask; c.mblur = l.mblur; c.clipIds = l.clipIds; c.clipInv = l.clipInv
            c.tgraph = l.tgraph; c.m3Env = l.m3Env; c.m3Metal = l.m3Metal; c.m3Ao = l.m3Ao; c.occlude = l.occlude; c.m3View = l.m3View; c.vdbDens = l.vdbDens; c.vdbBright = l.vdbBright; c.rtOn = l.rtOn; c.rtInt = l.rtInt; c.rtRad = l.rtRad; c.vdbEnv = l.vdbEnv; c.vdbEnvPath = l.vdbEnvPath; c.vdbSurround = l.vdbSurround; c.vdbTint = l.vdbTint; c.x3s = l.x3s; c.pbrMaps = l.pbrMaps
            c.fx.append(contentsOf: l.fx)
            c.fxOff.formUnion(l.fxOff)
            for (k, v) in l.inputs { c.inputs[k] = v }
            for (k, tr) in l.props {
                let n = c.track(k)
                n.base = tr.base
                n.copyExprFrom(tr)
                for key in tr.keys {
                    let nk = Key(key.t, key.v, key.ease)
                    nk.x1 = key.x1; nk.y1 = key.y1; nk.x2 = key.x2; nk.y2 = key.y2
                    n.keys.append(nk)
                }
            }
            return c
        }

        func targets() -> [Layer] {
            let m = Editor.scene.layers.filter { multi.contains($0.id) }
            if !m.isEmpty { return m }
            if let s = selected() { return [s] }
            return []
        }

        /// Clones layers together with everything inside any group among them, keeping the inner
        /// parent links on the NEW ids. Layers whose parent is not part of the set go to `dest`
        /// (nil = keep their own parent). This is what lets a layer copied out of a group land
        /// outside it, and a copied group bring its contents.
        func cloneSet(_ src: [Layer], suffix: String, dest: Int?) -> [Layer] {
            var all: [Layer] = []
            func add(_ l: Layer) { if !all.contains(where: { $0 === l }) { all.append(l) } }
            for l in src {
                add(l)
                if l.type == .GROUP { for d in PreRender.descendants(of: l, in: Editor.scene) { add(d) } }
            }
            var map: [Int: Layer] = [:]
            var out: [Layer] = []
            for l in all {
                let c = cloneLayer(l, src.contains(where: { $0 === l }) ? suffix : "")
                map[l.id] = c; out.append(c)
            }
            for (l, c) in zip(all, out) {
                if let p = map[l.parentId] { c.parentId = p.id }
                else if let d = dest { c.parentId = d }
            }
            return out
        }

        /// Where a paste lands: beside the selected layer (same group), or the top level if nothing is selected.
        func pasteParent() -> Int {
            if let s = selected() { return s.parentId }
            return -1
        }

        func duplicateSelected() {
            let t = targets()
            if t.isEmpty { toast("Select a layer first"); return }
            pushUndo()
            var last = -1
            let made = cloneSet(t, suffix: " copy", dest: nil)
            for c in made { Editor.scene.layers.append(c) }
            last = made.last?.id ?? -1
            multi.removeAll()
            multiMode = false
            onSelect(last)
        }

        func copySelected() {
            let t = targets()
            if t.isEmpty { toast("Select a layer first"); return }
            clipboard = cloneSet(t, suffix: "", dest: nil)      // contents of copied groups travel with them
            toast("Copied \(t.count)\(t.count == 1 ? " layer" : " layers")")
        }

        func pasteLayers() {
            if clipboard.isEmpty { toast("Nothing copied yet"); return }
            pushUndo()
            let dest = pasteParent()
            // clipboard holds clones whose own parent links are still valid among themselves
            let ids = Set(clipboard.map { $0.id })
            var map: [Int: Layer] = [:]
            var made: [Layer] = []
            for c in clipboard {
                let n = cloneLayer(c, "")
                map[c.id] = n; made.append(n)
            }
            for (c, n) in zip(clipboard, made) {
                if ids.contains(c.parentId), let p = map[c.parentId] { n.parentId = p.id } else { n.parentId = dest }
            }
            for n in made { Editor.scene.layers.append(n) }
            let top = zip(clipboard, made).filter { !ids.contains($0.0.parentId) }.last?.1 ?? made.last
            multi.removeAll()
            multiMode = false
            onSelect(top?.id ?? -1)
        }

        func selectAll() {
            multi.removeAll()
            for l in Editor.scene.layers { multi.append(l.id) }
            if multi.isEmpty { toast("No layers yet"); return }
            selId = multi.last ?? -1
            multiMode = true   // keep the selection alive so Group / Copy / Delete see every layer
            refreshTitle(); refreshToolbar(); render()
            toast("All layers selected")
        }

        func groupSelected(_ asMask: Bool = false) {
            var t = targets()
            if t.isEmpty { toast("Select layers first"); return }
            // a layer whose parent is also selected travels inside that parent
            let ids = Set(t.map { $0.id })
            t = t.filter { !ids.contains($0.parentId) }
            if Set(t.map { $0.parentId }).count > 1 { toast("Select layers that share the same parent group"); return }
            let wasSingle = t.count == 1 && multi.count <= 1
            pushUndo()
            let top = t.compactMap { l in Editor.scene.layers.firstIndex(where: { $0 === l }) }.max() ?? 0
            let g = addLayer(.GROUP)
            var ls = Editor.scene.layers
            ls.removeAll { $0 === g }
            ls.insert(g, at: min(top + 1, ls.count))
            Editor.scene.layers = ls
            g.parentId = t.first?.parentId ?? -1
            for l in t { l.parentId = g.id }
            if asMask {
                // Mask Group: the top layer becomes the alpha matte for everything below it in the group
                g.mask = 1
                g.name = "Mask Group"
                if t.count < 2 { toast("Mask Group needs 2+ layers: the top one is the matte for the rest") }
            }
            var total = t.count
            for r in t { total += PreRender.descendants(of: r, in: Editor.scene).count }   // layers parented to them travel inside too
            multi.removeAll()
            multiMode = false
            onSelect(g.id)
            toast(wasSingle ? "Grouped 1 layer. To group several, use Layers menu > Select Multiple Layers (or Select All) first"
                            : "Grouped \(total) layers")
        }

        func addSolid() {
            let l = addLayer(.SHAPE)
            l.shape = .RECT
            l.name = "Solid \(l.id)"
            l.color = Int32(bitPattern: 0xFF2A2A33)
            let ar = Float(Editor.project.w) / Float(Editor.project.h)
            l.track("scale").base = min(max(2 * ar, 2) / 0.8 / 0.84 * 1.02, 8)
            refreshPanel(); render()
        }

        func deleteLayer() {
            let t = targets()
            if t.isEmpty { return }
            pushUndo()
            // deleting a group deletes everything inside it (no orphaned contents left behind)
            var doomed: [Layer] = []
            for l in t {
                doomed.append(l)
                if l.type == .GROUP { doomed += PreRender.descendants(of: l, in: Editor.scene) }
            }
            for l in doomed {
                Editor.scene.layers.removeAll { $0 === l }
            }
            let gone = Set(doomed.map { $0.id })
            for o in Editor.scene.layers where gone.contains(o.parentId) { o.parentId = -1 }
            multi.removeAll()
            multiMode = false
            onSelect(-1)
        }

        func splitLayer(_ l: Layer, _ t: Float) -> Layer? {
            if t <= l.start + 0.04 || t >= l.end - 0.04 { return nil }
            if l.type == .GROUP { return splitGroup(l, t) }
            let c = cloneLayer(l, "")
            c.name = l.name
            c.start = t
            if l.type == .VIDEO || l.type == .AUDIO { c.srcOffset = l.srcOffset + (t - l.start) }
            l.end = t
            var ls = Editor.scene.layers
            if let i = ls.firstIndex(where: { $0 === l }) { ls.insert(c, at: i + 1) }
            Editor.scene.layers = ls
            return c
        }

        /// Cuts a group in two at `t`: children are split too, and the right-hand halves
        /// (plus children that start after `t`) move into the new second group.
        func splitGroup(_ g: Layer, _ t: Float) -> Layer? {
            let g2 = cloneLayer(g, "")
            g2.name = g.name
            g2.start = t
            g.end = t
            var ls = Editor.scene.layers
            if let i = ls.firstIndex(where: { $0 === g }) { ls.insert(g2, at: i + 1) }
            Editor.scene.layers = ls
            let kids = Editor.scene.layers.filter { $0.parentId == g.id }
            for c in kids {
                if c.end <= t + 0.04 { continue }
                if c.start >= t - 0.04 { c.parentId = g2.id; continue }
                if let c2 = splitLayer(c, t) { c2.parentId = g2.id }
            }
            return g2
        }

        /** Splits the selected layers (or every layer under the playhead) at the playhead. */
        func splitAtPlayhead(_ all: Bool) {
            let t = Editor.time
            let list = all ? Editor.scene.layers : targets()
            if list.isEmpty { toast("Select a layer first"); return }
            pushUndo()
            var last: Layer? = nil
            var n = 0
            for l in list {
                if let c = splitLayer(l, t) { last = c; n += 1 }
            }
            if last == nil { toast("Move the playhead inside the layer to split it"); return }
            multi.removeAll()
            multiMode = false
            toast(n == 1 ? "Layer split" : "Split \(n) layers")
            onSelect(last!.id)
        }

        /** Moves the start or end of the selected layers to the playhead. */
        func trimTo(_ start: Bool) {
            let list = targets()
            if list.isEmpty { toast("Select a layer first"); return }
            let t = Editor.time
            pushUndo()
            var n = 0
            for l in list {
                if l.type == .GROUP { continue }
                if start && t > l.start + 0.04 && t < l.end {
                    if l.type == .VIDEO || l.type == .AUDIO { l.srcOffset += t - l.start }
                    l.start = t; n += 1
                } else if !start && t < l.end - 0.04 && t > l.start {
                    l.end = t; n += 1
                }
            }
            if n == 0 { toast("Move the playhead inside the layer first") } else { render() }
        }

        func moveLayer(_ dir: Int) {
            guard let l = selected() else { return }
            pushUndo()
            var ls = Editor.scene.layers
            guard let i = ls.firstIndex(where: { $0 === l }) else { return }
            let j = i + dir
            if j < 0 || j >= ls.count { return }
            ls.remove(at: i)
            ls.insert(l, at: j)
            Editor.scene.layers = ls
            render()
        }

        func toggle3d() {
            guard let l = selected() else { toast("Select a layer first"); return }
            if l.type == .MODEL || l.type == .CAMERA { toast("This layer is always 3D"); return }
            pushUndo()
            l.is3d = !l.is3d
            refreshTitle(); refreshPanel(); render()
            toast(l.is3d ? "3D on" : "3D off")
        }

        /// Rename the selected layer (name shows in the timeline and the Cubism layer tree).
        func renameLayer(_ l: Layer) {
            let a = UIAlertController(title: "Rename layer", message: nil, preferredStyle: .alert)
            a.addTextField { $0.text = l.name; $0.clearButtonMode = .whileEditing; $0.autocapitalizationType = .sentences }
            a.addAction(UIAlertAction(title: "Cancel", style: .cancel))
            a.addAction(UIAlertAction(title: "Rename", style: .default) { [weak self, weak a] _ in
                let n = (a?.textFields?.first?.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
                guard let self = self, !n.isEmpty, n != l.name else { return }
                self.pushUndo(); l.name = n
                self.refreshTitle(); self.onEdited()
            })
            present(a, animated: true)
        }

        func showLayersMenu() {
            let sh = LayersSheet()
            sh.modalPresentationStyle = .overFullScreen; sh.modalTransitionStyle = .crossDissolve
            let hasSel = selected() != nil
            sh.clipboardReady = !clipboard.isEmpty || propsClip != nil
            typealias It = LayersSheet.Item
            sh.clipTools = [
                It(title: "Copy", icon: "dup", on: hasSel) { [weak self] in self?.copySelected() },
                It(title: "Paste", icon: "import", on: !clipboard.isEmpty) { [weak self] in self?.pasteLayers() },
                It(title: "Properties", icon: "edit", on: hasSel) { [weak self] in self?.showPropertiesMenu() },
                It(title: "Duplicate", icon: "dup", on: hasSel) { [weak self] in self?.duplicateSelected() },
                It(title: "Preset", icon: "bookmark", on: hasSel) { [weak self] in self?.openPanel(P_FX) }]
            sh.pages = [
                [It(title: "Select All Layers", icon: "layers", on: false) { [weak self] in self?.selectAll() },
                 It(title: multiMode ? "Stop Selecting Multiple" : "Select Multiple Layers", icon: "check", on: multiMode) { [weak self] in
                    guard let self = self else { return }
                    self.multiMode = !self.multiMode
                    if !self.multiMode { self.multi.removeAll() }
                    self.render()
                    self.toast(self.multiMode ? "Tap layers to select them" : "Multi select off") },
                 It(title: "Group Layers", icon: "layers", on: false) { [weak self] in self?.groupSelected() },
                 It(title: "Show All Keyframes", icon: "graph", on: false) { [weak self] in self?.timeline.expandAll() },
                 It(title: "Split at Playhead", icon: "split", on: false) { [weak self] in self?.splitAtPlayhead(false) },
                 It(title: "Split All Layers at Playhead", icon: "split", on: false) { [weak self] in self?.splitAtPlayhead(true) },
                 It(title: "Rename Layer", icon: "edit", on: false) { [weak self] in if let l = self?.selected() { self?.renameLayer(l) } }],
                [It(title: "Mask Group", icon: "mask", on: false) { [weak self] in self?.groupSelected(true) },
                 It(title: overlay.guides ? "Hide Grid" : "Show Grid", icon: "grid", on: overlay.guides) { [weak self] in
                    guard let self = self else { return }
                    self.overlay.guides = !self.overlay.guides; self.overlay.setNeedsDisplay() },
                 It(title: "Move Layer Up", icon: "chev_up", on: false) { [weak self] in self?.moveLayer(1) },
                 It(title: "Move Layer Down", icon: "chev_down", on: false) { [weak self] in self?.moveLayer(-1) },
                 It(title: "Set Parent…", icon: "link", on: false) { [weak self] in
                    if let self = self, let l = self.selected() { self.showParentPopup(l, self.parentIcon) } },
                 It(title: "Add Layer…", icon: "plus", on: false) { [weak self] in self?.showAddLayerMenu() },
                 It(title: "Delete Layer", icon: "trash", on: false) { [weak self] in self?.deleteLayer() }]]
            present(sh, animated: true)
        }

        /// Copy the selected layer's animated properties, or paste them onto the selected layer(s).
        func showPropertiesMenu() {
            Dlg(self).setTitle("Properties").setIconItems(["Copy Properties", "Paste Properties"], ["dup", "import"]) { [weak self] _, w in
                guard let self = self else { return }
                if w == 0 {
                    guard let l = self.selected() else { return }
                    self.propsClip = self.cloneLayer(l, ""); self.toast("Properties copied")
                } else {
                    guard let src = self.propsClip else { self.toast("Copy properties first"); return }
                    let targets = self.multiMode && !self.multi.isEmpty ? self.multi.compactMap { id in Editor.scene.layers.first { $0.id == id } }
                                                                       : (self.selected().map { [$0] } ?? [])
                    if targets.isEmpty { self.toast("Select a layer first"); return }
                    self.pushUndo()
                    for t in targets { t.props = self.cloneLayer(src, "").props }
                    self.onEdited(); self.render(); self.toast("Properties pasted")
                }
            }.setNegativeButton("Close", nil).show()
        }

        /// The two-square icon next to the title: add / copy / paste / group /
        /// keyframes / duplicate / parent.
        func showQuickLayerMenu() {
            let labels = ["Add Layer", "Copy Layer", "Paste Layer", "Group Layers",
                          "Show All Keyframes", "Duplicate Layer", "Rename Layer", "Set Parent…"]
            let icons = ["plus", "dup", "import", "layers", "graph", "dup", "edit", "link"]
            Dlg(self).setTitle("Layer").setIconItems(labels, icons) { [weak self] _, w in
                guard let self = self else { return }
                switch w {
                case 0: self.showAddLayerMenu()
                case 1: self.copySelected()
                case 2: self.pasteLayers()
                case 3: self.groupSelected()
                case 4: self.timeline.expandAll()
                case 5: self.duplicateSelected()
                case 6: if let l = self.selected() { self.renameLayer(l) }
                default:
                    if let l = self.selected() { self.showParentPopup(l, self.parentIcon) }
                }
            }.setNegativeButton("Close", nil).show()
        }

        func showAddLayerMenu() {
            let labels = ["Media", "Solid", "Adjustment", "Null", "Shape", "Camera", "Particles", "Group", "Vector Pen", "Organic Strands"]
            let icons = ["media", "solid", "adjust", "nullobj", "shape", "camera", "particles", "layers", "edit", "particles"]
            Dlg(self).setTitle("Add Layer").setIconItems(labels, icons) { [weak self] _, w in
                guard let self = self else { return }
                switch w {
                case 0: self.openPanel(P_MEDIA)
                case 1: self.addSolid()
                case 2: self.addLayer(.ADJUST)
                case 3: self.addLayer(.NULL)
                case 4: self.openPanel(P_SHAPES)
                case 5: self.addLayer(.CAMERA)
                case 6: self.addParticles()
                case 8: self.openPenEditor()
                case 9: self.addStrands()
                default: self.addLayer(.GROUP)
                }
            }.setNegativeButton("Close", nil).show()
        }
}
