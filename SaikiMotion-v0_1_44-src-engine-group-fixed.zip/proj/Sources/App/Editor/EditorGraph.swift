// EditorGraph.swift — the graph editor panel (value plot, easing curve, presets).

import UIKit

extension EditorViewController {
        // ---------------------------------------------------------------- graph

        func buildGraph(_ l: Layer) {
            let p: UIStackView = panelList
            graphOverlayView?.removeFromSuperview(); graphOverlayView = nil
            text(p, "Graph editor", C.TEXT, 16, true)
            // Kotlin props is a HashMap (unordered); sorted here so the chip row is stable.
            let animated = l.props.filter { $0.value.keys.count >= 2 }.map { $0.key }.sorted()
            if animated.isEmpty {
                text(p, "Add two keyframes to a parameter (tap its name, then the keyframe button) or tap a keyframe in the timeline.")
                return
            }
            if !animated.contains(graphProp) { graphProp = animated[0]; graphKey = 0 }
            let chips = chipRow(animated.map { Registry.propDef($0)?.label ?? $0 },
                                animated.firstIndex(of: graphProp) ?? 0) { [weak self] i in
                guard let self = self else { return }
                self.graphProp = animated[i]
                self.graphKey = 0
                self.refreshPanel()
            }
            let tr = l.track(graphProp)
            if tr.keys.count >= 2 {
                graphKey = clamp(graphKey, 0, tr.keys.count - 2)
            }
            guard tr.keys.count >= 2, tr.keys.indices.contains(graphKey) else { return }
            let key = tr.keys[graphKey]
            // the panel: Ease / Value / Speed tabs, curve-type dropdown, draggable knobs, preset column
            let gp = GraphPanelView(key: key)
            gp.tab = graphTab
            gp.title = Registry.propDef(graphProp)?.label ?? graphProp
            gp.segText = "◆\(graphKey + 1) → ◆\(graphKey + 2)"
            gp.onBegin = { [weak self] in self?.pushUndo() }
            gp.onChange = { [weak self] in self?.render() }
            gp.onRefresh = { [weak self] in self?.refreshPanel() }
            gp.onTab = { [weak self] i in self?.graphTab = i; self?.refreshPanel() }
            gp.onClose = { [weak self] in self?.closePanel() }
            gp.onCycleSegment = { [weak self] in
                guard let self = self else { return }
                self.graphKey = (self.graphKey + 1) % max(tr.keys.count - 1, 1)
                self.refreshPanel()
            }
            gp.onCopy = { [weak self] in
                self?.curveClip = Key(0, 0, .CUSTOM)
                self?.curveClip?.copyCurveFrom(key)
                Snack.show("Curve copied (tap the clipboard to paste it elsewhere)")
            }
            gp.onPaste = { [weak self] in
                guard let self = self, let c = self.curveClip else { Snack.show("Long-press the clipboard to copy this curve first"); return }
                self.pushUndo()
                key.copyCurveFrom(c)
                self.refreshPanel(); self.render()
            }
            gp.makeValueView = { [weak self] speed in
                let vg = ValueGraphView(frame: .zero)
                vg.track = tr
                vg.speedMode = speed
                vg.t0 = max(0, (tr.keys.first?.t ?? 0) - 0.3)
                vg.t1 = max(vg.t0 + 0.5, (tr.keys.last?.t ?? 1) + 0.3)
                vg.selIdx = self?.graphKey ?? 0
                vg.onPick = { [weak self] i in
                    guard let self = self else { return }
                    if tr.keys.count >= 2 { self.graphKey = clamp(i, 0, tr.keys.count - 2) }
                    if tr.keys.indices.contains(i) { Editor.time = tr.keys[i].t }
                    self.onTimeChanged(); self.refreshPanel()
                }
                return vg
            }
            gp.build()
            presentGraphOverlay(gp, chips: chips)     // big panel over the lower part of the screen (the preview stays visible above)
            text(p, "Drag the knobs: green = strength, orange = count (drag sideways). Right: pick a curve type, then a preset. ⋯ = copy / paste / save.", C.DIM, 12)
            addPlain(p, "Keyframe time (s)", 0, Editor.scene.duration, key.t, 2) { [weak self] v in
                key.t = v
                tr.keys.sort { $0.t < $1.t }
                self?.render()
            }
            if let pd = Registry.propDef(graphProp) {
                addPlain(p, "Keyframe value", pd.min, pd.max, key.v, pd.dec) { [weak self] v in
                    key.v = v
                    self?.render()
                }
            }
            put(p, pill("Apply this curve to every segment") { [weak self] in
                guard let self = self else { return }
                self.pushUndo()
                for k in tr.keys { k.copyCurveFrom(key) }
                self.render()
            }, 42)
        }
}


extension EditorViewController {
    /// The graph editor as a large panel (portrait: bottom ~58% of the screen, landscape: right ~56%) instead of a 292 pt strip inside the small bottom panel.
    func presentGraphOverlay(_ gp: GraphPanelView, chips: UIView) {
        graphOverlayView?.removeFromSuperview()
        let host: UIView = view
        let box = UIView()
        box.backgroundColor = argbToUIColor(Int32(bitPattern: 0xFF141416))
        box.layer.cornerRadius = 16; box.clipsToBounds = true
        for v in [box, chips, gp] { v.translatesAutoresizingMaskIntoConstraints = false }
        box.addSubview(chips); box.addSubview(gp)
        host.addSubview(box)
        var cs: [NSLayoutConstraint] = [
            chips.topAnchor.constraint(equalTo: box.topAnchor, constant: 6),
            chips.leadingAnchor.constraint(equalTo: box.leadingAnchor, constant: 8),
            chips.trailingAnchor.constraint(equalTo: box.trailingAnchor, constant: -8),
            chips.heightAnchor.constraint(equalToConstant: 40),
            gp.topAnchor.constraint(equalTo: chips.bottomAnchor, constant: 2),
            gp.leadingAnchor.constraint(equalTo: box.leadingAnchor),
            gp.trailingAnchor.constraint(equalTo: box.trailingAnchor),
            gp.bottomAnchor.constraint(equalTo: box.bottomAnchor)]
        let g = host.safeAreaLayoutGuide
        if host.bounds.width > host.bounds.height {
            cs += [box.trailingAnchor.constraint(equalTo: host.trailingAnchor), box.topAnchor.constraint(equalTo: g.topAnchor),
                   box.bottomAnchor.constraint(equalTo: g.bottomAnchor), box.widthAnchor.constraint(equalTo: host.widthAnchor, multiplier: 0.56)]
        } else {
            cs += [box.leadingAnchor.constraint(equalTo: host.leadingAnchor), box.trailingAnchor.constraint(equalTo: host.trailingAnchor),
                   box.bottomAnchor.constraint(equalTo: g.bottomAnchor), box.heightAnchor.constraint(equalTo: host.heightAnchor, multiplier: 0.58)]
        }
        NSLayoutConstraint.activate(cs)
        graphOverlayView = box
    }
}
