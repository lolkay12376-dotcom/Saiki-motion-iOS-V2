//
//  EditorPointMap.swift — Properties tab for imported .ply / .spz point maps:
//  density, point size, animation, and the collider mesh (occlusion).
//
import UIKit

extension EditorViewController {
    func buildPointMap(_ p: UIStackView, _ l: Layer) {
        guard l.type == .MODEL, let path = l.imagePath, PlyImport.isPointMap(path) else { return }
        func xs(_ label: String, _ lo: Float, _ hi: Float, _ key: String, _ def: Float, _ dec: Int = 2) {
            let r = RulerSlider(frame: .zero); r.label = label; r.lo = lo; r.hi = hi; r.dec = dec; r.value = l.xf(key, def)
            r.onBegin = { [weak self] in self?.pushUndo() }
            r.onChange = { [weak self] v in l.xset(key, v); self?.render() }
            put(p, r, 90)
        }
        func sw(_ label: String, _ key: String, _ def: Float) {
            let s = SwitchRow(); s.label = label; s.on = l.xf(key, def) > 0.5
            s.onToggle = { [weak self] v in self?.pushUndo(); l.xset(key, v ? 1 : 0); self?.render() }
            put(p, s, 46)
        }
        text(p, "Point map", C.TEXT, 14, true)
        text(p, "\(PlyImport.pointCount(path)) points loaded (you can re-import to pick a different quality).", C.DIM, 12)
        xs("Density (fewer / more points)", 0.005, 1, "ptDensity", 1, 3)
        xs("Point size", 0.5, 20, "ptSize", 3, 1)
        text(p, "Animation", C.TEXT, 13, true)
        p.addArrangedSubview(chipRow(["Off", "Ripple", "Shimmer", "Scan", "Burst", "Twist"], Int(l.xf("ptAnim", 0))) { [weak self] i in
            self?.pushUndo(); l.xset("ptAnim", Float(i)); self?.render()
        })
        xs("Animation amount", 0, 3, "ptAmt", 1)
        xs("Animation speed", 0, 4, "ptSpeed", 1)
        text(p, "Collider mesh", C.TEXT, 13, true)
        sw("Physical collision (3D objects can't pass through it)", "colPhys", 1)
        xs("Object collision size", 0.1, 2, "colRadius", 0.5)
        text(p, "A triangle mesh of the scene (walls, floor). It is invisible, but hides the points and any 3D object that is behind it. A mesh inside the imported .ply is used automatically; or import one here (.ply with faces, or .obj) in the same coordinates.", C.DIM, 12)
        put(p, pill(PlyImport.hasCollider(path) ? "Replace collider mesh (.ply / .obj)" : "Import collider mesh (.ply / .obj)", "import") { [weak self] in
            self?.pickFile(R_COLLIDER, colliderTypes())
        }, 44)
        if PlyImport.hasCollider(path) {
            sw("Occlusion (hide what is behind the collider)", "colOcc", 1)
            sw("Show collider mesh", "colShow", 0)
            put(p, pill("Remove collider", "export") { [weak self] in
                guard let self = self, let g = PlyImport.removeCollider(fromPointMap: path) else { return }
                self.pushUndo(); l.imagePath = g
                self.preview.warm(g); FrameCache.bump(); self.refreshPanel(); self.render()
            }, 42)
            text(p, "Objects must be drawn after (above) the point map layer in the layer list to be hidden by the wall.", C.DIM, 12)
        }
    }
}
