// Physics3D.swift — secondary motion on top of the pose.
//  * VRM spring bones (VRMC_springBone 1.0 and extensions.VRM.secondaryAnimation 0.x): verlet tail per joint,
//    stiffness / drag / gravity / hit radius / sphere + capsule colliders (same model as three-vrm).
//  * PMX rigid bodies + joints: verlet particles pulled to their bone, joined by distance constraints,
//    colliding with the kinematic bodies (head, body, legs ...). Result is written back as bone positions / rotations.
// All values are in model space (the skeleton's own space), so layer moves do not feed the simulation.

import Foundation
import simd

struct SpringJoint {
    var bone: Int
    var tailLocal: SIMD3<Float>          // rest tail position in the bone's local frame
    var stiffness: Float
    var drag: Float
    var gravity: Float
    var gravityDir: SIMD3<Float>
    var radius: Float
    var groups: [Int]                    // indices into Physics3D.groups
}

struct PhysCollider {
    var bone: Int
    var offset: SIMD3<Float>             // bone-local
    var tail: SIMD3<Float>?              // capsule end (bone-local); nil = sphere
    var radius: Float
    var inside = false
}

struct PmxBody {
    var bone: Int
    var group: Int
    var mask: Int
    var shape: Int                       // 0 sphere, 1 box, 2 capsule
    var size: SIMD3<Float>
    var pos: SIMD3<Float>                // model space at bind
    var rot: simd_quatf
    var mass: Float
    var linDamp: Float
    var angDamp: Float
    var repulsion: Float
    var friction: Float
    var mode: Int                        // 0 follow bone, 1 physics, 2 physics + bone alignment
}

struct PmxJoint {
    var a: Int, b: Int
    var pos: SIMD3<Float>
    var moveLo: SIMD3<Float>, moveHi: SIMD3<Float>
    var rotLo: SIMD3<Float>, rotHi: SIMD3<Float>
    var springMove: SIMD3<Float>, springRot: SIMD3<Float>
}

final class Physics3D {
    static let sub: Float = 1.0 / 60.0

    var springs: [SpringJoint] = []
    var colliders: [PhysCollider] = []
    var groups: [[Int]] = []
    var bodies: [PmxBody] = []
    var joints: [PmxJoint] = []
    var gravityUnits: Float = 98         // PMX gravity in model units per second squared (1 unit ~ 8 cm)
    var lastT: Float? = nil
    /// Inputs set by the viewport every frame.
    var worldXf = matrix_identity_float4x4      // model space -> world (any move / rotate / scale of the layer makes inertia)
    var windWorld = SIMD3<Float>.zero           // world-space wind acceleration
    var groundY: Float? = nil                   // world-space floor (collision)
    var disturb = false                         // the pose was edited this frame
    private var prevXf: simd_float4x4? = nil
    private var awake: Float = 0                // seconds of simulation left after the last disturbance
    private var windLocal = SIMD3<Float>.zero
    private var invXf = matrix_identity_float4x4
    private var xfScale: Float = 1

    var active: Bool { !springs.isEmpty || bodies.contains { $0.mode != 0 && $0.bone >= 0 } }

    // derived / state
    private var acc: Float = 0
    private var prepared = false
    private var springOf: [Int] = []
    private var cur: [SIMD3<Float>] = [], prv: [SIMD3<Float>] = []
    private var springInit: [Bool] = []
    private var dyn: [Int] = [], kin: [Int] = []
    private var bodiesOf: [[Int]] = []
    private var childDriven: [Int] = []
    private var bodyOff: [SIMD3<Float>] = []
    private var pp: [SIMD3<Float>] = [], pq: [SIMD3<Float>] = []
    private var tgt: [SIMD3<Float>] = [], kAxis: [SIMD3<Float>] = []
    private var ks: [Float] = [], prad: [Float] = [], krad: [Float] = [], khalf: [Float] = [], invM: [Float] = []
    private var axisLocal: [SIMD3<Float>] = []
    private var jRest: [Float] = []
    private var pInit = false
    private var pInitPending: Bool { !pInit }

    // MARK: helpers
    private static func pos(_ m: simd_float4x4) -> SIMD3<Float> { SIMD3<Float>(m.columns.3.x, m.columns.3.y, m.columns.3.z) }
    private static func xyz(_ v: SIMD4<Float>) -> SIMD3<Float> { SIMD3<Float>(v.x, v.y, v.z) }
    private static func norm(_ v: SIMD3<Float>, _ d: SIMD3<Float> = SIMD3<Float>(0, 1, 0)) -> SIMD3<Float> {
        let l = simd_length(v); return l > 1e-9 ? v / l : d
    }
    /// Rotation of a matrix (scale removed).
    static func rotQ(_ m: simd_float4x4) -> simd_quatf {
        let x = norm(xyz(m.columns.0), SIMD3<Float>(1, 0, 0))
        var y = xyz(m.columns.1); y = norm(y - simd_dot(y, x) * x, SIMD3<Float>(0, 1, 0))
        let z = simd_cross(x, y)
        return simd_quatf(simd_float3x3(columns: (x, y, z)))
    }
    private static func closest(_ p: SIMD3<Float>, _ a: SIMD3<Float>, _ b: SIMD3<Float>) -> SIMD3<Float> {
        let ab = b - a, l2 = simd_dot(ab, ab)
        if l2 < 1e-12 { return a }
        return a + ab * min(max(simd_dot(p - a, ab) / l2, 0), 1)
    }

    // MARK: setup
    private func prepare(_ sk: Skeleton3D) {
        let n = sk.bones.count
        springOf = [Int](repeating: -1, count: n)
        for (k, s) in springs.enumerated() where s.bone >= 0 && s.bone < n { springOf[s.bone] = k }
        cur = [SIMD3<Float>](repeating: .zero, count: springs.count); prv = cur
        springInit = [Bool](repeating: false, count: springs.count)

        let nb = bodies.count
        bodiesOf = [[Int]](repeating: [], count: n)
        dyn = []; kin = []
        bodyOff = [SIMD3<Float>](repeating: .zero, count: nb)
        tgt = bodyOff; kAxis = bodyOff; axisLocal = bodyOff; pp = bodyOff; pq = bodyOff
        ks = [Float](repeating: 0, count: nb); prad = ks; krad = ks; khalf = ks; invM = ks
        for (k, b) in bodies.enumerated() {
            let valid = b.bone >= 0 && b.bone < n
            bodyOff[k] = valid ? b.pos - Physics3D.pos(sk.bones[b.bone].bindWorld) : b.pos
            if b.mode != 0 && valid { dyn.append(k); bodiesOf[b.bone].append(k) } else { kin.append(k) }
            // collision shape
            let s = b.size
            switch b.shape {
            case 0: krad[k] = s.x; khalf[k] = 0; axisLocal[k] = SIMD3<Float>(0, 1, 0); prad[k] = s.x
            case 2: krad[k] = s.x; khalf[k] = max(s.y, 0) * 0.5; axisLocal[k] = SIMD3<Float>(0, 1, 0); prad[k] = s.x
            default:                              // box (half extents): capsule along the longest side
                let m = max(s.x, max(s.y, s.z))
                let ax: SIMD3<Float> = m == s.x ? SIMD3<Float>(1, 0, 0) : (m == s.y ? SIMD3<Float>(0, 1, 0) : SIMD3<Float>(0, 0, 1))
                let others = [s.x, s.y, s.z].sorted()
                krad[k] = others[0]; khalf[k] = max(m - others[0], 0); axisLocal[k] = ax; prad[k] = others[0]
            }
            invM[k] = 1 / min(max(b.mass, 0.05), 20)
        }
        // rest pull per dynamic body: stronger for "physics + bone alignment" and for stiff joints
        var sum = [Float](repeating: 0, count: nb), cnt = sum
        for j in joints {
            let rotSum: Float = abs(j.springRot.x) + abs(j.springRot.y) + abs(j.springRot.z)
            let moveSum: Float = abs(j.springMove.x) + abs(j.springMove.y) + abs(j.springMove.z)
            let st: Float = (rotSum + moveSum) / 6
            for k in [j.a, j.b] where k >= 0 && k < nb { sum[k] += st; cnt[k] += 1 }
        }
        for k in 0..<nb {
            var v: Float = bodies[k].mode == 2 ? 0.3 : 0.02
            if cnt[k] > 0 { v += min(sum[k] / cnt[k] / 300, 1) * 0.2 }
            ks[k] = min(v, 0.5)
        }
        jRest = joints.map { j in
            guard j.a >= 0, j.a < nb, j.b >= 0, j.b < nb else { return 0 }
            return simd_length(bodies[j.a].pos - bodies[j.b].pos)
        }
        childDriven = [Int](repeating: -1, count: n)
        for (i, b) in sk.bones.enumerated() where b.parent >= 0 && b.parent < n && b.parent != i && !bodiesOf[i].isEmpty && childDriven[b.parent] < 0 {
            childDriven[b.parent] = i
        }
        prepared = true
    }

    // MARK: solve
    /// Final world matrices (pose + physics) for time `t`.
    func solve(_ sk: Skeleton3D, t: Float, wall: Float) -> [simd_float4x4] {
        var reset = false
        if !prepared || springOf.count != sk.bones.count { prepare(sk); reset = true }
        var dt: Float = 0
        var wake = disturb; disturb = false
        if let lt = lastT {
            let d = t - lt
            if abs(d) <= 1e-5 { dt = 0 }                              // paused: nothing moves on its own
            else if d > 0 && d <= 0.25 { dt = d; wake = true }
            else { reset = true }
        } else { reset = true }
        lastT = t
        invXf = worldXf.inverse
        xfScale = max(simd_length(SIMD3<Float>(worldXf.columns.0.x, worldXf.columns.0.y, worldXf.columns.0.z)), 1e-6)
        if let px = prevXf, !reset, !pInitPending {
            let D = invXf * px                                       // old model space -> new model space (the world stays put = inertia)
            var dev: Float = 0
            for c in 0..<4 { let e = D[c] - matrix_identity_float4x4[c]; dev += abs(e.x) + abs(e.y) + abs(e.z) }
            if dev > 1e-6 {
                wake = true
                func xp(_ p: SIMD3<Float>) -> SIMD3<Float> { Physics3D.xyz(D * SIMD4<Float>(p.x, p.y, p.z, 1)) }
                for i in cur.indices { cur[i] = xp(cur[i]); prv[i] = xp(prv[i]) }
                for k in pp.indices { pp[k] = xp(pp[k]); pq[k] = xp(pq[k]) }
            }
        }
        prevXf = worldXf
        windLocal = Physics3D.xyz(invXf * SIMD4<Float>(windWorld.x, windWorld.y, windWorld.z, 0))
        if simd_length(windLocal) > 1e-6 { wake = true }
        if wake { awake = 1.5 }
        if dt == 0 && awake > 0 { dt = min(max(wall, 0), 0.05) }    // let it settle after a disturbance, then sleep
        awake = max(0, awake - max(wall, 0))
        if reset { acc = 0; for i in 0..<springInit.count { springInit[i] = false }; pInit = false }
        let pw = sk.poseWorld()
        if !pInit { initParticles(sk, pw); pInit = true }
        acc += dt
        var steps = 0
        while acc >= Physics3D.sub - 1e-5 && steps < 8 { _ = pass(sk, pw, true); acc -= Physics3D.sub; steps += 1 }
        if steps >= 8 { acc = 0 }
        return pass(sk, pw, false)
    }

    private func pass(_ sk: Skeleton3D, _ pw: [simd_float4x4], _ integrate: Bool) -> [simd_float4x4] {
        let n = sk.bones.count
        var fw = [simd_float4x4](repeating: matrix_identity_float4x4, count: n)
        if integrate { stepParticles(sk, pw) }
        for i in sk.order() {
            let b = sk.bones[i]
            let hasP = b.parent >= 0 && b.parent < n && b.parent != i
            let pm = hasP ? fw[b.parent] : matrix_identity_float4x4
            let M = pm * Skeleton3D.local(b)
            if springOf[i] >= 0 { fw[i] = spring(springOf[i], M, pw, integrate); continue }
            if !bodiesOf[i].isEmpty {
                var dq = simd_quatf(ix: 0, iy: 0, iz: 0, r: 1)
                if hasP { dq = Physics3D.rotQ(pm) * Physics3D.rotQ(pw[b.parent]).inverse }
                fw[i] = driven(i, M, dq, pw)
                continue
            }
            fw[i] = M
        }
        return fw
    }

    // MARK: VRM spring bones
    private func spring(_ si: Int, _ M: simd_float4x4, _ pw: [simd_float4x4], _ integrate: Bool) -> simd_float4x4 {
        let s = springs[si]
        let head = Physics3D.pos(M)
        let tailRest = Physics3D.xyz(M * SIMD4<Float>(s.tailLocal.x, s.tailLocal.y, s.tailLocal.z, 1))
        let len = max(simd_length(tailRest - head), 1e-5)
        if !springInit[si] { cur[si] = tailRest; prv[si] = tailRest; springInit[si] = true }
        if integrate {
            let h = Physics3D.sub
            let dir = (tailRest - head) / len
            let inertia = (cur[si] - prv[si]) * (1 - min(max(s.drag, 0), 1))
            var next = cur[si] + inertia + dir * (s.stiffness * h) + s.gravityDir * (s.gravity * h) + windLocal * (h * h)
            next = head + Physics3D.norm(next - head, dir) * len
            for gi in s.groups where gi >= 0 && gi < groups.count {
                for ci in groups[gi] where ci >= 0 && ci < colliders.count {
                    let c = colliders[ci]
                    guard c.bone >= 0, c.bone < pw.count else { continue }
                    let W = pw[c.bone]
                    let a = Physics3D.xyz(W * SIMD4<Float>(c.offset.x, c.offset.y, c.offset.z, 1))
                    var cp = a
                    if let t = c.tail { cp = Physics3D.closest(next, a, Physics3D.xyz(W * SIMD4<Float>(t.x, t.y, t.z, 1))) }
                    let d = next - cp, dist = simd_length(d)
                    if c.inside {
                        let r = max(c.radius - s.radius, 0)
                        if dist > r { next = cp + (dist > 1e-9 ? d / dist : SIMD3<Float>(0, r, 0)) * r }
                    } else {
                        let r = c.radius + s.radius
                        if dist < r { next = cp + (dist > 1e-9 ? d / dist : SIMD3<Float>(0, 1, 0)) * r }
                    }
                }
            }
            if let gy = groundY {                                    // floor collision (world space)
                var wp = worldXf * SIMD4<Float>(next.x, next.y, next.z, 1)
                let r = s.radius * xfScale
                if wp.y < gy + r { wp.y = gy + r; next = Physics3D.xyz(invXf * wp) }
            }
            next = head + Physics3D.norm(next - head, dir) * len
            prv[si] = cur[si]; cur[si] = next
        }
        let inv = M.inverse
        let ln = Physics3D.xyz(inv * SIMD4<Float>(cur[si].x, cur[si].y, cur[si].z, 1))
        let a = Physics3D.norm(s.tailLocal), b = Physics3D.norm(ln, a)
        let q = simd_quatf(from: a, to: b)
        return M * simd_float4x4(q)
    }

    // MARK: PMX rigid bodies
    private func target(_ k: Int, _ sk: Skeleton3D, _ pw: [simd_float4x4]) -> SIMD3<Float> {
        let b = bodies[k]
        guard b.bone >= 0, b.bone < pw.count else { return b.pos }
        return Physics3D.pos(pw[b.bone]) + Physics3D.rotQ(pw[b.bone]).act(bodyOff[k])
    }

    private func initParticles(_ sk: Skeleton3D, _ pw: [simd_float4x4]) {
        for k in 0..<bodies.count { tgt[k] = target(k, sk, pw); pp[k] = tgt[k]; pq[k] = tgt[k] }
    }

    private func stepParticles(_ sk: Skeleton3D, _ pw: [simd_float4x4]) {
        guard !dyn.isEmpty else { return }
        let h = Physics3D.sub, nb = bodies.count
        for k in 0..<nb {
            tgt[k] = target(k, sk, pw)
            let b = bodies[k]
            if b.bone >= 0, b.bone < pw.count { kAxis[k] = Physics3D.rotQ(pw[b.bone]).act(b.rot.act(axisLocal[k])) } else { kAxis[k] = b.rot.act(axisLocal[k]) }
        }
        let hh: Float = h * h
        let g = SIMD3<Float>(0, -gravityUnits * hh, 0) + windLocal * (hh * gravityUnits / 9.8)
        for k in dyn {
            let b = bodies[k]
            let damp = powf(max(1 - min(max(b.linDamp, 0), 0.99), 0.01), h)
            let v = (pp[k] - pq[k]) * damp
            var np = pp[k] + v + g
            np += (tgt[k] - np) * ks[k]
            pq[k] = pp[k]; pp[k] = np
        }
        func position(_ k: Int) -> SIMD3<Float> { (bodies[k].mode != 0 && bodies[k].bone >= 0 && bodies[k].bone < pw.count) ? pp[k] : tgt[k] }
        func isDyn(_ k: Int) -> Bool { bodies[k].mode != 0 && bodies[k].bone >= 0 && bodies[k].bone < pw.count }
        for _ in 0..<6 {
            for (ji, j) in joints.enumerated() {
                guard j.a >= 0, j.a < nb, j.b >= 0, j.b < nb, ji < jRest.count, jRest[ji] > 1e-7 else { continue }
                let da = isDyn(j.a), db = isDyn(j.b)
                if !da && !db { continue }
                let d = position(j.b) - position(j.a), dist = simd_length(d)
                guard dist > 1e-7 else { continue }
                let diff = (dist - jRest[ji]) / dist
                let wa: Float = da ? invM[j.a] : 0, wb: Float = db ? invM[j.b] : 0
                let ws = wa + wb
                if da { pp[j.a] += d * diff * (wa / ws) }
                if db { pp[j.b] -= d * diff * (wb / ws) }
            }
            for k in dyn {
                for c in kin {
                    if bodies[k].mask & (1 << min(max(bodies[c].group, 0), 15)) == 0 { continue }
                    if bodies[c].mask & (1 << min(max(bodies[k].group, 0), 15)) == 0 { continue }
                    let rr = prad[k] + krad[c]
                    var cp = tgt[c]
                    if khalf[c] > 0 { cp = Physics3D.closest(pp[k], tgt[c] - kAxis[c] * khalf[c], tgt[c] + kAxis[c] * khalf[c]) }
                    let d = pp[k] - cp, dist = simd_length(d)
                    if dist < rr { pp[k] = cp + (dist > 1e-7 ? d / dist : SIMD3<Float>(0, 1, 0)) * rr }
                }
                if let gy = groundY {
                    var wp = worldXf * SIMD4<Float>(pp[k].x, pp[k].y, pp[k].z, 1)
                    let r = prad[k] * xfScale
                    if wp.y < gy + r { wp.y = gy + r; pp[k] = Physics3D.xyz(invXf * wp) }
                }
            }
        }
    }

    private func drivenPos(_ i: Int, _ pw: [simd_float4x4]) -> SIMD3<Float>? {
        let ks = bodiesOf[i]
        guard !ks.isEmpty else { return nil }
        let q = Physics3D.rotQ(pw[i])
        var s = SIMD3<Float>.zero
        for k in ks { s += pp[k] - q.act(bodyOff[k]) }
        return s / Float(ks.count)
    }

    /// World matrix of a bone driven by rigid bodies: position from the particles, orientation toward the driven child
    /// (or inheriting the parent's physics rotation).
    private func driven(_ i: Int, _ M: simd_float4x4, _ dq: simd_quatf, _ pw: [simd_float4x4]) -> simd_float4x4 {
        guard let P = drivenPos(i, pw) else { return M }
        let rp = Physics3D.rotQ(pw[i])
        var q = dq
        let c = childDriven[i]
        if c >= 0, let Pc = drivenPos(c, pw) {
            let dp = Physics3D.pos(pw[c]) - Physics3D.pos(pw[i]), dn = Pc - P
            if simd_length(dp) > 1e-6, simd_length(dn) > 1e-6 { q = simd_quatf(from: simd_normalize(dp), to: simd_normalize(dn)) }
        }
        var m = simd_float4x4(simd_normalize(q * rp))
        m.columns.3 = SIMD4<Float>(P.x, P.y, P.z, 1)
        return m
    }

    // MARK: VRM import
    /// Glb nodes that need a bone for the spring simulation (spring joints, their descendants for VRM 0.x, collider nodes).
    static func springNodes(_ json: JObj, count: Int, children: (Int) -> [Int]) -> Set<Int> {
        var out = Set<Int>()
        func add(_ n: Int) { if n >= 0, n < count { out.insert(n) } }
        let ext = json.optJSONObject("extensions")
        if let sb = ext?.optJSONObject("VRMC_springBone") {
            if let cs = sb.optJSONArray("colliders") { for i in 0..<cs.count { add(cs.optJSONObject(i)?.optInt("node", -1) ?? -1) } }
            if let ss = sb.optJSONArray("springs") {
                for i in 0..<ss.count {
                    guard let js = ss.optJSONObject(i)?.optJSONArray("joints") else { continue }
                    for k in 0..<js.count { add(js.optJSONObject(k)?.optInt("node", -1) ?? -1) }
                }
            }
        } else if let sa = ext?.optJSONObject("VRM")?.optJSONObject("secondaryAnimation") {
            if let cg = sa.optJSONArray("colliderGroups") { for i in 0..<cg.count { add(cg.optJSONObject(i)?.optInt("node", -1) ?? -1) } }
            if let bg = sa.optJSONArray("boneGroups") {
                for i in 0..<bg.count {
                    guard let bs = bg.optJSONObject(i)?.optJSONArray("bones") else { continue }
                    for k in 0..<bs.count {
                        var stack = [bs.optInt(k, -1)], guardN = 0
                        while let n = stack.popLast(), guardN < 5000 {
                            guardN += 1
                            if n < 0 || n >= count || out.contains(n) { continue }
                            out.insert(n); stack += children(n)
                        }
                    }
                }
            }
        }
        return out
    }

    /// Spring bones of a VRM file. `boneOf` maps glb node → bone index.
    static func parseVrm(_ json: JObj, boneOf: [Int: Int], sk: Skeleton3D) -> Physics3D? {
        let ph = Physics3D()
        let ext = json.optJSONObject("extensions")
        func arr3(_ a: JArr?, _ d: SIMD3<Float>) -> SIMD3<Float> {
            guard let a = a, a.count >= 3 else { return d }
            return SIMD3<Float>(a.optFloat(0), a.optFloat(1), a.optFloat(2))
        }
        func obj3(_ o: JObj?, _ d: SIMD3<Float>, flipZ: Bool) -> SIMD3<Float> {
            guard let o = o else { return d }
            let z = o.optFloat("z", d.z)
            return SIMD3<Float>(o.optFloat("x", d.x), o.optFloat("y", d.y), flipZ ? -z : z)
        }
        func tail(_ bone: Int, _ next: Int) -> SIMD3<Float> {
            let t = sk.bones[bone].bindWorld.inverse * sk.bones[next].bindWorld.columns.3
            return SIMD3<Float>(t.x, t.y, t.z)
        }
        func children(_ b: Int) -> [Int] { sk.bones.indices.filter { sk.bones[$0].parent == b && $0 != b } }
        func virtualTail(_ b: Int) -> SIMD3<Float> {
            let rl = sk.bones[b].restLocal.columns.3
            let d = SIMD3<Float>(rl.x, rl.y, rl.z)
            return simd_length(d) > 1e-6 ? simd_normalize(d) * 0.07 : SIMD3<Float>(0, 0.07, 0)
        }

        if let sb = ext?.optJSONObject("VRMC_springBone") {
            var colMap: [Int] = []
            if let cs = sb.optJSONArray("colliders") {
                for i in 0..<cs.count {
                    guard let c = cs.optJSONObject(i), let bi = boneOf[c.optInt("node", -1)], let sh = c.optJSONObject("shape") else { colMap.append(-1); continue }
                    var col = PhysCollider(bone: bi, offset: .zero, tail: nil, radius: 0, inside: false)
                    if let s = sh.optJSONObject("sphere") {
                        col.offset = arr3(s.optJSONArray("offset"), .zero); col.radius = s.optFloat("radius", 0)
                    } else if let s = sh.optJSONObject("capsule") {
                        col.offset = arr3(s.optJSONArray("offset"), .zero); col.radius = s.optFloat("radius", 0)
                        col.tail = arr3(s.optJSONArray("tail"), .zero)
                    } else { colMap.append(-1); continue }
                    ph.colliders.append(col); colMap.append(ph.colliders.count - 1)
                }
            }
            if let gs = sb.optJSONArray("colliderGroups") {
                for i in 0..<gs.count {
                    var list: [Int] = []
                    if let ca = gs.optJSONObject(i)?.optJSONArray("colliders") {
                        for k in 0..<ca.count { let ci = ca.optInt(k, -1); if ci >= 0, ci < colMap.count, colMap[ci] >= 0 { list.append(colMap[ci]) } }
                    }
                    ph.groups.append(list)
                }
            }
            if let ss = sb.optJSONArray("springs") {
                for i in 0..<ss.count {
                    guard let sp = ss.optJSONObject(i), let js = sp.optJSONArray("joints"), js.count >= 1 else { continue }
                    var gl: [Int] = []
                    if let ga = sp.optJSONArray("colliderGroups") { for k in 0..<ga.count { gl.append(ga.optInt(k, -1)) } }
                    for k in 0..<js.count {
                        guard let j = js.optJSONObject(k), let b = boneOf[j.optInt("node", -1)] else { continue }
                        sk.bones[b].physics = true
                        guard k + 1 < js.count, let nb = boneOf[js.optJSONObject(k + 1)?.optInt("node", -1) ?? -1], nb != b else { continue }
                        ph.springs.append(SpringJoint(bone: b, tailLocal: tail(b, nb),
                                                      stiffness: j.optFloat("stiffness", 1), drag: j.optFloat("dragForce", 0.5),
                                                      gravity: j.optFloat("gravityPower", 0),
                                                      gravityDir: norm3(arr3(j.optJSONArray("gravityDir"), SIMD3<Float>(0, -1, 0))),
                                                      radius: j.optFloat("hitRadius", 0), groups: gl))
                    }
                }
            }
        } else if let sa = ext?.optJSONObject("VRM")?.optJSONObject("secondaryAnimation") {
            var groupsOfNode: [[Int]] = []
            if let cg = sa.optJSONArray("colliderGroups") {
                for i in 0..<cg.count {
                    var list: [Int] = []
                    if let g = cg.optJSONObject(i), let bi = boneOf[g.optInt("node", -1)], let ca = g.optJSONArray("colliders") {
                        for k in 0..<ca.count {
                            guard let c = ca.optJSONObject(k) else { continue }
                            ph.colliders.append(PhysCollider(bone: bi, offset: obj3(c.optJSONObject("offset"), .zero, flipZ: true), tail: nil, radius: c.optFloat("radius", 0), inside: false))
                            list.append(ph.colliders.count - 1)
                        }
                    }
                    groupsOfNode.append(list)
                }
            }
            ph.groups = groupsOfNode
            if let bg = sa.optJSONArray("boneGroups") {
                for i in 0..<bg.count {
                    guard let g = bg.optJSONObject(i), let roots = g.optJSONArray("bones") else { continue }
                    let stiff = g.has("stiffiness") ? g.optFloat("stiffiness", 1) : g.optFloat("stiffness", 1)
                    let drag = g.optFloat("dragForce", 0.4), gp = g.optFloat("gravityPower", 0), hit = g.optFloat("hitRadius", 0.02)
                    let gd = norm3(obj3(g.optJSONObject("gravityDir"), SIMD3<Float>(0, -1, 0), flipZ: true))
                    var gl: [Int] = []
                    if let ga = g.optJSONArray("colliderGroups") { for k in 0..<ga.count { gl.append(ga.optInt(k, -1)) } }
                    var done = Set<Int>()
                    func visit(_ b: Int, _ depth: Int) {
                        guard depth < 256, !done.contains(b) else { return }
                        done.insert(b)
                        sk.bones[b].physics = true
                        let ch = children(b)
                        let t = ch.first.map { tail(b, $0) } ?? virtualTail(b)
                        ph.springs.append(SpringJoint(bone: b, tailLocal: t, stiffness: stiff, drag: drag, gravity: gp, gravityDir: gd, radius: hit, groups: gl))
                        for c in ch { visit(c, depth + 1) }
                    }
                    for k in 0..<roots.count { if let b = boneOf[roots.optInt(k, -1)] { visit(b, 0) } }
                }
            }
        }
        return ph.springs.isEmpty ? nil : ph
    }

    private static func norm3(_ v: SIMD3<Float>) -> SIMD3<Float> { norm(v, SIMD3<Float>(0, -1, 0)) }
}
