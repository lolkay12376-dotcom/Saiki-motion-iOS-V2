// Lights.swift — scene lights for the 3D editor and the model renderer (Render).
//
// A light is a 3D Null flagged "isLight". Settings (all stored as layer xf values):
//   lightType   0 point, 1 sun (parallel), 2 spot
//   lightInt    intensity            lightTemp  colour temperature in Kelvin (6500 = neutral)
//   lightRange  reach, 0 = unlimited lightCone  spot outer angle (deg)   lightSoft  spot penumbra 0...1
//   lightPitch / lightYaw  direction of a sun / spot (deg)
//   lightDiff / lightSpec  diffuse and specular strength

import Foundation
import simd

enum Lights {
    static let types = ["Point", "Sun", "Spot"]
    static let maxLights = 8

    /// Black-body colour (Tanner Helland fit), normalised so 6500 K is exactly neutral white.
    static func kelvin(_ k: Float) -> SIMD3<Float> {
        func raw(_ kelvin: Float) -> SIMD3<Float> {
            let t = max(1000, min(kelvin, 15000)) / 100
            var r: Float, g: Float, b: Float
            if t <= 66 { r = 255 } else { r = 329.698727446 * pow(t - 60, -0.1332047592) }
            if t <= 66 { g = 99.4708025861 * log(t) - 161.1195681661 } else { g = 288.1221695283 * pow(t - 60, -0.0755148492) }
            if t >= 66 { b = 255 } else if t <= 19 { b = 0 } else { b = 138.5177312231 * log(t - 10) - 305.0447927307 }
            return SIMD3(min(max(r, 0), 255), min(max(g, 0), 255), min(max(b, 0), 255)) / 255
        }
        let c = raw(k), w = raw(6500)
        return SIMD3(c.x / max(w.x, 1e-3), c.y / max(w.y, 1e-3), c.z / max(w.z, 1e-3))
    }

    /// Linear-ish rgb * temperature (no intensity).
    static func tint(_ L: Layer) -> SIMD3<Float> {
        let c = UInt32(bitPattern: L.vdbTint), tc = kelvin(L.xf("lightTemp", 6500))
        return SIMD3(Float((c >> 16) & 255) / 255 * tc.x, Float((c >> 8) & 255) / 255 * tc.y, Float(c & 255) / 255 * tc.z)
    }
    /// Infinite reach = no distance falloff and no range cut-off.
    static func infinite(_ L: Layer) -> Bool { L.xf("lightInf", 1) > 0.5 }

    /// Direction the light travels (from the light into the scene).
    static func direction(_ l: Layer) -> SIMD3<Float> {
        let p = l.xf("lightPitch", -60) * Float.pi / 180, y = l.xf("lightYaw", 30) * Float.pi / 180
        return simd_normalize(SIMD3(cos(p) * sin(y), sin(p), -cos(p) * cos(y)))
    }

    /// Extra colour stop of a multi-colour light (stored as 24-bit rgb inside a Float, exact below 2^24).
    static func stop(_ L: Layer, _ key: String, _ def: Float) -> SIMD3<Float> {
        let c = UInt32(max(0, min(L.xf(key, def), 16777215)))
        let tc = kelvin(L.xf("lightTemp", 6500)), k = L.xf("lightInt", 1)
        return SIMD3(Float((c >> 16) & 255) / 255 * tc.x, Float((c >> 8) & 255) / 255 * tc.y, Float(c & 255) / 255 * tc.z) * k
    }

    /// Up to 8 lights, 8 float4 each, for the model fragment shader (buffer 5):
    ///   [0] position.xyz, type    [1] colour*intensity.rgb, range
    ///   [2] direction.xyz, cos(outer cone)    [3] cos(inner cone), diffuse, specular, active
    ///   [4] colour 2 rgb, number of colours (1...3)    [5] colour 3 rgb, -
    ///   [6] gradient mode (0 radial, 1 around, 2 height), span, -, -    [7] spare
    static func buffer(time: Float) -> (data: [SIMD4<Float>], count: Int) {
        var out = [SIMD4<Float>](repeating: .zero, count: maxLights * 8)
        var n = 0
        for L in Editor.scene.layers where L.isLight && L.visible && time >= L.start && time <= L.end && n < maxLights {
            let lt = L.editTime("x", time), c = UInt32(bitPattern: L.vdbTint), k = L.xf("lightInt", 1)
            let tc = kelvin(L.xf("lightTemp", 6500))
            let col = SIMD3(Float((c >> 16) & 255) / 255 * tc.x, Float((c >> 8) & 255) / 255 * tc.y, Float(c & 255) / 255 * tc.z) * k
            let type = Float(Int(L.xf("lightType", 0)))
            let outer = max(5, min(L.xf("lightCone", 45), 89)) * Float.pi / 180
            let soft = max(0, min(L.xf("lightSoft", 0.3), 1))
            let inner = outer * (1 - soft)
            let d = direction(L)
            out[n * 8] = SIMD4(L.p("x", lt), L.p("y", lt), Xf.worldZ(L, time), type)
            out[n * 8 + 1] = SIMD4(col.x, col.y, col.z, infinite(L) ? -1 : max(L.xf("lightRange", 0), 0))
            out[n * 8 + 2] = SIMD4(d.x, d.y, d.z, cos(outer))
            out[n * 8 + 3] = SIMD4(cos(inner), L.xf("lightDiff", 1), L.xf("lightSpec", 1), 1)
            let nc = max(1, min(Int(L.xf("lightCols", 1)), 3))
            let c2 = stop(L, "lightC2", 4033535), c3 = stop(L, "lightC3", 16731040)
            out[n * 8 + 4] = SIMD4(c2.x, c2.y, c2.z, Float(nc))
            out[n * 8 + 5] = SIMD4(c3.x, c3.y, c3.z, 0)
            out[n * 8 + 6] = SIMD4(L.xf("lightGradMode", 0), max(L.xf("lightGradSpan", 4), 0.05), max(L.xf("lightRad", 0.5), 0) * max(L.xf("lightShadowSoft", 1), 0), 0)
            n += 1
        }
        return (out, n)
    }
}
