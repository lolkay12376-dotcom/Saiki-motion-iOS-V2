import Foundation
import Metal
import UIKit

//  Stage 7c: FLARE layers in Metal (port of SceneRenderer.drawFlareLayer + the GL procedural flare shader).
//  The fragment shader is the GL one converted mechanically (vec -> float, mod -> glmod, atan -> atan2,
//  uniform arrays -> one float4 buffer: A, B, C, D, E, Col blocks of 16). Preview shades at half resolution
//  and upsamples, like GL; export stays full resolution.

enum MetalFlareSL {
    static let source = MetalSL.header + """
struct FlareU { float4 h0; float4 h1; float4 h2; float4 h3; float4 h4; float4 h5; };
constexpr sampler flareDepthS(coord::normalized, address::clamp_to_edge, filter::nearest);
inline float glmod(float x, float y) { return x - y * floor(x / y); }

float hn(float x) { return fract(sin(x * 127.1) * 43758.5453); }
float vn(float x) { float i = floor(x); float f = fract(x); f = f * f * (3.0 - 2.0 * f); return mix(hn(i), hn(i + 1.0), f); }
float3 hsv2rgb(float3 c) {
    float3 p = abs(fract(c.xxx + float3(1.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0);
    return c.z * mix(float3(1.0), clamp(p - 1.0, float3(0.0), float3(1.0)), float3(c.y));
}

// procedural iris: radius (vertex = 1) of the polygon / star / flower at angle a
float irisR(float a, float n, float round, float star, float curve) {
    float seg = 6.28318 / n;
    float t = glmod(a, seg);
    float hs = seg * 0.5;
    float phi = abs(t - hs);
    float cosH = cos(hs);
    float sinH = sin(hs);
    float inner = mix(cosH, 0.12, star);
    float den = cos(phi) * sinH - sin(phi) * (cosH - inner);
    float r = min(inner * sinH / max(den, 0.05), 2.0);
    float u = phi / hs;
    r *= 1.0 + curve * 0.25 * (1.0 - u * u);
    float rc = (inner + 1.0) * 0.5;
    return mix(r, rc, round);
}

float irisMask(float2 d, float size, float n, float round, float star, float curve,
               float thick, float soft, float grad) {
    float a = atan2(d.y, d.x) + 1.5708;
    float R = irisR(a, n, round, star, curve) * size;
    float x = length(d) / max(R, 0.0001);
    float edge = 0.02 + soft * 0.6;
    float outer = 1.0 - smoothstep(1.0 - edge, 1.0, x);
    float hole = mix(smoothstep(1.0 - thick - edge, 1.0 - thick + 0.001, x), 1.0, step(0.99, thick));
    return outer * hole * mix(1.0, x * x, grad);
}

float hash21(float2 p) { return fract(sin(dot(p, float2(127.1, 311.7))) * 43758.5453); }
float vn2(float2 p) {
    float2 i = floor(p); float2 f = fract(p); f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash21(i), hash21(i + float2(1, 0)), f.x), mix(hash21(i + float2(0, 1)), hash21(i + float2(1, 1)), f.x), f.y);
}
float fbm2(float2 p) { return vn2(p) * 0.55 + vn2(p * 2.07 + 5.3) * 0.3 + vn2(p * 4.3 + 11.1) * 0.15; }

// lens catalogue for the multi-lens stack: a = (blades, round, star, curve), b = (thickness, stretch, special, 0)
void lensShape(int k, thread float4 &a, thread float4 &b) {
    a = float4(6.0, 0.05, 0.0, 0.0); b = float4(1.0, 1.0, 0.0, 0.0);
    switch (k) {
        case 0: a = float4(12.0, 1.0, 0.0, 0.0); break;
        case 1: a = float4(3.0, 0.08, 0.0, 0.0); break;
        case 2: a = float4(4.0, 0.05, 0.0, 0.0); break;
        case 3: a = float4(5.0, 0.06, 0.0, 0.0); break;
        case 4: a = float4(6.0, 0.05, 0.0, 0.0); break;
        case 5: a = float4(7.0, 0.10, 0.0, 0.0); break;
        case 6: a = float4(8.0, 0.08, 0.0, 0.0); break;
        case 7: a = float4(9.0, 0.25, 0.0, 0.0); break;
        case 8: a = float4(7.0, 0.15, 0.0, 0.9); break;
        case 9: a = float4(12.0, 1.0, 0.0, 0.0); b.y = 2.2; break;
        case 10: a = float4(12.0, 1.0, 0.0, 0.0); b.z = 1.0; break;
        case 11: a = float4(5.0, 0.0, 0.6, 0.0); break;
        case 12: a = float4(6.0, 0.0, 0.65, 0.0); break;
        case 13: a = float4(8.0, 0.5, 0.0, -0.9); break;
        case 14: a = float4(12.0, 1.0, 0.0, 0.0); b.x = 0.22; break;
        case 15: a = float4(6.0, 0.05, 0.0, 0.0); b.x = 0.2; break;
        case 16: a = float4(12.0, 1.0, 0.0, 0.0); b.z = 2.0; break;
        case 17: a = float4(4.0, 0.05, 0.0, 0.0); b.z = 3.0; break;
        default: break;
    }
}

float lensMask(float2 d, int kind, float size, float stretch, float soft, float grad) {
    float4 a; float4 b; lensShape(kind, a, b);
    float2 q = float2(d.x / (stretch * b.y), d.y);
    if (b.z > 2.5) { q = float2(q.x + q.y, q.y - q.x) * 0.7071; }
    if (b.z > 0.5 && b.z < 1.5) {                       // cat-eye: two clipped circles
        float o = size * 0.42;
        return irisMask(q - float2(0.0, o), size, 12.0, 1.0, 0.0, 0.0, 1.0, soft, grad)
             * irisMask(q + float2(0.0, o), size, 12.0, 1.0, 0.0, 0.0, 1.0, soft, grad);
    }
    if (b.z > 1.5 && b.z < 2.5) {                       // crescent
        float m1 = irisMask(q, size, 12.0, 1.0, 0.0, 0.0, 1.0, soft, grad);
        float m2 = irisMask(q - float2(size * 0.35, 0.0), size * 0.85, 12.0, 1.0, 0.0, 0.0, 1.0, 0.1, 0.0);
        return m1 * (1.0 - m2);
    }
    return irisMask(q, size, a.x, a.y, a.z, a.w, b.x, soft, grad);
}

fragment float4 flareFragment(VOut in [[stage_in]], constant FlareU& u [[buffer(0)]], constant float4* arr [[buffer(1)]], constant float4* lens [[buffer(2)]], depth2d<float> dep [[texture(0)]]) {
    float2 uLight = u.h0.xy; float uIntensity = u.h0.z; float uAxis = u.h0.w;
    float uSizeMul = u.h1.x; float uEdgeFade = u.h1.y; float uAspect = u.h1.z; float uCount = u.h1.w;
    float uTime = u.h2.x; float uFlicker = u.h2.y; float uSpeed = u.h2.z; float uRayAmt = u.h2.w;
    float3 uTintRgb = u.h3.xyz;
    float uReal = u.h4.x; float uVeil = u.h4.y; float uDust = u.h4.z; float uOccl = u.h4.w;
    float uOcclSoft = u.h5.x; float uLightZ = u.h5.y; float uHasDepth = u.h5.z;
    // 3D occlusion: sample the model depth buffer over the light's disc; objects in front hide the whole flare
    float seen = 1.0;
    if (uHasDepth > 0.5 && uOccl > 0.001) {
        float rad = mix(0.003, 0.045, uOcclSoft);
        float vis = 0.0;
        for (int s = 0; s < 16; s++) {
            float ang = float(s) * 2.39996;
            float rr = sqrt((float(s) + 0.5) / 16.0) * rad;
            float2 suv = uLight + float2(cos(ang) / uAspect, sin(ang)) * rr;
            if (suv.x < 0.0 || suv.x > 1.0 || suv.y < 0.0 || suv.y > 1.0) { vis += 1.0; continue; }
            float z = dep.sample(flareDepthS, flipV(suv));
            vis += step(uLightZ - 0.0002, z);
        }
        seen = mix(1.0, vis / 16.0, uOccl);
    }
    float2 asp = float2(uAspect, 1.0);
    float2 p = in.uv * asp;
    float2 L = uLight * asp;
    float2 ax = (float2(0.5) * asp - L) * uAxis;
    float axLen = length(ax);
    float axAng = atan2(ax.y, ax.x);
    float2 perpU = axLen > 0.0001 ? float2(-ax.y, ax.x) / axLen : float2(0.0, 1.0);
    float3 acc = float3(0.0);

    for (int i = 0; i < 16; i++) {
        float t = arr[0 + i].x;
        if (t < -0.5 || float(i) + 0.5 > uCount) { continue; }
        float pos = arr[0 + i].y;
        float size = min(arr[0 + i].z * uSizeMul, 3.0);
        float bright = arr[16 + i].x;
        float soft = arr[16 + i].y;
        float thick = arr[16 + i].z;
        float stretch = arr[16 + i].w;
        float sides = arr[32 + i].x;
        float rays = arr[32 + i].y;
        float chroma = arr[32 + i].z;
        float follow = arr[32 + i].w;
        float noise = arr[64 + i].x;

        float ang = radians(arr[0 + i].w) + follow * axAng * smoothstep(0.03, 0.3, axLen) + arr[64 + i].y * 1.2 * axLen;
        float2 d = p - (L + ax * pos + perpU * arr[96 + i].y);
        float ca = cos(ang);
        float sa = sin(ang);
        d = float2(ca * d.x + sa * d.y, -sa * d.x + ca * d.y);
        float r = length(d);

        // PERFORMANCE: skip every pixel that is outside the element's reach. Without this each
        // pixel evaluated up to 16 elements (atan/pow/iris x3, multi-iris x8) -> heavy lag.
        bool multi = (t > 13.5 && t < 14.5) || t > 15.5;
        if (!multi && r > size * max(stretch, 1.0) * 2.6 + 0.01) { continue; }
        if (bright * uIntensity < 0.002) { continue; }

        float3 m = float3(0.0);
        if (t < 0.5) {                                  // Glow
            float2 q = float2(d.x / stretch, d.y);
            float x = length(q) / max(size, 0.001);
            float win = mix(1.0 - smoothstep(0.85, 1.0, x), 1.0 - smoothstep(0.35, 2.4, x), uReal);   // no hard disc edge
            float g = exp(-pow(x, mix(2.0, 0.85, soft)) * 4.5) * win;
            // real lens glare: hot core + long inverse-square wings (like the reference photos)
            float wing = (1.0 / (1.0 + x * x * 24.0)) * (1.0 - smoothstep(0.55, 1.0, x));
            g = mix(g, g * 0.6 + wing * 0.5, soft);
            // optical PSF: sharp airy core + 1/r^3 tail + faint far halo, warmer at the edge (dispersion)
            float psf = 1.0 / pow(1.0 + x * x * 60.0, 1.5);
            float halo = 1.0 / (1.0 + x * x * 5.0);
            float gr = g + uReal * (psf * 0.45 + halo * 0.10 * win * smoothstep(0.0, 0.6, soft + 0.3));
            m = float3(gr) * mix(float3(1.0), float3(1.0, 0.93, 0.82) + float3(0.0, 0.0, 0.18) * (1.0 - clamp(x, 0.0, 1.0)), float3(uReal * clamp(x, 0.0, 1.0) * 0.5));
        } else if (t < 1.5 || (t > 4.5 && t < 5.5) || (t > 12.5 && t < 13.5)) {   // Polygon / Ring polygon / Iris
            float st = 0.0; float rd = 0.0; float cv = 0.0; float gr = arr[48 + i].w; float th = thick; float sf = soft;
            if (t > 12.5) { rd = arr[48 + i].x; st = arr[48 + i].y; cv = arr[48 + i].z; }
            else { th = t < 1.5 ? max(thick, 0.3) : thick; gr = 0.3; sf = 0.12; }
            float2 q = float2(d.x / stretch, d.y);
            float k = chroma * 0.07;
            m = float3(irisMask(q, size * (1.0 + k), sides, rd, st, cv, th, sf, gr),
                     irisMask(q, size, sides, rd, st, cv, th, sf, gr),
                     irisMask(q, size * (1.0 - k), sides, rd, st, cv, th, sf, gr));
            if (chroma > 0.01) { m *= float3(1.0, 0.85, 1.0); }
        } else if (t < 2.5) {                            // Line
            float2 s = float2(size * stretch * 0.5, size * 0.5 * max(thick, 0.01));
            float2 qq = abs(d) - s;
            float e = 0.004 + soft * 0.03;
            m = float3(1.0 - smoothstep(-e, e, length(max(qq, float2(0.0))) + min(max(qq.x, qq.y), 0.0)));
        } else if (t < 3.5) {                            // Rays: thin straight beams (constant width, fading along their length)
            float n = max(rays, 2.0);
            float a = atan2(d.y, d.x);
            float seg = 6.2831853 / n;
            float fr = (fract(a / seg + 0.5) - 0.5) * seg;
            float perp = abs(fr) * r;
            float wd = size * (0.0035 + soft * 0.012) + 0.0005;
            float beam = exp(-(perp * perp) / (wd * wd));
            float rad = (1.0 - smoothstep(0.0, size * 0.5, r)) * smoothstep(0.0, size * 0.03, r);
            m = float3(beam * rad * 0.22 * uRayAmt);
        } else if (t < 4.5) {                            // Ring
            float R = size * 0.5;
            float w = max(thick, 0.01) * R;
            float e = 0.004 + soft * 0.02;
            float k = chroma * 0.06;
            float3 rr = float3(r / (1.0 + k), r, r / (1.0 - k));
            if (thick >= 0.95) { m = 1.0 - smoothstep(float3(R * (1.0 - soft * 0.5) - e), float3(R + e), rr); }
            else { m = 1.0 - smoothstep(float3(w * 0.5 - e), float3(w * 0.5 + e), abs(rr - R)); }
        } else if (t < 6.5) {                            // Dot
            float R = size * 0.5;
            m = float3(1.0 - smoothstep(R * (1.0 - soft * 0.8), R, r));
        } else if (t < 7.5) {                            // Glint: smooth starburst
            float n = max(rays, 2.0);
            float a = atan2(d.y, d.x);
            float seg = 6.28318 / n;
            float idx = glmod(floor(a / seg + 0.5), n);
            float fr = (fract(a / seg + 0.5) - 0.5) * seg;
            float lenv = mix(1.0, 0.6 + 0.4 * hn(idx * 3.7 + arr[64 + i].z), noise * 0.6);
            float len = size * 0.5 * lenv;
            float w = mix(0.018, 0.075, soft);
            float beam = exp(-(fr * fr) / (w * w));
            float rad = exp(-r / max(len * 0.45, 0.001)) * (1.0 - smoothstep(len * 0.55, len, r));
            float core = exp(-r / max(size * 0.05, 0.001)) * 0.7;
            float3 gspec = 0.72 + 0.28 * cos(6.28318 * (float3(r / max(size * 0.5, 0.001) * 3.0) + float3(0.0, 0.33, 0.67)));
            m = float3(beam * rad * 0.8 * uRayAmt) * mix(float3(1.0), gspec, float3(uReal * 0.6)) + float3(core);
        } else if (t < 8.5) {                            // Hoop
            float R = size * 0.5;
            float w = max(thick, 0.02) * R * 0.5;
            float k = chroma * 0.07;
            float3 rr = float3(r / (1.0 + k), r, r / (1.0 - k));
            float3 z = (rr - R) / w;
            m = exp(-z * z * (1.0 + (1.0 - soft) * 3.0));
        } else if (t < 9.5) {                            // Streak (anamorphic)
            float len = size * stretch * 0.5;
            float wy = size * 0.5 * max(thick, 0.01) * 0.35 + 0.002;
            float hx = exp(-abs(d.x) / max(len * (0.12 + 0.5 * soft), 0.001));
            float vy = exp(-(d.y / wy) * (d.y / wy));
            m = float3(hx * vy * (1.0 - smoothstep(len * 0.8, len * 1.2, abs(d.x))));
        } else if (t < 10.5) {                           // Spike ball: fine smooth spikes
            float n = max(rays, 3.0) * 2.0;
            float a = atan2(d.y, d.x);
            float seg = 6.28318 / n;
            float idx = glmod(floor(a / seg + 0.5), n);
            float fr = (fract(a / seg + 0.5) - 0.5) * seg;
            float lenv = mix(1.0, 0.45 + 0.55 * hn(idx * 5.3 + arr[64 + i].z), noise * 0.7);
            float len = size * 0.5 * lenv;
            float w = mix(0.012, 0.04, soft);
            float beam = exp(-(fr * fr) / (w * w));
            float rad = exp(-r / max(len * 0.4, 0.001)) * (1.0 - smoothstep(len * 0.6, len, r));
            float core = exp(-pow(r / max(size * 0.12, 0.001), 1.2) * 2.0);
            m = float3(beam * rad * 0.6 * uRayAmt + core * 0.9);
        } else if (t < 11.5) {                           // Rainbow
            float x = r / max(size * 0.5, 0.001);
            float inner = 1.0 - thick * 0.7;
            float band = smoothstep(inner, inner + 0.12, x) * (1.0 - smoothstep(0.92, 1.0, x));
            float3 spec = hsv2rgb(float3(clamp((1.0 - (x - inner) / max(1.0 - inner, 0.05)) * 0.75, 0.0, 0.8), 0.9, 1.0));
            m = band * mix(float3(1.0), spec, float3(0.25 + 0.75 * chroma));
        } else if (t > 15.5) {                           // Lens stack: each lens has its own shape / size / tint
            int cnt = int(clamp(rays, 1.0, 8.0) + 0.5);
            float3 mm = float3(0.0);
            float cov = 0.0;
            float sp = arr[64 + i].w;
            for (int k = 0; k < 8; k++) {
                if (k >= cnt) { break; }
                float4 LA = lens[(i * 8 + k) * 2];
                float4 LB = lens[(i * 8 + k) * 2 + 1];
                float2 dk = p - (L + ax * (pos + float(k) * sp + LA.w) + perpU * arr[96 + i].y);
                float ra = ang + radians(LB.w);
                float cr = cos(ra - ang + 0.0); float sr = sin(ra - ang);
                dk = float2(ca * dk.x + sa * dk.y, -sa * dk.x + ca * dk.y);
                dk = float2(cr * dk.x + sr * dk.y, -sr * dk.x + cr * dk.y);
                float szk = size * LA.y;
                int kind = int(LA.x + 0.5);
                if (length(dk) > szk * max(stretch, 1.0) * 2.6 + 0.01) { continue; }
                float kk = chroma * 0.07 + uReal * 0.008;
                float3 mk;
                if (kk > 0.004) {
                    mk = float3(lensMask(dk, kind, szk * (1.0 + kk), stretch, soft, arr[48 + i].w),
                                lensMask(dk, kind, szk, stretch, soft, arr[48 + i].w),
                                lensMask(dk, kind, szk * (1.0 - kk), stretch, soft, arr[48 + i].w));
                } else {
                    mk = float3(lensMask(dk, kind, szk, stretch, soft, arr[48 + i].w));
                }
                float fb = LA.z / (1.0 + 0.1 * float(k));
                mm += mk * LB.rgb * fb;
                cov += dot(mk, float3(0.3333)) * fb;
            }
            float gn = arr[96 + i].x;
            m = mm * (1.0 + gn * max(cov - 1.0, 0.0) * 1.8);           // light passing several lenses gets brighter
        } else if (t > 14.5) {                           // Arc: partial lens ring with colour fringe
            float R = size * 0.5;
            float w = max(thick, 0.02) * R * 0.5;
            float k = chroma * 0.07;
            float3 rr = float3(r / (1.0 + k), r, r / (1.0 - k));
            float3 z = (rr - R) / w;
            float aa = atan2(d.y, d.x);
            float hs = clamp(arr[64 + i].w, 0.02, 1.0) * 3.14159;
            float am = 1.0 - smoothstep(hs * (1.0 - soft), hs, abs(aa));
            m = exp(-z * z * (1.0 + (1.0 - soft) * 3.0)) * am;
        } else if (t > 13.5) {                           // Multi iris: a chain of ghost irises
            float cnt = clamp(rays, 2.0, 8.0);
            float3 mm = float3(0.0);
            float cov = 0.0;
            for (int k = 0; k < 8; k++) {
                float fk = float(k);
                if (fk + 0.5 > cnt) { break; }
                float h1 = hn(fk * 12.9 + arr[64 + i].z);
                float h2 = hn(fk * 7.7 + arr[64 + i].z + 3.0);
                float2 dk = p - (L + ax * (pos + fk * arr[64 + i].w) + perpU * arr[96 + i].y);
                dk = float2(ca * dk.x + sa * dk.y, -sa * dk.x + ca * dk.y);
                float szk = size * (1.0 - noise * 0.6 * h1) * (1.0 - 0.06 * fk);
                float mk = irisMask(float2(dk.x / stretch, dk.y), szk, sides, arr[48 + i].x, arr[48 + i].y, arr[48 + i].z,
                                    max(thick, 0.05), soft, arr[48 + i].w);
                float3 spec = hsv2rgb(float3(fract(0.08 + fk * 0.17 + h2 * 0.1), 0.65, 1.0));
                float3 tk = mix(float3(1.0), spec, float3(chroma * 0.9));
                float fbk = (0.55 + 0.45 * h2) / (1.0 + 0.12 * fk);
                mm += mk * tk * fbk;
                cov += mk * fbk;
            }
            m = mm * (1.0 + arr[96 + i].x * max(cov - 1.0, 0.0) * 1.8);     // overlapping lenses: brighter
        } else {                                         // Shimmer
            float x = r / max(size, 0.001);
            float a = atan2(d.y, d.x);
            float g = exp(-pow(x, 1.2) * 3.5) * (1.0 - smoothstep(0.9, 1.0, x));
            float nz = vn(a * rays * 0.35 + 20.0 + uTime * uSpeed * 1.2) * 0.7
                     + vn(a * rays * 0.9 + uTime * uSpeed * 2.3) * 0.5;
            m = float3(g * (0.45 + nz * 1.1 * (0.25 + noise)));
        }

        bool ghost = (t > 0.5 && t < 1.5) || (t > 3.5 && t < 5.5) || (t > 7.5 && t < 8.5) || (t > 12.5);
        if (ghost && uReal > 0.0) {
            float2 d0 = p - (L + ax * pos + perpU * arr[96 + i].y);
            float dl = max(length(d0), 0.0001);
            float facing = dot(d0 / dl, -ax / max(axLen, 0.0001));           // side of the ghost facing the light
            float dirG = mix(1.0, 0.62 + 0.76 * (facing * 0.5 + 0.5), uReal * 0.7);
            float dz = fbm2(d0 / max(size, 0.05) * 3.2 + float(i) * 7.1);
            float dustM = 1.0 - uDust * uReal * smoothstep(0.38, 0.85, dz) * 0.8;
            float scr = vn2(float2(atan2(d0.y, d0.x) * 14.0, dl / max(size, 0.05) * 1.5) + float(i));    // micro-scratches
            dustM *= 1.0 - uDust * uReal * 0.35 * smoothstep(0.7, 1.0, scr);
            m *= dirG * dustM;
        }
        float fl = 1.0 + uFlicker * (vn(uTime * uSpeed * 9.0 + float(i) * 3.1) - 0.5) * 0.7;
        acc += arr[80 + i].rgb * uTintRgb * m * bright * fl;
    }

    // the whole flare fades as the light leaves the frame
    float2 lp = uLight;
    float outside = max(max(-lp.x, lp.x - 1.0), max(-lp.y, lp.y - 1.0));
    outside = max(outside - 0.12, 0.0);                 // never fades while the light is on or near the frame
    float vis = 1.0 - smoothstep(0.0, max(uEdgeFade, 0.05) + 0.25, outside);
    // veiling glare: faint haze that lifts the blacks around the light (stray light in the barrel)
    float vl = length(p - L);
    float3 veilCol = (arr[0].x > -0.5 ? arr[80].rgb : float3(1.0)) * uTintRgb;
    acc += veilCol * uVeil * uReal * (1.0 / (1.0 + vl * vl * 9.0)) * 0.22 * step(0.5, uCount);
    acc = clamp(acc, float3(0.0), float3(60.0)) * uIntensity * vis * seen;

    // soft highlight roll-off keeps hot colours from clipping to flat white
    float3 o = float3(1.0) - exp(-acc * 1.1);
    float lum = max(o.r, max(o.g, o.b));
    o = mix(o, float3(lum), float3(smoothstep(0.55, 1.0, lum) * mix(0.45, 0.7, uReal)));
    o = mix(o, o + o * o * o * 0.18, float3(uReal));                      // film shoulder: hot highlights bloom   // hot cores bleed to white like film
    o = min(o, float3(1.0));
    float dn = fract(52.9829189 * fract(dot(in.pos.xy, float2(0.06711056, 0.00583715)))) - 0.5;
    o = max(o + dn * (1.0 / 255.0) * step(float3(0.002), o), float3(0.0));
    return float4(o, max(o.r, max(o.g, o.b)));
}

"""
}

struct FlareU {
    var h0 = SIMD4<Float>(), h1 = SIMD4<Float>(), h2 = SIMD4<Float>(), h3 = SIMD4<Float>()
    var h4 = SIMD4<Float>(), h5 = SIMD4<Float>()
}

final class MetalFlareRenderer {
    private let core: MetalCore
    private let passes: MetalPasses
    private var lib: MTLLibrary?
    private var halfT: MetalTarget?
    private(set) var buildError: String?
    private var dummyDepth: MTLTexture?

    init(_ core: MetalCore, _ passes: MetalPasses) {
        self.core = core
        self.passes = passes
        do { lib = try core.device.makeLibrary(source: MetalFlareSL.source, options: nil) }
        catch { buildError = String(String(describing: error).prefix(600)); NSLog("Flare shader build failed: %@", buildError ?? "") }
        let dd = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .depth32Float, width: 1, height: 1, mipmapped: false)
        dd.usage = .shaderRead; dd.storageMode = .private
        dummyDepth = core.device.makeTexture(descriptor: dd)
    }

    var ready: Bool { lib != nil }

    func trimMemory() { halfT = nil }

    private func projectPoint(_ vp: [Float], _ x: Float, _ y: Float, _ z: Float) -> (Float, Float, Float) {
        let cx = vp[0] * x + vp[4] * y + vp[8] * z + vp[12]
        let cy = vp[1] * x + vp[5] * y + vp[9] * z + vp[13]
        let cw = vp[3] * x + vp[7] * y + vp[11] * z + vp[15]
        return (cx / max(abs(cw), 0.0001), cy / max(abs(cw), 0.0001), cw)
    }

    private func rgb(_ c: Int32) -> SIMD4<Float> {
        let v = UInt32(bitPattern: c)
        return SIMD4(Float((v >> 16) & 0xFF) / 255, Float((v >> 8) & 0xFF) / 255, Float(v & 0xFF) / 255, 1)
    }

    /// Draws flare layer `l` into `a` (the caller has cleared it).
    func draw(_ l: Layer, time: Float, fov: Float, isExport: Bool, depth: MTLTexture? = nil, into a: MetalTarget, cb: MTLCommandBuffer) {
        guard ready, let f = l.flare, let lb = lib else { return }
        let tw = a.width, th = a.height
        let ar = Float(tw) / Float(max(th, 1))
        let lt = l.editTime("x", time)
        var wx = l.p("x", lt), wy = l.p("y", lt)
        var visible: Float = 1
        var sizeMul: Float = 1
        var lightZ: Float = 1
        var occlOK = false

        if l.is3d {
            // real 3D light: projected through the camera; grows/shrinks with distance, hidden behind it
            let z = Xf.worldZ(l, time)
            let vp = MetalCam.vpForModel(l, fov: fov, time: time, width: tw, height: th)
            guard vp.count == 16 else { return }
            let (nx, ny, pw) = projectPoint(vp, wx, wy, z)
            let cz = vp[2] * wx + vp[6] * wy + vp[10] * z + vp[14]
            lightZ = (cz / max(abs(pw), 0.0001)) * 0.5 + 0.5
            occlOK = pw > 0.01
            let (_, _, pw0) = projectPoint(vp, 0, 0, 0)
            if pw <= 0.01 { visible = 0 }
            sizeMul = 1 + (min(max(pw0 / max(pw, 0.01), 0.15), 6) - 1) * f.depthScale
            wx = nx * ar; wy = ny
        } else if l.parentId >= 0 {
            let m = Xf.matrix(l, time)
            wx = m[4]; wy = m[5]
        }
        let lightX = wx / ar / 2 + 0.5       // 0..1 across the canvas
        let lightY = 0.5 - wy / 2
        let intensity = l.p("fIntensity", lt) * visible
        let axis = l.p("fAxis", lt)
        if intensity <= 0.0005 { return }          // invisible (behind the camera / zero): skip the heavy shader

        let n = min(f.els.count, min(FlareEl.MAX, 16))
        var u = FlareU()
        u.h0 = SIMD4(lightX, lightY, intensity, axis)
        u.h1 = SIMD4(sizeMul, f.edgeFade, ar, Float(n))
        u.h2 = SIMD4(time, f.flicker, f.speed, f.rayAmt)
        u.h3 = rgb(f.tint)
        u.h4 = SIMD4(f.realism, f.veil, f.dust, f.occlusion)
        let useDepth = l.is3d && occlOK && depth != nil
        u.h5 = SIMD4(f.occlSoft, lightZ, useDepth ? 1 : 0, 0)
        var arr = [SIMD4<Float>](repeating: SIMD4<Float>(0, 0, 0, 0), count: 112)
        for i in 0..<16 {
            guard i < n else { arr[i] = SIMD4(-1, 0, 0, 0); continue }
            let e = f.els[i]
            arr[i] = SIMD4(Float(e.enabled ? e.type : -1), e.pos, e.size, e.rot)
            arr[16 + i] = SIMD4(e.bright, e.soft, e.thick, max(e.stretch, 0.05))
            arr[32 + i] = SIMD4(Float(e.sides), Float(e.rays), e.chroma, e.follow ? 1 : 0)
            arr[48 + i] = SIMD4(e.round, e.star, e.curve, e.grad)
            arr[64 + i] = SIMD4(e.noise, e.spin, Float(i) * 7.31 + 1.7, e.spread)
            arr[80 + i] = rgb(e.color)
            arr[96 + i] = SIMD4(e.gain, e.off, 0, 0)
        }
        // per-lens data for lens stacks: 16 elements x 8 lenses x 2 float4
        var lensArr = [SIMD4<Float>](repeating: SIMD4<Float>(0, 0, 0, 0), count: 256)
        for i in 0..<n where f.els[i].type == 16 {
            let ls = f.els[i].lenses.isEmpty ? LensDef.defaultStack() : f.els[i].lenses
            for k in 0..<min(8, ls.count) {
                let d = ls[k], c = rgb(d.color)
                lensArr[(i * 8 + k) * 2] = SIMD4(Float(d.kind), d.size, d.bright, d.offset)
                lensArr[(i * 8 + k) * 2 + 1] = SIMD4(c.x, c.y, c.z, d.rot)
            }
        }
        let lensBuf = lensArr.withUnsafeBytes { core.device.makeBuffer(bytes: $0.baseAddress!, length: $0.count, options: .storageModeShared) }
        let depthTex = (useDepth ? depth : nil) ?? dummyDepth

        func run(_ tgt: MetalTarget) {
            guard let pso = passes.pipeline(fragment: "flareFragment", library: lb, libKey: "flare",
                                            format: tgt.tex.pixelFormat) else { return }
            passes.encode(cb, into: tgt, pso: pso) { enc in
                enc.setFragmentBytes(&u, length: MemoryLayout<FlareU>.stride, index: 0)
                arr.withUnsafeBytes { enc.setFragmentBytes($0.baseAddress!, length: $0.count, index: 1) }
                if let lb2 = lensBuf { enc.setFragmentBuffer(lb2, offset: 0, index: 2) }
                enc.setFragmentTexture(depthTex, index: 0)
            }
        }

        if !isExport && tw >= 64 {
            // Preview: flares are smooth light, so shade them at half resolution and upsample.
            if halfT == nil || halfT!.width != tw / 2 || halfT!.height != th / 2 {
                halfT = MetalTarget(core, tw / 2, th / 2)
            }
            if let ft = halfT {
                run(ft)
                _ = passes.blit(cb, src: ft.tex, to: a)
                return
            }
        }
        run(a)
    }
}
