// EffectGuard.swift — quick safety test of an effect before it may touch the live preview.
//
// The first time an effect is used in a session it is compiled and rendered a few times at 128x128 on a
// background thread with its own GL context. Compile errors, a hang (no answer within 5 s), a GPU/driver
// problem or a cost that would be too slow at preview size all switch the effect off (passthrough), write
// a log in EffectCrashLogs and show a message. Meanwhile the effect is simply skipped, so the main thread
// can never be blocked by it. The test itself is tracked as "in flight": if the whole app dies during
// it, the next launch finds that and disables the effect too.

import Foundation
import UIKit
import OpenGLES

enum EffectGuard {
    static let doneNote = Notification.Name("EffectGuardDone")
    private static let lock = NSLock()
    private static var state: [String: Int] = [:]        // 1 testing, 2 ok, 3 bad
    private static let q = DispatchQueue(label: "fx.guard", qos: .utility)

    private static func key(_ d: EffectDef) -> String { d.id + "#" + String(d.glsl.hashValue) + "#" + d.props.map { $0.key }.joined(separator: ",") }

    /// True when the effect passed its test. Starts the test (and returns false) the first time.
    static func cleared(_ d: EffectDef) -> Bool {
        if !d.passes.isEmpty || d.kind == 1 { return true }     // plugins / single-instance effects have their own path
        let k = key(d)
        lock.lock()
        let st = state[k] ?? 0
        if st == 0 { state[k] = 1 }
        lock.unlock()
        if st == 2 { return true }
        if st == 0 { start(d, k) }
        return false
    }

    /// Export must never skip an effect just because its quick test has not finished yet
    /// (that produced frames with the effect missing). Waits (bounded) for the verdict.
    static func clearedWaiting(_ d: EffectDef, timeout: TimeInterval = 10) -> Bool {
        if cleared(d) { return true }
        let end = Date().addingTimeInterval(timeout)
        while Date() < end {
            lock.lock(); let st = state[key(d)] ?? 0; lock.unlock()
            if st == 2 { return true }
            if st == 3 { return false }
            Thread.sleep(forTimeInterval: 0.02)
        }
        return false
    }

    private static func finish(_ d: EffectDef, _ k: String, ok: Bool, kind: String, why: String) {
        lock.lock()
        if state[k] != 1 { lock.unlock(); return }          // already decided (timeout vs. late result)
        state[k] = ok ? 2 : 3
        lock.unlock()
        var msg: String? = nil
        if !ok {
            EffectCrashLog.writeLog(id: d.id, name: d.name, kind: kind, stage: "quick test", detail: why, markBroken: true)
            msg = "\(d.name) was switched off: \(kind). See Settings > Crash > Effect crash logs."
        }
        DispatchQueue.main.async {
            NotificationCenter.default.post(name: doneNote, object: nil, userInfo: msg.map { ["msg": $0] })
        }
    }

    private static func start(_ d: EffectDef, _ k: String) {
        EffectCrashLog.begin(d.id, name: d.name, stage: "quick test")
        q.async {
            // the test thread may wedge (driver hang): the main app must not wait for it.
            // The clock starts when THIS test starts — with many effects added at once the later tests used to
            // time out while still queued and were wrongly switched off as "hang".
            DispatchQueue.global().asyncAfter(deadline: .now() + 5) { finish(d, k, ok: false, kind: "hang", why: "The quick test did not finish within 5 seconds.") }
            let r = test(d)
            EffectCrashLog.end(d.id, stage: "quick test")
            finish(d, k, ok: r.ok, kind: r.kind, why: r.why)
        }
    }

    private static func test(_ d: EffectDef) -> (ok: Bool, kind: String, why: String) {
        guard let ctx = GLContext.make() else { return (true, "", "") }     // cannot test here: let it through
        let prev = EAGLContext.current()
        EAGLContext.setCurrent(ctx)
        defer { EAGLContext.setCurrent(prev) }
        let (src, _) = Gl.effectShaderSource(d)
        guard let prog = GLProgram(vertex: GLProgram.defaultVertex, fragment: src) else {
            return (false, "shader-compile-error", "The shader does not compile on this device:\n" + Gl.lastShaderLog)
        }
        let n = 128
        let a = Gl.Target(n, n), b = Gl.Target(n, n)
        a.bind(); glClearColor(0.5, 0.4, 0.3, 1); glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
        var best = Double.greatestFiniteMagnitude
        for i in 0..<3 {
            b.bind()
            glDisable(GLenum(GL_BLEND))
            glViewport(0, 0, GLsizei(n), GLsizei(n))
            glClearColor(0, 0, 0, 0); glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
            prog.use()
            prog.setTexture("uTex", a.tex, 0)
            prog.setTexture("uIn0", a.tex, 1)
            prog.setTexture("uIn1", a.tex, 2)
            prog.setVec2("uRes", Float(n), Float(n))
            prog.setFloat("uTime", 1.7 + Float(i))
            prog.setFloat("uHas0", 0); prog.setFloat("uHas1", 0)
            prog.setVec2("uLC", 0, 0); prog.setVec2("uLX", 2, 0); prog.setVec2("uLY", 0, 2)
            for pd in d.props { prog.setFloat(Gl.uniformName(pd.key), pd.def) }
            for cp in d.colors {
                let v = UInt32(bitPattern: cp.def)
                prog.setVec4(Gl.uniformName(cp.key), Float((v >> 16) & 0xFF) / 255, Float((v >> 8) & 0xFF) / 255,
                             Float(v & 0xFF) / 255, Float((v >> 24) & 0xFF) / 255)
            }
            let t0 = CFAbsoluteTimeGetCurrent()
            Gl.drawQuad(prog)
            glFinish()
            let dt = CFAbsoluteTimeGetCurrent() - t0
            if i > 0 { best = min(best, dt) }                // first frame includes warm-up
            let err = glGetError()
            if err != 0 { return (false, "gl-error", "OpenGL error 0x" + String(err, radix: 16) + " while rendering the effect.") }
        }
        let ms720 = best * 1000 * (1280.0 * 720.0) / Double(n * n)
        if ms720 > 700 {
            return (false, "too-heavy", "Rendering costs about \(Int(ms720)) ms per frame at 720p on this device (limit 700 ms), which would freeze the preview.")
        }
        return (true, "", "")
    }
}
