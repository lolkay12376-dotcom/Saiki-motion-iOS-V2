// HelpDocs.swift — in-app documentation (Settings > Help). Currently: Puppet.

import UIKit

enum HelpDocs {
    static let puppet: [(String, String)] = [
        ("Puppet: overview", "Puppet bends an image layer by pinning points on it. Drag a pin and the picture warps around it; pins you don't touch hold their place. Open it from the layer's toolbar (Puppet). The panel has three tabs: Pin, Mesh and Sway."),
        ("Pin tab", "Add: tap the layer to drop a pin. Select: tap a pin to pick it. Multi: pick several pins and move them together. Drag a pin to deform the layer. With Auto-key on, every drag records a keyframe on that pin (tracks named pp<id>x / pp<id>y), so you can edit, ease and graph them like any other property. Fine mode slows dragging for small moves. Delete removes the selected pins; Clear removes all."),
        ("Mesh tab", "Density sets how many triangles cover the layer (low / medium / high / ultra). Higher density follows pins more smoothly but costs more to preview. Stiffness controls how local a pin's pull is: higher keeps the warp close to the pin, lower spreads it wide. Show Mesh draws the triangle grid on the preview."),
        ("Sway tab: Auto Sway", "Auto Sway animates the pins for you. The master switch turns every sway on the layer on or off. Lock root keeps the first pin of each chain fixed so the effect hangs from it, like hair from a scalp or a flag from a pole."),
        ("Sway: stacking effects", "A layer can have many sway effects. Tap + Wave or + Physics to add one; each shows as a chip (Wave 1, Physics 2 ...). Select a chip to edit it, disable it, or delete it. All enabled effects are added together, so you can run a slow Wave for the breeze plus Physics for reaction to movement. Each effect has its own pin chain."),
        ("Pin chain", "Tap pins from root to tip. The number on the pin button is its place in the chain. The root moves least and the tip moves most. All in order picks every pin in the order they were placed. At least 2 pins are needed."),
        ("Wave", "Procedural swinging that needs no animation. Speed: cycles per second. Strength: swing angle at the tip in degrees. Wave: delay between pins, which makes the motion ripple along the chain. Tip weight: how quickly the effect grows toward the tip. Randomness and Seed vary each pin. Light / Medium / Heavy are quick strength presets."),
        ("Physics", "Physics makes the chain react to movement. Move, rotate or scale the layer (or its parent, or animate its pins) and the chain lags behind, overshoots and settles like a real object. Light / Medium / Heavy sets the mass: light is bouncy, heavy is slow and sags. Stiffness is how hard the chain pulls back to its rest pose. Damping is how fast the swinging dies down. Gravity pulls the chain downward. Wind pushes it sideways in gusts (negative values blow left). Strength scales how far it may lag. Physics is calculated from the layer's recent motion, so it looks the same when scrubbing, playing and exporting."),
        ("Linking to keyframes and expressions", "On a Physics effect, tap Link stiffness / damping / gravity / wind. This creates a layer track named sw<n>stiff, sw<n>damp, sw<n>grav or sw<n>wind (n is the effect's position, starting at 0). Keyframe the track or add an expression to it in the graph editor, for example to make wind rise over time, or to drive gravity from a marker. Tap the button again to unlink and return to the slider value."),
        ("Tips", "Use two or three pins per limb or strand. Put pins outside the area you want to keep still, and one pin on a fixed spot to anchor it. For a character that walks or jumps, add Physics to hair and clothes, put the layer in a parent that moves, and keep Lock root on. If the warp looks stretched, add a pin near the stretched spot or raise density."),
    ]

    static let topics: [(String, [(String, String)])] = [
        ("Getting started", gettingStarted), ("Layers, timeline & keyframes", timeline), ("3D scene & gestures", scene3d),
        ("Drawing editor", drawing), ("Effects & looks", effects), ("Rendering & cache", rendering), ("Puppet", puppet), ("Expression reference", [("Expressions", EditorViewController.expressionDoc)]), ("Extras & settings", extrasHelp)]

    static let gettingStarted: [(String, String)] = [
        ("Projects", "Home > Projects lists your projects. Tap + to create one, tap a project to open the editor. Projects save automatically."),
        ("Adding media", "In the editor, import images, video, audio, text, 3D models and drawings as layers. Each layer has its own parameters, keyframes and effects."),
        ("Parameters", "Every parameter is a scrolling ruler: drag left or right to change it, hold still to type an exact value, tap the name to open its graph. On iPad the rulers are drawn larger automatically."),
    ]
    static let timeline: [(String, String)] = [
        ("Layers", "Layers stack in the timeline; drag the ends to trim, drag the body to move. Parent a layer to another to inherit its movement. Position, scale, rotation, anchor and opacity are all animatable."),
        ("Keyframes", "Turn Auto-key on, move the playhead and change a value: a keyframe is recorded. A diamond beside a parameter shows it has keyframes. Tap the name of a keyframed parameter to open the graph editor and shape the easing."),
        ("Anchor point", "Anchor X / Y set the pivot a layer rotates and scales around; changing them keeps the picture in place. 3D and model layers also have Anchor Z, which moves the pivot along the depth axis."),
        ("Expressions", "Long-press a parameter to add an expression. An orange outline means an expression is active."),
    ]
    static let scene3d: [(String, String)] = [
        ("Camera gestures", "One finger: orbit. Two fingers: pan. Pinch: dolly in and out. Three fingers: drag up or down to dolly fast. Keep all three fingers down together while dragging; two-finger pan and pinch pause while three fingers are down so they no longer fight the dolly. Double-tap an object to fly to it, double-tap empty space to return to the centre."),
        ("Moving objects", "Tap an object to select it, then use Move, Rotate or Scale. In Rotate, drag a ring to turn around one axis, or drag the object itself for yaw and pitch."),
        ("Extras", "Scene 3D + > Extras adds a plane or cube with a Poly Haven PBR material, water, or terrain."),
    ]
    static let drawing: [(String, String)] = [
        ("Tools", "Brush, Eraser, Smudge, Eyedropper, Transform and Magic Wand. Brush and eraser tips can be customised; eraser presets fade softly instead of cutting in one go."),
        ("Layers", "Add, duplicate, merge down, reorder, group in folders and clear layers from the layer panel. Transparent areas show a checkerboard; choose a white paper in the paper switch if you want a solid background."),
        ("Selection", "The Selection Layer holds the selection as a blue overlay. Paint on it, use the wand, invert it, or copy / cut / paste the selected pixels."),
        ("Navigating", "Two fingers pan, pinch zooms and twisting rotates the canvas. Undo and redo keep full history per stroke."),
    ]
    static let effects: [(String, String)] = [
        ("Adding effects", "Open a layer's Effects panel and pick from the gallery. Effects stack from the top of the list down; reorder them to change the result."),
        ("Looks", "Looks apply colour grades and LUTs. Combine with blend modes to layer them over footage."),
        ("Problem effects", "If an effect crashes or freezes, it is logged. See Extras > Crash reports."),
    ]
    static let rendering: [(String, String)] = [
        ("Export", "Use the Render button in the editor. The overlay shows progress and lets you cancel."),
        ("Live render cache", "Renders frames ahead so playback is smooth. Toggle it in Extras. Clear cache frees space and never touches projects."),
        ("Pre-render groups", "Bakes groups to frames to speed up heavy scenes. Turn it off in Extras if a group looks stale."),
    ]
    static let extrasHelp: [(String, String)] = [
        ("Crash reports", "Open crash logs lists reports saved by the app; send them with bug reports."),
        ("Language", "Pick the app language at the bottom of Extras; every tab updates immediately."),
    ]

    static func show(from vc: UIViewController, title: String, sections: [(String, String)]) {
        let d = DocVC(); d.docTitle = title; d.sections = sections
        d.modalPresentationStyle = .fullScreen
        vc.present(d, animated: true)
    }
}

final class DocVC: UIViewController {
    var docTitle = ""; var sections: [(String, String)] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = argbToUIColor(C.BG)
        let bar = UIView(); bar.backgroundColor = argbToUIColor(C.PANEL)
        let t = UILabel(); t.text = docTitle; t.textColor = argbToUIColor(C.TEXT); t.font = .systemFont(ofSize: 18, weight: .semibold)
        t.numberOfLines = 1; t.lineBreakMode = .byTruncatingTail; t.adjustsFontSizeToFitWidth = true; t.minimumScaleFactor = 0.7
        let x = UIButton(type: .system); x.setTitle("Close", for: .normal); x.tintColor = argbToUIColor(C.GREEN)
        x.addTarget(self, action: #selector(close), for: .touchUpInside)
        let tv = UITextView(); tv.isEditable = false; tv.backgroundColor = .clear; tv.textContainerInset = UIEdgeInsets(top: 14, left: 16, bottom: 40, right: 16)
        let out = NSMutableAttributedString()
        let hp = NSMutableParagraphStyle(); hp.paragraphSpacing = 6; hp.lineBreakMode = .byWordWrapping
        let bp = NSMutableParagraphStyle(); bp.lineSpacing = 3; bp.paragraphSpacing = 22; bp.lineBreakMode = .byWordWrapping
        tv.contentInsetAdjustmentBehavior = .automatic; tv.textContainer.lineFragmentPadding = 0; tv.alwaysBounceVertical = true
        for (h, b) in sections {
            out.append(NSAttributedString(string: h + "\n", attributes: [.font: UIFont.systemFont(ofSize: 17, weight: .bold), .foregroundColor: argbToUIColor(C.GREEN), .paragraphStyle: hp]))
            out.append(NSAttributedString(string: b + "\n", attributes: [.font: UIFont.systemFont(ofSize: 15), .foregroundColor: argbToUIColor(C.TEXT), .paragraphStyle: bp]))
        }
        tv.attributedText = out
        for v in [bar, tv] as [UIView] { v.translatesAutoresizingMaskIntoConstraints = false; view.addSubview(v) }
        for v in [t, x] as [UIView] { v.translatesAutoresizingMaskIntoConstraints = false; bar.addSubview(v) }
        NSLayoutConstraint.activate([
            bar.topAnchor.constraint(equalTo: view.topAnchor), bar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            bar.trailingAnchor.constraint(equalTo: view.trailingAnchor), bar.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 48),
            t.leadingAnchor.constraint(equalTo: bar.leadingAnchor, constant: 16), t.bottomAnchor.constraint(equalTo: bar.bottomAnchor, constant: -12),
            x.trailingAnchor.constraint(equalTo: bar.trailingAnchor, constant: -16), x.centerYAnchor.constraint(equalTo: t.centerYAnchor), t.trailingAnchor.constraint(lessThanOrEqualTo: x.leadingAnchor, constant: -12),
            tv.topAnchor.constraint(equalTo: bar.bottomAnchor), tv.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tv.trailingAnchor.constraint(equalTo: view.trailingAnchor), tv.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)])
    }
    @objc private func close() { dismiss(animated: true) }
}
