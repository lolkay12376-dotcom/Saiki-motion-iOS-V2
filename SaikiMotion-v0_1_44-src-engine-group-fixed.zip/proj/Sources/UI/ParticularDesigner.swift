// ParticularDesigner.swift — full-screen Particle Designer for the Particular effect (UI).
// Own preview viewport (orbit camera, CPU drawn from the same ParticularSim the renderer uses), a block strip
// (Emitter / Particle / Physics / Displace) and a properties panel. All custom drawn, no system icons.

import UIKit
import PhotosUI
import UniformTypeIdentifiers

private let ptAcc = argbToUIColor(C.GREEN)
private var ptOpenFolders: Set<String> = ["Signature"]

private enum PtItem {
    case slider(String, String, Float, Float, Int)
    case choice(String, String, [String])
    case color(String, String, UInt32)
    case graph(String, String)
    case action(String, String)       // button title, action id
    case gradient
}

private struct PtBlock {
    let id: String, title: String
    let items: [PtItem]
    let presets: [(String, Int, [String: Float])]
}

private let ptColorPresets: [(String, UInt32, UInt32)] = [
    ("Warm", ParticularSim.defA, ParticularSim.defB), ("White", 0xFFFFFFFF, 0xFFFFFFFF), ("Fire", 0xFFFFF2B0, 0xFFFF3B00), ("Ice", 0xFFFFFFFF, 0xFF38BDF8),
    ("Aqualight", 0xFFB6E3C2, 0xFF1E9BD7), ("Autumn", 0xFF3CBF3C, 0xFFE8401C), ("Basic Red", 0xFFFF0000, 0xFFFF0000),
    ("Blue Ramp", 0xFF4B4BFF, 0xFF2A2AA0), ("Neon", 0xFFFF2BD6, 0xFF2BFFE0), ("Gold", 0xFFFFE27A, 0xFFC77700)]

private let ptEmitterPresets: [(String, Int, [String: Float])] = ParticularSim.emitterNames.enumerated().map { e -> (String, Int, [String: Float]) in
    (e.element, e.offset, ["ptEmType": Float(e.offset)]) }
private let ptMotionPresets: [(String, Int, [String: Float])] = ParticularSim.motionNames.enumerated().map { e -> (String, Int, [String: Float]) in
    (e.element, e.offset, ["ptMotion": Float(e.offset)]) }

private let ptBlocks: [PtBlock] = [
    PtBlock(id: "emitter", title: "EMITTER TYPE", items: [
        .choice("ptEmType", "Emitter Type", ParticularSim.emitterNames),
        .slider("ptModelLayer", "Model Layer ID (0 = first)", 0, 100000, 0),
        .action("Draw Path in 3D View", "pathDraw"), .action("Add Stroke to Path", "pathAdd"), .action("Clear Path", "pathClr"),
        .choice("ptPathMode", "Path Mode", ["Spread along path", "Travelling head"]), .slider("ptPathFlow", "Flow Speed", -2, 2, 2),
        .slider("ptPathSpeed", "Head Speed", 0, 4, 2), .choice("ptPathClosed", "Path Loop", ["Open", "Closed"]),
        .choice("ptBehavior", "Emitter Behavior", ParticularSim.behaviorNames),
        .slider("ptRate", "Particles/sec", 1, 2000, 0),
        .slider("ptPosX", "Position X", -3, 3, 2), .slider("ptPosY", "Position Y", -3, 3, 2), .slider("ptPosZ", "Position Z", -4, 4, 2),
        .slider("ptSizeX", "Radius X", 0, 4, 2), .slider("ptSizeY", "Radius Y", 0, 4, 2), .slider("ptSizeZ", "Radius Z", 0, 4, 2),
        .slider("ptGridN", "Grid cells", 2, 16, 0), .slider("ptSeed", "Random Seed", 0, 100, 0)],
        presets: ptEmitterPresets),
    PtBlock(id: "motion", title: "MOTION", items: [
        .choice("ptMotion", "Motion", ParticularSim.motionNames),
        .slider("ptVel", "Velocity", 0, 3, 2), .slider("ptVelRand", "Velocity Random", 0, 1, 2), .slider("ptSpread", "Spread", 0, 2, 2),
        .slider("ptDirX", "Direction X", -1, 1, 2), .slider("ptDirY", "Direction Y", -1, 1, 2), .slider("ptDirZ", "Direction Z", -1, 1, 2),
        .slider("ptLife", "Particle Life (s)", 0.2, 20, 2), .slider("ptLifeRand", "Life Random", 0, 1, 2),
        .graph("Sp", "Speed over life")],
        presets: ptMotionPresets),
    PtBlock(id: "source", title: "IMAGE / VIDEO", items: [
        .action("Import Image as Emitter", "emImg"), .action("Import Video as Emitter", "emVid"), .action("Remove Emitter Media", "emClr"),
        .slider("ptImgColor", "Use Media Colour", 0, 1, 2), .slider("ptEmFps", "Video Emitter FPS", 0.1, 60, 1)],
        presets: []),
    PtBlock(id: "type", title: "PARTICLE TYPE", items: [
        .choice("ptSprite", "Particle Shape", PtSprites.names),
        .slider("ptVolume", "Volumetric Shading", 0, 1, 2), .slider("ptVolLight", "Light Angle", -180, 180, 0),
        .action("Import Shape from Image", "spImg"), .action("Import Shape (black bg → clear)", "spKeyImg"), .action("Import Shape from Video", "spVid"),
        .slider("ptBump", "Bump Strength", 0, 3, 2), .action("Import Bump Map", "bpImg"), .action("Remove Custom Bump Map", "bpClr"), .slider("ptTumble", "3D Tumble", 0, 1, 2),
        .slider("ptGlow", "Glow", 0, 3, 2), .slider("ptGlowSize", "Glow Size", 0.5, 6, 2),
        .choice("ptSpriteAnim", "Animate Shape (video)", ["Off", "On"]), .slider("ptSpriteTint", "Shape Tint", 0, 1, 2),
        .slider("ptSize", "Particle Size", 0.002, 0.2, 3), .slider("ptSoft", "Softness", 0, 1, 2),
        .slider("ptDof", "Depth of Field", 0, 2, 2), .slider("ptFocus", "Focus Depth", -4, 4, 2)],
        presets: [("Dot", 0, ["ptSprite": 0, "ptSoft": 0]), ("Sphere", 1, ["ptSprite": 0, "ptSoft": 0.5]), ("Glow Sphere", 2, ["ptSprite": 0, "ptSoft": 1]),
                  ("Square", 3, ["ptSprite": 1, "ptSpriteTint": 1, "ptSoft": 0]), ("Star", 4, ["ptSprite": 2, "ptSpriteTint": 1]),
                  ("Glyph", 5, ["ptSprite": 3, "ptSpriteTint": 1]), ("Petal", 6, ["ptSprite": 4, "ptSpriteTint": 0]), ("Bokeh", 7, ["ptSprite": 5, "ptSpriteTint": 1]),
                  ("Cloud", 8, ["ptSprite": 8, "ptSpriteTint": 1, "ptVolume": 0.8, "ptSoft": 0.4]), ("Leaf", 9, ["ptSprite": 9, "ptSpriteTint": 0]),
                  ("Maple Leaf", 10, ["ptSprite": 10, "ptSpriteTint": 0, "ptBump": 1.3, "ptTumble": 0.8])]),
    PtBlock(id: "size", title: "SIZE / ROTATION", items: [
        .graph("Sz", "Size over life"),
        .slider("ptSizeRand", "Size Random", 0, 1, 2), .slider("ptSizeStart", "Size at Birth", 0, 3, 2), .slider("ptSizeEnd", "Size at Death", 0, 3, 2)],
        presets: [("Default", 0, ["ptSizeStart": 1, "ptSizeEnd": 1]), ("Grow", 1, ["ptSizeStart": 0.2, "ptSizeEnd": 1.6]),
                  ("Shrink", 2, ["ptSizeStart": 1.6, "ptSizeEnd": 0.1])]),
    PtBlock(id: "opacity", title: "OPACITY", items: [
        .graph("Op", "Opacity over life"),
        .slider("ptOpacity", "Opacity", 0, 1, 2), .slider("ptFadeIn", "Fade In", 0.001, 1, 3), .slider("ptFadeOut", "Fade Out", 0.001, 1, 3)],
        presets: [("Default", 0, ["ptFadeIn": 0.05, "ptFadeOut": 0.3]), ("Bell Curve", 1, ["ptFadeIn": 0.35, "ptFadeOut": 0.35]),
                  ("Ease Opacity Mid", 2, ["ptFadeIn": 0.1, "ptFadeOut": 0.6]), ("Linear Fade", 3, ["ptFadeIn": 0.001, "ptFadeOut": 1])]),
    PtBlock(id: "color", title: "COLOR", items: [
        .color("ptColA", "Birth color", ParticularSim.defA), .color("ptColB", "Death color", ParticularSim.defB)], presets: []),
    PtBlock(id: "gradient", title: "GRADIENT", items: [
        .choice("ptGrOn", "Colour over life", ["Birth / Death", "Gradient"]), .choice("ptGrBy", "Gradient by", ["Life", "Random per particle"]), .gradient],
        presets: []),
    PtBlock(id: "env", title: "ENVIRONMENT", items: [
        .slider("ptGravity", "Gravity", -3, 3, 2), .slider("ptAir", "Air Resistance", 0, 1, 2),
        .slider("ptWindX", "Wind X", -3, 3, 2), .slider("ptWindY", "Wind Y", -3, 3, 2), .slider("ptWindZ", "Wind Z", -3, 3, 2),
        .slider("ptSwirl", "Swirl (rad/s)", -6, 6, 2), .slider("ptSwirlPull", "Swirl Pull", 0, 1, 2),
        .slider("ptAttract", "Attractor Strength", 0, 1, 2), .slider("ptAttX", "Attractor X", -3, 3, 2),
        .slider("ptAttY", "Attractor Y", -3, 3, 2), .slider("ptAttZ", "Attractor Z", -3, 3, 2),
        .choice("ptFloorOn", "Floor", ["Off", "On"]), .slider("ptFloorY", "Floor Y", -3, 3, 2), .slider("ptBounce", "Bounce", 0, 1, 2)],
        presets: [("Off", 0, ["ptGravity": 0, "ptWindX": 0, "ptWindY": 0, "ptWindZ": 0, "ptAir": 0, "ptSwirl": 0, "ptSwirlPull": 0, "ptAttract": 0, "ptFloorOn": 0]),
                  ("Gravity", 1, ["ptGravity": 1, "ptAir": 0.2]), ("Wind", 1, ["ptWindX": 1.2]),
                  ("Vortex", 1, ["ptSwirl": 2.5, "ptSwirlPull": 0.3]), ("Black Hole", 1, ["ptAttract": 0.9, "ptSwirl": 3]),
                  ("Floor Bounce", 2, ["ptGravity": 1.5, "ptFloorOn": 1, "ptFloorY": -1, "ptBounce": 0.6])]),
    PtBlock(id: "curl", title: "CURL NOISE", items: [
        .slider("ptCurl", "Curl Strength", 0, 3, 2), .slider("ptCurlScale", "Curl Scale", 0.05, 5, 2), .slider("ptCurlSpeed", "Curl Speed", 0, 5, 2)],
        presets: [("Off", 0, ["ptCurl": 0]), ("Soft", 1, ["ptCurl": 0.6, "ptCurlScale": 1]), ("Strong", 2, ["ptCurl": 1.6, "ptCurlScale": 1.2]),
                  ("Wild", 3, ["ptCurl": 2.6, "ptCurlScale": 2.2, "ptCurlSpeed": 1.5]), ("Slow Swirl", 4, ["ptCurl": 1.2, "ptCurlScale": 0.4, "ptCurlSpeed": 0.2])]),
    PtBlock(id: "wave", title: "FLUID WAVE", items: [
        .slider("ptWaveAmp", "Wave Height", 0, 2, 2), .slider("ptWaveFreq", "Wave Frequency", 0, 10, 2),
        .slider("ptWaveSpeed", "Wave Speed", -8, 8, 2), .slider("ptWaveFlow", "Wave Flow", -3, 3, 2)],
        presets: [("Off", 0, ["ptWaveAmp": 0, "ptWaveFlow": 0]), ("Ripple", 1, ["ptWaveAmp": 0.08, "ptWaveFreq": 6, "ptWaveSpeed": 3]),
                  ("Ocean", 2, ["ptWaveAmp": 0.25, "ptWaveFreq": 3, "ptWaveSpeed": 2]), ("Flag", 3, ["ptWaveAmp": 0.15, "ptWaveFreq": 4, "ptWaveSpeed": 4, "ptWaveFlow": 0.5]),
                  ("Tsunami", 4, ["ptWaveAmp": 0.6, "ptWaveFreq": 1.5, "ptWaveSpeed": 1.5])]),
    PtBlock(id: "flutter", title: "FLUTTER / SPIN", items: [
        .slider("ptFlutter", "Flutter", 0, 3, 2), .slider("ptFlutterFreq", "Flutter Speed", 0.1, 10, 2),
        .slider("ptSpin", "Spin (rad/s)", -10, 10, 2), .slider("ptSpinRand", "Spin Random", 0, 1, 2)],
        presets: [("Off", 0, ["ptFlutter": 0, "ptSpin": 0, "ptSpinRand": 0]), ("Petal Sway", 1, ["ptFlutter": 1.2, "ptFlutterFreq": 2.2, "ptSpin": 1.6, "ptSpinRand": 1]),
                  ("Leaf", 2, ["ptFlutter": 2, "ptFlutterFreq": 1.2, "ptSpin": 1, "ptSpinRand": 1]), ("Tumble", 3, ["ptFlutter": 0.3, "ptFlutterFreq": 3, "ptSpin": 5, "ptSpinRand": 1])]),
    PtBlock(id: "trail", title: "TRAILS", items: [
        .slider("ptTrail", "Trail Copies", 0, 10, 0), .slider("ptTrailLen", "Trail Length (s)", 0.02, 2, 2),
        .slider("ptMBlur", "Motion Blur", 0, 4, 2), .slider("ptMBSamples", "Blur Samples", 3, 10, 0)],
        presets: [("Off", 0, ["ptTrail": 0]), ("Short", 1, ["ptTrail": 3, "ptTrailLen": 0.15]), ("Long", 2, ["ptTrail": 8, "ptTrailLen": 0.7]), ("Comet", 3, ["ptTrail": 10, "ptTrailLen": 1.2])]),
    PtBlock(id: "shock", title: "SHOCKWAVE", items: [
        .slider("ptShockAmp", "Push Strength", 0, 3, 2), .slider("ptShockSpeed", "Wave Speed", 0, 6, 2), .slider("ptShockWidth", "Wave Width", 0.02, 1, 2),
        .slider("ptShockPeriod", "Repeat every (s, 0 = once)", 0, 10, 2), .slider("ptShockGlow", "Glow in the wave", 0, 4, 2)],
        presets: [("Off", 0, ["ptShockAmp": 0]), ("Pulse", 1, ["ptShockAmp": 0.3, "ptShockSpeed": 1.2, "ptShockWidth": 0.12, "ptShockPeriod": 2, "ptShockGlow": 2]),
                  ("Ripple", 2, ["ptShockAmp": 0.15, "ptShockSpeed": 0.8, "ptShockWidth": 0.2, "ptShockPeriod": 1.2, "ptShockGlow": 1]),
                  ("Blast", 3, ["ptShockAmp": 1.2, "ptShockSpeed": 2, "ptShockWidth": 0.08, "ptShockPeriod": 3, "ptShockGlow": 3]),
                  ("Slow Ring", 4, ["ptShockAmp": 0.5, "ptShockSpeed": 0.5, "ptShockWidth": 0.3, "ptShockPeriod": 4, "ptShockGlow": 2])]),
    PtBlock(id: "field", title: "FIELDS", items: [
        .slider("ptTurb", "Turbulence", 0, 3, 2), .slider("ptTurbFreq", "Turbulence Scale", 0.05, 5, 2), .slider("ptTurbSpeed", "Turbulence Speed", 0, 5, 2)],
        presets: [("Off", 0, ["ptTurb": 0]), ("Turbulence", 1, ["ptTurb": 1])]),
    PtBlock(id: "scatter", title: "DISSOLVE", items: [
        .choice("ptBehavior", "Emitter Behavior (pick Dissolve)", ParticularSim.behaviorNames),
        .slider("ptScatter", "Scatter", 0, 4, 2), .slider("ptDissStart", "Dissolve Start (s)", 0, 10, 2),
        .slider("ptDissDur", "Dissolve Duration (s)", 0.05, 10, 2), .slider("ptDissSweep", "Sweep (0 random, 1 left to right)", 0, 1, 2)],
        presets: [("Off", 0, ["ptScatter": 0]), ("Dust", 1, ["ptScatter": 1.2]), ("Blow Away", 2, ["ptScatter": 0.6, "ptWindX": 1.2]),
                  ("Sweep", 3, ["ptDissSweep": 1, "ptScatter": 0.8])]),
    PtBlock(id: "quant", title: "GRID SNAP", items: [.slider("ptQuant", "Cell Size", 0, 0.5, 3)],
        presets: [("Off", 0, ["ptQuant": 0]), ("Fine", 1, ["ptQuant": 0.04]), ("Coarse", 2, ["ptQuant": 0.1]), ("Chunky", 3, ["ptQuant": 0.2])]),
    PtBlock(id: "twinkle", title: "TWINKLE", items: [.slider("ptTwinkle", "Twinkle", 0, 1, 2), .slider("ptTwinkleRate", "Twinkle Rate", 0.1, 20, 2)],
        presets: [("Off", 0, ["ptTwinkle": 0]), ("Soft", 1, ["ptTwinkle": 0.4, "ptTwinkleRate": 2]), ("Strong", 2, ["ptTwinkle": 0.9, "ptTwinkleRate": 6])]),
]
private let ptTabs: [(String, [String])] = [("Presets", ["presets"]), ("Emitter", ["emitter", "motion", "source"]),
                                            ("Particle", ["type", "size", "opacity", "color", "gradient"]),
                                            ("Physics", ["env", "curl", "wave", "flutter", "trail", "shock"]), ("Displace", ["field", "scatter", "quant", "twinkle"])]
private let ptThumbBlocks: Set<String> = ["emitter", "motion", "source", "type", "env", "curl", "wave", "flutter", "trail", "shock", "field", "scatter", "quant", "twinkle"]

private func ptArgb(_ l: Layer, _ k: String, _ d: UInt32) -> UInt32 {
    func comp(_ s: String, _ sh: UInt32) -> UInt32 { l.props[k + s].map { UInt32(max(0, min(255, $0.eval(Editor.time) * 255 + 0.5))) } ?? ((d >> sh) & 0xFF) }
    return comp("_a", 24) << 24 | comp("_r", 16) << 16 | comp("_g", 8) << 8 | comp("_b", 0)
}

/// Thumbnail recipe for a block tile: a small demo emitter that shows what the block's settings do.
private func ptThumbSpec(_ id: String, _ over: [String: Float]) -> (key: String, p: [String: Float], t: Float, yaw: CGFloat, pitch: CGFloat, dist: CGFloat)? {
    var p: [String: Float] = [:], t: Float = 2, yaw: CGFloat = 0.25, pitch: CGFloat = 0.12, dist: CGFloat = 3.3
    let stream: [String: Float] = ["ptEmType": 1, "ptSizeX": 0.5, "ptSizeY": 0.02, "ptSizeZ": 0.2, "ptPosY": -0.6, "ptMotion": 2, "ptDirY": 1, "ptVel": 0.7,
                                   "ptSpread": 0.15, "ptRate": 50, "ptLife": 3, "ptSize": 0.012, "ptSoft": 0.5]
    switch id {
    case "emitter":
        let ty = Int((over["ptEmType"] ?? 0).rounded())
        return ("e\(ty)", PtThumb.emitterParams(ty), 1, 0.55, 0.35, 2.2)
    case "motion":
        p = ["ptEmType": 0, "ptVel": 0.6, "ptRate": 120, "ptLife": 2.5, "ptSize": 0.014, "ptSpread": 0.6, "ptVelRand": 0.3, "ptSoft": 0.5, "ptDirY": 1]
        p["ptMotion"] = over["ptMotion"] ?? 0; t = 1.5; dist = 2.6
        return ("m\(Int(p["ptMotion"] ?? 0))", p, t, 0.4, 0.25, dist)
    case "type":
        p = ["ptEmType": 6, "ptSizeX": 0.6, "ptVel": 0, "ptRate": 2, "ptLife": 2, "ptSize": 0.12, "ptSizeRand": 0, "ptBehavior": 1, "ptFadeIn": 0.001, "ptFadeOut": 0.001]
        t = 1; dist = 2.4
    case "wave":
        p = ["ptEmType": 1, "ptSizeX": 1.2, "ptSizeY": 0.01, "ptSizeZ": 0.6, "ptVel": 0, "ptRate": 300, "ptLife": 4, "ptLifeRand": 0, "ptSize": 0.01, "ptSoft": 0.5,
             "ptWaveFreq": 3, "ptFadeIn": 0.1, "ptFadeOut": 0.1]
        pitch = 0.3
    case "shock":
        p = ["ptEmType": 16, "ptSizeX": 0.9, "ptSizeY": 0.9, "ptVel": 0, "ptRate": 700, "ptLife": 4, "ptLifeRand": 0, "ptSize": 0.008, "ptFadeIn": 0.2, "ptFadeOut": 0.2, "ptShockPeriod": 2]
        t = 1.2
    case "scatter":
        p = ["ptEmType": 11, "ptBehavior": 2, "ptSizeX": 0.6, "ptSizeY": 0.6, "ptRate": 600, "ptLife": 2, "ptVel": 0.1, "ptDissStart": 0.2, "ptDissDur": 1.5, "ptSize": 0.008, "ptSoft": 0.3]
        t = 1.2
    case "source":
        p = ["ptEmType": 11, "ptSizeX": 0.8, "ptSizeY": 0.8, "ptVel": 0, "ptRate": 400, "ptLife": 2, "ptSize": 0.012, "ptSoft": 0.3, "ptBehavior": 1, "ptFadeIn": 0.001, "ptFadeOut": 0.001]
        t = 1; dist = 2.6
    case "env", "curl", "flutter", "trail", "field", "quant", "twinkle":
        p = stream
    default: return nil
    }
    if p.isEmpty { p = stream }
    p.merge(over) { $1 }
    let key = id + ":" + over.sorted { $0.key < $1.key }.map { "\($0.key)=\($0.value)" }.joined(separator: ",")
    return (key, p, t, yaw, pitch, dist)
}
// MARK: - Block art (custom drawn)

private func ptArt(_ c: CGContext, _ kind: String, _ v: Int, _ r: CGRect, _ ca: UIColor? = nil, _ cb: UIColor? = nil) {
    c.saveGState(); c.clip(to: r)
    c.setFillColor(UIColor(white: 0.04, alpha: 1).cgColor); c.fill(r)
    let cx = r.midX, cy = r.midY, s = min(r.width, r.height)
    let w = UIColor.white, a = ptAcc
    func dot(_ x: CGFloat, _ y: CGFloat, _ d: CGFloat, _ col: UIColor = w) {
        c.setFillColor(col.cgColor); c.fillEllipse(in: CGRect(x: x - d / 2, y: y - d / 2, width: d, height: d))
    }
    func line(_ x0: CGFloat, _ y0: CGFloat, _ x1: CGFloat, _ y1: CGFloat, _ col: UIColor = w, _ lw: CGFloat = 1.2) {
        c.setStrokeColor(col.cgColor); c.setLineWidth(lw); c.move(to: CGPoint(x: x0, y: y0)); c.addLine(to: CGPoint(x: x1, y: y1)); c.strokePath()
    }
    func rnd(_ i: Int) -> CGFloat { CGFloat((i &* 7919 &+ 13) % 1000) / 1000 }
    switch kind {
    case "emitter":
        for i in 0..<46 {
            let u = rnd(i), q = rnd(i + 99)
            switch v {
            case 1: dot(cx + (u - 0.5) * s * 0.7, cy + (q - 0.5) * s * 0.7, 2)
            case 2: let an = u * 6.283, rr = sqrt(q) * s * 0.36; dot(cx + cos(an) * rr, cy + sin(an) * rr, 2)
            case 3: dot(cx + (CGFloat(i % 7) - 3) * s * 0.1, cy + (CGFloat(i / 7 % 6) - 2.5) * s * 0.1, 2)
            default: let an = u * 6.283, rr = q * s * 0.1; dot(cx + cos(an) * rr, cy + sin(an) * rr, 2.4, a)
            }
        }
    case "motion":
        for i in 0..<18 {
            let an = CGFloat(i) / 18 * 6.283
            switch v {
            case 1: if abs(cos(an)) > 0.8 { line(cx, cy, cx + cos(an) * s * 0.42, cy + sin(an) * s * 0.42 * 0.3, a) }
            case 2: if cos(an) > 0.5 { line(cx - s * 0.3, cy, cx - s * 0.3 + cos(an) * s * 0.7, cy + sin(an) * s * 0.5, a) }
            case 3: line(cx + cos(an) * s * 0.12, cy + sin(an) * s * 0.04, cx + cos(an) * s * 0.42, cy + sin(an) * s * 0.14, a)
            case 4: line(cx + cos(an) * s * 0.42, cy + sin(an) * s * 0.42, cx + cos(an) * s * 0.1, cy + sin(an) * s * 0.1, a)
            default: line(cx + cos(an) * s * 0.06, cy + sin(an) * s * 0.06, cx + cos(an) * s * 0.42, cy + sin(an) * s * 0.42, a)
            }
        }
    case "type":
        let cs = CGColorSpaceCreateDeviceRGB()
        let hard: CGFloat = v == 0 ? 0.92 : (v == 1 ? 0.5 : 0.0)
        let g = CGGradient(colorsSpace: cs, colors: [w.cgColor, w.cgColor, w.withAlphaComponent(0).cgColor] as CFArray, locations: [0, hard, 1])!
        c.drawRadialGradient(g, startCenter: CGPoint(x: cx, y: cy), startRadius: 0, endCenter: CGPoint(x: cx, y: cy), endRadius: s * 0.4, options: [])
    case "size":
        let sz: [CGFloat] = v == 1 ? [0.06, 0.1, 0.15, 0.21] : (v == 2 ? [0.21, 0.15, 0.1, 0.06] : [0.12, 0.12, 0.12, 0.12])
        for (i, d) in sz.enumerated() { dot(r.minX + s * (0.2 + CGFloat(i) * 0.2), cy, d * s * 1.6, i % 2 == 0 ? w : a) }
    case "opacity", "color":
        if kind == "color" {
            let g = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: [(ca ?? w).cgColor, (cb ?? w).cgColor] as CFArray, locations: [0, 1])!
            let b = r.insetBy(dx: s * 0.2, dy: s * 0.2)
            c.saveGState(); c.clip(to: b); c.drawLinearGradient(g, start: CGPoint(x: b.minX, y: cy), end: CGPoint(x: b.maxX, y: cy), options: []); c.restoreGState()
        } else {
            let b = r.insetBy(dx: s * 0.15, dy: s * 0.22)
            let p = UIBezierPath(); p.move(to: CGPoint(x: b.minX, y: b.maxY))
            switch v {
            case 1: p.addLine(to: CGPoint(x: b.minX + b.width * 0.3, y: b.minY)); p.addLine(to: CGPoint(x: b.minX + b.width * 0.7, y: b.minY))
            case 2: p.addLine(to: CGPoint(x: b.minX + b.width * 0.15, y: b.minY)); p.addLine(to: CGPoint(x: b.minX + b.width * 0.5, y: b.minY))
            case 3: p.addLine(to: CGPoint(x: b.minX, y: b.minY))
            default: p.addLine(to: CGPoint(x: b.minX, y: b.minY)); p.addLine(to: CGPoint(x: b.maxX, y: b.minY))
            }
            p.addLine(to: CGPoint(x: b.maxX, y: v == 0 ? b.minY : (v == 3 ? b.maxY : b.maxY))); p.addLine(to: CGPoint(x: b.maxX, y: b.maxY)); p.close()
            c.setFillColor(a.withAlphaComponent(0.85).cgColor); c.addPath(p.cgPath); c.fillPath()
        }
    case "env":
        for i in 0..<5 {
            let x0 = r.minX + s * (0.2 + CGFloat(i) * 0.15)
            c.setStrokeColor(w.withAlphaComponent(0.8).cgColor); c.setLineWidth(1.2)
            c.move(to: CGPoint(x: x0, y: r.minY + s * 0.15))
            c.addQuadCurve(to: CGPoint(x: x0 + s * 0.2, y: r.maxY - s * 0.1), control: CGPoint(x: x0 + s * 0.02, y: cy)); c.strokePath()
        }
    case "act_import", "act_export":
        let up = kind == "act_export"
        let top = cy - s * 0.28, bot = cy + s * 0.14
        line(cx, top, cx, bot, a, 2.4)
        let tip = up ? top : bot, dir: CGFloat = up ? 1 : -1
        line(cx, tip, cx - s * 0.13, tip + dir * s * 0.13, a, 2.4); line(cx, tip, cx + s * 0.13, tip + dir * s * 0.13, a, 2.4)
        line(cx - s * 0.3, cy + s * 0.3, cx + s * 0.3, cy + s * 0.3, w, 2); line(cx - s * 0.3, cy + s * 0.2, cx - s * 0.3, cy + s * 0.3, w, 2); line(cx + s * 0.3, cy + s * 0.2, cx + s * 0.3, cy + s * 0.3, w, 2)
    case "act_save":
        line(cx - s * 0.25, cy, cx + s * 0.25, cy, a, 3); line(cx, cy - s * 0.25, cx, cy + s * 0.25, a, 3)
    default: // field
        for i in 0..<5 {
            let t = r.minY + s * (0.2 + CGFloat(i) * 0.15)
            c.setStrokeColor(a.withAlphaComponent(0.9).cgColor); c.setLineWidth(1)
            c.move(to: CGPoint(x: r.minX + s * 0.12, y: t))
            c.addCurve(to: CGPoint(x: r.maxX - s * 0.12, y: t), control1: CGPoint(x: cx - s * 0.1, y: t - s * 0.14), control2: CGPoint(x: cx + s * 0.1, y: t + s * 0.14)); c.strokePath()
        }
    }
    c.restoreGState()
}
// MARK: - Tiles

private final class PtTile: TapView {
    var kind = "emitter", variant = 0, title = "", value = "", picked = false
    var ca: UIColor? = nil, cb: UIColor? = nil
    var thumb: UIImage? = nil
    var stops: [PtStop]? = nil
    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let art = CGRect(x: 0, y: 0, width: bounds.width, height: bounds.height - 34)
        if let st = stops, st.count >= 2 {
            c.setFillColor(UIColor(white: 0.04, alpha: 1).cgColor); c.fill(art)
            let cols = st.map { UIColor(red: CGFloat($0.r), green: CGFloat($0.g), blue: CGFloat($0.b), alpha: CGFloat($0.a)).cgColor } as CFArray
            if let g = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: cols, locations: st.map { CGFloat($0.p) }) {
                let b = art.insetBy(dx: art.width * 0.12, dy: art.height * 0.28)
                c.saveGState(); c.clip(to: b)
                c.drawLinearGradient(g, start: CGPoint(x: b.minX, y: 0), end: CGPoint(x: b.maxX, y: 0), options: [.drawsBeforeStartLocation, .drawsAfterEndLocation])
                c.restoreGState()
            }
        } else if let th = thumb {
            c.saveGState(); c.clip(to: art)
            let s = max(art.width, art.height)
            th.draw(in: CGRect(x: art.midX - s / 2, y: art.midY - s / 2, width: s, height: s))
            c.restoreGState()
        } else {
            ptArt(c, kind, variant, art, ca, cb)
        }
        c.setFillColor((picked ? UIColor.white : UIColor(white: 0.62, alpha: 1)).cgColor)
        c.fill(CGRect(x: 0, y: art.maxY, width: bounds.width, height: 34))
        let ps = NSMutableParagraphStyle(); ps.alignment = .center; ps.lineBreakMode = .byTruncatingTail
        let t1: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 10.5, weight: .medium), .foregroundColor: UIColor.black, .paragraphStyle: ps]
        let t2: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 10), .foregroundColor: UIColor(white: 0.2, alpha: 1), .paragraphStyle: ps]
        (title as NSString).draw(in: CGRect(x: 2, y: art.maxY + 3, width: bounds.width - 4, height: 14), withAttributes: t1)
        if !value.isEmpty { (value as NSString).draw(in: CGRect(x: 2, y: art.maxY + 17, width: bounds.width - 4, height: 13), withAttributes: t2) }
        if picked { c.setStrokeColor(ptAcc.cgColor); c.setLineWidth(2.5); c.stroke(bounds.insetBy(dx: 1.25, dy: 1.25)) }
    }
}

/// Big preset tile: a real render of the particle with its name underneath.
private final class PtPresetTile: TapView {
    var title = "", sub = ""
    var thumb: UIImage? = nil
    var onLong: (() -> Void)? = nil
    override init(frame: CGRect) {
        super.init(frame: frame)
        addGestureRecognizer(UILongPressGestureRecognizer(target: self, action: #selector(lp(_:))))
    }
    required init?(coder: NSCoder) { fatalError() }
    @objc private func lp(_ g: UILongPressGestureRecognizer) { if g.state == .began { isHighlighted = false; onLong?() } }
    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let art = CGRect(x: 0, y: 0, width: bounds.width, height: bounds.height - 34)
        c.setFillColor(UIColor(white: 0.03, alpha: 1).cgColor); c.fill(art)
        if let th = thumb {
            c.saveGState(); c.clip(to: art)
            let s = max(art.width, art.height)
            th.draw(in: CGRect(x: art.midX - s / 2, y: art.midY - s / 2, width: s, height: s))
            c.restoreGState()
        }
        c.setFillColor(argbToUIColor(C.CARD2).cgColor); c.fill(CGRect(x: 0, y: art.maxY, width: bounds.width, height: 34))
        let ps = NSMutableParagraphStyle(); ps.alignment = .center; ps.lineBreakMode = .byTruncatingTail
        (title as NSString).draw(in: CGRect(x: 4, y: art.maxY + 3, width: bounds.width - 8, height: 15),
                                 withAttributes: [.font: UIFont.systemFont(ofSize: 12, weight: .semibold), .foregroundColor: UIColor.white, .paragraphStyle: ps])
        (sub as NSString).draw(in: CGRect(x: 4, y: art.maxY + 18, width: bounds.width - 8, height: 13),
                               withAttributes: [.font: UIFont.systemFont(ofSize: 10), .foregroundColor: argbToUIColor(C.DIM), .paragraphStyle: ps])
        if isHighlighted { c.setStrokeColor(ptAcc.cgColor); c.setLineWidth(2.5); c.stroke(bounds.insetBy(dx: 1.25, dy: 1.25)) }
    }
}

private final class PtPresetGrid: UIView {
    var cols = 3, tileH: CGFloat = 100
    override func layoutSubviews() {
        super.layoutSubviews()
        let tw = (bounds.width - 8 * CGFloat(cols - 1)) / CGFloat(cols)
        for (i, v) in subviews.enumerated() {
            v.frame = CGRect(x: CGFloat(i % cols) * (tw + 8), y: CGFloat(i / cols) * (tileH + 8), width: tw, height: tileH)
        }
    }
}
private final class PtGlyph: TapView {
    var kind = "play"
    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let m = bounds.midX, n = bounds.midY, s: CGFloat = 8
        c.setFillColor((isHighlighted ? ptAcc : UIColor.white).cgColor)
        switch kind {
        case "pause": c.fill(CGRect(x: m - s * 0.8, y: n - s, width: s * 0.55, height: s * 2)); c.fill(CGRect(x: m + s * 0.25, y: n - s, width: s * 0.55, height: s * 2))
        case "back", "next":
            let d: CGFloat = kind == "back" ? -1 : 1
            c.move(to: CGPoint(x: m - d * s * 0.5, y: n - s)); c.addLine(to: CGPoint(x: m + d * s * 0.8, y: n)); c.addLine(to: CGPoint(x: m - d * s * 0.5, y: n + s)); c.fillPath()
            c.fill(CGRect(x: m - d * s * 0.8 - 1, y: n - s, width: 2, height: s * 2))
        default: c.move(to: CGPoint(x: m - s * 0.6, y: n - s)); c.addLine(to: CGPoint(x: m + s, y: n)); c.addLine(to: CGPoint(x: m - s * 0.6, y: n + s)); c.fillPath()
        }
    }
}

// MARK: - Custom life graph (add / move / remove points)

private final class PtGraphView: UIControl {
    var cid = "Op", range: Float = 1
    weak var lay: Layer?
    var onEdit: (() -> Void)?
    private(set) var pts: [(Float, Float)] = []
    private var sel = -1
    var pre = ""

    func load() {
        guard let l = lay else { return }
        pts = PtCurve.read({ l.p(self.pre + $0, Editor.time) }, cid)
        if pts.count < 2 { pts = PtCurve.defaults[cid] ?? [(0, 0.5), (1, 0.5)] }
        sel = -1; setNeedsDisplay()
    }
    private var plot: CGRect { bounds.insetBy(dx: 34, dy: 16) }
    private func toPt(_ p: (Float, Float)) -> CGPoint { CGPoint(x: plot.minX + CGFloat(p.0) * plot.width, y: plot.maxY - CGFloat(p.1) * plot.height) }
    private func fromPt(_ q: CGPoint) -> (Float, Float) {
        (Float(min(1, max(0, (q.x - plot.minX) / plot.width))), Float(min(1, max(0, (plot.maxY - q.y) / plot.height))))
    }
    private func commit() { if let l = lay { PtCurve.write(l, cid, pts, pre: pre) }; onEdit?() }
    func removeSelected() { if sel > 0 && sel < pts.count - 1 { pts.remove(at: sel); sel = -1; commit(); setNeedsDisplay() } }
    func reset() { pts = PtCurve.defaults[cid] ?? pts; sel = -1; commit(); setNeedsDisplay() }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        c.setFillColor(UIColor(white: 0.05, alpha: 1).cgColor); c.fill(bounds)
        let pl = plot
        c.setStrokeColor(UIColor(white: 1, alpha: 0.09).cgColor); c.setLineWidth(1)
        for i in 0...4 {
            let x = pl.minX + pl.width * CGFloat(i) / 4, y = pl.minY + pl.height * CGFloat(i) / 4
            c.move(to: CGPoint(x: x, y: pl.minY)); c.addLine(to: CGPoint(x: x, y: pl.maxY))
            c.move(to: CGPoint(x: pl.minX, y: y)); c.addLine(to: CGPoint(x: pl.maxX, y: y))
        }
        c.strokePath()
        let lf: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 10), .foregroundColor: UIColor(white: 0.55, alpha: 1)]
        ("\(String(format: "%.1f", range))" as NSString).draw(at: CGPoint(x: 6, y: pl.minY - 6), withAttributes: lf)
        ("0" as NSString).draw(at: CGPoint(x: 6, y: pl.maxY - 6), withAttributes: lf)
        ("Birth" as NSString).draw(at: CGPoint(x: pl.minX, y: pl.maxY + 2), withAttributes: lf)
        ("Death" as NSString).draw(at: CGPoint(x: pl.maxX - 28, y: pl.maxY + 2), withAttributes: lf)
        let path = UIBezierPath()
        for (i, p) in pts.enumerated() { i == 0 ? path.move(to: toPt(p)) : path.addLine(to: toPt(p)) }
        let fill = UIBezierPath(cgPath: path.cgPath)
        if let f = pts.first, let l = pts.last { fill.addLine(to: CGPoint(x: toPt(l).x, y: pl.maxY)); fill.addLine(to: CGPoint(x: toPt(f).x, y: pl.maxY)); fill.close() }
        c.setFillColor(ptAcc.withAlphaComponent(0.16).cgColor); c.addPath(fill.cgPath); c.fillPath()
        c.setStrokeColor(ptAcc.cgColor); c.setLineWidth(2); c.addPath(path.cgPath); c.strokePath()
        for (i, p) in pts.enumerated() {
            let q = toPt(p), r: CGFloat = i == sel ? 8 : 6
            c.setFillColor((i == sel ? UIColor.white : ptAcc).cgColor)
            c.fillEllipse(in: CGRect(x: q.x - r, y: q.y - r, width: r * 2, height: r * 2))
        }
        if sel >= 0 && sel < pts.count {
            let p = pts[sel]
            let txt = String(format: "life %.0f%%   value %.2f", p.0 * 100, p.1 * range)
            (txt as NSString).draw(at: CGPoint(x: pl.minX + 6, y: pl.minY + 2), withAttributes: [.font: UIFont.systemFont(ofSize: 11, weight: .medium), .foregroundColor: UIColor.white])
        }
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        let q = t.location(in: self)
        var best = -1, bd: CGFloat = 28
        for (i, p) in pts.enumerated() { let c = toPt(p); let d = hypot(c.x - q.x, c.y - q.y); if d < bd { bd = d; best = i } }
        if best >= 0 {
            sel = best
            if t.tapCount >= 2 { removeSelected(); return }
        } else if pts.count < PtCurve.cap {
            let n = fromPt(q)
            pts.append(n); pts.sort { $0.0 < $1.0 }
            sel = pts.firstIndex { $0.0 == n.0 && $0.1 == n.1 } ?? -1
            commit()
        }
        setNeedsDisplay()
    }
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard sel >= 0, sel < pts.count, let t = touches.first else { return }
        var n = fromPt(t.location(in: self))
        if sel == 0 { n.0 = 0 } else if sel == pts.count - 1 { n.0 = 1 }
        else { n.0 = min(max(n.0, pts[sel - 1].0 + 0.01), pts[sel + 1].0 - 0.01) }
        pts[sel] = n; commit(); setNeedsDisplay()
    }
}
// MARK: - Gradient editor (tap the bar to add a stop, drag to move, double-tap to remove)

private final class PtGradView: UIControl {
    weak var lay: Layer?
    var onEdit: (() -> Void)?
    var onEnd: (() -> Void)?
    var onPick: ((UInt32, @escaping (UInt32) -> Void) -> Void)?
    private(set) var stops: [PtStop] = []
    private var sel = 0
    var pre = ""

    func load() {
        guard let l = lay else { return }
        stops = PtGradient.read({ l.p(self.pre + $0, Editor.time) })
        if stops.count < 2 { stops = [PtStop.from(ptArgb(l, pre + "ptColA", ParticularSim.defA), 0), PtStop.from(ptArgb(l, pre + "ptColB", ParticularSim.defB), 1)] }
        sel = 0; setNeedsDisplay()
    }
    private var bar: CGRect { CGRect(x: 18, y: 10, width: bounds.width - 36, height: 40) }
    private func xFor(_ p: Float) -> CGFloat { bar.minX + CGFloat(p) * bar.width }
    private func commit() { if let l = lay { PtGradient.write(l, stops, pre: pre) }; onEdit?(); setNeedsDisplay() }
    func removeSelected() { if stops.count > 2 && sel >= 0 && sel < stops.count { stops.remove(at: sel); sel = 0; commit(); onEnd?() } }
    func editColor() {
        guard sel >= 0 && sel < stops.count else { return }
        let i = sel
        onPick?(stops[i].argb) { [weak self] c in
            guard let self = self, i < self.stops.count else { return }
            let p = self.stops[i].p; self.stops[i] = PtStop.from(c, p); self.commit(); self.onEnd?()
        }
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let b = bar
        c.setFillColor(UIColor(white: 0.16, alpha: 1).cgColor); c.fill(b)
        var chk = false
        for y in stride(from: b.minY, to: b.maxY, by: 10) { for x in stride(from: b.minX, to: b.maxX, by: 10) { if chk { c.setFillColor(UIColor(white: 0.26, alpha: 1).cgColor); c.fill(CGRect(x: x, y: y, width: 10, height: 10)) }; chk.toggle() }; chk.toggle() }
        let cols = stops.map { UIColor(red: CGFloat($0.r), green: CGFloat($0.g), blue: CGFloat($0.b), alpha: CGFloat($0.a)).cgColor } as CFArray
        if let g = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: cols, locations: stops.map { CGFloat($0.p) }) {
            c.saveGState(); c.clip(to: b)
            c.drawLinearGradient(g, start: CGPoint(x: b.minX, y: 0), end: CGPoint(x: b.maxX, y: 0), options: [.drawsBeforeStartLocation, .drawsAfterEndLocation]); c.restoreGState()
        }
        c.setStrokeColor(UIColor(white: 1, alpha: 0.25).cgColor); c.setLineWidth(1); c.stroke(b)
        for (i, s) in stops.enumerated() {
            let x = xFor(s.p), y = b.maxY + 22, r: CGFloat = i == sel ? 13 : 10
            c.setStrokeColor(UIColor.white.cgColor); c.setLineWidth(i == sel ? 3 : 1.5)
            c.move(to: CGPoint(x: x, y: b.maxY)); c.addLine(to: CGPoint(x: x, y: y - r)); c.strokePath()
            c.setFillColor(UIColor(red: CGFloat(s.r), green: CGFloat(s.g), blue: CGFloat(s.b), alpha: 1).cgColor)
            c.fillEllipse(in: CGRect(x: x - r, y: y - r, width: r * 2, height: r * 2))
            c.strokeEllipse(in: CGRect(x: x - r, y: y - r, width: r * 2, height: r * 2))
        }
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        let q = t.location(in: self)
        var best = -1, bd: CGFloat = 26
        for (i, s) in stops.enumerated() { let d = hypot(xFor(s.p) - q.x, bar.maxY + 22 - q.y); if d < bd { bd = d; best = i } }
        if best >= 0 {
            sel = best
            if t.tapCount >= 2 { removeSelected(); return }
        } else if stops.count < PtGradient.cap && q.y < bar.maxY + 6 {
            let p = Float(min(1, max(0, (q.x - bar.minX) / bar.width)))
            let v = PtGradient.eval(stops, p)
            stops.append(PtStop(p: p, r: v.x, g: v.y, b: v.z, a: v.w)); stops.sort { $0.p < $1.p }
            sel = stops.firstIndex { $0.p == p } ?? 0; commit()
        }
        setNeedsDisplay()
    }
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard sel >= 0, sel < stops.count, let t = touches.first else { return }
        var p = Float(min(1, max(0, (t.location(in: self).x - bar.minX) / bar.width)))
        if sel > 0 { p = max(p, stops[sel - 1].p + 0.005) }
        if sel < stops.count - 1 { p = min(p, stops[sel + 1].p - 0.005) }
        stops[sel].p = p; commit()
    }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) { onEnd?() }
}

// MARK: - Viewport (draws with the renderer's own camera and sprite maths)

final class ParticularViewport: UIView {
    var lay: Layer?
    var time: Float = 0, t0: Float = 0
    var playing = true
    var loop: Float = 6
    var compRatio: CGFloat = 9.0 / 16
    var compMode = true { didSet { modeBtn.text = compMode ? "Comp View" : "Orbit"; setNeedsDisplay() } }
    var onTick: ((Float) -> Void)?
    private var yaw: CGFloat = 0, pitch: CGFloat = 0.15, dist: CGFloat = 3
    /// Path drawing: one finger draws on the plane through the origin facing the camera; two fingers orbit.
    var drawMode = false { didSet { drawBtn.isHidden = !drawMode; setNeedsDisplay() } }
    var pathAppend = false
    var onPathDrawn: (([SIMD3<Float>], Bool) -> Void)?
    private var stroke: [CGPoint] = [], drawing = false
    private let drawBtn = PillButton("Stop Drawing", nil, C.CARD2, C.TEXT)
    func beginDrawing(append: Bool) {
        if compMode { yaw = 0; pitch = 0.15; dist = 3; compMode = false }
        pathAppend = append; drawMode = true
    }
    private func unproject(_ p: CGPoint) -> SIMD3<Float> {
        let f = 1 / CGFloat(tan(Editor.scene.fov * Float.pi / 360)), k = bounds.height * 0.5 * f / dist
        let x1 = (p.x - bounds.width / 2) / k, y2 = -(p.y - bounds.height / 2) / k
        let cy = cos(yaw), sy = sin(yaw), cp = cos(pitch), sp = sin(pitch)
        let Y = y2 * cp, z1 = -y2 * sp
        return SIMD3(Float(x1 * cy - z1 * sy), Float(Y), Float(x1 * sy + z1 * cy))
    }
    private var link: CADisplayLink?
    private var lastTs: CFTimeInterval = 0
    private let modeBtn = PillButton("Comp View", nil, C.CARD2, C.TEXT)

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .black; clipsToBounds = true; isMultipleTouchEnabled = true
        addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(pan(_:))))
        addGestureRecognizer(UIPinchGestureRecognizer(target: self, action: #selector(pinch(_:))))
        modeBtn.onClick = { [weak self] in
            guard let s = self else { return }
            if !s.compMode { s.yaw = 0; s.pitch = 0.15; s.dist = 3 }
            s.compMode.toggle()
        }
        addSubview(modeBtn)
        drawBtn.isHidden = true; drawBtn.onClick = { [weak self] in self?.drawMode = false }; addSubview(drawBtn)
    }
    required init?(coder: NSCoder) { fatalError() }
    override func layoutSubviews() { super.layoutSubviews(); modeBtn.frame = CGRect(x: bounds.width - 104, y: 8, width: 96, height: 30); drawBtn.frame = CGRect(x: 8, y: 8, width: 120, height: 30) }
    func start() { link?.invalidate(); lastTs = 0; link = CADisplayLink(target: self, selector: #selector(tick(_:))); link?.preferredFramesPerSecond = 24; link?.add(to: .main, forMode: .common) }
    func stop() { link?.invalidate(); link = nil }
    @objc private func tick(_ l: CADisplayLink) {
        if lastTs == 0 { lastTs = l.timestamp }
        let dt = Float(l.timestamp - lastTs); lastTs = l.timestamp
        if playing { time += dt; if time > t0 + loop { time = t0 }; onTick?(time); setNeedsDisplay() }
    }
    @objc private func pan(_ g: UIPanGestureRecognizer) {
        if g.state == .began { drawing = drawMode && !compMode && g.numberOfTouches == 1; if drawing { stroke = [] } }
        if drawing {
            switch g.state {
            case .began, .changed: stroke.append(g.location(in: self)); setNeedsDisplay()
            default:
                drawing = false
                if stroke.count >= 3 {
                    let pts = PtPath.resample(stroke.map { unproject($0) }, PtPath.cap)
                    onPathDrawn?(pts, pathAppend)
                }
                stroke = []; setNeedsDisplay()
            }
            return
        }
        if compMode { compMode = false }
        let t = g.translation(in: self); g.setTranslation(.zero, in: self)
        yaw += t.x * 0.01; pitch = min(1.4, max(-1.4, pitch + t.y * 0.01)); setNeedsDisplay()
    }
    @objc private func pinch(_ g: UIPinchGestureRecognizer) { if compMode { compMode = false }; dist = min(12, max(1.2, dist / g.scale)); g.scale = 1; setNeedsDisplay() }

    private func frameRect() -> CGRect {
        let m: CGFloat = 4
        var w = bounds.width - m * 2, h = w / compRatio
        if h > bounds.height - m * 2 { h = bounds.height - m * 2; w = h * compRatio }
        return CGRect(x: (bounds.width - w) / 2, y: (bounds.height - h) / 2, width: w, height: h)
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext(), let l = lay else { return }
        let et = time   // animated params + camera follow the preview playhead, exactly like the comp does
        let g: (String) -> Float = { l.p($0, et) }
        func colFor(_ q: String) -> (String, UInt32) -> [CGFloat] {
            return { k, d in
                func comp(_ s: String, _ sh: UInt32) -> CGFloat { CGFloat(l.props[q + k + s].map { $0.eval(et) } ?? Float((d >> sh) & 0xFF) / 255) }
                return [comp("_r", 16), comp("_g", 8), comp("_b", 0), comp("_a", 24)]
            }
        }
        let fr = compMode ? frameRect() : bounds
        c.saveGState(); c.clip(to: fr); c.translateBy(x: fr.minX, y: fr.minY)
        c.setFillColor(UIColor.black.cgColor); c.fill(CGRect(origin: .zero, size: fr.size))
        var cam: PtProject
        var lo: Float = 1
        if compMode {
            let w = Int(compRatio * 1000), h = 1000
            let hasCam = MetalCam.vp(for: l, time: et, width: w, height: h) != nil
            let vp = MetalCam.vpForModel(l, fov: Editor.scene.fov, time: et, width: w, height: h)
            let m = Xf.matrix(l, et)
            if vp.count == 16 && m.count >= 6 {
                cam = PtDraw.comp(vp: vp, m: m, layerZ: Xf.worldZ(l, et), rotXDeg: l.p("rotX", et), rotYDeg: l.p("rotY", et),
                                  use3D: hasCam || l.is3d, aspect: Float(compRatio), size: fr.size)
            } else { cam = PtDraw.orbit(yaw: 0, pitch: 0, dist: 3, fovDeg: Editor.scene.fov, size: fr.size) }
            lo = min(max(l.p("opacity", et), 0), 1)
        } else {
            cam = PtDraw.orbit(yaw: yaw, pitch: pitch, dist: dist, fovDeg: Editor.scene.fov, size: fr.size)
            drawGizmos(c, g, cam)
        }
        let n = PtGroup.count(g)
        for gi in 0..<n {
            PtDraw.render(c, size: fr.size, g: PtGroup.reader(g, gi), col: colFor(PtGroup.pre(gi)), time: time, cam: cam, layerOpacity: lo, cap: 1400 / n, compH: 1080, adaptive: true)
        }
        c.restoreGState()
        if stroke.count > 1 {
            c.setStrokeColor(ptAcc.cgColor); c.setLineWidth(2.5); c.setLineCap(.round); c.setLineJoin(.round)
            c.move(to: stroke[0]); for p in stroke.dropFirst() { c.addLine(to: p) }; c.strokePath()
        }
        if compMode { c.setStrokeColor(UIColor(white: 1, alpha: 0.18).cgColor); c.setLineWidth(1); c.stroke(fr) }
    }

    private func drawGizmos(_ c: CGContext, _ g: (String) -> Float, _ cam: PtProject) {
        typealias V = (Float, Float, Float)
        func line(_ pts: [V], _ col: UIColor) {
            c.setStrokeColor(col.cgColor); c.setLineWidth(1)
            var first = true
            for p in pts { if let q = cam(p.0, p.1, p.2) { let pt = CGPoint(x: q.x, y: q.y); if first { c.move(to: pt); first = false } else { c.addLine(to: pt) } } else { first = true } }
            c.strokePath()
        }
        let gc = UIColor(white: 1, alpha: 0.07)
        for i in -4...4 { let v = Float(i) * 0.5; line([(v, -1.2, -2), (v, -1.2, 2)], gc); line([(-2, -1.2, v), (2, -1.2, v)], gc) }
        line([(0, 0, 0), (0.5, 0, 0)], UIColor(red: 0.9, green: 0.3, blue: 0.3, alpha: 0.9))
        line([(0, 0, 0), (0, 0.5, 0)], UIColor(red: 0.4, green: 0.8, blue: 0.4, alpha: 0.9))
        line([(0, 0, 0), (0, 0, 0.5)], UIColor(red: 0.4, green: 0.5, blue: 1, alpha: 0.9))
        let ex = g("ptPosX"), ey = g("ptPosY"), ez = g("ptPosZ"), sx = g("ptSizeX"), sy = g("ptSizeY"), sz = g("ptSizeZ")
        let em = Int(g("ptEmType").rounded()), wc = ptAcc.withAlphaComponent(0.7)
        func circ(_ y: Float, _ rx: Float, _ rz: Float) -> [V] { (0...32).map { let a = Float($0) / 32 * 6.2831853; return (ex + cos(a) * rx, ey + y, ez + sin(a) * rz) } }
        func ell(_ ax: Int) -> [V] { (0...32).map { let a = Float($0) / 32 * 6.2831853, ca = cos(a), sa = sin(a)
            return ax == 0 ? (ex + ca * sx, ey + sa * sy, ez) : (ax == 1 ? (ex + ca * sx, ey, ez + sa * sz) : (ex, ey + ca * sy, ez + sa * sz)) } }
        switch em {
        case 18:
            let lut = PtPath.lut(g)
            if lut.count > 1 {
                line(lut.map { ($0.x, $0.y, $0.z) }, ptAcc)
                for q in PtPath.read(g) { if let s = cam(q.x, q.y, q.z) { c.setFillColor(UIColor.white.cgColor); c.fillEllipse(in: CGRect(x: s.x - 3, y: s.y - 3, width: 6, height: 6)) } }
            }
        case 1, 3:
            for i in 0..<8 { for b in [1, 2, 4] where i & b == 0 {
                let j = i | b
                func cn(_ k: Int) -> V { (ex + ((k & 1) == 0 ? -sx : sx), ey + ((k & 2) == 0 ? -sy : sy), ez + ((k & 4) == 0 ? -sz : sz)) }
                line([cn(i), cn(j)], wc) } }
        case 2, 12: for ax in 0..<3 { line(ell(ax), wc) }
        case 4, 5: line(circ(0, sx, sz), wc)
        case 8: line(circ(-sy, sx, sz), wc); line(circ(sy, sx, sz), wc)
        case 7: line(circ(sy, sx, sz), wc); line([(ex, ey - sy, ez), (ex + sx, ey + sy, ez)], wc); line([(ex, ey - sy, ez), (ex - sx, ey + sy, ez)], wc)
        case 9: line(circ(0, sx + sy, sx + sy), wc); line(circ(0, max(0, sx - sy), max(0, sx - sy)), wc)
        case 10: line((0...60).map { let a = Float($0) / 60 * 6.2831853 * 3; return (ex + cos(a) * sx, ey + (Float($0) / 30 - 1) * sy, ez + sin(a) * sz) }, wc)
        case 6: line([(ex - sx, ey, ez), (ex + sx, ey, ez)], wc)
        case 11, 13, 14: line([(ex - sx, ey - sy, ez), (ex + sx, ey - sy, ez), (ex + sx, ey + sy, ez), (ex - sx, ey + sy, ez), (ex - sx, ey - sy, ez)], wc)
        default: line([(ex - 0.08, ey, ez), (ex + 0.08, ey, ez)], wc); line([(ex, ey - 0.08, ez), (ex, ey + 0.08, ez)], wc); line([(ex, ey, ez - 0.08), (ex, ey, ez + 0.08)], wc)
        }
    }
}

// MARK: - Designer screen

final class ParticularDesignerViewController: UIViewController, PHPickerViewControllerDelegate, UIDocumentPickerDelegate {
    private let lay: Layer
    private weak var ed: EditorViewController?
    private let onDone: () -> Void
    private var snapKeys: [String] = [], snapVals: [String: Float] = [:]
    private let vp = ParticularViewport()
    private let bar = UIView(), transport = UIView(), strip = UIScrollView(), props = UIScrollView(), stack = UIStackView()
    private let timeLbl = UILabel(), titleLbl = UILabel()
    private var tabs: TabBar!
    private var tabIdx = 0, blockId = "presets"
    private let play = PtGlyph()
    private var pendingPick = "", lastW: CGFloat = 0
    private var curGroup = 0
    private var pre: String { PtGroup.pre(curGroup) }

    init(_ l: Layer, _ editor: EditorViewController?, _ done: @escaping () -> Void) {
        lay = l; ed = editor; onDone = done
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) { fatalError() }

    private func raw(_ k: String) -> Float { lay.p(k, Editor.time) }
    private func val(_ k: String) -> Float { lay.p(pre + k, Editor.time) }
    private func set(_ k: String, _ v: Float) { lay.track(pre + k).base = v }
    private func argb(_ k: String, _ d: UInt32) -> UInt32 { ptArgb(lay, pre + k, d) }
    private func setColor(_ k: String, _ c: UInt32) {
        set(k + "_a", Float((c >> 24) & 0xFF) / 255); set(k + "_r", Float((c >> 16) & 0xFF) / 255)
        set(k + "_g", Float((c >> 8) & 0xFF) / 255); set(k + "_b", Float(c & 0xFF) / 255)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = argbToUIColor(C.BG)
        snapKeys = Array(Set(PtParams.allKeys))
        for k in snapKeys { if let t = lay.props[k] { snapVals[k] = t.base } }
        bar.backgroundColor = argbToUIColor(C.PANEL); view.addSubview(bar)
        titleLbl.text = "Particle Designer"; titleLbl.textColor = .white; titleLbl.font = boldFont(15); titleLbl.textAlignment = .center; bar.addSubview(titleLbl)
        func btn(_ t: String, _ fill: Int32, _ txt: Int32, _ act: @escaping () -> Void) -> PillButton {
            let b = PillButton(t, nil, fill, txt); b.onClick = act; bar.addSubview(b); return b
        }
        _ = btn("Cancel", C.CARD2, C.TEXT) { [weak self] in self?.cancel() }.tag = 1
        _ = btn("Apply", C.GREEN, C.ONDARK) { [weak self] in self?.apply() }.tag = 2
        vp.lay = lay; vp.t0 = Editor.time; vp.time = Editor.time
        vp.compRatio = (ed?.aspect?.ratio).map { CGFloat($0) } ?? 9.0 / 16
        vp.onTick = { [weak self] t in self?.updateTime(t) }; view.addSubview(vp)
        vp.onPathDrawn = { [weak self] pts, append in self?.applyPath(pts, append) }
        transport.backgroundColor = argbToUIColor(C.PANEL); view.addSubview(transport)
        for (i, k) in ["back", "play", "next"].enumerated() {
            let g = k == "play" ? play : PtGlyph(); g.kind = k; g.tag = 10 + i; transport.addSubview(g)
            g.onClick = { [weak self] in self?.transportTap(k) }
        }
        play.kind = "pause"
        timeLbl.textColor = ptAcc; timeLbl.font = UIFont.monospacedDigitSystemFont(ofSize: 13, weight: .semibold); transport.addSubview(timeLbl)
        tabs = TabBar(ptTabs.map { $0.0 }, 0) { [weak self] i in self?.pickTab(i) }; view.addSubview(tabs)
        strip.showsHorizontalScrollIndicator = false; strip.backgroundColor = argbToUIColor(C.PANEL); view.addSubview(strip)
        props.backgroundColor = argbToUIColor(C.BG); view.addSubview(props)
        stack.axis = .vertical; stack.spacing = 6; props.addSubview(stack)
        rebuildStrip(); rebuildProps(); updateTime(vp.time)
    }
    override func viewDidAppear(_ animated: Bool) { super.viewDidAppear(animated); vp.start() }
    override func viewWillDisappear(_ animated: Bool) { super.viewWillDisappear(animated); vp.stop() }
    override var prefersStatusBarHidden: Bool { true }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let sa = view.safeAreaInsets, W = view.bounds.width, H = view.bounds.height
        let top = sa.top, bw = W - sa.left - sa.right, x0 = sa.left
        bar.frame = CGRect(x: 0, y: 0, width: W, height: top + 46)
        titleLbl.frame = CGRect(x: x0 + 120, y: top, width: bw - 240, height: 46)
        for v in bar.subviews { if v.tag == 1 { v.frame = CGRect(x: x0 + 10, y: top + 5, width: 100, height: 36) }; if v.tag == 2 { v.frame = CGRect(x: x0 + bw - 110, y: top + 5, width: 100, height: 36) } }
        let landscape = W > H
        let bottom = H - sa.bottom
        let leftW = landscape ? bw * 0.5 : bw
        let vpH = landscape ? bottom - bar.frame.maxY - 40 : (bottom - bar.frame.maxY) * 0.4
        vp.frame = CGRect(x: x0, y: bar.frame.maxY, width: leftW, height: vpH)
        transport.frame = CGRect(x: x0, y: vp.frame.maxY, width: leftW, height: 40)
        for v in transport.subviews { if v.tag >= 10 { v.frame = CGRect(x: 6 + CGFloat(v.tag - 10) * 44, y: 0, width: 44, height: 40) } }
        timeLbl.frame = CGRect(x: 150, y: 0, width: leftW - 160, height: 40)
        let rx = landscape ? x0 + leftW : x0, rw = landscape ? bw - leftW : bw
        let ry = landscape ? bar.frame.maxY : transport.frame.maxY
        tabs.frame = CGRect(x: rx, y: ry, width: rw, height: 40)
        strip.frame = CGRect(x: rx, y: ry + 40, width: rw, height: 112)
        props.frame = CGRect(x: rx, y: strip.frame.maxY, width: rw, height: bottom - strip.frame.maxY)
        if tabIdx == 0 && abs(props.bounds.width - lastW) > 1 { lastW = props.bounds.width; rebuildProps() }
        relayoutStack()
    }

    private func relayoutStack() {
        let w = props.bounds.width - 20
        let h = stack.systemLayoutSizeFitting(CGSize(width: w, height: 0), withHorizontalFittingPriority: .required, verticalFittingPriority: .fittingSizeLevel).height
        stack.frame = CGRect(x: 10, y: 8, width: w, height: h)
        props.contentSize = CGSize(width: props.bounds.width, height: h + 24)
    }

    private func updateTime(_ t: Float) {
        let f = Int(t * 30), s = f / 30
        timeLbl.text = String(format: "00:%02d:%02d:%02d   Loop %.1fs", s / 60, s % 60, f % 30, vp.loop)
    }
    private func transportTap(_ k: String) {
        switch k {
        case "play": vp.playing.toggle()
        case "back": vp.time = max(vp.t0, vp.time - 1.0 / 30); vp.playing = false; updateTime(vp.time)
        default: vp.time += 1.0 / 30; vp.playing = false; updateTime(vp.time)
        }
        play.kind = vp.playing ? "pause" : "play"; play.setNeedsDisplay()
    }

    private func pickTab(_ i: Int) { tabIdx = i; blockId = ptTabs[i].1[0]; rebuildStrip(); rebuildProps() }

    private func valueText(_ b: PtBlock) -> String {
        func on(_ v: Bool) -> String { v ? "On" : "Off" }
        switch b.id {
        case "emitter": return ParticularSim.emitterNames[min(ParticularSim.emitterNames.count - 1, max(0, Int(val("ptEmType").rounded())))]
        case "motion": return ParticularSim.motionNames[min(ParticularSim.motionNames.count - 1, max(0, Int(val("ptMotion").rounded())))]
        case "source": return val("ptEmType") >= 12.5 ? (val("ptEmImgId") > 0 ? "Media" : "Empty") : "None"
        case "color":
            let a = argb("ptColA", ParticularSim.defA), c = argb("ptColB", ParticularSim.defB)
            return ptColorPresets.first { $0.1 == a && $0.2 == c }?.0 ?? "Custom"
        case "gradient": return on(val("ptGrOn") >= 0.5)
        case "type":
            let sp = Int(val("ptSprite").rounded())
            if sp == 6 { return "Custom" }
            for p in b.presets where p.2.allSatisfy({ abs(val($0.key) - $0.value) < 0.011 }) { return p.0 }
            return "Custom"
        case "env": return on(abs(val("ptSwirl")) + val("ptAttract") + val("ptFloorOn") + abs(val("ptGravity")) + abs(val("ptWindX")) + abs(val("ptWindY")) + abs(val("ptWindZ")) + val("ptAir") > 0.001)
        case "field": return on(val("ptTurb") > 0.001)
        case "curl": return on(val("ptCurl") > 0.001)
        case "wave": return on(val("ptWaveAmp") > 0.001 || abs(val("ptWaveFlow")) > 0.001)
        case "flutter": return on(val("ptFlutter") > 0.001 || abs(val("ptSpin")) > 0.001)
        case "trail": return on(val("ptTrail") > 0.5)
        case "scatter": return on(val("ptScatter") > 0.001 || Int(val("ptBehavior").rounded()) == 2)
        case "quant": return on(val("ptQuant") > 0.001)
        case "twinkle": return on(val("ptTwinkle") > 0.001)
        default:
            for p in b.presets where p.2.allSatisfy({ abs(val($0.key) - $0.value) < 0.011 }) { return p.0 }
            return "Custom"
        }
    }

    private func attach(_ t: PtTile, _ id: String, _ over: [String: Float]) {
        guard let s = ptThumbSpec(id, over) else { return }
        PtThumb.make(s.key, s.p, time: s.t, yaw: s.yaw, pitch: s.pitch, dist: s.dist) { [weak t] img in t?.thumb = img; t?.setNeedsDisplay() }
    }
    private func currentStops() -> [PtStop] {
        let s = PtGradient.read { [lay = self.lay, pre = self.pre] in lay.p(pre + $0, Editor.time) }
        if val("ptGrOn") >= 0.5 && s.count >= 2 { return s }
        return [PtStop.from(argb("ptColA", ParticularSim.defA), 0), PtStop.from(argb("ptColB", ParticularSim.defB), 1)]
    }

    private func rebuildStrip() {
        strip.subviews.forEach { $0.removeFromSuperview() }
        var x: CGFloat = 8
        if blockId == "presets" {
            for (title, kind, value, act) in [("IMPORT", "act_import", ".saikiparticle", "import"), ("SAVE", "act_save", "to My presets", "save"), ("EXPORT", "act_export", "share file", "export")] {
                let t = PtTile(frame: CGRect(x: x, y: 6, width: 92, height: 100)); t.kind = kind; t.title = title; t.value = value
                t.onClick = { [weak self] in self?.presetAction(act) }
                strip.addSubview(t); x += 98
            }
            strip.contentSize = CGSize(width: x + 8, height: 112); return
        }
        for id in ptTabs[tabIdx].1 {
            guard let b = ptBlocks.first(where: { $0.id == id }) else { continue }
            let t = PtTile(frame: CGRect(x: x, y: 6, width: 92, height: 100))
            t.kind = b.id == "type" ? "type" : b.id
            t.variant = b.id == "emitter" ? Int(val("ptEmType").rounded()) : (b.id == "motion" ? Int(val("ptMotion").rounded()) : 1)
            t.title = b.title; t.value = valueText(b); t.picked = b.id == blockId
            if b.id == "color" { t.ca = argbToUIColor(Int32(bitPattern: argb("ptColA", ParticularSim.defA))); t.cb = argbToUIColor(Int32(bitPattern: argb("ptColB", ParticularSim.defB))) }
            if b.id == "gradient" { t.stops = currentStops() }
            if ptThumbBlocks.contains(b.id) {
                var over: [String: Float] = [:]
                for it in b.items {
                    switch it {
                    case .slider(let k, _, _, _, _), .choice(let k, _, _): over[k] = val(k)
                    default: break
                    }
                }
                if b.id == "source" { over["ptEmImgId"] = val("ptEmImgId") }
                attach(t, b.id, over)
            }
            t.onClick = { [weak self] in self?.blockId = id; self?.rebuildStrip(); self?.rebuildProps() }
            strip.addSubview(t); x += 98
        }
        strip.contentSize = CGSize(width: x + 8, height: 112)
    }

    private func label(_ s: String) -> UILabel {
        let l = UILabel(); l.text = s; l.textColor = argbToUIColor(C.DIM); l.font = boldFont(12); l.numberOfLines = 0; return l
    }

    // MARK: presets tab

    private func buildPresets() {
        stack.addArrangedSubview(label("BUILT-IN PRESETS  ·  tap a folder to open"))
        var cats: [String] = []
        for p in PtBuiltins.all where !cats.contains(p.cat) { cats.append(p.cat) }
        for cat in cats {
            let items = PtBuiltins.all.filter { $0.cat == cat }
            let open = ptOpenFolders.contains(cat)
            let b = UIButton(type: .system)
            b.setTitle("\(open ? "▾" : "▸")  \(cat)  ·  \(items.count)", for: .normal)
            b.setTitleColor(.white, for: .normal); b.titleLabel?.font = .systemFont(ofSize: 13, weight: .bold)
            b.contentHorizontalAlignment = .left; b.contentEdgeInsets = UIEdgeInsets(top: 0, left: 12, bottom: 0, right: 0)
            b.backgroundColor = UIColor(white: 1, alpha: 0.07); b.layer.cornerRadius = 8
            b.heightAnchor.constraint(equalToConstant: 36).isActive = true
            b.addAction(UIAction { [weak self] _ in
                if ptOpenFolders.contains(cat) { ptOpenFolders.remove(cat) } else { ptOpenFolders.insert(cat) }
                self?.rebuildProps()
            }, for: .touchUpInside)
            stack.addArrangedSubview(b)
            if open { stack.addArrangedSubview(presetGrid(items)) }
        }
        stack.addArrangedSubview(label("MY PRESETS  ·  long-press to delete"))
        let mine = PtPresetStore.list()
        if mine.isEmpty { stack.addArrangedSubview(label("Nothing saved yet. Tap SAVE to keep the current look, or IMPORT a .saikiparticle file.")) }
        else { stack.addArrangedSubview(presetGrid(mine)) }
    }
    private func presetGrid(_ items: [PtPreset]) -> UIView {
        let w = max(300, props.bounds.width - 20), cols = max(2, Int((w + 8) / 116))
        let tw = (w - 8 * CGFloat(cols - 1)) / CGFloat(cols), th = tw * 0.78 + 34
        let v = PtPresetGrid(); v.cols = cols; v.tileH = th
        v.heightAnchor.constraint(equalToConstant: CGFloat((items.count + cols - 1) / cols) * (th + 8)).isActive = true
        for p in items {
            let t = PtPresetTile(frame: .zero); t.title = p.name; t.sub = p.custom ? "Saved" : p.cat
            t.onClick = { [weak self] in self?.applyPreset(p) }
            if p.custom { t.onLong = { [weak self] in self?.confirmDelete(p) } }
            PtThumb.make("p:" + p.id, p.params, time: p.thumbT) { [weak t] img in t?.thumb = img; t?.setNeedsDisplay() }
            v.addSubview(t)
        }
        return v
    }
    private func applyPreset(_ p: PtPreset) {
        let skip: Set<String> = ["ptOcclude", "ptShowSrc"]
        for k in Set(PtParams.allKeys) where !skip.contains(k) { lay.track(k).base = PtParams.def(k) }
        for (k, v) in p.params { lay.track(k).base = v }
        curGroup = 0; vp.time = vp.t0
        afterEdit(true); Snack.show("Applied \(p.name)")
    }
    private func confirmDelete(_ p: PtPreset) {
        let a = UIAlertController(title: "Delete \"\(p.name)\"?", message: nil, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "Delete", style: .destructive) { [weak self] _ in PtPresetStore.delete(p); self?.rebuildProps() })
        a.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(a, animated: true)
    }
    private func currentParams() -> [String: Float] {
        var d: [String: Float] = [:]
        for k in Set(PtParams.allKeys) { d[k] = raw(k) }
        for gi in 0..<PtGroup.count(raw) {
            let q = PtGroup.pre(gi)
            d.merge(PtParams.color(q + "ptColA", ptArgb(lay, q + "ptColA", ParticularSim.defA))) { $1 }
            d.merge(PtParams.color(q + "ptColB", ptArgb(lay, q + "ptColB", ParticularSim.defB))) { $1 }
        }
        return d
    }
    private func presetAction(_ act: String) {
        switch act {
        case "import":
            var types: [UTType] = [.data]
            if let u = UTType(filenameExtension: PtPresetStore.ext) { types.insert(u, at: 0) }
            let p = UIDocumentPickerViewController(forOpeningContentTypes: types, asCopy: true)
            p.delegate = self; present(p, animated: true)
        case "save":
            let a = UIAlertController(title: "Save Preset", message: "Saved to My presets with a thumbnail.", preferredStyle: .alert)
            a.addTextField { $0.placeholder = "Preset name" }
            a.addAction(UIAlertAction(title: "Save", style: .default) { [weak self, weak a] _ in
                guard let self = self else { return }
                if PtPresetStore.save(name: a?.textFields?.first?.text ?? "", params: self.currentParams()) != nil { Snack.show("Saved"); self.rebuildProps() }
            })
            a.addAction(UIAlertAction(title: "Cancel", style: .cancel))
            present(a, animated: true)
        default:
            guard let u = PtPresetStore.exportURL(name: "Particle", params: currentParams()) else { return }
            let a = UIActivityViewController(activityItems: [u], applicationActivities: nil)
            a.popoverPresentationController?.sourceView = view
            a.popoverPresentationController?.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 1, height: 1)
            present(a, animated: true)
        }
    }
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        for u in urls {
            if let p = PtPresetStore.importFile(u) { applyPreset(p) } else { Snack.show("Not a valid .saikiparticle file") }
        }
    }

    // MARK: particle groups (extra emitters on the same layer, each with its own full parameter set)

    private func groupRow() -> [UIView] {
        let n = PtGroup.count(raw)
        var names = (0..<n).map { $0 == 0 ? "Main" : "Group \($0 + 1)" }
        if n < 1 + PtGroup.maxExtra { names.append("+ Add Group") }
        let row = chipRow(names, min(curGroup, n - 1)) { [weak self] i in self?.groupTap(i, n) }
        row.heightAnchor.constraint(equalToConstant: 46).isActive = true
        var out: [UIView] = [label("PARTICLE GROUP  ·  each group is its own emitter, shape, colour and physics"), row]
        if n > 1 {
            let rm = PillButton("Remove this group", nil, C.CARD2, C.TEXT)
            rm.onClick = { [weak self] in self?.removeGroup(n) }
            rm.heightAnchor.constraint(equalToConstant: 38).isActive = true
            out.append(rm)
        }
        return out
    }
    private func groupTap(_ i: Int, _ n: Int) {
        if i >= n {
            for k in PtParams.baseKeys { lay.track(PtGroup.pre(n) + k).base = raw(pre + k) }   // new group starts as a copy of the current one
            lay.track("ptGroups").base = Float(n)
            curGroup = n
        } else { curGroup = i }
        afterEdit(true)
    }
    private func removeGroup(_ n: Int) {
        for j in curGroup..<(n - 1) { for k in PtParams.baseKeys { lay.track(PtGroup.pre(j) + k).base = raw(PtGroup.pre(j + 1) + k) } }
        lay.track("ptGroups").base = Float(n - 2)
        curGroup = min(curGroup, n - 2)
        afterEdit(true)
    }

    // MARK: media import (sprite shapes and image / video emitters)

    private func applyPath(_ pts: [SIMD3<Float>], _ append: Bool) {
        var all = pts
        if append { all = PtPath.resample(PtPath.read({ self.val($0) }) + pts, PtPath.cap) }
        PtPath.write(lay, all, pre: pre)
        set("ptEmType", 18)
        afterEdit(true)
    }

    private func runAction(_ id: String) {
        switch id {
        case "pathDraw", "pathAdd":
            vp.beginDrawing(append: id == "pathAdd")
            Snack.show("Drag one finger to draw the path · two fingers rotate the view")
        case "pathClr": set("ptPathN", 0); vp.drawMode = false; afterEdit(true)
        case "bpClr": set("ptBumpId", 0); afterEdit(true)
        case "emClr": set("ptEmImgId", 0); if val("ptEmType") >= 12.5 { set("ptEmType", 11) }; afterEdit(true)
        default:
            pendingPick = id
            var c = PHPickerConfiguration(); c.filter = id.hasSuffix("Vid") ? .videos : .images; c.selectionLimit = 1
            let pk = PHPickerViewController(configuration: c); pk.delegate = self; present(pk, animated: true)
        }
    }
    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        picker.dismiss(animated: true)
        guard let r = results.first else { return }
        let act = pendingPick
        if act.hasSuffix("Img") {
            r.itemProvider.loadObject(ofClass: UIImage.self) { [weak self] obj, _ in
                guard let im = obj as? UIImage else { return }
                DispatchQueue.main.async { self?.mediaReady(act, PtImages.add(image: act == "spKeyImg" ? PtImages.keyBlack(im) : im)) }
            }
        } else {
            r.itemProvider.loadFileRepresentation(forTypeIdentifier: UTType.movie.identifier) { [weak self] url, _ in
                guard let url = url else { return }
                let tmp = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + "." + url.pathExtension)
                try? FileManager.default.copyItem(at: url, to: tmp)
                DispatchQueue.main.async {
                    PtImages.add(video: tmp) { id in self?.mediaReady(act, id); try? FileManager.default.removeItem(at: tmp) }
                }
            }
        }
    }
    private func mediaReady(_ act: String, _ id: Int?) {
        guard let id = id else { Snack.show("Couldn't import that file"); return }
        if act == "bpImg" { set("ptBumpId", Float(id)); set("ptBump", max(val("ptBump"), 1)) }
        else if act.hasPrefix("sp") { set("ptSprite", 6); set("ptSpriteId", Float(id)); set("ptSpriteAnim", act == "spVid" ? 1 : 0); set("ptSpriteTint", 0) }
        else { set("ptEmImgId", Float(id)); set("ptEmType", act == "emVid" ? 14 : 13) }
        afterEdit(true)
    }

    // MARK: property panel

    private func rebuildProps() {
        stack.arrangedSubviews.forEach { stack.removeArrangedSubview($0); $0.removeFromSuperview() }
        if blockId == "presets" { buildPresets(); relayoutStack(); return }
        guard let b = ptBlocks.first(where: { $0.id == blockId }) else { return }
        groupRow().forEach { stack.addArrangedSubview($0) }
        stack.addArrangedSubview(label(b.title))
        let presetCount = b.id == "color" ? ptColorPresets.count : (b.id == "gradient" ? PtGradient.presets.count : b.presets.count)
        if presetCount > 0 {
            stack.addArrangedSubview(label("Presets"))
            let sc = UIScrollView(); sc.showsHorizontalScrollIndicator = false
            sc.heightAnchor.constraint(equalToConstant: 84).isActive = true
            var x: CGFloat = 0
            for i in 0..<presetCount {
                let t = PtTile(frame: CGRect(x: x, y: 0, width: 74, height: 82))
                if b.id == "color" {
                    let p = ptColorPresets[i]; t.kind = "color"; t.title = p.0
                    t.ca = argbToUIColor(Int32(bitPattern: p.1)); t.cb = argbToUIColor(Int32(bitPattern: p.2))
                    t.onClick = { [weak self] in self?.setColor("ptColA", p.1); self?.setColor("ptColB", p.2); self?.set("ptGrOn", 0); self?.afterEdit(true) }
                } else if b.id == "gradient" {
                    let p = PtGradient.presets[i]; t.title = p.0; t.stops = PtGradient.evenly(p.1)
                    t.onClick = { [weak self] in
                        guard let self = self else { return }
                        PtGradient.write(self.lay, PtGradient.evenly(p.1), pre: self.pre); self.afterEdit(true)
                    }
                } else {
                    let p = b.presets[i]; t.kind = b.id; t.variant = p.1; t.title = p.0
                    if ptThumbBlocks.contains(b.id) { attach(t, b.id, p.2) }
                    t.onClick = { [weak self] in for (k, v) in p.2 { self?.set(k, v) }; self?.afterEdit(true) }
                }
                sc.addSubview(t); x += 80
            }
            sc.contentSize = CGSize(width: x, height: 82)
            stack.addArrangedSubview(sc)
        }
        stack.addArrangedSubview(label("Properties"))
        for it in b.items {
            switch it {
            case .slider(let k, let name, let lo, let hi, let dec):
                let s = RulerSlider(); s.label = name; s.lo = lo; s.hi = hi; s.dec = dec; s.canKey = false; s.value = val(k)
                s.heightAnchor.constraint(equalToConstant: 52).isActive = true
                s.onChange = { [weak self] v in self?.set(k, v); self?.vp.setNeedsDisplay() }
                stack.addArrangedSubview(s)
            case .choice(let k, let name, let opts):
                stack.addArrangedSubview(label(name))
                let row = chipRow(opts, min(opts.count - 1, max(0, Int(val(k).rounded())))) { [weak self] i in self?.set(k, Float(i)); self?.afterEdit(false) }
                row.heightAnchor.constraint(equalToConstant: 46).isActive = true
                stack.addArrangedSubview(row)
            case .action(let title, let id):
                let pb = PillButton(title, nil, C.CARD2, C.TEXT); pb.onClick = { [weak self] in self?.runAction(id) }
                pb.heightAnchor.constraint(equalToConstant: 44).isActive = true
                stack.addArrangedSubview(pb)
            case .gradient:
                let gv = PtGradView(); gv.lay = lay; gv.pre = pre; gv.load()
                gv.heightAnchor.constraint(equalToConstant: 96).isActive = true
                gv.onEdit = { [weak self] in self?.vp.setNeedsDisplay() }
                gv.onEnd = { [weak self] in self?.rebuildStrip() }
                gv.onPick = { [weak self] cur, apply in
                    self?.ed?.showColorPicker(Int32(bitPattern: cur)) { c in apply(UInt32(bitPattern: c)) }
                }
                let br = UIStackView(); br.axis = .horizontal; br.spacing = 8; br.distribution = .fillEqually
                br.heightAnchor.constraint(equalToConstant: 40).isActive = true
                let ec = PillButton("Edit stop colour", nil, C.CARD2, C.TEXT); ec.onClick = { [weak gv] in gv?.editColor() }
                let rm = PillButton("Remove stop", nil, C.CARD2, C.TEXT); rm.onClick = { [weak gv] in gv?.removeSelected() }
                br.addArrangedSubview(ec); br.addArrangedSubview(rm)
                stack.addArrangedSubview(gv); stack.addArrangedSubview(br)
                stack.addArrangedSubview(label("Tap the bar to add a stop (up to 8), drag a handle to move it, double-tap a handle to remove it. Editing turns the gradient on."))
            case .graph(let id, let title):
                stack.addArrangedSubview(label(title))
                let gv = PtGraphView(); gv.cid = id; gv.range = id == "Op" ? 1 : 2; gv.lay = lay; gv.pre = pre; gv.load()
                gv.heightAnchor.constraint(equalToConstant: 190).isActive = true
                gv.onEdit = { [weak self] in self?.vp.setNeedsDisplay() }
                let on = SwitchRow(); on.label = "Use custom graph"; on.on = val("ptCv\(id)On") >= 0.5
                on.heightAnchor.constraint(equalToConstant: 52).isActive = true
                gv.alpha = on.on ? 1 : 0.45; gv.isUserInteractionEnabled = on.on
                on.onToggle = { [weak self, weak gv] v in
                    guard let self = self, let gv = gv else { return }
                    self.set("ptCv\(id)On", v ? 1 : 0)
                    if v { PtCurve.write(self.lay, id, gv.pts, pre: self.pre) }
                    gv.alpha = v ? 1 : 0.45; gv.isUserInteractionEnabled = v; self.afterEdit(false)
                }
                let br = UIStackView(); br.axis = .horizontal; br.spacing = 8; br.distribution = .fillEqually
                br.heightAnchor.constraint(equalToConstant: 40).isActive = true
                let rm = PillButton("Remove point", nil, C.CARD2, C.TEXT); rm.onClick = { [weak gv] in gv?.removeSelected() }
                let rs = PillButton("Reset graph", nil, C.CARD2, C.TEXT); rs.onClick = { [weak gv] in gv?.reset() }
                br.addArrangedSubview(rm); br.addArrangedSubview(rs)
                stack.addArrangedSubview(on); stack.addArrangedSubview(gv); stack.addArrangedSubview(br)
                stack.addArrangedSubview(label("Tap empty space to add a point, drag to move, double-tap a point to remove it."))
            case .color(let k, let name, let def):
                let row = TapView(); row.backgroundColor = argbToUIColor(C.CARD); row.heightAnchor.constraint(equalToConstant: 46).isActive = true
                let tv = UILabel(); tv.text = name; tv.textColor = .white; tv.font = boldFont(15); tv.frame = CGRect(x: 14, y: 0, width: 200, height: 46); row.addSubview(tv)
                let sw = UIView(); sw.backgroundColor = argbToUIColor(Int32(bitPattern: argb(k, def))); sw.layer.cornerRadius = 6
                sw.frame = CGRect(x: max(0, props.bounds.width - 20 - 62), y: 8, width: 48, height: 30); sw.autoresizingMask = [.flexibleLeftMargin]; row.addSubview(sw)
                row.onClick = { [weak self] in
                    guard let self = self else { return }
                    self.ed?.showColorPicker(Int32(bitPattern: self.argb(k, def))) { [weak self] col in self?.setColor(k, UInt32(bitPattern: col)); self?.set("ptGrOn", 0); self?.afterEdit(true) }
                }
                stack.addArrangedSubview(row)
            }
        }
        relayoutStack()
    }

    private func afterEdit(_ rebuildProperties: Bool) {
        vp.setNeedsDisplay(); rebuildStrip()
        if rebuildProperties { rebuildProps() }
    }

    private func apply() { vp.stop(); dismiss(animated: true) { [onDone] in onDone() } }
    private func cancel() {
        for k in snapKeys { if let v = snapVals[k] { lay.track(k).base = v } else { lay.props.removeValue(forKey: k) } }
        vp.stop(); dismiss(animated: true) { [onDone] in onDone() }
    }
}
