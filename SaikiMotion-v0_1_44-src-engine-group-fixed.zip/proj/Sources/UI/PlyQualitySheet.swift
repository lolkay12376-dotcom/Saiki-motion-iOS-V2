//
//  PlyQualitySheet.swift — asks Low / Balanced / Full when a point cloud is too big for a phone.
//
import UIKit

final class PlyQualitySheet: UIView {
    private var done: ((Int) -> Void)?
    private var answered = false

    static func show(in host: UIView, count: Int, _ pick: @escaping (Int) -> Void) {
        let s = PlyQualitySheet(frame: host.bounds); s.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        s.done = pick; s.build(count); host.addSubview(s)
    }

    private func answer(_ n: Int) { guard !answered else { return }; answered = true; done?(n); removeFromSuperview() }
    @objc private func low() { answer(PlyImport.low) }
    @objc private func bal() { answer(PlyImport.balanced) }
    @objc private func full() { answer(min(countAll, PlyImport.fullCap)) }
    private var countAll = 0

    private func build(_ count: Int) {
        countAll = count
        let dim = UIView(frame: bounds); dim.backgroundColor = UIColor(white: 0, alpha: 0.55); dim.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        addSubview(dim)
        let card = UIStackView(); card.axis = .vertical; card.spacing = 10; card.layoutMargins = UIEdgeInsets(top: 20, left: 18, bottom: 20, right: 18)
        card.isLayoutMarginsRelativeArrangement = true
        card.backgroundColor = argbToUIColor(C.PANEL); card.layer.cornerRadius = 22
        card.translatesAutoresizingMaskIntoConstraints = false
        addSubview(card)
        NSLayoutConstraint.activate([card.centerXAnchor.constraint(equalTo: centerXAnchor), card.centerYAnchor.constraint(equalTo: centerYAnchor),
                                     card.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 0.88), card.widthAnchor.constraint(lessThanOrEqualToConstant: 420)])
        func label(_ t: String, _ size: CGFloat, _ bold: Bool, _ col: Int32) {
            let l = UILabel(); l.text = t; l.numberOfLines = 0
            l.font = bold ? .boldSystemFont(ofSize: size) : .systemFont(ofSize: size); l.textColor = argbToUIColor(col); card.addArrangedSubview(l)
        }
        func button(_ title: String, _ sub: String, _ sel: Selector, _ fill: Int32, _ tc: Int32) {
            let b = UIButton(type: .system)
            b.setTitle("\(title)  ·  \(sub)", for: .normal); b.setTitleColor(argbToUIColor(tc), for: .normal)
            b.titleLabel?.font = .boldSystemFont(ofSize: 15); b.backgroundColor = argbToUIColor(fill); b.layer.cornerRadius = 14
            b.heightAnchor.constraint(equalToConstant: 48).isActive = true
            b.addTarget(self, action: sel, for: .touchUpInside); card.addArrangedSubview(b)
        }
        func fmt(_ n: Int) -> String { n >= 1_000_000 ? String(format: "%.1fM", Double(n) / 1e6) : "\(n / 1000)k" }
        label("This point cloud is large", 18, true, C.TEXT)
        label("\(fmt(count)) points. More points look better but are slower and use more memory.", 13, false, C.DIM)
        button("Low", "\(fmt(PlyImport.low)) points, fastest", #selector(low), C.CARD2, C.TEXT)
        button("Balanced", "\(fmt(PlyImport.balanced)) points, recommended", #selector(bal), C.GREEN, C.ONDARK)
        button("Full", "\(fmt(min(count, PlyImport.fullCap))) points, heavy", #selector(full), C.CARD2, C.TEXT)
    }
}
