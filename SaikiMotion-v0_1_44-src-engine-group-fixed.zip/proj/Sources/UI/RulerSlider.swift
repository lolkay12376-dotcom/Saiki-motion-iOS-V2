// RulerSlider.swift — the scrolling-ruler value control used for every parameter.

import UIKit
import Foundation

// MARK: - RulerSlider

/// The scrolling-ruler value control used for every parameter.
/// Drag horizontally to change the value, tap the label to toggle a keyframe.
final class RulerSlider: UIControl {
    var label = ""
    var lo: Float = 0
    var hi: Float = 1
    var value: Float = 0
    var dec = 2
    var hasKey = false
    var hasAnim = false
    var canKey = true
    var onChange: ((Float) -> Void)? = nil
    var onBegin: (() -> Void)? = nil
    var onLabelTap: (() -> Void)? = nil
    var onLabelLong: (() -> Void)? = nil
    var onKeyTap: (() -> Void)? = nil
    private var onKey = false
    var hasExpr = false
    var infinite = false
    var span: Float = 1
    var onExprIcon: (() -> Void)? = nil
    var rowSelected = false

    private var onIcon = false
    private var longFired = false
    private var raw: Float = 0
    private var downX: CGFloat = 0
    private var lastX: CGFloat = 0
    private var dragging = false
    private var onLabel = false
    private var longWork: DispatchWorkItem? = nil

    override init(frame: CGRect) {
        super.init(frame: frame)
    }

    private func fmt(_ v: Float) -> String {
        let q: Float = abs(v) < 0.5 * pow(10, -Float(dec)) ? 0 : v
        return String(format: "%.\(dec)f", q)
    }

    /// Hold-to-type: every ruler slider lets you enter an exact number.
    func promptValue() {
        var top = UIApplication.shared.connectedScenes.compactMap { ($0 as? UIWindowScene)?.windows.first { $0.isKeyWindow } }.first?.rootViewController
        while let p = top?.presentedViewController { top = p }
        guard let vc = top else { return }
        let a = UIAlertController(title: label, message: infinite ? nil : "Range \(fmt(lo)) to \(fmt(hi))", preferredStyle: .alert)
        a.addTextField { [weak self] tf in
            tf.text = self.map { $0.fmt($0.value) }
            tf.keyboardType = .numbersAndPunctuation
            tf.clearButtonMode = .whileEditing
            DispatchQueue.main.async { tf.selectAll(nil) }
        }
        a.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        a.addAction(UIAlertAction(title: "Set", style: .default) { [weak self, weak a] _ in
            guard let self = self, let txt = a?.textFields?.first?.text?.replacingOccurrences(of: ",", with: "."),
                  var v = Float(txt.trimmingCharacters(in: .whitespaces)) else { return }
            if !self.infinite { v = clamp(v, self.lo, self.hi) }
            if self.dec == 0 { v = Float(kotlinRound(v)) }
            self.onBegin?()
            self.value = v; self.raw = v
            self.onChange?(v)
            self.setNeedsDisplay()
        })
        vc.present(a, animated: true)
    }

    private var k: CGFloat { Dev.k }
    private var bw: CGFloat { bounds.width / k }
    private var bh: CGFloat { bounds.height / k }
    private func loc(_ t: UITouch) -> CGPoint { let p = t.location(in: self); return CGPoint(x: p.x / k, y: p.y / k) }
    private func labelW() -> CGFloat { bw * 0.36 }
    private func ppu() -> CGFloat {
        // guard: a degenerate range (min == max) must not divide by zero
        let range: Float = infinite ? max(span, 0.001) : max(hi - lo, 0.001)
        return (bw - labelW()) / CGFloat(range * 0.6)
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let w = bw, h = bh
        c.scaleBy(x: k, y: k)
        let bounds = CGRect(x: 0, y: 0, width: w, height: h)
        fillRoundRect(c, CGRect(x: 0, y: 0, width: w, height: h), 10, C.CARD)
        if hasExpr {
            // expression on: outline fades orange → red
            c.saveGState()
            c.addPath(UIBezierPath(roundedRect: bounds.insetBy(dx: 1.5, dy: 1.5), cornerRadius: 10).cgPath)
            c.setLineWidth(3); c.replacePathWithStrokedPath(); c.clip()
            let g = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(),
                               colors: [UIColor(red: 1, green: 0.6, blue: 0.1, alpha: 1).cgColor,
                                        UIColor(red: 0.95, green: 0.12, blue: 0.1, alpha: 1).cgColor] as CFArray,
                               locations: [0, 1])!
            c.drawLinearGradient(g, start: .zero, end: CGPoint(x: w, y: h), options: [])
            c.restoreGState()
        } else if rowSelected {
            strokeRoundRect(c, bounds.insetBy(dx: 1, dy: 1), 10, 2, C.GREEN)
        }

        let lw = labelW()
        drawText(label, 14, h / 2 + 5, color: hasExpr ? Int32(bitPattern: 0xFFFF6A2A) : C.TEXT, size: 15, bold: true, align: .left)
        if canKey {
            Icons.draw(c, hasKey ? "diamond_f" : "diamond", lw - 18, 18, 16,
                       hasKey ? C.GREEN : Int32(bitPattern: 0xFF7A7A84))
        }

        // ruler
        let cxv = lw + (w - lw) / 2
        let ppuVal = ppu()
        c.saveGState()
        c.clip(to: CGRect(x: lw, y: 0, width: w - lw, height: h))
        let range: Float = infinite ? span : hi - lo
        let rawStep: Float = range * 0.1
        let mag: Float = pow(10, Float(floor(log10(Double(rawStep)))))
        let f: Float = rawStep / mag
        let nice: Float = f < 1.5 ? 1 : (f < 3.5 ? 2 : (f < 7.5 ? 5 : 10))
        let major: Float = nice * mag
        let minor: Float = major / 5
        let k0 = Int(ceil(Double((value - Float((cxv - lw) / ppuVal)) / minor)))
        let k1 = Int(floor(Double((value + Float((w - cxv) / ppuVal)) / minor)))
        if k1 >= k0 {
            for k in k0...k1 {
                let v = Float(k) * minor
                if v < lo - 0.0001 || v > hi + 0.0001 { continue }
                let x = cxv + CGFloat(v - value) * ppuVal
                let isMajor = k % 5 == 0
                let top: CGFloat = isMajor ? h - 18 : h - 11
                strokeLine(c, x, top, x, h - 4, 1.2, Int32(bitPattern: 0xFF6B6B75))
                if isMajor {
                    let s = String(format: major >= 1 ? "%.0f" : "%.1f", v)
                    drawText(s, x, h - 22, color: Int32(bitPattern: 0xFF8C8C96), size: 11, align: .center)
                }
            }
        }
        // boundary markers at min and max
        let xl = cxv + CGFloat(lo - value) * ppuVal
        let xh = cxv + CGFloat(hi - value) * ppuVal
        if xl >= lw && xl <= w { strokeLine(c, xl, 8, xl, h - 4, 2, Int32(bitPattern: 0xFFFFFFFF)) }
        if xh >= lw && xh <= w { strokeLine(c, xh, 8, xh, h - 4, 2, Int32(bitPattern: 0xFFFFFFFF)) }
        // centre line
        strokeLine(c, cxv, 30, cxv, h, 2, C.GREEN)
        c.restoreGState()

        // value bubble
        let s = fmt(value)
        let bw = max(44, measureText(s, 15, true) + 20)
        let r = CGRect(x: cxv - bw / 2, y: 6, width: bw, height: 28)
        fillRoundRect(c, r, 8, C.GREEN)
        drawText(s, cxv, 26, color: C.ONDARK, size: 15, bold: true, align: .center)
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        let pt = loc(t)
        downX = pt.x; lastX = pt.x; dragging = false
        onLabel = pt.x < labelW()
        onIcon = onLabel && onExprIcon != nil && pt.x > labelW() - 42 && pt.y > bh * 0.45
        onKey = onLabel && onKeyTap != nil && canKey && pt.x > labelW() - 44 && pt.y < bh * 0.5
        if onKey { onIcon = false }
        longFired = false
        raw = value
        if !onLabel {
            onBegin?()
            disallowParentScrollInterception(self, true)
            // hold still on the ruler → type an exact value
            longWork = DispatchWorkItem(block: { [weak self] in
                guard let self = self, !self.dragging else { return }
                self.longFired = true
                self.promptValue()
            })
            if let work = longWork { DispatchQueue.main.asyncAfter(deadline: .now() + 0.55, execute: work) }
        } else if !onIcon && !onKey {
            // postDelayed(longRun, 450)
            longWork = DispatchWorkItem(block: { [weak self] in
                guard let self = self, !self.dragging else { return }
                self.longFired = true
                if let f = self.onLabelLong { f() } else { self.promptValue() }
            })
            if let work = longWork { DispatchQueue.main.asyncAfter(deadline: .now() + 0.45, execute: work) }
        }
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        let x = loc(t).x
        if onLabel { return }
        if abs(x - downX) > 4 { dragging = true }
        let dx = x - lastX
        lastX = x
        raw = raw - Float(dx) / Float(ppu())
        if !infinite { raw = clamp(raw, lo, hi) }
        let v: Float = dec == 0 ? Float(kotlinRound(raw)) : raw
        if v != value { value = v; onChange?(v); setNeedsDisplay() }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else {
            longWork?.cancel(); longWork = nil
            disallowParentScrollInterception(self, false)
            return
        }
        let x = loc(t).x
        longWork?.cancel(); longWork = nil
        if onKey && abs(x - downX) < 12 { onKeyTap?() }
        else if onIcon && abs(x - downX) < 10 { onExprIcon?() }
        else if onLabel && !longFired && abs(x - downX) < 8 { onLabelTap?() }
        disallowParentScrollInterception(self, false)
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        longWork?.cancel(); longWork = nil
        disallowParentScrollInterception(self, false)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}
