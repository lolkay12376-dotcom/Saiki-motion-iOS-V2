// Exporter.swift — offscreen render to MP4 (Render).
//
// Renders every frame through the same SceneRenderer the preview uses (full
// quality, deterministic video sampling), writes H.264 via AVAssetWriter,
// then muxes the first audio layer on top with an AVMutableComposition pass.
// Output lands in <Documents>/SaikiMotion/exports and (optionally) Photos.

import Foundation
import AVFoundation
import os
import OpenGLES
import GLKit
import UIKit

struct RenderSettings {
    var scale: Float = 1          // canvas resolution multiplier
    var fps: Int = 30
    var draft = false             // quarter-res fast pass
    var withAudio = true
    var bitrateMbps: Float = 0    // 0 = automatic
    var exportProjectFile = false
}

enum Exporter {

    final class Result {
        var url: URL? = nil
        var error: String? = nil
        var frames = 0
    }

    /// Renders `project`'s current scene to an .mp4. Blocking — call off main.
    static func export(project: Project, scene: Scene, settings: RenderSettings) -> Result {
        let res = Result()
        Paths.ensure()
        let outDir = Paths.root.appendingPathComponent("exports", isDirectory: true)
        try? FileManager.default.createDirectory(at: outDir, withIntermediateDirectories: true)
        let name = "\(alnum(project.name))-\(nowMs()).mp4"
        let outURL = outDir.appendingPathComponent(name)
        try? FileManager.default.removeItem(at: outURL)

        let w = max(16, Int(Float(project.w) * settings.scale) & ~1)   // even for H.264
        let h = max(16, Int(Float(project.h) * settings.scale) & ~1)
        let fps = settings.fps
        let duration = scene.duration

        guard let ctx = GLContext.make() else {
            res.error = "Could not create a GL context."
            return res
        }
        let prev = EAGLContext.current()
        EAGLContext.setCurrent(ctx)
        defer { EAGLContext.setCurrent(prev) }

        let renderer = SceneRenderer(context: ctx)
        renderer.quality = settings.draft ? 4 : 1
        renderer.isExport = true
        Editor.exporting = true
        defer { Editor.exporting = false }
        // pre-rendered groups: make sure their frames exist at export size, then the final
        // render plays those baked frames instead of re-rendering what is inside them
        if !RenderBackend.needsMetal(scene) { renderer.preRenderAll(project: project, scene: scene) }   // Metal export renders groups live (GL bakes had no cloud lighting / water)

        // audio: first visible audio layer
        // audio: every visible audio layer AND every video layer that carries sound
        var audioSegs: [(url: URL, start: Float, offset: Float, end: Float, vol: [(Float, Float)])] = []
        if settings.withAudio {
            for l in scene.layers where (l.type == .AUDIO || l.type == .VIDEO) && l.visible {
                guard let p = l.imagePath else { continue }
                var u = URL(fileURLWithPath: p)
                if let fxu = AudioFxProc.renderSync(p, l.afxChainAt(l.start), l.afxBake()) { u = fxu }
                if l.type == .VIDEO && AVURLAsset(url: u).tracks(withMediaType: .audio).isEmpty { continue }
                var curve: [(Float, Float)] = []      // volume sampled along the layer so keyframes are heard in the export
                var tt = l.start
                while tt < l.end { curve.append((tt, max(0, min(1, l.p("volume", tt))))); tt += 0.05 }
                curve.append((l.end, max(0, min(1, l.p("volume", l.end)))))
                audioSegs.append((u, l.start, l.srcOffset, l.end, curve))
            }
        }

        let writer = try? AVAssetWriter(outputURL: outURL, fileType: .mp4)
        guard let writer = writer else {
            res.error = "Could not create the movie file."
            return res
        }
        var videoSettings: [String: Any] = [
            AVVideoCodecKey: AVVideoCodecType.h264,
            AVVideoWidthKey: w,
            AVVideoHeightKey: h,
        ]
        if settings.bitrateMbps > 0 {
            videoSettings[AVVideoCompressionPropertiesKey] = [AVVideoAverageBitRateKey: Int(settings.bitrateMbps * 1_000_000)]
        }
        let videoInput = AVAssetWriterInput(mediaType: .video, outputSettings: videoSettings)
        videoInput.expectsMediaDataInRealTime = false
        let adaptor = AVAssetWriterInputPixelBufferAdaptor(
            assetWriterInput: videoInput,
            sourcePixelBufferAttributes: [
                kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
                kCVPixelBufferWidthKey as String: w,
                kCVPixelBufferHeightKey as String: h,
            ])
        writer.add(videoInput)

        // GL readback buffer (RGBA → BGRA swap while copying); sized after the
        // first draw() fixes the renderer's working resolution
        var glData = [UInt8](repeating: 0, count: 4)

        writer.startWriting()
        writer.startSession(atSourceTime: .zero)

        let frames = Int(duration * Float(fps))
        var frameIdx = 0
        let timeInc = 1.0 / Double(fps)

        // Render on THIS thread (the one that owns the GL context). Pumping frames from a
        // writer queue made draw() run on a second thread while the context was current
        // here, which can yield blank frames.
        while frameIdx < frames && writer.status != .failed {
            // one autorelease pool per frame: every frame creates a UIImage / CGImage / pixel buffers, and
            // without a pool they all pile up until the system kills the app (the crash at ~80%)
            var stop = false
            autoreleasepool {
            var waited = 0
            while !videoInput.isReadyForMoreMediaData && writer.status != .failed && waited < 5000 {
                Thread.sleep(forTimeInterval: 0.004); waited += 1
            }
            if writer.status == .failed { stop = true; return }
            let t = Float(Double(frameIdx) * timeInc)

            if RenderBackend.needsMetal(scene),
               let img = MetalSceneRenderer.thumbnail(project: project, scene: scene, time: t, quality: renderer.quality),
               let cg = img.cgImage {
                let iw = cg.width, ih = cg.height
                var px = [UInt8](repeating: 0, count: iw * ih * 4)
                if let cx = CGContext(data: &px, width: iw, height: ih, bitsPerComponent: 8, bytesPerRow: iw * 4,
                                      space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) {
                    cx.draw(cg, in: CGRect(x: 0, y: 0, width: iw, height: ih))     // CG memory is top-down; makePixelBuffer expects GL bottom-up
                    var flipped = [UInt8](repeating: 0, count: px.count)
                    for y in 0..<ih { flipped.replaceSubrange((ih - 1 - y) * iw * 4 ..< (ih - y) * iw * 4, with: px[y * iw * 4 ..< (y + 1) * iw * 4]) }
                    if let pb = makePixelBuffer(flipped, iw, ih, w, h) {
                        let cm = CMTime(seconds: Double(frameIdx) * timeInc, preferredTimescale: CMTimeScale(fps * 1000))
                        adaptor.append(pb, withPresentationTime: cm)
                        ExporterProgress.shared.add()
                    }
                    frameIdx += 1
                    return
                }
            }
            EAGLContext.setCurrent(ctx)
            _ = renderer.draw(project: project, scene: scene, time: t, video: nil)
            guard let target = renderer.sceneTarget else { stop = true; return }
            glFinish()
            if glData.count != target.width * target.height * 4 {
                glData = [UInt8](repeating: 0, count: target.width * target.height * 4)
            }
            glBindFramebuffer(GLenum(GL_FRAMEBUFFER), target.fbo)
            glReadPixels(0, 0, GLsizei(target.width), GLsizei(target.height),
                         GLenum(GL_RGBA), GLenum(GL_UNSIGNED_BYTE), &glData)

            if let pb = makePixelBuffer(glData, Int(target.width), Int(target.height), w, h) {
                let cm = CMTime(seconds: Double(frameIdx) * timeInc, preferredTimescale: CMTimeScale(fps * 1000))
                adaptor.append(pb, withPresentationTime: cm)
                ExporterProgress.shared.add()
            }
            frameIdx += 1
            }
            if stop { break }
            if frameIdx % 8 == 0, os_proc_available_memory() < 450 * 1024 * 1024 {
                MetalSceneRenderer.shared?.trimMemory()      // low on memory: drop cached textures instead of being killed
            }
        }
        videoInput.markAsFinished()

        res.frames = frameIdx
        if writer.status == .failed {
            res.error = writer.error?.localizedDescription ?? "The encoder failed."
            try? FileManager.default.removeItem(at: outURL)
            return res
        }
        writer.finishWriting {
            // status becomes .completed here
        }
        while writer.status == .writing {
            Thread.sleep(forTimeInterval: 0.05)
        }
        if writer.status != .completed {
            res.error = writer.error?.localizedDescription ?? "The encoder did not finish."
            try? FileManager.default.removeItem(at: outURL)
            return res
        }

        // audio mux pass
        if !audioSegs.isEmpty {
            let muxed = muxAudio(video: outURL, segs: audioSegs, duration: duration)
            if let muxed = muxed {
                try? FileManager.default.removeItem(at: outURL)
                res.url = muxed
                return res
            }
            // mux failed → ship the silent video
        }
        res.url = outURL
        return res
    }

    /// RGBA buffer (bottom-up) → CVPixelBuffer (top-down BGRA), scaled to outW×outH.
    private static func makePixelBuffer(_ data: [UInt8], _ rw: Int, _ rh: Int,
                                        _ outW: Int, _ outH: Int) -> CVPixelBuffer? {
        var pb: CVPixelBuffer?
        CVPixelBufferCreate(kCFAllocatorDefault, outW, outH,
                            kCVPixelFormatType_32BGRA, nil, &pb)
        guard let pb = pb else { return nil }
        CVPixelBufferLockBaseAddress(pb, [])
        defer { CVPixelBufferUnlockBaseAddress(pb, []) }
        guard let base = CVPixelBufferGetBaseAddress(pb) else { return nil }
        let bpr = CVPixelBufferGetBytesPerRow(pb)
        let dst = base.assumingMemoryBound(to: UInt8.self)

        for y in 0..<outH {
            // flip vertically (GL origin bottom-left → video top-left)
            let srcY = min(rh - 1, Int(Float(rh - 1) * Float(outH - 1 - y) / Float(max(outH - 1, 1))))
            let row = srcY * rw * 4
            let dstRow = y * bpr
            if rw == outW {
                for x in 0..<outW {
                    let s = row + x * 4
                    let d = dstRow + x * 4
                    dst[d] = data[s + 2]      // B
                    dst[d + 1] = data[s + 1]  // G
                    dst[d + 2] = data[s]      // R
                    dst[d + 3] = data[s + 3]  // A
                }
            } else {
                for x in 0..<outW {
                    let sx = min(rw - 1, Int(Float(rw - 1) * Float(x) / Float(max(outW - 1, 1))))
                    let s = row + sx * 4
                    let d = dstRow + x * 4
                    dst[d] = data[s + 2]
                    dst[d + 1] = data[s + 1]
                    dst[d + 2] = data[s]
                    dst[d + 3] = data[s + 3]
                }
            }
        }
        return pb
    }

    /// Composes the rendered video + one audio track into a final .mp4.
    private static func muxAudio(video: URL,
                                 segs: [(url: URL, start: Float, offset: Float, end: Float, vol: [(Float, Float)])],
                                 duration: Float) -> URL? {
        let comp = AVMutableComposition()
        guard let vTrack = comp.addMutableTrack(withMediaType: .video, preferredTrackID: 1),
              let vidAsset = try? AVURLAsset(url: video),
              let vSrc = vidAsset.tracks(withMediaType: .video).first else { return nil }
        let vRange = CMTimeRange(start: .zero, duration: vidAsset.duration)
        try? vTrack.insertTimeRange(vRange, of: vSrc, at: .zero)

        var params: [AVMutableAudioMixInputParameters] = []
        for seg in segs {
            let audAsset = AVURLAsset(url: seg.url)
            guard let aSrc = audAsset.tracks(withMediaType: .audio).first,
                  let aTrack = comp.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid)
            else { continue }
            let at = CMTime(seconds: Double(max(0, seg.offset)), preferredTimescale: 600)
            let inDur = audAsset.duration - at
            let layerLen = CMTime(seconds: Double(max(0, seg.end - seg.start)), preferredTimescale: 600)
            let want = CMTime(seconds: Double(max(0, min(duration - seg.start, seg.end - seg.start))), preferredTimescale: 600)
            let len = min(min(inDur, want), layerLen)
            guard len.seconds > 0 else { continue }
            let insertAt = CMTime(seconds: Double(max(0, seg.start)), preferredTimescale: 600)
            try? aTrack.insertTimeRange(CMTimeRange(start: at, duration: len), of: aSrc, at: insertAt)
            let ip = AVMutableAudioMixInputParameters(track: aTrack)
            ip.setVolume(seg.vol.first?.1 ?? 1, at: .zero)
            for i in 0..<max(0, seg.vol.count - 1) {
                let a = seg.vol[i], b = seg.vol[i + 1]
                ip.setVolumeRamp(fromStartVolume: a.1, toEndVolume: b.1,
                                 timeRange: CMTimeRange(start: CMTime(seconds: Double(a.0), preferredTimescale: 600),
                                                        end: CMTime(seconds: Double(b.0), preferredTimescale: 600)))
            }
            params.append(ip)
        }

        let out = video.deletingLastPathComponent()
            .appendingPathComponent("mux-" + video.lastPathComponent)
        try? FileManager.default.removeItem(at: out)
        guard let session = AVAssetExportSession(asset: comp,
                                                 presetName: AVAssetExportPresetHighestQuality) else { return nil }
        session.outputURL = out
        session.outputFileType = .mp4
        if !params.isEmpty { let mix = AVMutableAudioMix(); mix.inputParameters = params; session.audioMix = mix }
        let sem = DispatchSemaphore(value: 0)
        session.exportAsynchronously { sem.signal() }
        _ = sem.wait(timeout: .now() + 1800)
        guard session.status == .completed else {
            try? FileManager.default.removeItem(at: out)
            return nil
        }
        return out
    }

    private static func alnum(_ s: String) -> String {
        String(s.map { c in
            (c.isASCII && c.isLetter) || (c.isASCII && c.isNumber) ? c : "_"
        })
    }
}

