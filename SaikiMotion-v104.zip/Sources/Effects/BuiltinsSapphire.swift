// BuiltinsSapphire.swift — Sapphire-style effects: Warp Bubble, Blur MoCurves, Roman Tile.
//
// Written from the Sapphire parameter docs. Mocha / crop / filter-quality controls are not included
// (they need the tracker or the host); everything that shapes the look is.

import Foundation

/// GLSL snippet: applies Wrap X / Wrap Y (0 No, 1 Tile, 2 Reflect) to `var`, leaves `inb` = 0 outside when "No".
private func wrapSnippet(_ v: String, _ wx: String, _ wy: String, _ inb: String = "inb") -> String {
    """
    float \(inb) = 1.0;
    if (\(wx) < 0.5) { if (\(v).x < 0.0 || \(v).x > 1.0) { \(inb) = 0.0; } }
    else if (\(wx) < 1.5) { \(v).x = fract(\(v).x); }
    else { \(v).x = 1.0 - abs(mod(\(v).x, 2.0) - 1.0); }
    if (\(wy) < 0.5) { if (\(v).y < 0.0 || \(v).y > 1.0) { \(inb) = 0.0; } }
    else if (\(wy) < 1.5) { \(v).y = fract(\(v).y); }
    else { \(v).y = 1.0 - abs(mod(\(v).y, 2.0) - 1.0); }

    """
}

/// GLSL snippet shared by the Distort* effects. Defines `asp` and `g`: the lens gradient (vec2, brightness
/// difference across the lens), rotated, scaled by Amount Rel and by the Matte. The Lens input is in0, the Matte
/// is in1. With no Lens connected the layer itself acts as the lens, so the effect is visible straight away.
private func lensSnippet(blur: String, rot rotKey: String, relX: String, relY: String,
                         matteUse: String, inv: String) -> String {
    """
    vec2 asp = vec2(uRes.x / uRes.y, 1.0);
    float dpx = max(1.0, \(blur) * 12.0);
    vec2 ox = vec2(dpx / uRes.x, 0.0);
    vec2 oy = vec2(0.0, dpx / uRes.y);
    vec4 la1 = src(uv + ox);
    vec4 la2 = src(uv - ox);
    vec4 lb1 = src(uv + oy);
    vec4 lb2 = src(uv - oy);
    if (uHas0 > 0.5) {
        la1 = in0(uv + ox);
        la2 = in0(uv - ox);
        lb1 = in0(uv + oy);
        lb2 = in0(uv - oy);
    }
    vec2 g = vec2(luma(la1.rgb) - luma(la2.rgb), luma(lb1.rgb) - luma(lb2.rgb));
    g = rot(g, radians(\(rotKey)));
    g = g * vec2(\(relX), \(relY));
    float mm = 1.0;
    if (uHas1 > 0.5) {
        vec4 mt = in1(uv);
        mm = \(matteUse) < 0.5 ? luma(mt.rgb) : mt.a;
        if (\(inv) > 0.5) { mm = 1.0 - mm; }
    }
    g = g * mm;

    """
}

func sapphireDistortFx() -> [EffectDef] {
    var out: [EffectDef] = []
    let wrapOpts = ["No", "Tile", "Reflect"]
    func commonProps(_ p: String) -> [PropDef] {
        [PropDef(p + "RelX", "Amount Rel X", 0, 10, 1, 2),
         PropDef(p + "RelY", "Amount Rel Y", 0, 10, 1, 2),
         PropDef(p + "WrapX", "Wrap X", 0, 2, 2, 0, wrapOpts),
         PropDef(p + "WrapY", "Wrap Y", 0, 2, 2, 0, wrapOpts),
         PropDef(p + "MatteUse", "Matte Use", 0, 1, 0, 0, ["Luma", "Alpha"]),
         PropDef(p + "InvMatte", "Invert Matte", 0, 1, 0, 0, ["Off", "On"])]
    }

    // MARK: Distort Chroma
    out.append(EffectDef(
        id: "distortchroma", name: "Distort Chroma",
        desc: "Prism-like colour fringing: the layer's colour spectrum is warped by the gradient of a Lens layer.",
        category: "Distort", props: [
            PropDef("dcAmount", "Amount", -10, 10, 1, 3),
            PropDef("dcBlur", "Blur Lens", 0, 20, 0.4, 2),
            PropDef("dcRot", "Rotate Warp Dir", -360, 360, 0, 1),
            PropDef("dcRed", "Warp Red", -10, 10, 0.5, 2),
            PropDef("dcBlue", "Warp Blue", -10, 10, 1, 2),
            PropDef("dcSteps", "Steps", 3, 100, 8, 0),
            PropDef("dcWB", "White Balance", 0, 1, 0, 0, ["Off", "On"]),
        ] + commonProps("dc"), colors: [
            ColorParam("dcC1", "Color1", Int32(bitPattern: 0xFFFF0000)),
            ColorParam("dcC2", "Color2", Int32(bitPattern: 0xFF00FF00)),
            ColorParam("dcC3", "Color3", Int32(bitPattern: 0xFF0000FF)),
        ], inputs: ["Lens", "Matte"], glsl: """
    \(lensSnippet(blur: "dcBlur", rot: "dcRot", relX: "dcRelX", relY: "dcRelY", matteUse: "dcMatteUse", inv: "dcInvMatte"))
    vec3 acc = vec3(0.0);
    vec3 sw = vec3(0.0);
    float accA = 0.0;
    float n = max(dcSteps, 3.0);
    for (int i = 0; i < 100; i++) {
        if (float(i) < n) {
            float t = float(i) / (n - 1.0);
            vec3 wc = dcC1.rgb;
            if (t < 0.5) { wc = mix(dcC1.rgb, dcC2.rgb, t * 2.0); }
            else { wc = mix(dcC2.rgb, dcC3.rgb, (t - 0.5) * 2.0); }
            float wf = mix(dcRed, dcBlue, t);
            vec2 d = g * dcAmount * 0.05 * wf;
            vec2 q = uv + vec2(d.x / asp.x, d.y);
            \(wrapSnippet("q", "dcWrapX", "dcWrapY"))
            vec4 s = src(q) * inb;
            acc += s.rgb * wc;
            accA += s.a / n;
            sw += wc;
        }
    }
    vec3 nrm = vec3(max(max(sw.r, sw.g), sw.b));
    if (dcWB > 0.5) { nrm = sw; }
    vec3 rgb = acc / max(nrm, vec3(0.0001));
    return vec4(min(rgb, vec3(accA)), accA);
"""))

    // MARK: Distort RGB
    out.append(EffectDef(
        id: "distortrgbsapphire", name: "Distort RGB (Lens)",
        desc: "Warps the red, green and blue channels by different amounts using the gradient of a Lens layer.",
        category: "Distort", props: [
            PropDef("drAmount", "Amount", -10, 10, 1, 3),
            PropDef("drBlur", "Blur Lens", 0, 20, 0.4, 2),
            PropDef("drRot", "Rotate Warp Dir", -360, 360, 0, 1),
            PropDef("drRed", "Warp Red", -10, 10, 0.5, 2),
            PropDef("drGreen", "Warp Green", -10, 10, 0.75, 2),
            PropDef("drBlue", "Warp Blue", -10, 10, 1, 2),
        ] + commonProps("dr"), inputs: ["Lens", "Matte"], glsl: """
    \(lensSnippet(blur: "drBlur", rot: "drRot", relX: "drRelX", relY: "drRelY", matteUse: "drMatteUse", inv: "drInvMatte"))
    vec2 dB = g * drAmount * 0.05;
    vec2 qr = uv + vec2(dB.x / asp.x, dB.y) * drRed;
    vec2 qg = uv + vec2(dB.x / asp.x, dB.y) * drGreen;
    vec2 qb = uv + vec2(dB.x / asp.x, dB.y) * drBlue;
    \(wrapSnippet("qr", "drWrapX", "drWrapY", "inbR"))
    \(wrapSnippet("qg", "drWrapX", "drWrapY", "inbG"))
    \(wrapSnippet("qb", "drWrapX", "drWrapY", "inbB"))
    vec4 sr = src(qr) * inbR;
    vec4 sg = src(qg) * inbG;
    vec4 sb = src(qb) * inbB;
    float a = (sr.a + sg.a + sb.a) / 3.0;
    return vec4(min(vec3(sr.r, sg.g, sb.b), vec3(a)), a);
"""))

    // MARK: Distort Blur
    out.append(EffectDef(
        id: "distortblur", name: "Distort Blur",
        desc: "Blurs the layer in the direction of the gradient of a Lens layer.",
        category: "Distort", props: [
            PropDef("dbBlurAmt", "Blur Amount", 0, 10, 1, 3),
            PropDef("dbWarpAmt", "Warp Amount", -10, 10, 0, 3),
            PropDef("dbBlur", "Blur Lens", 0, 20, 0.4, 2),
            PropDef("dbRot", "Rotate Blur Dir", -360, 360, 0, 1),
        ] + commonProps("db"), inputs: ["Lens", "Matte"], glsl: """
    \(lensSnippet(blur: "dbBlur", rot: "dbRot", relX: "dbRelX", relY: "dbRelY", matteUse: "dbMatteUse", inv: "dbInvMatte"))
    vec2 gu = vec2(g.x / asp.x, g.y);
    vec2 dirUv = gu * dbBlurAmt * 0.08;
    vec2 warpUv = gu * dbWarpAmt * 0.05;
    vec4 acc = vec4(0.0);
    for (int i = 0; i < 24; i++) {
        float t = (float(i) + 0.5) / 24.0 * 2.0 - 1.0;
        vec2 q = uv + warpUv + dirUv * t;
        \(wrapSnippet("q", "dbWrapX", "dbWrapY"))
        acc += src(q) * inb;
    }
    return acc / 24.0;
"""))
    return out
}

func sapphireFx() -> [EffectDef] {
    var out: [EffectDef] = []
    let wrapOpts = ["No", "Tile", "Reflect"]

    // MARK: Warp Bubble
    out.append(EffectDef(
        id: "warpbubble", name: "Warp Bubble",
        desc: "Warps the layer by smooth animated noise: heat haze, underwater, bubbles.",
        category: "Distort", props: [
            PropDef("wbAmp", "Amplitude", -3, 3, 0.25, 3),
            PropDef("wbFreq", "Frequency", 0.01, 200, 16, 2),
            PropDef("wbFreqX", "Frequency Rel X", 0.01, 10, 1, 2),
            PropDef("wbOct", "Octaves", 1, 10, 1, 0),
            PropDef("wbSeed", "Seed", 0, 100, 0.23, 3),
            PropDef("wbRotDir", "Rotate Warp Dir", -360, 360, 0, 1),
            PropDef("wbShX", "Shift Start X", -100, 100, 0, 3),
            PropDef("wbShY", "Shift Start Y", -100, 100, 0, 3),
            PropDef("wbSpdX", "Shift Speed X", -10, 10, 0.1, 3),
            PropDef("wbSpdY", "Shift Speed Y", -10, 10, 0, 3),
            PropDef("wbZ", "Z Dist", 0.001, 5, 1, 3),
            PropDef("wbWrapX", "Wrap X", 0, 2, 2, 0, wrapOpts),
            PropDef("wbWrapY", "Wrap Y", 0, 2, 2, 0, wrapOpts),
            PropDef("wbMatteUse", "Matte Use", 0, 1, 0, 0, ["Luma", "Alpha"]),
            PropDef("wbInvMatte", "Invert Matte", 0, 1, 0, 0, ["Off", "On"]),
        ], inputs: ["Matte"], glsl: """
    vec2 asp = vec2(uRes.x / uRes.y, 1.0);
    vec2 q0 = (uv - 0.5) * asp;
    vec2 pp = q0 * wbFreq * vec2(wbFreqX, 1.0) + vec2(wbShX, wbShY) + vec2(wbSpdX, wbSpdY) * uTime
            + vec2(wbSeed * 17.3, wbSeed * 9.1);
    vec2 n = vec2(0.0);
    float amp = 1.0;
    float tot = 0.0;
    for (int i = 0; i < 10; i++) {
        if (float(i) < wbOct) {
            n += amp * vec2(vnoise(pp) - 0.5, vnoise(pp + vec2(31.7, 17.3)) - 0.5);
            tot += amp;
            amp *= 0.5;
            pp *= 2.0;
        }
    }
    n = n / max(tot, 0.0001) * 2.0;
    n = rot(n, radians(wbRotDir));
    float m = 1.0;
    if (uHas0 > 0.5) {
        vec4 mt = in0(uv);
        m = wbMatteUse < 0.5 ? luma(mt.rgb) : mt.a;
        if (wbInvMatte > 0.5) { m = 1.0 - m; }
    }
    vec2 disp = n * wbAmp * 2.0 / max(wbFreq, 0.01) * m;
    vec2 q = uv + vec2(disp.x / asp.x, disp.y);
    q = 0.5 + (q - 0.5) * wbZ;
    \(wrapSnippet("q", "wbWrapX", "wbWrapY"))
    return src(q) * inb;
"""))

    // MARK: Blur MoCurves
    out.append(EffectDef(
        id: "blurmocurves", name: "Blur MoCurves",
        desc: "Motion blur along a Z Dist / Rotate / Shift path. Set the per-frame change to blur; keyframe them to animate.",
        category: "Blur", props: [
            PropDef("mcMode", "Mode", 0, 1, 0, 0, ["Transform and Blur", "Blur Only"]),
            PropDef("mcCX", "Center X", -4, 4, 0, 3),
            PropDef("mcCY", "Center Y", -4, 4, 0, 3),
            PropDef("mcZ", "Z Dist", 0.001, 10, 1, 3),
            PropDef("mcRot", "Rotate", -720, 720, 0, 2),
            PropDef("mcShX", "Shift X", -4, 4, 0, 3),
            PropDef("mcShY", "Shift Y", -4, 4, 0, 3),
            PropDef("mcVZ", "Z Dist change / frame", -1, 1, 0, 4),
            PropDef("mcVR", "Rotate change / frame", -90, 90, 0, 3),
            PropDef("mcVShX", "Shift X change / frame", -1, 1, 0, 4),
            PropDef("mcVShY", "Shift Y change / frame", -1, 1, 0, 4),
            PropDef("mcShutter", "Shutter Duration", 0, 8, 1, 2),
            PropDef("mcShutShift", "Shutter Shift", -4, 4, 0, 2),
            PropDef("mcBias", "Exposure Bias", 0, 1, 0.5, 2),
            PropDef("mcBright", "Brightness", 0, 4, 1, 2),
            PropDef("mcWrapX", "Wrap X", 0, 2, 0, 0, wrapOpts),
            PropDef("mcWrapY", "Wrap Y", 0, 2, 0, 0, wrapOpts),
            PropDef("mcMaskUse", "Mask Use", 0, 1, 0, 0, ["Luma", "Alpha"]),
            PropDef("mcInvMask", "Invert Mask", 0, 1, 0, 0, ["Off", "On"]),
        ], inputs: ["Mask"], glsl: """
    vec2 asp = vec2(uRes.x / uRes.y, 1.0);
    vec2 c0 = vec2(0.5 + mcCX * 0.5 / asp.x, 0.5 - mcCY * 0.5);
    float m = 1.0;
    if (uHas0 > 0.5) {
        vec4 mt = in0(uv);
        m = mcMaskUse < 0.5 ? luma(mt.rgb) : mt.a;
        if (mcInvMask > 0.5) { m = 1.0 - m; }
    }
    float baseZ = mcMode > 0.5 ? 1.0 : mcZ;
    float baseR = mcMode > 0.5 ? 0.0 : mcRot;
    vec2 baseS = mcMode > 0.5 ? vec2(0.0) : vec2(mcShX, mcShY);
    vec4 acc = vec4(0.0);
    float ws = 0.0;
    for (int i = 0; i < 32; i++) {
        float u = (float(i) + 0.5) / 32.0;
        float ts = ((u - 0.5) * mcShutter + mcShutShift) * m;   // frames
        float z = max(baseZ + mcVZ * ts, 0.001);
        float r = radians(baseR + mcVR * ts);
        vec2 sh = baseS + vec2(mcVShX, mcVShY) * ts;
        vec2 shUv = vec2(sh.x / asp.x, -sh.y) * 0.5;
        vec2 p = (uv - c0 - shUv) * asp;
        p = rot(p, -r) * z;
        vec2 q = c0 + p / asp;
        \(wrapSnippet("q", "mcWrapX", "mcWrapY"))
        float w = mix(1.0 - u, u, mcBias) + 0.001;
        acc += src(q) * inb * w;
        ws += w;
    }
    return acc / ws * mcBright;
"""))

    // MARK: Roman Tile
    out.append(EffectDef(
        id: "romantile", name: "Roman Tile",
        desc: "Mosaic of lit, grouted tiles coloured from the layer. Square or hexagon, irregular shapes.",
        category: "Stylize", props: [
            PropDef("rtSize", "Tile Size", 0.02, 4, 0.5, 3),
            PropDef("rtShape", "Tile Shape", 0, 1, 0, 0, ["Square", "Hexagon"]),
            PropDef("rtVary", "Vary Shape", 0, 1, 0.2, 2),
            PropDef("rtShX", "Tile Shift X", -50, 50, 0, 3),
            PropDef("rtShY", "Tile Shift Y", -50, 50, 0, 3),
            PropDef("rtSharp", "Tile Edge Sharpness", 0, 1, 0.9, 2),
            PropDef("rtTexF", "Tile Texture Freq", 0, 400, 50, 1),
            PropDef("rtRough", "Tile Roughness", 0, 1, 0.75, 2),
            PropDef("rtHeight", "Tile Height", 0, 3, 0.5, 2),
            PropDef("rtTOp", "Tile Opacity", 0, 1, 0.9, 2),
            PropDef("rtGroutW", "Grout Width", 0, 1, 0.1, 3),
            PropDef("rtGTexF", "Grout Texture Freq", 0, 600, 150, 1),
            PropDef("rtGRough", "Grout Roughness", 0, 1, 0.5, 2),
            PropDef("rtGOp", "Grout Opacity", 0, 1, 1, 2),
            PropDef("rtLX", "Light Position X", -2, 3, 0.9, 3),
            PropDef("rtLY", "Light Position Y", -2, 3, 0.5, 3),
            PropDef("rtLBright", "Light Brightness", 0, 8, 1, 2),
            PropDef("rtLZ", "Light Z", 1, 50, 5, 2),
            PropDef("rtCrop", "Crop To Alpha", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("rtBg", "Bg Brightness", 0, 1, 1, 2),
            PropDef("rtInvMatte", "Invert Matte", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("rtMatteUse", "Matte Use", 0, 1, 1, 0, ["Luma", "Alpha"]),
            PropDef("rtSeed", "Seed", 0, 100, 0.123, 3),
        ], colors: [
            ColorParam("rtGrout", "Grout Color", Int32(bitPattern: 0xFF666666)),
            ColorParam("rtLight", "Light Color", Int32(bitPattern: 0xFF808080)),
        ], inputs: ["Matte"], glsl: """
    vec2 asp = vec2(uRes.x / uRes.y, 1.0);
    float cellH = max(rtSize, 0.01) * 0.15;
    float hexm = rtShape > 0.5 ? 1.0 : 0.0;
    float rowH = mix(1.0, 0.8660254, hexm);
    float e = 1.0 / (max(uRes.y, 1.0) * cellH);
    float gw = clamp(rtGroutW, 0.0, 1.0) * 0.5;
    float h0 = 0.0;
    float h1 = 0.0;
    float h2 = 0.0;
    float inG0 = 0.0;
    vec2 centerUv = uv;
    for (int k = 0; k < 3; k++) {
        vec2 uk = uv;
        if (k == 1) { uk.x += 1.0 / uRes.x; }
        if (k == 2) { uk.y += 1.0 / uRes.y; }
        vec2 p = uk * asp / cellH + vec2(rtShX, rtShY);
        float j0 = floor(p.y / rowH);
        float i0 = floor(p.x);
        float d1 = 1.0e9;
        float d2 = 1.0e9;
        vec2 best = vec2(0.0);
        for (int dj = -1; dj <= 1; dj++) {
            for (int di = -1; di <= 1; di++) {
                float jj = j0 + float(dj);
                float ii = i0 + float(di);
                vec2 g = vec2(ii + 0.5 * hexm * mod(jj, 2.0), jj * rowH);
                vec2 rj = vec2(hash21(vec2(ii, jj) + rtSeed * 91.7),
                               hash21(vec2(jj, ii) + rtSeed * 53.1 + 7.7)) - 0.5;
                vec2 pt = g + 0.5 + rj * rtVary * 0.9;
                float d = length(p - pt);
                if (d < d1) { d2 = d1; d1 = d; best = pt; }
                else if (d < d2) { d2 = d; }
            }
        }
        float b = (d2 - d1) * 0.5;
        float tex = vnoise(uk * asp * rtTexF) - 0.5;
        float gtex = vnoise(uk * asp * rtGTexF + 13.7) - 0.5;
        float inG = 1.0 - smoothstep(gw - 0.012, gw + 0.012, b);
        float prof = clamp((b - gw) / max(0.02, (1.0 - rtSharp) * 0.5), 0.0, 1.0);
        float ht = rtHeight * prof + rtRough * tex * 0.15;
        float hg = rtGRough * gtex * 0.15;
        float hh = mix(ht, hg, inG);
        if (k == 0) { h0 = hh; inG0 = inG; centerUv = (best - vec2(rtShX, rtShY)) * cellH / asp; }
        else if (k == 1) { h1 = hh; }
        else { h2 = hh; }
    }
    vec3 nrm = normalize(vec3(-(h1 - h0) / e, -(h2 - h0) / e, 1.0));
    vec3 Ld = normalize(vec3((vec2(rtLX, rtLY) - uv) * asp, rtLZ * 0.25));
    float diff = max(dot(nrm, Ld), 0.0);
    vec3 lightF = vec3(1.0);
    if (rtLBright > 0.0001) { lightF = vec3(0.5) + rtLight.rgb * rtLBright * diff * 2.0; }
    vec4 s = src(uv);
    vec4 sc = unpremul(s);
    vec4 cs = unpremul(src(centerUv));
    vec3 bgRgb = sc.rgb * rtBg;
    vec3 tcol = mix(bgRgb, cs.rgb * lightF, rtTOp);
    vec3 gcol = mix(bgRgb, rtGrout.rgb * lightF, rtGOp);
    vec3 oc = mix(tcol, gcol, inG0);
    float oa = rtCrop > 0.5 ? s.a : cs.a;
    vec4 res = vec4(oc * oa, oa);
    if (uHas0 > 0.5) {
        vec4 mt = in0(uv);
        float m = rtMatteUse < 0.5 ? luma(mt.rgb) : mt.a;
        if (rtInvMatte > 0.5) { m = 1.0 - m; }
        res = mix(s, res, m);
    }
    return res;
"""))
    return out
}

/// GLSL snippet: defines `mk`, the Mask input (in0) as a 0..1 value (1 everywhere when no mask is connected).
private func maskSnippet(_ use: String, _ inv: String) -> String {
    """
    float mk = 1.0;
    if (uHas0 > 0.5) {
        vec4 mt = in0(uv);
        mk = \(use) < 0.5 ? luma(mt.rgb) : mt.a;
        if (\(inv) > 0.5) { mk = 1.0 - mk; }
    }

    """
}

func sapphireMoreFx() -> [EffectDef] {
    var out: [EffectDef] = []
    let wrapOpts = ["No", "Tile", "Reflect"]
    let maskProps: (String) -> [PropDef] = { p in
        [PropDef(p + "MaskUse", "Mask Use", 0, 1, 0, 0, ["Luma", "Alpha"]),
         PropDef(p + "InvMask", "Invert Mask", 0, 1, 0, 0, ["Off", "On"])]
    }

    // MARK: Deband
    out.append(EffectDef(
        id: "sapdeband", name: "Deband",
        desc: "Removes banding by diffusing pixels across banded areas while keeping real edges. Use Show: Edges to tune the threshold.",
        category: "Blur", props: [
            PropDef("deThr", "Edge Threshold", 0, 255, 2, 2),
            PropDef("deGrow", "Grow Edges", 0, 50, 0, 1),
            PropDef("deShow", "Show", 0, 1, 0, 0, ["Result", "Edges"]),
            PropDef("deDiff", "Diffuse Threshold", 0, 20, 1, 2),
            PropDef("deRad", "Diffuse Radius", 0, 100, 12, 1),
            PropDef("dePre", "Pre Blur", 0, 20, 0, 2),
            PropDef("dePost", "Post Blur", 0, 20, 0.5, 2),
        ] + maskProps("de"), inputs: ["Mask"], glsl: """
    \(maskSnippet("deMaskUse", "deInvMask"))
    vec4 c0 = src(uv);
    vec2 px = vec2(1.0) / uRes;
    float thr = deThr / 255.0;
    vec3 cen = c0.rgb;
    if (dePre > 0.0) {
        cen = (c0.rgb * 2.0 + src(uv + vec2(px.x, 0.0) * dePre).rgb + src(uv - vec2(px.x, 0.0) * dePre).rgb
               + src(uv + vec2(0.0, px.y) * dePre).rgb + src(uv - vec2(0.0, px.y) * dePre).rgb) / 6.0;
    }
    float edge = 0.0;
    for (int k = 0; k < 9; k++) {
        vec2 off = vec2(0.0);
        if (k > 0) {
            float an = (float(k) - 1.0) * 0.785398;
            off = vec2(cos(an), sin(an)) * deGrow * px;
        }
        vec2 p0 = uv + off;
        vec3 a = src(p0).rgb;
        vec3 e1 = abs(a - src(p0 + vec2(px.x, 0.0)).rgb);
        vec3 e2 = abs(a - src(p0 + vec2(0.0, px.y)).rgb);
        float em = max(max(max(e1.r, e1.g), e1.b), max(max(e2.r, e2.g), e2.b));
        if (em > thr) { edge = 1.0; }
    }
    if (deShow > 0.5) { return vec4(vec3(edge), c0.a); }
    float dt = deDiff * thr;
    vec3 acc = cen;
    float ws = 1.0;
    for (int i = 0; i < 24; i++) {
        float f = (float(i) + 0.5) / 24.0;
        float an = float(i) * 2.39996;
        vec3 s = src(uv + vec2(cos(an), sin(an)) * sqrt(f) * deRad * px).rgb;
        vec3 dd = abs(s - cen);
        if (max(max(dd.r, dd.g), dd.b) <= dt) { acc += s; ws += 1.0; }
    }
    vec3 res = acc / ws;
    if (dePost > 0.0) {
        vec3 nb = (src(uv + vec2(px.x, 0.0) * dePost).rgb + src(uv - vec2(px.x, 0.0) * dePost).rgb
                 + src(uv + vec2(0.0, px.y) * dePost).rgb + src(uv - vec2(0.0, px.y) * dePost).rgb) * 0.25;
        res = mix(res, nb, clamp(dePost, 0.0, 1.0) * 0.5);
    }
    res += vec3(hash21(uv * uRes) - 0.5) / 255.0;       // tiny dither so the smoothed result does not re-band at 8 bits
    res = mix(res, c0.rgb, edge);
    return mix(c0, vec4(res, c0.a), mk);
"""))

    // MARK: Shake
    out.append(EffectDef(
        id: "sapshake", name: "Shake (Sapphire)",
        desc: "Repeatable camera shake with random and wave motion on X, Y, zoom and tilt; Twitchy / Jumpy styles; RGB split; motion blur.",
        category: "Distort", props: [
            PropDef("shStyle", "Style", 0, 2, 0, 0, ["Normal", "Twitchy", "Jumpy"]),
            PropDef("shApply", "Apply Mask", 0, 1, 0, 0, ["Post-effect", "Pre-effect"]),
            PropDef("shAmp", "Amplitude", 0, 20, 1, 2),
            PropDef("shFreq", "Frequency", 0, 100, 8, 2),
            PropDef("shPhase", "Phase", -1000, 1000, 0, 2),
            PropDef("shStill", "Stillness", 0, 1, 0.7, 2),
            PropDef("shTwF", "Twitch Frequency", 0, 50, 2, 2),
            PropDef("shDrift", "Drift", 0, 1, 0.3, 2),
            PropDef("shBias", "Center Bias", 0, 1, 0, 2),
            PropDef("shZ", "Z Dist", 0.001, 5, 1, 3),
            PropDef("shMB", "Motion Blur", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("shMBLen", "Mo Blur Length", 0, 10, 1, 2),
            PropDef("shSeed", "Seed", 0, 1000, 0, 2),
            PropDef("shWrapX", "Wrap X", 0, 2, 2, 0, wrapOpts),
            PropDef("shWrapY", "Wrap Y", 0, 2, 2, 0, wrapOpts),
            PropDef("shXRA", "X Rand Amp", 0, 10, 0.2, 3),
            PropDef("shXRF", "X Rand Freq", 0, 50, 1, 2),
            PropDef("shXWA", "X Wave Amp", 0, 10, 0, 3),
            PropDef("shXWF", "X Wave Freq", 0, 50, 0.5, 2),
            PropDef("shXPh", "X Phase", -1000, 1000, 0, 2),
            PropDef("shYRA", "Y Rand Amp", 0, 10, 0.1, 3),
            PropDef("shYRF", "Y Rand Freq", 0, 50, 1, 2),
            PropDef("shYWA", "Y Wave Amp", 0, 10, 0, 3),
            PropDef("shYWF", "Y Wave Freq", 0, 50, 0.5, 2),
            PropDef("shYPh", "Y Phase", -1000, 1000, 0, 2),
            PropDef("shZRA", "Z Rand Amp", 0, 10, 0, 3),
            PropDef("shZRF", "Z Rand Freq", 0, 50, 1, 2),
            PropDef("shZWA", "Z Wave Amp", 0, 10, 0, 3),
            PropDef("shZWF", "Z Wave Freq", 0, 50, 0.5, 2),
            PropDef("shZPh", "Z Phase", -1000, 1000, 0, 2),
            PropDef("shTRA", "Tilt Rand Amp", 0, 90, 0, 3),
            PropDef("shTRF", "Tilt Rand Freq", 0, 50, 1, 2),
            PropDef("shTWA", "Tilt Wave Amp", 0, 90, 0, 3),
            PropDef("shTWF", "Tilt Wave Freq", 0, 50, 0.5, 2),
            PropDef("shTPh", "Tilt Phase", -1000, 1000, 0, 2),
            PropDef("shRedAmp", "Red Amplitude", 0, 10, 1, 2),
            PropDef("shGreenAmp", "Green Amplitude", 0, 10, 1, 2),
            PropDef("shBlueAmp", "Blue Amplitude", 0, 10, 1, 2),
            PropDef("shRedPh", "Red Phase", -10, 10, 0, 3),
            PropDef("shGreenPh", "Green Phase", -10, 10, 0, 3),
            PropDef("shBluePh", "Blue Phase", -10, 10, 0, 3),
            PropDef("shRGBRand", "RGB Randomness", 0, 10, 0, 2),
            PropDef("shRGBF", "RGB Frequency", 0, 50, 2, 2),
            PropDef("shFlip", "Flip Shake Vertically", 0, 1, 0, 0, ["Off", "On"]),
        ] + maskProps("sh"), inputs: ["Mask"], glsl: """
    \(maskSnippet("shMaskUse", "shInvMask"))
    vec2 asp = vec2(uRes.x / uRes.y, 1.0);
    float ampK = shAmp * (shApply > 0.5 ? mk : 1.0);
    float nS = shMB > 0.5 ? 8.0 : 1.0;
    vec4 rAmp = vec4(shXRA, shYRA, shZRA, shTRA);
    vec4 rFq = vec4(shXRF, shYRF, shZRF, shTRF);
    vec4 wAmp = vec4(shXWA, shYWA, shZWA, shTWA);
    vec4 wFq = vec4(shXWF, shYWF, shZWF, shTWF);
    vec4 aPh = vec4(shXPh, shYPh, shZPh, shTPh);
    float sd = shSeed * 7.13;
    vec4 acc = vec4(0.0);
    for (int s = 0; s < 8; s++) {
        if (float(s) < nS) {
            float u = (float(s) + 0.5) / nS;
            float ts = uTime + shPhase + (u - 0.5) * shMBLen * (shMB > 0.5 ? 1.0 : 0.0) / 30.0;
            for (int ch = 0; ch < 3; ch++) {
                float cAmp = shRedAmp;
                float cPh = shRedPh;
                if (ch == 1) { cAmp = shGreenAmp; cPh = shGreenPh; }
                if (ch == 2) { cAmp = shBlueAmp; cPh = shBluePh; }
                float tb = (ts + cPh) * shFreq;
                vec4 tv = (vec4(tb) + aPh) * rFq;
                vec4 nz = vec4(vnoise(vec2(tv.x, sd + 1.0)), vnoise(vec2(tv.y, sd + 2.0)),
                               vnoise(vec2(tv.z, sd + 3.0)), vnoise(vec2(tv.w, sd + 4.0))) - 0.5;
                nz = nz * 2.0;
                float rc = tb * shRGBF + float(ch) * 13.7;
                vec4 rn = vec4(vnoise(vec2(rc, sd + 11.0)), vnoise(vec2(rc, sd + 12.0)),
                               vnoise(vec2(rc, sd + 13.0)), vnoise(vec2(rc, sd + 14.0))) - 0.5;
                nz = nz + rn * 2.0 * shRGBRand;
                float gate = 1.0;
                if (shStyle > 0.5 && shStyle < 1.5) {
                    float tq = 0.2 + 0.6 * shStill;
                    gate = smoothstep(tq - 0.04, tq + 0.04, vnoise(vec2(tb * shTwF * 0.125, sd + 21.0)));
                }
                if (shStyle > 1.5) {
                    float jt = floor(tb * 0.25);
                    vec4 jv = (vec4(hash21(vec2(jt, sd + 1.0)), hash21(vec2(jt, sd + 2.0)),
                                    hash21(vec2(jt, sd + 3.0)), hash21(vec2(jt, sd + 4.0))) - 0.5) * 2.0;
                    if (hash21(vec2(jt, sd + 99.0)) < shBias) { jv = vec4(0.0); }
                    nz = jv + nz * shDrift;
                }
                vec4 wv = sin(6.2831853 * wFq * (vec4(tb) + aPh) / 8.0);
                vec4 sh = (nz * rAmp + wv * wAmp) * gate * cAmp * ampK;
                float zS = max(shZ + sh.z * 0.1, 0.001);
                vec2 tr = vec2(sh.x / asp.x, sh.y * (shFlip > 0.5 ? -1.0 : 1.0)) * 0.1;
                vec2 p = (uv - vec2(0.5) - tr) * asp;
                p = rot(p, -radians(sh.w)) * zS;
                vec2 q = vec2(0.5) + p / asp;
                \(wrapSnippet("q", "shWrapX", "shWrapY"))
                vec4 sm = src(q) * inb;
                if (ch == 0) { acc.r += sm.r; }
                else if (ch == 1) { acc.g += sm.g; }
                else { acc.b += sm.b; }
                acc.a += sm.a / 3.0;
            }
        }
    }
    vec4 res = acc / nS;
    if (shApply < 0.5) { res = mix(src(uv), res, mk); }
    return res;
"""))

    // MARK: Scan Lines
    out.append(EffectDef(
        id: "sapscanlines", name: "Scan Lines (Sapphire)",
        desc: "Colour-TV scan line pattern with per-channel line shifts, noise, gamma and saturation.",
        category: "Stylize", props: [
            PropDef("slFreq", "Lines Frequency", 1, 1000, 50, 1),
            PropDef("slSharp", "Lines Sharpness", 0, 10, 1, 2),
            PropDef("slAngle", "Lines Angle", -360, 360, 0, 1),
            PropDef("slShift", "Lines Shift", -10, 10, 0, 3),
            PropDef("slShR", "Shift Red", -2, 2, 0, 3),
            PropDef("slShG", "Shift Green", -2, 2, 0, 3),
            PropDef("slShB", "Shift Blue", -2, 2, 0, 3),
            PropDef("slNoise", "Add Noise", 0, 2, 0, 3),
            PropDef("slNoiseF", "Noise Freq Rel", 0.01, 20, 1, 2),
            PropDef("slBright", "Brightness", 0, 4, 1, 2),
            PropDef("slOffset", "Offset", -1, 1, 0, 3),
            PropDef("slGamma", "Gamma", 0.1, 4, 1.5, 2),
            PropDef("slSat", "Saturation", 0, 4, 1, 2),
            PropDef("slSmooth", "Smooth Source", 0, 20, 0, 2),
        ] + maskProps("sl"), colors: [
            ColorParam("slScale", "Scale Color", Int32(bitPattern: 0xFFFFFFFF)),
        ], inputs: ["Mask"], glsl: """
    \(maskSnippet("slMaskUse", "slInvMask"))
    vec2 asp = vec2(uRes.x / uRes.y, 1.0);
    vec2 px = vec2(1.0) / uRes;
    vec4 c = src(uv);
    if (slSmooth > 0.0) {
        c = (c * 2.0 + src(uv + vec2(px.x, 0.0) * slSmooth) + src(uv - vec2(px.x, 0.0) * slSmooth)
             + src(uv + vec2(0.0, px.y) * slSmooth) + src(uv - vec2(0.0, px.y) * slSmooth)) / 6.0;
    }
    vec4 un = unpremul(c);
    vec2 pr = rot((uv - vec2(0.5)) * asp, -radians(slAngle));
    float base = pr.y * slFreq + slShift;
    vec3 v = vec3(base + slShR, base + slShG, base + slShB);
    vec3 prof = vec3(0.5) + 0.5 * cos(6.2831853 * v);
    vec3 lv = clamp((prof - 0.5) * max(slSharp, 1.0) + 0.5, 0.0, 1.0);
    vec3 f = mix(vec3(1.0), lv, clamp(slSharp, 0.0, 1.0));
    vec3 rgb = un.rgb * f;
    if (slNoise > 0.0) {
        vec2 nc = floor(pr * slFreq * slNoiseF);
        rgb += (vec3(hash21(nc + 1.3), hash21(nc + 7.9), hash21(nc + 17.1)) - 0.5) * slNoise;
    }
    rgb = pow(max(rgb, vec3(0.0)), vec3(1.0 / max(slGamma, 0.1)));
    rgb = mix(vec3(luma(rgb)), rgb, slSat);
    rgb = rgb * slBright * slScale.rgb + vec3(slOffset);
    vec4 res = vec4(clamp(rgb, 0.0, 1.0) * un.a, un.a);
    return mix(src(uv), res, mk);
"""))
    return out
}
