// BuiltinsSapphire2.swift — Sapphire-style Etching, Film Damage and Warp Bubble 2.
//
// Written from the Sapphire parameter docs. Mocha / crop / filter-quality controls are not included
// (they need the tracker or the host); everything that shapes the look is.

import Foundation

private let wrap2Opts = ["No", "Tile", "Reflect"]

private func wrap2(_ v: String, _ wx: String, _ wy: String) -> String {
    """
    float inb = 1.0;
    if (\(wx) < 0.5) { if (\(v).x < 0.0 || \(v).x > 1.0) { inb = 0.0; } }
    else if (\(wx) < 1.5) { \(v).x = fract(\(v).x); }
    else { \(v).x = 1.0 - abs(mod(\(v).x, 2.0) - 1.0); }
    if (\(wy) < 0.5) { if (\(v).y < 0.0 || \(v).y > 1.0) { inb = 0.0; } }
    else if (\(wy) < 1.5) { \(v).y = fract(\(v).y); }
    else { \(v).y = 1.0 - abs(mod(\(v).y, 2.0) - 1.0); }

    """
}

/// One bubble set (A or B): returns its displacement in `nA` / `nB`.
private func bubbleSet(_ s: String, _ k: String) -> String {
    """
    vec2 pp\(s) = q0 * \(k)Freq + vec2(\(k)ShX, \(k)ShY) + vec2(\(k)SpdX, \(k)SpdY) * uTime + vec2(\(k)Seed * 17.3, \(k)Seed * 9.1);
    vec2 n\(s) = vec2(0.0);
    float amp\(s) = 1.0;
    float tot\(s) = 0.0;
    for (int i = 0; i < 10; i++) {
        if (float(i) < \(k)Oct) {
            vec2 pq = rot(pp\(s), 0.9) + vec2(5.3, 8.1);
            n\(s) += amp\(s) * vec2(0.5 * (vnoise(pp\(s)) + vnoise(pq)) - 0.5,
                                0.5 * (vnoise(pp\(s) + vec2(31.7, 17.3)) + vnoise(pq + vec2(11.1, 23.9))) - 0.5);
            tot\(s) += amp\(s);
            amp\(s) *= 0.5;
            pp\(s) *= 2.0;
        }
    }
    n\(s) = n\(s) / max(tot\(s), 0.0001) * 2.0 * \(k)Amp * 2.0 / max(\(k)Freq, 0.01);

    """
}

private func bubbleProps(_ k: String, _ nm: String, _ seed: Float, _ spd: Float) -> [PropDef] {
    [PropDef("\(k)Amp", "\(nm) Amplitude", -3, 3, 0.25, 3),
     PropDef("\(k)Freq", "\(nm) Frequency", 0.01, 200, 4, 2),
     PropDef("\(k)Oct", "\(nm) Octaves", 1, 10, 1, 0),
     PropDef("\(k)Seed", "\(nm) Seed", 0, 100, seed, 3),
     PropDef("\(k)ShX", "\(nm) Shift Start X", -100, 100, 0, 3),
     PropDef("\(k)ShY", "\(nm) Shift Start Y", -100, 100, 0, 3),
     PropDef("\(k)SpdX", "\(nm) Speed X", -10, 10, spd, 3),
     PropDef("\(k)SpdY", "\(nm) Speed Y", -10, 10, 0, 3)]
}

func sapphire2Fx() -> [EffectDef] {
    var out: [EffectDef] = []

    // MARK: Warp Bubble 2
    out.append(EffectDef(
        id: "warpbubble2", name: "Warp Bubble 2",
        desc: "Warps the layer with two overlapping sets of bubble patterns (heat haze, underwater). Shift Speed animates each set.",
        category: "Distort",
        props: bubbleProps("wb2a", "A", 0.23, 0.1) + bubbleProps("wb2b", "B", 0.34, -0.1) + [
            PropDef("wb2Z", "Z Dist", 0.001, 5, 1, 3),
            PropDef("wb2WrapX", "Wrap X", 0, 2, 2, 0, wrap2Opts),
            PropDef("wb2WrapY", "Wrap Y", 0, 2, 2, 0, wrap2Opts),
            PropDef("wb2MatteUse", "Matte Use", 0, 1, 0, 0, ["Luma", "Alpha"]),
            PropDef("wb2InvMatte", "Invert Matte", 0, 1, 0, 0, ["Off", "On"]),
        ], inputs: ["Matte"], glsl: """
    vec2 asp = vec2(uRes.x / uRes.y, 1.0);
    vec2 q0 = (uv - 0.5) * asp;
    \(bubbleSet("A", "wb2a"))
    \(bubbleSet("B", "wb2b"))
    float m = 1.0;
    if (uHas0 > 0.5) {
        vec4 mt = in0(uv);
        m = wb2MatteUse < 0.5 ? luma(mt.rgb) : mt.a;
        if (wb2InvMatte > 0.5) { m = 1.0 - m; }
    }
    vec2 disp = (nA + nB) * m;
    vec2 q = uv + vec2(disp.x / asp.x, disp.y);
    q = 0.5 + (q - 0.5) * wb2Z;
    \(wrap2("q", "wb2WrapX", "wb2WrapY"))
    return src(q) * inb;
"""))

    // MARK: Etching
    out.append(EffectDef(
        id: "etching", name: "Etching",
        desc: "Etching / lithograph look from two sets of black and white lines of varying thickness. Smooth Source evens out the lines; Lines Frequency sets the density.",
        category: "Stylize", props: [
            PropDef("etFreq", "Lines Frequency", 0, 400, 50, 1),
            PropDef("etFreq1", "Lines1 Frequency", 0, 4, 1, 2),
            PropDef("etFreq2", "Lines2 Frequency", 0, 4, 1, 2),
            PropDef("etAng", "Lines Angle", -360, 360, 0, 1),
            PropDef("etAng1", "Lines1 Angle", -360, 360, 30, 1),
            PropDef("etAng2", "Lines2 Angle", -360, 360, -20, 1),
            PropDef("etShX", "Lines Shift X", -1, 1, 0, 3),
            PropDef("etShY", "Lines Shift Y", -1, 1, 0, 3),
            PropDef("etSharp", "Lines Sharpness", 0.1, 20, 4, 2),
            PropDef("etAdd", "Lines Add Width", -1, 1, 0, 3),
            PropDef("etSmooth", "Smooth Source", 0, 5, 0, 2),
            PropDef("etWaveAmp", "Wave Amp", 0, 1, 0.1, 3),
            PropDef("etWaveFreq", "Wave Frequency", 0, 20, 2, 2),
            PropDef("etWarpAmp", "Warp Amp", -1, 1, 0.04, 3),
            PropDef("etWarpSm", "Warp Smooth", 0, 1, 0.044, 3),
            PropDef("etEdgeScale", "Edges Scale", 0, 3, 0.5, 2),
            PropDef("etEdgeThr", "Edges Threshold", 0, 2, 0.3, 2),
            PropDef("etEdgeW", "Edges Width", 0, 6, 0, 2),
            PropDef("etEdgeSharp", "Edges Sharpness", 0.1, 10, 3, 2),
        ], colors: [
            ColorParam("etCol1", "Color1 (bright)", Int32(bitPattern: 0xFFFFFFFF)),
            ColorParam("etCol0", "Color0 (dark)", Int32(bitPattern: 0xFF000000)),
        ], glsl: """
    vec2 asp = vec2(uRes.x / uRes.y, 1.0);
    vec2 px = 1.0 / uRes;
    // blurred luminance (Smooth Source) — also drives the warp
    float sr = max(etSmooth, etWarpSm * 8.0) * 2.0 + 0.5;
    float lb = 0.0;
    float lw = 0.0;
    for (int i = 0; i < 9; i++) {
        vec2 o = vec2(float(i - (i / 3) * 3) - 1.0, float(i / 3) - 1.0);
        float w = exp(-dot(o, o) * 0.5);
        lb += luma(src(uv + o * sr * px).rgb) * w; lw += w;
    }
    lb /= lw;
    float ls = etSmooth > 0.001 ? lb : luma(src(uv).rgb);
    vec2 puv = uv + vec2(lb - 0.5, lb - 0.5) * etWarpAmp * vec2(1.0 / asp.x, 1.0);
    vec2 p = (puv - 0.5 - vec2(etShX, etShY)) * asp;
    float freq = etFreq;
    vec2 d1 = vec2(cos(radians(etAng + etAng1)), sin(radians(etAng + etAng1)));
    vec2 d2 = vec2(cos(radians(etAng + etAng2)), sin(radians(etAng + etAng2)));
    float w1 = sin(dot(p, vec2(-d1.y, d1.x)) * etWaveFreq * 6.2832) * etWaveAmp;
    float w2 = sin(dot(p, vec2(-d2.y, d2.x)) * etWaveFreq * 6.2832 + 1.7) * etWaveAmp;
    float u1 = dot(p, d1) * freq * etFreq1 + w1 * freq * etFreq1 * 0.1;
    float u2 = dot(p, d2) * freq * etFreq2 + w2 * freq * etFreq2 * 0.1;
    float t1 = abs(fract(u1) - 0.5) * 2.0;          // 0 on a line centre, 1 between lines
    float t2 = abs(fract(u2) - 0.5) * 2.0;
    float th1 = clamp((0.78 - ls) * 1.5 + etAdd, 0.0, 1.0);    // darker → thicker lines
    float th2 = clamp((0.42 - ls) * 2.6 + etAdd, 0.0, 1.0);    // second set only in the shadows
    float ink = max(clamp((th1 - t1) * etSharp, 0.0, 1.0), clamp((th2 - t2) * etSharp, 0.0, 1.0));
    // source edges added to the pattern
    if (etEdgeScale > 0.001) {
        vec2 ep = px * (1.0 + etEdgeW);
        float a = luma(src(uv + vec2(-ep.x, -ep.y)).rgb), b = luma(src(uv + vec2(0.0, -ep.y)).rgb), c = luma(src(uv + vec2(ep.x, -ep.y)).rgb);
        float d = luma(src(uv + vec2(-ep.x, 0.0)).rgb), f = luma(src(uv + vec2(ep.x, 0.0)).rgb);
        float g = luma(src(uv + vec2(-ep.x, ep.y)).rgb), h = luma(src(uv + vec2(0.0, ep.y)).rgb), k = luma(src(uv + vec2(ep.x, ep.y)).rgb);
        float gx = (c + 2.0 * f + k) - (a + 2.0 * d + g);
        float gy = (g + 2.0 * h + k) - (a + 2.0 * b + c);
        float e = length(vec2(gx, gy)) * etEdgeScale;
        e = clamp((e - etEdgeThr) * etEdgeSharp, 0.0, 1.0);
        ink = max(ink, e);
    }
    vec4 c0 = src(uv);
    vec3 rgb = mix(etCol1.rgb, etCol0.rgb, ink);
    return vec4(rgb * c0.a, c0.a);
"""))

    // MARK: Film Damage
    out.append(EffectDef(
        id: "filmdamage", name: "Film Damage",
        desc: "Damaged film: grain, dust, hairs, stains, scratches, defocus, flicker, shake, vignette and colour correction. Each damage type has a master control and detail controls.",
        category: "Stylize", props: [
            PropDef("fdGrain", "Grain Amp", 0, 2, 0.1, 2),
            PropDef("fdGrR", "Grain Amp Red", 0, 4, 0.9, 2),
            PropDef("fdGG", "Grain Amp Green", 0, 4, 1, 2),
            PropDef("fdGB", "Grain Amp Blue", 0, 4, 1.6, 2),
            PropDef("fdGDark", "Grain Amp Darks", 0, 2, 0.2, 2),
            PropDef("fdGBright", "Grain Amp Brights", 0, 2, 0, 2),
            PropDef("fdGBlur", "Grain Blur", 0, 6, 0, 2),
            PropDef("fdGMono", "Grain Mono", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("fdSat", "Saturation", 0, 3, 1, 2),
            PropDef("fdScale", "Scale Lights", 0, 3, 1, 2),
            PropDef("fdOffD", "Offset Darks", -1, 1, 0, 3),
            PropDef("fdStain", "Stain Density", 0, 12, 0.2, 2),
            PropDef("fdStainSize", "Stain Size", 0, 4, 1, 2),
            PropDef("fdStainOp", "Stain Opacity", 0, 1, 0.5, 2),
            PropDef("fdDust", "Dust Density", 0, 400, 30, 1),
            PropDef("fdDustSize", "Dust Size", 0, 6, 1, 2),
            PropDef("fdDustOp", "Dust Opacity", 0, 1, 0.8, 2),
            PropDef("fdDustVary", "Vary Dust Size", 0, 2, 0.5, 2),
            PropDef("fdHairs", "Hairs", 0, 12, 2, 0),
            PropDef("fdHairPers", "Hair Persistence", 0.1, 20, 3, 2),
            PropDef("fdHairWig", "Hair Wiggle Amp", 0, 2, 0.1, 2),
            PropDef("fdHairOp", "Hair Opacity", 0, 1, 1, 2),
            PropDef("fdHairSize", "Hair Size", 0, 4, 1, 2),
            PropDef("fdScr", "Scratches", 0, 16, 5, 0),
            PropDef("fdScrBlack", "Black Scratches", 0, 1, 1, 2),
            PropDef("fdScrWhite", "White Scratches", 0, 1, 0.1, 2),
            PropDef("fdScrLen", "Scratch Length (frames)", 1, 60, 10, 0),
            PropDef("fdScrW", "Scratch Width", 0, 4, 0.15, 3),
            PropDef("fdScrOp", "Scratch Opacity", 0, 1, 1, 2),
            PropDef("fdScrGaps", "Gaps", 0, 1, 0.28, 2),
            PropDef("fdScrCtr", "Scratch Area Center", -1, 1, 0, 2),
            PropDef("fdScrArea", "Scratch Area Width", 0, 1, 1, 2),
            PropDef("fdScrWeave", "Weave Amount", 0, 3, 1, 2),
            PropDef("fdShake", "Shake Amplitude", 0, 4, 0, 2),
            PropDef("fdShakeJump", "Shake Jumpiness", 0, 4, 1, 2),
            PropDef("fdShakeAlways", "Shake Always", 0, 1, 0.5, 2),
            PropDef("fdBar", "Interframe Border Height", 0, 1, 0.1, 2),
            PropDef("fdVig", "Vignette Darkness", 0, 1, 0.1, 2),
            PropDef("fdVigRad", "Vignette Radius", 0, 3, 1, 2),
            PropDef("fdVigSoft", "Vignette Edge Softness", 0, 2, 0.5, 2),
            PropDef("fdFlick", "Flicker", 0, 3, 0.2, 2),
            PropDef("fdFlickFreq", "Flicker Rand Freq", 0, 60, 10, 1),
            PropDef("fdFlickWave", "Flicker Wave Amp", 0, 2, 0, 2),
            PropDef("fdFlickWaveF", "Flicker Wave Freq", 0, 30, 5, 1),
            PropDef("fdDefocus", "Defocus", 0, 8, 0, 2),
            PropDef("fdDefWave", "Defocus Wave Amp", 0, 2, 0, 2),
            PropDef("fdSeed", "Seed", 0, 100, 0.123, 3),
        ], colors: [
            ColorParam("fdTintL", "Tint Lights", Int32(bitPattern: 0xFFFFFFFF)),
            ColorParam("fdTintD", "Tint Darks", Int32(bitPattern: 0xFF000000)),
            ColorParam("fdStainC1", "Stain Color1", Int32(bitPattern: 0xFF000000)),
            ColorParam("fdStainC2", "Stain Color2", Int32(bitPattern: 0xFF402000)),
            ColorParam("fdDustC", "Dust Color", Int32(bitPattern: 0xFF000000)),
            ColorParam("fdHairC", "Hair Color", Int32(bitPattern: 0xFF000000)),
        ], glsl: """
    vec2 asp = vec2(uRes.x / uRes.y, 1.0);
    float fps = 24.0;
    float fr = floor(uTime * fps + 0.5);
    float sd = fdSeed * 13.7;

    // ---- shake: jumpy vertical hops + the black bar between frames
    vec2 suv = uv;
    float bar = 0.0;
    if (fdShake > 0.0001) {
        float on = step(hash11(floor(uTime * 3.0) + sd), fdShakeAlways);
        float hop = (hash11(fr * 1.7 + sd) - 0.5) * 2.0 * fdShakeJump + (hash11(fr * 3.1 + sd + 5.0) - 0.5) * 0.4;
        float off = hop * fdShake * 0.04 * on;
        suv.y += off;
        float bw = max(abs(off) * fdBar * 8.0, 0.0005);
        bar = (1.0 - smoothstep(0.0, bw, abs(suv.y - 1.0))) * step(0.001, abs(off)) * step(0.0001, fdBar);
    }

    // ---- defocus (random + wave over time) as a 9-tap blur
    float dfa = fdDefocus * (hash11(floor(uTime * 10.0) + sd) + fdDefWave * sin(uTime * 6.2832 * 1.3)) ;
    vec4 c;
    if (dfa > 0.01) {
        vec4 acc = vec4(0.0);
        for (int i = 0; i < 9; i++) {
            vec2 o = vec2(float(i - (i / 3) * 3) - 1.0, float(i / 3) - 1.0);
            acc += src(suv + o * dfa * 2.0 / uRes);
        }
        c = acc / 9.0;
    } else {
        c = src(suv);
    }
    vec3 rgb = c.rgb;
    float a0 = max(c.a, 0.0001);
    rgb /= a0;

    // ---- colour correct
    float lum = luma(rgb);
    rgb = mix(vec3(lum), rgb, fdSat);
    rgb = rgb * fdScale * fdTintL.rgb + fdTintD.rgb * (1.0 - lum) + fdOffD * (1.0 - lum);

    // ---- flicker
    float fl = (hash11(floor(uTime * fdFlickFreq) + sd + 9.0) - 0.5) * 2.0 + fdFlickWave * sin(uTime * 6.2832 * fdFlickWaveF);
    rgb *= 1.0 + fdFlick * 0.5 * fl;

    // ---- grain (new pattern every frame; Grain Blur makes it coarser)
    if (fdGrain > 0.0001) {
        vec2 gp = floor(uv * uRes / (1.0 + fdGBlur * 2.0));
        float gr = hash21(gp + fr * vec2(7.13, 3.77) + sd);
        float gg = fdGMono > 0.5 ? gr : hash21(gp + fr * vec2(5.31, 9.17) + sd + 11.0);
        float gb = fdGMono > 0.5 ? gr : hash21(gp + fr * vec2(2.71, 6.43) + sd + 23.0);
        float lw = mix(fdGDark, 1.0, smoothstep(0.0, 0.5, lum));
        lw = mix(lw, fdGBright, smoothstep(0.6, 1.0, lum));
        rgb += (vec3(gr, gg, gb) - 0.5) * fdGrain * 0.5 * lw * vec3(fdGR, fdGG, fdGB);
    }

    vec2 p = vec2(uv.x * asp.x, uv.y);
    float aspX = asp.x;

    // ---- stains (large soft blotches)
    if (fdStain > 0.0001) {
        for (int j = 0; j < 9; j++) {
            vec2 cell = floor(uv * 3.0) + vec2(float(j - (j / 3) * 3) - 1.0, float(j / 3) - 1.0);
            float h = hash21(cell + fr * 0.0 + floor(uTime * 0.7) * 3.1 + sd);
            if (h < fdStain / 9.0) {
                vec2 ctr = (cell + vec2(hash21(cell + 1.3 + sd), hash21(cell + 4.7 + sd))) / 3.0;
                vec2 dd = (uv - ctr) * asp;
                float r = (0.05 + 0.08 * hash21(cell + 8.1)) * fdStainSize;
                float n = vnoise(dd * 40.0 + cell) * 0.35;
                float m = (1.0 - smoothstep(r * 0.2, r * (1.0 + n), length(dd))) * fdStainOp * (0.5 + 0.5 * hash21(cell + 2.2));
                vec3 sc = mix(fdStainC1.rgb, fdStainC2.rgb, hash21(cell + 6.6));
                rgb = mix(rgb, sc, m);
            }
        }
    }

    // ---- dust specks (cell grid: each cell may hold one speck this frame)
    if (fdDust > 0.0001) {
        float G = 28.0;
        for (int j = 0; j < 9; j++) {
            vec2 cell = floor(uv * vec2(G * asp.x, G)) + vec2(float(j - (j / 3) * 3) - 1.0, float(j / 3) - 1.0);
            float h = hash21(cell + fr * vec2(1.7, 4.1) + sd);
            if (h < fdDust / (G * G * asp.x)) {
                vec2 ctr = (cell + vec2(hash21(cell + fr + 3.3), hash21(cell + fr + 7.7))) / vec2(G * asp.x, G);
                vec2 dd = (uv - ctr) * asp;
                float r = 0.0035 * fdDustSize * (1.0 + (hash21(cell + 2.9 + fr) - 0.5) * 2.0 * fdDustVary);
                float n = vnoise(dd * 600.0 + cell) * 0.6;
                float m = (1.0 - smoothstep(r * 0.3, r * (1.0 + n), length(dd))) * fdDustOp;
                rgb = mix(rgb, fdDustC.rgb, m);
            }
        }
    }

    // ---- hairs: wiggling curved strands that persist for a while
    for (int i = 0; i < 12; i++) {
        if (float(i) < fdHairs) {
            float id = floor(uTime / fdHairPers + float(i) * 0.37);
            float hs = hash21(vec2(id, float(i)) + sd);
            vec2 base = vec2(hash21(vec2(id, float(i) + 3.0)), hash21(vec2(id, float(i) + 7.0))) ;
            float ang = (hash21(vec2(id, float(i) + 11.0)) - 0.5) * 3.0;
            vec2 dir = vec2(cos(ang), sin(ang));
            vec2 nrm = vec2(-dir.y, dir.x);
            vec2 rel = (uv - base) * asp;
            float t = dot(rel, dir);
            float L = (0.08 + 0.1 * hs) * fdHairSize;
            float wig = sin(t * 30.0 + uTime * 6.0 + hs * 20.0) * fdHairWig * 0.01 + (t * t) * (hs - 0.5) * 3.0;
            float dist = abs(dot(rel, nrm) - wig);
            float m = (1.0 - smoothstep(0.0003, 0.0016 * fdHairSize, dist)) * step(0.0, t) * step(t, L) * fdHairOp;
            rgb = mix(rgb, fdHairC.rgb, m);
        }
    }

    // ---- scratches: vertical, weaving, tapered, with gaps; black and white
    for (int i = 0; i < 16; i++) {
        if (float(i) < fdScr) {
            float sid = floor((fr + float(i) * 7.0) / fdScrLen);
            float h1 = hash21(vec2(sid, float(i)) + sd);
            float h2 = hash21(vec2(sid, float(i) + 5.0) + sd);
            float isBlack = step(h2, fdScrBlack / max(fdScrBlack + fdScrWhite, 0.0001));
            float cnt = isBlack > 0.5 ? fdScrBlack : fdScrWhite;
            if (cnt > 0.001) {
                float xs = 0.5 + fdScrCtr * 0.5 + (h1 - 0.5) * fdScrArea;
                xs += sin(uTime * 0.6 * 6.2832 * (0.5 + h2) + h1 * 9.0) * 0.05 * fdScrWeave;
                float y0 = hash21(vec2(sid, float(i) + 9.0)) * 0.5;
                float y1 = y0 + 0.35 + 0.65 * hash21(vec2(sid, float(i) + 13.0));
                float ty = (uv.y - y0) / max(y1 - y0, 0.001);
                float taper = smoothstep(0.0, 0.15, ty) * (1.0 - smoothstep(0.85, 1.0, ty)) * step(0.0, ty) * step(ty, 1.0);
                float w = fdScrW / uRes.y * (1.0 + h2 * 3.0) * 1.5 + 0.0004;
                float rough = (vnoise(vec2(uv.y * 150.0, sid + float(i))) - 0.5) * w * 1.2;
                float dx = abs(uv.x - xs - rough) * asp.x;
                float gap = step(fdScrGaps, vnoise(vec2(uv.y * 40.0, sid * 3.0 + float(i))));
                float m = (1.0 - smoothstep(w * 0.2, w, dx)) * taper * gap * fdScrOp;
                rgb = mix(rgb, vec3(isBlack > 0.5 ? 0.0 : 1.0), m);
            }
        }
    }

    // ---- vignette
    vec2 vd = (uv - 0.5) * vec2(1.0, 0.75) * 2.0;
    float v = smoothstep(fdVigRad - fdVigSoft * 0.5, fdVigRad + fdVigSoft, length(vd));
    rgb *= 1.0 - fdVig * v;
    rgb *= 1.0 - bar;
    rgb = max(rgb, 0.0);
    return vec4(rgb * a0, c.a);
"""))
    return out
}
