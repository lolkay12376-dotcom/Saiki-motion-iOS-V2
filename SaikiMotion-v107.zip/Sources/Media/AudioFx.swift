// AudioFx.swift — per-audio-layer effect chain: model, parameter defs, offline DSP and render cache.
//
// Effects: Flanger, Chorus, Modulator, Phaser, Panning, Reverb, Muffle, Tone, Equalizer.
// Every effect except Panning and Equalizer has a Blend (dry/wet) control.
// The chain is rendered offline (streaming, chunked) into a cached stereo WAV that the preview player and the
// exporter both use, so what you hear while editing is exactly what is rendered.

import Foundation
import AVFoundation

struct AudioFxItem {
    var type: String
    var on = true
    var blend: Float = 0.5
    var p: [String: Float] = [:]

    init(type: String) {
        self.type = type
        blend = AFxDefs.defaultBlend(type)
        for d in AFxDefs.params(type) { p[d.key] = d.def }
    }
    func v(_ k: String) -> Float { p[k] ?? AFxDefs.params(type).first(where: { $0.key == k })?.def ?? 0 }

    func toJson() -> JObj {
        let o = JObj().put("type", type).put("on", on).put("blend", Double(blend))
        let po = JObj()
        for (k, v) in p.sorted(by: { $0.key < $1.key }) { po.put(k, Double(v)) }
        o.put("p", po)
        return o
    }
    static func fromJson(_ o: JObj) -> AudioFxItem {
        var it = AudioFxItem(type: o.optString("type"))
        it.on = o.optBool("on", true)
        it.blend = o.optFloat("blend", it.blend)
        if let po = o.optJSONObject("p") { for k in po.keys { it.p[k] = po.optFloat(k) } }
        return it
    }
}

struct AFxParam {
    let key: String, label: String, lo: Float, hi: Float, def: Float, dec: Int
    var options: [String]? = nil
    init(_ key: String, _ label: String, _ lo: Float, _ hi: Float, _ def: Float, _ dec: Int = 2, _ options: [String]? = nil) {
        self.key = key; self.label = label; self.lo = lo; self.hi = hi; self.def = def; self.dec = dec; self.options = options
    }
}

enum AFxDefs {
    static let types: [(id: String, name: String)] = [
        ("flanger", "Flanger"), ("chorus", "Chorus"), ("modulator", "Modulator"), ("phaser", "Phaser"),
        ("pan", "Panning"), ("reverb", "Reverb"), ("muffle", "Muffle"), ("tone", "Tone"), ("eq", "Equalizer"),
    ]
    static func name(_ id: String) -> String { types.first(where: { $0.id == id })?.name ?? id }
    static func hasBlend(_ t: String) -> Bool { t != "pan" && t != "eq" }
    static func defaultBlend(_ t: String) -> Float {
        switch t { case "reverb": return 0.3; case "muffle", "tone", "modulator": return 1; default: return 0.5 }
    }

    // Equalizer: 5 bands — low shelf, 3 peaking, high shelf
    static let eqDefaultFreq: [Float] = [80, 300, 1000, 3500, 10000]
    static let eqNames = ["Low", "Low-mid", "Mid", "High-mid", "High"]

    static func params(_ t: String) -> [AFxParam] {
        switch t {
        case "flanger": return [AFxParam("rate", "Rate (Hz)", 0.05, 5, 0.3), AFxParam("depth", "Depth (ms)", 0.1, 5, 2),
                                AFxParam("delay", "Delay (ms)", 0.5, 10, 2), AFxParam("fb", "Feedback", -0.95, 0.95, 0.5)]
        case "chorus": return [AFxParam("rate", "Rate (Hz)", 0.1, 8, 1.2), AFxParam("depth", "Depth (ms)", 0, 15, 5),
                               AFxParam("delay", "Delay (ms)", 5, 40, 20, 1), AFxParam("voices", "Voices", 1, 4, 3, 0)]
        case "modulator": return [AFxParam("wave", "Wave", 0, 3, 0, 0, ["Sine", "Triangle", "Square", "Saw"]),
                                  AFxParam("mode", "Mode", 0, 1, 0, 0, ["Ring", "Tremolo"]),
                                  AFxParam("freq", "Frequency (Hz)", 0.5, 2000, 30, 1), AFxParam("depth", "Depth", 0, 1, 1)]
        case "phaser": return [AFxParam("rate", "Rate (Hz)", 0.05, 5, 0.5), AFxParam("depth", "Depth", 0, 1, 0.8),
                               AFxParam("stages", "Stages", 2, 12, 4, 0), AFxParam("freq", "Center (Hz)", 200, 4000, 1000, 0),
                               AFxParam("fb", "Feedback", -0.9, 0.9, 0.4)]
        case "pan": return [AFxParam("pan", "Pan (L ← → R)", -1, 1, 0), AFxParam("rate", "Auto-pan rate (Hz)", 0, 5, 0, 2),
                            AFxParam("depth", "Auto-pan depth", 0, 1, 0.5)]
        case "reverb": return [AFxParam("room", "Room size", 0, 1, 0.6), AFxParam("damp", "Damping", 0, 1, 0.5),
                               AFxParam("width", "Width", 0, 1, 1), AFxParam("pre", "Pre-delay (ms)", 0, 150, 15, 0)]
        case "muffle": return [AFxParam("cut", "Cutoff (Hz)", 100, 8000, 800, 0), AFxParam("res", "Resonance", 0.5, 3, 0.7),
                               AFxParam("slope", "Slope", 0, 1, 1, 0, ["12 dB", "24 dB"])]
        case "tone": return [AFxParam("tone", "Tone (dark ← → bright)", -1, 1, 0), AFxParam("pivot", "Pivot (Hz)", 200, 4000, 1000, 0),
                             AFxParam("level", "Output (dB)", -12, 12, 0, 1)]
        case "eq":
            var a: [AFxParam] = []
            for i in 0..<5 {
                a.append(AFxParam("f\(i)", "\(eqNames[i]) freq", 20, 20000, eqDefaultFreq[i], 0))
                a.append(AFxParam("g\(i)", "\(eqNames[i]) gain (dB)", -18, 18, 0, 1))
                a.append(AFxParam("q\(i)", "\(eqNames[i]) Q", 0.3, 8, 1, 2))
            }
            a.append(AFxParam("out", "Output (dB)", -12, 12, 0, 1))
            return a
        default: return []
        }
    }
}

// MARK: - DSP primitives

struct Biquad {
    var b0: Float = 1, b1: Float = 0, b2: Float = 0, a1: Float = 0, a2: Float = 0
    var x1: Float = 0, x2: Float = 0, y1: Float = 0, y2: Float = 0

    enum Kind { case lowpass, lowShelf, highShelf, peak }

    init() {}
    init(_ k: Kind, f: Float, q: Float, gainDb: Float, sr: Float) { set(k, f: f, q: q, gainDb: gainDb, sr: sr) }

    mutating func set(_ k: Kind, f fin: Float, q qin: Float, gainDb: Float, sr: Float) {
        let f = min(max(fin, 10), sr * 0.45), q = max(qin, 0.1)
        let w = 2 * Float.pi * f / sr, cw = cos(w), sw = sin(w)
        let A = pow(10, gainDb / 40), al = sw / (2 * q)
        var nb0: Float = 1, nb1: Float = 0, nb2: Float = 0, a0: Float = 1, na1: Float = 0, na2: Float = 0
        switch k {
        case .lowpass:
            nb0 = (1 - cw) / 2; nb1 = 1 - cw; nb2 = (1 - cw) / 2
            a0 = 1 + al; na1 = -2 * cw; na2 = 1 - al
        case .peak:
            nb0 = 1 + al * A; nb1 = -2 * cw; nb2 = 1 - al * A
            a0 = 1 + al / A; na1 = -2 * cw; na2 = 1 - al / A
        case .lowShelf:
            let s = 2 * sqrt(A) * al
            nb0 = A * ((A + 1) - (A - 1) * cw + s); nb1 = 2 * A * ((A - 1) - (A + 1) * cw); nb2 = A * ((A + 1) - (A - 1) * cw - s)
            a0 = (A + 1) + (A - 1) * cw + s; na1 = -2 * ((A - 1) + (A + 1) * cw); na2 = (A + 1) + (A - 1) * cw - s
        case .highShelf:
            let s = 2 * sqrt(A) * al
            nb0 = A * ((A + 1) + (A - 1) * cw + s); nb1 = -2 * A * ((A - 1) + (A + 1) * cw); nb2 = A * ((A + 1) + (A - 1) * cw - s)
            a0 = (A + 1) - (A - 1) * cw + s; na1 = 2 * ((A - 1) - (A + 1) * cw); na2 = (A + 1) - (A - 1) * cw - s
        }
        b0 = nb0 / a0; b1 = nb1 / a0; b2 = nb2 / a0; a1 = na1 / a0; a2 = na2 / a0
    }

    @inline(__always) mutating func tick(_ x: Float) -> Float {
        let y = b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
        x2 = x1; x1 = x; y2 = y1; y1 = y
        return y
    }

    /// Magnitude response in dB at `f` (used by the Equalizer graph).
    func magnitudeDb(_ f: Float, sr: Float) -> Float {
        let w = 2 * Float.pi * f / sr
        let c1 = cos(w), s1 = sin(w), c2 = cos(2 * w), s2 = sin(2 * w)
        let nr = b0 + b1 * c1 + b2 * c2, ni = -(b1 * s1 + b2 * s2)
        let dr = 1 + a1 * c1 + a2 * c2, di = -(a1 * s1 + a2 * s2)
        let n = nr * nr + ni * ni, d = max(dr * dr + di * di, 1e-12)
        return 10 * log10(max(n / d, 1e-12))
    }
}

/// Circular delay line with linear-interpolated reads.
struct DelayLine {
    var buf: [Float]
    var w = 0
    init(maxSamples: Int) { buf = [Float](repeating: 0, count: max(4, maxSamples + 4)) }
    @inline(__always) mutating func write(_ x: Float) { buf[w] = x; w += 1; if w >= buf.count { w = 0 } }
    @inline(__always) func read(_ d: Float) -> Float {
        var p = Float(w) - d
        let n = Float(buf.count)
        while p < 0 { p += n }
        let i = Int(p), fr = p - Float(i)
        let a = buf[i % buf.count], b = buf[(i + 1) % buf.count]
        return a + (b - a) * fr
    }
}

@inline(__always) private func lfo(_ ph: Float, _ wave: Int) -> Float {   // −1…1
    switch wave {
    case 1: return ph < 0.5 ? 4 * ph - 1 : 3 - 4 * ph
    case 2: return ph < 0.5 ? 1 : -1
    case 3: return 2 * ph - 1
    default: return sin(2 * Float.pi * ph)
    }
}

// MARK: - effect processors (always stereo, in place)

protocol AFxProc: AnyObject {
    func process(_ l: UnsafeMutablePointer<Float>, _ r: UnsafeMutablePointer<Float>, _ n: Int)
}

/// Wraps a processor with dry/wet blending.
final class AFxBlend: AFxProc {
    let inner: AFxProc, mix: Float
    var dl: [Float] = [], dr: [Float] = []
    init(_ i: AFxProc, _ m: Float) { inner = i; mix = min(max(m, 0), 1) }
    func process(_ l: UnsafeMutablePointer<Float>, _ r: UnsafeMutablePointer<Float>, _ n: Int) {
        if mix >= 0.999 { inner.process(l, r, n); return }
        if dl.count < n { dl = [Float](repeating: 0, count: n); dr = dl }
        for i in 0..<n { dl[i] = l[i]; dr[i] = r[i] }
        inner.process(l, r, n)
        let d = 1 - mix
        for i in 0..<n { l[i] = dl[i] * d + l[i] * mix; r[i] = dr[i] * d + r[i] * mix }
    }
}

final class AFxFlanger: AFxProc {
    var dL: DelayLine, dR: DelayLine
    let sr: Float, rate: Float, depth: Float, delay: Float, fb: Float
    var ph: Float = 0, fL: Float = 0, fR: Float = 0
    init(_ it: AudioFxItem, _ sr: Float) {
        self.sr = sr; rate = it.v("rate"); depth = it.v("depth"); delay = it.v("delay"); fb = it.v("fb")
        let m = Int((it.v("delay") + it.v("depth") + 2) * 0.001 * sr) + 8
        dL = DelayLine(maxSamples: m); dR = DelayLine(maxSamples: m)
    }
    func process(_ l: UnsafeMutablePointer<Float>, _ r: UnsafeMutablePointer<Float>, _ n: Int) {
        let inc = rate / sr, ms = 0.001 * sr
        for i in 0..<n {
            let a = (sin(2 * Float.pi * ph) * 0.5 + 0.5), b = (sin(2 * Float.pi * (ph + 0.25)) * 0.5 + 0.5)   // R is 90° out
            let tl = max(1, (delay + depth * a) * ms), tr = max(1, (delay + depth * b) * ms)
            dL.write(l[i] + fL * fb); dR.write(r[i] + fR * fb)
            fL = dL.read(tl); fR = dR.read(tr)
            l[i] = (l[i] + fL) * 0.7071; r[i] = (r[i] + fR) * 0.7071
            ph += inc; if ph >= 1 { ph -= 1 }
        }
    }
}

final class AFxChorus: AFxProc {
    var dL: DelayLine, dR: DelayLine
    let sr: Float, rate: Float, depth: Float, delay: Float, voices: Int
    var ph: Float = 0
    init(_ it: AudioFxItem, _ sr: Float) {
        self.sr = sr; rate = it.v("rate"); depth = it.v("depth"); delay = it.v("delay"); voices = max(1, min(4, Int(it.v("voices").rounded())))
        let m = Int((it.v("delay") + it.v("depth") + 2) * 0.001 * sr) + 8
        dL = DelayLine(maxSamples: m); dR = DelayLine(maxSamples: m)
    }
    func process(_ l: UnsafeMutablePointer<Float>, _ r: UnsafeMutablePointer<Float>, _ n: Int) {
        let inc = rate / sr, ms = 0.001 * sr, g = 1 / Float(voices + 1)
        for i in 0..<n {
            dL.write(l[i]); dR.write(r[i])
            var sl = l[i], sR = r[i]
            for v in 0..<voices {
                let o = Float(v) / Float(voices)
                let m = sin(2 * Float.pi * (ph + o)) * 0.5 + 0.5
                let d = max(1, (delay * (1 + 0.15 * Float(v)) + depth * m) * ms)
                let pan = voices == 1 ? 0.5 : Float(v) / Float(voices - 1)       // spread voices across the stereo field
                sl += dL.read(d) * (1 - pan) * 1.4; sR += dR.read(d) * pan * 1.4
                if voices == 1 { sl += dL.read(d) * 0.2; sR += dR.read(d) * 0.2 }
            }
            l[i] = sl * g * 1.2; r[i] = sR * g * 1.2
            ph += inc; if ph >= 1 { ph -= 1 }
        }
    }
}

final class AFxModulator: AFxProc {
    let sr: Float, freq: Float, depth: Float, wave: Int, mode: Int
    var ph: Float = 0
    init(_ it: AudioFxItem, _ sr: Float) {
        self.sr = sr; freq = it.v("freq"); depth = it.v("depth"); wave = Int(it.v("wave").rounded()); mode = Int(it.v("mode").rounded())
    }
    func process(_ l: UnsafeMutablePointer<Float>, _ r: UnsafeMutablePointer<Float>, _ n: Int) {
        let inc = freq / sr
        for i in 0..<n {
            let m = lfo(ph, wave)
            // Ring: x·m blended by depth. Tremolo: gain swings between 1−depth and 1.
            let g = mode == 0 ? (1 - depth) + depth * m : 1 - depth * (0.5 - 0.5 * m)
            l[i] *= g; r[i] *= g
            ph += inc; if ph >= 1 { ph -= floor(ph) }
        }
    }
}

final class AFxPhaser: AFxProc {
    let sr: Float, rate: Float, depth: Float, stages: Int, freq: Float, fb: Float
    var zL: [Float], zR: [Float]
    var ph: Float = 0, fL: Float = 0, fR: Float = 0
    init(_ it: AudioFxItem, _ sr: Float) {
        self.sr = sr; rate = it.v("rate"); depth = it.v("depth"); freq = it.v("freq"); fb = it.v("fb")
        let st = max(2, min(12, Int(it.v("stages").rounded())))
        stages = st
        zL = [Float](repeating: 0, count: st); zR = zL
    }
    @inline(__always) private func ap(_ x: Float, _ a: Float, _ z: inout Float) -> Float {
        let y = -a * x + z; z = x + a * y; return y
    }
    func process(_ l: UnsafeMutablePointer<Float>, _ r: UnsafeMutablePointer<Float>, _ n: Int) {
        let inc = rate / sr
        for i in 0..<n {
            let m = sin(2 * Float.pi * ph) * 0.5 + 0.5
            let f = min(sr * 0.45, max(30, freq * pow(2, (m - 0.5) * 2 * 2.5 * depth)))    // sweep up to ±2.5 octaves
            let t = tan(Float.pi * f / sr), a = (t - 1) / (t + 1)
            var xl = l[i] + fL * fb, xr = r[i] + fR * fb
            for s in 0..<stages { xl = ap(xl, a, &zL[s]); xr = ap(xr, a, &zR[s]) }
            fL = xl; fR = xr
            l[i] = (l[i] + xl) * 0.5 * 1.2; r[i] = (r[i] + xr) * 0.5 * 1.2
            ph += inc; if ph >= 1 { ph -= 1 }
        }
    }
}

final class AFxPan: AFxProc {
    let sr: Float, pan: Float, rate: Float, depth: Float
    var ph: Float = 0
    init(_ it: AudioFxItem, _ sr: Float) { self.sr = sr; pan = it.v("pan"); rate = it.v("rate"); depth = it.v("depth") }
    func process(_ l: UnsafeMutablePointer<Float>, _ r: UnsafeMutablePointer<Float>, _ n: Int) {
        let inc = rate / sr
        for i in 0..<n {
            var p = pan
            if rate > 0 { p += depth * sin(2 * Float.pi * ph); ph += inc; if ph >= 1 { ph -= 1 } }
            p = min(max(p, -1), 1)
            let a = (p + 1) * 0.25 * Float.pi                    // constant-power law, centre = −3 dB each side → ×√2 restores unity
            let gl = cos(a) * 1.41421356, gr = sin(a) * 1.41421356
            l[i] *= min(gl, 1); r[i] *= min(gr, 1)
        }
    }
}

final class AFxReverb: AFxProc {
    // Freeverb (8 combs + 4 allpasses per channel)
    private static let combT = [1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617]
    private static let apT = [556, 441, 341, 225]
    struct Comb { var b: [Float]; var i = 0; var s: Float = 0 }
    var cl: [Comb], cr: [Comb], al: [Comb], ar: [Comb]
    let fbk: Float, damp: Float, width: Float
    var pre: DelayLine, preR: DelayLine
    let preS: Float
    init(_ it: AudioFxItem, _ sr: Float) {
        let k = sr / 44100, spread = 23
        func mk(_ t: Int) -> Comb { Comb(b: [Float](repeating: 0, count: max(8, Int(Float(t) * k)))) }
        cl = Self.combT.map(mk); cr = Self.combT.map { mk($0 + spread) }
        al = Self.apT.map(mk); ar = Self.apT.map { mk($0 + spread) }
        fbk = it.v("room") * 0.28 + 0.7; damp = it.v("damp") * 0.4; width = it.v("width")
        let ps = it.v("pre") * 0.001 * sr
        preS = ps
        let dlp = DelayLine(maxSamples: Int(ps) + 8)
        pre = dlp; preR = dlp
    }
    @inline(__always) private func comb(_ c: inout Comb, _ x: Float) -> Float {
        let o = c.b[c.i]
        c.s = o * (1 - damp) + c.s * damp
        c.b[c.i] = x + c.s * fbk
        c.i += 1; if c.i >= c.b.count { c.i = 0 }
        return o
    }
    @inline(__always) private func allp(_ c: inout Comb, _ x: Float) -> Float {
        let o = c.b[c.i], y = o - x
        c.b[c.i] = x + o * 0.5
        c.i += 1; if c.i >= c.b.count { c.i = 0 }
        return y
    }
    func process(_ l: UnsafeMutablePointer<Float>, _ r: UnsafeMutablePointer<Float>, _ n: Int) {
        let w1 = width * 0.5 + 0.5, w2 = (1 - width) * 0.5
        for i in 0..<n {
            pre.write(l[i]); preR.write(r[i])
            let inp = preS > 1 ? (pre.read(preS) + preR.read(preS)) * 0.015 : (l[i] + r[i]) * 0.015
            var sl: Float = 0, sr: Float = 0
            for j in 0..<8 { sl += comb(&cl[j], inp); sr += comb(&cr[j], inp) }
            for j in 0..<4 { sl = allp(&al[j], sl); sr = allp(&ar[j], sr) }
            l[i] = (sl * w1 + sr * w2) * 3; r[i] = (sr * w1 + sl * w2) * 3
        }
    }
}

final class AFxFilterChain: AFxProc {          // Muffle / Tone / Equalizer
    var fl: [Biquad], fr: [Biquad]
    let gain: Float
    init(_ f: [Biquad], gainDb: Float = 0) { fl = f; fr = f; gain = pow(10, gainDb / 20) }
    func process(_ l: UnsafeMutablePointer<Float>, _ r: UnsafeMutablePointer<Float>, _ n: Int) {
        for i in 0..<n {
            var a = l[i], b = r[i]
            for s in 0..<fl.count { a = fl[s].tick(a); b = fr[s].tick(b) }
            l[i] = a * gain; r[i] = b * gain
        }
    }
}

// MARK: - factory + offline rendering

enum AudioFxProc {
    static func eqBands(_ it: AudioFxItem, sr: Float) -> [Biquad] {
        var out: [Biquad] = []
        for i in 0..<5 {
            let g = it.v("g\(i)")
            if abs(g) < 0.05 { continue }
            let k: Biquad.Kind = i == 0 ? .lowShelf : (i == 4 ? .highShelf : .peak)
            out.append(Biquad(k, f: it.v("f\(i)"), q: it.v("q\(i)"), gainDb: g, sr: sr))
        }
        return out
    }

    static func make(_ it: AudioFxItem, sr: Float) -> AFxProc? {
        guard it.on else { return nil }
        let core: AFxProc
        switch it.type {
        case "flanger": core = AFxFlanger(it, sr)
        case "chorus": core = AFxChorus(it, sr)
        case "modulator": core = AFxModulator(it, sr)
        case "phaser": core = AFxPhaser(it, sr)
        case "pan": return AFxPan(it, sr)
        case "reverb": core = AFxReverb(it, sr)
        case "muffle":
            var f = [Biquad(.lowpass, f: it.v("cut"), q: it.v("res"), gainDb: 0, sr: sr)]
            if it.v("slope") > 0.5 { f.append(Biquad(.lowpass, f: it.v("cut"), q: 0.707, gainDb: 0, sr: sr)) }
            core = AFxFilterChain(f)
        case "tone":
            let t = it.v("tone"), p = it.v("pivot")
            core = AFxFilterChain([Biquad(.lowShelf, f: p, q: 0.7, gainDb: -t * 12, sr: sr),
                                   Biquad(.highShelf, f: p, q: 0.7, gainDb: t * 12, sr: sr)], gainDb: it.v("level"))
        case "eq":
            let b = eqBands(it, sr: sr), o = it.v("out")
            if b.isEmpty && abs(o) < 0.05 { return nil }
            return AFxFilterChain(b, gainDb: o)
        default: return nil
        }
        return AFxBlend(core, it.blend)
    }

    /// Chain key for a layer: "" when nothing audible would change.
    static func key(_ chain: [AudioFxItem]) -> String {
        let act = chain.filter { $0.on }
        if act.isEmpty { return "" }
        return act.map { $0.toJson().toString() }.joined(separator: "|")
    }

    private static let lock = NSLock()
    private static var inflight = Set<String>()
    private static var failed = Set<String>()          // sources that could not be rendered (e.g. video without sound): never retried
    private static let queue = DispatchQueue(label: "audiofx", qos: .userInitiated)

    private static func fnv(_ s: String) -> String {
        var h: UInt64 = 0xcbf29ce484222325
        for b in s.utf8 { h = (h ^ UInt64(b)) &* 0x100000001b3 }
        return String(h, radix: 16)
    }

    private static var dirURL: URL {
        let d = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0].appendingPathComponent("AudioFx", isDirectory: true)
        try? FileManager.default.createDirectory(at: d, withIntermediateDirectories: true)
        return d
    }

    private static func cacheURL(_ path: String, _ key: String) -> URL {
        let attrs = (try? FileManager.default.attributesOfItem(atPath: path)) ?? [:]
        let size = (attrs[.size] as? NSNumber)?.int64Value ?? 0
        let mod = (attrs[.modificationDate] as? Date)?.timeIntervalSince1970 ?? 0
        return dirURL.appendingPathComponent(fnv("\((path as NSString).lastPathComponent)|\(size)|\(mod)|" + key) + ".wav")
    }

    /// The rendered file when it already exists.
    static func cachedURL(_ path: String, _ chain: [AudioFxItem]) -> URL? {
        let k = key(chain)
        if k.isEmpty { return nil }
        let u = cacheURL(path, k)
        return FileManager.default.fileExists(atPath: u.path) ? u : nil
    }

    /// Renders in the background (once per distinct chain); `done` runs on the main thread.
    static func prepare(_ path: String, _ chain: [AudioFxItem], done: @escaping () -> Void) {
        let k = key(chain)
        if k.isEmpty { return }
        let u = cacheURL(path, k)
        if FileManager.default.fileExists(atPath: u.path) { return }
        lock.lock()
        if inflight.contains(u.path) || failed.contains(u.path) { lock.unlock(); return }
        inflight.insert(u.path); lock.unlock()
        queue.async {
            let ok = render(path, chain, to: u)
            lock.lock(); inflight.remove(u.path); if !ok { failed.insert(u.path) }; lock.unlock()
            DispatchQueue.main.async { done() }
        }
    }

    /// Blocking version for the exporter: returns the processed file (rendering it if needed) or nil on failure.
    static func renderSync(_ path: String, _ chain: [AudioFxItem]) -> URL? {
        let k = key(chain)
        if k.isEmpty { return nil }
        let u = cacheURL(path, k)
        if FileManager.default.fileExists(atPath: u.path) { return u }
        return render(path, chain, to: u) ? u : nil
    }

    @discardableResult
    private static func render(_ path: String, _ chain: [AudioFxItem], to dst: URL) -> Bool {
        // video files: if the audio engine cannot open the container, pull the sound track out to m4a first
        var fopen = try? AVAudioFile(forReading: URL(fileURLWithPath: path))
        if fopen == nil {
            let tmpA = FileManager.default.temporaryDirectory.appendingPathComponent("fxsrc-\(abs(path.hashValue)).m4a")
            if FileManager.default.fileExists(atPath: tmpA.path) || AudioTools.extractAudio(path, tmpA) {
                fopen = try? AVAudioFile(forReading: tmpA)
            }
        }
        guard let f = fopen else { return false }
        let fmt = f.processingFormat
        let sr = Float(fmt.sampleRate), ch = Int(fmt.channelCount)
        let procs = chain.compactMap { make($0, sr: sr) }
        if procs.isEmpty { return false }
        let tmp = dst.appendingPathExtension("tmp")
        try? FileManager.default.removeItem(at: tmp)
        let settings: [String: Any] = [AVFormatIDKey: kAudioFormatLinearPCM, AVSampleRateKey: fmt.sampleRate, AVNumberOfChannelsKey: 2,
                                       AVLinearPCMBitDepthKey: 16, AVLinearPCMIsFloatKey: false, AVLinearPCMIsBigEndianKey: false]
        guard let out = try? AVAudioFile(forWriting: tmp, settings: settings, commonFormat: .pcmFormatFloat32, interleaved: false),
              let inBuf = AVAudioPCMBuffer(pcmFormat: fmt, frameCapacity: 32768),
              let ofmt = AVAudioFormat(commonFormat: .pcmFormatFloat32, sampleRate: fmt.sampleRate, channels: 2, interleaved: false),
              let outBuf = AVAudioPCMBuffer(pcmFormat: ofmt, frameCapacity: 32768) else { return false }
        // reverb / delay tails: keep feeding silence for 2 s after the file ends so the tail is not cut
        var tailLeft = Int(fmt.sampleRate * 2)
        let hasTail = chain.contains { $0.on && ($0.type == "reverb" || $0.type == "flanger" || $0.type == "chorus") }
        while true {
            inBuf.frameLength = 0
            var n = 0
            if f.framePosition < f.length {
                do { try f.read(into: inBuf, frameCount: 32768) } catch { return false }
                n = Int(inBuf.frameLength)
            }
            if n == 0 {
                if !hasTail || tailLeft <= 0 { break }
                n = min(32768, tailLeft); tailLeft -= n
                for c in 0..<2 { if let p = outBuf.floatChannelData?[c] { for i in 0..<n { p[i] = 0 } } }
            } else if let src = inBuf.floatChannelData, let dstp = outBuf.floatChannelData {
                for i in 0..<n { dstp[0][i] = src[0][i]; dstp[1][i] = src[ch > 1 ? 1 : 0][i] }
            }
            guard let d = outBuf.floatChannelData else { return false }
            for p in procs { p.process(d[0], d[1], n) }
            for c in 0..<2 { for i in 0..<n { d[c][i] = min(1, max(-1, d[c][i])) } }
            outBuf.frameLength = AVAudioFrameCount(n)
            do { try out.write(from: outBuf) } catch { return false }
        }
        try? FileManager.default.removeItem(at: dst)
        do { try FileManager.default.moveItem(at: tmp, to: dst) } catch { return false }
        return true
    }
}
