// EditorAudioFx.swift — "Audio effects" section of the audio layer panel + the custom Equalizer graph.

import UIKit

private enum EqSel { static var band = 2 }

extension EditorViewController {

    /// Audio effects as normal effect rows (handle · name · eye · chevron · more), shown in the Applied tab.
    func buildAudioFxPanel(_ p: UIStackView, _ l: Layer) {
        var rows: [UIView] = [], idxs: [Int] = [], handles: [UIView] = []
        for idx in 0..<l.afx.count {
            let t = l.afx[idx].type
            let key = "\(l.id):afx\(idx)"
            let isOpen = expanded.contains(key)
            let c = vStack()
            let hdr = audioFxHeader(l, idx, key, isOpen)
            handles.append((hdr as? UIStackView)?.arrangedSubviews.first ?? hdr)
            c.addArrangedSubview(hdr)
            if isOpen {
                if t == "eq" {
                    buildEqUi(c, l, idx)
                } else {
                    for d in AFxDefs.params(t) { fxRow(c, l, idx, d) }
                }
                if AFxDefs.hasBlend(t) {
                    let b = RulerSlider(frame: .zero)
                    b.label = "Blend (dry ↔ wet)"; b.lo = 0; b.hi = 1; b.dec = 2; b.value = l.afx[idx].blend
                    b.onBegin = { [weak self] in self?.pushUndo() }
                    b.onChange = { [weak self] v in guard idx < l.afx.count else { return }; l.afx[idx].blend = v; self?.audioFxChanged() }
                    put(c, b, 90)
                }
            }
            let pr = put(p, c, 0, 3, 6)
            rows.append(pr.superview ?? pr); idxs.append(idx)
        }
        if rows.count > 1 {
            for (n, h) in handles.enumerated() {
                let pan = ClosurePan()
                pan.cb = { [weak self] g in
                    self?.dragFx(l, g, n, rows, idxs) { a, b in let e = l.afx.remove(at: a); l.afx.insert(e, at: b); self?.audioFxChanged() }
                }
                h.addGestureRecognizer(pan)
            }
        }
    }

    private func audioFxHeader(_ l: Layer, _ idx: Int, _ key: String, _ isOpen: Bool) -> UIView {
        let bar = hRow()
        bar.backgroundColor = argbToUIColor(C.CARD)
        bar.isLayoutMarginsRelativeArrangement = true
        bar.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 14, bottom: 0, trailing: 2)
        bar.addArrangedSubview(wrap(IconView("handle", C.DIM, 20), 36, 48, 0, 0, 0, 0))
        let t = UILabel()
        t.text = AFxDefs.name(l.afx[idx].type)
        t.textColor = argbToUIColor(C.TEXT)
        t.font = boldFont(16)
        t.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
        bar.addArrangedSubview(t)
        let off = !l.afx[idx].on
        let eye = IconView(off ? "eye_off" : "eye", off ? C.DIM : C.GREEN, 20)
        eye.onClick = { [weak self] in
            guard let self = self, idx < l.afx.count else { return }
            self.pushUndo(); l.afx[idx].on.toggle(); self.audioFxChanged(); self.refreshPanel()
        }
        bar.addArrangedSubview(wrap(eye, 40, 48, 0, 0, 0, 0))
        let chev = IconView(isOpen ? "chev_up" : "chev_down", C.DIM, 20)
        chev.onClick = { [weak self] in
            guard let self = self else { return }
            if self.expanded.contains(key) { self.expanded.remove(key) } else { self.expanded.insert(key) }
            self.refreshPanel()
        }
        bar.addArrangedSubview(wrap(chev, 40, 48, 0, 0, 0, 0))
        let more = IconView("more", C.TEXT, 20)
        more.onClick = { [weak self] in
            guard let self = self else { return }
            Dlg(self).setTitle(AFxDefs.name(l.afx[idx].type)).setIconItems(["Duplicate", "Reset to default", "Remove"], ["dup", "adjust", "trash"]) { [weak self] _, w in
                guard let self = self, idx < l.afx.count else { return }
                self.pushUndo()
                switch w {
                case 0: l.afx.insert(l.afx[idx], at: idx + 1)
                case 1: l.afx[idx] = AudioFxItem(type: l.afx[idx].type)
                default: l.afx.remove(at: idx)
                }
                self.audioFxChanged(); self.refreshPanel()
            }.show()
        }
        bar.addArrangedSubview(wrap(more, 40, 48, 0, 0, 0, 0))
        return bar
    }

    private func fxRow(_ p: UIStackView, _ l: Layer, _ idx: Int, _ d: AFxParam) {
        if let opts = d.options {
            text(p, d.label, C.DIM, 12)
            p.addArrangedSubview(chipRow(opts, Int(l.afx[idx].v(d.key).rounded())) { [weak self] i in
                guard let self = self, idx < l.afx.count else { return }
                self.pushUndo(); l.afx[idx].p[d.key] = Float(i); self.audioFxChanged(); self.refreshPanel()
            })
            return
        }
        let s = RulerSlider(frame: .zero)
        s.label = d.label; s.lo = d.lo; s.hi = d.hi; s.dec = d.dec; s.value = l.afx[idx].v(d.key)
        s.onBegin = { [weak self] in self?.pushUndo() }
        s.onChange = { [weak self] v in guard idx < l.afx.count else { return }; l.afx[idx].p[d.key] = v; self?.audioFxChanged() }
        put(p, s, 90)
    }

    private func buildEqUi(_ p: UIStackView, _ l: Layer, _ idx: Int) {
        let eq = AudioEqView(frame: .zero)
        eq.item = l.afx[idx]
        eq.selected = EqSel.band
        eq.onBegin = { [weak self] in self?.pushUndo() }
        eq.onChange = { [weak self] it in guard idx < l.afx.count else { return }; l.afx[idx] = it; self?.audioFxChanged() }
        eq.onSelect = { [weak self] b in EqSel.band = b; self?.refreshPanel() }
        put(p, eq, 230)
        text(p, "Drag a dot: left/right = frequency, up/down = gain. Tap a dot to pick it, double-tap to flatten it.", C.DIM, 12)
        let b = max(0, min(4, EqSel.band))
        for k in ["q\(b)", "f\(b)", "g\(b)"] {
            if let d = AFxDefs.params("eq").first(where: { $0.key == k }) { fxRow(p, l, idx, d) }
        }
        if let d = AFxDefs.params("eq").first(where: { $0.key == "out" }) { fxRow(p, l, idx, d) }
        put(p, pill("Reset equalizer") { [weak self] in
            guard let self = self, idx < l.afx.count else { return }
            self.pushUndo(); l.afx[idx] = AudioFxItem(type: "eq"); self.audioFxChanged(); self.refreshPanel()
        }, 40)
    }
}

/// Custom equalizer: log-frequency / gain graph with 5 draggable band dots and the live combined response curve.
final class AudioEqView: UIView {
    var item = AudioFxItem(type: "eq") { didSet { setNeedsDisplay() } }
    var selected = 2
    var onBegin: (() -> Void)?
    var onChange: ((AudioFxItem) -> Void)?
    var onSelect: ((Int) -> Void)?

    private var drag = -1
    private let fMin: Float = 20, fMax: Float = 20000, gMax: Float = 18
    private let bandColors: [UIColor] = [.systemRed, .systemOrange, .systemGreen, .systemTeal, .systemPurple]

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        isOpaque = false
        let pan = UIPanGestureRecognizer(target: self, action: #selector(onPan(_:)))
        addGestureRecognizer(pan)
        let dbl = UITapGestureRecognizer(target: self, action: #selector(onDouble(_:)))
        dbl.numberOfTapsRequired = 2
        addGestureRecognizer(dbl)
        let tap = UITapGestureRecognizer(target: self, action: #selector(onTap(_:)))
        tap.require(toFail: dbl)
        addGestureRecognizer(tap)
    }
    required init?(coder: NSCoder) { fatalError() }

    private var plot: CGRect { bounds.insetBy(dx: 10, dy: 14) }
    private func xFor(_ f: Float) -> CGFloat { plot.minX + CGFloat(log(f / fMin) / log(fMax / fMin)) * plot.width }
    private func fFor(_ x: CGFloat) -> Float { fMin * pow(fMax / fMin, Float((x - plot.minX) / plot.width)) }
    private func yFor(_ g: Float) -> CGFloat { plot.midY - CGFloat(g / gMax) * plot.height / 2 }
    private func gFor(_ y: CGFloat) -> Float { Float((plot.midY - y) / (plot.height / 2)) * gMax }

    private func nearest(_ pt: CGPoint) -> Int {
        var best = -1, bd = CGFloat(44 * 44)
        for i in 0..<5 {
            let dx = xFor(item.v("f\(i)")) - pt.x, dy = yFor(item.v("g\(i)")) - pt.y
            let d = dx * dx + dy * dy
            if d < bd { bd = d; best = i }
        }
        return best
    }

    @objc private func onTap(_ g: UITapGestureRecognizer) {
        let i = nearest(g.location(in: self))
        if i >= 0 { selected = i; setNeedsDisplay(); onSelect?(i) }
    }
    @objc private func onDouble(_ g: UITapGestureRecognizer) {
        let i = nearest(g.location(in: self))
        guard i >= 0 else { return }
        onBegin?(); item.p["g\(i)"] = 0; selected = i; onChange?(item); onSelect?(i)
    }
    @objc private func onPan(_ g: UIPanGestureRecognizer) {
        let pt = g.location(in: self)
        switch g.state {
        case .began:
            drag = nearest(pt)
            if drag >= 0 { onBegin?(); selected = drag }
        case .changed:
            guard drag >= 0 else { return }
            item.p["f\(drag)"] = min(fMax, max(fMin, fFor(pt.x)))
            item.p["g\(drag)"] = min(gMax, max(-gMax, gFor(pt.y)))
            onChange?(item)
        case .ended, .cancelled:
            if drag >= 0 { onSelect?(drag) }
            drag = -1
        default: break
        }
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let r = bounds
        c.setFillColor(argbToUIColor(C.CARD2).cgColor)
        UIBezierPath(roundedRect: r, cornerRadius: 12).fill()
        let pl = plot
        // grid
        c.setStrokeColor(UIColor.white.withAlphaComponent(0.10).cgColor); c.setLineWidth(1)
        for f in [50, 100, 200, 500, 1000, 2000, 5000, 10000] as [Float] {
            c.move(to: CGPoint(x: xFor(f), y: pl.minY)); c.addLine(to: CGPoint(x: xFor(f), y: pl.maxY))
        }
        for g in [-12, -6, 6, 12] as [Float] { c.move(to: CGPoint(x: pl.minX, y: yFor(g))); c.addLine(to: CGPoint(x: pl.maxX, y: yFor(g))) }
        c.strokePath()
        c.setStrokeColor(UIColor.white.withAlphaComponent(0.30).cgColor)
        c.move(to: CGPoint(x: pl.minX, y: yFor(0))); c.addLine(to: CGPoint(x: pl.maxX, y: yFor(0))); c.strokePath()
        let lab: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 9), .foregroundColor: UIColor.white.withAlphaComponent(0.45)]
        for (f, s) in [(100, "100"), (1000, "1k"), (10000, "10k")] as [(Float, String)] { (s as NSString).draw(at: CGPoint(x: xFor(f) + 2, y: pl.maxY - 11), withAttributes: lab) }
        for g in [12, 0, -12] as [Float] { ("\(Int(g))" as NSString).draw(at: CGPoint(x: pl.minX + 2, y: yFor(g) - 11), withAttributes: lab) }

        // combined response
        let sr: Float = 44100
        var bq: [Biquad] = []
        for i in 0..<5 {
            let k: Biquad.Kind = i == 0 ? .lowShelf : (i == 4 ? .highShelf : .peak)
            bq.append(Biquad(k, f: item.v("f\(i)"), q: item.v("q\(i)"), gainDb: item.v("g\(i)"), sr: sr))
        }
        let path = UIBezierPath()
        let n = 160
        for s in 0...n {
            let x = pl.minX + pl.width * CGFloat(s) / CGFloat(n)
            var db: Float = item.v("out")
            for b in bq { db += b.magnitudeDb(fFor(x), sr: sr) }
            let pt = CGPoint(x: x, y: min(pl.maxY, max(pl.minY, yFor(db))))
            if s == 0 { path.move(to: pt) } else { path.addLine(to: pt) }
        }
        let fill = path.copy() as! UIBezierPath
        fill.addLine(to: CGPoint(x: pl.maxX, y: yFor(0))); fill.addLine(to: CGPoint(x: pl.minX, y: yFor(0))); fill.close()
        argbToUIColor(C.GREEN).withAlphaComponent(0.18).setFill(); fill.fill()
        argbToUIColor(C.GREEN).setStroke(); path.lineWidth = 2.5; path.lineJoinStyle = .round; path.stroke()

        // band dots
        for i in 0..<5 {
            let p = CGPoint(x: xFor(item.v("f\(i)")), y: yFor(item.v("g\(i)")))
            let rad: CGFloat = i == selected ? 13 : 10
            bandColors[i].withAlphaComponent(i == selected ? 0.35 : 0.2).setFill()
            UIBezierPath(ovalIn: CGRect(x: p.x - rad - 5, y: p.y - rad - 5, width: (rad + 5) * 2, height: (rad + 5) * 2)).fill()
            bandColors[i].setFill()
            UIBezierPath(ovalIn: CGRect(x: p.x - rad, y: p.y - rad, width: rad * 2, height: rad * 2)).fill()
            UIColor.white.setStroke(); let ring = UIBezierPath(ovalIn: CGRect(x: p.x - rad, y: p.y - rad, width: rad * 2, height: rad * 2)); ring.lineWidth = i == selected ? 2.5 : 1.2; ring.stroke()
            ("\(i + 1)" as NSString).draw(at: CGPoint(x: p.x - 3, y: p.y - 6),
                withAttributes: [.font: UIFont.boldSystemFont(ofSize: 11), .foregroundColor: UIColor.white])
        }
        // readout of the selected band
        let b = max(0, min(4, selected))
        let f = item.v("f\(b)"), g = item.v("g\(b)")
        let fs = f >= 1000 ? String(format: "%.2f kHz", f / 1000) : String(format: "%.0f Hz", f)
        let txt = "\(AFxDefs.eqNames[b])  \(fs)  \(String(format: "%+.1f dB", g))  Q \(String(format: "%.2f", item.v("q\(b)")))"
        (txt as NSString).draw(at: CGPoint(x: pl.minX + 6, y: pl.minY - 2),
            withAttributes: [.font: UIFont.boldSystemFont(ofSize: 11), .foregroundColor: UIColor.white.withAlphaComponent(0.85)])
    }
}

/// Browse card for an audio effect (same look as the visual effect cards, with an audio icon instead of a preview).
final class AudioFxCard: TapView {
    var badge = false { didSet { setNeedsLayout() } }
    init(_ name: String) {
        super.init(frame: .zero)
        backgroundColor = argbToUIColor(C.CARD)
        layer.cornerRadius = 14
        clipsToBounds = true
        let ic = IconView("audio", C.GREEN, 48)
        ic.isUserInteractionEnabled = false
        ic.translatesAutoresizingMaskIntoConstraints = false
        addSubview(ic)
        let t = UILabel(); t.text = name; t.textColor = argbToUIColor(C.TEXT); t.font = boldFont(16)
        let c = UILabel(); c.text = "Audio"; c.textColor = argbToUIColor(C.DIM); c.font = sysFont(13)
        let st = UIStackView(arrangedSubviews: [t, c]); st.axis = .vertical; st.spacing = 2
        st.translatesAutoresizingMaskIntoConstraints = false
        addSubview(st)
        NSLayoutConstraint.activate([
            ic.centerXAnchor.constraint(equalTo: centerXAnchor), ic.topAnchor.constraint(equalTo: topAnchor, constant: 26),
            ic.widthAnchor.constraint(equalToConstant: 48), ic.heightAnchor.constraint(equalToConstant: 48),
            st.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16), st.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -12),
            st.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -16),
        ])
    }
    required init?(coder: NSCoder) { fatalError() }
}
