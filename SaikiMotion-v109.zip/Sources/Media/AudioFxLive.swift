// AudioFxLive.swift — real-time playback of audio layers that carry effects.
//
// Each such layer plays through AVAudioEngine:  player node → custom effect Audio Unit → main mixer.
// The Audio Unit runs the same DSP as the exporter (AudioFx.swift), so editing a slider is heard immediately
// and the render sounds identical. Only the effects whose settings changed are rebuilt, so dragging one
// slider never resets the others (reverb tails, LFO phases).

import Foundation
import AVFoundation
import AudioToolbox

final class AFxAudioUnit: AUAudioUnit {
    static let desc = AudioComponentDescription(componentType: kAudioUnitType_Effect, componentSubType: 0x61667863,
                                                componentManufacturer: 0x536B6D6F, componentFlags: 0, componentFlagsMask: 0)
    private static var registered = false
    static func register() {
        if registered { return }
        registered = true
        AUAudioUnit.registerSubclass(AFxAudioUnit.self, as: desc, name: "SaikiMotion: Audio FX", version: 1)
    }

    private var ins: AUAudioUnitBusArray!
    private var outs: AUAudioUnitBusArray!
    private let lock = UnsafeMutablePointer<os_unfair_lock>.allocate(capacity: 1)
    private var procs: [AFxProc] = []
    private var scratch: UnsafeMutablePointer<Float>? = nil
    private var scratchN = 0
    private var keys: [String] = []
    private var rate: Float = 44100

    override init(componentDescription: AudioComponentDescription, options: AudioComponentInstantiationOptions = []) throws {
        lock.initialize(to: os_unfair_lock())
        try super.init(componentDescription: componentDescription, options: options)
        let f = AVAudioFormat(standardFormatWithSampleRate: 44100, channels: 2)!
        ins = AUAudioUnitBusArray(audioUnit: self, busType: .input, busses: [try AUAudioUnitBus(format: f)])
        outs = AUAudioUnitBusArray(audioUnit: self, busType: .output, busses: [try AUAudioUnitBus(format: f)])
        maximumFramesToRender = 4096
    }
    deinit { scratch?.deallocate(); lock.deallocate() }

    override var inputBusses: AUAudioUnitBusArray { ins }
    override var outputBusses: AUAudioUnitBusArray { outs }

    override func allocateRenderResources() throws {
        try super.allocateRenderResources()
        scratchN = Int(maximumFramesToRender) + 64
        scratch = UnsafeMutablePointer<Float>.allocate(capacity: scratchN)
        rate = Float(outs[0].format.sampleRate)
        rebuild(force: true)
    }
    override func deallocateRenderResources() {
        super.deallocateRenderResources()
        scratch?.deallocate(); scratch = nil
    }

    private var chain: [AudioFxItem] = []

    /// Main thread: new settings. Unchanged effects keep their DSP state; changed ones are rebuilt.
    func setChain(_ items: [AudioFxItem], sampleRate: Float) {
        chain = items; rate = sampleRate
        rebuild(force: false)
    }

    private func rebuild(force: Bool) {
        let act = chain.filter { $0.on }
        let newKeys = act.map { $0.toJson().toString() }
        // reuse processors whose settings did not change
        os_unfair_lock_lock(lock)
        let oldKeys = keys, oldProcs = procs
        os_unfair_lock_unlock(lock)
        var np: [AFxProc] = []
        var nk: [String] = []
        for (i, it) in act.enumerated() {
            if !force, let j = oldKeys.firstIndex(of: newKeys[i]), j < oldProcs.count { np.append(oldProcs[j]); nk.append(newKeys[i]); continue }
            if let p = AudioFxProc.make(it, sr: rate) { np.append(p); nk.append(newKeys[i]) }
        }
        os_unfair_lock_lock(lock); procs = np; keys = nk; os_unfair_lock_unlock(lock)
    }

    override var internalRenderBlock: AUInternalRenderBlock {
        return { [unowned self] actionFlags, timestamp, frameCount, _, outputData, _, pull in
            guard let pull = pull else { return kAudioUnitErr_NoConnection }
            let st = pull(actionFlags, timestamp, frameCount, 0, outputData)
            if st != noErr { return st }
            let abl = UnsafeMutableAudioBufferListPointer(outputData)
            guard abl.count >= 1, let l = abl[0].mData?.assumingMemoryBound(to: Float.self) else { return noErr }
            let n = Int(frameCount)
            if os_unfair_lock_trylock(self.lock) {
                let ps = self.procs
                os_unfair_lock_unlock(self.lock)
                if !ps.isEmpty {
                    if abl.count >= 2, let r = abl[1].mData?.assumingMemoryBound(to: Float.self) {
                        for p in ps { p.process(l, r, n) }
                    } else if let sc = self.scratch, n <= self.scratchN {        // mono: process a copy as the right channel
                        for i in 0..<n { sc[i] = l[i] }
                        for p in ps { p.process(l, sc, n) }
                    }
                }
            }
            return noErr
        }
    }
}

/// One engine for every effected layer.
final class AudioFxLive {
    private struct Entry {
        var file: AVAudioFile
        var node: AVAudioPlayerNode
        var unit: AFxAudioUnit
        var av: AVAudioUnit
        var segStart: Double = 0
        var playing = false
        var path: String
    }
    private let engine = AVAudioEngine()
    private var entries: [Int: Entry] = [:]
    private var pending = Set<Int>()
    private var failed = Set<String>()

    func has(_ id: Int) -> Bool { entries[id] != nil }
    /// True while a layer's file is still being opened (play dry-silent for a moment instead of falling back).
    func isPending(_ id: Int) -> Bool { pending.contains(id) }

    /// Creates / updates the chain of a layer. `done` runs on main when a new entry became ready.
    func sync(_ l: Layer, path: String, done: @escaping () -> Void) {
        let id = l.id
        if let e = entries[id], e.path == path { e.unit.setChain(l.afx, sampleRate: Float(e.file.processingFormat.sampleRate)); return }
        if entries[id] != nil { remove(id) }
        if pending.contains(id) || failed.contains(path) { return }
        pending.insert(id)
        let chainCopy = l.afx
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            var f = try? AVAudioFile(forReading: URL(fileURLWithPath: path))
            if f == nil {      // video container: pull the sound out first
                let tmp = FileManager.default.temporaryDirectory.appendingPathComponent("fxsrc-\(abs(path.hashValue)).m4a")
                if FileManager.default.fileExists(atPath: tmp.path) || AudioTools.extractAudio(path, tmp) { f = try? AVAudioFile(forReading: tmp) }
            }
            DispatchQueue.main.async {
                guard let self = self else { return }
                guard let file = f else { self.pending.remove(id); self.failed.insert(path); return }
                AFxAudioUnit.register()
                AVAudioUnit.instantiate(with: AFxAudioUnit.desc, options: []) { av, _ in
                    DispatchQueue.main.async {
                        self.pending.remove(id)
                        guard let av = av, let au = av.auAudioUnit as? AFxAudioUnit else { self.failed.insert(path); return }
                        let node = AVAudioPlayerNode()
                        self.engine.attach(node); self.engine.attach(av)
                        let fmt = file.processingFormat
                        self.engine.connect(node, to: av, format: fmt)
                        self.engine.connect(av, to: self.engine.mainMixerNode, format: fmt)
                        au.setChain(chainCopy, sampleRate: Float(fmt.sampleRate))
                        self.entries[id] = Entry(file: file, node: node, unit: au, av: av, path: path)
                        done()
                    }
                }
            }
        }
    }

    func remove(_ id: Int) {
        guard let e = entries.removeValue(forKey: id) else { return }
        e.node.stop()
        engine.detach(e.node); engine.detach(e.av)
    }

    func prune(keep: Set<Int>) { for id in Array(entries.keys) where !keep.contains(id) { remove(id) } }

    func removeAll() {
        for id in Array(entries.keys) { remove(id) }
        if engine.isRunning { engine.stop() }
    }

    func pauseAll() {
        for (id, var e) in entries where e.playing { e.node.pause(); e.playing = false; entries[id] = e }
    }

    /// Keeps the layer locked to the timeline. `want` = seconds into the source file.
    func tick(_ id: Int, inside: Bool, want: Double, volume: Float, restart: Bool) {
        guard var e = entries[id] else { return }
        e.node.volume = volume
        if inside {
            var drift = 0.0
            if e.playing, let nt = e.node.lastRenderTime, let pt = e.node.playerTime(forNodeTime: nt) {
                drift = abs(e.segStart + Double(pt.sampleTime) / pt.sampleRate - want)
            }
            if !e.playing || restart || drift > 0.14 {
                let sr = e.file.processingFormat.sampleRate
                let start = AVAudioFramePosition(max(0, want) * sr)
                if start < e.file.length {
                    e.node.stop()
                    e.node.scheduleSegment(e.file, startingFrame: start, frameCount: AVAudioFrameCount(e.file.length - start), at: nil, completionHandler: nil)
                    if !engine.isRunning { try? engine.start() }
                    e.node.play()
                    e.segStart = max(0, want); e.playing = true
                }
            }
        } else if e.playing {
            e.node.pause(); e.playing = false
        }
        entries[id] = e
    }
}
