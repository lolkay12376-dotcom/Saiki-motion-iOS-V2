// AudioFx.swift — per-audio-layer effect chain: model, parameter defs, offline DSP and render cache.
//
// Effects: Flanger, Chorus, Modulator, Phaser, Panning, Reverb, Muffle, Tone, Equalizer, Echo, Distortion, Compressor.
// Every parameter can be keyframed (tracks named afx<uid>__<param> on the layer); processors smooth every change.
// Every effect except Panning and Equalizer has a Blend (dry/wet) control.
// The chain is rendered offline (streaming, chunked) into a cached stereo WAV that the preview player and the
// exporter both use, so what you hear while editing is exactly what is rendered.

import Foundation
import AVFoundation

struct AudioFxItem {
    var type: String
    var on = true
    var blend: Float = 0.5
    var p: [String: Float] = [:]
    var uid: Int = AudioFxItem.newUid()        // stable id: keyframe tracks are named afx<uid>__<param>
    private static var nextUid = 1
    static func newUid() -> Int { nextUid += 1; return nextUid }

    init(type: String) {
        self.type = type
        blend = AFxDefs.defaultBlend(type)
        for d in AFxDefs.params(type) { p[d.key] = d.def }
    }
    func v(_ k: String) -> Float { p[k] ?? AFxDefs.params(type).first(where: { $0.key == k })?.def ?? 0 }

    func toJson() -> JObj {
        let o = JObj().put("type", type).put("on", on).put("blend", Double(blend)).put("uid", Int64(uid))
        let po = JObj()
        for (k, v) in p.sorted(by: { $0.key < $1.key }) { po.put(k, Double(v)) }
        o.put("p", po)
        return o
    }
    static func fromJson(_ o: JObj) -> AudioFxItem {
        var it = AudioFxItem(type: o.optString("type"))
        it.on = o.optBool("on", true)
        it.blend = o.optFloat("blend", it.blend)
        let u = o.optInt("uid", 0)
        if u > 0 { it.uid = u; nextUid = max(nextUid, u) }
        if let po = o.optJSONObject("p") { for k in po.keys { it.p[k] = po.optFloat(k) } }
        return it
    }
}

struct AFxParam {
    let key: String, label: String, lo: Float, hi: Float, def: Float, dec: Int
    var options: [String]? = nil
    init(_ key: String, _ label: String, _ lo: Float, _ hi: Float, _ def: Float, _ dec: Int = 2, _ options: [String]? = nil) {
        self.key = key; self.label = label; self.lo = lo; self.hi = hi; self.def = def; self.dec = dec; self.options = options
    }
}

enum AFxDefs {
    static let types: [(id: String, name: String)] = [
        ("flanger", "Flanger"), ("chorus", "Chorus"), ("modulator", "Modulator"), ("phaser", "Phaser"),
        ("pan", "Panning"), ("reverb", "Reverb"), ("muffle", "Muffle"), ("tone", "Tone"), ("eq", "Equalizer"),
        ("echo", "Echo"), ("dist", "Distortion"), ("comp", "Compressor"),
    ]
    static func name(_ id: String) -> String { types.first(where: { $0.id == id })?.name ?? id }
    static func hasBlend(_ t: String) -> Bool { t != "pan" && t != "eq" }
    static func defaultBlend(_ t: String) -> Float {
        switch t { case "reverb": return 0.3; case "echo": return 0.35; case "muffle", "tone", "modulator", "dist", "phaser", "flanger", "chorus", "comp": return 1; default: return 0.5 }
    }

    // Equalizer: 5 bands — low shelf, 3 peaking, high shelf
    static let eqDefaultFreq: [Float] = [80, 300, 1000, 3500, 10000]
    static let eqNames = ["Low", "Low-mid", "Mid", "High-mid", "High"]

    static func params(_ t: String) -> [AFxParam] {
        switch t {
        case "flanger": return [AFxParam("rate", "Rate (Hz)", 0.05, 5, 0.3), AFxParam("depth", "Depth (ms)", 0.1, 5, 2),
                                AFxParam("delay", "Delay (ms)", 0.5, 10, 2), AFxParam("fb", "Feedback", -0.95, 0.95, 0.5)]
        case "chorus": return [AFxParam("rate", "Rate (Hz)", 0.1, 8, 1.2), AFxParam("depth", "Depth (ms)", 0, 15, 5),
                               AFxParam("delay", "Delay (ms)", 5, 40, 20, 1), AFxParam("voices", "Voices", 1, 4, 3, 0)]
        case "modulator": return [AFxParam("wave", "Wave", 0, 3, 0, 0, ["Sine", "Triangle", "Square", "Saw"]),
                                  AFxParam("mode", "Mode", 0, 1, 0, 0, ["Ring", "Tremolo"]),
                                  AFxParam("freq", "Frequency (Hz)", 0.5, 2000, 30, 1), AFxParam("depth", "Depth", 0, 1, 1)]
        case "phaser": return [AFxParam("rate", "Rate (Hz)", 0.05, 5, 0.5), AFxParam("depth", "Depth", 0, 1, 0.8),
                               AFxParam("stages", "Stages", 2, 12, 6, 0), AFxParam("freq", "Center (Hz)", 200, 4000, 1000, 0),
                               AFxParam("fb", "Feedback", -0.9, 0.9, 0.4)]
        case "comp": return [AFxParam("thresh", "Threshold (dB)", -60, 0, -18, 1), AFxParam("ratio", "Ratio", 1, 20, 4, 1),
                             AFxParam("attack", "Attack (ms)", 0.1, 200, 10, 1), AFxParam("release", "Release (ms)", 10, 1000, 150, 0),
                             AFxParam("knee", "Knee (dB)", 0, 24, 6, 1), AFxParam("makeup", "Make-up (dB)", 0, 24, 0, 1)]
        case "pan": return [AFxParam("pan", "Pan (L ← → R)", -1, 1, 0), AFxParam("rate", "Auto-pan rate (Hz)", 0, 5, 0, 2),
                            AFxParam("depth", "Auto-pan depth", 0, 1, 0.5)]
        case "reverb": return [AFxParam("room", "Room size", 0, 1, 0.6), AFxParam("damp", "Damping", 0, 1, 0.5),
                               AFxParam("width", "Width", 0, 1, 1), AFxParam("pre", "Pre-delay (ms)", 0, 150, 15, 0)]
        case "muffle": return [AFxParam("cut", "Cutoff (Hz)", 100, 8000, 800, 0), AFxParam("res", "Resonance", 0.5, 3, 0.7),
                               AFxParam("slope", "Slope", 0, 1, 1, 0, ["12 dB", "24 dB"])]
        case "tone": return [AFxParam("tone", "Tone (dark ← → bright)", -1, 1, 0), AFxParam("pivot", "Pivot (Hz)", 200, 4000, 1000, 0),
                             AFxParam("level", "Output (dB)", -12, 12, 0, 1)]
        case "echo": return [AFxParam("time", "Time (ms)", 20, 1500, 350, 0), AFxParam("fb", "Feedback", 0, 0.95, 0.4),
                             AFxParam("damp", "Damping", 0, 1, 0.3), AFxParam("ping", "Ping-pong", 0, 1, 0, 0, ["Off", "On"])]
        case "dist": return [AFxParam("drive", "Drive (dB)", 0, 40, 12, 1), AFxParam("shape", "Shape", 0, 2, 0, 0, ["Soft", "Hard", "Fold"]),
                             AFxParam("tone", "Tone (Hz)", 500, 16000, 8000, 0), AFxParam("level", "Output (dB)", -24, 6, -6, 1)]
        case "eq":
            var a: [AFxParam] = []
            for i in 0..<5 {
                a.append(AFxParam("f\(i)", "\(eqNames[i]) freq", 20, 20000, eqDefaultFreq[i], 0))
                a.append(AFxParam("g\(i)", "\(eqNames[i]) gain (dB)", -18, 18, 0, 1))
                a.append(AFxParam("q\(i)", "\(eqNames[i]) Q", 0.3, 8, 1, 2))
            }
            a.append(AFxParam("out", "Output (dB)", -12, 12, 0, 1))
            return a
        default: return []
        }
    }
}

// MARK: - DSP primitives

struct Biquad {
    var b0: Float = 1, b1: Float = 0, b2: Float = 0, a1: Float = 0, a2: Float = 0
    var x1: Float = 0, x2: Float = 0, y1: Float = 0, y2: Float = 0

    enum Kind { case lowpass, lowShelf, highShelf, peak }

    init() {}
    init(_ k: Kind, f: Float, q: Float, gainDb: Float, sr: Float) { set(k, f: f, q: q, gainDb: gainDb, sr: sr) }

    mutating func set(_ k: Kind, f fin: Float, q qin: Float, gainDb: Float, sr: Float) {
        let f = min(max(fin, 10), sr * 0.45), q = max(qin, 0.1)
        let w = 2 * Float.pi * f / sr, cw = cos(w), sw = sin(w)
        let A = pow(10, gainDb / 40), al = sw / (2 * q)
        var nb0: Float = 1, nb1: Float = 0, nb2: Float = 0, a0: Float = 1, na1: Float = 0, na2: Float = 0
        switch k {
        case .lowpass:
            nb0 = (1 - cw) / 2; nb1 = 1 - cw; nb2 = (1 - cw) / 2
            a0 = 1 + al; na1 = -2 * cw; na2 = 1 - al
        case .peak:
            nb0 = 1 + al * A; nb1 = -2 * cw; nb2 = 1 - al * A
            a0 = 1 + al / A; na1 = -2 * cw; na2 = 1 - al / A
        case .lowShelf:
            let s = 2 * sqrt(A) * al
            nb0 = A * ((A + 1) - (A - 1) * cw + s); nb1 = 2 * A * ((A - 1) - (A + 1) * cw); nb2 = A * ((A + 1) - (A - 1) * cw - s)
            a0 = (A + 1) + (A - 1) * cw + s; na1 = -2 * ((A - 1) + (A + 1) * cw); na2 = (A + 1) + (A - 1) * cw - s
        case .highShelf:
            let s = 2 * sqrt(A) * al
            nb0 = A * ((A + 1) + (A - 1) * cw + s); nb1 = -2 * A * ((A - 1) + (A + 1) * cw); nb2 = A * ((A + 1) + (A - 1) * cw - s)
            a0 = (A + 1) - (A - 1) * cw + s; na1 = 2 * ((A - 1) - (A + 1) * cw); na2 = (A + 1) - (A - 1) * cw - s
        }
        b0 = nb0 / a0; b1 = nb1 / a0; b2 = nb2 / a0; a1 = na1 / a0; a2 = na2 / a0
    }

    @inline(__always) mutating func tick(_ x: Float) -> Float {
        let y = b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
        x2 = x1; x1 = x; y2 = y1; y1 = y
        return y
    }

    /// Magnitude response in dB at `f` (used by the Equalizer graph).
    func magnitudeDb(_ f: Float, sr: Float) -> Float {
        let w = 2 * Float.pi * f / sr
        let c1 = cos(w), s1 = sin(w), c2 = cos(2 * w), s2 = sin(2 * w)
        let nr = b0 + b1 * c1 + b2 * c2, ni = -(b1 * s1 + b2 * s2)
        let dr = 1 + a1 * c1 + a2 * c2, di = -(a1 * s1 + a2 * s2)
        let n = nr * nr + ni * ni, d = max(dr * dr + di * di, 1e-12)
        return 10 * log10(max(n / d, 1e-12))
    }
}

/// Circular delay line with linear (`read`) and cubic-Hermite (`readCubic`, for modulated delays) reads.
struct DelayLine {
    var buf: [Float]
    var w = 0
    init(maxSamples: Int) { buf = [Float](repeating: 0, count: max(4, maxSamples + 4)) }
    @inline(__always) mutating func write(_ x: Float) { buf[w] = x; w += 1; if w >= buf.count { w = 0 } }
    @inline(__always) func read(_ d: Float) -> Float {
        var p = Float(w) - d
        let n = Float(buf.count)
        while p < 0 { p += n }
        let i = Int(p), fr = p - Float(i)
        let a = buf[i % buf.count], b = buf[(i + 1) % buf.count]
        return a + (b - a) * fr
    }
    /// 4-point Hermite read: far less interpolation grit than linear on swept delays. `d` must be ≥ 3 samples.
    @inline(__always) func readCubic(_ d: Float) -> Float {
        let n = buf.count
        var p = Float(w) - d
        while p < 0 { p += Float(n) }
        let i = Int(p), fr = p - Float(i)
        let y0 = buf[(i + n - 1) % n], y1 = buf[i % n], y2 = buf[(i + 1) % n], y3 = buf[(i + 2) % n]
        let c1 = 0.5 * (y2 - y0), c2 = y0 - 2.5 * y1 + 2 * y2 - 0.5 * y3, c3 = 0.5 * (y3 - y0) + 1.5 * (y1 - y2)
        return ((c3 * fr + c2) * fr + c1) * fr + y1
    }
}

@inline(__always) func afxLfo(_ ph: Float, _ wave: Int) -> Float {   // −1…1
    switch wave {
    case 1: return ph < 0.5 ? 4 * ph - 1 : 3 - 4 * ph
    case 2: return ph < 0.5 ? 1 : -1
    case 3: return 2 * ph - 1
    default: return sin(2 * Float.pi * ph)
    }
}

// MARK: - smoothing + processor base

/// One-pole parameter smoother: every target change glides, so nothing ever steps or zippers.
struct Sm {
    var v: Float, t: Float, c: Float
    init(_ x: Float, sr: Float, ms: Float = 25) { v = x; t = x; c = 1 - exp(-1 / max(1, ms * 0.001 * sr)) }
    @inline(__always) mutating func next() -> Float { v += (t - v) * c; return v }
    mutating func advance(_ k: Float) { v += (t - v) * (1 - pow(1 - c, k)) }
    mutating func snap(_ x: Float) { v = x; t = x }
}

protocol AFxProc: AnyObject {
    func update(_ it: AudioFxItem)
    func process(_ l: UnsafeMutablePointer<Float>, _ r: UnsafeMutablePointer<Float>, _ n: Int)
}

/// Processors live for as long as the effect exists. `update` only moves smoothed targets (never rebuilds, never clears
/// delay lines or LFO phase), so dragging or keyframing a parameter is click-free.
class AFxBase: AFxProc {
    let sr: Float
    var first = true
    init(sr: Float) { self.sr = sr }
    @inline(__always) final func tgt(_ s: inout Sm, _ v: Float) { if first { s.snap(v) } else { s.t = v } }
    final func update(_ it: AudioFxItem) { apply(it); first = false }
    func apply(_ it: AudioFxItem) {}
    func process(_ l: UnsafeMutablePointer<Float>, _ r: UnsafeMutablePointer<Float>, _ n: Int) {}
}

/// Dry/wet blend (smoothed).
final class AFxBlend: AFxBase {
    let inner: AFxBase
    var mix: Sm
    var dl = [Float](repeating: 0, count: 8192), dr = [Float](repeating: 0, count: 8192)
    init(_ i: AFxBase, sr: Float) { inner = i; mix = Sm(1, sr: sr); super.init(sr: sr) }
    override func apply(_ it: AudioFxItem) { inner.update(it); tgt(&mix, min(max(it.blend, 0), 1)) }
    override func process(_ l: UnsafeMutablePointer<Float>, _ r: UnsafeMutablePointer<Float>, _ n: Int) {
        if mix.t > 0.999 && mix.v > 0.9995 { inner.process(l, r, n); return }
        if dl.count < n { dl = [Float](repeating: 0, count: n); dr = dl }
        for i in 0..<n { dl[i] = l[i]; dr[i] = r[i] }
        inner.process(l, r, n)
        for i in 0..<n { let m = mix.next(); l[i] = dl[i] * (1 - m) + l[i] * m; r[i] = dr[i] * (1 - m) + r[i] * m }
    }
}

/// Flanger: short (0.1–15 ms) LFO-swept delay summed with the dry signal → moving comb filter.
/// Cubic-interpolated reads (no HF grit), smoothed delay/depth, soft-limited + DC-blocked feedback, 90° stereo LFO.
final class AFxFlanger: AFxBase {
    var dL: DelayLine, dR: DelayLine
    var rate: Sm, depth: Sm, delay: Sm, fb: Sm
    var ph: Float = 0
    var hxL: Float = 0, hyL: Float = 0, hxR: Float = 0, hyR: Float = 0
    init(_ it: AudioFxItem, _ sr: Float) {
        let m = Int(18 * 0.001 * sr) + 16
        dL = DelayLine(maxSamples: m); dR = DelayLine(maxSamples: m)
        rate = Sm(0.3, sr: sr, ms: 60); depth = Sm(2, sr: sr, ms: 40); delay = Sm(2, sr: sr, ms: 40); fb = Sm(0, sr: sr, ms: 30)
        super.init(sr: sr); update(it)
    }
    override func apply(_ it: AudioFxItem) { tgt(&rate, it.v("rate")); tgt(&depth, it.v("depth")); tgt(&delay, it.v("delay")); tgt(&fb, it.v("fb")) }
    override func process(_ l: UnsafeMutablePointer<Float>, _ r: UnsafeMutablePointer<Float>, _ n: Int) {
        let ms = 0.001 * sr
        for i in 0..<n {
            let rt = rate.next(), dp = depth.next(), dy = delay.next(), f = fb.next()
            let a = 0.5 + 0.5 * sin(2 * Float.pi * ph), b = 0.5 + 0.5 * sin(2 * Float.pi * (ph + 0.25))
            let xl = l[i], xr = r[i]
            let wl = dL.readCubic(max(3, (dy + dp * a) * ms)), wr = dR.readCubic(max(3, (dy + dp * b) * ms))
            let sl = tanh(wl * f), sR = tanh(wr * f)
            let ol = sl - hxL + 0.995 * hyL; hxL = sl; hyL = ol
            let or = sR - hxR + 0.995 * hyR; hxR = sR; hyR = or
            dL.write(xl + ol); dR.write(xr + or)
            l[i] = (xl + wl) * 0.6; r[i] = (xr + wr) * 0.6
            ph += rt / sr; if ph >= 1 { ph -= 1 }
        }
    }
}

/// Chorus: 5–55 ms delays with slow LFOs, up to 4 voices with spread LFO phases (R channel offset 180°).
/// Voice count is continuous (each extra voice fades in), so changing it never clicks.
final class AFxChorus: AFxBase {
    var dL: DelayLine, dR: DelayLine
    var rate: Sm, depth: Sm, delay: Sm, voices: Sm
    var ph: Float = 0
    init(_ it: AudioFxItem, _ sr: Float) {
        let m = Int(62 * 0.001 * sr) + 16
        dL = DelayLine(maxSamples: m); dR = DelayLine(maxSamples: m)
        rate = Sm(1, sr: sr, ms: 60); depth = Sm(5, sr: sr, ms: 40); delay = Sm(20, sr: sr, ms: 40); voices = Sm(3, sr: sr, ms: 80)
        super.init(sr: sr); update(it)
    }
    override func apply(_ it: AudioFxItem) { tgt(&rate, it.v("rate")); tgt(&depth, it.v("depth")); tgt(&delay, it.v("delay")); tgt(&voices, it.v("voices")) }
    override func process(_ l: UnsafeMutablePointer<Float>, _ r: UnsafeMutablePointer<Float>, _ n: Int) {
        let ms = 0.001 * sr
        for i in 0..<n {
            let rt = rate.next(), dp = depth.next(), dy = delay.next(), nv = voices.next()
            let xl = l[i], xr = r[i]
            dL.write(xl); dR.write(xr)
            var sl: Float = 0, sR: Float = 0, gs: Float = 0
            for v in 0..<4 {
                let vg = min(max(nv - Float(v), 0), 1)
                if vg <= 0.0005 { continue }
                let o = Float(v) / 4, base = dy * (1 + 0.12 * Float(v))
                let ml = 0.5 + 0.5 * sin(2 * Float.pi * (ph + o)), mr = 0.5 + 0.5 * sin(2 * Float.pi * (ph + o + 0.5))
                sl += dL.readCubic(max(3, (base + dp * ml) * ms)) * vg
                sR += dR.readCubic(max(3, (base + dp * mr) * ms)) * vg
                gs += vg
            }
            let g = 1 / max(1, gs).squareRoot()
            l[i] = (xl + sl * g) * 0.7071; r[i] = (xr + sR * g) * 0.7071
            ph += rt / sr; if ph >= 1 { ph -= 1 }
        }
    }
}

final class AFxModulator: AFxBase {
    var freq: Sm, depth: Sm, gs: Sm
    var wave = 0, mode = 0
    var ph: Float = 0
    init(_ it: AudioFxItem, _ sr: Float) {
        freq = Sm(30, sr: sr, ms: 40); depth = Sm(1, sr: sr, ms: 25); gs = Sm(1, sr: sr, ms: 0.08)
        super.init(sr: sr); update(it)
    }
    override func apply(_ it: AudioFxItem) {
        tgt(&freq, it.v("freq")); tgt(&depth, it.v("depth"))
        wave = Int(it.v("wave").rounded()); mode = Int(it.v("mode").rounded())
    }
    override func process(_ l: UnsafeMutablePointer<Float>, _ r: UnsafeMutablePointer<Float>, _ n: Int) {
        for i in 0..<n {
            let f = freq.next(), d = depth.next()
            let m = afxLfo(ph, wave)
            gs.t = mode == 0 ? (1 - d) + d * m : 1 - d * (0.5 - 0.5 * m)     // ring / tremolo; edge-smoothed so a square wave doesn't click
            let g = gs.next()
            l[i] *= g; r[i] *= g
            ph += f / sr; if ph >= 1 { ph -= floor(ph) }
        }
    }
}

/// Phaser: N staggered first-order all-pass stages swept exponentially, summed with the dry signal (notches).
/// Coefficients refresh every 8 samples; stage count is continuous; feedback is tanh-limited and DC-blocked.
final class AFxPhaser: AFxBase {
    static func stagger(_ s: Int) -> Float { (Float(s) - 5.5) * 0.12 }       // octaves of offset between stages
    var rate: Sm, depth: Sm, stages: Sm, freq: Sm, fb: Sm
    var ph: Float = 0
    var zL = [Float](repeating: 0, count: 12), zR = [Float](repeating: 0, count: 12)
    var aL = [Float](repeating: 0, count: 12), aR = [Float](repeating: 0, count: 12)
    var fL: Float = 0, fR: Float = 0, ctl = 0
    var hxL: Float = 0, hyL: Float = 0, hxR: Float = 0, hyR: Float = 0
    init(_ it: AudioFxItem, _ sr: Float) {
        rate = Sm(0.5, sr: sr, ms: 60); depth = Sm(0.8, sr: sr, ms: 40); stages = Sm(6, sr: sr, ms: 80)
        freq = Sm(1000, sr: sr, ms: 40); fb = Sm(0.4, sr: sr, ms: 30)
        super.init(sr: sr); update(it)
    }
    override func apply(_ it: AudioFxItem) {
        tgt(&rate, it.v("rate")); tgt(&depth, it.v("depth")); tgt(&stages, it.v("stages")); tgt(&freq, it.v("freq")); tgt(&fb, it.v("fb"))
    }
    private func coeffs(_ fc: Float, _ dp: Float) {
        let sL = sin(2 * Float.pi * ph), sR = sin(2 * Float.pi * (ph + 0.25))
        for s in 0..<12 {
            let off = AFxPhaser.stagger(s)
            let fl = min(sr * 0.45, max(20, fc * exp2(sL * 2.5 * dp + off))), fr = min(sr * 0.45, max(20, fc * exp2(sR * 2.5 * dp + off)))
            let tl = tan(Float.pi * fl / sr), tr = tan(Float.pi * fr / sr)
            aL[s] = (1 - tl) / (1 + tl); aR[s] = (1 - tr) / (1 + tr)
        }
    }
    override func process(_ l: UnsafeMutablePointer<Float>, _ r: UnsafeMutablePointer<Float>, _ n: Int) {
        for i in 0..<n {
            let rt = rate.next(), dp = depth.next(), ns = stages.next(), fc = freq.next(), f = fb.next()
            if ctl == 0 { coeffs(fc, dp) }
            ctl = (ctl + 1) & 7
            let sl = tanh(fL * f), sR = tanh(fR * f)
            let ol = sl - hxL + 0.995 * hyL; hxL = sl; hyL = ol
            let or = sR - hxR + 0.995 * hyR; hxR = sR; hyR = or
            let dl = l[i], dr = r[i]
            var xl = dl + ol, xr = dr + or
            for s in 0..<12 {
                let w = min(max(ns - Float(s), 0), 1)
                if w <= 0 { break }
                let yl = aL[s] * xl + zL[s]; zL[s] = xl - aL[s] * yl
                let yr = aR[s] * xr + zR[s]; zR[s] = xr - aR[s] * yr
                xl += (yl - xl) * w; xr += (yr - xr) * w
            }
            fL = xl; fR = xr
            l[i] = (dl + xl) * 0.5; r[i] = (dr + xr) * 0.5
            ph += rt / sr; if ph >= 1 { ph -= 1 }
        }
    }
}

final class AFxPan: AFxBase {
    var pan: Sm, rate: Sm, depth: Sm
    var ph: Float = 0
    init(_ it: AudioFxItem, _ sr: Float) {
        pan = Sm(0, sr: sr, ms: 30); rate = Sm(0, sr: sr, ms: 60); depth = Sm(0.5, sr: sr, ms: 40)
        super.init(sr: sr); update(it)
    }
    override func apply(_ it: AudioFxItem) { tgt(&pan, it.v("pan")); tgt(&rate, it.v("rate")); tgt(&depth, it.v("depth")) }
    override func process(_ l: UnsafeMutablePointer<Float>, _ r: UnsafeMutablePointer<Float>, _ n: Int) {
        for i in 0..<n {
            let pn = pan.next(), rt = rate.next(), dp = depth.next()
            let act = min(rt * 20, 1)
            let p = min(max(pn + act * dp * sin(2 * Float.pi * ph), -1), 1)
            ph += rt / sr; if ph >= 1 { ph -= 1 }
            let a = (p + 1) * 0.25 * Float.pi
            l[i] *= min(cos(a) * 1.41421356, 1); r[i] *= min(sin(a) * 1.41421356, 1)
        }
    }
}

final class AFxReverb: AFxBase {
    private static let combT = [1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617]
    private static let apT = [556, 441, 341, 225]
    struct Comb { var b: [Float]; var i = 0; var s: Float = 0 }
    var cl: [Comb], cr: [Comb], al: [Comb], ar: [Comb]
    var fbk: Sm, damp: Sm, width: Sm, preS: Sm
    var pre: DelayLine, preR: DelayLine
    init(_ it: AudioFxItem, _ sr: Float) {
        let k = sr / 44100, spread = 23
        func mk(_ t: Int) -> Comb { Comb(b: [Float](repeating: 0, count: max(8, Int(Float(t) * k)))) }
        cl = Self.combT.map(mk); cr = Self.combT.map { mk($0 + spread) }
        al = Self.apT.map(mk); ar = Self.apT.map { mk($0 + spread) }
        fbk = Sm(0.85, sr: sr, ms: 80); damp = Sm(0.2, sr: sr, ms: 60); width = Sm(1, sr: sr, ms: 40); preS = Sm(0, sr: sr, ms: 80)
        let mx = Int(0.16 * sr) + 8
        pre = DelayLine(maxSamples: mx); preR = DelayLine(maxSamples: mx)
        super.init(sr: sr); update(it)
    }
    override func apply(_ it: AudioFxItem) {
        tgt(&fbk, it.v("room") * 0.28 + 0.7); tgt(&damp, it.v("damp") * 0.4); tgt(&width, it.v("width")); tgt(&preS, it.v("pre") * 0.001 * sr)
    }
    @inline(__always) private func comb(_ c: inout Comb, _ x: Float, _ fb: Float, _ dm: Float) -> Float {
        let o = c.b[c.i]
        c.s = o * (1 - dm) + c.s * dm
        c.b[c.i] = x + c.s * fb
        c.i += 1; if c.i >= c.b.count { c.i = 0 }
        return o
    }
    @inline(__always) private func allp(_ c: inout Comb, _ x: Float) -> Float {
        let o = c.b[c.i], y = o - x
        c.b[c.i] = x + o * 0.5
        c.i += 1; if c.i >= c.b.count { c.i = 0 }
        return y
    }
    override func process(_ l: UnsafeMutablePointer<Float>, _ r: UnsafeMutablePointer<Float>, _ n: Int) {
        for i in 0..<n {
            let fb = fbk.next(), dm = damp.next(), wd = width.next(), p = preS.next()
            let w1 = wd * 0.5 + 0.5, w2 = (1 - wd) * 0.5
            pre.write(l[i]); preR.write(r[i])
            let inp = p > 1 ? (pre.read(p) + preR.read(p)) * 0.015 : (l[i] + r[i]) * 0.015
            var sl: Float = 0, sR: Float = 0
            for j in 0..<8 { sl += comb(&cl[j], inp, fb, dm); sR += comb(&cr[j], inp, fb, dm) }
            for j in 0..<4 { sl = allp(&al[j], sl); sR = allp(&ar[j], sR) }
            l[i] = (sl * w1 + sR * w2) * 3; r[i] = (sR * w1 + sl * w2) * 3
        }
    }
}

final class AFxEcho: AFxBase {
    var dL: DelayLine, dR: DelayLine
    var time: Sm, fb: Sm, damp: Sm, ping: Sm
    var lpL: Float = 0, lpR: Float = 0
    init(_ it: AudioFxItem, _ sr: Float) {
        let mx = Int(1.55 * sr) + 16
        dL = DelayLine(maxSamples: mx); dR = DelayLine(maxSamples: mx)
        time = Sm(0.35 * sr, sr: sr, ms: 150); fb = Sm(0.4, sr: sr, ms: 40); damp = Sm(0.3, sr: sr, ms: 40); ping = Sm(0, sr: sr, ms: 60)
        super.init(sr: sr); update(it)
    }
    override func apply(_ it: AudioFxItem) {
        tgt(&time, it.v("time") * 0.001 * sr); tgt(&fb, it.v("fb")); tgt(&damp, it.v("damp") * 0.85); tgt(&ping, it.v("ping") > 0.5 ? 1 : 0)
    }
    override func process(_ l: UnsafeMutablePointer<Float>, _ r: UnsafeMutablePointer<Float>, _ n: Int) {
        for i in 0..<n {
            let t = max(3, time.next()), f = fb.next(), dm = damp.next(), p = ping.next()
            let a = dL.readCubic(t), b = dR.readCubic(t)
            lpL = a * (1 - dm) + lpL * dm; lpR = b * (1 - dm) + lpR * dm
            dL.write(l[i] + f * (lpL * (1 - p) + lpR * p))                     // ping-pong crossfades the feedback path L↔R
            dR.write(r[i] * (1 - p) + f * (lpR * (1 - p) + lpL * p))
            l[i] += a; r[i] += b
        }
    }
}

/// A biquad whose frequency / Q / gain glide; coefficients refresh every 32 samples (no zipper noise on sweeps).
struct SBand {
    let kind: Biquad.Kind, sr: Float
    var f: Sm, q: Sm, g: Sm          // f is stored as log2(Hz) so sweeps are musical
    var bl = Biquad(), br = Biquad()
    init(_ k: Biquad.Kind, _ f0: Float, _ q0: Float, _ g0: Float, sr: Float) {
        kind = k; self.sr = sr
        f = Sm(log2(max(f0, 10)), sr: sr, ms: 30); q = Sm(q0, sr: sr, ms: 30); g = Sm(g0, sr: sr, ms: 30)
        refresh()
    }
    mutating func target(_ f0: Float, _ q0: Float, _ g0: Float, snap: Bool) {
        let lf = log2(max(f0, 10))
        if snap { f.snap(lf); q.snap(q0); g.snap(g0); refresh() } else { f.t = lf; q.t = q0; g.t = g0 }
    }
    mutating func step(_ k: Float) { f.advance(k); q.advance(k); g.advance(k); refresh() }
    mutating func refresh() {
        bl.set(kind, f: exp2(f.v), q: q.v, gainDb: g.v, sr: sr)
        br.b0 = bl.b0; br.b1 = bl.b1; br.b2 = bl.b2; br.a1 = bl.a1; br.a2 = bl.a2
    }
}

final class AFxFilterChain: AFxBase {          // Muffle / Tone / Equalizer
    let type: String
    var bands: [SBand]
    var gain: Sm
    init(_ it: AudioFxItem, _ sr: Float) {
        type = it.type
        switch it.type {
        case "muffle": bands = [SBand(.lowpass, 800, 0.7, 0, sr: sr), SBand(.lowpass, 800, 0.707, 0, sr: sr)]
        case "tone": bands = [SBand(.lowShelf, 1000, 0.7, 0, sr: sr), SBand(.highShelf, 1000, 0.7, 0, sr: sr)]
        default: bands = (0..<5).map { SBand($0 == 0 ? .lowShelf : ($0 == 4 ? .highShelf : .peak), AFxDefs.eqDefaultFreq[$0], 1, 0, sr: sr) }
        }
        gain = Sm(1, sr: sr, ms: 25)
        super.init(sr: sr); update(it)
    }
    override func apply(_ it: AudioFxItem) {
        let sn = first
        switch type {
        case "muffle":
            let cut = it.v("cut")
            bands[0].target(cut, it.v("res"), 0, snap: sn)
            bands[1].target(it.v("slope") > 0.5 ? cut : 20000, 0.707, 0, snap: sn)
            tgt(&gain, 1)
        case "tone":
            let t = it.v("tone"), p = it.v("pivot")
            bands[0].target(p, 0.7, -t * 12, snap: sn); bands[1].target(p, 0.7, t * 12, snap: sn)
            tgt(&gain, pow(10, it.v("level") / 20))
        default:
            for i in 0..<5 { bands[i].target(it.v("f\(i)"), it.v("q\(i)"), it.v("g\(i)"), snap: sn) }
            tgt(&gain, pow(10, it.v("out") / 20))
        }
    }
    override func process(_ l: UnsafeMutablePointer<Float>, _ r: UnsafeMutablePointer<Float>, _ n: Int) {
        var i = 0
        while i < n {
            let m = min(32, n - i)
            for b in 0..<bands.count { bands[b].step(Float(m)) }
            for j in i..<(i + m) {
                var a = l[j], c = r[j]
                for b in 0..<bands.count { a = bands[b].bl.tick(a); c = bands[b].br.tick(c) }
                let g = gain.next()
                l[j] = a * g; r[j] = c * g
            }
            i += m
        }
    }
}

final class AFxDist: AFxBase {
    var drive: Sm, out: Sm
    var w: [Sm]
    var tone: SBand
    init(_ it: AudioFxItem, _ sr: Float) {
        drive = Sm(4, sr: sr, ms: 25); out = Sm(0.5, sr: sr, ms: 25)
        w = (0..<3).map { _ in Sm(0, sr: sr, ms: 15) }
        tone = SBand(.lowpass, 8000, 0.707, 0, sr: sr)
        super.init(sr: sr); update(it)
    }
    override func apply(_ it: AudioFxItem) {
        tgt(&drive, pow(10, it.v("drive") / 20)); tgt(&out, pow(10, it.v("level") / 20))
        let s = Int(it.v("shape").rounded())
        for i in 0..<3 { tgt(&w[i], i == s ? 1 : 0) }
        tone.target(it.v("tone"), 0.707, 0, snap: first)
    }
    @inline(__always) private func fold(_ x: Float) -> Float {
        var y = x; var k = 0
        while abs(y) > 1 && k < 6 { y = y > 1 ? 2 - y : (y < -1 ? -2 - y : y); k += 1 }
        return y
    }
    @inline(__always) private func shape(_ x: Float, _ w0: Float, _ w1: Float, _ w2: Float) -> Float {
        var y: Float = 0
        if w0 > 0.001 { y += tanh(x) * w0 }
        if w1 > 0.001 { y += max(-1, min(1, x)) * w1 }
        if w2 > 0.001 { y += fold(x) * w2 }
        return y
    }
    override func process(_ l: UnsafeMutablePointer<Float>, _ r: UnsafeMutablePointer<Float>, _ n: Int) {
        var i = 0
        while i < n {
            let m = min(32, n - i)
            tone.step(Float(m))
            for j in i..<(i + m) {
                let d = drive.next(), o = out.next(), w0 = w[0].next(), w1 = w[1].next(), w2 = w[2].next()
                l[j] = tone.bl.tick(shape(l[j] * d, w0, w1, w2)) * o
                r[j] = tone.br.tick(shape(r[j] * d, w0, w1, w2)) * o
            }
            i += m
        }
    }
}

/// Compressor: stereo-linked peak detector in dB, soft-knee gain computer, attack/release ballistics, make-up gain.
final class AFxComp: AFxBase {
    var thr: Sm, ratio: Sm, knee: Sm, makeup: Sm
    var att: Float = 10, rel: Float = 150
    var gr: Float = 0
    init(_ it: AudioFxItem, _ sr: Float) {
        thr = Sm(-18, sr: sr, ms: 30); ratio = Sm(4, sr: sr, ms: 30); knee = Sm(6, sr: sr, ms: 30); makeup = Sm(0, sr: sr, ms: 30)
        super.init(sr: sr); update(it)
    }
    override func apply(_ it: AudioFxItem) {
        tgt(&thr, it.v("thresh")); tgt(&ratio, it.v("ratio")); tgt(&knee, it.v("knee")); tgt(&makeup, it.v("makeup"))
        att = it.v("attack"); rel = it.v("release")
    }
    override func process(_ l: UnsafeMutablePointer<Float>, _ r: UnsafeMutablePointer<Float>, _ n: Int) {
        let ac = exp(-1 / max(1, att * 0.001 * sr)), rc = exp(-1 / max(1, rel * 0.001 * sr))
        for i in 0..<n {
            let T = thr.next(), R = max(1, ratio.next()), W = knee.next(), mk = makeup.next()
            let lv = 20 * log10(max(max(abs(l[i]), abs(r[i])), 1e-6))
            let over = lv - T
            var target: Float = 0                                    // gain change in dB (≤ 0)
            if W < 0.01 { if over > 0 { target = -over * (1 - 1 / R) } }
            else if 2 * over > W { target = -over * (1 - 1 / R) }
            else if 2 * abs(over) <= W { let x = over + W / 2; target = -(1 - 1 / R) * x * x / (2 * W) }
            let c = target < gr ? ac : rc
            gr = c * gr + (1 - c) * target
            let g = exp((gr + mk) * 0.11512925)
            l[i] *= g; r[i] *= g
        }
    }
}

// MARK: - automation (keyframes) baked for the offline renderer

/// Keyframed parameter curves sampled at 100 Hz of *source* time. Thread-safe copy of the layer's tracks for the renderer.
struct AFxAuto {
    static let rate: Float = 100
    var curves: [String: [Float]] = [:]       // "<uid>__<param>"
    var t0: Float = 0

    func apply(_ it: AudioFxItem, _ srcT: Float) -> AudioFxItem {
        if curves.isEmpty { return it }
        var o = it
        let x = max(0, srcT) * AFxAuto.rate
        let pre = "\(it.uid)__"
        for (k, c) in curves where k.hasPrefix(pre) && c.count >= 2 {
            let i = min(Int(x), c.count - 2), f = min(max(x - Float(i), 0), 1)
            let v = c[i] + (c[i + 1] - c[i]) * f
            let name = String(k.dropFirst(pre.count))
            if name == "blend" { o.blend = v } else { o.p[name] = v }
        }
        return o
    }
    func signature() -> String {
        var h: UInt64 = 0xcbf29ce484222325
        for k in curves.keys.sorted() {
            for b in k.utf8 { h = (h ^ UInt64(b)) &* 0x100000001b3 }
            for v in curves[k]! { h = (h ^ UInt64(UInt32(bitPattern: Int32((v * 1000).rounded())))) &* 0x100000001b3 }
        }
        return String(h, radix: 16)
    }
}

extension Layer {
    func afxKey(_ it: AudioFxItem, _ k: String) -> String { "afx\(it.uid)__\(k)" }
    private func afxKeys(_ it: AudioFxItem) -> [String] { AFxDefs.params(it.type).map { $0.key } + (AFxDefs.hasBlend(it.type) ? ["blend"] : []) }

    /// True when any effect parameter of this layer has keyframes (so playback must push values every tick).
    var afxAnimated: Bool { props.contains { $0.key.hasPrefix("afx") && $0.key.contains("__") && !$0.value.keys.isEmpty } }

    /// The effect with every parameter evaluated at timeline time `t` (track = source of truth once it exists).
    func afxAt(_ it: AudioFxItem, _ t: Float) -> AudioFxItem {
        var o = it
        for k in afxKeys(it) {
            guard let tr = props[afxKey(it, k)] else { continue }
            let v = tr.eval(t)
            if k == "blend" { o.blend = v } else { o.p[k] = v }
        }
        return o
    }
    func afxChainAt(_ t: Float) -> [AudioFxItem] { afx.map { afxAt($0, t) } }

    func afxDropTracks(_ uid: Int) {
        let p = "afx\(uid)__"
        for k in Array(props.keys) where k.hasPrefix(p) { props.removeValue(forKey: k) }
    }
    func afxCopyTracks(from a: Int, to b: Int) {
        let pa = "afx\(a)__", pb = "afx\(b)__"
        for (k, tr) in props where k.hasPrefix(pa) {
            let n = Track(tr.base)
            n.keys = tr.keys.map { Key.fromJson($0.toJson()) }
            props[pb + k.dropFirst(pa.count)] = n
        }
    }
    /// Samples every keyframed effect parameter for the offline renderer / exporter.
    func afxBake() -> AFxAuto {
        var a = AFxAuto()
        a.t0 = start - srcOffset
        let n = max(2, min(Int((max(0, end - start) + srcOffset + 4) * AFxAuto.rate), Int(AFxAuto.rate) * 3600))
        for it in afx where it.on {
            for k in afxKeys(it) {
                guard let tr = props[afxKey(it, k)], !tr.keys.isEmpty else { continue }
                var c = [Float](repeating: 0, count: n)
                for i in 0..<n { c[i] = tr.eval(a.t0 + Float(i) / AFxAuto.rate) }
                a.curves["\(it.uid)__\(k)"] = c
            }
        }
        return a
    }
}

// MARK: - factory + offline rendering

enum AudioFxProc {
    static func make(_ it: AudioFxItem, sr: Float) -> AFxBase? {
        guard it.on else { return nil }
        let core: AFxBase
        switch it.type {
        case "flanger": core = AFxFlanger(it, sr)
        case "chorus": core = AFxChorus(it, sr)
        case "modulator": core = AFxModulator(it, sr)
        case "phaser": core = AFxPhaser(it, sr)
        case "pan": return AFxPan(it, sr)
        case "reverb": core = AFxReverb(it, sr)
        case "echo": core = AFxEcho(it, sr)
        case "dist": core = AFxDist(it, sr)
        case "comp": core = AFxComp(it, sr)
        case "muffle", "tone": core = AFxFilterChain(it, sr)
        case "eq": return AFxFilterChain(it, sr)
        default: return nil
        }
        let b = AFxBlend(core, sr: sr)
        b.update(it)
        return b
    }

    /// Chain key for a layer: "" when nothing audible would change.
    static func key(_ chain: [AudioFxItem], _ auto: AFxAuto = AFxAuto()) -> String {
        let act = chain.filter { $0.on }
        if act.isEmpty { return "" }
        var s = "v3|" + act.map { $0.toJson().toString() }.joined(separator: "|")        // v3 = smoothed DSP; old renders are never reused
        if !auto.curves.isEmpty { s += "#" + auto.signature() }
        return s
    }

    private static let lock = NSLock()
    private static var inflight = Set<String>()
    private static var failed = Set<String>()          // sources that could not be rendered (e.g. video without sound): never retried
    private static let queue = DispatchQueue(label: "audiofx", qos: .userInitiated)

    private static func fnv(_ s: String) -> String {
        var h: UInt64 = 0xcbf29ce484222325
        for b in s.utf8 { h = (h ^ UInt64(b)) &* 0x100000001b3 }
        return String(h, radix: 16)
    }

    private static var dirURL: URL {
        let d = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0].appendingPathComponent("AudioFx", isDirectory: true)
        try? FileManager.default.createDirectory(at: d, withIntermediateDirectories: true)
        return d
    }

    private static func cacheURL(_ path: String, _ key: String) -> URL {
        let attrs = (try? FileManager.default.attributesOfItem(atPath: path)) ?? [:]
        let size = (attrs[.size] as? NSNumber)?.int64Value ?? 0
        let mod = (attrs[.modificationDate] as? Date)?.timeIntervalSince1970 ?? 0
        return dirURL.appendingPathComponent(fnv("\((path as NSString).lastPathComponent)|\(size)|\(mod)|" + key) + ".wav")
    }

    /// The rendered file when it already exists.
    static func cachedURL(_ path: String, _ chain: [AudioFxItem], _ auto: AFxAuto = AFxAuto()) -> URL? {
        let k = key(chain, auto)
        if k.isEmpty { return nil }
        let u = cacheURL(path, k)
        return FileManager.default.fileExists(atPath: u.path) ? u : nil
    }

    /// Renders in the background (once per distinct chain); `done` runs on the main thread.
    static func prepare(_ path: String, _ chain: [AudioFxItem], _ auto: AFxAuto = AFxAuto(), done: @escaping () -> Void) {
        let k = key(chain, auto)
        if k.isEmpty { return }
        let u = cacheURL(path, k)
        if FileManager.default.fileExists(atPath: u.path) { return }
        lock.lock()
        if inflight.contains(u.path) || failed.contains(u.path) { lock.unlock(); return }
        inflight.insert(u.path); lock.unlock()
        queue.async {
            let ok = render(path, chain, auto, to: u)
            lock.lock(); inflight.remove(u.path); if !ok { failed.insert(u.path) }; lock.unlock()
            DispatchQueue.main.async { done() }
        }
    }

    /// Blocking version for the exporter: returns the processed file (rendering it if needed) or nil on failure.
    static func renderSync(_ path: String, _ chain: [AudioFxItem], _ auto: AFxAuto = AFxAuto()) -> URL? {
        let k = key(chain, auto)
        if k.isEmpty { return nil }
        let u = cacheURL(path, k)
        if FileManager.default.fileExists(atPath: u.path) { return u }
        return render(path, chain, auto, to: u) ? u : nil
    }

    @discardableResult
    private static func render(_ path: String, _ chain: [AudioFxItem], _ auto: AFxAuto, to dst: URL) -> Bool {
        // video files: if the audio engine cannot open the container, pull the sound track out to m4a first
        var fopen = try? AVAudioFile(forReading: URL(fileURLWithPath: path))
        if fopen == nil {
            let tmpA = FileManager.default.temporaryDirectory.appendingPathComponent("fxsrc-\(abs(path.hashValue)).m4a")
            if FileManager.default.fileExists(atPath: tmpA.path) || AudioTools.extractAudio(path, tmpA) {
                fopen = try? AVAudioFile(forReading: tmpA)
            }
        }
        guard let f = fopen else { return false }
        let fmt = f.processingFormat
        let sr = Float(fmt.sampleRate), ch = Int(fmt.channelCount)
        let pairs: [(AFxBase, AudioFxItem)] = chain.compactMap { it in make(it, sr: sr).map { ($0, it) } }
        if pairs.isEmpty { return false }
        var done: Double = 0                                  // source frames already rendered (drives keyframed parameters)
        let tmp = dst.appendingPathExtension("tmp")
        try? FileManager.default.removeItem(at: tmp)
        let settings: [String: Any] = [AVFormatIDKey: kAudioFormatLinearPCM, AVSampleRateKey: fmt.sampleRate, AVNumberOfChannelsKey: 2,
                                       AVLinearPCMBitDepthKey: 16, AVLinearPCMIsFloatKey: false, AVLinearPCMIsBigEndianKey: false]
        guard let out = try? AVAudioFile(forWriting: tmp, settings: settings, commonFormat: .pcmFormatFloat32, interleaved: false),
              let inBuf = AVAudioPCMBuffer(pcmFormat: fmt, frameCapacity: 32768),
              let ofmt = AVAudioFormat(commonFormat: .pcmFormatFloat32, sampleRate: fmt.sampleRate, channels: 2, interleaved: false),
              let outBuf = AVAudioPCMBuffer(pcmFormat: ofmt, frameCapacity: 32768) else { return false }
        // reverb / delay tails: keep feeding silence for 2 s after the file ends so the tail is not cut
        var tailLeft = Int(fmt.sampleRate * 2)
        let hasTail = chain.contains { $0.on && ($0.type == "reverb" || $0.type == "flanger" || $0.type == "chorus" || $0.type == "echo" || $0.type == "phaser") }
        while true {
            inBuf.frameLength = 0
            var n = 0
            if f.framePosition < f.length {
                do { try f.read(into: inBuf, frameCount: 32768) } catch { return false }
                n = Int(inBuf.frameLength)
            }
            if n == 0 {
                if !hasTail || tailLeft <= 0 { break }
                n = min(32768, tailLeft); tailLeft -= n
                for c in 0..<2 { if let p = outBuf.floatChannelData?[c] { for i in 0..<n { p[i] = 0 } } }
            } else if let src = inBuf.floatChannelData, let dstp = outBuf.floatChannelData {
                for i in 0..<n { dstp[0][i] = src[0][i]; dstp[1][i] = src[ch > 1 ? 1 : 0][i] }
            }
            guard let d = outBuf.floatChannelData else { return false }
            var off = 0
            while off < n {                                       // 256-sample steps: parameters follow their keyframes, smoothed inside each effect
                let m = min(256, n - off)
                let st = Float((done + Double(off)) / Double(sr))
                for (p, it) in pairs { p.update(auto.apply(it, st)) }
                for (p, _) in pairs { p.process(d[0] + off, d[1] + off, m) }
                off += m
            }
            done += Double(n)
            for c in 0..<2 { for i in 0..<n { d[c][i] = min(1, max(-1, d[c][i])) } }
            outBuf.frameLength = AVAudioFrameCount(n)
            do { try out.write(from: outBuf) } catch { return false }
        }
        try? FileManager.default.removeItem(at: dst)
        do { try FileManager.default.moveItem(at: tmp, to: dst) } catch { return false }
        return true
    }
}
