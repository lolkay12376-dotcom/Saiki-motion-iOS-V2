// Pass 2: vertical blur -> height maps. Full resolution.
vec4 aurea_main(vec2 uv) {
    int qn = int(quality + 0.5);
    int half_ = qn == 0 ? 6 : (qn == 1 ? 10 : 30);
    float R1 = 6.0 * bevelx;
    float R2 = R1 * 3.5;
    float R3 = 22.0 + 10.0 * bevelx;
    vec3 acc = vec3(0.0);
    float wsum = 0.0;
    for (int i = -30; i <= 30; ++i) {
        if (abs(i) > half_) continue;
        float t = float(i) / float(half_);
        float w = exp(-t * t * 3.0);
        float b1 = texture(bh, uv + aurea_px_to_uv(vec2(0.0, t * R1))).r;
        float b2 = texture(bh, uv + aurea_px_to_uv(vec2(0.0, t * R2))).g;
        float b3 = texture(bh, uv + aurea_px_to_uv(vec2(0.0, t * R3))).b;
        acc += w * vec3(b1, b2, b3);
        wsum += w;
    }
    return vec4(acc / wsum, 1.0);
}
