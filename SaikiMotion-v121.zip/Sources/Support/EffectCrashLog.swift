// EffectCrashLog.swift — finds which effect crashed / froze the app and keeps a readable log for it.
//
// Before an effect is compiled or used for the first time it is written to a small "in flight" file.
// It is removed once that work finished fine. If the app dies (crash) or the watchdog aborts it (freeze)
// the file survives; on the next launch recover() turns it into a log in
// Documents/EffectCrashLogs/<effect id>/ and marks the effect broken, so it stays switched off
// (passthrough) instead of crashing the app again. Settings > Crash shows and exports the logs.

import Foundation
import UIKit

enum EffectCrashLog {
    private static let lock = NSLock()
    private static var inflight: [String: [String: String]] = [:]
    private static var verified = Set<String>()
    private static var recovered = false

    static func rootDir() -> URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first ?? FileManager.default.temporaryDirectory
        return docs.appendingPathComponent("EffectCrashLogs", isDirectory: true)
    }
    private static var flightFile: URL { rootDir().appendingPathComponent(".inflight.json") }
    private static var brokenFile: URL { rootDir().appendingPathComponent(".broken.json") }

    // MARK: broken list
    private static var brokenCache: Set<String>? = nil
    static func isBroken(_ id: String) -> Bool {
        lock.lock(); defer { lock.unlock() }
        if brokenCache == nil { brokenCache = loadBroken() }
        return brokenCache!.contains(id)
    }
    static func brokenSet() -> Set<String> { lock.lock(); defer { lock.unlock() }; return loadBroken() }
    private static func loadBroken() -> Set<String> {
        guard let d = try? Data(contentsOf: brokenFile), let a = try? JSONSerialization.jsonObject(with: d) as? [String] else { return [] }
        return Set(a)
    }
    static func setBroken(_ id: String, _ on: Bool) {
        lock.lock(); defer { lock.unlock() }
        var b = loadBroken(); if on { b.insert(id) } else { b.remove(id) }
        try? FileManager.default.createDirectory(at: rootDir(), withIntermediateDirectories: true)
        brokenCache = b
        if let d = try? JSONSerialization.data(withJSONObject: Array(b)) { try? d.write(to: brokenFile, options: .atomic) }
    }

    // MARK: in-flight tracking (cheap: only the first use of each effect is tracked)
    /// Returns false if this effect already ran fine this session (nothing to track).
    @discardableResult
    static func begin(_ id: String, name: String = "", stage: String, detail: String = "") -> Bool {
        lock.lock()
        if verified.contains(id) && stage == "first render" { lock.unlock(); return false }
        inflight[id + "|" + stage] = ["id": id, "name": name, "stage": stage, "detail": detail,
                                      "time": ISO8601DateFormatter().string(from: Date()),
                                      "t0": String(CFAbsoluteTimeGetCurrent())]
        writeFlight()
        lock.unlock()
        return true
    }
    static func end(_ id: String, stage: String) {
        lock.lock()
        inflight[id + "|" + stage] = nil
        if stage == "first render" { verified.insert(id) }
        writeFlight()
        lock.unlock()
    }
    private static func writeFlight() {
        try? FileManager.default.createDirectory(at: rootDir(), withIntermediateDirectories: true)
        if inflight.isEmpty { try? FileManager.default.removeItem(at: flightFile); return }
        if let d = try? JSONSerialization.data(withJSONObject: Array(inflight.values)) { try? d.write(to: flightFile, options: .atomic) }
    }

    // MARK: logs
    private static func deviceInfo() -> String {
        let d = UIDevice.current
        let v = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "?"
        return "App \(v)  |  \(d.model) iOS \(d.systemVersion)  |  RAM \(ProcessInfo.processInfo.physicalMemory / 1_048_576) MB"
    }
    @discardableResult
    static func writeLog(id: String, name: String, kind: String, stage: String, detail: String, markBroken: Bool) -> URL? {
        let dir = rootDir().appendingPathComponent(id.replacingOccurrences(of: "/", with: "_"), isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let f = DateFormatter(); f.dateFormat = "yyyy-MM-dd_HH-mm-ss"
        let url = dir.appendingPathComponent("\(f.string(from: Date()))_\(kind).log")
        var t = "EFFECT \(kind.uppercased())\n==============================\n"
        t += "Effect: \(name.isEmpty ? id : name) (\(id))\nWhat happened: \(kind)\nWhile: \(stage)\n"
        t += "When: \(ISO8601DateFormatter().string(from: Date()))\n\(deviceInfo())\n"
        if !detail.isEmpty { t += "\nDetails:\n\(detail)\n" }
        if markBroken { t += "\nThis effect was switched off (passthrough) so the app keeps working. Re-enable it in Settings > Crash > Effect crash logs.\n" }
        try? t.write(to: url, atomically: true, encoding: .utf8)
        if markBroken { setBroken(id, true) }
        return url
    }
    /// A shader / compile problem that did not kill the app.
    static func logError(_ id: String, _ msg: String, name: String = "") {
        writeLog(id: id, name: name, kind: "error", stage: "shader compile", detail: msg, markBroken: false)
    }
    /// Run once at launch: anything still "in flight" means the last run died while using that effect.
    static func recover() {
        lock.lock(); if recovered { lock.unlock(); return }; recovered = true; lock.unlock()
        guard let d = try? Data(contentsOf: flightFile),
              let arr = try? JSONSerialization.jsonObject(with: d) as? [[String: String]] else { return }
        for e in arr {
            writeLog(id: e["id"] ?? "unknown", name: e["name"] ?? "", kind: "crash-or-freeze", stage: e["stage"] ?? "?",
                     detail: "The app stopped while this effect was being \(e["stage"] ?? "used") (started \(e["time"] ?? "?")).\n" + (e["detail"] ?? ""),
                     markBroken: true)
        }
        try? FileManager.default.removeItem(at: flightFile)
    }
    /// Called by the freeze watchdog right before it aborts the app.
    static func noteFreeze(_ detail: String) {
        lock.lock(); let items = Array(inflight.values); inflight = [:]; lock.unlock()
        for e in items {
            writeLog(id: e["id"] ?? "unknown", name: e["name"] ?? "", kind: "freeze", stage: e["stage"] ?? "?",
                     detail: detail + "\n" + (e["detail"] ?? ""), markBroken: true)
        }
        try? FileManager.default.removeItem(at: flightFile)
    }
    /// Called every ~2 s by the watchdog while the main thread is silent: an effect that has been in flight
    /// for `secs` is logged and switched off NOW, before the user has to force-quit the frozen app.
    static func noteStallIfAny(_ secs: Double) {
        lock.lock()
        let now = CFAbsoluteTimeGetCurrent()
        let stuck = inflight.filter { now - (Double($0.value["t0"] ?? "") ?? now) > secs && $0.value["stage"] != "quick test" }
        for k in stuck.keys { inflight[k] = nil }
        if !stuck.isEmpty { writeFlight() }
        lock.unlock()
        for e in stuck.values {
            writeLog(id: e["id"] ?? "unknown", name: e["name"] ?? "", kind: "freeze", stage: e["stage"] ?? "?",
                     detail: "The app stopped responding for more than \(Int(secs)) s while this effect was being \(e["stage"] ?? "used").\n" + (e["detail"] ?? ""),
                     markBroken: true)
        }
    }
    static func count() -> Int {
        let fm = FileManager.default
        let dirs = (try? fm.contentsOfDirectory(at: rootDir(), includingPropertiesForKeys: [.isDirectoryKey])) ?? []
        return dirs.filter { (try? $0.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) == true }.count
    }
}
