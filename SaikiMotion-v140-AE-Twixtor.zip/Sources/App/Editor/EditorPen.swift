// EditorPen.swift — opens the vector pen to create or edit a path shape layer.
import UIKit

extension EditorViewController {
    func openPenEditor(editing l: Layer? = nil) {
        let vc = VectorPenViewController(path: l?.vpath ?? VPath())
        vc.onDone = { [weak self] p in
            guard let self = self else { return }
            let t: Layer
            if let l = l { self.pushUndo(); t = l } else { t = self.addLayer(.SHAPE); t.name = "Path \(t.id)"; t.color = Int32(bitPattern: 0xFFFF8A1A) }
            t.shape = .PATH; t.vpath = p
            self.refreshPanel(); self.render()
        }
        present(vc, animated: true)
    }
}
