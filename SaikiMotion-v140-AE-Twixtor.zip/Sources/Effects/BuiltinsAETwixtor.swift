// BuiltinsAETwixtor.swift — "Turbulent Displace" laid out like After Effects, and Twixtor (retime + motion-compensated interpolation).

import Foundation

func aeTwixtorFx() -> [EffectDef] {
    var out: [EffectDef] = []

    // MARK: Turbulent Displace (After Effects parameter set, px units)
    out.append(EffectDef(
        id: "aeturbdisp", name: "Turbulent Displace",
        desc: "Uses fractal noise to create turbulent distortions: flowing water, funhouse mirrors, waving flags. Same controls as After Effects (Displacement type, Amount, Size, Offset, Complexity, Evolution, Evolution Options, Pinning, Resize Layer, Antialiasing).",
        category: "Distort", props: [
            PropDef("tdDisp", "Displacement", 0, 8, 0, 0, ["Turbulent", "Bulge", "Twist", "Turbulent Smoother", "Bulge Smoother", "Twist Smoother", "Horizontal Displacement", "Vertical Displacement", "Cross Displacement"]),
            PropDef("tdAmount", "Amount", -2000, 2000, 50, 1),
            PropDef("tdSize", "Size", 1, 10000, 200, 1),
            PropDef("tdOffX", "Offset (Turbulence) X", -100000, 100000, 960, 1, nil, true, 500),
            PropDef("tdOffY", "Offset (Turbulence) Y", -100000, 100000, 540, 1, nil, true, 500),
            PropDef("tdCplx", "Complexity", 1, 10, 1, 1),
            PropDef("tdEvo", "Evolution", -36000, 36000, 0, 1, nil, true, 360),
            PropDef("tdCycleOn", "Cycle Evolution", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("tdCycle", "Cycle (in Revolutions)", 1, 100, 1, 0),
            PropDef("tdSeed", "Random Seed", 0, 10000, 0, 0, nil, true, 100),
            PropDef("tdPin", "Pinning", 0, 7, 0, 0, ["No Pinning", "Pin All", "Pin Horizontally", "Pin Vertically", "Pin Top", "Pin Bottom", "Pin Left", "Pin Right"]),
            PropDef("tdResize", "Resize Layer", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("tdAA", "Antialiasing for Best Quality", 0, 1, 0, 0, ["Low", "High"]),
        ], glsl: """
    vec2 px = uv * uRes;
    vec2 cen = vec2(tdOffX, uRes.y - tdOffY);
    float sz = max(tdSize, 1.0);
    float evoRev = tdEvo / 360.0;
    float theta = 6.2831853 * (tdCycleOn > 0.5 ? evoRev / max(tdCycle, 1.0) : evoRev);
    vec2 circ = vec2(cos(theta), sin(theta)) * (tdCycleOn > 0.5 ? 2.0 : 1.2);
    vec2 drift = tdCycleOn > 0.5 ? vec2(0.0) : vec2(evoRev * 1.7, evoRev * 1.1);
    vec2 sd = vec2(tdSeed * 13.17, tdSeed * 7.31);
    bool smoothT = tdDisp > 2.5 && tdDisp < 5.5;
    float cplx = smoothT ? min(tdCplx, 2.0) : tdCplx;
    vec2 q = (px - vec2(tdOffX, uRes.y - tdOffY)) / sz;
    vec2 pa = q + circ + drift + sd;
    vec2 pb = q + vec2(circ.y, -circ.x) + drift * 0.8 + sd + vec2(31.4, 17.9);
    float nx = 0.0; float ny = 0.0; float amp = 1.0; float nrm = 0.0;
    for (int i = 0; i < 10; i++) {
        float oc = clamp(cplx - float(i), 0.0, 1.0);
        if (oc <= 0.0) break;
        nx += (vnoise(pa) * 2.0 - 1.0) * amp * oc;
        ny += (vnoise(pb) * 2.0 - 1.0) * amp * oc;
        nrm += amp * oc;
        pa = pa * 2.0 + vec2(5.2, 1.3); pb = pb * 2.0 + vec2(9.7, 8.3);
        amp *= 0.5;
    }
    nx /= max(nrm, 0.0001); ny /= max(nrm, 0.0001);
    if (smoothT) { nx = nx * (1.5 - 0.5 * nx * nx); ny = ny * (1.5 - 0.5 * ny * ny); }
    vec2 dir = px - cen; float dl = max(length(dir), 1.0);
    vec2 dv = vec2(0.0);
    float md = tdDisp;
    if (md > 2.5 && md < 5.5) { md -= 3.0; }
    if (md < 0.5) { dv = vec2(nx, ny); }
    else if (md < 1.5) { dv = dir / dl * nx; }
    else if (md < 2.5) { dv = vec2(-dir.y, dir.x) / dl * nx; }
    else if (md < 6.5) { dv = vec2(nx, 0.0); }
    else if (md < 7.5) { dv = vec2(0.0, nx); }
    else { dv = vec2(ny, nx); }
    float pin = 1.0;
    float e = max(sz * 0.25, 1.0);
    float eL = smoothstep(0.0, e, px.x), eR = smoothstep(0.0, e, uRes.x - px.x);
    float eB = smoothstep(0.0, e, px.y), eT = smoothstep(0.0, e, uRes.y - px.y);
    float pm = tdPin;
    if (pm > 0.5 && pm < 1.5) { pin = eL * eR * eT * eB; }
    else if (pm < 2.5 && pm > 1.5) { pin = eL * eR; }
    else if (pm < 3.5 && pm > 2.5) { pin = eT * eB; }
    else if (pm < 4.5 && pm > 3.5) { pin = eT; }
    else if (pm < 5.5 && pm > 4.5) { pin = eB; }
    else if (pm < 6.5 && pm > 5.5) { pin = eL; }
    else if (pm > 6.5) { pin = eR; }
    vec2 sp = px + dv * tdAmount * pin * vec2(1.0, -1.0);
    vec2 suv = sp / uRes;
    vec4 r;
    if (tdAA > 0.5) {
        vec2 o = 0.35 / uRes;
        r = (src(suv + vec2(-o.x, -o.y)) + src(suv + vec2(o.x, -o.y)) + src(suv + vec2(-o.x, o.y)) + src(suv + vec2(o.x, o.y))) * 0.25;
    } else { r = src(suv); }
    if (suv.x < 0.0 || suv.x > 1.0 || suv.y < 0.0 || suv.y > 1.0) { r = vec4(0.0); }
    return r;
"""))

    // MARK: Twixtor — retime (Speed % / Frame #) + block-matching optical-flow interpolation between source frames A and B.
    // The renderer supplies frame A as the layer and frame B (next source frame) as the effect's second input; twFrac is set by the renderer.
    out.append(EffectDef(
        id: "twixtor", name: "Twixtor",
        desc: "Retiming with motion-compensated frame interpolation: slow motion, speed-ups and frame-rate conversion. Set the source Input Frame Rate, choose Speed % or Frame # time remapping, and tune Motion Sensitivity / Image Prep. Display switches between the Twixtored output, the source frame and the motion vectors.",
        category: "Transform and time", props: [
            PropDef("twDisplay", "Display", 0, 2, 0, 0, ["Twixtored Output", "Source Frame", "Motion Vectors"]),
            PropDef("twInFps", "Input: Frame Rate", 1, 240, 24, 3),
            PropDef("twInIsOut", "In FPS is Out FPS", 0, 1, 1, 0, ["Off", "On"]),
            PropDef("twOutFps", "Out FPS", 1, 240, 24, 3),
            PropDef("twMode", "Time Remap Mode", 0, 1, 0, 0, ["Speed", "Frame"]),
            PropDef("twSpeed", "Speed %", -1000, 1000, 100, 2, nil, true, 100),
            PropDef("twFrame", "Frame #", 0, 100000, 0, 2, nil, true, 100),
            PropDef("twSens", "Motion Sensitivity", 0, 100, 50, 1),
            PropDef("twPrep", "Image Prep Preset", 0, 2, 0, 0, ["Normal", "Enhance Contrast / Edges", "Dark Imagery"]),
            PropDef("twSmart", "Smart Blend", 0, 1, 1, 0, ["Off", "On"]),
            PropDef("twFrac", "Interpolation Position (auto)", 0, 1, 0, 3),
        ], glsl: """
    vec2 px = 1.0 / uRes;
    vec4 A = src(uv);
    if (twDisplay > 0.5 && twDisplay < 1.5) { return A; }
    float t = clamp(twFrac, 0.0, 1.0);
    if (uHas1 < 0.5) { return A; }
    float stp = max(1.0, twSens * 0.12);
    float gain = twPrep > 0.5 && twPrep < 1.5 ? 2.2 : (twPrep > 1.5 ? 3.5 : 1.0);
    float bestS = 1e9; vec2 bestV = vec2(0.0);
    float lc = luma(A.rgb) * gain;
    for (int j = -2; j <= 2; j++) {
        for (int i = -2; i <= 2; i++) {
            vec2 v = vec2(float(i), float(j)) * stp;
            float s = 0.0;
            for (int k = 0; k < 5; k++) {
                vec2 o = k == 0 ? vec2(0.0) : (k == 1 ? vec2(1.0, 0.0) : (k == 2 ? vec2(-1.0, 0.0) : (k == 3 ? vec2(0.0, 1.0) : vec2(0.0, -1.0)))) * stp * 0.5;
                float a = luma(src(uv + o * px).rgb) * gain;
                float b = luma(in1(uv + (o + v) * px).rgb) * gain;
                s += abs(a - b);
            }
            s += length(v) * 0.002;
            if (s < bestS) { bestS = s; bestV = v; }
        }
    }
    vec2 flow = bestV * px;
    if (twDisplay > 1.5) { return vec4(0.5 + flow * uRes * 0.5 / max(stp * 2.0, 1.0), 0.5, 1.0); }
    vec4 fa = src(uv - flow * t);
    vec4 fb = in1(uv + flow * (1.0 - t));
    vec4 mc = mix(fa, fb, t);
    vec4 lin = mix(A, in1(uv), t);
    float conf = twSmart > 0.5 ? smoothstep(0.35, 0.05, bestS) : 1.0;
    return mix(lin, mc, conf);
"""))
    return out
}
