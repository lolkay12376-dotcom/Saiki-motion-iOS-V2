//  MetalScene.swift
//  Metal migration stage 4 (part 1): MSL for layer quads + shapes, image/text texture upload,
//  the byte-budgeted LRU image cache and the CVPixelBuffer -> CVMetalTextureCache video sampler.
//
//  UV CONVENTION (same as stage 3): shader uv.y is UP (0 = bottom of the quad). Every Metal
//  texture (images, text, video frames AND render targets) is stored top-row-first, so sampling
//  uses (uv.x, 1 - uv.y). QuadU.flipY = 1 means "texture is top-row-first" (always, in Metal);
//  0 would read the texture with uv.y unflipped (kept only for parity with the GL uniform).

import Foundation
import Metal
import UIKit
import AVFoundation
import CoreVideo

enum MetalSceneSL {
    /// Ports of SceneRenderer.layerQuadVertex (2D subset: uMat, uQuad, uAspect), the quad fragment
    /// (uTex, uFlipY, uColor) and the shape fragment (uKind, uCornerRadius, uColor).
    /// 3D (uRot/uZ/uVP/uInvCam) is ported in clipPos (stage 6a). Puppet meshes: meshVertex / warpVertex.
    static let source = MetalSL.header + """
struct QuadU {
    float4 color;     // uColor
    float4 abcd;      // uMat: a b c d  (Xf affine [a b c d tx ty])
    float2 t;         // uMat: tx ty
    float2 quad;      // uQuad (also the shape size)
    float aspect;     // uAspect
    float flipY;      // uFlipY
    float kind;       // uKind
    float corner;     // uCornerRadius
    float4 rot3;      // 3D: x = uRot.x, y = uRot.y, z = uZ, w = uInvCam
    float4 flags;     // 3D: x = uUseVP, y = 3D path on (else the exact 2D path)
    float4 vp0;       // uVP columns (GL column-major)
    float4 vp1;
    float4 vp2;
    float4 vp3;
};
struct QOut { float4 pos [[position]]; float2 uv; float2 lc; };

inline float glmod(float x, float y) { return x - y * floor(x / y); }

// Port of the GL layerQuadVertex tail: 3D rotation about the layer centre, then camera VP or the
// default z=3 perspective. flags.y = 0 keeps the untouched 2D position.
inline float4 clipPos(float2 w, constant QuadU& u) {
    if (u.flags.y < 0.5) { return float4(w.x / u.aspect, w.y, 0.0, 1.0); }
    float2 c = u.t;
    float3 o = float3(w - c, 0.0);
    float cy = cos(u.rot3.y), sy = sin(u.rot3.y);
    o = float3(o.x * cy + o.z * sy, o.y, -o.x * sy + o.z * cy);
    float cx = cos(u.rot3.x), sx = sin(u.rot3.x);
    o = float3(o.x, o.y * cx - o.z * sx, o.y * sx + o.z * cx);
    float3 pos = float3(c + o.xy, o.z + u.rot3.z);
    if (u.flags.x > 0.5) {
        float4 cl = u.vp0 * pos.x + u.vp1 * pos.y + u.vp2 * pos.z + u.vp3;
        if (cl.w < 0.02) { return float4(2.0, 2.0, 0.0, 1.0); }
        return float4(cl.x, cl.y, 0.0, cl.w);
    }
    return float4(pos.x / u.aspect, pos.y, 0.0, 1.0 - pos.z * u.rot3.w);
}

vertex QOut quadVertex(uint vid [[vertex_id]], constant QuadU& u [[buffer(0)]]) {
    // triangle strip: (0,0) (1,0) (0,1) (1,1); pu.y = 1 is the TOP of the quad
    float2 pu = float2(float(vid & 1u), float(vid >> 1u));
    float2 lc = (pu - 0.5) * u.quad;
    // GL: w = uMat * vec3(lc, 1) with uMat columns (a,b,0) (c,d,0) (tx,ty,1)
    float2 w = float2(u.abcd.x * lc.x + u.abcd.z * lc.y + u.t.x,
                      u.abcd.y * lc.x + u.abcd.w * lc.y + u.t.y);
    QOut o;
    o.pos = clipPos(w, u);
    o.uv = pu;
    o.lc = lc;
    return o;
}

// Puppet mesh: vertices come from two device buffers (expanded triangle list). pos is the deformed
// quad-space position in [-1,1] (same as GL aPos), uvs the rest uv (uv.y up, like the GL aUv).
vertex QOut meshVertex(uint vid [[vertex_id]], constant QuadU& u [[buffer(0)]],
                       const device float2* mpos [[buffer(1)]], const device float2* muv [[buffer(2)]]) {
    float2 pu = mpos[vid] * 0.5 + 0.5;
    float2 lc = (pu - 0.5) * u.quad;
    float2 w = float2(u.abcd.x * lc.x + u.abcd.z * lc.y + u.t.x,
                      u.abcd.y * lc.x + u.abcd.w * lc.y + u.t.y);
    QOut o;
    o.pos = clipPos(w, u);
    o.uv = muv[vid];
    o.lc = lc;
    return o;
}

// Group puppet warp: positions are already clip space (GL warpProg).
vertex QOut warpVertex(uint vid [[vertex_id]], constant QuadU& u [[buffer(0)]],
                       const device float2* mpos [[buffer(1)]], const device float2* muv [[buffer(2)]]) {
    QOut o;
    o.pos = float4(mpos[vid], 0.0, 1.0);
    o.uv = muv[vid];
    o.lc = float2(0.0);
    return o;
}

fragment float4 quadFragment(QOut in [[stage_in]], constant QuadU& u [[buffer(0)]],
                             texture2d<float> tex [[texture(0)]]) {
    float2 p = u.flipY > 0.5 ? float2(in.uv.x, 1.0 - in.uv.y) : in.uv;
    return tex.sample(linearClamp, p) * u.color;
}


inline float sdBox2(float2 p, float2 b) { float2 d = abs(p) - b; return length(max(d, float2(0.0))) + min(max(d.x, d.y), 0.0); }
inline float sdPoly(float2 p, float n, float R) {
    float an = 3.14159265 / n;
    float bn = glmod(atan2(p.x, p.y), 2.0 * an) - an;
    float2 q = length(p) * float2(cos(bn), abs(sin(bn)));
    q -= R * float2(cos(an), sin(an));
    q.y += clamp(-q.y, 0.0, R * sin(an));
    return length(q) * sign(q.x);
}
inline float sdTri(float2 p, float2 a, float2 b, float2 c) {
    float2 e0 = b - a; float2 e1 = c - b; float2 e2 = a - c;
    float2 v0 = p - a; float2 v1 = p - b; float2 v2 = p - c;
    float2 pq0 = v0 - e0 * clamp(dot(v0, e0) / dot(e0, e0), 0.0, 1.0);
    float2 pq1 = v1 - e1 * clamp(dot(v1, e1) / dot(e1, e1), 0.0, 1.0);
    float2 pq2 = v2 - e2 * clamp(dot(v2, e2) / dot(e2, e2), 0.0, 1.0);
    float s = sign(e0.x * e2.y - e0.y * e2.x);
    float2 d = min(min(float2(dot(pq0, pq0), s * (v0.x * e0.y - v0.y * e0.x)),
                     float2(dot(pq1, pq1), s * (v1.x * e1.y - v1.y * e1.x))),
                     float2(dot(pq2, pq2), s * (v2.x * e2.y - v2.y * e2.x)));
    return -sqrt(d.x) * sign(d.y);
}
inline float sdHeart(float2 p) {
    p.x = abs(p.x);
    if (p.y + p.x > 1.0) { float2 t = p - float2(0.25, 0.75); return sqrt(dot(t, t)) - 0.35355339; }
    float2 a = p - float2(0.0, 1.0);
    float2 b = p - 0.5 * max(p.x + p.y, 0.0);
    return sqrt(min(dot(a, a), dot(b, b))) * sign(p.x - p.y);
}
inline float smin2(float a, float b, float k) { float h = clamp(0.5 + 0.5 * (b - a) / k, 0.0, 1.0); return mix(b, a, h) - k * h * (1.0 - h); }
inline float shapeSd(float2 q, float2 qs, float kind, float rr, float th) {
    float mm = max(0.5 * min(qs.x, qs.y), 0.0001);
    float2 p = q / max(qs * 0.5, float2(0.0001));
    float rn = clamp(rr / mm, 0.0, 0.9);
    float sd = 1.0;
    if (kind < 8.5) {
        float n = 4.0;
        if (kind > 5.5) n = 6.0;
        if (kind > 6.5) n = 5.0;
        if (kind > 7.5) n = 8.0;
        float cv = cos(3.14159265 / n);
        float R = max(1.0 - rn / cv, 0.02);
        sd = sdPoly(p, n, R) - (1.0 - R) * cv;
    } else if (kind < 9.5) {
        float hy = max(th * 0.6, 0.04);
        float sdS = sdBox2(p - float2(-0.325, 0.0), max(float2(0.675, hy) - float2(rn), float2(0.0))) - rn;
        float2 cc = float2(0.4667, 0.0);
        float k = max(1.0 - rn * 1.5, 0.2);
        float sdH = sdTri(p, cc + (float2(0.2, 0.95) - cc) * k, cc + (float2(0.2, -0.95) - cc) * k, cc + (float2(1.0, 0.0) - cc) * k) - rn * 0.7;
        sd = smin2(sdS, sdH, max(rn * 0.3, 0.0001));
    } else if (kind < 10.5) {
        float xc = 0.4 - 0.9 * abs(p.y);
        float band = (abs(p.x - xc) - 0.3) * 0.743;
        float kk = max(rn * 0.5, 0.0001);
        sd = -smin2(-band, 1.0 - abs(p.y), kk);
    } else if (kind < 11.5) {
        float t = clamp(th * 0.5, 0.03, 0.48);
        float a1 = sdBox2(p, max(float2(1.0, t) - float2(rn), float2(0.0))) - rn;
        float a2 = sdBox2(p, max(float2(t, 1.0) - float2(rn), float2(0.0))) - rn;
        sd = smin2(a1, a2, max(rn * 0.6, 0.0001));
    } else if (kind < 12.5) {
        float2 u = float2(p.x * 0.6036, (p.y + 1.0) * 0.5518);
        sd = sdHeart(u) / 0.58;
    } else if (kind < 13.5) {
        float t = clamp(th, 0.05, 0.95);
        sd = abs(length(p) - (1.0 - t * 0.5)) - t * 0.5;
    } else {
        sd = (length(p) - 1.0) * 0.75;
    }
    return sd * mm;
}

fragment float4 shapeFragment(QOut in [[stage_in]], constant QuadU& u [[buffer(0)]]) {
    float2 q = in.lc;
    float2 qs = u.quad;
    float cr = u.corner;
    float a = 0.0;
    if (u.kind < 0.5) {
        a = 1.0;
    } else if (u.kind < 1.5) {
        float2 d = abs(q) - (qs * 0.5 - float2(cr));
        float outD = length(max(d, float2(0.0))) + min(max(d.x, d.y), 0.0) - cr;
        a = 1.0 - smoothstep(-0.004, 0.004, outD);
    } else if (u.kind < 2.5) {
        float m = min(qs.x, qs.y);
        a = 1.0 - smoothstep(0.48 * m, 0.5 * m, length(q));
    } else if (u.kind < 3.5) {
        float2 v1 = float2(-qs.x * 0.5, -qs.y * 0.5) - q;
        float2 v2 = float2(qs.x * 0.5, -qs.y * 0.5) - q;
        float2 v3 = q - float2(-qs.x * 0.5, -qs.y * 0.5);
        float s1 = v1.x * v2.y - v1.y * v2.x;
        float s2 = v2.x * v3.y - v2.y * v3.x;
        float s3 = v3.x * (-v1.y) - v3.y * (-v1.x);
        a = ((s1 >= 0.0 && s2 >= 0.0 && s3 >= 0.0) || (s1 <= 0.0 && s2 <= 0.0 && s3 <= 0.0)) ? 1.0 : 0.0;
    } else if (u.kind > 4.5) {
        a = 1.0 - smoothstep(-0.004, 0.004, shapeSd(q, qs, u.kind, cr, u.flags.z));
    } else {
        float n = 5.0;
        float a0 = atan2(q.y, q.x) + 1.5708;
        float seg = 6.2831 / n;
        float m = min(qs.x, qs.y);
        float rIn = 0.22 * m;
        float rOut = 0.5 * m;
        float ang = glmod(a0, seg) - seg * 0.5;
        float rLim = mix(rOut, rIn, abs(ang) / (seg * 0.5));
        a = 1.0 - smoothstep(rLim - 0.01, rLim + 0.01, length(q));
    }
    // same as GL: rgb * a, alpha * a (the colour is not multiplied by its own alpha)
    return float4(u.color.rgb * a, u.color.a * a);
}
"""
}

/// Must match QuadU in MSL byte for byte (160 bytes, 16-aligned).
struct QuadU {
    var color = SIMD4<Float>(1, 1, 1, 1)
    var abcd = SIMD4<Float>(1, 0, 0, 1)
    var t = SIMD2<Float>(0, 0)
    var quad = SIMD2<Float>(2, 2)
    var aspect: Float = 1
    var flipY: Float = 1
    var kind: Float = 0
    var corner: Float = 0.12
    var rot3 = SIMD4<Float>(0, 0, 0, 0)
    var flags = SIMD4<Float>(0, 0, 0, 0)
    var vp0 = SIMD4<Float>(0, 0, 0, 0)
    var vp1 = SIMD4<Float>(0, 0, 0, 0)
    var vp2 = SIMD4<Float>(0, 0, 0, 0)
    var vp3 = SIMD4<Float>(0, 0, 0, 0)
}

// MARK: - image upload

enum MetalImageUpload {
    /// Decoded size in bytes when scaled so the longest side is <= maxSide (mirrors Gl.uploadBytes).
    static func byteCount(_ image: UIImage, maxSide: Int) -> Int {
        guard let cg = image.cgImage, cg.width > 0, cg.height > 0 else { return 0 }
        let sc = min(1.0, Double(maxSide) / Double(max(cg.width, cg.height)))
        return max(1, Int(Double(cg.width) * sc)) * max(1, Int(Double(cg.height) * sc)) * 4
    }

    /// UIImage -> premultiplied RGBA8 MTLTexture, rows top-first (CGContext memory order). Mirrors Gl.upload.
    static func texture(_ core: MetalCore, _ image: UIImage, maxSide: Int = 4096) -> (tex: MTLTexture, bytes: Int)? {
        guard let cg = image.cgImage, cg.width > 0, cg.height > 0 else { return nil }
        let sc = min(1.0, Double(maxSide) / Double(max(cg.width, cg.height, 1)))
        let w = max(1, Int(Double(cg.width) * sc)), h = max(1, Int(Double(cg.height) * sc))
        var data = [UInt8](repeating: 0, count: w * h * 4)
        let drew: Bool = data.withUnsafeMutableBytes { raw -> Bool in
            guard let ctx = CGContext(data: raw.baseAddress, width: w, height: h, bitsPerComponent: 8,
                                      bytesPerRow: w * 4, space: CGColorSpaceCreateDeviceRGB(),
                                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            ctx.setBlendMode(.copy)
            ctx.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h))
            return true
        }
        guard drew else { return nil }
        let d = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .rgba8Unorm, width: w, height: h, mipmapped: false)
        d.usage = .shaderRead
        d.storageMode = .shared
        guard let t = core.device.makeTexture(descriptor: d) else { return nil }
        data.withUnsafeBytes {
            t.replace(region: MTLRegionMake2D(0, 0, w, h), mipmapLevel: 0,
                      withBytes: $0.baseAddress!, bytesPerRow: w * 4)
        }
        return (t, w * h * 4)
    }
}

// MARK: - image cache (port of SceneRenderer.imageTexture, byte-budgeted LRU)

final class MetalImageCache {
    private let core: MetalCore
    private var tex: [String: MTLTexture] = [:]
    private var bytes: [String: Int] = [:]
    private var order: [String] = []        // least recently used first
    private var total = 0
    private var side = 0
    let budget = 360 * 1_048_576

    init(_ core: MetalCore) { self.core = core }

    var totalBytes: Int { total }

    func texture(path: String, quality: Int) -> MTLTexture? {
        let s = max(384, 1536 / max(1, quality))
        if s != side { flush(); side = s }
        if let t = tex[path] {
            if order.last != path {
                if let i = order.firstIndex(of: path) { order.remove(at: i) }
                order.append(path)
            }
            return t
        }
        var made: (tex: MTLTexture, bytes: Int)?
        autoreleasepool {
            guard let img = UIImage(contentsOfFile: path) else { return }
            made = MetalImageUpload.texture(core, img, maxSide: s)
        }
        guard let m = made else { return nil }
        tex[path] = m.tex
        bytes[path] = m.bytes
        total += m.bytes
        order.append(path)
        while total > budget, order.count > 1 {
            let old = order.removeFirst()
            tex.removeValue(forKey: old)            // ARC frees the MTLTexture once in-flight work is done
            total -= bytes.removeValue(forKey: old) ?? 0
        }
        return m.tex
    }

    func flush() {
        tex.removeAll(); bytes.removeAll(); order.removeAll(); total = 0
    }
}

// MARK: - video frames (CVPixelBuffer -> CVMetalTextureCache)

/// Per-layer async frame source, same 10-frames-per-second bucketing as VideoFrames.Sampler.
/// Frames are decoded with AVAssetReader (BGRA, preferred transform applied) and wrapped as
/// MTLTextures through a CVMetalTextureCache (no CPU copy).
final class MetalVideoSampler {
    private let asset: AVURLAsset
    private let queue: DispatchQueue
    private var cache: CVMetalTextureCache?
    private let lock = NSLock()
    private var current: MTLTexture?
    private var currentRef: CVMetalTexture?     // keeps the pixel buffer alive while `current` is in use
    private var bucket = -1
    private var pending = -1
    /// Fired on the main thread after a fresh frame arrives.
    var onFrame: (() -> Void)?
    /// Frame-cache buckets per second (10 for normal playback; Twixtor uses the source frame rate).
    var bucketsPerSec: Float = 10

    init(path: String, device: MTLDevice) {
        asset = VideoFrames.asset(path)
        queue = DispatchQueue(label: "saiki.metalvideo.\(abs(path.hashValue))")
        CVMetalTextureCacheCreate(kCFAllocatorDefault, nil, device, nil, &cache)
    }

    /// The newest frame at/near `srcTime` (returns the previous frame while the next one decodes).
    func texture(at srcTime: Float) -> MTLTexture? {
        let b = Int(max(0, srcTime) * bucketsPerSec + 1e-3)
        lock.lock()
        let cur = current
        let have = (b == bucket) || (b == pending)
        if !have { pending = b }
        lock.unlock()
        if !have {
            queue.async { [weak self] in self?.generate(srcTime, bucket: b) }
        }
        return cur
    }

    private func generate(_ t: Float, bucket b: Int) {
        var made: MTLTexture?
        var ref: CVMetalTexture?
        autoreleasepool {
            guard let cache = cache,
                  let track = asset.tracks(withMediaType: .video).first,
                  let reader = try? AVAssetReader(asset: asset) else { return }
            let settings: [String: Any] = [
                kCVPixelBufferPixelFormatTypeKey as String: Int(kCVPixelFormatType_32BGRA),
                kCVPixelBufferMetalCompatibilityKey as String: true,
                kCVPixelBufferIOSurfacePropertiesKey as String: [String: Any](),
            ]
            let out = AVAssetReaderVideoCompositionOutput(videoTracks: [track], videoSettings: settings)
            out.videoComposition = AVMutableVideoComposition(propertiesOf: asset)   // applies the rotation
            reader.timeRange = CMTimeRange(start: CMTime(seconds: Double(max(0, t)), preferredTimescale: 600),
                                           duration: CMTime(seconds: 0.5, preferredTimescale: 600))
            guard reader.canAdd(out) else { return }
            reader.add(out)
            guard reader.startReading(),
                  let sb = out.copyNextSampleBuffer(),
                  let pb = CMSampleBufferGetImageBuffer(sb) else { return }
            let w = CVPixelBufferGetWidth(pb), h = CVPixelBufferGetHeight(pb)
            var cvt: CVMetalTexture?
            let st = CVMetalTextureCacheCreateTextureFromImage(kCFAllocatorDefault, cache, pb, nil,
                                                               .bgra8Unorm, w, h, 0, &cvt)
            if st == kCVReturnSuccess, let c = cvt, let tx = CVMetalTextureGetTexture(c) {
                made = tx
                ref = c
            }
            reader.cancelReading()
        }
        lock.lock()
        if let m = made { current = m; currentRef = ref }
        bucket = b
        pending = -1
        lock.unlock()
        if made != nil {
            DispatchQueue.main.async { [weak self] in self?.onFrame?() }
        }
    }
}
