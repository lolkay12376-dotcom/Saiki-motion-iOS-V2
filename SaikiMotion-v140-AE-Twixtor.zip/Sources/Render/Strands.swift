// Strands.swift — BCC Organic Strands: deterministic 3D strand field (pure function of seed + time).
// Strands are returned as particles in layer-local 3D space, so MetalParticleRenderer draws them with the same
// layer transform, 3D rotation, comp camera / default perspective and depth sort as the Particles effect.
import Foundation
import simd

enum StrandsSim {
    private static func h(_ x: Float) -> Float { let s = sin(x * 127.1 + 311.7) * 43758.5453; return s - floor(s) }

    private static func lat(_ x: Int, _ y: Int, _ z: Int, _ seed: Float) -> Float {
        h(Float(x) * 1.0 + Float(y) * 57.0 + Float(z) * 113.0 + seed * 17.0)
    }
    /// Smooth 3D value noise in 0...1.
    static func noise3(_ x: Float, _ y: Float, _ z: Float, _ seed: Float) -> Float {
        let xi = Int(floor(x)), yi = Int(floor(y)), zi = Int(floor(z))
        let fx = x - floor(x), fy = y - floor(y), fz = z - floor(z)
        let ux = fx * fx * (3 - 2 * fx), uy = fy * fy * (3 - 2 * fy), uz = fz * fz * (3 - 2 * fz)
        func l2(_ a: Float, _ b: Float, _ t: Float) -> Float { a + (b - a) * t }
        let c00 = l2(lat(xi, yi, zi, seed), lat(xi + 1, yi, zi, seed), ux)
        let c10 = l2(lat(xi, yi + 1, zi, seed), lat(xi + 1, yi + 1, zi, seed), ux)
        let c01 = l2(lat(xi, yi, zi + 1, seed), lat(xi + 1, yi, zi + 1, seed), ux)
        let c11 = l2(lat(xi, yi + 1, zi + 1, seed), lat(xi + 1, yi + 1, zi + 1, seed), ux)
        return l2(l2(c00, c10, uy), l2(c01, c11, uy), uz)
    }

    static func field(_ l: Layer, lt: Float, t: Float) -> [Particle] {
        func P(_ k: String) -> Float { l.p(k, lt) }
        let seed = P("stSeed")
        let nStr = max(1, min(Int(P("stCount")), 600))
        let dens = max(2, min(Int(P("stDensity")), 150))
        let total = min(nStr * dens, 40000)
        let per = max(2, total / nStr)
        let pd = Float.pi / 180
        // strand direction basis
        var dir = SIMD3<Float>(P("stDirX"), P("stDirY"), P("stDirZ"))
        if simd_length_sq(dir) < 1e-6 { dir = SIMD3(0, 1, 0) }
        dir = simd_normalize(dir)
        let up: SIMD3<Float> = abs(dir.y) > 0.95 ? SIMD3(1, 0, 0) : SIMD3(0, 1, 0)
        let tu = simd_normalize(simd_cross(dir, up)), tv = simd_cross(dir, tu)
        let spread = P("stSpread") * pd
        let len0 = P("stLength"), lenVar = P("stLenVar")
        let thick = P("stThick"), thickVar = P("stThickVar"), taper = P("stTaper")
        let grav = P("stGravity")
        let shape = Int(P("stShape").rounded())
        let sc = SIMD3<Float>(P("stScaleX"), P("stScaleY"), P("stScaleZ"))
        let bend = P("stBend"), freq = max(0.05, P("stFreq")), nThick = P("stNThick")
        let evo = SIMD3<Float>(P("stEvX"), P("stEvY"), P("stEvZ")) + SIMD3<Float>(repeating: t * P("stEvSpeed"))
        let indiv = P("stIndiv") > 0.5
        let srcSup = P("stSrcSup"), dstSup = P("stDstSup")
        let destOn = P("stDestOn") > 0.5
        let dest = SIMD3<Float>(P("stDX"), P("stDY"), P("stDZ")), pull = P("stPull")
        let mv = P("stMove") + t * P("stMoveSpeed"), mvRand = P("stMoveRand"), loop = max(0.2, P("stLoop"))
        let gs = P("stGScale"), cen = SIMD3<Float>(P("stCX"), P("stCY"), P("stCZ"))
        let rx = P("stRotX") * pd, ry = P("stRotY") * pd, rz = P("stRotZ") * pd
        let (cx, sx, cy, sy, cz, sz) = (cos(rx), sin(rx), cos(ry), sin(ry), cos(rz), sin(rz))
        let mirror = Int(P("stMirror").rounded())
        let soft = P("stSoft")
        var out: [Particle] = []
        out.reserveCapacity(nStr * per * (mirror == 3 ? 2 : (mirror > 0 ? 2 : 1)))

        for j in 0..<nStr {
            let b = Float(j) * 1.618 + seed * 7.13
            let h1 = h(b), h2 = h(b + 3.7), h3 = h(b + 8.1), h4 = h(b + 12.9), h5 = h(b + 17.3)
            // source point
            var B = SIMD3<Float>(0, 0, 0)
            switch shape {
            case 1: B = SIMD3((h1 - 0.5) * 2 * sc.x, 0, 0)
            case 2: let a = h1 * 2 * .pi; B = SIMD3(cos(a) * sc.x, sin(a) * sc.y, 0)
            case 3:
                let z = h1 * 2 - 1, a = h2 * 2 * .pi, r = (1 - z * z).squareRoot()
                B = SIMD3(r * cos(a) * sc.x, r * sin(a) * sc.y, z * sc.z)
            case 4: B = SIMD3((h1 - 0.5) * 2 * sc.x, (h2 - 0.5) * 2 * sc.y, 0)
            default: break
            }
            // direction inside the spread cone
            let ca = spread * h3.squareRoot(), az = h4 * 2 * .pi
            let d = simd_normalize(dir * cos(ca) + (tu * cos(az) + tv * sin(az)) * sin(ca))
            let L = len0 * (1 + (h5 - 0.5) * 2 * lenVar)
            let tk = thick * (1 + (h3 - 0.5) * 2 * thickVar)
            let nOff = indiv ? SIMD3<Float>(h1, h2, h3) * 20 : SIMD3<Float>(0, 0, 0)
            let mvj = mv + mvRand * h2 * loop

            for i in 0..<per {
                let u = Float(i) / Float(per - 1)
                let a = (u + mvj) / loop
                let s = (a - floor(a))            // 0...1 along the strand (loops back to the source)
                let sa = s * loop
                var p = B + d * (L * sa)
                p.y -= grav * L * sa * sa * 0.5
                if destOn { p = p + (dest - (B + d * (L * sa))) * pull * sa }
                let q = (p * freq + evo + nOff)
                let n = SIMD3<Float>(noise3(q.x, q.y, q.z, seed) - 0.5, noise3(q.x + 31.4, q.y, q.z, seed) - 0.5,
                                     noise3(q.x, q.y + 17.9, q.z + 5.5, seed) - 0.5)
                let ramp = (1 - srcSup) + srcSup * min(1, sa / 0.3 * (1 / max(len0, 0.001)) * 0.3)
                let tip = (1 - dstSup) + dstSup * (1 - s * s)
                p += n * (bend * 2 * L * sa * ramp * tip)
                let nt = noise3(q.x * 1.7 + 9, q.y * 1.7, q.z * 1.7, seed + 1)
                var size = tk * max(0.04, 1 - taper * s) * (1 + nThick * (nt - 0.5) * 2)
                size = max(0.02, size)
                // global scale + rotation + centre
                var v = p * gs
                var y1 = v.y * cx - v.z * sx, z1 = v.y * sx + v.z * cx; v.y = y1; v.z = z1
                let x2 = v.x * cy + v.z * sy; z1 = -v.x * sy + v.z * cy; v.x = x2; v.z = z1
                let x3 = v.x * cz - v.y * sz; y1 = v.x * sz + v.y * cz; v.x = x3; v.y = y1
                v += cen
                size *= gs
                out.append(Particle(x: v.x, y: v.y, z: v.z, size: size, life: s, soft: soft))
                if mirror == 1 || mirror == 3 { out.append(Particle(x: -v.x, y: v.y, z: v.z, size: size, life: s, soft: soft)) }
                else if mirror == 2 { out.append(Particle(x: v.x, y: -v.y, z: v.z, size: size, life: s, soft: soft)) }
            }
        }
        return out
    }
}
