// Particular.swift — 3D particle emitter (Render). Pure function of (params, time): scrubbing, caching and export match.
// Positions are layer-local 3D (x/y world units, z depth); the Metal particle renderer projects them with the comp camera.

import Foundation

enum ParticularSim {
    static let emitterNames = ["Point", "Box", "Sphere", "Grid"]
    static let motionNames = ["Default", "Bidirectional", "Directional", "Disc", "Inward"]

    static func field(_ g: (String) -> Float, t: Float) -> [Particle] {
        let life = max(g("ptLife"), 0.1)
        let n = max(1, min(Int(g("ptRate") * life), 6000))
        let seed = g("ptSeed")
        let em = Int(g("ptEmType").rounded()), mo = Int(g("ptMotion").rounded())
        let explode = g("ptBehavior") >= 0.5
        let sx = g("ptSizeX") * 0.5, sy = g("ptSizeY") * 0.5, sz = g("ptSizeZ") * 0.5
        let px = g("ptPosX"), py = g("ptPosY"), pz = g("ptPosZ")
        let vel = g("ptVel"), vr = g("ptVelRand"), spread = g("ptSpread"), lr = g("ptLifeRand")
        var ax = g("ptDirX"), ay = g("ptDirY"), az = g("ptDirZ")
        let al = max((ax * ax + ay * ay + az * az).squareRoot(), 0.0001)
        ax /= al; ay /= al; az /= al
        let grav = g("ptGravity"), wx = g("ptWindX"), wy = g("ptWindY"), wz = g("ptWindZ")
        let air = g("ptAir"), turb = g("ptTurb"), tf = max(g("ptTurbFreq"), 0.05)
        let szr = g("ptSizeRand"), s0 = g("ptSizeStart"), s1 = g("ptSizeEnd")
        let softB = g("ptSoft"), dof = g("ptDof"), focus = g("ptFocus")
        let cells = max(2, Int(g("ptGridN").rounded()))
        let cells3 = cells * cells * cells
        func gf(_ k: Int) -> Float { Float(k) / Float(cells - 1) - 0.5 }
        var out: [Particle] = []
        out.reserveCapacity(n)
        let time = max(0, t)
        for i in 0..<n {
            let fi = Float(i)
            let h0 = hash(seed * 131 + fi), h1 = hash(seed * 977 + fi * 7), h2 = hash(seed * 3313 + fi * 13)
            let h3 = hash(seed * 6151 + fi * 29), h4 = hash(seed * 17 + fi * 3), h5 = hash(seed * 4001 + fi * 19)
            let h6 = hash(seed * 811 + fi * 23), h7 = hash(seed * 523 + fi * 31)
            let lf = max(0.05, life * (1 - lr * h6 * 0.8))
            var age = explode ? time : time - h0 * lf
            age = age.truncatingRemainder(dividingBy: lf)
            if age < 0 { age += lf }
            let p = age / lf

            var bx: Float = 0, by: Float = 0, bz: Float = 0
            switch em {
            case 1:
                bx = (h1 * 2 - 1) * sx; by = (h2 * 2 - 1) * sy; bz = (h5 * 2 - 1) * sz
            case 2:
                let u = h2 * 2 - 1, a = h1 * 6.2831853, r = cbrt(h5), rr = (1 - u * u).squareRoot()
                bx = rr * cos(a) * r * sx; by = rr * sin(a) * r * sy; bz = u * r * sz
            case 3:
                let c = i % cells3
                bx = gf(c % cells) * 2 * sx; by = gf((c / cells) % cells) * 2 * sy; bz = gf(c / (cells * cells)) * 2 * sz
            default: break
            }

            let u = h3 * 2 - 1, a = h4 * 6.2831853, rr = (1 - u * u).squareRoot()
            let rx = rr * cos(a), ry = rr * sin(a), rz = u
            var vx = rx, vy = ry, vz = rz
            switch mo {
            case 1:
                let s: Float = h0 < 0.5 ? -1 : 1
                vx = ax * s + rx * spread; vy = ay * s + ry * spread; vz = az * s + rz * spread
            case 2:
                vx = ax + rx * spread; vy = ay + ry * spread; vz = az + rz * spread
            case 3:
                let d = rx * ax + ry * ay + rz * az
                vx = rx - d * ax; vy = ry - d * ay; vz = rz - d * az
            case 4:
                let l = max((bx * bx + by * by + bz * bz).squareRoot(), 0.0001)
                vx = -bx / l + rx * spread * 0.3; vy = -by / l + ry * spread * 0.3; vz = -bz / l + rz * spread * 0.3
            default: break
            }
            let spd = vel * (1 - vr * h7)
            var travel = age
            if air > 0.001 { let k = air * 4; travel = (1 - exp(-k * age)) / k }
            var x = bx + vx * spd * travel + 0.5 * wx * age * age
            var y = by + vy * spd * travel + 0.5 * (wy - grav) * age * age
            var z = bz + vz * spd * travel + 0.5 * wz * age * age
            if turb > 0.001 {
                let ph = age * 0.9 + h1 * 6.2831853
                x += sin(y * tf * 3 + ph) * turb * 0.15
                y += sin(z * tf * 3 + ph * 1.3 + 1.7) * turb * 0.15
                z += sin(x * tf * 3 + ph * 0.7 + 3.1) * turb * 0.15
            }
            x += px; y += py; z += pz
            let base = (1 - szr) + szr * h2 * 1.8
            let size = base * (s0 + (s1 - s0) * p)
            let soft = min(1, max(0, softB + abs(z - focus) * dof * 0.8))
            out.append(Particle(x: x, y: y, z: z, size: size, life: p, soft: soft))
        }
        return out
    }

    private static func hash(_ x: Float) -> Float {
        var n = UInt32(truncatingIfNeeded: Int64(x * 8192.0))
        n = n &* 747796405 &+ 2891336453
        n = ((n >> ((n >> 28) + 4)) ^ n) &* 277803737
        n = (n >> 22) ^ n
        return Float(n % 100000) / 100000
    }
}
