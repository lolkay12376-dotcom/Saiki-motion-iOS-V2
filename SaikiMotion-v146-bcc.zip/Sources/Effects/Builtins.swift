// Builtins.swift — the built-in effect catalog (Effects).
//
// Every effect the shipped app had, as GLSL `vec4 effect(vec2 uv)` bodies
// plus their parameter tables. The renderer wraps each body in the SDK
// prelude (src/luma/noise/... helpers + uniforms), so these bodies read
// exactly like user-written SDK effects — the bundled examples ARE the same
// files (Resources/sdk/examples) with these definitions.
//
// Convention: uv is 0..1 across the layer; `src(uv)` is the layer pixel
// (straight alpha); parameters arrive as uniforms named exactly like their
// effect.json keys.

import Foundation

// MARK: - light and glow

private func lightGlow() -> [EffectDef] {
    var out: [EffectDef] = []
    out.append(EffectDef(
        id: "deepglow", name: "Deep Glow", desc: "Multi-scale Gaussian bloom that spills past the edges.",
        category: "Light and glow", props: [
            PropDef("radius", "Radius", 0, 1.5, 0.12, 3),
            PropDef("intensity", "Intensity", 0, 100, 1, 2),
            PropDef("threshold", "Threshold", 0, 1, 0.3, 2),
            PropDef("knee", "Threshold softness", 0, 1, 0.5, 2),
            PropDef("falloff", "Falloff (tight → wide halo)", 0, 1, 0.5, 2),
            PropDef("tintAmt", "Tint amount", 0, 1, 0, 2),
            PropDef("tintHue", "Tint hue", 0, 1, 0.08, 2),
            PropDef("chroma", "Chromatic aberration", 0, 1, 0, 2),
            PropDef("glowOnly", "Glow only (0 / 1)", 0, 1, 0, 0),
        ], glsl: """
    vec4 c = src(uv);
    vec2 asp = vec2(uRes.y / uRes.x, 1.0);
    vec3 gsum = vec3(0.0);
    float ga = 0.0;
    for (int s = 0; s < 3; s++) {
        float R = radius * (s == 0 ? 0.2 : (s == 1 ? 0.5 : 1.0));
        float sw = s == 0 ? 0.45 : (s == 1 ? 0.35 : 0.3);
        vec4 acc = vec4(0.0);
        float ws = 0.0;
        float ang0 = float(s) * 1.1;   // fixed per-scale twist: smooth bloom, no per-pixel noise
        for (int i = 0; i < 24; i++) {
            float f = (float(i) + 0.5) / 24.0;
            float r = sqrt(f);
            float an = float(i) * 2.39996 + ang0;
            vec2 o = vec2(cos(an), sin(an)) * (r * R) * asp;
            float w = exp(-r * r * 4.5);
            vec4 t = src(uv + o);
            float l = max(max(t.r, t.g), t.b);   // premultiplied brightness (alpha-divide blew soft glows out)
            float m = clamp((l - threshold) / max(0.001, 1.0 - threshold), 0.0, 1.0);
            m = m * m * (3.0 - 2.0 * m);
            acc += vec4(t.rgb * m, t.a * m) * w;
            ws += w;
        }
        acc /= ws;
        gsum += acc.rgb * sw;
        ga += acc.a * sw;
    }
    vec3 rgb = c.rgb + gsum * intensity * 1.5;
    float a = clamp(c.a + ga * intensity * 1.5 * (1.0 - c.a), 0.0, 1.0);
    return vec4(rgb, a);
"""))
    out.append(EffectDef(
        id: "lightsweep", name: "CC Light Sweep", desc: "After Effects style light sweep: angled band with shape, edge highlight, color and light reception.",
        category: "Light and glow", props: [
            PropDef("centerX", "Center X", -0.6, 1.6, 0.5, 3),
            PropDef("centerY", "Center Y", -0.6, 1.6, 0.5, 3),
            PropDef("direction", "Direction", -360, 360, 45, 1),
            PropDef("offset", "Offset (px)", -3000, 3000, 0, 1),
            PropDef("shape", "Shape", 0, 2, 0, 0, ["Linear", "Smooth", "Sharp"]),
            PropDef("bandW", "Width (px)", 0, 1000, 30, 1),
            PropDef("sweepInt", "Sweep Intensity", 0, 100, 30, 1),
            PropDef("edgeInt", "Edge Intensity", 0, 100, 100, 1),
            PropDef("edgeThick", "Edge Thickness", 0, 100, 70, 1),
            PropDef("reception", "Light Reception", 0, 2, 0, 0, ["Add", "Composite", "Cutout"]),
            PropDef("colorMode", "Color Mode", 0, 2, 0, 0, ["Solid", "Gradient", "Rainbow"]),
            PropDef("colorSpread", "Rainbow Spread", 0.1, 3, 1, 2),
            PropDef("hueOffset", "Hue Offset", 0, 1, 0, 2),
            PropDef("edgeColorMix", "Edge Color Mix", 0, 1, 0, 2),
        ], colors: [
            ColorParam("lightColor", "Light Color", Int32(bitPattern: 0xFFFFFFFF)),
            ColorParam("lightColor2", "Gradient End Color", Int32(bitPattern: 0xFFFF9A3C)),
            ColorParam("edgeColor", "Edge Color", Int32(bitPattern: 0xFFFFFFFF)),
        ], glsl: """
    vec4 c = src(uv);
    float a = radians(direction);
    vec2 n = vec2(cos(a), sin(a));                 // band normal: 0 deg = vertical band moving sideways
    vec2 p = (uv - vec2(centerX, centerY)) * uRes; // pixels from Center
    float hw = max(bandW, 0.5);
    float t = abs(dot(p, n) - offset) / hw;                // 0 at band centre, 1 at band edge
    float inside = 1.0 - t;
    float m;
    if (shape < 0.5) {
        m = clamp(inside, 0.0, 1.0);                                  // Linear falloff
    } else if (shape < 1.5) {
        float s = clamp(inside, 0.0, 1.0);
        m = s * s * (3.0 - 2.0 * s);                                  // Smooth falloff
    } else {
        m = 1.0 - smoothstep(0.88, 1.0, t);                           // Sharp: flat top, hard edge
    }
    // Edge Intensity / Thickness (as in After Effects): the *contours of the layer itself* (alpha silhouette + brightness edges)
    // light up wherever the sweep band passes, independent of Sweep Intensity (so 0 still shows the lit contours).
    float th = mix(0.6, 7.0, clamp(edgeThick * 0.01, 0.0, 1.0));    // sample distance in px = contour thickness
    vec2 px = th / uRes;
    vec4 cl = src(uv - vec2(px.x, 0.0)), cr = src(uv + vec2(px.x, 0.0));
    vec4 cd = src(uv - vec2(0.0, px.y)), cu = src(uv + vec2(0.0, px.y));
    vec2 gl = vec2(luma(cr.rgb) - luma(cl.rgb), luma(cu.rgb) - luma(cd.rgb));
    vec2 ga = vec2(cr.a - cl.a, cu.a - cd.a);
    float edge = clamp(length(gl) * 2.5 + length(ga) * 1.6, 0.0, 1.0);
    float Ls = sweepInt * 0.01 * m;
    float Le = edgeInt * 0.01 * edge * clamp(m * 1.6, 0.0, 1.0) * 1.5;
    float L = max(Ls + Le, 0.0);
    float across = clamp((dot(p, n) - offset) / hw * 0.5 + 0.5, 0.0, 1.0);
    vec3 sc = lightColor.rgb;
    if (colorMode > 0.5 && colorMode < 1.5) sc = mix(lightColor.rgb, lightColor2.rgb, across);
    else if (colorMode > 1.5) sc = hsv2rgb(vec3(fract(across * colorSpread + hueOffset), 0.75, 1.0));
    vec3 ec = mix(sc, edgeColor.rgb, edgeColorMix);
    vec3 lc = (sc * Ls + ec * Le) / max(Ls + Le, 0.0001);
    if (reception < 0.5) {
        return vec4(c.rgb + lc * L * c.a, c.a);                       // Add
    } else if (reception < 1.5) {
        return vec4(mix(c.rgb, lc * c.a, clamp(L, 0.0, 1.0)), c.a);   // Composite (inside layer alpha)
    }
    return vec4(c.rgb * clamp(L, 0.0, 1.0), c.a * clamp(L, 0.0, 1.0)); // Cutout: layer shows only where lit
"""))
    out.append(EffectDef(
        id: "contour", name: "Contour", desc: "Edge-detecting lines that follow brightness.",
        category: "Light and glow", props: [
            PropDef("strength", "Strength", 0, 3, 1, 2),
            PropDef("width", "Width", 1, 4, 1.6, 2),
        ], glsl: """
    vec2 px = width / uRes;
    float l0 = luma(src(uv).rgb);
    float lx = luma(src(uv + vec2(px.x, 0.0)).rgb);
    float ly = luma(src(uv + vec2(0.0, px.y)).rgb);
    float e = clamp(length(vec2(lx - l0, ly - l0)) * 6.0, 0.0, 1.0);
    return vec4(mix(src(uv).rgb, vec3(1.0), e * strength), src(uv).a);
"""))
    out.append(EffectDef(
        id: "lightleak", name: "Light Leak", desc: "Analog-film light leak from a corner.",
        category: "Light and glow", props: [
            PropDef("amount", "Amount", 0, 2, 0.8, 2),
            PropDef("angle", "Angle", 0, 6.2832, 0.8, 3),
        ], glsl: """
    vec2 p = rot(uv - vec2(0.0, 1.0), angle);
    float d = length(vec2(max(p.x, 0.0), max(p.y, 0.0)));
    float g = exp(-d * 4.0) * amount;
    float streak = exp(-abs(p.y) * 14.0) * exp(-max(-p.x, 0.0) * 3.0) * amount * 0.7;
    vec3 warm = vec3(1.0, 0.72, 0.42);
    vec4 c = src(uv);
    return vec4(c.rgb + warm * (g + streak), c.a);
"""))
    out.append(EffectDef(
        id: "godrays", name: "God Rays", desc: "Radial light shafts from a bright point.",
        category: "Light and glow", props: [
            PropDef("cx", "Source X", -0.5, 1.5, 0.5, 3),
            PropDef("cy", "Source Y", -0.5, 1.5, 0.5, 3),
            PropDef("density", "Density", 0.2, 3, 1, 2),
            PropDef("decay", "Decay", 0.5, 2, 1, 2),
        ], glsl: """
    vec2 dir = (vec2(cx, cy) - uv) * 0.12;
    vec2 p = uv;
    float illum = 0.0;
    for (int i = 0; i < 16; i++) {
        p += dir;
        vec3 s = src(p).rgb;
        illum += max(luma(s) - 0.6, 0.0) * pow(decay, float(i) * 0.12);
    }
    illum /= 16.0;
    illum *= density * 2.4;
    return vec4(src(uv).rgb + vec3(1.0, 0.95, 0.85) * illum, src(uv).a);
"""))
    out.append(EffectDef(
        id: "starburst", name: "Star Burst", desc: "Star sparkles on bright areas.",
        category: "Light and glow", props: [
            PropDef("threshold", "Threshold", 0, 1, 0.7, 2),
            PropDef("size", "Size", 2, 40, 12, 0),
            PropDef("rays", "Rays", 4, 12, 6, 0),
            PropDef("intensity", "Intensity", 0, 2, 0.8, 2),
        ], glsl: """
    float l = luma(src(uv).rgb);
    if (l < threshold) return src(uv);
    vec2 p = (uv - 0.5) * uRes;
    float a = atan(p.y, p.x);
    float r = length(p);
    float star = 0.0;
    for (int i = 0; i < 12; i++) {
        float fi = float(i);
        float rayOn = step(fi + 0.5, rays);   // (was "active": a reserved word in GLSL ES, so this shader never compiled)
        float aa = a + fi * 3.14159 / max(rays * 0.5, 1.0);
        star += rayOn * pow(abs(cos(aa)), max(size, 2.0)) * exp(-r / max(size * 0.5, 0.5));
    }
    star *= intensity * smoothstep(threshold, 1.0, l);
    return vec4(src(uv).rgb + vec3(star), src(uv).a);
"""))
    out.append(EffectDef(
        id: "softfocus", name: "Soft Focus", desc: "Dreamy diffusion that keeps detail.",
        category: "Light and glow", props: [
            PropDef("amount", "Amount", 0, 1, 0.5, 2),
            PropDef("radius", "Radius", 0, 0.1, 0.015, 3),
        ], glsl: """
    vec4 c = src(uv);
    vec3 blur = vec3(0.0);
    blur += src(uv + vec2(radius, radius)).rgb;
    blur += src(uv + vec2(-radius, radius)).rgb;
    blur += src(uv + vec2(radius, -radius)).rgb;
    blur += src(uv + vec2(-radius, -radius)).rgb;
    blur *= 0.25;
    vec3 hi = max(blur - c.rgb, vec3(0.0));
    return vec4(c.rgb + mix(blur - c.rgb, hi * 1.4, 0.5) * amount * 0.8 + hi * amount * 0.4, c.a);
"""))
    out.append(EffectDef(
        id: "bokeh", name: "Bokeh", desc: "Out-of-focus discs on highlights.",
        category: "Light and glow", props: [
            PropDef("size", "Disc size", 4, 64, 20, 0),
            PropDef("threshold", "Threshold", 0, 1, 0.65, 2),
            PropDef("intensity", "Intensity", 0, 2, 0.7, 2),
        ], glsl: """
    vec4 c = src(uv);
    vec2 px = size / uRes;
    vec3 acc = vec3(0.0);
    float wsum = 0.0;
    for (int i = 0; i < 12; i++) {
        float a = float(i) * 0.5236;
        vec2 o = vec2(cos(a), sin(a)) * px;
        vec3 s = src(uv + o).rgb;
        float w = max(luma(s) - threshold, 0.0);
        acc += s * w;
        wsum += w;
    }
    if (wsum > 0.001) acc /= wsum;
    float here = max(luma(c.rgb) - threshold, 0.0);
    vec3 add = acc * intensity * (1.0 - clamp(here * 2.0, 0.0, 1.0));
    return vec4(c.rgb + add, c.a);
"""))
    return out
}

// MARK: - color

private func colorFx() -> [EffectDef] {
    var out: [EffectDef] = []
    out.append(EffectDef(
        id: "tritone", name: "Tritone", desc: "Three-color gradient map.",
        category: "Color", props: [
            PropDef("amount", "Amount", 0, 1, 1, 2),
        ], colors: [
            ColorParam("shadow", "Shadows", Int32(bitPattern: 0xFF10203A)),
            ColorParam("mid", "Midtones", Int32(bitPattern: 0xFF8C5A2B)),
            ColorParam("high", "Highlights", Int32(bitPattern: 0xFFFFE8C2)),
        ], glsl: """
    vec4 c = src(uv);
    float l = luma(c.rgb);
    vec3 m = l < 0.5 ? mix(shadow.rgb, mid.rgb, l * 2.0) : mix(mid.rgb, high.rgb, l * 2.0 - 1.0);
    return vec4(mix(c.rgb, m, amount), c.a);
"""))
    out.append(EffectDef(
        id: "duotone", name: "Duotone", desc: "Two-color gradient map.",
        category: "Color", props: [
            PropDef("amount", "Amount", 0, 1, 1, 2),
        ], colors: [
            ColorParam("dark", "Darks", Int32(bitPattern: 0xFF1B2A4A)),
            ColorParam("light", "Lights", Int32(bitPattern: 0xFFF2C9A0)),
        ], glsl: """
    vec4 c = src(uv);
    float l = luma(c.rgb);
    vec3 m = mix(dark.rgb, light.rgb, l);
    return vec4(mix(c.rgb, m, amount), c.a);
"""))
    out.append(EffectDef(
        id: "hueshift", name: "Hue Shift", desc: "Rotates the hue wheel.",
        category: "Color", props: [
            PropDef("shift", "Shift (turns)", -0.5, 0.5, 0.08, 3),
            PropDef("sat", "Saturation", 0, 2, 1, 2),
        ], glsl: """
    vec4 c = src(uv);
    vec3 h = rgb2hsv(c.rgb);
    h.x = fract(h.x + shift);
    h.y *= sat;
    return vec4(hsv2rgb(h), c.a);
"""))
    out.append(EffectDef(
        id: "grayscale", name: "Grayscale", desc: "Desaturates to luma.",
        category: "Color", props: [
            PropDef("amount", "Amount", 0, 1, 1, 2),
        ], glsl: """
    vec4 c = src(uv);
    float l = luma(c.rgb);
    return vec4(mix(c.rgb, vec3(l), amount), c.a);
"""))
    out.append(EffectDef(
        id: "colorcorrect", name: "Color Correction", desc: "Exposure, contrast, saturation, temperature and more.",
        category: "Color", props: [
            PropDef("ccExposure", "Exposure", -3, 3, 0, 2),
            PropDef("ccBright", "Brightness", -1, 1, 0, 2),
            PropDef("ccContrast", "Contrast", 0, 3, 1, 2),
            PropDef("ccSat", "Saturation", 0, 3, 1, 2),
            PropDef("ccVib", "Vibrance", -1, 1, 0, 2),
            PropDef("ccTemp", "Temperature", -1, 1, 0, 2),
            PropDef("ccTint", "Tint", -1, 1, 0, 2),
            PropDef("ccGamma", "Gamma", 0.2, 3, 1, 2),
            PropDef("ccHi", "Highlights", -1, 1, 0, 2),
            PropDef("ccSh", "Shadows", -1, 1, 0, 2),
        ], glsl: """
    vec4 c = src(uv);
    vec3 r = c.rgb * exp2(ccExposure) + ccBright;
    r = (r - 0.5) * ccContrast + 0.5;
    r += vec3(ccTemp * 0.12, ccTint * -0.08, -ccTemp * 0.12);
    float l = luma(r);
    r += ccSh * (1.0 - smoothstep(0.0, 0.5, l)) * 0.3;
    r += ccHi * smoothstep(0.5, 1.0, l) * 0.3;
    l = luma(r);
    float mx = max(r.r, max(r.g, r.b)), mn = min(r.r, min(r.g, r.b));
    float satNow = mx - mn;
    r = mix(vec3(l), r, ccSat * (1.0 + ccVib * (1.0 - satNow)));
    r = pow(max(r, vec3(0.0)), vec3(1.0 / max(ccGamma, 0.01)));
    return vec4(r, c.a);
"""))
    out.append(EffectDef(
        id: "levels", name: "Levels", desc: "Input/output black and white points and gamma.",
        category: "Color", props: [
            PropDef("lvInBlack", "Input black", 0, 1, 0, 2),
            PropDef("lvInWhite", "Input white", 0, 1, 1, 2),
            PropDef("lvGamma", "Gamma", 0.2, 3, 1, 2),
            PropDef("lvOutBlack", "Output black", 0, 1, 0, 2),
            PropDef("lvOutWhite", "Output white", 0, 1, 1, 2),
        ], glsl: """
    vec4 c = src(uv);
    vec3 r = clamp((c.rgb - lvInBlack) / max(lvInWhite - lvInBlack, 0.001), 0.0, 1.0);
    r = pow(r, vec3(1.0 / max(lvGamma, 0.01)));
    r = mix(vec3(lvOutBlack), vec3(lvOutWhite), r);
    return vec4(r, c.a);
"""))
    out.append(EffectDef(
        id: "splittone", name: "Split Tone", desc: "Tints shadows and highlights separately.",
        category: "Color", props: [
            PropDef("stBalance", "Balance", -1, 1, 0, 2),
            PropDef("stAmount", "Amount", 0, 1, 0.5, 2),
        ], colors: [
            ColorParam("stShadow", "Shadow color", Int32(bitPattern: 0xFF2040C0)),
            ColorParam("stHigh", "Highlight color", Int32(bitPattern: 0xFFFFB040)),
        ], glsl: """
    vec4 c = src(uv);
    float l = luma(c.rgb);
    float w = smoothstep(0.0, 1.0, l + stBalance * 0.5);
    vec3 tint = mix(stShadow.rgb, stHigh.rgb, w);
    return vec4(mix(c.rgb, c.rgb * tint * 1.6, stAmount), c.a);
"""))
    out.append(EffectDef(
        id: "channelmix", name: "Channel Mixer", desc: "Scales and swaps red, green and blue.",
        category: "Color", props: [
            PropDef("cmR", "Red gain", 0, 2, 1, 2),
            PropDef("cmG", "Green gain", 0, 2, 1, 2),
            PropDef("cmB", "Blue gain", 0, 2, 1, 2),
            PropDef("cmSwap", "Swap R/B", 0, 1, 0, 0, ["Off", "On"]),
        ], glsl: """
    vec4 c = src(uv);
    vec3 r = cmSwap > 0.5 ? c.bgr : c.rgb;
    return vec4(r * vec3(cmR, cmG, cmB), c.a);
"""))
    out.append(EffectDef(
        id: "invert", name: "Invert", desc: "Inverts the colors.",
        category: "Color", props: [
            PropDef("amount", "Amount", 0, 1, 1, 2),
        ], glsl: """
    vec4 c = src(uv);
    return vec4(mix(c.rgb, 1.0 - c.rgb, amount), c.a);
"""))
    out.append(EffectDef(
        id: "rgbsplit", name: "RGB Split", desc: "Chromatic channel separation.",
        category: "Color", props: [
            PropDef("amount", "Amount", 0, 0.1, 0.01, 3),
            PropDef("angle", "Angle", 0, 6.2832, 0, 3),
        ], glsl: """
    vec2 dir = vec2(cos(angle), sin(angle)) * amount;
    float r = src(uv + dir).r;
    float g = src(uv).g;
    float b = src(uv - dir).b;
    return vec4(r, g, b, src(uv).a);
"""))
    out.append(EffectDef(
        id: "raytrace", name: "Ray Tracing", desc: "Screen-space ray-traced shadows, ambient occlusion and bounce light from the layer's shapes.",
        category: "Light and glow", props: [
            PropDef("intensity", "Intensity", 0, 2, 1, 2),
            PropDef("lightAngle", "Light angle", 0, 360, 45, 0),
            PropDef("lightHeight", "Light height", 0.05, 2, 0.6, 2),
            PropDef("shadowLen", "Shadow length", 0, 0.5, 0.15, 3),
            PropDef("softness", "Softness", 0, 1, 0.4, 2),
            PropDef("ao", "Occlusion", 0, 1, 0.5, 2),
            PropDef("bounce", "Bounce light", 0, 1, 0.3, 2),
            PropDef("depthScale", "Depth scale", 0, 2, 0.6, 2),
        ], glsl: """
    vec4 c = src(uv);
    vec2 asp = vec2(uRes.y / max(uRes.x, 1.0), 1.0);
    float a0 = radians(lightAngle);
    vec2 ldir = vec2(cos(a0), sin(a0)) * asp;
    float h0 = (c.a * 0.6 + dot(c.rgb, vec3(0.299, 0.587, 0.114)) * 0.4) * depthScale;
    float lit = 1.0;
    float occ = 0.0;
    vec3 bnc = vec3(0.0);
    for (int i = 1; i <= 14; i++) {
        float t = float(i) / 14.0;
        vec2 p = uv + ldir * shadowLen * t;
        vec4 s = src(p);
        float hs = (s.a * 0.6 + dot(s.rgb, vec3(0.299, 0.587, 0.114)) * 0.4) * depthScale;
        float rayH = h0 + lightHeight * t * shadowLen * 6.0;
        float blk = smoothstep(0.0, 0.05 + softness * 0.3, hs - rayH);
        lit = min(lit, 1.0 - blk * (1.0 - t * softness * 0.6));
        bnc += s.rgb * s.a * (1.0 - t);
    }
    for (int j = 0; j < 8; j++) {
        float ang = float(j) * 0.785398;
        vec2 p = uv + vec2(cos(ang), sin(ang)) * asp * shadowLen * 0.5;
        vec4 s = src(p);
        float hs = (s.a * 0.6 + dot(s.rgb, vec3(0.299, 0.587, 0.114)) * 0.4) * depthScale;
        occ += clamp(hs - h0, 0.0, 1.0) / 8.0;
    }
    float shade = lit * (1.0 - ao * occ * 2.0);
    shade = clamp(shade, 0.0, 1.0);
    vec3 outc = c.rgb * mix(1.0, 0.35 + 0.65 * shade, clamp(intensity, 0.0, 1.0));
    outc += bnc / 14.0 * bounce * intensity * (1.0 - shade);
    float shadowA = (1.0 - shade) * clamp(intensity, 0.0, 1.0) * 0.6 * (1.0 - c.a);
    float na = max(c.a, shadowA);
    return vec4(outc * (c.a > 0.001 ? 1.0 : 0.0), na);
"""))
    out.append(EffectDef(
        id: "vignette", name: "Vignette", desc: "Darkens the edges of the frame.",
        category: "Color", props: [
            PropDef("amount", "Amount", 0, 2, 0.8, 2),
            PropDef("radius", "Radius", 0.1, 1.5, 1, 2),
            PropDef("soft", "Softness", 0.05, 1, 0.5, 2),
        ], glsl: """
    vec4 c = src(uv);
    float d = length((uv - 0.5) * vec2(uRes.x / max(uRes.y, 1.0), 1.0));
    float v = smoothstep(radius, radius - soft, d);
    return vec4(c.rgb * mix(1.0, v, clamp(amount, 0.0, 1.0)), c.a);
"""))
    out.append(EffectDef(
        id: "fill", name: "Fill", desc: "Fills the alpha with a solid color.",
        category: "Color", colors: [
            ColorParam("color", "Color", Int32(bitPattern: 0xFFFF6A00)),
        ], glsl: """
    float fa = src(uv).a;
    return vec4(color.rgb * fa, fa);
"""))
    out.append(EffectDef(
        id: "nightvision", name: "Night Vision", desc: "Green night-mode look with grain.",
        category: "Color", props: [
            PropDef("amount", "Amount", 0, 1, 1, 2),
            PropDef("grain", "Grain", 0, 1, 0.4, 2),
        ], glsl: """
    vec4 c = src(uv);
    float l = luma(c.rgb);
    l = pow(l, 0.75);
    float g = (hash21(uv * uRes + fract(uTime) * 100.0) - 0.5) * grain * 0.35;
    vec3 nv = vec3(0.08, 1.0, 0.25) * l + g;
    return vec4(mix(c.rgb, nv, amount), c.a);
"""))
    out.append(EffectDef(
        id: "thermal", name: "Thermal", desc: "Heat-camera palette.",
        category: "Color", props: [
            PropDef("amount", "Amount", 0, 1, 1, 2),
        ], glsl: """
    vec4 c = src(uv);
    float l = clamp(luma(c.rgb), 0.0, 1.0);
    vec3 t = hsv2rgb(vec2(mix(0.72, 0.98, l), 0.9, mix(0.25, 1.0, l)));
    return vec4(mix(c.rgb, t, amount), c.a);
"""))
    out.append(EffectDef(
        id: "oldphoto", name: "Old Photo", desc: "Sepia print with faded edges.",
        category: "Color", props: [
            PropDef("amount", "Amount", 0, 1, 0.85, 2),
            PropDef("fade", "Fade", 0, 1, 0.35, 2),
        ], glsl: """
    vec4 c = src(uv);
    float l = luma(c.rgb);
    vec3 sep = vec3(l * 1.07 + 0.05, l * 0.85 + 0.02, l * 0.58);
    sep = mix(sep, vec3(0.93), fade * 0.5);
    float d = length(uv - 0.5);
    sep *= 1.0 - smoothstep(0.35, 0.75, d) * fade;
    return vec4(mix(c.rgb, sep, amount), c.a);
"""))
    out.append(EffectDef(
        id: "gradientmap", name: "Gradient Map", desc: "Maps luma through a two-stop gradient.",
        category: "Color", props: [
            PropDef("amount", "Amount", 0, 1, 1, 2),
        ], colors: [
            ColorParam("dark", "Dark end", Int32(bitPattern: 0xFF2D0B4E)),
            ColorParam("light", "Light end", Int32(bitPattern: 0xFFFF9E3D)),
        ], glsl: """
    vec4 c = src(uv);
    float l = luma(c.rgb);
    return vec4(mix(c.rgb, mix(dark.rgb, light.rgb, l), amount), c.a);
"""))
    out.append(EffectDef(
        id: "threshold", name: "Threshold", desc: "Hard black/white cutoff.",
        category: "Color", props: [
            PropDef("level", "Level", 0, 1, 0.5, 2),
        ], colors: [
            ColorParam("dark", "Dark", Int32(bitPattern: 0xFF000000)),
            ColorParam("light", "Light", Int32(bitPattern: 0xFFFFFFFF)),
        ], glsl: """
    vec4 c = src(uv);
    float l = luma(c.rgb);
    return vec4(mix(dark.rgb, light.rgb, step(level, l)), c.a);
"""))
    return out
}

// MARK: - stylize

private func stylizeFx() -> [EffectDef] {
    var out: [EffectDef] = []
    out.append(EffectDef(
        id: "etching", name: "Etching", desc: "Cross-hatched line shading.",
        category: "Stylize", props: [
            PropDef("scale", "Scale", 4, 40, 14, 0),
            PropDef("strength", "Strength", 0, 2, 1, 2),
        ], glsl: """
    float l = luma(src(uv).rgb);
    float v = 0.0;
    for (int i = 0; i < 4; i++) {
        float fi = float(i) + 1.0;
        float t = fi * 0.25;
        if (l < t) {
            float a = 0.7 + fi * 0.33;
            vec2 p = rot(uv * uRes / scale, a);
            v = max(v, smoothstep(0.0, 0.45, abs(sin(p.x * 3.14159) ) ) * (t - l) * 4.0);
        }
    }
    return vec4(vec3(1.0 - clamp(v * strength, 0.0, 1.0)), src(uv).a);
"""))
    out.append(EffectDef(
        id: "halftone", name: "Halftone", desc: "Print-style dot screen.",
        category: "Stylize", props: [
            PropDef("size", "Dot size", 2, 24, 8, 0),
            PropDef("angle", "Angle", 0, 1.5708, 0.5236, 3),
        ], colors: [
            ColorParam("ink", "Ink", Int32(bitPattern: 0xFF111111)),
            ColorParam("paper", "Paper", Int32(bitPattern: 0xFFF6F1E7)),
        ], glsl: """
    vec2 p = rot(uv * uRes / size, angle);
    vec2 cell = fract(p) - 0.5;
    float l = luma(src(uv).rgb);
    float r = sqrt(1.0 - l) * 0.62;
    float d = step(length(cell), r);
    return vec4(mix(paper.rgb, ink.rgb, d), src(uv).a);
"""))
    out.append(EffectDef(
        id: "zebrafy", name: "Zebrafy", desc: "Zebra stripes following brightness.",
        category: "Stylize", props: [
            PropDef("scale", "Stripe scale", 4, 40, 12, 0),
            PropDef("contrast", "Contrast", 0.5, 3, 1.2, 2),
        ], glsl: """
    float l = luma(src(uv).rgb);
    float s = sin((uv.x + uv.y) * scale + l * 6.2831);
    s = smoothstep(-0.2, 0.2, s * contrast);
    return vec4(mix(vec3(0.05), vec3(0.98), s), src(uv).a);
"""))
    out.append(EffectDef(
        id: "posterize", name: "Posterize", desc: "Quantizes colors into bands.",
        category: "Stylize", props: [
            PropDef("levels", "Levels", 2, 16, 5, 0),
        ], glsl: """
    vec4 c = src(uv);
    float n = max(floor(levels), 2.0);
    return vec4(floor(c.rgb * n + 0.5) / n, c.a);
"""))
    out.append(EffectDef(
        id: "filmgrain", name: "Film Grain", desc: "Animated analog film grain.",
        category: "Stylize", props: [
            PropDef("amount", "Amount", 0, 1, 0.35, 2),
            PropDef("size", "Size", 0.5, 4, 1.5, 2),
        ], glsl: """
    vec4 c = src(uv);
    float n = vnoise(uv * uRes / (size * 3.0) + vec2(uTime * 61.7, uTime * 23.9));
    n = (n - 0.5) * 2.0;
    return vec4(c.rgb + n * amount * 0.28, c.a);
"""))
    out.append(EffectDef(
        id: "edgelines", name: "Edge Lines", desc: "Colored outline pass on black.",
        category: "Stylize", props: [
            PropDef("strength", "Strength", 0, 4, 1.5, 2),
        ], colors: [
            ColorParam("line", "Line color", Int32(bitPattern: 0xFF30E8B0)),
        ], glsl: """
    vec2 px = 1.5 / uRes;
    float l0 = luma(src(uv).rgb);
    float lx = luma(src(uv + vec2(px.x, 0.0)).rgb);
    float ly = luma(src(uv + vec2(0.0, px.y)).rgb);
    float e = clamp(length(vec2(lx - l0, ly - l0)) * 8.0, 0.0, 1.0) * strength;
    return vec4(line.rgb * e, src(uv).a * clamp(e, 0.0, 1.0));
"""))
    out.append(EffectDef(
        id: "scanlines", name: "Scanlines", desc: "CRT-style horizontal lines.",
        category: "Stylize", props: [
            PropDef("count", "Line count", 40, 800, 240, 0),
            PropDef("opacity", "Opacity", 0, 1, 0.4, 2),
            PropDef("speed", "Roll speed", -2, 2, 0, 2),
        ], glsl: """
    vec4 c = src(uv);
    float y = uv.y + uTime * speed * 0.1;
    float s = 0.5 + 0.5 * sin(y * count * 6.2831);
    return vec4(c.rgb * mix(1.0, 0.55 + 0.45 * s, opacity), c.a);
"""))
    out.append(EffectDef(
        id: "pixelate", name: "Pixelate", desc: "Chunky pixels.",
        category: "Stylize", props: [
            PropDef("size", "Pixel size", 2, 64, 12, 0),
        ], glsl: """
    vec2 px = size / uRes;
    vec2 q = (floor(uv / px) + 0.5) * px;
    return src(q);
"""))
    out.append(EffectDef(
        id: "sharpen", name: "Sharpen", desc: "Unsharp-mask detail boost.",
        category: "Stylize", props: [
            PropDef("amount", "Amount", 0, 3, 0.8, 2),
        ], glsl: """
    vec4 c = src(uv);
    vec2 px = 1.0 / uRes;
    vec3 blur = (src(uv + vec2(px.x, 0.0)).rgb + src(uv - vec2(px.x, 0.0)).rgb
               + src(uv + vec2(0.0, px.y)).rgb + src(uv - vec2(0.0, px.y)).rgb) * 0.25;
    return vec4(c.rgb + (c.rgb - blur) * amount, c.a);
"""))
    out.append(EffectDef(
        id: "ascii", name: "ASCII", desc: "Renders the frame as text characters.",
        category: "Stylize", props: [
            PropDef("cols", "Columns", 20, 160, 72, 0),
        ], glsl: """
    vec2 cell = vec2(1.0 / max(cols, 8.0), (1.0 / max(cols, 8.0)) * (uRes.x / max(uRes.y, 1.0)) * 0.55);
    vec2 q = (floor(uv / cell) + 0.5) * cell;
    float l = luma(src(q).rgb);
    vec2 f = fract(uv / cell);
    float g = 0.0;
    if (l > 0.85) { g = 1.0; }
    else if (l > 0.6) { g = step(0.2, f.x) * step(0.2, f.y) * step(f.x, 0.8) * step(f.y, 0.8); }
    else if (l > 0.35) { g = step(length(f - vec2(0.5)), 0.35); }
    else if (l > 0.15) { g = step(length(f - vec2(0.5, 0.35)), 0.22); }
    return vec4(vec3(g * 0.92), src(uv).a);
"""))
    out.append(EffectDef(
        id: "hexpixel", name: "Hex Pixel", desc: "Hexagonal pixel mosaic.",
        category: "Stylize", props: [
            PropDef("size", "Hex size", 4, 48, 16, 0),
        ], glsl: """
    vec2 s = vec2(1.0, 1.7320508);
    vec2 p = uv * uRes / (size * s);
    vec2 a = mod(p, s) - s * 0.5;
    vec2 b = mod(p - s * 0.5, s) - s * 0.5;
    vec2 g = dot(a, a) < dot(b, b) ? a : b;
    vec2 q = ((p - g) * size * s) / uRes;
    return src(clamp(q, 0.0, 1.0));
"""))
    out.append(EffectDef(
        id: "sketch", name: "Sketch", desc: "Pencil-drawn look.",
        category: "Stylize", props: [
            PropDef("strength", "Strength", 0, 3, 1.2, 2),
        ], glsl: """
    vec2 px = 1.2 / uRes;
    float l0 = luma(src(uv).rgb);
    float lx = luma(src(uv + vec2(px.x, 0.0)).rgb);
    float ly = luma(src(uv + vec2(0.0, px.y)).rgb);
    float ld = luma(src(uv + px).rgb);
    float e = clamp((abs(lx - l0) + abs(ly - l0) + abs(ld - l0)) * 10.0, 0.0, 1.0);
    float shade = l0 * 0.5;
    float v = clamp(1.0 - e * strength - (1.0 - shade) * 0.15, 0.0, 1.0);
    return vec4(vec3(v * 0.9 + 0.08), src(uv).a);
"""))
    out.append(EffectDef(
        id: "toon", name: "Toon", desc: "Cel-shaded flat colors with outlines.",
        category: "Stylize", props: [
            PropDef("levels", "Color steps", 2, 8, 4, 0),
            PropDef("edge", "Outline", 0, 2, 0.8, 2),
        ], glsl: """
    vec2 px = 1.5 / uRes;
    vec4 c = src(uv);
    float n = max(floor(levels), 2.0);
    vec3 q = floor(c.rgb * n + 0.5) / n;
    float l0 = luma(c.rgb);
    float e = clamp(length(vec2(luma(src(uv + vec2(px.x, 0.0)).rgb) - l0,
                                luma(src(uv + vec2(0.0, px.y)).rgb) - l0)) * 9.0, 0.0, 1.0);
    q = mix(q, vec3(0.02), e * edge);
    return vec4(q, c.a);
"""))
    out.append(EffectDef(
        id: "emboss", name: "Emboss", desc: "Relief stamp effect.",
        category: "Stylize", props: [
            PropDef("strength", "Strength", 0, 4, 1.5, 2),
        ], glsl: """
    vec2 px = 2.0 / uRes;
    float c0 = luma(src(uv).rgb);
    float cx = luma(src(uv + px).rgb);
    float cy = luma(src(uv + vec2(px.x, -px.y)).rgb);
    float d = (c0 - cx) + (c0 - cy);
    float v = 0.5 + d * strength;
    return vec4(vec3(clamp(v, 0.0, 1.0)), src(uv).a);
"""))
    out.append(EffectDef(
        id: "clay", name: "Clay", desc: "Matte plasticine shading.",
        category: "Stylize", props: [
            PropDef("amount", "Amount", 0, 1, 0.8, 2),
        ], glsl: """
    vec2 px = 2.0 / uRes;
    vec4 c = src(uv);
    float l0 = luma(c.rgb);
    float lx = luma(src(uv + vec2(px.x, 0.0)).rgb);
    float ly = luma(src(uv + vec2(0.0, px.y)).rgb);
    vec3 n = normalize(vec3((l0 - lx) * 6.0, (l0 - ly) * 6.0, 1.0));
    vec3 lightDir = normalize(vec3(-0.4, 0.6, 0.8));
    float diff = clamp(dot(n, lightDir) * 0.5 + 0.55, 0.0, 1.0);
    vec3 clay = vec3(0.85, 0.52, 0.45) * diff;
    return vec4(mix(c.rgb, clay, amount), c.a);
"""))
    out.append(EffectDef(
        id: "matrixrain", name: "Matrix Rain", desc: "Falling green code.",
        category: "Stylize", props: [
            PropDef("density", "Density", 0.2, 1, 0.5, 2),
            PropDef("speed", "Speed", 0.2, 4, 1, 2),
        ], glsl: """
    vec2 p = uv * vec2(uRes.x / max(uRes.y, 1.0), 1.0) * 36.0;
    float col = floor(p.x);
    float t = uTime * speed;
    float head = fract(p.y * 0.15 + hash11(col) * 10.0 - t * 0.8);
    float trail = exp(-head * 4.0);
    float chr = step(0.55, hash21(vec2(col, floor(p.y) + floor(t * 8.0))));
    float v = trail * chr * density;
    vec4 c = src(uv);
    return vec4(c.rgb + vec3(0.1, 1.0, 0.25) * v * 1.2, max(c.a, clamp(v, 0.0, 1.0)));
"""))
    out.append(EffectDef(
        id: "pixelscatter", name: "Pixel Scatter", desc: "Random blocks drift apart.",
        category: "Stylize", props: [
            PropDef("amount", "Amount", 0, 0.5, 0.08, 3),
            PropDef("size", "Block size", 4, 48, 16, 0),
        ], glsl: """
    vec2 cell = floor(uv * uRes / size);
    vec2 j = vec2(hash21(cell + floor(uTime * 3.0)), hash21(cell + 7.3 + floor(uTime * 3.0))) - 0.5;
    return src(clamp(uv + j * amount, 0.0, 1.0));
"""))
    out.append(EffectDef(
        id: "crt", name: "CRT TV", desc: "Curved screen, mask, glow and flicker.",
        category: "Stylize", props: [
            PropDef("curve", "Curve", 0, 1, 0.35, 2),
            PropDef("mask", "Pixel mask", 0, 1, 0.5, 2),
            PropDef("glow", "Glow", 0, 2, 0.6, 2),
            PropDef("flicker", "Flicker", 0, 1, 0.2, 2),
        ], glsl: """
    vec2 cc = uv - 0.5;
    vec2 duv = 0.5 + cc * (1.0 + curve * dot(cc, cc) * 1.6);
    if (duv.x < 0.0 || duv.x > 1.0 || duv.y < 0.0 || duv.y > 1.0) return vec4(0.0);
    vec4 c = src(duv);
    // aperture mask
    float m = 1.0 - mask * 0.35 * (0.5 + 0.5 * sin(duv.x * uRes.x * 3.14159));
    // scan flicker
    float fl = 1.0 - flicker * 0.12 * (0.5 + 0.5 * sin(uTime * 47.0));
    // phosphor glow (cheap: brighten)
    vec3 g = vec3(luma(c.rgb)) * glow * 0.35;
    return vec4((c.rgb * m + g) * fl, c.a);
"""))
    return out
}

// MARK: - distort

private func distortFx() -> [EffectDef] {
    var out: [EffectDef] = []
    out.append(EffectDef(
        id: "kaleido", name: "Kaleidoscope", desc: "Mirror segments around the centre.",
        category: "Distort", props: [
            PropDef("segments", "Segments", 2, 16, 6, 0),
            PropDef("rotate", "Rotation", 0, 6.2832, 0, 3),
        ], glsl: """
    vec2 p = uv - 0.5;
    p = rot(p, rotate);
    float a = atan(p.y, p.x);
    float r = length(p);
    float seg = 6.2831 / max(float(int(segments)), 2.0);
    a = mod(a, seg);
    a = abs(a - seg * 0.5);
    return src(clamp(vec2(cos(a), sin(a)) * r + 0.5, 0.0, 1.0));
"""))
    out.append(EffectDef(
        id: "bulge", name: "Bulge", desc: "Lens bulge / pinch.",
        category: "Distort", props: [
            PropDef("amount", "Amount", -1, 1, 0.5, 2),
            PropDef("radius", "Radius", 0.1, 1, 0.7, 2),
        ], glsl: """
    vec2 p = uv - 0.5;
    float r = length(p);
    if (r < radius) {
        float f = 1.0 - amount * (1.0 - r / radius) * (1.0 - r / radius);
        p *= f;
    }
    return src(clamp(p + 0.5, 0.0, 1.0));
"""))
    out.append(EffectDef(
        id: "twirl", name: "Twirl", desc: "Rotational swirl.",
        category: "Distort", props: [
            PropDef("angle", "Angle", -6.2832, 6.2832, 2.5, 3),
            PropDef("radius", "Radius", 0.1, 1, 0.7, 2),
        ], glsl: """
    vec2 p = uv - 0.5;
    float r = length(p);
    if (r < radius) {
        float t = (1.0 - r / radius);
        p = rot(p, angle * t * t);
    }
    return src(clamp(p + 0.5, 0.0, 1.0));
"""))
    out.append(EffectDef(
        id: "barrel", name: "Barrel", desc: "Wide-angle barrel distortion.",
        category: "Distort", props: [
            PropDef("amount", "Amount", -1, 1, 0.3, 2),
        ], glsl: """
    vec2 p = uv - 0.5;
    float r2 = dot(p, p);
    p *= 1.0 + amount * r2;
    return src(clamp(p + 0.5, 0.0, 1.0));
"""))
    out.append(EffectDef(
        id: "wavewarp", name: "Wave Warp", desc: "Traveling sine displacement.",
        category: "Distort", props: [
            PropDef("ampX", "Amplitude X", 0, 0.2, 0.03, 3),
            PropDef("ampY", "Amplitude Y", 0, 0.2, 0.02, 3),
            PropDef("freq", "Frequency", 0.5, 20, 5, 2),
            PropDef("speed", "Speed", 0, 6, 2, 2),
        ], glsl: """
    vec2 w = vec2(sin(uv.y * freq + uTime * speed) * ampX,
                  cos(uv.x * freq + uTime * speed) * ampY);
    return src(clamp(uv + w, 0.0, 1.0));
"""))
    out.append(EffectDef(
        id: "ripple", name: "Ripple", desc: "Water rings from the centre.",
        category: "Distort", props: [
            PropDef("amp", "Amplitude", 0, 0.1, 0.02, 3),
            PropDef("freq", "Frequency", 5, 80, 30, 1),
            PropDef("speed", "Speed", 0, 6, 2, 2),
        ], glsl: """
    vec2 p = uv - 0.5;
    float r = length(p);
    float w = sin(r * freq - uTime * speed) * amp * (1.0 - r);
    return src(clamp(uv + normalize(max(p, vec2(0.0001))) * w, 0.0, 1.0));
"""))
    out.append(EffectDef(
        id: "glassblocks", name: "Glass Blocks", desc: "Frosted glass tiles.",
        category: "Distort", props: [
            PropDef("size", "Tile size", 8, 96, 32, 0),
            PropDef("warp", "Warp", 0, 0.15, 0.03, 3),
        ], glsl: """
    vec2 cell = floor(uv * uRes / size);
    vec2 j = vec2(hash21(cell), hash21(cell + 3.1)) - 0.5;
    vec2 within = fract(uv * uRes / size) - 0.5;
    vec2 off = (j - within * 0.6) * warp;
    return src(clamp(uv + off, 0.0, 1.0));
"""))
    out.append(EffectDef(
        id: "droste", name: "Droste", desc: "Picture-in-picture spiral recursion.",
        category: "Distort", props: [
            PropDef("zoom", "Zoom", 0.5, 2, 1.1, 3),
            PropDef("twist", "Twist", -3, 3, 0.5, 2),
        ], glsl: """
    vec2 p = uv - 0.5;
    float r = length(p);
    float a = atan(p.y, p.x);
    float lr = log(max(r, 0.0001));
    a += twist * lr;
    lr /= log(zoom);
    float f = fract(lr);
    float rr = exp(f * log(zoom));
    vec2 q = vec2(cos(a), sin(a)) * rr + 0.5;
    if (q.x < 0.0 || q.x > 1.0 || q.y < 0.0 || q.y > 1.0) return vec4(0.0);
    return src(q);
"""))
    out.append(EffectDef(
        id: "polarwarp", name: "Polar Warp", desc: "Rectangular ↔ polar remap.",
        category: "Distort", props: [
            PropDef("amount", "Amount", 0, 1, 0.7, 2),
            PropDef("rotate", "Rotate", 0, 6.2832, 0, 3),
        ], glsl: """
    vec2 p = uv - 0.5;
    float a = atan(p.y, p.x) / 6.2831 + 0.5 + rotate * 0.159;
    float r = length(p) * 2.0;
    vec2 polar = vec2(fract(a), clamp(r, 0.0, 1.0));
    vec2 rect = uv;
    return src(mix(rect, polar, amount));
"""))
    out.append(EffectDef(
        id: "turbulent", name: "Turbulent Displace (Legacy)", desc: "Smoke-like fbm distortion with complexity, evolution, direction and edge control.",
        category: "Distort", props: [
            PropDef("amount", "Amount", 0, 0.4, 0.04, 3),
            PropDef("scale", "Size (scale)", 1, 12, 4, 2),
            PropDef("complexity", "Complexity", 1, 6, 4, 0),
            PropDef("speed", "Speed", 0, 4, 0.8, 2),
            PropDef("evolution", "Evolution", 0, 20, 0, 2),
            PropDef("tSeed", "Random seed", 0, 100, 0, 0),
            PropDef("tOffX", "Offset X", -3, 3, 0, 2),
            PropDef("tOffY", "Offset Y", -3, 3, 0, 2),
            PropDef("tAmtX", "Amount X", 0, 2, 1, 2),
            PropDef("tAmtY", "Amount Y", 0, 2, 1, 2),
            PropDef("tDir", "Direction", -180, 180, 0, 0, nil, true, 180),
            PropDef("tSplit", "Chroma split", 0, 1, 0, 2),
            PropDef("tEdge", "Edges", 0, 3, 0, 0, ["Clamp", "Mirror", "Tile", "Transparent"]),
            PropDef("tMix", "Mix", 0, 1, 1, 2),
        ], glsl: """
    float oct = floor(complexity + 0.5);
    vec2 q = (uv + vec2(tOffX, tOffY)) * scale + vec2(tSeed * 7.13, tSeed * 3.71);
    float tt = uTime * speed * 0.3 + evolution;
    vec2 p1 = q + vec2(tt, 0.0);
    vec2 p2 = q + vec2(5.2, tt);
    vec2 f = vec2(0.0);
    float amp = 0.5;
    float nrm = 0.0;
    for (int i = 0; i < 6; i++) {
        if (float(i) >= oct) break;
        f += amp * vec2(vnoise(p1), vnoise(p2));
        nrm += amp;
        p1 = p1 * 2.03 + 1.7;
        p2 = p2 * 2.03 + 3.1;
        amp *= 0.5;
    }
    f = f / max(nrm, 0.0001) - 0.5;
    float da = tDir * 0.0174533;
    f = vec2(cos(da) * f.x - sin(da) * f.y, sin(da) * f.x + cos(da) * f.y);
    vec2 off = f * amount * vec2(tAmtX, tAmtY);
    vec2 p = uv + off;
    float em = floor(tEdge + 0.5);
    bool outside = p.x < 0.0 || p.x > 1.0 || p.y < 0.0 || p.y > 1.0;
    if (em > 0.5 && em < 1.5) p = vec2(1.0) - abs(vec2(1.0) - mod(p, vec2(2.0)));
    else if (em > 1.5 && em < 2.5) p = fract(p);
    else p = clamp(p, 0.0, 1.0);
    vec4 r = src(p);
    if (tSplit > 0.001) {
        vec2 o = off * tSplit * 0.6;
        r.r = src(clamp(p + o, 0.0, 1.0)).r;
        r.b = src(clamp(p - o, 0.0, 1.0)).b;
    }
    if (em > 2.5 && outside) r = vec4(0.0);
    return mix(src(uv), r, tMix);
"""))
    out.append(EffectDef(
        id: "mirror", name: "Mirror", desc: "Kaleidoscopic mirror split.",
        category: "Distort", props: [
            PropDef("axis", "Axis", 0, 1, 0.5, 3),
            PropDef("angle", "Angle", 0, 3.1416, 0, 3),
        ], glsl: """
    vec2 p = rot(uv - 0.5, angle) + 0.5;
    if (p.x > axis) p.x = axis - (p.x - axis);
    p = rot(p - 0.5, -angle) + 0.5;
    return src(clamp(p, 0.0, 1.0));
"""))
    return out
}

// MARK: - blur

private func blurFx() -> [EffectDef] {
    var out: [EffectDef] = []
    out.append(EffectDef(
        id: "blur", name: "Gaussian Blur", desc: "Smooth true-Gaussian blur (no boxes or polygon edges). Radius is a fraction of the frame height.",
        category: "Blur", props: [
            PropDef("radius", "Radius", 0, 0.05, 0.008, 3),
        ], glsl: """
    vec4 acc = vec4(0.0);
    float sigma = radius * 0.5;
    if (sigma <= 0.00001) { return src(uv); }
    vec2 asp = vec2(uRes.y / uRes.x, 1.0);
    float rnd = fract(52.9829189 * fract(dot(uv * uRes, vec2(0.06711056, 0.00583715))));
    for (int i = 0; i < 64; i++) {
        float u = (float(i) + 0.5) / 64.0;
        float r = sigma * sqrt(-2.0 * log(1.0 - u * 0.9975));
        float a = (float(i) + rnd) * 2.39996323;
        acc += src(uv + vec2(cos(a), sin(a)) * r * asp);
    }
    return acc / 64.0;
"""))
    out.append(EffectDef(
        id: "radialblur", name: "Radial Blur", desc: "Zoom/radial smear.",
        category: "Blur", props: [
            PropDef("amount", "Amount", 0, 0.2, 0.05, 3),
            PropDef("steps", "Steps", 4, 24, 10, 0),
            PropDef("cx", "Center X", 0, 1, 0.5, 3),
            PropDef("cy", "Center Y", 0, 1, 0.5, 3),
        ], glsl: """
    vec2 dir = (uv - vec2(cx, cy)) * amount / 10.0;
    vec3 acc = vec3(0.0);
    float n = 10.0;
    for (int i = 0; i < 10; i++) {
        acc += src(clamp(uv - dir * float(i) / n, 0.0, 1.0)).rgb;
    }
    acc /= n;
    return vec4(acc, src(uv).a);
"""))
    out.append(EffectDef(
        id: "blurmo", name: "Motion Blur", desc: "Directional smear with speed control.",
        category: "Blur", props: [
            PropDef("angle", "Angle", 0, 6.2832, 0, 3),
            PropDef("length", "Length", 0, 0.2, 0.04, 3),
        ], glsl: """
    vec2 dir = vec2(cos(angle), sin(angle)) * length / 12.0;
    vec3 acc = vec3(0.0);
    for (int i = 0; i < 12; i++) {
        acc += src(clamp(uv + dir * (float(i) - 5.5), 0.0, 1.0)).rgb;
    }
    acc /= 12.0;
    return vec4(acc, src(uv).a);
"""))
    out.append(EffectDef(
        id: "dirblur", name: "Directional Blur", desc: "After Effects style: blur along a direction angle with a blur length.",
        category: "Blur", props: [
            PropDef("dbAngle", "Direction (deg)", -360, 360, 0, 1),
            PropDef("dbLen", "Blur length", 0, 300, 40, 1),
            PropDef("dbQual", "Quality", 8, 48, 32, 0),
            PropDef("dbOneSide", "One side (0 = both, 1 = trail)", 0, 1, 0, 0),
        ], glsl: """
    float a = dbAngle * 0.01745329;
    vec2 dir = vec2(cos(a), -sin(a)) / uRes * dbLen;      // blur length in pixels, angle counter-clockwise like AE
    float n = clamp(floor(dbQual), 8.0, 48.0);
    vec4 acc = vec4(0.0);
    float wsum = 0.0;
    for (int i = 0; i < 48; i++) {
        if (float(i) >= n) { break; }
        float t = (float(i) + 0.5) / n;                    // 0..1 along the streak
        float k = dbOneSide > 0.5 ? -t : (t - 0.5);
        float w = dbOneSide > 0.5 ? (1.0 - 0.6 * t) : 1.0;  // trail fades; both-sides is a flat box like AE
        vec4 c = src(clamp(uv + dir * k, 0.0, 1.0));
        acc += vec4(c.rgb * c.a, c.a) * w;                  // premultiplied so transparent edges do not darken
        wsum += w;
    }
    acc /= max(wsum, 1e-4);
    return vec4(acc.a > 1e-4 ? acc.rgb / acc.a : vec3(0.0), acc.a);
"""))
    return out
}

// MARK: - generate

private func generateFx() -> [EffectDef] {
    var out: [EffectDef] = []
    out.append(EffectDef(
        id: "psykoblobs", name: "Psykoblobs", desc: "Animated lava-lamp blobs.",
        category: "Generate", props: [
            PropDef("scale", "Scale", 1, 10, 3.5, 2),
            PropDef("speed", "Speed", 0, 3, 0.7, 2),
            PropDef("mix", "Mix", 0, 1, 0.5, 2),
        ], colors: [
            ColorParam("cola", "Color A", Int32(bitPattern: 0xFFFF2D78)),
            ColorParam("colb", "Color B", Int32(bitPattern: 0xFF2DD4FF)),
        ], glsl: """
    float n = fbm(uv * scale + vec2(uTime * speed * 0.2, uTime * speed * 0.13));
    float m = smoothstep(0.35, 0.65, n);
    vec3 gen = mix(cola.rgb, colb.rgb, m) * src(uv).a;
    vec4 c = src(uv);
    return vec4(mix(c.rgb, gen, mix), c.a);
"""))
    out.append(EffectDef(
        id: "texturemoire", name: "Moire", desc: "Interference pattern.",
        category: "Generate", props: [
            PropDef("scale", "Scale", 10, 200, 70, 0),
            PropDef("twist", "Twist", 0, 1, 0.2, 2),
            PropDef("mix", "Mix", 0, 1, 0.6, 2),
        ], glsl: """
    vec2 p = uv * scale;
    float a = sin(p.x) * sin(p.y);
    float b = sin(p.x * 1.07 + uv.y * twist * 20.0) * sin(p.y * 0.93);
    float t = clamp(abs(a - b) * 1.5, 0.0, 1.0);
    vec4 c = src(uv);
    return vec4(mix(c.rgb, vec3(t), mix), c.a);
"""))
    out.append(EffectDef(
        id: "starfield", name: "Starfield", desc: "Flying star field.",
        category: "Generate", props: [
            PropDef("density", "Density", 0.2, 2, 0.8, 2),
            PropDef("speed", "Speed", 0, 4, 1, 2),
            PropDef("mix", "Mix", 0, 1, 0.7, 2),
        ], glsl: """
    vec2 p = uv * vec2(uRes.x / max(uRes.y, 1.0), 1.0);
    vec3 acc = vec3(0.0);
    for (int layer = 0; layer < 3; layer++) {
        float fl = float(layer) + 1.0;
        vec2 g = p * fl * 3.0;
        g.y += uTime * speed * fl * 0.4;
        vec2 cell = floor(g);
        vec2 f = fract(g) - 0.5;
        float rnd = hash21(cell + fl * 17.0);
        if (rnd > 1.0 - density * 0.35) {
            float d = length(f);
            float tw = 0.6 + 0.4 * sin(uTime * (2.0 + rnd * 5.0) + rnd * 20.0);
            acc += vec3(smoothstep(0.18, 0.0, d) * tw / fl);
        }
    }
    vec4 c = src(uv);
    return vec4(c.rgb + acc * 1.5, max(c.a, length(acc)) * mix + c.a * (1.0 - mix));
"""))
    out.append(EffectDef(
        id: "plasma", name: "Plasma", desc: "Classic sine plasma.",
        category: "Generate", props: [
            PropDef("scale", "Scale", 1, 12, 4, 2),
            PropDef("speed", "Speed", 0, 3, 1, 2),
            PropDef("mix", "Mix", 0, 1, 0.6, 2),
        ], glsl: """
    vec2 p = uv * scale;
    float v = sin(p.x + uTime * speed);
    v += sin((p.y + uTime * speed * 1.3) * 1.1);
    v += sin((p.x + p.y + uTime * speed * 0.7) * 0.7);
    v += sin(length(p - vec2(scale * 0.5)) * 1.2 - uTime * speed);
    v *= 0.25;
    vec3 gen = hsv2rgb(vec3(fract(v * 0.3 + 0.5), 0.8, 1.0));
    vec4 c = src(uv);
    return vec4(mix(c.rgb, gen, mix), c.a);
"""))
    out.append(EffectDef(
        id: "fire", name: "Fire", desc: "Rising fbm flames.",
        category: "Generate", props: [
            PropDef("intensity", "Intensity", 0, 2, 1, 2),
            PropDef("scale", "Scale", 1, 10, 3, 2),
            PropDef("speed", "Speed", 0, 3, 1.2, 2),
        ], glsl: """
    vec2 p = uv * vec2(1.0, 1.0);
    p.y = 1.0 - p.y;
    float n = fbm(vec2(p.x * scale, p.y * scale * 1.5 - uTime * speed));
    float f = clamp(p.y * 1.4 - n * 0.9 + 0.25, 0.0, 1.0);
    f = pow(f, 1.8) * intensity;
    vec3 fire = mix(vec3(1.0, 0.95, 0.5), vec3(0.9, 0.25, 0.02), clamp(p.y * 1.3, 0.0, 1.0));
    vec4 c = src(uv);
    return vec4(c.rgb + fire * f, max(c.a, f));
"""))
    out.append(EffectDef(
        id: "snow", name: "Snow", desc: "Falling snowflakes.",
        category: "Generate", props: [
            PropDef("density", "Density", 0.1, 2, 0.7, 2),
            PropDef("speed", "Speed", 0.1, 3, 0.6, 2),
            PropDef("size", "Flake size", 1, 6, 2.5, 2),
        ], glsl: """
    vec2 p = uv * vec2(uRes.x / max(uRes.y, 1.0), 1.0) * 20.0;
    vec3 acc = vec3(0.0);
    for (int layer = 0; layer < 3; layer++) {
        float fl = float(layer) + 1.0;
        vec2 g = vec2(p.x * fl * 0.5, p.y * fl * 0.5);
        g.y += uTime * speed * fl;
        g.x += sin(g.y * 0.8 + float(layer) * 2.0) * 0.4;
        vec2 cell = floor(g);
        vec2 f = fract(g) - 0.5;
        float rnd = hash21(cell + fl * 31.0);
        if (rnd > 1.0 - density * 0.4) {
            acc += vec3(smoothstep(size * 0.09 * fl, 0.0, length(f)) * 0.8);
        }
    }
    vec4 c = src(uv);
    return vec4(c.rgb + acc, max(c.a, clamp(acc.r, 0.0, 1.0)));
"""))
    return out
}

// MARK: - glitch and motion

private func glitchFx() -> [EffectDef] {
    var out: [EffectDef] = []
    out.append(EffectDef(
        id: "sshake", name: "Smooth Shake", desc: "Perlin camera shake.",
        category: "Glitch and motion", props: [
            PropDef("amount", "Amount", 0, 0.3, 0.03, 3),
            PropDef("speed", "Speed", 0, 10, 3, 2),
            PropDef("rot", "Rotation", 0, 15, 2, 2),
        ], glsl: """
    float t = uTime * speed;
    vec2 off = vec2(vnoise(vec2(t, 3.7)) - 0.5, vnoise(vec2(t, 9.2)) - 0.5) * amount * 2.0;
    float a = (vnoise(vec2(t, 21.0)) - 0.5) * rot * 0.01745;
    vec2 p = rot(uv - 0.5, a) + 0.5 + off;
    return src(clamp(p, 0.0, 1.0));
"""))
    out.append(EffectDef(
        id: "twitch", name: "Twitch", desc: "Random jumpy offsets.",
        category: "Glitch and motion", props: [
            PropDef("amount", "Amount", 0, 0.3, 0.05, 3),
            PropDef("rate", "Rate", 1, 20, 8, 0),
        ], glsl: """
    float slot = floor(uTime * rate);
    float r1 = hash11(slot * 1.37);
    float r2 = hash11(slot * 7.91);
    vec2 off = (r1 > 0.6 ? vec2((r2 - 0.5) * amount, 0.0) : (r2 > 0.6 ? vec2(0.0, (r1 - 0.5) * amount) : vec2(0.0)));
    return src(clamp(uv + off, 0.0, 1.0));
"""))
    out.append(EffectDef(
        id: "glitchslices", name: "Glitch Slices", desc: "Horizontal displaced bands.",
        category: "Glitch and motion", props: [
            PropDef("amount", "Amount", 0, 0.4, 0.1, 3),
            PropDef("slices", "Slices", 2, 30, 10, 0),
            PropDef("rate", "Rate", 1, 20, 6, 0),
        ], glsl: """
    float slot = floor(uTime * rate);
    float band = floor(uv.y * max(float(int(slices)), 2.0));
    float r = hash21(vec2(band, slot));
    float off = (r - 0.5) * amount * (r > 0.55 ? 1.0 : 0.0);
    return src(clamp(uv + vec2(off, 0.0), 0.0, 1.0));
"""))
    out.append(EffectDef(
        id: "vhs", name: "VHS", desc: "Tape wobble, tracking noise and bleed.",
        category: "Glitch and motion", props: [
            PropDef("wobble", "Wobble", 0, 0.1, 0.02, 3),
            PropDef("noise", "Noise", 0, 1, 0.3, 2),
            PropDef("bleed", "Color bleed", 0, 0.05, 0.008, 3),
        ], glsl: """
    float track = step(0.96, hash11(floor(uTime * 2.0)));
    float wob = sin(uv.y * 180.0 + uTime * 30.0) * wobble * (0.3 + track);
    vec2 duv = uv + vec2(wob, 0.0);
    float r = src(clamp(duv + vec2(bleed, 0.0), 0.0, 1.0)).r;
    vec4 c = src(clamp(duv, 0.0, 1.0));
    float b = src(clamp(duv - vec2(bleed, 0.0), 0.0, 1.0)).b;
    float n = (hash21(uv * uRes * 0.7 + uTime * 63.0) - 0.5) * noise * 0.35;
    float band = step(0.995, hash21(vec2(floor(uv.y * 240.0), floor(uTime * 8.0)))) * noise;
    return vec4(vec3(r, c.g, b) + n + band, c.a);
"""))
    out.append(EffectDef(
        id: "oscillate", name: "Oscillate", desc: "Sine wobble over time.",
        category: "Glitch and motion", props: [
            PropDef("amount", "Amount", 0, 0.3, 0.05, 3),
            PropDef("freq", "Frequency", 0.2, 8, 1.5, 2),
        ], glsl: """
    vec2 off = vec2(sin(uTime * freq), cos(uTime * freq * 0.8)) * amount;
    return src(clamp(uv + off, 0.0, 1.0));
"""))
    out.append(EffectDef(
        id: "autoshake", name: "Auto Shake", desc: "Beat-synced decay shake.",
        category: "Glitch and motion", props: [
            PropDef("amount", "Amount", 0, 0.3, 0.06, 3),
            PropDef("rate", "BPM", 60, 200, 120, 0),
        ], glsl: """
    float beat = uTime * rate / 60.0;
    float ph = fract(beat);
    float decay = exp(-ph * 5.0);
    float r1 = hash11(floor(beat));
    float r2 = hash11(floor(beat) + 4.7);
    vec2 off = vec2(r1 - 0.5, r2 - 0.5) * amount * decay * 2.0;
    return src(clamp(uv + off, 0.0, 1.0));
"""))
    out.append(EffectDef(
        id: "randisp", name: "Random Displace",
        desc: "Random movement of the whole layer (no pixel scatter). Amplitude and Displace X / Y set how far it wanders; Evolution (infinite) scrubs the random pattern and Speed animates it; Phase offsets it. Works with Motion Blur.",
        category: "Glitch and motion", props: [
            PropDef("rdAmp", "Amplitude", 0, 1, 0.05, 3),
            PropDef("rdX", "Displace X", 0, 1, 1, 2),
            PropDef("rdY", "Displace Y", 0, 1, 1, 2),
            PropDef("rdEvolve", "Evolution", -3600, 3600, 0, 1, nil, true, 360),
            PropDef("rdSpeed", "Evolution speed", 0, 20, 1, 2),
            PropDef("rdFreq", "Frequency", 0.1, 10, 1, 2),
            PropDef("rdPhase", "Phase", -360, 360, 0, 1, nil, true, 180),
            PropDef("rdSeed", "Random seed", 0, 1000, 0, 0),
        ], previewAnim: "oscillate", glsl: """
    float n = (rdEvolve / 360.0 + uTime * rdSpeed) * rdFreq + rdSeed * 13.7;
    vec2 asp = vec2(uRes.y / uRes.x, 1.0);
    vec2 d = vec2(vnoise(vec2(n, 1.7)) + 0.5 * vnoise(vec2(n * 2.3, 5.1)) - 0.75,
                  vnoise(vec2(n + rdPhase / 360.0 * 5.0, 8.3)) + 0.5 * vnoise(vec2(n * 2.3 + rdPhase / 360.0 * 5.0, 11.9)) - 0.75) * 2.0;
    vec2 p = uv - d * vec2(rdX, rdY) * rdAmp * asp;
    p = 1.0 - abs(1.0 - mod(p, 2.0));
    return src(p);
"""))
    out.append(EffectDef(
        id: "streaks", name: "Streaks", desc: "Directional light trails.",
        category: "Glitch and motion", props: [
            PropDef("amount", "Amount", 0, 1, 0.5, 2),
            PropDef("length", "Length", 0, 0.2, 0.06, 3),
            PropDef("angle", "Angle", 0, 3.1416, 0, 3),
        ], glsl: """
    vec2 dir = vec2(cos(angle), sin(angle)) * length / 8.0;
    vec3 acc = vec3(0.0);
    for (int i = 0; i < 8; i++) {
        acc += src(clamp(uv - dir * float(i), 0.0, 1.0)).rgb;
    }
    acc /= 8.0;
    vec4 c = src(uv);
    vec3 trail = max(acc - c.rgb, vec3(0.0));
    return vec4(c.rgb + trail * amount * 2.0, c.a);
"""))
    out.append(EffectDef(
        id: "timeslice", name: "Time Slice", desc: "Bands show different moments.",
        category: "Glitch and motion", props: [
            PropDef("slices", "Slices", 2, 16, 6, 0),
            PropDef("offset", "Time offset (s)", 0, 2, 0.4, 2),
        ], glsl: """
    // The renderer feeds each slice the same frame; the offset appears as
    // spatial displacement proportional to the slice's age, like the shipped
    // build did for live preview (true multi-frame needs the export pass).
    float band = floor(uv.y * max(float(int(slices)), 2.0));
    float r = hash11(band * 3.1);
    vec2 off = vec2((r - 0.5) * offset * 0.15, 0.0);
    return src(clamp(uv + off, 0.0, 1.0));
"""))
    return out
}

// MARK: - keying

private func keyingFx() -> [EffectDef] {
    var out: [EffectDef] = []
    out.append(EffectDef(
        id: "chromakey", name: "Chroma Key", desc: "Removes a color (green screen).",
        category: "Keying", props: [
            PropDef("tolerance", "Tolerance", 0, 1, 0.32, 2),
            PropDef("soft", "Edge softness", 0, 0.5, 0.1, 3),
            PropDef("spill", "Spill suppression", 0, 1, 0.4, 2),
        ], colors: [
            ColorParam("key", "Key color", Int32(bitPattern: 0xFF00FF00)),
        ], glsl: """
    vec4 c = src(uv);
    float d = distance(c.rgb, key.rgb);
    float m = smoothstep(tolerance, tolerance + soft, d);
    vec3 rgb = c.rgb;
    if (spill > 0.0) {
        float g = rgb.g - max(rgb.r, rgb.b) * 0.85;
        rgb.g -= clamp(g, 0.0, 1.0) * spill;
    }
    return vec4(rgb, c.a * m);
"""))
    out.append(EffectDef(
        id: "lumakey", name: "Luma Key", desc: "Keeps only the picked color (by brightness or by color). Invert flips what stays. Use the eyedropper to pick.",
        category: "Keying", props: [
            PropDef("mode", "Match by", 0, 1, 0, 0, ["Luma", "Color"]),
            PropDef("tolerance", "Tolerance", 0, 1, 0.12, 3),
            PropDef("soft", "Edge softness", 0, 0.5, 0.08, 3),
            PropDef("invert", "Invert", 0, 1, 0, 0, ["Off", "On"]),
        ], colors: [
            ColorParam("key", "Key color", Int32(bitPattern: 0xFFFFFFFF)),
        ], glsl: """
    vec4 c = src(uv);
    float dl = abs(luma(c.rgb) - luma(key.rgb));
    float dc = distance(c.rgb, key.rgb) * 0.57735;
    float d = mix(dl, dc, step(0.5, mode));
    float m = 1.0 - smoothstep(tolerance, tolerance + max(soft, 0.001), d);
    m = mix(m, 1.0 - m, step(0.5, invert));
    return vec4(c.rgb, c.a * m);
"""))
    out.append(EffectDef(
        id: "bevel", name: "Bevel", desc: "Lit 3D edge on the layer's shape. Smooth, chisel or pillow, with light angle.",
        category: "Stylize", props: [
            PropDef("style", "Style", 0, 4, 0, 0, ["Smooth", "Chisel", "Pillow", "Emboss", "Sharp"]),
            PropDef("size", "Size (px)", 1, 30, 8, 1),
            PropDef("depth", "Depth", 0, 4, 1.5, 2),
            PropDef("angle", "Light angle", -180, 180, 135, 0, nil, true, 180),
            PropDef("bvSpec", "Specular", 0, 2, 0, 2),
            PropDef("bvTintAmt", "Tint amount", 0, 1, 0, 2),
            PropDef("bvOpacity", "Opacity", 0, 1, 1, 2),
        ], colors: [
            ColorParam("hi", "Highlight", Int32(bitPattern: 0xFFFFFFFF)),
            ColorParam("sh", "Shadow", Int32(bitPattern: 0xFF000000)),
            ColorParam("bvTint", "Tint", Int32(bitPattern: 0xFFFFFFFF)),
        ], glsl: """
    vec4 c = src(uv);
    vec2 px = size / uRes;
    vec2 dir = vec2(cos(angle * 0.0174533), sin(angle * 0.0174533)) * px;
    float a1 = src(uv + dir * 0.25).a + src(uv + dir * 0.5).a + src(uv + dir * 0.75).a + src(uv + dir).a;
    float a2 = src(uv - dir * 0.25).a + src(uv - dir * 0.5).a + src(uv - dir * 0.75).a + src(uv - dir).a;
    float g = (a2 - a1) * 0.25;
    float sg = sign(g);
    float st = floor(style + 0.5);
    if (st == 1.0) g = sg * sqrt(abs(g));
    else if (st == 2.0) g = -g;
    else if (st == 3.0) g = -sg * sqrt(abs(g));
    else if (st == 4.0) g = clamp(g * 3.0, -1.0, 1.0);
    float h = clamp(g * depth, 0.0, 1.0);
    float s = clamp(-g * depth, 0.0, 1.0);
    vec3 rgb = c.rgb + hi.rgb * h * 0.9;
    rgb = rgb * (1.0 - s * 0.65) + sh.rgb * s * 0.25;
    rgb += hi.rgb * h * h * h * bvSpec;
    rgb = mix(rgb, bvTint.rgb * c.a, bvTintAmt * clamp(h + s, 0.0, 1.0));
    return mix(c, vec4(rgb, c.a), bvOpacity);
"""))
    return out
}

// MARK: - transform and time (single-instance, kind 1)

private func timeFx() -> [EffectDef] {
    var out: [EffectDef] = []
    out.append(EffectDef(
        id: "remap", name: "Time Remap", desc: "Speed ramps and time-remap keyframes.",
        category: "Transform and time", kind: 1, props: [
            PropDef("remapT", "Time Remap (s)", 0, 600, 0, 2),
            PropDef("remapSpeed", "Speed", 0.1, 4, 1, 2),
            PropDef("remapInterp", "Frame interpolation", 0, 2, 0, 0,
                    ["Off", "Frame Blend", "Optical Flow"]),
        ], glsl: """
    return src(uv);   // the renderer reads the remap tracks before sampling
"""))
    out.append(EffectDef(
        id: "particles", name: "Particle World", desc: "Birth-to-death particle field (CC Particle World style).",
        category: "Generate", kind: 1, props: [
            PropDef("pCount", "Birth Rate (amount)", 8, 4000, 400, 0),
            PropDef("pOpacity", "Max Opacity", 0, 1, 1, 2),
            PropDef("pFadeIn", "Fade In (life)", 0.001, 1, 0.1, 2),
            PropDef("pFadeOut", "Fade Out (life)", 0.001, 1, 0.5, 2),
            PropDef("pBurst", "Explosion (0 = drift, 1 = burst out)", 0, 1, 1, 2),
            PropDef("pBurstForce", "Explosion Force", 0, 3, 0.6, 2),
            PropDef("pPosX", "Position X", -3, 3, 0, 2),
            PropDef("pPosY", "Position Y", -3, 3, 0, 2),
            PropDef("pPosZ", "Position Z", -4, 4, 0, 2),
            PropDef("pRadX", "Radius X", 0, 4, 0.1, 2),
            PropDef("pRadY", "Radius Y", 0, 4, 0.1, 2),
            PropDef("pRadZ", "Radius Z", 0, 4, 0.1, 2),
            PropDef("pSize", "Particle Size", 0.002, 0.2, 0.012, 3),
            PropDef("pSizeVar", "Size Variation", 0, 1, 0.8, 2),
            PropDef("pSizeEnd", "Death Size (x)", 0, 3, 1, 2),
            PropDef("pSpread", "Velocity Variance", 0, 3, 1, 2),
            PropDef("pSpeed", "Velocity", 0, 3, 0.12, 2),
            PropDef("pGravity", "Gravity", -2, 2, 0, 2),
            PropDef("pResist", "Resistance", 0, 1, 0, 2),
            PropDef("pWobble", "Extra (wobble)", 0, 3, 0.4, 2),
            PropDef("pLife", "Longevity (s)", 0.5, 20, 3, 2),
            PropDef("pSeed", "Random Seed", 0, 100, 0, 0),
            PropDef("pSoftEdge", "Soft emitter edge", 0, 1, 0.6, 2),
            PropDef("pDirX", "Direction X", -1, 1, 0, 2),
            PropDef("pDirY", "Direction Y", -1, 1, 0, 2),
            PropDef("pDirZ", "Direction Z", -1, 1, 0, 2),
            PropDef("pDof", "Depth of Field", 0, 2, 0.6, 2),
            PropDef("pFocus", "Focus Depth", -4, 4, 0, 2),
            PropDef("pShowSrc", "Show source", 0, 1, 1, 0, ["Off", "On"]),
        ], colors: [
            ColorParam("pColA", "Birth color", Int32(bitPattern: 0xFFFFFFFF)),
            ColorParam("pColB", "Death color", Int32(bitPattern: 0xFFFFFFFF)),
        ], glsl: """
    // The renderer simulates particles on the CPU (state survives frames);
    // this pass only runs when pShowSrc keeps the source visible.
    return src(uv);
"""))
    out.append(EffectDef(
        id: "particular", name: "Particular", desc: "3D particle system with its own Particle Designer. Follows the comp camera and is occluded by 3D layers.",
        category: "Generate", kind: 1, props: [
            PropDef("ptEmType", "Emitter Type", 0, 3, 0, 0,["Point","Box","Sphere","Grid"]),
            PropDef("ptBehavior", "Emitter Behavior", 0, 1, 0, 0,["Continuous","Explode"]),
            PropDef("ptRate", "Particles/sec", 1, 2000, 225, 0),
            PropDef("ptPosX", "Position X", -3, 3, 0, 2),
            PropDef("ptPosY", "Position Y", -3, 3, 0, 2),
            PropDef("ptPosZ", "Position Z", -4, 4, 0, 2),
            PropDef("ptSizeX", "Radius X", 0, 4, 0.3, 2),
            PropDef("ptSizeY", "Radius Y", 0, 4, 0.3, 2),
            PropDef("ptSizeZ", "Radius Z", 0, 4, 0.3, 2),
            PropDef("ptGridN", "Grid cells", 2, 16, 6, 0),
            PropDef("ptSeed", "Random Seed", 0, 100, 0, 0),
            PropDef("ptMotion", "Motion", 0, 4, 0, 0,["Default","Bidirectional","Directional","Disc","Inward"]),
            PropDef("ptVel", "Velocity", 0, 3, 0.3, 2),
            PropDef("ptVelRand", "Velocity Random", 0, 1, 0.5, 2),
            PropDef("ptSpread", "Spread", 0, 2, 0.4, 2),
            PropDef("ptDirX", "Direction X", -1, 1, 0, 2),
            PropDef("ptDirY", "Direction Y", -1, 1, 1, 2),
            PropDef("ptDirZ", "Direction Z", -1, 1, 0, 2),
            PropDef("ptLife", "Particle Life (s)", 0.2, 20, 3, 2),
            PropDef("ptLifeRand", "Life Random", 0, 1, 0.3, 2),
            PropDef("ptSize", "Particle Size", 0.002, 0.2, 0.012, 3),
            PropDef("ptSoft", "Softness", 0, 1, 0.5, 2),
            PropDef("ptDof", "Depth of Field", 0, 2, 0, 2),
            PropDef("ptFocus", "Focus Depth", -4, 4, 0, 2),
            PropDef("ptSizeRand", "Size Random", 0, 1, 0.5, 2),
            PropDef("ptSizeStart", "Size at Birth", 0, 3, 1, 2),
            PropDef("ptSizeEnd", "Size at Death", 0, 3, 1, 2),
            PropDef("ptOpacity", "Opacity", 0, 1, 1, 2),
            PropDef("ptFadeIn", "Fade In", 0.001, 1, 0.05, 3),
            PropDef("ptFadeOut", "Fade Out", 0.001, 1, 0.3, 3),
            PropDef("ptGravity", "Gravity", -3, 3, 0, 2),
            PropDef("ptWindX", "Wind X", -3, 3, 0, 2),
            PropDef("ptWindY", "Wind Y", -3, 3, 0, 2),
            PropDef("ptWindZ", "Wind Z", -3, 3, 0, 2),
            PropDef("ptAir", "Air Resistance", 0, 1, 0, 2),
            PropDef("ptTurb", "Turbulence", 0, 3, 0, 2),
            PropDef("ptTurbFreq", "Turbulence Scale", 0.05, 5, 1, 2),
            PropDef("ptSwirl", "Swirl (rad/s)", -6, 6, 0, 2),
            PropDef("ptSwirlPull", "Swirl Pull", 0, 1, 0, 2),
            PropDef("ptAttract", "Attractor Strength", 0, 1, 0, 2),
            PropDef("ptAttX", "Attractor X", -3, 3, 0, 2),
            PropDef("ptAttY", "Attractor Y", -3, 3, 0, 2),
            PropDef("ptAttZ", "Attractor Z", -3, 3, 0, 2),
            PropDef("ptFloorOn", "Floor", 0, 1, 0, 0,["Off","On"]),
            PropDef("ptFloorY", "Floor Y", -3, 3, -1, 2),
            PropDef("ptBounce", "Bounce", 0, 1, 0.5, 2),
            PropDef("ptTurbSpeed", "Turbulence Speed", 0, 5, 1, 2),
            PropDef("ptOcclude", "Occlude", 0, 1, 1, 0,["Off","On"]),
            PropDef("ptShowSrc", "Show source", 0, 1, 0, 0,["Off","On"]),
        ], colors: [
            ColorParam("ptColA", "Birth color", Int32(bitPattern: 0xFFFFE08A)),
            ColorParam("ptColB", "Death color", Int32(bitPattern: 0xFFFF5A1F)),
        ], glsl: """
    return src(uv);   // drawn by the particle renderer; this pass only runs when Show source is on
"""))
    out.append(EffectDef(
        id: "tile", name: "Tile", desc: "Repeats the layer as tiles.",
        category: "Transform and time", props: [
            PropDef("tileX", "Columns", 1, 10, 3, 0),
            PropDef("tileY", "Rows", 1, 10, 3, 0),
            PropDef("tileMirror", "Mirror", 0, 1, 0, 0, ["Off", "On"]),
        ], glsl: """
    float nx = max(floor(tileX), 1.0);
    float ny = max(floor(tileY), 1.0);
    vec2 t = fract(uv * vec2(nx, ny));
    if (tileMirror > 0.5) {
        vec2 c = floor(uv * vec2(nx, ny));
        if (mod(c.x, 2.0) > 0.5) t.x = 1.0 - t.x;
        if (mod(c.y, 2.0) > 0.5) t.y = 1.0 - t.y;
    }
    return src(t);
"""))
    out.append(EffectDef(
        id: "transform", name: "Transform", desc: "Effect-space offset/scale/rotate.",
        category: "Transform and time", props: [
            PropDef("tOffX", "Offset X", -1, 1, 0, 3),
            PropDef("tOffY", "Offset Y", -1, 1, 0, 3),
            PropDef("tScale", "Scale", 0.1, 4, 1, 3),
            PropDef("tRot", "Rotation", -180, 180, 0, 1),
        ], glsl: """
    vec2 p = (uv - 0.5) / max(tScale, 0.01);
    p = rot(p, radians(tRot));
    p += vec2(tOffX, tOffY) * 0.5;
    return src(clamp(p + 0.5, 0.0, 1.0));
"""))
    // shake_* presets (the shipped app shipped with a few)
    for (i, style) in [("handheld", "Handheld camera"), ("impact", "Impact"),
                       ("earthquake", "Earthquake")].enumerated() {
        let amt: Float = [0.012, 0.05, 0.09][i]
        let spd: Float = [2.5, 7, 12][i]
        out.append(EffectDef(
            id: "shake_\(style.0)", name: "Shake: \(style.1)",
            desc: "Ready-made \(style.1.lowercased()) shake preset.",
            category: "Glitch and motion", builtin: true, glsl: """
    float t = uTime * \(String(format: "%.2f", spd));
    vec2 off = vec2(vnoise(vec2(t, 3.7)) - 0.5, vnoise(vec2(t, 9.2)) - 0.5) * \(String(format: "%.4f", amt)) * 2.0;
    return src(clamp(uv + off, 0.0, 1.0));
"""))
    }
    return out
}

// MARK: - parent lock (read by Xf.chainMatrix; draws nothing itself)

private func parentFx() -> [EffectDef] {
    [EffectDef(
        id: "parentlock", name: "Parent Lock", desc: "Stops this layer inheriting its parent's rotation, scale or movement (ferris wheel cabins stay upright).",
        category: "Transform and time", kind: 1, props: [
            PropDef("plRot", "Lock rotation (0 / 1)", 0, 1, 1, 0),
            PropDef("plScale", "Lock scale (0 / 1)", 0, 1, 0, 0),
            PropDef("plMove", "Lock movement (0 / 1)", 0, 1, 0, 0),
        ], glsl: "return src(uv);")]
}


// MARK: - CC Jaws

private func sliderFx() -> [EffectDef] {
    return [EffectDef(
        id: "slidercontrol", name: "Slider Control",
        desc: "Expression control (like After Effects). Add it to a Null, keyframe or script the slider, then read it from any property's expression with slider(\"Layer name\") — or slider(\"Layer name\", 2) for the second one.",
        category: "Transform and time", props: [
            PropDef("slider", "Slider", -100000, 100000, 0, 2),
        ], glsl: "return src(uv);"
    )]
}

private func jawsFx() -> [EffectDef] {
    return [EffectDef(
        id: "ccjaws", name: "CC Jaws", desc: "Toothed jaws close over the layer from two sides (triangle, square, round or wave teeth).",
        category: "Stylize", props: [
            PropDef("jComp", "Completion (%)", 0, 100, 50, 1),
            PropDef("jShape", "Jaw shape", 0, 3, 0, 0, ["Triangle", "Square", "Round", "Wave"]),
            PropDef("jOrient", "Direction", 0, 1, 0, 0, ["Top / Bottom", "Left / Right"]),
            PropDef("jW", "Tooth width (px)", 4, 1000, 80, 0),
            PropDef("jH", "Tooth height (px)", 0, 1000, 80, 0),
            PropDef("jShift", "Tooth offset", 0, 1, 0, 2),
            PropDef("jInter", "Interlock (0 / 1)", 0, 1, 1, 0),
            PropDef("jSoft", "Edge softness (px)", 0, 60, 1.5, 1),
            PropDef("jInv", "Invert (0 / 1)", 0, 1, 0, 0),
        ], glsl: """
    vec4 c = src(uv);
    vec2 P = uv * uRes;
    bool vert = jOrient > 0.5;
    float along = vert ? P.y : P.x;          // runs along the teeth
    float across = vert ? P.x : P.y;         // jaws travel along this axis
    float len = vert ? uRes.x : uRes.y;
    float W = max(jW, 2.0);
    float H = max(jH, 0.0);
    float comp = clamp(jComp / 100.0, 0.0, 1.0);
    float travel = comp * (len * 0.5 + H) - H;

    float f1 = fract(along / W + jShift);
    float f2 = fract(along / W + jShift + (jInter > 0.5 ? 0.5 : 0.0));
    float p1, p2;
    if (jShape < 0.5) { p1 = 1.0 - abs(2.0 * f1 - 1.0); p2 = 1.0 - abs(2.0 * f2 - 1.0); }
    else if (jShape < 1.5) { p1 = f1 < 0.5 ? 1.0 : 0.0; p2 = f2 < 0.5 ? 1.0 : 0.0; }
    else if (jShape < 2.5) { float a = 2.0 * f1 - 1.0, b = 2.0 * f2 - 1.0; p1 = sqrt(max(1.0 - a * a, 0.0)); p2 = sqrt(max(1.0 - b * b, 0.0)); }
    else { p1 = 0.5 + 0.5 * cos(6.2831853 * (f1 - 0.5)); p2 = 0.5 + 0.5 * cos(6.2831853 * (f2 - 0.5)); }

    float edge1 = travel + p1 * H;           // first jaw: distance from the start edge
    float edge2 = travel + p2 * H;           // second jaw: distance from the far edge
    float s = max(jSoft, 0.001);
    float m1 = smoothstep(edge1 - s, edge1 + s, across);              // 1 = outside jaw 1
    float m2 = smoothstep(edge2 - s, edge2 + s, len - across);        // 1 = outside jaw 2
    float vis = m1 * m2;
    if (jInv > 0.5) vis = 1.0 - vis;
    return c * vis;
"""
    )]
}

// MARK: - catalog

enum Builtins {
    static func all() -> [EffectDef] {
        var out: [EffectDef] = []
        out += lightGlow()
        out += jawsFx()
        out += sliderFx()
        out += colorFx()
        out += stylizeFx()
        out += distortFx()
        out += blurFx()
        out += generateFx()
        out += glitchFx()
        out += keyingFx()
        out += timeFx()
        out += extraFx()
        out += looksFx()
        out += motionFx()
        out += sapphireFx()
        out += sapphireDistortFx()
        out += sapphireMoreFx()
        out += sapphire2Fx()
        out += sapphire3Fx()
        out += sapphire4Fx()
        out += chromaTownFx()
        out += universeFx()
        out += aeTwixtorFx()
        out += saikiFx()
        out += bccFx()
        out += parentFx()
        for d in out {
            d.builtin = true
            if d.glsl.isEmpty { d.glsl = "return src(uv);" }
        }
        return out
    }

    /// The five bundled SDK examples — same ids/params, bodies identical to
    /// the Resource/sdk folders the IDE shows read-only.
    static let exampleIds = ["filmgrain", "tint_pulse", "crt_tv", "scan_wipe", "chroma"]

    static func exampleById(_ id: String) -> EffectDef? {
        switch id {
        case "tint_pulse":
            let d = EffectDef(id: "tint_pulse", name: "Tint Pulse",
                              desc: "Breathes a color tint over the layer.",
                              category: "Custom", builtin: true, bundled: true,
                              source: "bundle:sdk/examples/tint_pulse")
            d.props = [PropDef("rate", "Rate", 0.1, 6, 1.2, 2)]
            d.colors = [ColorParam("tint", "Tint", Int32(bitPattern: 0xFFFF7A9E))]
            d.previewAnim = "fade"
            d.glsl = """
    vec4 c = src(uv);
    float p = 0.5 + 0.5 * sin(uTime * rate * 6.2831);
    return vec4(mix(c.rgb, tint.rgb, p * 0.65), c.a);
"""
            return d
        case "crt_tv":
            let d = EffectDef(id: "crt_tv", name: "CRT TV",
                              desc: "Curved glass, scan mask and glow.",
                              category: "Custom", builtin: true, bundled: true,
                              source: "bundle:sdk/examples/crt_tv")
            d.props = [PropDef("curve", "Curve", 0, 1, 0.3, 2),
                       PropDef("mask", "Mask", 0, 1, 0.5, 2)]
            d.previewAnim = "swipe"
            d.glsl = """
    vec2 cc = uv - 0.5;
    vec2 duv = 0.5 + cc * (1.0 + curve * dot(cc, cc) * 1.6);
    if (duv.x < 0.0 || duv.x > 1.0 || duv.y < 0.0 || duv.y > 1.0) return vec4(0.0);
    vec4 c = src(duv);
    float m = 1.0 - mask * 0.35 * (0.5 + 0.5 * sin(duv.x * uRes.x * 3.14159));
    return vec4(c.rgb * m + vec3(luma(c.rgb)) * 0.18, c.a);
"""
            return d
        case "scan_wipe":
            let d = EffectDef(id: "scan_wipe", name: "Scan Wipe",
                              desc: "A scan line wipes between original and graded.",
                              category: "Custom", builtin: true, bundled: true,
                              source: "bundle:sdk/examples/scan_wipe")
            d.props = [PropDef("center", "Center", -0.2, 1.2, 0.5, 3),
                       PropDef("soft", "Softness", 0.01, 0.5, 0.08, 3)]
            d.colors = [ColorParam("grade", "Graded color", Int32(bitPattern: 0xFF7FD4FF))]
            d.previewAnim = "wipe"
            d.glsl = """
    vec4 c = src(uv);
    float m = smoothstep(center - soft, center + soft, uv.y);
    vec3 g = vec3(luma(c.rgb)) * grade.rgb * 1.4;
    return vec4(mix(c.rgb, g, m), c.a);
"""
            return d
        case "chroma":
            let d = EffectDef(id: "chroma", name: "Chromatic Aberration",
                              desc: "RGB channels split apart at the edges.",
                              category: "Custom", builtin: true, bundled: true,
                              source: "bundle:sdk/examples/chroma")
            d.props = [PropDef("amount", "Amount", 0, 0.05, 0.006, 3)]
            d.previewAnim = "cut"
            d.glsl = """
    vec2 dir = (uv - 0.5);
    float r = src(clamp(uv + dir * amount, 0.0, 1.0)).r;
    float b = src(clamp(uv - dir * amount, 0.0, 1.0)).b;
    vec4 c = src(uv);
    return vec4(r, c.g, b, c.a);
"""
            return d
        default:
            let d = EffectDef(id: "filmgrain", name: "Film Grain",
                              desc: "Animated analog film grain.",
                              category: "Custom", builtin: true, bundled: true,
                              source: "bundle:sdk/examples/filmgrain")
            d.props = [PropDef("amount", "Amount", 0, 1, 0.3, 2),
                       PropDef("size", "Size", 0.5, 4, 1.5, 2)]
            d.previewAnim = "fade"
            d.glsl = """
    vec4 c = src(uv);
    float n = vnoise(uv * uRes / (size * 3.0) + vec2(uTime * 61.7, uTime * 23.9));
    return vec4(c.rgb + (n - 0.5) * amount * 0.28, c.a);
"""
            return d
        }
    }
}
