// BuiltinsChromaTown.swift — ChromaTown: morphing chromatic streak / blur utility.
// Splits the image into colorized subdivisions along a start→end transform path (scale, rotation, lens
// distortion, blur, position) — directional, linear and radial blurs plus chromatic separation in one effect.
// Chroma Style: Chromatic Spectrum / Start-End Colorize / Start-End Fill. Stateless, so it works on stills and exports.

import Foundation

let chromaTownStyles = ["Chromatic Spectrum", "Start/End Colorize", "Start/End Fill"]

func chromaTownFx() -> [EffectDef] {
    let d = EffectDef(
        id: "chromatown", name: "Universe ChromaTown",
        desc: "Morphing colour distortions: a chromatic streak and blur that splits the image into colourised subdivisions with varying transforms. Combines directional, linear and radial blur with chromatic separation. Open the Dashboard for 32 presets.",
        category: "Distort", props: [
            PropDef("ctStyle", "Chroma Style", 0, 2, 0, 0, chromaTownStyles),
            PropDef("ctFalloff", "Falloff", 0, 1, 0.35, 2),
            PropDef("ctGamma", "Falloff Gamma", 0.1, 4, 1, 2),
            PropDef("ctComp", "Completeness", 0, 1, 1, 2),
            PropDef("ctCompC", "Completeness Center", 0, 1, 0.5, 2),
            PropDef("ctCap", "Completeness Capped", 0, 1, 1, 0, ["Off", "On"]),
            PropDef("ctSAmt", "Start Color Amount", 0, 100, 100, 1),
            PropDef("ctSX", "Start X", -1, 2, 0.5, 3),
            PropDef("ctSY", "Start Y", -1, 2, 0.5, 3),
            PropDef("ctSScale", "Start Scale", 20, 300, 80, 1),
            PropDef("ctSRot", "Start Rotation", -360, 360, 5, 1),
            PropDef("ctSLens", "Start Lens Distortion", -50, 50, 11, 1),
            PropDef("ctSBlur", "Start Blur", 0, 100, 21, 1),
            PropDef("ctEAmt", "End Color Amount", 0, 100, 100, 1),
            PropDef("ctEX", "End X", -1, 2, 0.5, 3),
            PropDef("ctEY", "End Y", -1, 2, 0.5, 3),
            PropDef("ctEScale", "End Scale", 20, 300, 96.5, 1),
            PropDef("ctERot", "End Rotation", -360, 360, -1.7, 1),
            PropDef("ctELens", "End Lens Distortion", -50, 50, 2, 1),
            PropDef("ctEBlur", "End Blur", 0, 100, 0, 1),
            PropDef("ctSwap", "Swap Start/End", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("ctColorful", "Colorfulness", 0, 200, 100, 1),
            PropDef("ctMix", "Mix With Original", 0, 1, 0, 2),
        ], colors: [
            ColorParam("ctSC", "Start Color", Int32(bitPattern: 0xFF8AD2FF)),
            ColorParam("ctEC", "End Color", Int32(bitPattern: 0xFFFFC08A)),
        ], glsl: """
    vec2 asp = vec2(uRes.x / uRes.y, 1.0);
    vec4 orig = src(uv);
    float comp = max(ctComp, 0.001);
    float lo = ctCompC - comp * 0.5;
    if (ctCap > 0.5) { lo = clamp(lo, 0.0, 1.0 - comp); }
    vec3 acc = vec3(0.0); vec3 wsum = vec3(0.0001); float aacc = 0.0; float asum = 0.0001;
    for (int i = 0; i < 32; i++) {
        float t = (float(i) + 0.5) / 32.0;
        float tt = lo + comp * t;
        float k = ctSwap > 0.5 ? 1.0 - tt : tt;
        vec2 c = mix(vec2(ctSX, ctSY), vec2(ctEX, ctEY), k);
        float sc = max(mix(ctSScale, ctEScale, k) * 0.01, 0.01);
        float rot = radians(mix(ctSRot, ctERot, k));
        float lens = mix(ctSLens, ctELens, k) * 0.02;
        float bl = mix(ctSBlur, ctEBlur, k) * 0.0006;
        vec2 p = (uv - c) * asp / sc;
        p *= 1.0 + lens * dot(p, p);
        float cs = cos(rot), sn = sin(rot);
        p = vec2(cs * p.x - sn * p.y, sn * p.x + cs * p.y);
        vec2 q = p / asp + c;
        vec2 dir = normalize(p + vec2(0.0001)) / asp * bl;
        vec4 s = (src(q - dir) + src(q) * 2.0 + src(q + dir)) * 0.25;
        vec3 col;
        float amt = mix(ctSAmt, ctEAmt, k) * 0.01;
        if (ctStyle < 0.5) {
            col = 0.5 + 0.5 * cos(6.28318 * (tt + vec3(0.0, 0.33, 0.67)));
            col = mix(vec3(1.0), col * 1.6, amt);
        } else {
            vec3 tc = mix(ctSC.rgb, ctEC.rgb, k);
            col = mix(vec3(1.0), tc, amt);
        }
        float w = pow(max(1.0 - ctFalloff * abs(t - 0.5) * 2.0, 0.001), ctGamma);
        vec3 sc3 = s.rgb;
        if (ctStyle > 1.5) { sc3 = vec3(s.a); }
        else if (ctStyle > 0.5) { sc3 = vec3(dot(s.rgb, vec3(0.299, 0.587, 0.114))); }
        acc += sc3 * col * w; wsum += col * w; aacc += s.a * w; asum += w;
    }
    vec3 rgb = acc / wsum;
    float a = aacc / asum;
    float lm = dot(rgb, vec3(0.299, 0.587, 0.114));
    rgb = mix(vec3(lm), rgb, ctColorful * 0.01);
    vec4 o = vec4(rgb, a);
    return mix(o, orig, ctMix);
""")
    return [d]
}

// MARK: - 32 presets (key → value). Colours: ctSC / ctEC as 0xAARRGGBB.

struct ChromaTownPreset {
    let name: String
    let vals: [String: Float]
    let sc: UInt32, ec: UInt32
    var swatch: [UInt32] { [sc, ec] }
}

enum ChromaTownPresets {
    static let all: [ChromaTownPreset] = {
        var out: [ChromaTownPreset] = []
        func add(_ n: String, _ style: Float, _ v: [String: Float], _ s: UInt32, _ e: UInt32) {
            var m: [String: Float] = ["ctStyle": style]
            for (k, x) in v { m[k] = x }
            out.append(ChromaTownPreset(name: n, vals: m, sc: s, ec: e))
        }
        let cols: [(UInt32, UInt32)] = [(0xFF8AD2FF, 0xFFFFC08A), (0xFFFF2D55, 0xFF2D5BFF), (0xFF00E5C8, 0xFF7B2DFF), (0xFFFFB300, 0xFFFF3D00)]
        for (i, c) in cols.enumerated() {
            let f = Float(i)
            add("Spectrum Zoom \(i + 1)", 0, ["ctSScale": 100, "ctEScale": 130 + f * 25, "ctSRot": 0, "ctERot": 0, "ctSLens": 0, "ctELens": 0, "ctSBlur": 10, "ctEBlur": 30 + f * 10], c.0, c.1)
            add("Vortex \(i + 1)", 0, ["ctSScale": 100, "ctEScale": 100 + f * 8, "ctSRot": 0, "ctERot": 40 + f * 45, "ctSLens": 0, "ctELens": 10, "ctSBlur": 5, "ctEBlur": 25], c.0, c.1)
            add("Lens Warp \(i + 1)", 0, ["ctSScale": 80, "ctEScale": 96, "ctSRot": 5, "ctERot": -2, "ctSLens": 11 + f * 6, "ctELens": 2, "ctSBlur": 21, "ctEBlur": 0], c.0, c.1)
            add("Linear Streak \(i + 1)", 0, ["ctSX": 0.35 - f * 0.05, "ctEX": 0.65 + f * 0.05, "ctSY": 0.5, "ctEY": 0.5, "ctSScale": 100, "ctEScale": 100, "ctSRot": 0, "ctERot": 0, "ctSLens": 0, "ctELens": 0, "ctSBlur": 0, "ctEBlur": 0], c.0, c.1)
            add("Tint Sweep \(i + 1)", 1, ["ctSScale": 90, "ctEScale": 105 + f * 6, "ctSRot": 0, "ctERot": 6 * f, "ctSBlur": 8, "ctEBlur": 18, "ctFalloff": 0.2], c.0, c.1)
            add("Colorize Burst \(i + 1)", 1, ["ctSScale": 100, "ctEScale": 150 + f * 20, "ctSBlur": 15, "ctEBlur": 40, "ctSRot": 0, "ctERot": 0], c.0, c.1)
            add("Fill Glow \(i + 1)", 2, ["ctSScale": 95, "ctEScale": 125 + f * 10, "ctSBlur": 20, "ctEBlur": 50, "ctFalloff": 0.6], c.0, c.1)
            add("Soft Spectrum \(i + 1)", 0, ["ctSScale": 96, "ctEScale": 100, "ctSRot": 2, "ctERot": -2, "ctSBlur": 4 + f * 3, "ctEBlur": 0, "ctColorful": 70 + f * 20, "ctComp": 0.6 + f * 0.1], c.0, c.1)
        }
        return out
    }()
}
