// BuiltinsSapphire4.swift — S_Feedback, S_GradientMulti, S_WipeChecker, S_Zebrafy, BCC+ Prism, BCC Mosaic.
// Written from the Sapphire / Continuum parameter docs. Mocha / FX Editor / compare-mode controls are not included.
// Feedback is stateless here (previous frames are rebuilt by re-sampling the source through the feedback
// transform Max Steps times), so it works on stills, seeks and exports without a frame history.

import Foundation

/// Effects whose browser thumbnail uses the skyscraper sample photo.
let skyscraperFxIds: Set<String> = ["sfeedback", "sgradientmulti", "swipechecker", "szebrafy", "bccprism", "bccmosaic", "bcclightsweep", "prismdisplacement", "bccstrands", "bccgrunge", "bcccaustics", "bccextrude"]

private func maskProps(_ k: String) -> [PropDef] {
    [PropDef(k + "MaskUse", "Mask Use", 0, 1, 0, 0, ["Luma", "Alpha"]),
     PropDef(k + "InvMask", "Invert Mask", 0, 1, 0, 0, ["Off", "On"])]
}
/// Needs `vec4 s0 = src(uv);` and `vec4 o` in scope.
private func maskTail(_ k: String) -> String {
    """
        if (uHas0 > 0.5) {
            vec4 mk = in0(uv);
            float mm = \(k)MaskUse < 0.5 ? luma(mk.rgb) : mk.a;
            if (\(k)InvMask > 0.5) { mm = 1.0 - mm; }
            o = mix(s0, o, mm);
        }
        return o;
    """
}
private let applyModes = ["Normal", "Add", "Multiply", "Screen", "Difference"]
/// Apply `s` over `d` with a blend (both premultiplied). Expects `k + "Apply"` float.
private func applyExpr(_ k: String, _ d: String, _ s: String, _ out: String) -> String {
    """
        vec4 \(out) = \(s);
        if (\(k)Apply > 3.5) { \(out) = vec4(abs(\(d).rgb - \(s).rgb), max(\(d).a, \(s).a)); }
        else if (\(k)Apply > 2.5) { \(out) = vec4(1.0 - (1.0 - \(d).rgb) * (1.0 - \(s).rgb), max(\(d).a, \(s).a)); }
        else if (\(k)Apply > 1.5) { \(out) = vec4(\(d).rgb * \(s).rgb, \(s).a); }
        else if (\(k)Apply > 0.5) { \(out) = \(d) + \(s); }
    """
}

func sapphire4Fx() -> [EffectDef] {
    var out: [EffectDef] = []

    // MARK: S_Feedback
    out.append(EffectDef(
        id: "sfeedback", name: "S_Feedback",
        desc: "Video-feedback trails: previous output is zoomed, rotated, shifted, faded and combined with the current frame. Max Steps sets how many feedback cycles are rebuilt for each frame.",
        category: "Transform and time", props: [
            PropDef("fbSteps", "Max Steps", 2, 30, 15, 0),
            PropDef("fbPrev", "Prev Brightness", 0, 2, 0.8, 2),
            PropDef("fbHue", "Prev Hue Shift", -1, 1, 0, 3),
            PropDef("fbComb", "Combine New", 0, 6, 0, 0, ["Ave", "Max", "Screen", "Add", "Over", "Under", "Min"]),
            PropDef("fbNewOp", "New Opacity", 0, 10, 1, 2),
            PropDef("fbBlur", "Blur Amount", 0, 10, 0, 2),
            PropDef("fbCX", "Center X", -2, 2, 0, 3),
            PropDef("fbCY", "Center Y", -2, 2, 0, 3),
            PropDef("fbZ", "Z Dist", 0.5, 1.5, 0.95, 3),
            PropDef("fbRot", "Rotate", -180, 180, 3, 1),
            PropDef("fbSX", "Shift X", -1, 1, 0, 3),
            PropDef("fbSY", "Shift Y", -1, 1, 0, 3),
            PropDef("fbWrapX", "Wrap X", 0, 2, 0, 0, ["No", "Tile", "Reflect"]),
            PropDef("fbWrapY", "Wrap Y", 0, 2, 0, 0, ["No", "Tile", "Reflect"]),
        ] + maskProps("fb"), colors: [
            ColorParam("fbPrevC", "Prev Color", Int32(bitPattern: 0xFFFFFFFF)),
            ColorParam("fbNewC", "New Color", Int32(bitPattern: 0xFFFFFFFF)),
        ], inputs: ["Mask"], glsl: """
    vec2 asp = vec2(uRes.x / uRes.y, 1.0);
    vec2 cen = vec2(0.5) + vec2(fbCX, fbCY) * 0.5;
    float f = fbPrev;
    float fa = min(f, 0.999);
    vec3 ncol = fbNewC.rgb * fbNewOp;
    vec3 wc = vec3(1.0);
    vec2 p = uv;
    vec4 acc = vec4(0.0);
    float fk = 1.0; float trans = 1.0;
    float ang = radians(fbRot);
    for (int k = 0; k < 30; k++) {
        if (float(k) < fbSteps) {
            vec2 q = p; float inside = 1.0;
            if (fbWrapX > 1.5) { q.x = 1.0 - abs(1.0 - mod(q.x, 2.0)); } else if (fbWrapX > 0.5) { q.x = fract(q.x); } else if (q.x < 0.0 || q.x > 1.0) { inside = 0.0; }
            if (fbWrapY > 1.5) { q.y = 1.0 - abs(1.0 - mod(q.y, 2.0)); } else if (fbWrapY > 0.5) { q.y = fract(q.y); } else if (q.y < 0.0 || q.y > 1.0) { inside = 0.0; }
            vec4 s;
            if (fbBlur > 0.0) {
                float br = fbBlur * 0.004 * float(k + 1);
                s = (src(q) * 2.0 + src(q + vec2(br, 0.0)) + src(q - vec2(br, 0.0)) + src(q + vec2(0.0, br)) + src(q - vec2(0.0, br))) / 6.0;
            } else { s = src(q); }
            s *= inside;
            if (fbHue != 0.0) {
                vec3 h = rgb2hsv(max(s.rgb, vec3(0.0)));
                h.x = fract(h.x + fbHue * float(k));
                s.rgb = hsv2rgb(h);
            }
            s.rgb *= ncol * wc;
            s.a *= min(fbNewOp, 1.0);
            if (fbComb < 0.5) {
                float w = float(k) < fbSteps - 1.5 ? (1.0 - fa) * fk : fk;
                acc += s * w; fk *= fa;
            } else if (fbComb < 1.5) { acc = max(acc, s * fk); fk *= f; }
            else if (fbComb < 2.5) { vec4 t = s * fk; acc = 1.0 - (1.0 - acc) * (1.0 - t); fk *= f; }
            else if (fbComb < 3.5) { acc += s * fk; fk *= f; }
            else if (fbComb < 4.5) { acc += s * trans; trans *= f * (1.0 - s.a); }
            else if (fbComb < 5.5) { acc = s * fk + acc * (1.0 - s.a * fk); fk *= f; }
            else { acc = k == 0 ? s : min(acc, s * fk); fk *= f; }
            wc *= fbPrevC.rgb;
            vec2 d = (p - cen) * asp;
            p = cen + rot(d, ang) * fbZ / asp + vec2(fbSX, fbSY) * 0.5;
        }
    }
    vec4 s0 = src(uv);
    vec4 o = clamp(acc, 0.0, 1.0);
\(maskTail("fb"))
"""))

    // MARK: S_GradientMulti
    var gmProps: [PropDef] = [
        PropDef("gmSoft", "Softness", 0.01, 10, 1, 2),
        PropDef("gmFall", "Softness Falloff", 0, 10, 0, 2),
    ]
    var gmColors: [ColorParam] = []
    let gmDefaults: [(UInt32, Float, Float)] = [
        (0xFFFF0000, -0.972, -0.719), (0xFF00FF00, -0.972, 0.701), (0xFF0000FF, 0.972, 0.701),
        (0xFFFFFFFF, 0.972, -0.719), (0xFFFFFF00, -0.167, 0), (0xFF00FFFF, 0.167, 0),
    ]
    var gmBody = "    vec2 asp = vec2(uRes.x / uRes.y, 1.0);\n"
    for i in 1...6 {
        let d = gmDefaults[i - 1]
        gmProps += [PropDef("gmEn\(i)", "Point \(i) Enable", 0, 1, i <= 3 ? 1 : 0, 0, ["Off", "On"]),
                    PropDef("gmX\(i)", "Point \(i) X", -2, 2, d.1, 3), PropDef("gmY\(i)", "Point \(i) Y", -2, 2, d.2, 3),
                    PropDef("gmS\(i)", "Softness \(i)", 0.1, 10, 1, 2), PropDef("gmZ\(i)", "Size \(i)", 0.1, 10, 1, 2)]
        gmColors.append(ColorParam("gmC\(i)", "Color \(i)", Int32(bitPattern: d.0)))
        gmBody += """
            float lw\(i) = -1.0e9;
            if (gmEn\(i) > 0.5) {
                float d\(i) = length((uv - (vec2(0.5) + vec2(gmX\(i), gmY\(i)) * 0.5)) * asp);
                float e\(i) = 2.0 / max(gmSoft * gmS\(i), 0.05) * (1.0 + gmFall * d\(i));
                lw\(i) = -e\(i) * log(1.0 + 4.0 * d\(i) / gmZ\(i));
            }

        """
    }
    gmBody += "    float lm = max(max(max(lw1, lw2), max(lw3, lw4)), max(lw5, lw6));\n    vec3 gs = vec3(0.0); float ws = 0.0;\n"
    for i in 1...6 { gmBody += "    if (gmEn\(i) > 0.5) { float w = exp(lw\(i) - lm); gs += gmC\(i).rgb * w; ws += w; }\n" }
    gmBody += """
        vec3 col = gs / max(ws, 1.0e-6);
        vec4 s0 = src(uv);
        vec3 bg = s0.a > 0.0001 ? s0.rgb / s0.a * gmBg : vec3(0.0);
        vec3 r = col;
        if (gmComb > 4.5) { r = mix(2.0 * bg * col, 1.0 - 2.0 * (1.0 - bg) * (1.0 - col), step(0.5, bg)); }
        else if (gmComb > 3.5) { r = abs(bg - col); }
        else if (gmComb > 2.5) { r = 1.0 - (1.0 - bg) * (1.0 - col); }
        else if (gmComb > 1.5) { r = bg + col; }
        else if (gmComb > 0.5) { r = bg * col; }
        float a = gmOutOp > 0.5 ? 1.0 : s0.a;
        vec4 o = vec4(r * a, a);

    """ + maskTail("gm")
    gmProps += [PropDef("gmComb", "Combine", 0, 5, 0, 0, ["Grad Only", "Mult", "Add", "Screen", "Difference", "Overlay"]),
                PropDef("gmBg", "Bg Brightness", 0, 4, 1, 2),
                PropDef("gmOutOp", "Output Opacity", 0, 1, 1, 0, ["Copy From Input", "All Opaque"])] + maskProps("gm")
    out.append(EffectDef(id: "sgradientmulti", name: "S_GradientMulti",
        desc: "Smooth multi-color gradient from up to six colored control points, optionally combined with the layer.",
        category: "Generate", props: gmProps, colors: gmColors, inputs: ["Mask"], glsl: gmBody))

    // MARK: S_WipeChecker
    out.append(EffectDef(
        id: "swipechecker", name: "S_WipeChecker",
        desc: "Wipe transition from this layer to the Background input using a grid of growing or shrinking checkers. Animate Wipe Percent 0→1.",
        category: "Transform and time", props: [
            PropDef("wcDir", "Transition Dir", 0, 1, 0, 0, ["Wipe Off to Bg", "Wipe On from Bg"]),
            PropDef("wcPct", "Wipe Percent", 0, 1, 0.5, 3),
            PropDef("wcType", "Checkers", 0, 1, 1, 0, ["Shrink", "Grow"]),
            PropDef("wcSoft", "Edge Softness", 0, 5, 0, 2),
            PropDef("wcAngle", "Angle", -360, 360, 45, 1),
            PropDef("wcFreq", "Frequency", 0.1, 40, 6, 2),
            PropDef("wcRelW", "Rel Width", 0.1, 10, 1, 2),
            PropDef("wcRelWPre", "Rel Wid Pre Rot", 0.1, 10, 1, 2),
            PropDef("wcShX", "Shift X", -2, 2, 0, 3), PropDef("wcShY", "Shift Y", -2, 2, 0, 3),
            PropDef("wcGradAdd", "Grad Add", -10, 10, 0, 2),
            PropDef("wcGradAng", "Grad Angle", -360, 360, 0, 1),
            PropDef("wcBW", "Border Width", 0, 5, 0, 2),
            PropDef("wcBOp", "Border Opacity", 0, 1, 1, 2),
            PropDef("wcBSoft", "Border Softness", 0, 5, 0, 2),
            PropDef("wcBShift", "Border Shift", -5, 5, 0, 2),
            PropDef("wcGlow", "Border Glow", 0, 10, 0, 2),
            PropDef("wcGW", "Glow Width", 0, 2, 0.1, 2),
            PropDef("wcWR", "Width Red", 0, 4, 1, 2), PropDef("wcWG", "Width Green", 0, 4, 1.2, 2), PropDef("wcWB", "Width Blue", 0, 4, 1.4, 2),
            PropDef("wcNAmp", "Noise Amp", 0, 4, 1, 2), PropDef("wcNFreq", "Noise Freq", 0.1, 20, 16, 2), PropDef("wcNSpd", "Noise Speed", -10, 10, 2, 2),
        ], colors: [
            ColorParam("wcBC", "Border Color", Int32(bitPattern: 0xFFBF0000)),
            ColorParam("wcGC", "Glow Color", Int32(bitPattern: 0xFFFFFFFF)),
        ], inputs: ["Background"], glsl: """
    vec2 asp = vec2(uRes.x / uRes.y, 1.0);
    float a = radians(wcAngle);
    float t = wcDir > 0.5 ? 1.0 - wcPct : wcPct;
    vec2 sh = vec2(wcShX, wcShY) * 0.5;
    vec2 q = (uv - 0.5) * asp - sh;
    q.x /= wcRelWPre; q = rot(q, -a); q.x /= wcRelW; q *= wcFreq;
    vec2 id = floor(q);
    vec2 fr = fract(q) - 0.5;
    float s = max(abs(fr.x), abs(fr.y)) * 2.0;
    float chk = mod(id.x + id.y, 2.0);
    float g = 0.0;
    if (abs(wcGradAdd) > 0.0) {
        vec2 c = (id + 0.5) / wcFreq; c.x *= wcRelW; c = rot(c, a); c.x *= wcRelWPre;
        vec2 cuv = (c + sh) / asp + 0.5;
        vec2 gd = vec2(cos(radians(wcGradAng)), sin(radians(wcGradAng)));
        g = clamp(dot(cuv - 0.5, gd) + 0.5, 0.0, 1.0);
        if (wcGradAdd < 0.0) { g = 1.0 - g; }
    }
    float ga = abs(wcGradAdd);
    float tt = clamp(t * (1.0 + ga) - ga * g, 0.0, 1.0);
    bool fromCenter = (chk < 0.5) == (wcType > 0.5);
    float dist = fromCenter ? (tt - s) : (s - (1.0 - tt));
    float soft = max(wcSoft * 0.1, 0.003);
    float reveal = tt <= 0.0 ? 0.0 : (tt >= 1.0 ? 1.0 : smoothstep(-soft, soft, dist));
    vec4 s0 = src(uv);
    vec4 o = mix(s0, in0(uv), reveal);
    if (tt > 0.0 && tt < 1.0) {
        if (wcBW > 0.0) {
            float bw = wcBW * 0.05;
            float bm = 1.0 - smoothstep(bw * 0.5, bw * 0.5 + wcBSoft * 0.05 + 0.003, abs(dist - wcBShift * 0.05));
            o = mix(o, vec4(wcBC.rgb, 1.0), bm * wcBOp);
        }
        if (wcGlow > 0.0) {
            float n = 1.0 + wcNAmp * (vnoise(uv * asp * wcNFreq + vec2(uTime * wcNSpd, 0.0)) - 0.5) * 2.0;
            vec3 gr = exp(-abs(dist) / max(wcGW * 0.2 * vec3(wcWR, wcWG, wcWB), vec3(0.001)));
            o.rgb += wcGC.rgb * gr * wcGlow * max(n, 0.0);
        }
    }
    return o;
"""))

    // MARK: S_Zebrafy
    out.append(EffectDef(
        id: "szebrafy", name: "S_Zebrafy",
        desc: "Modulates the brightness of the clip with a sinusoid for a black-and-white solarized zebra-stripe look.",
        category: "Stylize", props: [
            PropDef("zfBlur", "Source Blur", 0, 5, 0.088, 3),
            PropDef("zfFreq", "Frequency", 0.01, 30, 4, 2),
            PropDef("zfPhase", "Phase Start", -10, 10, 0, 2),
            PropDef("zfSpeed", "Phase Speed", -5, 5, 0, 2),
            PropDef("zfBr", "Brightness", 0, 4, 1, 2),
            PropDef("zfOff", "Offset", -2, 2, 0, 2),
            PropDef("zfSbs", "Scale By Source", 0, 1, 0, 2),
            PropDef("zfAmp", "Scale By Src Amp", 0, 4, 1, 2),
            PropDef("zfMix", "Mix With Source", 0, 1, 0, 2),
        ] + maskProps("zf"), colors: [ColorParam("zfCol", "Color", Int32(bitPattern: 0xFFFFFFFF))], inputs: ["Mask"], glsl: """
    vec4 s0 = src(uv);
    vec3 u = s0.a > 0.0001 ? s0.rgb / s0.a : vec3(0.0);
    float r = zfBlur * 0.02;
    float l = luma(u) * 4.0;
    for (int i = 0; i < 8; i++) {
        float an = float(i) * 0.785398;
        vec4 t = src(uv + vec2(cos(an), sin(an)) * r * vec2(1.0 / (uRes.x / uRes.y), 1.0));
        l += t.a > 0.0001 ? luma(t.rgb / t.a) : 0.0;
    }
    l /= 12.0;
    float z = 0.5 + 0.5 * sin(6.2831853 * (l * zfFreq + zfPhase + zfSpeed * uTime));
    z = clamp((z - 0.5) * 1.5 + 0.5, 0.0, 1.0);
    vec3 col = vec3(z) * zfBr * zfCol.rgb + zfOff;
    col *= mix(1.0, clamp(l * zfAmp, 0.0, 1.0), zfSbs);
    col = max(mix(col, u, zfMix), vec3(0.0));
    vec4 o = vec4(col * s0.a, s0.a);
\(maskTail("zf"))
"""))

    // MARK: BCC+ Prism
    out.append(EffectDef(
        id: "bccprism", name: "BCC+ Prism",
        desc: "Prismatic color aberration: the image is smeared forward and backward along the Z axis (zoom / spiral) and tinted with three prism colors.",
        category: "Stylize", props: [
            PropDef("prWeight", "Weight", 0, 1, 1, 2),
            PropDef("prGlobal", "Global Transform", 0, 4, 1, 2),
            PropDef("prLock", "Lock Center Start/End", 0, 1, 1, 0, ["Off", "On"]),
            PropDef("prCSX", "Center Start X", -2, 2, 0, 3), PropDef("prCSY", "Center Start Y", -2, 2, 0, 3),
            PropDef("prCEX", "Center End X", -2, 2, 0, 3), PropDef("prCEY", "Center End Y", -2, 2, 0, 3),
            PropDef("prSS", "Scale Start", 0.2, 3, 0.9, 3), PropDef("prSE", "Scale End", 0.2, 3, 1.1, 3),
            PropDef("prAS", "Angle Start", -180, 180, -3, 1), PropDef("prAE", "Angle End", -180, 180, 3, 1),
            PropDef("prOS", "Offset Start", -1, 1, 0, 3), PropDef("prOE", "Offset End", -1, 1, 0, 3),
            PropDef("prFall", "Falloff", 0, 1, 0.5, 2),
            PropDef("prApply", "Blend Mode", 0, 4, 0, 0, applyModes),
            PropDef("prAMix", "Apply Mix", 0, 1, 1, 2),
            PropDef("prEdge", "Edge Mode", 0, 2, 1, 0, ["Transparent", "Repeat", "Reflect"]),
            PropDef("prOrig", "Mix with Original", 0, 1, 0, 2),
        ], colors: [
            ColorParam("prShort", "Short Color", Int32(bitPattern: 0xFF1A4DFF)),
            ColorParam("prMid", "Mid Color", Int32(bitPattern: 0xFF33FF66)),
            ColorParam("prLong", "Long Color", Int32(bitPattern: 0xFFFF3319)),
        ], inputs: ["Mask"], glsl: """
    vec2 asp = vec2(uRes.x / uRes.y, 1.0);
    vec2 cs = vec2(0.5) + vec2(prCSX, prCSY) * 0.5;
    vec2 ce = prLock > 0.5 ? cs : vec2(0.5) + vec2(prCEX, prCEY) * 0.5;
    float bias = exp2(-(prFall - 0.5) * 4.0);
    vec4 acc = vec4(0.0); vec3 ws = vec3(0.0);
    for (int i = 0; i < 20; i++) {
        float t = (float(i) + 0.5) / 20.0;
        float tq = mix(clamp(floor(t * 5.0) / 4.0, 0.0, 1.0), t, prWeight);
        float tb = pow(tq, bias);
        vec2 c = mix(cs, ce, tb);
        float sc = 1.0 + (mix(prSS, prSE, tb) - 1.0) * prGlobal;
        float an = radians(mix(prAS, prAE, tb)) * prGlobal;
        float of = 1.0 - mix(prOS, prOE, tb) * prGlobal;
        vec2 d = rot((uv - c) * asp, an) / max(sc, 0.05) * of;
        vec2 p = c + d / asp;
        float inside = 1.0;
        if (prEdge > 1.5) { p = 1.0 - abs(1.0 - mod(p, 2.0)); }
        else if (prEdge > 0.5) { p = clamp(p, 0.0, 1.0); }
        else if (p.x < 0.0 || p.x > 1.0 || p.y < 0.0 || p.y > 1.0) { inside = 0.0; }
        vec4 s = src(p) * inside;
        vec3 pc = tq < 0.5 ? mix(prShort.rgb, prMid.rgb, tq * 2.0) : mix(prMid.rgb, prLong.rgb, tq * 2.0 - 1.0);
        acc.rgb += s.rgb * pc; ws += pc; acc.a += s.a;
    }
    vec4 s0 = src(uv);
    vec4 pr = vec4(acc.rgb / max(ws, vec3(0.0001)), acc.a / 20.0);
\(applyExpr("pr", "s0", "pr", "ap"))
    vec4 o = mix(pr, ap, prAMix);
    o = mix(o, s0, prOrig);
\(maskTail("pr"))
"""))
    out[out.count - 1].props += maskProps("pr")

    // MARK: BCC Mosaic
    out.append(EffectDef(
        id: "bccmosaic", name: "BCC Mosaic",
        desc: "Pixelates the image into a mosaic. Scramble shuffles the pixels; Scramble Seed picks the random arrangement.",
        category: "Stylize", props: [
            PropDef("msLock", "Lock Pixelation", 0, 1, 1, 0, ["Off", "On"]),
            PropDef("msPx", "Pixelate X", 0, 100, 40, 1),
            PropDef("msPy", "Pixelate Y", 0, 100, 40, 1),
            PropDef("msScr", "Scramble", 0, 100, 0, 1),
            PropDef("msSeed", "Scramble Seed", 0, 100, 0, 0),
            PropDef("msApply", "Apply Mode", 0, 4, 0, 0, applyModes),
            PropDef("msAMix", "Apply Mix", 0, 1, 1, 2),
        ] + maskProps("ms"), inputs: ["Mask"], glsl: """
    vec2 asp = vec2(uRes.x / uRes.y, 1.0);
    float py = msLock > 0.5 ? msPx : msPy;
    float kx = clamp(msPx / 100.0, 0.0, 1.0); float ky = clamp(py / 100.0, 0.0, 1.0);
    vec2 n = vec2(exp(mix(log(max(uRes.x, 4.0)), log(3.0 * asp.x), kx)), exp(mix(log(max(uRes.y, 4.0)), log(3.0), ky)));
    vec2 id = floor(uv * n);
    float scr = msScr / 100.0;
    if (scr > 0.0) {
        float pick = hash21(id * 1.31 + msSeed * 3.1);
        if (pick < scr) { id = floor(vec2(hash21(id + 5.2 + msSeed), hash21(id + 9.7 + msSeed)) * n); }
    }
    vec4 s0 = src(uv);
    vec4 s = src((id + 0.5) / n);
\(applyExpr("ms", "s0", "s", "ap"))
    vec4 o = mix(s, ap, msAMix);
\(maskTail("ms"))
"""))

    // MARK: BCC Light Sweep
    out.append(EffectDef(
        id: "bcclightsweep", name: "BCC Light Sweep",
        desc: "A linear beam of light that sweeps across the image, with optional edge lighting. Animate Light Center to sweep.",
        category: "Light and glow", props: [
            PropDef("lswCX", "Light Center X", -2, 2, 0, 3), PropDef("lswCY", "Light Center Y", -2, 2, 0, 3),
            PropDef("lswDir", "Direction", -360, 360, 45, 1),
            PropDef("lswFall", "Falloff Distance", 0.01, 6, 1.5, 2),
            PropDef("lswCone", "Cone Width", 0.01, 3, 0.35, 2),
            PropDef("lswCenterPct", "Center %", 0, 0.99, 0.3, 2),
            PropDef("lswShape", "Shape", 0.05, 8, 1, 2),
            PropDef("lswInt", "Intensity", 0, 6, 1.2, 2),
            PropDef("lswAmb", "Ambient Light", 0, 300, 100, 0),
            PropDef("lswFrom", "Edges From", 0, 4, 0, 0, ["Luma", "Alpha", "Red", "Green", "Blue"]),
            PropDef("lswEdgeInt", "Edge Intensity", 0, 6, 0, 2),
            PropDef("lswThr", "Edge Threshold", 0, 1, 0.1, 2),
            PropDef("lswPre", "Edge Pre Blur", 0, 10, 0, 2),
            PropDef("lswViewEdges", "View Edges Only", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("lswEdgeMode", "Edge Color Mode", 0, 2, 1, 0, ["Ignore", "Mix", "Prefer"]),
            PropDef("lswApply", "Apply Mode", 0, 3, 0, 0, ["Normal", "Add", "Multiply", "Screen"]),
            PropDef("lswAMix", "Apply Mix", 0, 1, 1, 2),
            PropDef("lswShadowT", "Shadow Transparent", 0, 1, 0, 0, ["Off", "On"]),
        ] + maskProps("lsw"), colors: [
            ColorParam("lswCol", "Light Color", Int32(bitPattern: 0xFFFFFFFF)),
            ColorParam("lswEdgeCol", "Edge Color", Int32(bitPattern: 0xFFFFD27F)),
        ], inputs: ["Mask"], glsl: """
    vec2 asp = vec2(uRes.x / uRes.y, 1.0);
    vec4 s0 = src(uv);
    vec3 u0 = s0.a > 0.0001 ? s0.rgb / s0.a : vec3(0.0);
    vec2 c = vec2(0.5) + vec2(lswCX, lswCY) * 0.5;
    float an = radians(lswDir);
    vec2 dv = vec2(cos(an), sin(an)); vec2 nv = vec2(-dv.y, dv.x);
    vec2 pp = (uv - c) * asp;
    float al = dot(pp, dv); float ac = dot(pp, nv);
    float x = abs(ac) / (max(lswCone, 0.001) * 0.5);
    float cp = clamp(lswCenterPct, 0.0, 0.99);
    float tt = clamp((x - cp) / (1.0 - cp), 0.0, 1.0);
    float prof = 1.0 - pow(tt, 1.0 / max(lswShape, 0.05));
    float att = al > 0.0 ? exp(-al / max(lswFall, 0.01)) : 1.0;
    float beam = prof * att;
    float ed = 0.0;
    if (lswEdgeInt > 0.0 || lswViewEdges > 0.5) {
        float r = 0.002 + lswPre * 0.004;
        vec2 ex = vec2(r / asp.x, 0.0); vec2 ey = vec2(0.0, r);
        vec4 a = src(uv + ex); vec4 b = src(uv - ex); vec4 c2 = src(uv + ey); vec4 d2 = src(uv - ey);
        float fa = lswFrom < 0.5 ? luma(a.rgb / max(a.a, 0.0001)) : (lswFrom < 1.5 ? a.a : (lswFrom < 2.5 ? a.r : (lswFrom < 3.5 ? a.g : a.b)));
        float fb = lswFrom < 0.5 ? luma(b.rgb / max(b.a, 0.0001)) : (lswFrom < 1.5 ? b.a : (lswFrom < 2.5 ? b.r : (lswFrom < 3.5 ? b.g : b.b)));
        float fc = lswFrom < 0.5 ? luma(c2.rgb / max(c2.a, 0.0001)) : (lswFrom < 1.5 ? c2.a : (lswFrom < 2.5 ? c2.r : (lswFrom < 3.5 ? c2.g : c2.b)));
        float fd = lswFrom < 0.5 ? luma(d2.rgb / max(d2.a, 0.0001)) : (lswFrom < 1.5 ? d2.a : (lswFrom < 2.5 ? d2.r : (lswFrom < 3.5 ? d2.g : d2.b)));
        ed = smoothstep(lswThr, lswThr + 0.1, length(vec2(fa - fb, fc - fd)) * 2.0);
    }
    if (lswViewEdges > 0.5) { return vec4(vec3(ed), 1.0); }
    vec3 ecol = lswEdgeMode < 0.5 ? lswCol.rgb : (lswEdgeMode < 1.5 ? (lswCol.rgb + lswEdgeCol.rgb) * 0.5 : mix(lswCol.rgb, lswEdgeCol.rgb, ed));
    vec3 applied = lswCol.rgb * beam * lswInt + ecol * ed * lswEdgeInt * beam;
    vec3 base = u0 * lswAmb * 0.01;
    vec3 lit = base + applied * (0.35 + u0);
    vec3 res = lit;
    if (lswApply > 2.5) { res = 1.0 - (1.0 - base) * (1.0 - applied); }
    else if (lswApply > 1.5) { res = base * (1.0 + applied * 3.0); }
    else if (lswApply > 0.5) { res = base + applied; }
    res = mix(lit, res, lswAMix);
    float a = s0.a;
    if (lswShadowT > 0.5) { a *= clamp(max(applied.r, max(applied.g, applied.b)), 0.0, 1.0); }
    vec4 o = vec4(res * a, a);
\(maskTail("lsw"))
"""))

    // MARK: Prism Displacement
    out.append(EffectDef(
        id: "prismdisplacement", name: "Prism Displacement",
        desc: "Distorts and displaces pixels with a prism-like chromatic split driven by the luminance of another layer (the Map Layer input; without one it uses the layer's own luma).",
        category: "Distort", props: [
            PropDef("pdiMode", "Map Use", 0, 1, 0, 0, ["Luma Value", "Luma Gradient"]),
            PropDef("pdiAmt", "Amount", -1, 1, 0.08, 3),
            PropDef("pdiAngle", "Direction", -360, 360, 90, 1),
            PropDef("pdiSpread", "Prism Spread", 0, 4, 1.5, 2),
            PropDef("pdiSat", "Prism Color", 0, 1, 1, 2),
            PropDef("pdiMid", "Map Midpoint", 0, 1, 0.5, 2),
            PropDef("pdiBlur", "Map Blur", 0, 10, 0.5, 2),
            PropDef("pdiInv", "Invert Map", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("pdiEdge", "Edge Mode", 0, 2, 0, 0, ["Repeat", "Transparent", "Mirror"]),
            PropDef("pdiMix", "Mix with Original", 0, 1, 0, 2),
        ], inputs: ["Map Layer"], glsl: """
    vec2 asp = vec2(uRes.x / uRes.y, 1.0);
    vec4 s0 = src(uv);
    float an = radians(pdiAngle);
    vec2 dv = vec2(cos(an), sin(an));
    float r = 0.001 + pdiBlur * 0.003;
    vec2 ex = vec2(r / asp.x, 0.0); vec2 ey = vec2(0.0, r);
    float m = 0.0; float mx1 = 0.0; float mx0 = 0.0; float my1 = 0.0; float my0 = 0.0;
    if (uHas0 > 0.5) {
        m = (luma(in0(uv).rgb) * 2.0 + luma(in0(uv + ex).rgb) + luma(in0(uv - ex).rgb) + luma(in0(uv + ey).rgb) + luma(in0(uv - ey).rgb)) / 6.0;
        mx1 = luma(in0(uv + ex * 2.0).rgb); mx0 = luma(in0(uv - ex * 2.0).rgb);
        my1 = luma(in0(uv + ey * 2.0).rgb); my0 = luma(in0(uv - ey * 2.0).rgb);
    } else {
        vec4 a = src(uv); m = luma(a.rgb / max(a.a, 0.0001));
        vec4 b = src(uv + ex * 2.0); mx1 = luma(b.rgb / max(b.a, 0.0001));
        b = src(uv - ex * 2.0); mx0 = luma(b.rgb / max(b.a, 0.0001));
        b = src(uv + ey * 2.0); my1 = luma(b.rgb / max(b.a, 0.0001));
        b = src(uv - ey * 2.0); my0 = luma(b.rgb / max(b.a, 0.0001));
    }
    vec2 off = pdiMode < 0.5 ? dv * (m - pdiMid) * 2.0 * pdiAmt : vec2(mx1 - mx0, my1 - my0) * 4.0 * pdiAmt;
    if (pdiInv > 0.5) { off = -off; }
    vec4 acc = vec4(0.0); vec3 ws = vec3(0.0);
    for (int i = 0; i < 12; i++) {
        float t = (float(i) + 0.5) / 12.0 * 2.0 - 1.0;
        vec2 p = uv + off * (1.0 + t * pdiSpread) / vec2(asp.x, 1.0);
        float inside = 1.0;
        if (pdiEdge > 1.5) { p = 1.0 - abs(1.0 - mod(p, 2.0)); }
        else if (pdiEdge > 0.5) { if (p.x < 0.0 || p.x > 1.0 || p.y < 0.0 || p.y > 1.0) { inside = 0.0; } }
        vec3 w = mix(vec3(1.0), hsv2rgb(vec3(0.72 * (1.0 - (t * 0.5 + 0.5)), 1.0, 1.0)), pdiSat);
        vec4 s = src(p) * inside;
        acc.rgb += s.rgb * w; ws += w; acc.a += s.a;
    }
    vec4 o = vec4(acc.rgb / max(ws, vec3(0.0001)), acc.a / 12.0);
    return mix(o, s0, pdiMix);
"""))

    // MARK: BCC Organic Strands (3D strand particles; drawn by the particle renderer, so it follows the 3D camera / layer transform)
    out.append(EffectDef(
        id: "bccstrands", name: "BCC Organic Strands",
        desc: "Particle-based 3D strands that grow from a source shape with organic noise, gravity and an optional destination point. Works with the comp camera, 3D rotation and the layer transform.",
        category: "Generate", kind: 1, props: [
            PropDef("stCount", "Count", 1, 600, 80, 0),
            PropDef("stDirX", "Direction X", -1, 1, 0, 2), PropDef("stDirY", "Direction Y", -1, 1, 1, 2), PropDef("stDirZ", "Direction Z", -1, 1, 0, 2),
            PropDef("stSpread", "Spread (deg)", 0, 180, 30, 1),
            PropDef("stLength", "Length", 0.05, 4, 0.9, 2), PropDef("stLenVar", "Length Variance", 0, 1, 0.4, 2),
            PropDef("stThick", "Thickness", 0.05, 6, 1, 2), PropDef("stThickVar", "Thickness Variance", 0, 1, 0.3, 2),
            PropDef("stTaper", "Taper", 0, 1, 0.7, 2),
            PropDef("stDensity", "Density", 4, 150, 60, 0),
            PropDef("stGravity", "Gravity", -3, 3, 0.4, 2),
            PropDef("stShape", "Source Shape", 0, 4, 2, 0, ["Point", "Line", "Circle", "Sphere", "Plane"]),
            PropDef("stScaleX", "Source Scale X", 0, 3, 0.25, 2), PropDef("stScaleY", "Source Scale Y", 0, 3, 0.25, 2), PropDef("stScaleZ", "Source Scale Z", 0, 3, 0.25, 2),
            PropDef("stSrcSup", "Source Noise Suppression", 0, 1, 0.5, 2),
            PropDef("stDestOn", "Use Destination Point", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("stDX", "Dest X", -3, 3, 0, 2), PropDef("stDY", "Dest Y", -3, 3, 1, 2), PropDef("stDZ", "Dest Z", -3, 3, 0, 2),
            PropDef("stPull", "Strength and Pull", 0, 1, 0.6, 2),
            PropDef("stDstSup", "Destination Noise Suppression", 0, 1, 0, 2),
            PropDef("stBend", "Random Bend", 0, 2, 0.5, 2),
            PropDef("stNThick", "Thickness Noise", 0, 1, 0, 2),
            PropDef("stFreq", "Noise Frequency", 0.05, 10, 1.5, 2),
            PropDef("stEvSpeed", "Auto Evolve Speed", -5, 5, 0.4, 2),
            PropDef("stEvX", "Evolve X", -20, 20, 0, 2), PropDef("stEvY", "Evolve Y", -20, 20, 0, 2), PropDef("stEvZ", "Evolve Z", -20, 20, 0, 2),
            PropDef("stIndiv", "Individual Particle Noise", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("stMove", "Move Progress", -4, 4, 0, 2),
            PropDef("stMoveSpeed", "Move Speed", -4, 4, 0, 2),
            PropDef("stMoveRand", "Move Random %", 0, 1, 0, 2),
            PropDef("stLoop", "Loop at Distance", 0.2, 4, 1, 2),
            PropDef("stGScale", "Global Scale", 0.05, 4, 1, 2),
            PropDef("stCX", "Center X", -3, 3, 0, 2), PropDef("stCY", "Center Y", -3, 3, 0, 2), PropDef("stCZ", "Center Z", -4, 4, 0, 2),
            PropDef("stRotX", "Rotate X", -360, 360, 0, 1), PropDef("stRotY", "Rotate Y", -360, 360, 0, 1), PropDef("stRotZ", "Rotate Z", -360, 360, 0, 1),
            PropDef("stMirror", "Mirror Mode", 0, 3, 0, 0, ["Off", "Mirror X", "Mirror Y", "Mirror X (copy)"]),
            PropDef("stSize", "Particle Size", 0.002, 0.2, 0.012, 3),
            PropDef("stSoft", "Softness", 0, 1, 0.5, 2),
            PropDef("stOpacity", "Opacity Boost", 0, 1, 1, 2),
            PropDef("stFadeIn", "Fade In (along strand)", 0.001, 1, 0.05, 2),
            PropDef("stFadeOut", "Fade Out (along strand)", 0.001, 1, 0.5, 2),
            PropDef("stOcclude", "Occlude by 3D layers", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("stSeed", "Random Seed", 0, 100, 0, 0),
            PropDef("stShowSrc", "Show source", 0, 1, 0, 0, ["Off", "On"]),
        ], colors: [
            ColorParam("stColA", "Base Color", Int32(bitPattern: 0xFFFFC857)),
            ColorParam("stColB", "Tip Color", Int32(bitPattern: 0xFF4FC3F7)),
        ], glsl: "return src(uv);"))
    return out
}
