// BuiltinsUniverse.swift — Universe ShrinkRay (tilt-shift miniature) and Universe Noir (dramatic noir lighting).

import Foundation

func universeFx() -> [EffectDef] {
    var out: [EffectDef] = []

    // MARK: ShrinkRay
    let patchModes = ["Off", "Focus", "Blur"]
    var srProps: [PropDef] = [
        PropDef("srMask", "Mask View", 0, 1, 0, 0, ["Off", "On"]),
        PropDef("srBlur", "Blur Magnitude", 0, 100, 40, 1),
        PropDef("srCX", "Focus Center X", 0, 1, 0.5, 3),
        PropDef("srCY", "Focus Center Y", 0, 1, 0.5, 3),
        PropDef("srAngle", "Orientation", -180, 180, 0, 1),
        PropDef("srSize", "Focus Size", 0, 1, 0.2, 3),
        PropDef("srFall", "Falloff", 0.01, 1, 0.35, 3),
        PropDef("srSat", "Saturation Boost", 0, 2, 1.25, 2),
        PropDef("srCon", "Contrast Boost", 0, 2, 1.1, 2),
    ]
    var srGlsl = """
    vec2 asp = vec2(uRes.x / uRes.y, 1.0);
    float ang = radians(srAngle);
    vec2 ax = vec2(-sin(ang), cos(ang));
    float d = abs(dot((uv - vec2(srCX, srCY)) * asp, ax));
    float m = smoothstep(srSize, srSize + srFall, d);
"""
    for i in 1...3 {
        srProps += [PropDef("srP\(i)Mode", "Patch \(i)", 0, 2, 0, 0, patchModes),
                    PropDef("srP\(i)X", "Patch \(i) X", 0, 1, 0.5, 3),
                    PropDef("srP\(i)Y", "Patch \(i) Y", 0, 1, 0.5, 3),
                    PropDef("srP\(i)R", "Patch \(i) Radius", 0.01, 1, 0.15, 3),
                    PropDef("srP\(i)F", "Patch \(i) Feather", 0.01, 1, 0.2, 3)]
        srGlsl += """
    if (srP\(i)Mode > 0.5) {
        float pd = length((uv - vec2(srP\(i)X, srP\(i)Y)) * asp);
        float pm = smoothstep(srP\(i)R, srP\(i)R + srP\(i)F, pd);      // 0 inside, 1 outside
        if (srP\(i)Mode < 1.5) { m = min(m, pm); } else { m = max(m, 1.0 - pm); }
    }
"""
    }
    srGlsl += """
    if (srMask > 0.5) { return vec4(vec3(1.0 - m), 1.0); }
    float r = srBlur * 0.0007 * m;
    vec4 acc = src(uv); float ws = 1.0;
    for (int i = 0; i < 24; i++) {
        float fi = float(i) + 1.0;
        float a = fi * 2.39996;
        float rr = sqrt(fi / 24.0) * r;
        vec2 o = vec2(cos(a), sin(a)) * rr * vec2(1.0 / asp.x, 1.0);
        acc += src(uv + o); ws += 1.0;
    }
    vec4 o = acc / ws;
    float lm = dot(o.rgb, vec3(0.299, 0.587, 0.114));
    o.rgb = mix(vec3(lm), o.rgb, srSat);
    o.rgb = (o.rgb - 0.5) * srCon + 0.5;
    return o;
"""
    out.append(EffectDef(
        id: "universeshrinkray", name: "Universe ShrinkRay",
        desc: "Make big things look tiny with a simulated tilt-shift. Control blur magnitude, orientation and falloff; three Focus/Blur patches clean up the frame; Mask View shows exactly what is blurred and in focus. Best on wide shots.",
        category: "Blur", props: srProps, glsl: srGlsl))

    // MARK: Noir
    out.append(EffectDef(
        id: "universenoir", name: "Universe Noir",
        desc: "Dramatic noir lighting: saturation control, optically captured vignette, flicker, venetian-blind light patterns, tint and grain.",
        category: "Light and glow", props: [
            PropDef("nrSat", "Saturation", 0, 1, 0, 2),
            PropDef("nrCon", "Contrast", 0, 3, 1.4, 2),
            PropDef("nrBright", "Brightness", -1, 1, -0.05, 2),
            PropDef("nrVig", "Vignette Amount", 0, 1, 0.6, 2),
            PropDef("nrVigSize", "Vignette Size", 0, 1.5, 0.55, 2),
            PropDef("nrVigSoft", "Vignette Softness", 0.01, 1.5, 0.6, 2),
            PropDef("nrVigOpt", "Optical Vignette", 0, 1, 0.3, 2),
            PropDef("nrFlick", "Flicker Amount", 0, 1, 0.15, 2),
            PropDef("nrFlickSpd", "Flicker Speed", 0, 30, 12, 1),
            PropDef("nrVen", "Venetian Amount", 0, 1, 0.5, 2),
            PropDef("nrVenCnt", "Venetian Count", 1, 40, 10, 1),
            PropDef("nrVenAng", "Venetian Angle", -90, 90, -20, 1),
            PropDef("nrVenDuty", "Venetian Slat Width", 0.05, 0.95, 0.5, 2),
            PropDef("nrVenSoft", "Venetian Softness", 0.01, 0.5, 0.12, 2),
            PropDef("nrVenScroll", "Venetian Scroll", -2, 2, 0, 2),
            PropDef("nrTint", "Tint Amount", 0, 1, 0.15, 2),
            PropDef("nrGrain", "Grain", 0, 1, 0.2, 2),
        ], colors: [
            ColorParam("nrTintC", "Tint Color", Int32(bitPattern: 0xFF9DB4D0)),
        ], glsl: """
    vec4 s = src(uv);
    vec3 c = s.rgb;
    float lm = dot(c, vec3(0.299, 0.587, 0.114));
    c = mix(vec3(lm), c, nrSat);
    c = mix(c, c * nrTintC.rgb * 1.4, nrTint);
    c = (c - 0.5) * nrCon + 0.5 + nrBright;
    vec2 asp = vec2(uRes.x / uRes.y, 1.0);
    vec2 p = (uv - 0.5) * asp;
    float vd = length(p);
    float v = smoothstep(nrVigSize, nrVigSize + nrVigSoft, vd);
    c *= 1.0 - nrVig * v;
    c *= 1.0 - nrVigOpt * pow(clamp(vd * 1.2, 0.0, 1.0), 4.0);
    float fl = sin(uTime * nrFlickSpd) * 0.5 + sin(uTime * nrFlickSpd * 2.37 + 1.7) * 0.3 + sin(uTime * nrFlickSpd * 5.1) * 0.2;
    c *= 1.0 + nrFlick * fl * 0.5;
    float va = radians(nrVenAng);
    float vp = (uv.x * asp.x * sin(va) + uv.y * cos(va)) * nrVenCnt + uTime * nrVenScroll;
    float vf = fract(vp);
    float slat = smoothstep(0.0, nrVenSoft, vf) * (1.0 - smoothstep(nrVenDuty, nrVenDuty + nrVenSoft, vf));
    c *= mix(1.0, 0.25 + 0.75 * slat, nrVen);
    float g = fract(sin(dot(uv * uRes + uTime, vec2(12.9898, 78.233))) * 43758.5453) - 0.5;
    c += g * nrGrain * 0.25;
    return vec4(clamp(c, 0.0, 1.0) * s.a, s.a);
"""))

    // MARK: BCC+ Chroma Bands (BCC Lights)
    out.append(EffectDef(
        id: "bccchromabands", name: "BCC+ Chroma Bands",
        desc: "BCC Lights: customizable rainbow diffraction bands around a light source, simulating prismatic dispersion. View switches between Output and the band Element.",
        category: "Light and glow", props: [
            PropDef("cbView", "View", 0, 1, 0, 0, ["Output", "Element"]),
            PropDef("cbBlend", "Blend", 0, 4, 0, 0, ["Add", "Screen", "Normal", "Multiply", "Overlay"]),
            PropDef("cbBright", "Brightness", 0, 5, 1, 2),
            PropDef("cbX", "Position X", -0.5, 1.5, 0.5, 3),
            PropDef("cbY", "Position Y", -0.5, 1.5, 0.5, 3),
            PropDef("cbScale", "Scale", 0.05, 4, 1, 2),
            PropDef("cbAspect", "Aspect", 0.1, 4, 1, 2),
            PropDef("cbSoft", "Softness", 0.01, 1, 0.35, 2),
            PropDef("cbChroma", "Chroma", 0, 1, 1, 2),
            PropDef("cbAngle", "Angle", -360, 360, 0, 1, nil, true, 180),
            PropDef("cbCycles", "Cycles", 0, 12, 1.5, 2),
            PropDef("cbDensity", "Density", 0, 200, 0, 0),
            PropDef("cbTaper", "Taper", 0.1, 4, 1, 2),
            PropDef("cbSpread", "Spread", 0.2, 3, 1, 2),
            PropDef("cbOffset", "Offset", 0, 0.95, 0.3, 2),
            PropDef("cbNoise", "Noise", 0, 1, 0, 2),
            PropDef("cbGpu", "GPU Rendering", 0, 3, 0, 0, ["Default", "16 Bit Float", "32 Bit Float", "Disabled"]),
        ], colors: [
            ColorParam("cbColor", "Color", Int32(bitPattern: 0xFFFFFFFF)),
        ], glsl: """
    vec4 s = src(uv);
    vec2 asp = vec2(uRes.x / uRes.y, 1.0);
    vec2 p = (uv - vec2(cbX, cbY)) * asp;
    float ca = cos(radians(cbAngle)), sa = sin(radians(cbAngle));
    p = vec2(ca * p.x + sa * p.y, -sa * p.x + ca * p.y);
    p.x /= max(cbAspect, 0.05);
    float r = length(p) / max(cbScale * 0.5, 0.001);
    float ang = atan(p.y, p.x);
    float rn = (r - cbOffset) / max(1.0 - cbOffset, 0.001);
    float sf = max(cbSoft, 0.001) * 0.5;
    float inside = smoothstep(0.0, sf, rn) * (1.0 - smoothstep(1.0 - sf, 1.0, rn));
    inside = pow(clamp(inside, 0.0, 1.0), max(cbTaper, 0.05));
    float n = vnoise(vec2(ang * 4.0, r * 10.0)) - 0.5;
    float t = pow(clamp(rn, 0.0, 1.0), max(cbSpread, 0.05)) * cbCycles + n * cbNoise * 2.0;
    vec3 rb = hsv2rgb(vec3(fract(t), cbChroma, 1.0));
    float rays = cbDensity < 0.5 ? 1.0 : mix(0.2, 1.0, 0.5 + 0.5 * cos(ang * cbDensity + n * cbNoise * 6.0));
    vec3 band = rb * cbColor.rgb * inside * rays * (1.0 + n * cbNoise) * cbBright;
    if (cbView > 0.5) { return vec4(band, 1.0); }
    vec3 c = s.rgb;
    float bl = cbBlend;
    if (bl < 0.5) { c = s.rgb + band; }
    else if (bl < 1.5) { c = 1.0 - (1.0 - s.rgb) * (1.0 - clamp(band, 0.0, 1.0)); }
    else if (bl < 2.5) { c = mix(s.rgb, band, clamp(max(band.r, max(band.g, band.b)), 0.0, 1.0)); }
    else if (bl < 3.5) { c = s.rgb * mix(vec3(1.0), band, clamp(inside, 0.0, 1.0)); }
    else { c = mix(2.0 * s.rgb * band, 1.0 - 2.0 * (1.0 - s.rgb) * (1.0 - band), step(0.5, s.rgb)); c = mix(s.rgb, c, clamp(inside, 0.0, 1.0)); }
    return vec4(c, max(s.a, clamp(max(band.r, max(band.g, band.b)), 0.0, 1.0) * (bl < 0.5 ? 1.0 : 0.0)));
"""))
    return out
}
