// BuiltinsUniverse4.swift — uni.Edge Glow and uni.HUD Components with dashboard presets (from the Universe docs).
import Foundation

private let hudTypes = ["None", "Arc", "Square Outline", "Chevron", "Triangle Outline", "Target Brackets", "Crosshair", "Hex Outline", "Radar Ticks", "Dot Grid", "Pointer"]
private let hudAnims = ["None", "Oscillate Horizontal", "Oscillate Vertical", "Orbit 2D", "Rotate", "Pulse Scale"]

private func hudElemGLSL(_ k: Int) -> String {
    let P = "h\(k)"
    func L(_ n: String) -> String { k == 1 ? "\(P)\(n)" : "(\(P)Link > 0.5 ? h1\(n) : \(P)\(n))" }
    return """
    if (\(P)Type > 0.5) {
        vec2 pos = vec2(\(L("PX")), \(L("PY"))) * fxs; float rz = \(L("RZ")); float sc = \(L("Sc"));
        float an = \(L("Anim")); float at = uTime * \(L("Spd")) * hMS; float amp = \(L("Amp")); float orad = \(L("Orb"));
        vec2 off = vec2(0.0);
        if (an > 0.5 && an < 1.5) { off.x = sin(at * 3.0) * amp * 20.0 * fxs; }
        else if (an < 2.5 && an > 1.5) { off.y = sin(at * 3.0) * amp * 20.0 * fxs; }
        else if (an < 3.5 && an > 2.5) { off = vec2(cos(at * 2.0), sin(at * 2.0)) * orad * 10.0 * fxs; }
        else if (an < 4.5 && an > 3.5) { rz += at * 60.0; }
        else if (an > 4.5) { sc *= 1.0 + 0.15 * amp * sin(at * 3.0); }
        float R = \(P)Rad * fxs; float sw = \(P)SW * fxs; float seg = \(P)Seg;
        int nc = int(\(P)Cn);
        for (int i = 0; i < 100; i++) {
            if (i > nc) { break; }
            float ci = float(i);
            vec2 rnd = vec2(hash21(vec2(ci, \(P)RS + hSeed)), hash21(vec2(ci + 7.0, \(P)RS + hSeed + 3.0))) - 0.5;
            vec2 q = p0 - pos - off - vec2(\(P)CX, \(P)CY) * fxs * ci - rnd * \(P)RO * 10.0 * fxs;
            float ang = radians(rz + \(P)CR * ci + rnd.x * \(P)RR * 3.6);
            float s = max(sc * (1.0 + \(P)CS * ci / 100.0) * (1.0 + rnd.y * \(P)RSc / 100.0), 0.02);
            float ca = cos(ang), sa = sin(ang);
            q = vec2(ca * q.x + sa * q.y, -sa * q.x + ca * q.y) / s;
            float d = 1000.0; float t = \(P)Type; vec2 aq = abs(q);
            if (t < 1.5) { d = abs(length(q) - R) - sw * 0.5; float dg = mod(degrees(atan(q.y, q.x)) + 360.0, 360.0); if (dg > seg) { d = 1000.0; } }
            else if (t < 2.5) { d = abs(max(aq.x, aq.y) - R) - sw * 0.5; }
            else if (t < 3.5) { d = max(abs(q.y + aq.x * 0.6 - R * 0.3) * 0.857 - sw * 0.5, aq.x - R); }
            else if (t < 4.5) { d = abs(max(aq.x * 0.866 + q.y * 0.5, -q.y) - R * 0.5) - sw * 0.5; }
            else if (t < 5.5) { d = abs(max(aq.x, aq.y) - R) - sw * 0.5; if (min(aq.x, aq.y) < R * 0.5) { d = 1000.0; } }
            else if (t < 6.5) { d = min(max(abs(q.y) - sw * 0.5, abs(aq.x - R * 0.6) - R * 0.4), max(abs(q.x) - sw * 0.5, abs(aq.y - R * 0.6) - R * 0.4)); }
            else if (t < 7.5) { d = abs(max(aq.x * 0.866 + aq.y * 0.5, aq.y) - R * 0.866) - sw * 0.5; }
            else if (t < 8.5) { float a2 = atan(q.y, q.x); float da = abs(fract(a2 * 36.0 / 6.2831853 + 0.5) - 0.5) * 6.2831853 / 36.0 * length(q); d = max(da - sw * 0.5, abs(length(q) - (R - 10.0)) - 10.0); }
            else if (t < 9.5) { float cs = max(R * 0.25, 2.0); d = length(fract(q / cs + 0.5) - 0.5) * cs - sw * 0.8; d = max(d, max(aq.x, aq.y) - R); }
            else { d = max(aq.x * 0.866 + q.y * 0.5, -q.y) - R * 0.25; }
            d *= s;
            float fade = clamp(1.0 - ci * \(P)CF / 100.0, 0.0, 1.0) * clamp(1.0 + rnd.x * \(P)RO2 / 50.0, 0.0, 1.0) * \(P)Op / 100.0;
            float a = (1.0 - smoothstep(-0.5, 1.0, d)) * fade;
            float gl = exp(-max(d, 0.0) / max(hGR * 0.25 * fxs, 1.0)) * 0.5 * fade * hGI * hGM / 100.0;
            hud += \(P)C.rgb * a + mix(\(P)C.rgb, hGC.rgb, hGCM / 100.0) * gl;
        }
    }
"""
}

func universe4Fx() -> [EffectDef] {
    var out: [EffectDef] = []

    // MARK: uni.Edge Glow
    out.append(EffectDef(
        id: "uedge", name: "uni.Edge Glow",
        desc: "Glowing effect on the edges and outlines of an image. Edge Detect, Glow Radius, Brightness, Saturation, Tint. Open the Dashboard for 8 presets.",
        category: "Light and glow", props: [
            PropDef("egEdge", "Edge Detect", 0, 1000, 100, 0),
            PropDef("egRad", "Glow Radius", 0, 200, 50, 1),
            PropDef("egBr", "Brightness", 0, 1000, 100, 0),
            PropDef("egSat", "Saturation", 0, 300, 100, 0),
            PropDef("egCol", "Colorize", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("egOp", "Opacity", 0, 100, 100, 1),
            PropDef("egBlend", "Blend Mode", 0, 4, 0, 0, ["Add", "Screen", "Normal", "Multiply", "Overlay"]),
            PropDef("egPre", "Premult", 0, 1, 0, 0, ["Off", "On"]),
        ],
        colors: [ColorParam("egTint", "Tint Color", Int32(bitPattern: 0xFF3A8CFF))],
        glsl: """
    vec4 s0 = src(uv);
    vec2 px = vec2(1.0) / uRes; float fxs = uRes.y / 1080.0;
    float R = egRad * 1.2 * fxs; float st = 1.5 * fxs;
    float jit = 0.5 + (hash21(uv * uRes) - 0.5) * 0.1;
    vec3 acc = vec3(0.0); float ws = 0.0;
    for (int i = 0; i < 24; i++) {
        float f = (float(i) + jit) / 24.0;
        float an = float(i) * 2.39996;
        vec2 p = uv + vec2(cos(an), sin(an)) * sqrt(f) * R * px;
        vec2 dx = vec2(st, 0.0) * px; vec2 dy = vec2(0.0, st) * px;
        float gx = luma(src(p + dx).rgb) - luma(src(p - dx).rgb);
        float gy = luma(src(p + dy).rgb) - luma(src(p - dy).rgb);
        float e = length(vec2(gx, gy));
        float w = 1.0 - sqrt(f) * 0.85;
        acc += src(p).rgb * e * w; ws += w;
    }
    vec3 g = acc / max(ws, 0.0001) * egEdge / 100.0 * 3.0 * egBr / 100.0 * (1.0 + R / (60.0 * fxs));
    float lm = luma(g);
    g = mix(vec3(lm), g, egSat / 100.0);
    if (egCol > 0.5) { g = egTint.rgb * lm * 1.6 + g * 0.1; }
    g = clamp(g, 0.0, 3.0);
    vec3 b = s0.rgb + g;
    if (egBlend > 3.5) { b = mix(2.0 * s0.rgb * g, 1.0 - 2.0 * (1.0 - s0.rgb) * (1.0 - g), step(0.5, s0.rgb)); }
    else if (egBlend > 2.5) { b = s0.rgb * (vec3(1.0) + g); }
    else if (egBlend > 1.5) { b = g; }
    else if (egBlend > 0.5) { b = 1.0 - (1.0 - s0.rgb) * (1.0 - min(g, vec3(1.0))); }
    vec3 res = mix(s0.rgb, b, egOp / 100.0);
    float ga = clamp(max(g.r, max(g.g, g.b)), 0.0, 1.0);
    float a = egPre > 0.5 ? max(s0.a, ga * egOp / 100.0) : s0.a;
    if (egPre < 0.5) { res = min(res, vec3(1.0)); }
    return vec4(res, min(a, 1.0));
"""))

    // MARK: uni.HUD Components
    var props: [PropDef] = [
        PropDef("hMS", "Master Animation Speed", -10, 10, 1, 2),
        PropDef("hSeed", "Master Random Seed", 0, 100, 1, 0),
    ]
    var cols: [ColorParam] = []
    let defCols: [UInt32] = [0xFF4A90E2, 0xFF30D0FF, 0xFFFFB030, 0xFF40FFA0]
    let defTypes: [Float] = [1, 6, 2, 5]
    var body = ""
    for k in 1...4 {
        let P = "h\(k)"
        let n = "E\(k) "
        props += [
            PropDef("\(P)Type", n + "Element Type", 0, 10, k == 1 ? defTypes[0] : 0, 0, hudTypes),
        ]
        if k > 1 { props.append(PropDef("\(P)Link", n + "Link to Element 1", 0, 1, 1, 0, ["Off", "On"])) }
        props += [
            PropDef("\(P)Op", n + "Opacity", 0, 100, 100, 1),
            PropDef("\(P)Anim", n + "Animation Type", 0, 5, k == 1 ? 4 : 0, 0, hudAnims),
            PropDef("\(P)Spd", n + "Animation Speed", -10, 10, 1, 2),
            PropDef("\(P)Amp", n + "Animation Amplitude", 0, 20, 2, 2),
            PropDef("\(P)Orb", n + "Animation Radius", 0, 100, 10, 1),
            PropDef("\(P)PX", n + "Position X", -1500, 1500, 0, 0),
            PropDef("\(P)PY", n + "Position Y", -1500, 1500, 0, 0),
            PropDef("\(P)RZ", n + "Rotation Z", -360, 360, 0, 1),
            PropDef("\(P)Sc", n + "Scale", 0.05, 5, 1, 2),
            PropDef("\(P)Rad", n + "Radius", 1, 1000, k == 1 ? 200 : 120, 0),
            PropDef("\(P)Seg", n + "Segment Angle", 0, 360, 360, 0),
            PropDef("\(P)SW", n + "Stroke Width", 0.5, 60, 4, 1),
            PropDef("\(P)Cn", n + "Number of Clones", 0, 99, 0, 0),
            PropDef("\(P)CX", n + "Clone Offset X", -200, 200, 0, 1),
            PropDef("\(P)CY", n + "Clone Offset Y", -200, 200, 0, 1),
            PropDef("\(P)CR", n + "Clone Rotation", -90, 90, 0, 1),
            PropDef("\(P)CS", n + "Clone Scale", -20, 20, -3, 1),
            PropDef("\(P)CF", n + "Clone Fade", 0, 20, 0, 1),
            PropDef("\(P)RO", n + "Random Offset", 0, 100, 0, 1),
            PropDef("\(P)RR", n + "Random Rotation", 0, 100, 0, 1),
            PropDef("\(P)RSc", n + "Random Scale", 0, 100, 0, 1),
            PropDef("\(P)RO2", n + "Random Opacity", 0, 100, 0, 1),
            PropDef("\(P)RS", n + "Random Seed", 0, 100, Float(k), 0),
        ]
        cols.append(ColorParam("\(P)C", n + "Color", Int32(bitPattern: defCols[k - 1])))
        body += hudElemGLSL(k)
    }
    props += [
        PropDef("hBlend", "Blend Mode", 0, 2, 1, 0, ["Normal", "Add", "Screen"]),
        PropDef("hSO", "Source Opacity", 0, 100, 100, 1),
        PropDef("hCO", "Component Opacity", 0, 100, 100, 1),
        PropDef("hNoise", "Noise Amount", 0, 100, 0, 1),
        PropDef("hGR", "Glow Radius", 0, 300, 50, 1),
        PropDef("hGI", "Glow Intensity", 0, 5, 1, 2),
        PropDef("hGCM", "Glow Color Mix", 0, 100, 0, 1),
        PropDef("hGM", "Glow Mix", 0, 100, 100, 1),
    ]
    cols.append(ColorParam("hGC", "Glow Color", Int32(bitPattern: 0xFFFFFFFF)))
    out.append(EffectDef(
        id: "uhud", name: "uni.HUD Components",
        desc: "Animated heads-up display elements: four linkable elements with animation, clones, randomness, glow and noise. Open the Dashboard for presets.",
        category: "Universe", props: props, colors: cols,
        glsl: """
    vec4 s0 = src(uv);
    float asp = uRes.x / uRes.y; float fxs = uRes.y / 1080.0;
    vec2 p0 = (uv - 0.5) * vec2(asp, 1.0) * uRes.y;
    vec3 hud = vec3(0.0);
\(body)
    hud *= 1.0 + (hash21(uv * uRes + uTime * 7.0) - 0.5) * hNoise / 50.0;
    hud = max(hud, vec3(0.0)) * hCO / 100.0;
    float ha = clamp(max(hud.r, max(hud.g, hud.b)), 0.0, 1.0);
    vec3 base = s0.rgb * hSO / 100.0;
    vec3 res = hBlend > 1.5 ? 1.0 - (1.0 - base) * (1.0 - min(hud, vec3(1.0))) : (hBlend > 0.5 ? base + hud : mix(base, min(hud, vec3(1.0)), ha) + max(hud - 1.0, vec3(0.0)) * 0.5);
    return vec4(min(res, vec3(2.0)), min(max(s0.a * hSO / 100.0, ha), 1.0));
"""))
    return out
}

extension UniversePresets {
    static let edge: [UniversePreset] = [
        UniversePreset(name: "Aura", vals: ["egCol": 1, "egEdge": 300, "egBr": 150, "egRad": 70], cols: ["egTint": 0xFFB070FF], tint: 0xFF301050, bloom: 0.9),
        UniversePreset(name: "Cool", vals: ["egCol": 1, "egEdge": 300, "egBr": 150], cols: ["egTint": 0xFF3A8CFF], tint: 0xFF0A2A66, bloom: 0.9),
        UniversePreset(name: "Default", bloom: 0.3),
        UniversePreset(name: "Huelogram", vals: ["egCol": 1, "egEdge": 350, "egBr": 130, "egSat": 160], cols: ["egTint": 0xFF40E0E0], tint: 0xFF083838, bloom: 0.9),
        UniversePreset(name: "Intense", vals: ["egEdge": 500, "egBr": 300, "egRad": 40], tint: 0xFFFFFFFF, bloom: 1.2),
        UniversePreset(name: "Soft", vals: ["egEdge": 150, "egBr": 80, "egRad": 120, "egSat": 0], tint: 0xFF808080, bloom: 0.5),
        UniversePreset(name: "Sparkle", vals: ["egCol": 1, "egEdge": 400, "egBr": 250, "egRad": 30], cols: ["egTint": 0xFFFF40A0], tint: 0xFF501030, bloom: 1.1),
        UniversePreset(name: "Warm", vals: ["egCol": 1, "egEdge": 300, "egBr": 150], cols: ["egTint": 0xFFFF9030], tint: 0xFF402008, bloom: 0.9),
    ]
    static let hud: [UniversePreset] = [
        UniversePreset(name: "Targeting 1", vals: ["h1Type": 5, "h1Anim": 5, "h1Rad": 150, "h2Type": 6, "h2Rad": 100], cols: ["h1C": 0xFF30D0FF, "h2C": 0xFF30D0FF], tint: 0xFF083040, bloom: 0.9),
        UniversePreset(name: "Slinky Rings", vals: ["h1Type": 1, "h1Seg": 340, "h1Anim": 4, "h1Cn": 34, "h1CS": -3, "h1CR": 5, "h1CF": 5], cols: ["h1C": 0xFF4AB0FF], tint: 0xFF0A2A66, bloom: 1.0),
        UniversePreset(name: "Wide Chevrons", vals: ["h1Type": 3, "h1Rad": 200, "h1Cn": 2, "h1CY": 60, "h1CS": 0, "h1CF": 4, "h1Anim": 2, "h1Amp": 2], cols: ["h1C": 0xFF40D0FF], tint: 0xFF083040, bloom: 0.8),
        UniversePreset(name: "Radar", vals: ["h1Type": 8, "h1Rad": 260, "h1Anim": 4, "h1Spd": 0.5, "h2Type": 1, "h2Rad": 220, "h2Seg": 300, "h2Anim": 4], cols: ["h1C": 0xFF40FF90, "h2C": 0xFF40FF90], tint: 0xFF083018, bloom: 0.9),
        UniversePreset(name: "HUD Clock", vals: ["h1Type": 1, "h1Rad": 260, "h1Seg": 270, "h2Type": 8, "h2Rad": 240, "h3Type": 1, "h3Rad": 180, "h3Seg": 90, "h3Anim": 4], cols: ["h1C": 0xFFFFC040, "h2C": 0xFF40D0FF, "h3C": 0xFF40D0FF], tint: 0xFF302008, bloom: 0.9),
        UniversePreset(name: "Widget Spin", vals: ["h1Type": 2, "h1Anim": 4, "h1Rad": 160, "h2Type": 7, "h2Rad": 120, "h3Type": 6, "h3Rad": 200], cols: ["h1C": 0xFF70FFE0, "h2C": 0xFF70FFE0, "h3C": 0xFF70FFE0], tint: 0xFF083830, bloom: 0.9),
        UniversePreset(name: "Hex Grid", vals: ["h1Type": 7, "h1Cn": 6, "h1CX": 70, "h1CY": 40, "h1CS": 0, "h1Rad": 50, "h1CF": 2], cols: ["h1C": 0xFF50FF90], tint: 0xFF083018, bloom: 0.8),
        UniversePreset(name: "Dot Grid", vals: ["h1Type": 9, "h1Rad": 220, "h1SW": 3, "h1Anim": 1, "h1Amp": 1], cols: ["h1C": 0xFF50FF90], tint: 0xFF083018, bloom: 0.7),
        UniversePreset(name: "Pointer Stack", vals: ["h1Type": 10, "h1Rad": 200, "h1Cn": 4, "h1CY": 50, "h1CF": 4, "h1CS": 0, "h1Anim": 2], cols: ["h1C": 0xFFFF9040], tint: 0xFF402008, bloom: 0.9),
        UniversePreset(name: "Triangle Orbit", vals: ["h1Type": 4, "h1Anim": 3, "h1Orb": 30, "h1Cn": 8, "h1CR": 10, "h1CF": 3, "h1Rad": 120], cols: ["h1C": 0xFFFF40C0], tint: 0xFF401030, bloom: 1.0),
    ]
}
