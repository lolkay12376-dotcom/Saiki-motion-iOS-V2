// BuiltinsUniverse2.swift — Universe Glow (U_Glow) and Universe Prism Displacement, plus their dashboard presets.
// Written from the Universe docs. Not included: Legacy Mode, Bicubic Sampling, Stretch Map to Fit (always fit), Link Height.

import Foundation

struct UniversePreset {
    let name: String
    var vals: [String: Float] = [:]
    var cols: [String: UInt32] = [:]
    var tint: UInt32? = nil      // dashboard thumbnail tint
    var bloom: Float = 0.6       // dashboard thumbnail bloom
}

private func ugB(_ c: String) -> String {
    "(ugCh < 0.5 ? \(c).r : ugCh < 1.5 ? \(c).g : ugCh < 2.5 ? \(c).b : ugCh < 3.5 ? \(c).a : ugCh < 4.5 ? max(max(\(c).r, \(c).g), \(c).b) : ugCh < 5.5 ? 0.5 * (max(max(\(c).r, \(c).g), \(c).b) + min(min(\(c).r, \(c).g), \(c).b)) : luma(\(c).rgb))"
}
private func upWrap(_ p: String) -> String {
    "\(p) = upWrap > 2.5 ? clamp(\(p), 0.0, 1.0) : (upWrap > 1.5 ? 1.0 - abs(1.0 - mod(\(p), 2.0)) : (upWrap > 0.5 ? fract(\(p)) : \(p)));"
}
private func upMap(_ pos: String) -> String {
    """
    t = uHas0 > 0.5 ? in0(\(pos)) : src(\(pos));
        v = luma(t.rgb / max(t.a, 0.0001));
        if (upSrc > 0.5 && upSrc < 1.5) { v = mix(0.5, v, t.a); } else if (upSrc > 1.5) { v = luma(t.rgb); }
        v = pow(clamp((v - upBlack) / max(upWhite - upBlack, 0.001), 0.0, 1.0), 1.0 / max(upGam, 0.05));
    """
}

func universe2Fx() -> [EffectDef] {
    var out: [EffectDef] = []

    // MARK: Universe Glow
    out.append(EffectDef(
        id: "uglow", name: "uni.Glow",
        desc: "A diffused glow that softens the bright parts of the image. Isolate an input channel, tint the glow, split it chromatically, mask it. Open the Dashboard for 11 presets.",
        category: "Light and glow", props: [
            PropDef("ugCh", "Input Channel", 0, 6, 4, 0, ["Red", "Green", "Blue", "Alpha", "RGBA", "Lightness", "Luminance"]),
            PropDef("ugThr", "Threshold", 0, 100, 60, 1),
            PropDef("ugThrS", "Threshold Softness", 0, 100, 30, 1),
            PropDef("ugSize", "Size", 0, 200, 30, 1),
            PropDef("ugInt", "Intensity", 0, 10, 1, 2),
            PropDef("ugBr", "Brightness", 0, 200, 50, 1),
            PropDef("ugFall", "Falloff", 0, 10, 2, 2),
            PropDef("ugW", "Width", 0, 100, 0, 1),
            PropDef("ugH", "Height", 0, 100, 0, 1),
            PropDef("ugGam", "Gamma", 0.2, 4, 1, 2),
            PropDef("ugSat", "Saturation", -100, 200, 0, 1),
            PropDef("ugCS", "Color Strength", 0, 100, 0, 1),
            PropDef("ugAbFall", "Aberration Falloff", 0, 2, 1, 0, ["None", "Linear", "Smooth"]),
            PropDef("ugAbX", "Aberration X", -100, 100, 0, 1),
            PropDef("ugAbY", "Aberration Y", -100, 100, 0, 1),
            PropDef("ugAbR", "Red Scale", -3, 3, 1, 2),
            PropDef("ugAbG", "Green Scale", -3, 3, 0, 2),
            PropDef("ugAbB", "Blue Scale", -3, 3, -1, 2),
            PropDef("ugAbSat", "Chromatic Saturation", 0, 200, 100, 1),
            PropDef("ugAbTint", "Chromatic Tint", -180, 180, 0, 1),
            PropDef("ugPass", "Passes", 1, 8, 3, 0),
            PropDef("ugMask", "Use Mask", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("ugShow", "Show Masked Area", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("ugMShape", "Mask Shape", 0, 1, 0, 0, ["Ellipse", "Rectangle"]),
            PropDef("ugMX", "Mask Position X", -0.5, 1.5, 0.5, 3),
            PropDef("ugMY", "Mask Position Y", -0.5, 1.5, 0.5, 3),
            PropDef("ugMW", "Mask Width", 0, 3, 0.8, 3),
            PropDef("ugMH", "Mask Height", 0, 3, 0.5, 3),
            PropDef("ugLink", "Link Width/Height", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("ugMRot", "Mask Rotation", -360, 360, 0, 1),
            PropDef("ugFeath", "Feather Mask", 0, 100, 20, 1),
            PropDef("ugMInv", "Invert Mask", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("ugNoise", "Noise", 0, 100, 0, 1),
            PropDef("ugGO", "Glow Opacity", 0, 100, 100, 1),
            PropDef("ugSO", "Source Opacity", 0, 100, 100, 1),
            PropDef("ugQ", "Quality", 0, 2, 1, 0, ["Draft", "Production", "Extreme"]),
            PropDef("ugAssist", "Scale Assist", 0, 1, 1, 0, ["Off", "On"]),
        ],
        colors: [ColorParam("ugC1", "Color 1 (outer)", Int32(bitPattern: 0xFFFF8A3C)),
                 ColorParam("ugC2", "Color 2 (inner)", Int32(bitPattern: 0xFFFFFFFF))],
        glsl: """
    vec4 s0 = src(uv);
    float fxs = ugAssist > 0.5 ? uRes.y / 1080.0 : 1.0;
    vec2 px = vec2(1.0) / uRes;
    float R = ugSize * 4.0 * fxs;
    vec2 sc = vec2(1.0 + ugW * 0.1, 1.0 + ugH * 0.1);
    float NT = ugQ < 0.5 ? 32.0 : 48.0;
    float thr = ugThr / 100.0; float soft = ugThrS / 100.0 * 0.5 + 0.002;
    float jit = 0.5 + (hash21(uv * uRes) - 0.5) * 0.12;
    vec3 acc = vec3(0.0); float wsum = 0.0;
    for (int i = 0; i < 48; i++) {
        if (float(i) >= NT) { break; }
        float f = (float(i) + jit) / NT;
        float rf = sqrt(f);
        float an = float(i) * 2.39996 + jit * 6.2831853;
        vec2 d = vec2(cos(an), sin(an)) * rf * R * sc * px;
        float w = pow(max(1.0 - rf, 0.0), ugFall) + 0.0001;
        float af = ugAbFall < 0.5 ? 1.0 : (ugAbFall < 1.5 ? 1.0 - rf : smoothstep(0.0, 1.0, 1.0 - rf));
        float pf = (mod(float(i), ugPass) + 1.0) / ugPass;
        vec2 ab = vec2(ugAbX, ugAbY) * fxs * px * af * pf;
        vec4 sr = src(uv + d + ab * ugAbR);
        vec4 sg = src(uv + d + ab * ugAbG);
        vec4 sb = src(uv + d + ab * ugAbB);
        float br = pow(smoothstep(thr - soft, thr + soft, \(ugB("sr"))), 1.0 / ugGam);
        float bgc = pow(smoothstep(thr - soft, thr + soft, \(ugB("sg"))), 1.0 / ugGam);
        float bb = pow(smoothstep(thr - soft, thr + soft, \(ugB("sb"))), 1.0 / ugGam);
        acc += vec3(br * sr.r, bgc * sg.g, bb * sb.b) * w;
        wsum += w;
    }
    vec3 gl = acc / max(wsum, 0.0001) * ugInt * 2.5 * ugBr / 100.0;
    gl = mix(vec3((gl.r + gl.g + gl.b) / 3.0), gl, ugAbSat / 100.0);
    if (abs(ugAbTint) > 0.01) { vec3 h = rgb2hsv(max(gl, vec3(0.0))); h.x = fract(h.x + ugAbTint / 360.0); gl = hsv2rgb(h); }
    float lm = luma(gl);
    gl = mix(gl, mix(ugC1.rgb, ugC2.rgb, smoothstep(0.0, 0.6, lm)) * lm, ugCS / 100.0);
    gl = mix(vec3(luma(gl)), gl, 1.0 + ugSat / 100.0);
    gl *= 1.0 + (hash21(uv * uRes + uTime * 13.0) - 0.5) * ugNoise / 50.0;
    float m = 1.0;
    if (ugMask > 0.5) {
        vec2 p = (uv - vec2(ugMX, ugMY)) * vec2(uRes.x / uRes.y, 1.0);
        float ca = cos(radians(ugMRot)); float sa = sin(radians(ugMRot));
        p = vec2(ca * p.x + sa * p.y, -sa * p.x + ca * p.y);
        float hw = max(ugMW * 0.5, 0.001); float hh = max((ugLink > 0.5 ? ugMW : ugMH) * 0.5, 0.001);
        float dd = ugMShape < 0.5 ? length(p / vec2(hw, hh)) : max(abs(p.x) / hw, abs(p.y) / hh);
        float fe = ugFeath / 100.0 * 0.5 + 0.002;
        m = 1.0 - smoothstep(1.0 - fe, 1.0 + fe, dd);
        if (ugMInv > 0.5) { m = 1.0 - m; }
        if (ugShow > 0.5) { return vec4(vec3(m), 1.0); }
    }
    vec3 res = s0.rgb * ugSO / 100.0 + gl * ugGO / 100.0 * m;
    float a = max(s0.a * ugSO / 100.0, clamp(max(res.r, max(res.g, res.b)), 0.0, 1.0));
    return vec4(res, min(a, 1.0));
"""))

    // MARK: Universe Prism Displacement
    out.append(EffectDef(
        id: "uprism", name: "uni.Prism Displacement",
        desc: "Distorts and displaces pixels with a prism-like chromatic split driven by the luminance of another layer (Displacement Source; without one it uses the layer itself). Open the Dashboard for presets.",
        category: "Distort", props: [
            PropDef("upSrc", "Source", 0, 2, 0, 0, ["Luminance", "Alpha (gray)", "Alpha (black)"]),
            PropDef("upGlass", "Glass Refraction", 0, 10, 1, 2),
            PropDef("upIdx", "Refractive Index", 0, 4, 1, 2),
            PropDef("upSoft", "Soften Displacement Map", 0, 50, 2, 1),
            PropDef("upRR", "Refraction Red", 0, 4, 0.9, 2),
            PropDef("upRG", "Refraction Green", 0, 4, 1, 2),
            PropDef("upRB", "Refraction Blue", 0, 4, 1.1, 2),
            PropDef("upBlack", "Map Black Level", 0, 1, 0, 2),
            PropDef("upWhite", "Map White Level", 0, 1, 1, 2),
            PropDef("upGam", "Map Gamma", 0.1, 4, 1, 2),
            PropDef("upLX", "Light X", -1, 2, 0.3, 2),
            PropDef("upLY", "Light Y", -1, 2, 0.2, 2),
            PropDef("upLZ", "Light Z", 0.05, 5, 0.8, 2),
            PropDef("upLInt", "Light Amount", 0, 3, 0, 2),
            PropDef("upWrap", "Wrap Mode", 0, 3, 3, 0, ["Border", "Repeat", "Mirror", "Clamp"]),
            PropDef("upView", "View Displacement Map", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("upAssist", "Scale Assist", 0, 1, 1, 0, ["Off", "On"]),
        ],
        colors: [ColorParam("upLC", "Diffuse Color", Int32(bitPattern: 0xFFFFFFFF))],
        inputs: ["Displacement Source"], glsl: """
    float fxs = upAssist > 0.5 ? uRes.y / 1080.0 : 1.0;
    vec2 px = vec2(1.0) / uRes;
    float r = max(upSoft, 0.5) * px.y * fxs * 2.0;
    vec2 ex = vec2(r * uRes.y / uRes.x, 0.0); vec2 ey = vec2(0.0, r);
    vec4 t; float v;
    \(upMap("uv"))
    float m0 = v;
    \(upMap("(uv + ex)"))
    float mR = v;
    \(upMap("(uv - ex)"))
    float mL = v;
    \(upMap("(uv + ey)"))
    float mU = v;
    \(upMap("(uv - ey)"))
    float mD = v;
    if (upView > 0.5) { return vec4(vec3(m0), 1.0); }
    vec2 grad = vec2(mR - mL, mU - mD) / (2.0 * r);
    vec2 off = grad * upGlass * upIdx * 0.012 * fxs * vec2(uRes.y / uRes.x, 1.0) * 10.0;
    vec2 pr = uv + off * upRR; vec2 pg = uv + off * upRG; vec2 pb = uv + off * upRB;
    \(upWrap("pr"))
    \(upWrap("pg"))
    \(upWrap("pb"))
    float ir = 1.0; float ig = 1.0; float ib = 1.0;
    if (upWrap < 0.5) {
        ir = (pr.x < 0.0 || pr.x > 1.0 || pr.y < 0.0 || pr.y > 1.0) ? 0.0 : 1.0;
        ig = (pg.x < 0.0 || pg.x > 1.0 || pg.y < 0.0 || pg.y > 1.0) ? 0.0 : 1.0;
        ib = (pb.x < 0.0 || pb.x > 1.0 || pb.y < 0.0 || pb.y > 1.0) ? 0.0 : 1.0;
    }
    vec4 sr = src(pr) * ir; vec4 sg = src(pg) * ig; vec4 sb = src(pb) * ib;
    vec4 o = vec4(sr.r, sg.g, sb.b, (sr.a + sg.a + sb.a) / 3.0);
    if (upLInt > 0.0) {
        vec3 nn = normalize(vec3(-grad * 0.6, 1.0));
        vec3 L = normalize(vec3(upLX, upLY, upLZ) - vec3(uv, 0.0));
        float dl = max(dot(nn, L) - L.z, 0.0);
        o.rgb += upLC.rgb * dl * upLInt * o.a;
    }
    return o;
"""))

    // MARK: uni.Point Zoom
    out.append(EffectDef(
        id: "upointzoom", name: "uni.Point Zoom",
        desc: "Zoom blur with glow toward a point: a \"holographic projection\" look, as if the layer beams from a light source. Open the Dashboard for 4 presets.",
        category: "Light and glow", props: [
            PropDef("pzX", "Position X", -1, 2, 0.5, 3),
            PropDef("pzY", "Position Y", -1, 2, 0.4, 3),
            PropDef("pzLen", "Length", 0, 300, 100, 1),
            PropDef("pzGain", "Glow Amount", 0, 4, 1.5, 2),
            PropDef("pzFollow", "Follow Layer (3D / Camera)", 0, 1, 1, 0, ["Off", "On"]),
            PropDef("pzRot", "Ray Rotation", -360, 360, 0, 1),
            PropDef("pzTX", "Tilt X (3D depth)", -2, 2, 0, 2),
            PropDef("pzTY", "Tilt Y (3D depth)", -2, 2, 0, 2),
            PropDef("pzBlend", "Blend with Original", 0, 100, 0, 1),
            PropDef("pzMode", "Blend Mode", 0, 4, 1, 0, ["Normal", "Add", "Screen", "Multiply", "Difference"]),
            PropDef("pzMask", "Use Mask", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("pzVis", "Visualize Mask", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("pzShape", "Shape", 0, 1, 0, 0, ["Ellipse", "Rectangle"]),
            PropDef("pzMMode", "Mask Mode", 0, 3, 0, 0, ["Apply", "Show Mask", "Show Red Mask", "Show Inverted Red Mask"]),
            PropDef("pzInv", "Invert", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("pzAX", "Point A X", -1, 2, 0.5, 3),
            PropDef("pzAY", "Point A Y", -1, 2, 0.25, 3),
            PropDef("pzBX", "Point B X", -1, 2, 0.5, 3),
            PropDef("pzBY", "Point B Y", -1, 2, 0.75, 3),
            PropDef("pzRad", "Radius", 0, 2, 0.3, 3),
            PropDef("pzFeath", "Feather Size", 0, 100, 20, 1),
            PropDef("pzFDir", "Feather Direction", -100, 100, 0, 1),
            PropDef("pzRedOp", "Red Opacity", 0, 100, 60, 1),
            PropDef("pzMA", "Mask Alpha", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("pzStr", "Straighten", 0, 1, 0, 0, ["Off", "On"]),
        ], glsl: """
    vec4 s0 = src(uv);
    float ar = uRes.x / uRes.y;
    vec2 dw = (uv - 0.5) * vec2(2.0 * ar, 2.0) - uLC;
    float det = uLX.x * uLY.y - uLX.y * uLY.x;
    bool lay = pzFollow > 0.5 && abs(det) > 1e-8;
    vec2 q = lay ? vec2(dw.x * uLY.y - dw.y * uLY.x, -dw.x * uLX.y + dw.y * uLX.x) / det + 0.5 : uv;
    vec2 P = vec2(pzX, pzY);
    float la = lay ? length(uLX) / max(length(uLY), 0.000001) : ar;
    vec2 dd = P - q;
    float rca = cos(radians(pzRot)); float rsa = sin(radians(pzRot));
    dd = vec2(dd.x * la, dd.y);
    dd = vec2(rca * dd.x - rsa * dd.y, rsa * dd.x + rca * dd.y);
    dd = vec2(dd.x / la, dd.y);
    float tz = max(1.0 + (q.y - P.y) * pzTX * 2.0 + (q.x - P.x) * pzTY * 2.0, 0.05);
    float lf = min(pzLen / 100.0, 1.0) * tz;
    float jit = 0.5 + (hash21(uv * uRes) - 0.5) * 0.12;
    vec4 acc = vec4(0.0); float ws = 0.0;
    for (int i = 0; i < 40; i++) {
        float f = (float(i) + jit) / 40.0;
        float w = exp(-f * 3.0 * 100.0 / max(pzLen, 1.0));
        vec2 qs = q + dd * f * lf;
        vec2 us = lay ? ((uLC + (qs.x - 0.5) * uLX + (qs.y - 0.5) * uLY) / vec2(2.0 * ar, 2.0) + 0.5) : qs;
        acc += src(us) * w; ws += w;
    }
    vec4 z = acc / max(ws, 0.0001) * pzGain;
    vec4 cmp = z + s0 * (1.0 - min(z.a, 1.0));
    if (pzMode > 3.5) { cmp = vec4(abs(z.rgb - s0.rgb), max(z.a, s0.a)); }
    else if (pzMode > 2.5) { cmp = vec4(z.rgb * s0.rgb, s0.a); }
    else if (pzMode > 1.5) { cmp = vec4(1.0 - (1.0 - z.rgb) * (1.0 - s0.rgb), max(z.a, s0.a)); }
    else if (pzMode > 0.5) { cmp = z + s0; }
    vec4 o = mix(z, cmp, pzBlend / 100.0);
    float m = 1.0;
    if (pzMask > 0.5) {
        float asp = uRes.x / uRes.y;
        vec2 A = vec2(pzAX, pzAY) * vec2(asp, 1.0); vec2 B = vec2(pzBX, pzBY) * vec2(asp, 1.0);
        vec2 ax = B - A; float hl = max(length(ax) * 0.5, 0.001); vec2 ud = ax / (2.0 * hl);
        vec2 p = uv * vec2(asp, 1.0) - (A + B) * 0.5;
        vec2 q = vec2(dot(p, ud) / hl, dot(p, vec2(-ud.y, ud.x)) / max(pzRad, 0.001));
        float dd = pzShape < 0.5 ? length(q) : max(abs(q.x), abs(q.y));
        float fe = pzFeath / 100.0 * 0.5 + 0.002;
        m = 1.0 - smoothstep(1.0 + pzFDir / 200.0 - fe, 1.0 + pzFDir / 200.0 + fe, dd);
        if (pzInv > 0.5) { m = 1.0 - m; }
        if (pzVis > 0.5 || pzMMode > 0.5) {
            if (pzMMode > 2.5) { return mix(s0, vec4(1.0, 0.0, 0.0, 1.0), (1.0 - m) * pzRedOp / 100.0); }
            if (pzMMode > 1.5) { return mix(s0, vec4(1.0, 0.0, 0.0, 1.0), m * pzRedOp / 100.0); }
            return vec4(vec3(m), 1.0);
        }
        o = mix(s0, o, m);
    }
    if (pzMA > 0.5) { return vec4(vec3(o.a), 1.0); }
    if (pzStr > 0.5) { o = vec4(o.rgb / max(o.a, 0.0001), o.a); }
    return o;
"""))

    return out
}

enum UniversePresets {
    static func list(for id: String) -> [UniversePreset] {
        switch id { case "uglow": return glow; case "upointzoom": return zoom; case "ugofi": return gofi; case "uecto": return ecto; case "ucarousel": return carousel; case "uedge": return edge; case "uhud": return hud; default: return prism }
    }
    static let title: [String: String] = ["uglow": "GLOW", "uprism": "PRISM DISPLACEMENT", "upointzoom": "POINT ZOOM", "ugofi": "GLO FI II", "uecto": "ECTO", "ucarousel": "CAROUSEL", "uedge": "EDGE GLOW", "uhud": "HUD COMPONENTS"]

    static let glow: [UniversePreset] = [
        UniversePreset(name: "Blue Tint", vals: ["ugCS": 75, "ugInt": 1.5], cols: ["ugC1": 0xFF2B6BFF, "ugC2": 0xFFA8D4FF], tint: 0xFF0A2A66, bloom: 0.9),
        UniversePreset(name: "Green Tint", vals: ["ugCS": 75, "ugInt": 1.5], cols: ["ugC1": 0xFF18C45A, "ugC2": 0xFFC8FFD8], tint: 0xFF0A4A22, bloom: 0.9),
        UniversePreset(name: "Hard Light Prism", vals: ["ugThr": 70, "ugFall": 3, "ugGam": 1.3, "ugInt": 1.6, "ugAbX": 18, "ugAbR": 1.5, "ugAbB": -1.5, "ugAbFall": 0], bloom: 1.0),
        UniversePreset(name: "Highlights", vals: ["ugThr": 80, "ugThrS": 10, "ugSize": 20, "ugInt": 2], bloom: 0.5),
        UniversePreset(name: "Horizontal Spectrum", vals: ["ugW": 60, "ugSize": 40, "ugInt": 1.5, "ugAbX": 30, "ugAbFall": 2, "ugAbSat": 140], bloom: 0.8),
        UniversePreset(name: "Optical Noise", vals: ["ugNoise": 60, "ugSize": 35, "ugInt": 1.2], bloom: 0.7),
        UniversePreset(name: "Rainbow Gleam", vals: ["ugSize": 45, "ugInt": 1.5, "ugAbX": 15, "ugAbY": 15, "ugPass": 6, "ugAbSat": 160], bloom: 1.0),
        UniversePreset(name: "Red Tint", vals: ["ugCS": 75, "ugInt": 1.5], cols: ["ugC1": 0xFFFF2B3A, "ugC2": 0xFFFFC0B0], tint: 0xFF5A0A12, bloom: 0.9),
        UniversePreset(name: "Soft Glow", vals: ["ugSize": 60, "ugFall": 1, "ugInt": 0.8, "ugThr": 40, "ugThrS": 60], bloom: 1.2),
        UniversePreset(name: "Subtle Aberration", vals: ["ugSize": 25, "ugInt": 1, "ugAbX": 6, "ugAbY": 3], bloom: 0.6),
        UniversePreset(name: "Vertical Spectrum", vals: ["ugH": 60, "ugSize": 40, "ugInt": 1.5, "ugAbX": 0, "ugAbY": 30, "ugAbFall": 2, "ugAbSat": 140], bloom: 0.8),
    ]
    static let zoom: [UniversePreset] = [
        UniversePreset(name: "Hologram Beam", vals: ["pzLen": 100, "pzGain": 1.5, "pzBlend": 0], bloom: 0.8),
        UniversePreset(name: "Long Projection", vals: ["pzLen": 300, "pzGain": 1.8, "pzBlend": 40], bloom: 1.0),
        UniversePreset(name: "Light Source Glow", vals: ["pzLen": 150, "pzGain": 1.2, "pzBlend": 75, "pzMode": 2], bloom: 0.6),
        UniversePreset(name: "Soft Reveal", vals: ["pzLen": 60, "pzGain": 1, "pzBlend": 100], bloom: 0.4),
    ]
    static let prism: [UniversePreset] = [
        UniversePreset(name: "Default", bloom: 0),
        UniversePreset(name: "Minor Refraction", vals: ["upGlass": 0.5], bloom: 0),
        UniversePreset(name: "Major Refraction", vals: ["upGlass": 3, "upIdx": 1.5], bloom: 0),
        UniversePreset(name: "Reverse Color", vals: ["upRR": 1.1, "upRG": 1, "upRB": 0.9], bloom: 0),
        UniversePreset(name: "Oil Slick", vals: ["upGlass": 2, "upSoft": 8, "upRR": 0.7, "upRB": 1.4, "upLInt": 0.6, "upGam": 1.4], bloom: 0),
        UniversePreset(name: "Opalescent", vals: ["upGlass": 1.5, "upSoft": 12, "upRR": 0.8, "upRG": 1, "upRB": 1.25, "upLInt": 0.4], bloom: 0),
        UniversePreset(name: "Heavy Glass", vals: ["upGlass": 6, "upIdx": 2, "upSoft": 4, "upLInt": 0.8], bloom: 0),
        UniversePreset(name: "Soft Prism", vals: ["upGlass": 1, "upSoft": 20, "upRR": 0.85, "upRB": 1.15], bloom: 0),
    ]
}
