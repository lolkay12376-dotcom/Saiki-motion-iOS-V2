// ParticularDesigner.swift — full-screen Particle Designer for the Particular effect (UI).
// Own preview viewport (orbit camera, CPU drawn from the same ParticularSim the renderer uses), a block strip
// (Emitter / Particle / Physics / Displace) and a properties panel. All custom drawn, no system icons.

import UIKit

private let ptAcc = argbToUIColor(C.GREEN)

private enum PtItem {
    case slider(String, String, Float, Float, Int)
    case choice(String, String, [String])
    case color(String, String, UInt32)
    case graph(String, String)
}

private struct PtBlock {
    let id: String, title: String
    let items: [PtItem]
    let presets: [(String, Int, [String: Float])]
}

private let ptColorPresets: [(String, UInt32, UInt32)] = [
    ("Warm", ParticularSim.defA, ParticularSim.defB), ("White", 0xFFFFFFFF, 0xFFFFFFFF), ("Fire", 0xFFFFF2B0, 0xFFFF3B00), ("Ice", 0xFFFFFFFF, 0xFF38BDF8),
    ("Aqualight", 0xFFB6E3C2, 0xFF1E9BD7), ("Autumn", 0xFF3CBF3C, 0xFFE8401C), ("Basic Red", 0xFFFF0000, 0xFFFF0000),
    ("Blue Ramp", 0xFF4B4BFF, 0xFF2A2AA0), ("Neon", 0xFFFF2BD6, 0xFF2BFFE0), ("Gold", 0xFFFFE27A, 0xFFC77700)]

private let ptBlocks: [PtBlock] = [
    PtBlock(id: "emitter", title: "EMITTER TYPE", items: [
        .choice("ptEmType", "Emitter Type", ["Point", "Box", "Sphere", "Grid"]),
        .choice("ptBehavior", "Emitter Behavior", ["Continuous", "Explode"]),
        .slider("ptRate", "Particles/sec", 1, 2000, 0),
        .slider("ptPosX", "Position X", -3, 3, 2), .slider("ptPosY", "Position Y", -3, 3, 2), .slider("ptPosZ", "Position Z", -4, 4, 2),
        .slider("ptSizeX", "Radius X", 0, 4, 2), .slider("ptSizeY", "Radius Y", 0, 4, 2), .slider("ptSizeZ", "Radius Z", 0, 4, 2),
        .slider("ptGridN", "Grid cells", 2, 16, 0), .slider("ptSeed", "Random Seed", 0, 100, 0)],
        presets: [("Default", 0, ["ptEmType": 0]), ("Box", 1, ["ptEmType": 1]), ("Sphere", 2, ["ptEmType": 2]), ("Grid", 3, ["ptEmType": 3])]),
    PtBlock(id: "motion", title: "MOTION", items: [
        .choice("ptMotion", "Motion", ["Default", "Bidirectional", "Directional", "Disc", "Inward"]),
        .slider("ptVel", "Velocity", 0, 3, 2), .slider("ptVelRand", "Velocity Random", 0, 1, 2), .slider("ptSpread", "Spread", 0, 2, 2),
        .slider("ptDirX", "Direction X", -1, 1, 2), .slider("ptDirY", "Direction Y", -1, 1, 2), .slider("ptDirZ", "Direction Z", -1, 1, 2),
        .slider("ptLife", "Particle Life (s)", 0.2, 20, 2), .slider("ptLifeRand", "Life Random", 0, 1, 2),
        .graph("Sp", "Speed over life")],
        presets: [("Default", 0, ["ptMotion": 0]), ("Bidirectional", 1, ["ptMotion": 1]), ("Directional", 2, ["ptMotion": 2]),
                  ("Disc", 3, ["ptMotion": 3]), ("Inward", 4, ["ptMotion": 4])]),
    PtBlock(id: "type", title: "PARTICLE TYPE", items: [
        .slider("ptSize", "Particle Size", 0.002, 0.2, 3), .slider("ptSoft", "Softness", 0, 1, 2),
        .slider("ptDof", "Depth of Field", 0, 2, 2), .slider("ptFocus", "Focus Depth", -4, 4, 2)],
        presets: [("Dot", 0, ["ptSoft": 0]), ("Sphere", 1, ["ptSoft": 0.5]), ("Glow Sphere", 2, ["ptSoft": 1])]),
    PtBlock(id: "size", title: "SIZE / ROTATION", items: [
        .graph("Sz", "Size over life"),
        .slider("ptSizeRand", "Size Random", 0, 1, 2), .slider("ptSizeStart", "Size at Birth", 0, 3, 2), .slider("ptSizeEnd", "Size at Death", 0, 3, 2)],
        presets: [("Default", 0, ["ptSizeStart": 1, "ptSizeEnd": 1]), ("Grow", 1, ["ptSizeStart": 0.2, "ptSizeEnd": 1.6]),
                  ("Shrink", 2, ["ptSizeStart": 1.6, "ptSizeEnd": 0.1])]),
    PtBlock(id: "opacity", title: "OPACITY", items: [
        .graph("Op", "Opacity over life"),
        .slider("ptOpacity", "Opacity", 0, 1, 2), .slider("ptFadeIn", "Fade In", 0.001, 1, 3), .slider("ptFadeOut", "Fade Out", 0.001, 1, 3)],
        presets: [("Default", 0, ["ptFadeIn": 0.05, "ptFadeOut": 0.3]), ("Bell Curve", 1, ["ptFadeIn": 0.35, "ptFadeOut": 0.35]),
                  ("Ease Opacity Mid", 2, ["ptFadeIn": 0.1, "ptFadeOut": 0.6]), ("Linear Fade", 3, ["ptFadeIn": 0.001, "ptFadeOut": 1])]),
    PtBlock(id: "color", title: "COLOR", items: [
        .color("ptColA", "Birth color", ParticularSim.defA), .color("ptColB", "Death color", ParticularSim.defB)], presets: []),
    PtBlock(id: "env", title: "ENVIRONMENT", items: [
        .slider("ptGravity", "Gravity", -3, 3, 2), .slider("ptAir", "Air Resistance", 0, 1, 2),
        .slider("ptWindX", "Wind X", -3, 3, 2), .slider("ptWindY", "Wind Y", -3, 3, 2), .slider("ptWindZ", "Wind Z", -3, 3, 2),
        .slider("ptSwirl", "Swirl (rad/s)", -6, 6, 2), .slider("ptSwirlPull", "Swirl Pull", 0, 1, 2),
        .slider("ptAttract", "Attractor Strength", 0, 1, 2), .slider("ptAttX", "Attractor X", -3, 3, 2),
        .slider("ptAttY", "Attractor Y", -3, 3, 2), .slider("ptAttZ", "Attractor Z", -3, 3, 2),
        .choice("ptFloorOn", "Floor", ["Off", "On"]), .slider("ptFloorY", "Floor Y", -3, 3, 2), .slider("ptBounce", "Bounce", 0, 1, 2)],
        presets: [("Off", 0, ["ptGravity": 0, "ptWindX": 0, "ptWindY": 0, "ptWindZ": 0, "ptAir": 0, "ptSwirl": 0, "ptSwirlPull": 0, "ptAttract": 0, "ptFloorOn": 0]),
                  ("Gravity", 1, ["ptGravity": 1, "ptAir": 0.2]), ("Wind", 1, ["ptWindX": 1.2]),
                  ("Vortex", 1, ["ptSwirl": 2.5, "ptSwirlPull": 0.3]),
                  ("Floor Bounce", 2, ["ptGravity": 1.5, "ptFloorOn": 1, "ptFloorY": -1, "ptBounce": 0.6])]),
    PtBlock(id: "field", title: "FIELDS", items: [
        .slider("ptTurb", "Turbulence", 0, 3, 2), .slider("ptTurbFreq", "Turbulence Scale", 0.05, 5, 2), .slider("ptTurbSpeed", "Turbulence Speed", 0, 5, 2)],
        presets: [("Off", 0, ["ptTurb": 0]), ("Turbulence", 1, ["ptTurb": 1])]),
]
private let ptTabs: [(String, [String])] = [("Emitter", ["emitter", "motion"]), ("Particle", ["type", "size", "opacity", "color"]),
                                            ("Physics", ["env"]), ("Displace", ["field"])]

// MARK: - Block art (custom drawn)

private func ptArt(_ c: CGContext, _ kind: String, _ v: Int, _ r: CGRect, _ ca: UIColor? = nil, _ cb: UIColor? = nil) {
    c.saveGState(); c.clip(to: r)
    c.setFillColor(UIColor(white: 0.04, alpha: 1).cgColor); c.fill(r)
    let cx = r.midX, cy = r.midY, s = min(r.width, r.height)
    let w = UIColor.white, a = ptAcc
    func dot(_ x: CGFloat, _ y: CGFloat, _ d: CGFloat, _ col: UIColor = w) {
        c.setFillColor(col.cgColor); c.fillEllipse(in: CGRect(x: x - d / 2, y: y - d / 2, width: d, height: d))
    }
    func line(_ x0: CGFloat, _ y0: CGFloat, _ x1: CGFloat, _ y1: CGFloat, _ col: UIColor = w, _ lw: CGFloat = 1.2) {
        c.setStrokeColor(col.cgColor); c.setLineWidth(lw); c.move(to: CGPoint(x: x0, y: y0)); c.addLine(to: CGPoint(x: x1, y: y1)); c.strokePath()
    }
    func rnd(_ i: Int) -> CGFloat { CGFloat((i &* 7919 &+ 13) % 1000) / 1000 }
    switch kind {
    case "emitter":
        for i in 0..<46 {
            let u = rnd(i), q = rnd(i + 99)
            switch v {
            case 1: dot(cx + (u - 0.5) * s * 0.7, cy + (q - 0.5) * s * 0.7, 2)
            case 2: let an = u * 6.283, rr = sqrt(q) * s * 0.36; dot(cx + cos(an) * rr, cy + sin(an) * rr, 2)
            case 3: dot(cx + (CGFloat(i % 7) - 3) * s * 0.1, cy + (CGFloat(i / 7 % 6) - 2.5) * s * 0.1, 2)
            default: let an = u * 6.283, rr = q * s * 0.1; dot(cx + cos(an) * rr, cy + sin(an) * rr, 2.4, a)
            }
        }
    case "motion":
        for i in 0..<18 {
            let an = CGFloat(i) / 18 * 6.283
            switch v {
            case 1: if abs(cos(an)) > 0.8 { line(cx, cy, cx + cos(an) * s * 0.42, cy + sin(an) * s * 0.42 * 0.3, a) }
            case 2: if cos(an) > 0.5 { line(cx - s * 0.3, cy, cx - s * 0.3 + cos(an) * s * 0.7, cy + sin(an) * s * 0.5, a) }
            case 3: line(cx + cos(an) * s * 0.12, cy + sin(an) * s * 0.04, cx + cos(an) * s * 0.42, cy + sin(an) * s * 0.14, a)
            case 4: line(cx + cos(an) * s * 0.42, cy + sin(an) * s * 0.42, cx + cos(an) * s * 0.1, cy + sin(an) * s * 0.1, a)
            default: line(cx + cos(an) * s * 0.06, cy + sin(an) * s * 0.06, cx + cos(an) * s * 0.42, cy + sin(an) * s * 0.42, a)
            }
        }
    case "type":
        let cs = CGColorSpaceCreateDeviceRGB()
        let hard: CGFloat = v == 0 ? 0.92 : (v == 1 ? 0.5 : 0.0)
        let g = CGGradient(colorsSpace: cs, colors: [w.cgColor, w.cgColor, w.withAlphaComponent(0).cgColor] as CFArray, locations: [0, hard, 1])!
        c.drawRadialGradient(g, startCenter: CGPoint(x: cx, y: cy), startRadius: 0, endCenter: CGPoint(x: cx, y: cy), endRadius: s * 0.4, options: [])
    case "size":
        let sz: [CGFloat] = v == 1 ? [0.06, 0.1, 0.15, 0.21] : (v == 2 ? [0.21, 0.15, 0.1, 0.06] : [0.12, 0.12, 0.12, 0.12])
        for (i, d) in sz.enumerated() { dot(r.minX + s * (0.2 + CGFloat(i) * 0.2), cy, d * s * 1.6, i % 2 == 0 ? w : a) }
    case "opacity", "color":
        if kind == "color" {
            let g = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: [(ca ?? w).cgColor, (cb ?? w).cgColor] as CFArray, locations: [0, 1])!
            let b = r.insetBy(dx: s * 0.2, dy: s * 0.2)
            c.saveGState(); c.clip(to: b); c.drawLinearGradient(g, start: CGPoint(x: b.minX, y: cy), end: CGPoint(x: b.maxX, y: cy), options: []); c.restoreGState()
        } else {
            let b = r.insetBy(dx: s * 0.15, dy: s * 0.22)
            let p = UIBezierPath(); p.move(to: CGPoint(x: b.minX, y: b.maxY))
            switch v {
            case 1: p.addLine(to: CGPoint(x: b.minX + b.width * 0.3, y: b.minY)); p.addLine(to: CGPoint(x: b.minX + b.width * 0.7, y: b.minY))
            case 2: p.addLine(to: CGPoint(x: b.minX + b.width * 0.15, y: b.minY)); p.addLine(to: CGPoint(x: b.minX + b.width * 0.5, y: b.minY))
            case 3: p.addLine(to: CGPoint(x: b.minX, y: b.minY))
            default: p.addLine(to: CGPoint(x: b.minX, y: b.minY)); p.addLine(to: CGPoint(x: b.maxX, y: b.minY))
            }
            p.addLine(to: CGPoint(x: b.maxX, y: v == 0 ? b.minY : (v == 3 ? b.maxY : b.maxY))); p.addLine(to: CGPoint(x: b.maxX, y: b.maxY)); p.close()
            c.setFillColor(a.withAlphaComponent(0.85).cgColor); c.addPath(p.cgPath); c.fillPath()
        }
    case "env":
        for i in 0..<5 {
            let x0 = r.minX + s * (0.2 + CGFloat(i) * 0.15)
            c.setStrokeColor(w.withAlphaComponent(0.8).cgColor); c.setLineWidth(1.2)
            c.move(to: CGPoint(x: x0, y: r.minY + s * 0.15))
            c.addQuadCurve(to: CGPoint(x: x0 + s * 0.2, y: r.maxY - s * 0.1), control: CGPoint(x: x0 + s * 0.02, y: cy)); c.strokePath()
        }
    default: // field
        for i in 0..<5 {
            let t = r.minY + s * (0.2 + CGFloat(i) * 0.15)
            c.setStrokeColor(a.withAlphaComponent(0.9).cgColor); c.setLineWidth(1)
            c.move(to: CGPoint(x: r.minX + s * 0.12, y: t))
            c.addCurve(to: CGPoint(x: r.maxX - s * 0.12, y: t), control1: CGPoint(x: cx - s * 0.1, y: t - s * 0.14), control2: CGPoint(x: cx + s * 0.1, y: t + s * 0.14)); c.strokePath()
        }
    }
    c.restoreGState()
}

// MARK: - Tile

private final class PtTile: TapView {
    var kind = "emitter", variant = 0, title = "", value = "", picked = false
    var ca: UIColor? = nil, cb: UIColor? = nil
    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let art = CGRect(x: 0, y: 0, width: bounds.width, height: bounds.height - 34)
        ptArt(c, kind, variant, art, ca, cb)
        c.setFillColor((picked ? UIColor.white : UIColor(white: 0.62, alpha: 1)).cgColor)
        c.fill(CGRect(x: 0, y: art.maxY, width: bounds.width, height: 34))
        let ps = NSMutableParagraphStyle(); ps.alignment = .center; ps.lineBreakMode = .byTruncatingTail
        let t1: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 10.5, weight: .medium), .foregroundColor: UIColor.black, .paragraphStyle: ps]
        let t2: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 10), .foregroundColor: UIColor(white: 0.2, alpha: 1), .paragraphStyle: ps]
        (title as NSString).draw(in: CGRect(x: 2, y: art.maxY + 3, width: bounds.width - 4, height: 14), withAttributes: t1)
        if !value.isEmpty { (value as NSString).draw(in: CGRect(x: 2, y: art.maxY + 17, width: bounds.width - 4, height: 13), withAttributes: t2) }
        if picked { c.setStrokeColor(ptAcc.cgColor); c.setLineWidth(2.5); c.stroke(bounds.insetBy(dx: 1.25, dy: 1.25)) }
    }
}

private final class PtGlyph: TapView {
    var kind = "play"
    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let m = bounds.midX, n = bounds.midY, s: CGFloat = 8
        c.setFillColor((isHighlighted ? ptAcc : UIColor.white).cgColor)
        switch kind {
        case "pause": c.fill(CGRect(x: m - s * 0.8, y: n - s, width: s * 0.55, height: s * 2)); c.fill(CGRect(x: m + s * 0.25, y: n - s, width: s * 0.55, height: s * 2))
        case "back", "next":
            let d: CGFloat = kind == "back" ? -1 : 1
            c.move(to: CGPoint(x: m - d * s * 0.5, y: n - s)); c.addLine(to: CGPoint(x: m + d * s * 0.8, y: n)); c.addLine(to: CGPoint(x: m - d * s * 0.5, y: n + s)); c.fillPath()
            c.fill(CGRect(x: m - d * s * 0.8 - 1, y: n - s, width: 2, height: s * 2))
        default: c.move(to: CGPoint(x: m - s * 0.6, y: n - s)); c.addLine(to: CGPoint(x: m + s, y: n)); c.addLine(to: CGPoint(x: m - s * 0.6, y: n + s)); c.fillPath()
        }
    }
}

// MARK: - Custom life graph (add / move / remove points)

private final class PtGraphView: UIControl {
    var cid = "Op", range: Float = 1
    weak var lay: Layer?
    var onEdit: (() -> Void)?
    private(set) var pts: [(Float, Float)] = []
    private var sel = -1

    func load() {
        guard let l = lay else { return }
        pts = PtCurve.read({ l.p($0, Editor.time) }, cid)
        if pts.count < 2 { pts = PtCurve.defaults[cid] ?? [(0, 0.5), (1, 0.5)] }
        sel = -1; setNeedsDisplay()
    }
    private var plot: CGRect { bounds.insetBy(dx: 34, dy: 16) }
    private func toPt(_ p: (Float, Float)) -> CGPoint { CGPoint(x: plot.minX + CGFloat(p.0) * plot.width, y: plot.maxY - CGFloat(p.1) * plot.height) }
    private func fromPt(_ q: CGPoint) -> (Float, Float) {
        (Float(min(1, max(0, (q.x - plot.minX) / plot.width))), Float(min(1, max(0, (plot.maxY - q.y) / plot.height))))
    }
    private func commit() { if let l = lay { PtCurve.write(l, cid, pts) }; onEdit?() }
    func removeSelected() { if sel > 0 && sel < pts.count - 1 { pts.remove(at: sel); sel = -1; commit(); setNeedsDisplay() } }
    func reset() { pts = PtCurve.defaults[cid] ?? pts; sel = -1; commit(); setNeedsDisplay() }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        c.setFillColor(UIColor(white: 0.05, alpha: 1).cgColor); c.fill(bounds)
        let pl = plot
        c.setStrokeColor(UIColor(white: 1, alpha: 0.09).cgColor); c.setLineWidth(1)
        for i in 0...4 {
            let x = pl.minX + pl.width * CGFloat(i) / 4, y = pl.minY + pl.height * CGFloat(i) / 4
            c.move(to: CGPoint(x: x, y: pl.minY)); c.addLine(to: CGPoint(x: x, y: pl.maxY))
            c.move(to: CGPoint(x: pl.minX, y: y)); c.addLine(to: CGPoint(x: pl.maxX, y: y))
        }
        c.strokePath()
        let lf: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 10), .foregroundColor: UIColor(white: 0.55, alpha: 1)]
        ("\(String(format: "%.1f", range))" as NSString).draw(at: CGPoint(x: 6, y: pl.minY - 6), withAttributes: lf)
        ("0" as NSString).draw(at: CGPoint(x: 6, y: pl.maxY - 6), withAttributes: lf)
        ("Birth" as NSString).draw(at: CGPoint(x: pl.minX, y: pl.maxY + 2), withAttributes: lf)
        ("Death" as NSString).draw(at: CGPoint(x: pl.maxX - 28, y: pl.maxY + 2), withAttributes: lf)
        let path = UIBezierPath()
        for (i, p) in pts.enumerated() { i == 0 ? path.move(to: toPt(p)) : path.addLine(to: toPt(p)) }
        let fill = UIBezierPath(cgPath: path.cgPath)
        if let f = pts.first, let l = pts.last { fill.addLine(to: CGPoint(x: toPt(l).x, y: pl.maxY)); fill.addLine(to: CGPoint(x: toPt(f).x, y: pl.maxY)); fill.close() }
        c.setFillColor(ptAcc.withAlphaComponent(0.16).cgColor); c.addPath(fill.cgPath); c.fillPath()
        c.setStrokeColor(ptAcc.cgColor); c.setLineWidth(2); c.addPath(path.cgPath); c.strokePath()
        for (i, p) in pts.enumerated() {
            let q = toPt(p), r: CGFloat = i == sel ? 8 : 6
            c.setFillColor((i == sel ? UIColor.white : ptAcc).cgColor)
            c.fillEllipse(in: CGRect(x: q.x - r, y: q.y - r, width: r * 2, height: r * 2))
        }
        if sel >= 0 && sel < pts.count {
            let p = pts[sel]
            let txt = String(format: "life %.0f%%   value %.2f", p.0 * 100, p.1 * range)
            (txt as NSString).draw(at: CGPoint(x: pl.minX + 6, y: pl.minY + 2), withAttributes: [.font: UIFont.systemFont(ofSize: 11, weight: .medium), .foregroundColor: UIColor.white])
        }
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        let q = t.location(in: self)
        var best = -1, bd: CGFloat = 28
        for (i, p) in pts.enumerated() { let c = toPt(p); let d = hypot(c.x - q.x, c.y - q.y); if d < bd { bd = d; best = i } }
        if best >= 0 {
            sel = best
            if t.tapCount >= 2 { removeSelected(); return }
        } else if pts.count < PtCurve.cap {
            let n = fromPt(q)
            pts.append(n); pts.sort { $0.0 < $1.0 }
            sel = pts.firstIndex { $0.0 == n.0 && $0.1 == n.1 } ?? -1
            commit()
        }
        setNeedsDisplay()
    }
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard sel >= 0, sel < pts.count, let t = touches.first else { return }
        var n = fromPt(t.location(in: self))
        if sel == 0 { n.0 = 0 } else if sel == pts.count - 1 { n.0 = 1 }
        else { n.0 = min(max(n.0, pts[sel - 1].0 + 0.01), pts[sel + 1].0 - 0.01) }
        pts[sel] = n; commit(); setNeedsDisplay()
    }
}

// MARK: - Viewport

final class ParticularViewport: UIView {
    var lay: Layer?
    var time: Float = 0
    var playing = true
    var loop: Float = 6
    var onTick: ((Float) -> Void)?
    private var yaw: CGFloat = 0.55, pitch: CGFloat = 0.3, dist: CGFloat = 4.2
    private var link: CADisplayLink?
    private var lastTs: CFTimeInterval = 0

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .black; clipsToBounds = true; isMultipleTouchEnabled = true
        addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(pan(_:))))
        addGestureRecognizer(UIPinchGestureRecognizer(target: self, action: #selector(pinch(_:))))
    }
    required init?(coder: NSCoder) { fatalError() }
    func start() { link?.invalidate(); link = CADisplayLink(target: self, selector: #selector(tick(_:))); link?.preferredFramesPerSecond = 30; link?.add(to: .main, forMode: .common) }
    func stop() { link?.invalidate(); link = nil }
    @objc private func tick(_ l: CADisplayLink) {
        if lastTs == 0 { lastTs = l.timestamp }
        let dt = Float(l.timestamp - lastTs); lastTs = l.timestamp
        if playing { time += dt; if time > loop { time = 0 }; onTick?(time) }
        setNeedsDisplay()
    }
    @objc private func pan(_ g: UIPanGestureRecognizer) {
        let t = g.translation(in: self); g.setTranslation(.zero, in: self)
        yaw += t.x * 0.01; pitch = min(1.4, max(-1.4, pitch + t.y * 0.01)); setNeedsDisplay()
    }
    @objc private func pinch(_ g: UIPinchGestureRecognizer) { dist = min(12, max(1.5, dist / g.scale)); g.scale = 1; setNeedsDisplay() }

    private func proj(_ x: Float, _ y: Float, _ z: Float) -> (CGPoint, CGFloat)? {
        let cy = cos(yaw), sy = sin(yaw), cp = cos(pitch), sp = sin(pitch)
        let X = CGFloat(x), Y = CGFloat(y), Z = CGFloat(z)
        let x1 = X * cy + Z * sy, z1 = -X * sy + Z * cy
        let y2 = Y * cp - z1 * sp, z2 = Y * sp + z1 * cp
        let d = dist - z2
        if d < 0.2 { return nil }
        let k = bounds.height * 0.5 * 1.7 / d
        return (CGPoint(x: bounds.midX + x1 * k, y: bounds.midY - y2 * k), k)
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext(), let l = lay else { return }
        let et = Editor.time
        let g: (String) -> Float = { l.p($0, et) }
        func seg(_ a: (Float, Float, Float), _ b: (Float, Float, Float), _ col: UIColor) {
            guard let p = proj(a.0, a.1, a.2), let q = proj(b.0, b.1, b.2) else { return }
            c.setStrokeColor(col.cgColor); c.setLineWidth(1); c.move(to: p.0); c.addLine(to: q.0); c.strokePath()
        }
        let gc = UIColor(white: 1, alpha: 0.07)
        for i in -4...4 { let v = Float(i) * 0.5; seg((v, -1.2, -2), (v, -1.2, 2), gc); seg((-2, -1.2, v), (2, -1.2, v), gc) }
        seg((0, 0, 0), (0.5, 0, 0), UIColor(red: 0.9, green: 0.3, blue: 0.3, alpha: 0.9))
        seg((0, 0, 0), (0, 0.5, 0), UIColor(red: 0.4, green: 0.8, blue: 0.4, alpha: 0.9))
        seg((0, 0, 0), (0, 0, 0.5), UIColor(red: 0.4, green: 0.5, blue: 1, alpha: 0.9))
        // emitter wireframe
        let ex = g("ptPosX"), ey = g("ptPosY"), ez = g("ptPosZ"), sx = g("ptSizeX"), sy = g("ptSizeY"), sz = g("ptSizeZ")
        let em = Int(g("ptEmType").rounded()), wc = ptAcc.withAlphaComponent(0.7)
        if em == 1 || em == 3 {
            var cs: [(Float, Float, Float)] = []
            for i in 0..<8 {
                let ox: Float = (i & 1) == 0 ? -sx : sx, oy: Float = (i & 2) == 0 ? -sy : sy, oz: Float = (i & 4) == 0 ? -sz : sz
                cs.append((ox, oy, oz))
            }
            for i in 0..<8 { for b in [1, 2, 4] where i & b == 0 { let j = i | b
                seg((cs[i].0 + ex, cs[i].1 + ey, cs[i].2 + ez), (cs[j].0 + ex, cs[j].1 + ey, cs[j].2 + ez), wc) } }
        } else if em == 2 {
            for ax in 0..<3 { var prev: (Float, Float, Float)? = nil
                for k in 0...24 { let a = Float(k) / 24 * 6.2831853, ca = cos(a), sa = sin(a)
                    let p = ax == 0 ? (ca * sx, sa * sy, 0) : (ax == 1 ? (ca * sx, 0, sa * sz) : (0, ca * sy, sa * sz))
                    let q = (p.0 + ex, p.1 + ey, p.2 + ez)
                    if let pr = prev { seg(pr, q, wc) }; prev = q } }
        } else {
            seg((ex - 0.08, ey, ez), (ex + 0.08, ey, ez), wc); seg((ex, ey - 0.08, ez), (ex, ey + 0.08, ez), wc); seg((ex, ey, ez - 0.08), (ex, ey, ez + 0.08), wc)
        }
        // particles (far to near), additive
        func col(_ k: String, _ d: UInt32) -> [CGFloat] {
            func comp(_ s: String, _ sh: UInt32) -> CGFloat { CGFloat(l.props[k + s].map { $0.eval(et) } ?? Float((d >> sh) & 0xFF) / 255) }
            return [comp("_r", 16), comp("_g", 8), comp("_b", 0), comp("_a", 24)]
        }
        let ca = col("ptColA", ParticularSim.defA), cb = col("ptColB", ParticularSim.defB)
        let fd = ParticularSim.fades(g), fin = CGFloat(fd.0), fout = CGFloat(fd.1), op = CGFloat(g("ptOpacity")), psz = CGFloat(g("ptSize"))
        var list: [(CGPoint, CGFloat, Particle, CGFloat)] = []
        let f = ParticularSim.field(g, t: time)
        let stride = max(1, f.count / 2500)
        for (i, q) in f.enumerated() where i % stride == 0 {
            if let p = proj(q.x, q.y, q.z) { list.append((p.0, p.1, q, 0)) }
        }
        list.sort { $0.1 < $1.1 }
        c.setBlendMode(.plusLighter)
        for (pt, k, q, _) in list {
            let life = CGFloat(min(max(q.life, 0), 1))
            let fade = min(1, life / fin) * (1 - max(0, min(1, (life - (1 - fout)) / fout)))
            let a = fade * op * CGFloat(q.alpha) * (ca[3] + (cb[3] - ca[3]) * life) * (0.85 + 0.15 * (1 - CGFloat(q.soft)))
            if a < 0.01 { continue }
            let r = max(1.2, psz * CGFloat(q.size) * k * 1.3)
            let rgb = (0..<3).map { ca[$0] + (cb[$0] - ca[$0]) * life }
            let col = UIColor(red: rgb[0], green: rgb[1], blue: rgb[2], alpha: min(1, a))
            if q.soft > 0.35 { c.setFillColor(col.withAlphaComponent(min(1, a) * 0.3).cgColor); c.fillEllipse(in: CGRect(x: pt.x - r * 1.9, y: pt.y - r * 1.9, width: r * 3.8, height: r * 3.8)) }
            c.setFillColor(col.cgColor); c.fillEllipse(in: CGRect(x: pt.x - r, y: pt.y - r, width: r * 2, height: r * 2))
        }
        c.setBlendMode(.normal)
    }
}

// MARK: - Designer screen

final class ParticularDesignerViewController: UIViewController {
    private let lay: Layer
    private weak var ed: EditorViewController?
    private let onDone: () -> Void
    private var snapKeys: [String] = [], snapVals: [String: Float] = [:]
    private let vp = ParticularViewport()
    private let bar = UIView(), transport = UIView(), strip = UIScrollView(), props = UIScrollView(), stack = UIStackView()
    private let timeLbl = UILabel(), titleLbl = UILabel()
    private var tabs: TabBar!
    private var tabIdx = 0, blockId = "emitter"
    private let play = PtGlyph()

    init(_ l: Layer, _ editor: EditorViewController?, _ done: @escaping () -> Void) {
        lay = l; ed = editor; onDone = done
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) { fatalError() }

    private func val(_ k: String) -> Float { lay.p(k, Editor.time) }
    private func set(_ k: String, _ v: Float) { lay.track(k).base = v }
    private func argb(_ k: String, _ d: UInt32) -> UInt32 {
        func comp(_ s: String, _ sh: UInt32) -> UInt32 { lay.props[k + s].map { UInt32(max(0, min(255, $0.eval(Editor.time) * 255 + 0.5))) } ?? ((d >> sh) & 0xFF) }
        return comp("_a", 24) << 24 | comp("_r", 16) << 16 | comp("_g", 8) << 8 | comp("_b", 0)
    }
    private func setColor(_ k: String, _ c: UInt32) {
        set(k + "_a", Float((c >> 24) & 0xFF) / 255); set(k + "_r", Float((c >> 16) & 0xFF) / 255)
        set(k + "_g", Float((c >> 8) & 0xFF) / 255); set(k + "_b", Float(c & 0xFF) / 255)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = argbToUIColor(C.BG)
        if let d = Registry.get("particular") {
            snapKeys = d.props.map { $0.key } + d.colors.flatMap { c in ["_r", "_g", "_b", "_a"].map { c.key + $0 } } + PtCurve.allKeys
            for k in snapKeys { if let t = lay.props[k] { snapVals[k] = t.base } }
        }
        bar.backgroundColor = argbToUIColor(C.PANEL); view.addSubview(bar)
        titleLbl.text = "Particle Designer"; titleLbl.textColor = .white; titleLbl.font = boldFont(15); titleLbl.textAlignment = .center; bar.addSubview(titleLbl)
        func btn(_ t: String, _ fill: Int32, _ txt: Int32, _ act: @escaping () -> Void) -> PillButton {
            let b = PillButton(t, nil, fill, txt); b.onClick = act; bar.addSubview(b); return b
        }
        _ = btn("Cancel", C.CARD2, C.TEXT) { [weak self] in self?.cancel() }.tag = 1
        _ = btn("Apply", C.GREEN, C.ONDARK) { [weak self] in self?.apply() }.tag = 2
        vp.lay = lay; vp.onTick = { [weak self] t in self?.updateTime(t) }; view.addSubview(vp)
        transport.backgroundColor = argbToUIColor(C.PANEL); view.addSubview(transport)
        for (i, k) in ["back", "play", "next"].enumerated() {
            let g = k == "play" ? play : PtGlyph(); g.kind = k; g.tag = 10 + i; transport.addSubview(g)
            g.onClick = { [weak self] in self?.transportTap(k) }
        }
        play.kind = "pause"
        timeLbl.textColor = ptAcc; timeLbl.font = UIFont.monospacedDigitSystemFont(ofSize: 13, weight: .semibold); transport.addSubview(timeLbl)
        tabs = TabBar(ptTabs.map { $0.0 }, 0) { [weak self] i in self?.pickTab(i) }; view.addSubview(tabs)
        strip.showsHorizontalScrollIndicator = false; strip.backgroundColor = argbToUIColor(C.PANEL); view.addSubview(strip)
        props.backgroundColor = argbToUIColor(C.BG); view.addSubview(props)
        stack.axis = .vertical; stack.spacing = 6; props.addSubview(stack)
        rebuildStrip(); rebuildProps(); updateTime(0)
    }
    override func viewDidAppear(_ animated: Bool) { super.viewDidAppear(animated); vp.start() }
    override func viewWillDisappear(_ animated: Bool) { super.viewWillDisappear(animated); vp.stop() }
    override var prefersStatusBarHidden: Bool { true }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let sa = view.safeAreaInsets, W = view.bounds.width, H = view.bounds.height
        let top = sa.top, bw = W - sa.left - sa.right, x0 = sa.left
        bar.frame = CGRect(x: 0, y: 0, width: W, height: top + 46)
        titleLbl.frame = CGRect(x: x0 + 120, y: top, width: bw - 240, height: 46)
        for v in bar.subviews { if v.tag == 1 { v.frame = CGRect(x: x0 + 10, y: top + 5, width: 100, height: 36) }; if v.tag == 2 { v.frame = CGRect(x: x0 + bw - 110, y: top + 5, width: 100, height: 36) } }
        let landscape = W > H
        let bottom = H - sa.bottom
        let leftW = landscape ? bw * 0.5 : bw
        let vpH = landscape ? bottom - bar.frame.maxY - 40 : (bottom - bar.frame.maxY) * 0.36
        vp.frame = CGRect(x: x0, y: bar.frame.maxY, width: leftW, height: vpH)
        transport.frame = CGRect(x: x0, y: vp.frame.maxY, width: leftW, height: 40)
        for v in transport.subviews { if v.tag >= 10 { v.frame = CGRect(x: 6 + CGFloat(v.tag - 10) * 44, y: 0, width: 44, height: 40) } }
        timeLbl.frame = CGRect(x: 150, y: 0, width: leftW - 160, height: 40)
        let rx = landscape ? x0 + leftW : x0, rw = landscape ? bw - leftW : bw
        let ry = landscape ? bar.frame.maxY : transport.frame.maxY
        tabs.frame = CGRect(x: rx, y: ry, width: rw, height: 40)
        strip.frame = CGRect(x: rx, y: ry + 40, width: rw, height: 112)
        props.frame = CGRect(x: rx, y: strip.frame.maxY, width: rw, height: bottom - strip.frame.maxY)
        stack.frame = CGRect(x: 10, y: 8, width: rw - 20, height: stack.frame.height)
        relayoutStack()
    }

    private func relayoutStack() {
        let w = props.bounds.width - 20
        let h = stack.systemLayoutSizeFitting(CGSize(width: w, height: 0), withHorizontalFittingPriority: .required, verticalFittingPriority: .fittingSizeLevel).height
        stack.frame = CGRect(x: 10, y: 8, width: w, height: h)
        props.contentSize = CGSize(width: props.bounds.width, height: h + 24)
    }

    private func updateTime(_ t: Float) {
        let f = Int(t * 30), s = f / 30
        timeLbl.text = String(format: "00:%02d:%02d:%02d   Loop %.1fs", s / 60, s % 60, f % 30, vp.loop)
    }
    private func transportTap(_ k: String) {
        switch k {
        case "play": vp.playing.toggle(); play.kind = vp.playing ? "play" : "pause"; play.setNeedsDisplay()
        case "back": vp.time = max(0, vp.time - 1.0 / 30); vp.playing = false; play.kind = "pause"; play.setNeedsDisplay(); updateTime(vp.time)
        default: vp.time += 1.0 / 30; vp.playing = false; play.kind = "pause"; play.setNeedsDisplay(); updateTime(vp.time)
        }
        // the glyph shows the action to take: "play" glyph while paused would be confusing, so it mirrors state
        play.kind = vp.playing ? "pause" : "play"; play.setNeedsDisplay()
    }

    private func pickTab(_ i: Int) { tabIdx = i; blockId = ptTabs[i].1[0]; rebuildStrip(); rebuildProps() }

    private func valueText(_ b: PtBlock) -> String {
        switch b.id {
        case "emitter": return ParticularSim.emitterNames[min(3, max(0, Int(val("ptEmType").rounded())))]
        case "motion": return ParticularSim.motionNames[min(4, max(0, Int(val("ptMotion").rounded())))]
        case "color":
            let a = argb("ptColA", ParticularSim.defA), c = argb("ptColB", ParticularSim.defB)
            return ptColorPresets.first { $0.1 == a && $0.2 == c }?.0 ?? "Custom"
        case "env": return abs(val("ptSwirl")) + val("ptAttract") + val("ptFloorOn") + abs(val("ptGravity")) + abs(val("ptWindX")) + abs(val("ptWindY")) + abs(val("ptWindZ")) + val("ptAir") > 0.001 ? "On" : "Off"
        case "field": return val("ptTurb") > 0.001 ? "On" : "Off"
        default:
            for p in b.presets where p.2.allSatisfy({ abs(val($0.key) - $0.value) < 0.011 }) { return p.0 }
            return "Custom"
        }
    }

    private func rebuildStrip() {
        strip.subviews.forEach { $0.removeFromSuperview() }
        var x: CGFloat = 8
        for id in ptTabs[tabIdx].1 {
            guard let b = ptBlocks.first(where: { $0.id == id }) else { continue }
            let t = PtTile(frame: CGRect(x: x, y: 6, width: 92, height: 100))
            t.kind = b.id == "type" ? "type" : (b.id == "size" ? "size" : b.id)
            t.variant = b.id == "emitter" ? Int(val("ptEmType").rounded()) : (b.id == "motion" ? Int(val("ptMotion").rounded()) : 1)
            t.title = b.title; t.value = valueText(b); t.picked = b.id == blockId
            if b.id == "color" { t.ca = argbToUIColor(Int32(bitPattern: argb("ptColA", ParticularSim.defA))); t.cb = argbToUIColor(Int32(bitPattern: argb("ptColB", ParticularSim.defB))) }
            t.onClick = { [weak self] in self?.blockId = id; self?.rebuildStrip(); self?.rebuildProps() }
            strip.addSubview(t); x += 98
        }
        strip.contentSize = CGSize(width: x + 8, height: 112)
    }

    private func label(_ s: String) -> UILabel {
        let l = UILabel(); l.text = s; l.textColor = argbToUIColor(C.DIM); l.font = boldFont(12); return l
    }

    private func rebuildProps() {
        stack.arrangedSubviews.forEach { stack.removeArrangedSubview($0); $0.removeFromSuperview() }
        guard let b = ptBlocks.first(where: { $0.id == blockId }) else { return }
        stack.addArrangedSubview(label(b.title))
        // presets row
        let presetCount = b.id == "color" ? ptColorPresets.count : b.presets.count
        if presetCount > 0 {
            stack.addArrangedSubview(label("Presets"))
            let sc = UIScrollView(); sc.showsHorizontalScrollIndicator = false
            sc.heightAnchor.constraint(equalToConstant: 84).isActive = true
            var x: CGFloat = 0
            for i in 0..<presetCount {
                let t = PtTile(frame: CGRect(x: x, y: 0, width: 74, height: 82))
                if b.id == "color" {
                    let p = ptColorPresets[i]; t.kind = "color"; t.title = p.0
                    t.ca = argbToUIColor(Int32(bitPattern: p.1)); t.cb = argbToUIColor(Int32(bitPattern: p.2))
                    t.onClick = { [weak self] in self?.setColor("ptColA", p.1); self?.setColor("ptColB", p.2); self?.afterEdit(true) }
                } else {
                    let p = b.presets[i]; t.kind = b.id; t.variant = p.1; t.title = p.0
                    t.onClick = { [weak self] in for (k, v) in p.2 { self?.set(k, v) }; self?.afterEdit(true) }
                }
                sc.addSubview(t); x += 80
            }
            sc.contentSize = CGSize(width: x, height: 82)
            stack.addArrangedSubview(sc)
        }
        stack.addArrangedSubview(label("Properties"))
        for it in b.items {
            switch it {
            case .slider(let k, let name, let lo, let hi, let dec):
                let s = RulerSlider(); s.label = name; s.lo = lo; s.hi = hi; s.dec = dec; s.canKey = false; s.value = val(k)
                s.heightAnchor.constraint(equalToConstant: 52).isActive = true
                s.onChange = { [weak self] v in self?.set(k, v); self?.vp.setNeedsDisplay() }
                stack.addArrangedSubview(s)
            case .choice(let k, let name, let opts):
                stack.addArrangedSubview(label(name))
                let row = chipRow(opts, min(opts.count - 1, max(0, Int(val(k).rounded())))) { [weak self] i in self?.set(k, Float(i)); self?.afterEdit(false) }
                row.heightAnchor.constraint(equalToConstant: 46).isActive = true
                stack.addArrangedSubview(row)
            case .graph(let id, let title):
                stack.addArrangedSubview(label(title))
                let gv = PtGraphView(); gv.cid = id; gv.range = id == "Op" ? 1 : 2; gv.lay = lay; gv.load()
                gv.heightAnchor.constraint(equalToConstant: 190).isActive = true
                gv.onEdit = { [weak self] in self?.vp.setNeedsDisplay() }
                let on = SwitchRow(); on.label = "Use custom graph"; on.on = val("ptCv\(id)On") >= 0.5
                on.heightAnchor.constraint(equalToConstant: 52).isActive = true
                gv.alpha = on.on ? 1 : 0.45; gv.isUserInteractionEnabled = on.on
                on.onToggle = { [weak self, weak gv] v in
                    guard let self = self, let gv = gv else { return }
                    self.set("ptCv\(id)On", v ? 1 : 0)
                    if v { PtCurve.write(self.lay, id, gv.pts) }
                    gv.alpha = v ? 1 : 0.45; gv.isUserInteractionEnabled = v; self.afterEdit(false)
                }
                let br = UIStackView(); br.axis = .horizontal; br.spacing = 8; br.distribution = .fillEqually
                br.heightAnchor.constraint(equalToConstant: 40).isActive = true
                let rm = PillButton("Remove point", nil, C.CARD2, C.TEXT); rm.onClick = { [weak gv] in gv?.removeSelected() }
                let rs = PillButton("Reset graph", nil, C.CARD2, C.TEXT); rs.onClick = { [weak gv] in gv?.reset() }
                br.addArrangedSubview(rm); br.addArrangedSubview(rs)
                stack.addArrangedSubview(on); stack.addArrangedSubview(gv); stack.addArrangedSubview(br)
                stack.addArrangedSubview(label("Tap empty space to add a point, drag to move, double-tap a point to remove it."))
            case .color(let k, let name, let def):
                let row = TapView(); row.backgroundColor = argbToUIColor(C.CARD); row.heightAnchor.constraint(equalToConstant: 46).isActive = true
                let tv = UILabel(); tv.text = name; tv.textColor = .white; tv.font = boldFont(15); tv.frame = CGRect(x: 14, y: 0, width: 200, height: 46); row.addSubview(tv)
                let sw = UIView(); sw.backgroundColor = argbToUIColor(Int32(bitPattern: argb(k, def))); sw.layer.cornerRadius = 6
                sw.frame = CGRect(x: max(0, props.bounds.width - 20 - 62), y: 8, width: 48, height: 30); sw.autoresizingMask = [.flexibleLeftMargin]; row.addSubview(sw)
                row.onClick = { [weak self] in
                    guard let self = self else { return }
                    self.ed?.showColorPicker(Int32(bitPattern: self.argb(k, def))) { [weak self] col in self?.setColor(k, UInt32(bitPattern: col)); self?.afterEdit(true) }
                }
                stack.addArrangedSubview(row)
            }
        }
        relayoutStack()
    }

    private func afterEdit(_ rebuildProperties: Bool) {
        vp.setNeedsDisplay(); rebuildStrip()
        if rebuildProperties { rebuildProps() }
    }

    private func apply() { vp.stop(); dismiss(animated: true) { [onDone] in onDone() } }
    private func cancel() {
        for k in snapKeys { if let v = snapVals[k] { lay.track(k).base = v } else { lay.props.removeValue(forKey: k) } }
        vp.stop(); dismiss(animated: true) { [onDone] in onDone() }
    }
}
