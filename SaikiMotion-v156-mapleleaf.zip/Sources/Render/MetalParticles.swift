import Foundation
import Metal
import UIKit

//  Stage 7b: particle fields in Metal (port of SceneRenderer.drawParticleLayer + the GL point-sprite shader).
//  ParticlesSim is CPU-only, so the simulation, 3D projection, depth sort and occluder rectangles are the same
//  code as GL; only the point-sprite draw is Metal (point primitives, premultiplied one / one-minus-src-alpha).

enum MetalParticleSL {
    static let source = MetalSL.header + """
struct PtU {
    float4 vp0; float4 vp1; float4 vp2; float4 vp3;
    float4 a;       // aspect, ortho, size, px
    float4 b;       // opacity, fadeIn, fadeOut, 0
    float4 colA; float4 colB;
    float4 c;       // sprite cells, atlas grid, tint, hasSprite
    float4 d;       // image colour mix, sprite animates over life, gradient by random, gradient on
    float4 e;       // bump strength, 3D tumble, light angle, 0
};
struct PtOut {
    float4 pos [[position]];
    float psz [[point_size]];
    float4 col;
    float life;
    float soft;
    float ps;
    float alpha;
    float rot;
    float vari;
};
vertex PtOut particleVertex(uint vid [[vertex_id]], constant PtU& u [[buffer(0)]],
                            const device float* pts [[buffer(1)]], constant float4* grad [[buffer(2)]]) {
    uint o0 = vid * 12;
    float3 aPos = float3(pts[o0], pts[o0 + 1], pts[o0 + 2]);
    float3 aData = float3(pts[o0 + 3], pts[o0 + 4], pts[o0 + 5]);
    PtOut o;
    float k = 1.0;
    if (u.a.y > 0.5) {
        o.pos = float4(aPos.x / u.a.x, aPos.y, 0.5, 1.0);
    } else {
        float4x4 vp = float4x4(u.vp0, u.vp1, u.vp2, u.vp3);
        float4 c = vp * float4(aPos, 1.0);
        o.pos = float4(c.x, c.y, (c.z + c.w) * 0.5, c.w);     // GL clip z [-w, w] -> Metal [0, w]
        k = 3.0 / max(c.w, 0.05);
    }
    o.alpha = pts[o0 + 6];
    o.rot = pts[o0 + 7];
    o.vari = pts[o0 + 8];
    o.soft = aData.z;
    float ps = max(4.0, u.a.z * u.a.w * aData.x * k * (1.0 + aData.z * 0.35));
    if (u.c.w > 0.5) ps *= 1.42;                                // room for a rotated sprite
    o.psz = ps;
    o.ps = ps;
    o.life = aData.y;
    float lf = clamp(aData.y, 0.0, 1.0);
    float4 col = mix(u.colA, u.colB, lf);
    if (u.d.w > 0.5) {
        float f = clamp(u.d.z > 0.5 ? o.vari : lf, 0.0, 1.0) * 15.0;
        int i0 = int(floor(f));
        int i1 = min(i0 + 1, 15);
        col = mix(grad[i0], grad[i1], f - float(i0));
    }
    col.rgb = mix(col.rgb, float3(pts[o0 + 9], pts[o0 + 10], pts[o0 + 11]), u.d.x);
    o.col = col;
    return o;
}
fragment float4 particleFragment(PtOut in [[stage_in]], constant PtU& u [[buffer(0)]], float2 pc [[point_coord]],
                                 texture2d<float> atlas [[texture(0)]], texture2d<float> bump [[texture(1)]]) {
    float fade = smoothstep(0.0, u.b.y, in.life) * (1.0 - smoothstep(1.0 - u.b.z, 1.0, in.life));
    if (u.c.w > 0.5) {
        constexpr sampler smp(coord::normalized, address::clamp_to_edge, filter::linear);
        float2 q = (pc - 0.5) * 1.42;
        float cs = cos(in.rot), sn = sin(in.rot);
        float2 r = float2(q.x * cs - q.y * sn, q.x * sn + q.y * cs);
        float face = 1.0;
        if (u.e.y > 0.001) {   // 3D tumble: the sprite turns about its own axis, foreshortening and showing its back
            float ph = in.vari * 6.2832 + in.life * (3.0 + 4.0 * in.vari) * 3.1416;
            float sc = mix(1.0, cos(ph), u.e.y);
            face = sc >= 0.0 ? 1.0 : -1.0;
            r.x /= face * max(abs(sc), 0.1);
        }
        if (abs(r.x) > 0.5 || abs(r.y) > 0.5) discard_fragment();
        float cells = max(u.c.x, 1.0), grid = max(u.c.y, 1.0);
        float idx = u.d.y > 0.5 ? floor(clamp(in.life, 0.0, 0.999) * cells) : floor(clamp(in.vari, 0.0, 0.999) * cells);
        float2 cell = float2(fmod(idx, grid), floor(idx / grid));
        float4 t = atlas.sample(smp, (cell + r + 0.5) / grid);
        float a = t.a * fade * u.b.x * in.alpha * in.col.a;
        float3 rgb = t.rgb / max(t.a, 0.001);
        rgb *= mix(float3(1.0), in.col.rgb, u.c.z);
        if (u.e.x > 0.001) {   // bump map: height gradient -> normal, lit from the light angle, rotated with the particle
            float2 uvc = (cell + r + 0.5) / grid;
            float ep = 1.5 / 512.0;
            float dx = bump.sample(smp, uvc + float2(ep, 0.0)).r - bump.sample(smp, uvc - float2(ep, 0.0)).r;
            float dy = bump.sample(smp, uvc + float2(0.0, ep)).r - bump.sample(smp, uvc - float2(0.0, ep)).r;
            float k = u.e.x * 10.0;
            float3 n = normalize(float3(-dx * k, -dy * k, 1.0));
            float2 ns = float2(n.x * cs + n.y * sn, -n.x * sn + n.y * cs);
            float3 nn = normalize(float3(ns * face, n.z));
            float3 L = normalize(float3(cos(u.e.z) * 0.8, -sin(u.e.z) * 0.8, 0.6));
            float diff = clamp(dot(nn, L), 0.0, 1.0);
            float shade = (0.5 + 0.9 * diff) / (0.5 + 0.9 * L.z);
            float sp = pow(clamp(dot(nn, normalize(L + float3(0.0, 0.0, 1.0))), 0.0, 1.0), 30.0) * 0.18 * min(u.e.x, 1.5);
            rgb = rgb * shade + sp;
            if (face < 0.0) rgb *= 0.8;
        } else if (face < 0.0) { rgb *= 0.8; }
        return float4(rgb * a, a);
    }
    float2 c = pc - 0.5;
    float d = length(c);
    float aa = 1.5 / max(in.ps, 3.0);
    float a = 1.0 - smoothstep(mix(0.5 - aa, 0.0, in.soft), 0.5, d);
    a *= fade * u.b.x * in.alpha * in.col.a;
    return float4(in.col.rgb * a, a);
}
"""
}

struct PtU {
    var vp0 = SIMD4<Float>(), vp1 = SIMD4<Float>(), vp2 = SIMD4<Float>(), vp3 = SIMD4<Float>()
    var a = SIMD4<Float>()
    var b = SIMD4<Float>()
    var colA = SIMD4<Float>(), colB = SIMD4<Float>()
    var c = SIMD4<Float>()
    var d = SIMD4<Float>()
    var e = SIMD4<Float>()
}

final class MetalParticleRenderer {
    private let core: MetalCore
    private var lib: MTLLibrary?
    private var psos: [UInt: MTLRenderPipelineState] = [:]
    /// While set, particle simulation uses this time (camera / layer keep the blur sub-time), so particles
    /// stay crisp under motion blur instead of averaging to nothing. Same meaning as GL particleSimTime.
    var simTime: Float? = nil

    init(_ core: MetalCore) {
        self.core = core
        lib = try? core.device.makeLibrary(source: MetalParticleSL.source, options: nil)
    }

    var ready: Bool { lib != nil }

    private var texCache: [String: MTLTexture] = [:]
    private var dummy: MTLTexture?
    private func dummyTexture() -> MTLTexture? {
        if let d = dummy { return d }
        let td = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .rgba8Unorm, width: 1, height: 1, mipmapped: false)
        let t = core.device.makeTexture(descriptor: td)
        var px: [UInt8] = [255, 255, 255, 255]
        t?.replace(region: MTLRegionMake2D(0, 0, 1, 1), mipmapLevel: 0, withBytes: &px, bytesPerRow: 4)
        dummy = t
        return t
    }
    /// 512x512 premultiplied RGBA sprite sheet (built-in shapes, petals, imported image / video flipbook).
    private func spriteTexture(_ s: PtSpriteSet) -> MTLTexture? {
        if let t = texCache[s.key] { return t }
        let w = 512
        guard let data = s.rgba() else { return nil }
        let td = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .rgba8Unorm, width: w, height: w, mipmapped: false)
        guard let t = core.device.makeTexture(descriptor: td) else { return nil }
        data.withUnsafeBytes { t.replace(region: MTLRegionMake2D(0, 0, w, w), mipmapLevel: 0, withBytes: $0.baseAddress!, bytesPerRow: w * 4) }
        if texCache.count > 24 { texCache.removeAll() }
        texCache[s.key] = t
        return t
    }

    /// Height map for the bump shading: the imported one (ptBumpId), or the bundled maple-leaf map when the shape is the Maple Leaf.
    private func bumpTexture(_ g: (String) -> Float) -> MTLTexture? {
        let id = Int(g("ptBumpId").rounded())
        let key = id > 0 ? "bump\(id)" : "bumpleaf"
        if let t = texCache[key] { return t }
        var im: CGImage? = nil
        if id > 0 { im = PtImages.load(id)?.0 }
        else if Int(g("ptSprite").rounded()) == 10, let u = Bundle.main.url(forResource: "pt_leaf_bump", withExtension: "png") { im = UIImage(contentsOfFile: u.path)?.cgImage }
        guard let img = im else { return nil }
        let w = 512
        var data = [UInt8](repeating: 0, count: w * w * 4)
        let ok: Bool = data.withUnsafeMutableBytes { raw in
            guard let c = CGContext(data: raw.baseAddress, width: w, height: w, bitsPerComponent: 8, bytesPerRow: w * 4,
                                    space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.noneSkipLast.rawValue) else { return false }
            c.draw(img, in: CGRect(x: 0, y: 0, width: w, height: w)); return true
        }
        guard ok else { return nil }
        let td = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .rgba8Unorm, width: w, height: w, mipmapped: false)
        guard let t = core.device.makeTexture(descriptor: td) else { return nil }
        data.withUnsafeBytes { t.replace(region: MTLRegionMake2D(0, 0, w, w), mipmapLevel: 0, withBytes: $0.baseAddress!, bytesPerRow: w * 4) }
        if texCache.count > 24 { texCache.removeAll() }
        texCache[key] = t
        return t
    }

    private func pso(_ format: MTLPixelFormat) -> MTLRenderPipelineState? {
        if let p = psos[format.rawValue] { return p }
        guard let lb = lib, let vf = lb.makeFunction(name: "particleVertex"),
              let ff = lb.makeFunction(name: "particleFragment") else { return nil }
        let d = MTLRenderPipelineDescriptor()
        d.vertexFunction = vf
        d.fragmentFunction = ff
        let ca = d.colorAttachments[0]!
        ca.pixelFormat = format
        ca.isBlendingEnabled = true
        ca.sourceRGBBlendFactor = .one; ca.destinationRGBBlendFactor = .oneMinusSourceAlpha
        ca.sourceAlphaBlendFactor = .one; ca.destinationAlphaBlendFactor = .oneMinusSourceAlpha
        guard let p = try? core.device.makeRenderPipelineState(descriptor: d) else { return nil }
        psos[format.rawValue] = p
        return p
    }

    private func projectPoint(_ vp: [Float], _ x: Float, _ y: Float, _ z: Float) -> (Float, Float, Float) {
        let cx = vp[0] * x + vp[4] * y + vp[8] * z + vp[12]
        let cy = vp[1] * x + vp[5] * y + vp[9] * z + vp[13]
        let cw = vp[3] * x + vp[7] * y + vp[11] * z + vp[15]
        return (cx / max(abs(cw), 0.0001), cy / max(abs(cw), 0.0001), cw)
    }

    private func colorComp(_ l: Layer, key: String, def: Float, time: Float) -> Float {
        if let tr = l.props[key] { return tr.eval(l.editTime(key, time)) }
        return def
    }

    private func clamp01(_ v: Float) -> Float { min(max(v, 0), 1) }

    /// Draws the particle field of `l` over `target`'s current content (the caller has cleared / drawn the source).
    func draw(_ l: Layer, time: Float, fov: Float, into target: MetalTarget, cb: MTLCommandBuffer) {
        guard ready else { return }
        let n = Xf.isParticular(l) ? PtGroup.count({ l.p($0, l.editTime("x", time)) }) : 1
        for gi in 0..<n { drawGroup(l, gi, time: time, fov: fov, into: target, cb: cb) }
    }

    private func drawGroup(_ l: Layer, _ gi: Int, time: Float, fov: Float, into target: MetalTarget, cb: MTLCommandBuffer) {
        let pre = PtGroup.pre(gi)
        let ar = Float(target.width) / Float(max(target.height, 1))
        let lt = l.editTime("x", time)
        let isStr = Xf.isStrands(l)
        let isPtc = Xf.isParticular(l)
        let field = isPtc ? ParticularSim.field({ l.p(pre + $0, lt) }, t: simTime ?? time) : isStr ? StrandsSim.field(l, lt: lt, t: simTime ?? time) : ParticlesSim.field(count: Int(l.p("pCount", lt)), spread: l.p("pSpread", lt),
                                       speed: l.p("pSpeed", lt), gravity: l.p("pGravity", lt),
                                       life: l.p("pLife", lt), seed: l.p("pSeed", lt),
                                       dirX: l.p("pDirX", lt), dirY: l.p("pDirY", lt), t: simTime ?? time, ar: ar,
                                       posX: l.p("pPosX", lt), posY: l.p("pPosY", lt), posZ: l.p("pPosZ", lt),
                                       radX: l.p("pRadX", lt), radY: l.p("pRadY", lt), radZ: l.p("pRadZ", lt),
                                       dirZ: l.p("pDirZ", lt), resist: l.p("pResist", lt),
                                       wobble: l.p("pWobble", lt), sizeVar: l.p("pSizeVar", lt),
                                       sizeEnd: l.p("pSizeEnd", lt), dof: l.p("pDof", lt),
                                       focus: l.p("pFocus", lt),
                                       burst: l.p("pBurst", lt), burstForce: l.p("pBurstForce", lt),
                                       edge: l.p("pSoftEdge", lt))
        let m = Xf.matrix(l, time)
        let scene = Editor.scene
        let hasCam = MetalCam.vp(for: l, time: time, width: target.width, height: target.height) != nil
        let vp = MetalCam.vpForModel(l, fov: fov, time: time, width: target.width, height: target.height)
        guard vp.count == 16, m.count >= 6 else { return }
        let use3D = hasCam || l.is3d
        let occlude = l.p(isPtc ? "ptOcclude" : isStr ? "stOcclude" : "pOcclude", lt) >= 0.5

        // Occlude: particles behind a 3D layer / model are hidden by it.
        var blockers: [(Float, Float, Float, Float, Float)] = []   // minX, minY, maxX, maxY, z
        if occlude {
            for o in scene.layers where o !== l && o.visible
                && time >= o.start - 0.001 && time <= o.end + 0.001
                && (o.is3d || o.type == .MODEL) && o.isRenderable() && o.type != .PARTICLES && !Xf.isParticles(o) {
                let ot = o.editTime("x", time)
                let sc = o.p("scale", ot)
                let (qw, qh) = Xf.quadSize(o)
                let hw = qw * sc * 0.5, hh = qh * sc * 0.5
                let ox = o.p("x", ot), oy = o.p("y", ot), oz = Xf.worldZ(o, time)
                var minX = Float.greatestFiniteMagnitude, minY = minX
                var maxX = -Float.greatestFiniteMagnitude, maxY = maxX
                var ok = true
                for (sx, sy) in [(-hw, -hh), (hw, -hh), (hw, hh), (-hw, hh)] {
                    let (px, py, pw) = projectPoint(vp, ox + sx, oy + sy, oz)
                    if pw <= 0.01 { ok = false; break }
                    minX = min(minX, px); maxX = max(maxX, px)
                    minY = min(minY, py); maxY = max(maxY, py)
                }
                if ok { blockers.append((minX, minY, maxX, maxY, oz)) }
            }
        }

        struct Pt { var x: Float; var y: Float; var z: Float; var size: Float; var life: Float; var soft: Float; var alpha: Float; var w: Float
                    var rot: Float; var vari: Float; var cr: Float; var cg: Float; var cb: Float }
        var list: [Pt] = []
        list.reserveCapacity(field.count)
        let layerZ = Xf.worldZ(l, time)
        let pd = Float.pi / 180
        let prx = l.p("rotX", lt) * pd, pry = -l.p("rotY", lt) * pd
        let pcx = cos(prx), psx = sin(prx), pcy = cos(pry), psy = sin(pry)
        let pRot = prx != 0 || pry != 0
        for q0 in field {
            var q = q0
            if pRot {
                let x1 = q.x * pcy + q.z * psy, z1 = -q.x * psy + q.z * pcy
                let y2 = q.y * pcx - z1 * psx, z2 = q.y * psx + z1 * pcx
                q.x = x1; q.y = y2; q.z = z2
            }
            q.z += layerZ
            var wx = m[0] * q.x + m[2] * q.y + m[4]
            var wy = m[1] * q.x + m[3] * q.y + m[5]
            var sz = q.size
            var w: Float = 1
            if use3D {
                let (sx, sy, pw) = projectPoint(vp, wx, wy, q.z)
                if pw <= 0.05 { continue }
                w = pw
                if occlude {
                    var hidden = false
                    for b in blockers where q.z < b.4 - 0.001 && sx >= b.0 && sx <= b.2 && sy >= b.1 && sy <= b.3 {
                        hidden = true; break
                    }
                    if hidden { continue }
                }
            } else {
                let pf = 1 / max(0.2, 1 - q.z / 3)
                wx *= pf; wy *= pf; sz *= pf
                w = 1 / pf
            }
            list.append(Pt(x: wx, y: wy, z: q.z, size: sz, life: q.life, soft: q.soft, alpha: q.alpha, w: w, rot: q.rot, vari: q.vari, cr: q.cr, cg: q.cg, cb: q.cb))
        }
        if list.isEmpty { return }
        if use3D { list.sort { $0.w > $1.w } }   // far -> near

        var u = PtU()
        u.vp0 = SIMD4(vp[0], vp[1], vp[2], vp[3]); u.vp1 = SIMD4(vp[4], vp[5], vp[6], vp[7])
        u.vp2 = SIMD4(vp[8], vp[9], vp[10], vp[11]); u.vp3 = SIMD4(vp[12], vp[13], vp[14], vp[15])
        u.a = SIMD4(ar, use3D ? 0 : 1, l.p(isPtc ? pre + "ptSize" : isStr ? "stSize" : "pSize", lt), Float(target.height) * 0.5)
        u.b = SIMD4(l.p(isPtc ? pre + "ptOpacity" : isStr ? "stOpacity" : "pOpacity", lt) * clamp01(l.p("opacity", lt)),
                    isPtc ? ParticularSim.fades({ l.p(pre + $0, lt) }).0 : max(0.001, l.p(isStr ? "stFadeIn" : "pFadeIn", lt)), isPtc ? ParticularSim.fades({ l.p(pre + $0, lt) }).1 : max(0.001, l.p(isStr ? "stFadeOut" : "pFadeOut", lt)), 0)
        func pc(_ k: String, _ def: UInt32) -> SIMD4<Float> {
            SIMD4(colorComp(l, key: k + "_r", def: Float((def >> 16) & 0xFF) / 255, time: time),
                  colorComp(l, key: k + "_g", def: Float((def >> 8) & 0xFF) / 255, time: time),
                  colorComp(l, key: k + "_b", def: Float(def & 0xFF) / 255, time: time),
                  colorComp(l, key: k + "_a", def: 1, time: time))
        }
        u.colA = pc(isPtc ? pre + "ptColA" : isStr ? "stColA" : "pColA", isPtc ? ParticularSim.defA : isStr ? 0xFFFFC857 : 0xFFFFFFFF)
        u.colB = pc(isPtc ? pre + "ptColB" : isStr ? "stColB" : "pColB", isPtc ? ParticularSim.defB : isStr ? 0xFF4FC3F7 : 0xFFFFFFFF)

        // Particular extras: sprite sheet, life gradient, per-particle (image) colour.
        var sprite: PtSpriteSet? = nil
        var bumpTex: MTLTexture? = nil
        var gradLut = [SIMD4<Float>](repeating: SIMD4<Float>(1, 1, 1, 1), count: 16)
        if isPtc {
            let g: (String) -> Float = { l.p(pre + $0, lt) }
            sprite = PtSprites.set(g)
            if let gr = PtGradient.active(g) { gradLut = PtGradient.lut(gr); u.d.w = 1 }
            let emT = Int(g("ptEmType").rounded()); u.d.x = (emT == 13 || emT == 14) ? g("ptImgColor") : (g("ptVolume") > 0.001 ? 1 : 0)
            u.d.y = g("ptSpriteAnim") >= 0.5 ? 1 : 0
            u.d.z = g("ptGrBy") >= 0.5 ? 1 : 0
            if let sp = sprite { u.c = SIMD4(Float(sp.cells), Float(sp.grid), g("ptSpriteTint"), 1) }
            if sprite != nil, g("ptBump") > 0.001 { bumpTex = bumpTexture(g) }
            u.e = SIMD4(bumpTex != nil ? g("ptBump") : 0, sprite != nil ? g("ptTumble") : 0, g("ptVolLight") * Float.pi / 180, 0)
        }
        var pts = [Float]()
        pts.reserveCapacity(list.count * 12)
        for q in list {
            pts.append(q.x); pts.append(q.y); pts.append(q.z)
            pts.append(q.size); pts.append(q.life); pts.append(q.soft); pts.append(q.alpha)
            pts.append(q.rot); pts.append(q.vari); pts.append(q.cr); pts.append(q.cg); pts.append(q.cb)
        }
        guard let ps = pso(target.tex.pixelFormat),
              let vb = pts.withUnsafeBytes({ core.device.makeBuffer(bytes: $0.baseAddress!, length: $0.count, options: .storageModeShared) }),
              let enc = cb.makeRenderCommandEncoder(descriptor: target.passDescriptor()) else { return }
        enc.setRenderPipelineState(ps)
        enc.setVertexBytes(&u, length: MemoryLayout<PtU>.stride, index: 0)
        enc.setVertexBuffer(vb, offset: 0, index: 1)
        gradLut.withUnsafeBytes { enc.setVertexBytes($0.baseAddress!, length: $0.count, index: 2) }
        enc.setFragmentTexture(sprite.flatMap { spriteTexture($0) } ?? dummyTexture(), index: 0)
        enc.setFragmentTexture(bumpTex ?? dummyTexture(), index: 1)
        enc.setFragmentBytes(&u, length: MemoryLayout<PtU>.stride, index: 0)
        enc.drawPrimitives(type: .point, vertexStart: 0, vertexCount: list.count)
        enc.endEncoding()
    }
}
