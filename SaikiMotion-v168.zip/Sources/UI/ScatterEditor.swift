//
//  ScatterEditor.swift — full-screen Scatter editor. One scatter GROUP = every model in the scatter list: they share a
//  target surface, a master frequency and an overlap-avoid switch; each model keeps its own frequency, count, scale,
//  rotation, filters, noise clumps and animation. Settings are the same x3s "sc*" keys the renderer already reads.
//
import UIKit

final class ScatterEditor: UIView {
    private weak var host: EditorViewController?
    private var sel = -1
    private let accent = UIColor(red: 1, green: 0.55, blue: 0.08, alpha: 1)
    private let top = UIStackView(), chips = UIStackView(), chipScroll = UIScrollView(), scroll = UIScrollView(), stack = UIStackView()
    private let panel = UIView(), peek = UIButton(type: .system)
    private var renderWork: DispatchWorkItem?

    static func present(in host: EditorViewController, over view: UIView, select: Int) {
        if view.subviews.contains(where: { $0 is ScatterEditor }) { return }
        let v = ScatterEditor(host: host, select: select)
        v.translatesAutoresizingMaskIntoConstraints = false; view.addSubview(v)
        NSLayoutConstraint.activate([v.leadingAnchor.constraint(equalTo: view.leadingAnchor), v.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                                     v.topAnchor.constraint(equalTo: view.topAnchor), v.bottomAnchor.constraint(equalTo: view.bottomAnchor)])
    }

    private init(host: EditorViewController, select: Int) {
        self.host = host; self.sel = select
        super.init(frame: .zero)
        backgroundColor = UIColor(white: 0.06, alpha: 1)
        panel.translatesAutoresizingMaskIntoConstraints = false; addSubview(panel)
        // header
        let title = UILabel(); title.text = "Scatter editor"; title.textColor = .white; title.font = .systemFont(ofSize: 18, weight: .bold)
        let close = UIButton(type: .system); close.setImage(UIImage(systemName: "xmark"), for: .normal); close.tintColor = .white
        close.addAction(UIAction { [weak self] _ in self?.removeFromSuperview() }, for: .touchUpInside)
        peek.setTitle("Hold: peek", for: .normal); peek.setTitleColor(accent, for: .normal); peek.titleLabel?.font = .systemFont(ofSize: 13, weight: .semibold)
        peek.addAction(UIAction { [weak self] _ in self?.setPeek(true) }, for: .touchDown)
        peek.addAction(UIAction { [weak self] _ in self?.setPeek(false) }, for: [.touchUpInside, .touchUpOutside, .touchCancel])
        let bar = UIStackView(arrangedSubviews: [title, UIView(), peek, close]); bar.alignment = .center; bar.spacing = 14
        bar.translatesAutoresizingMaskIntoConstraints = false; addSubview(bar)
        chips.axis = .horizontal; chips.spacing = 8; chips.translatesAutoresizingMaskIntoConstraints = false
        chipScroll.translatesAutoresizingMaskIntoConstraints = false; chipScroll.showsHorizontalScrollIndicator = false
        chipScroll.addSubview(chips); panel.addSubview(chipScroll)
        top.axis = .vertical; top.spacing = 8; top.translatesAutoresizingMaskIntoConstraints = false; panel.addSubview(top)
        stack.axis = .vertical; stack.spacing = 10; stack.translatesAutoresizingMaskIntoConstraints = false
        scroll.translatesAutoresizingMaskIntoConstraints = false; scroll.addSubview(stack); panel.addSubview(scroll)
        let g = safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            bar.topAnchor.constraint(equalTo: g.topAnchor, constant: 8), bar.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 16),
            bar.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -16), bar.heightAnchor.constraint(equalToConstant: 36),
            panel.topAnchor.constraint(equalTo: bar.bottomAnchor, constant: 6), panel.leadingAnchor.constraint(equalTo: leadingAnchor),
            panel.trailingAnchor.constraint(equalTo: trailingAnchor), panel.bottomAnchor.constraint(equalTo: bottomAnchor),
            top.topAnchor.constraint(equalTo: panel.topAnchor), top.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 16),
            top.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -16),
            chipScroll.topAnchor.constraint(equalTo: top.bottomAnchor, constant: 8), chipScroll.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 16),
            chipScroll.trailingAnchor.constraint(equalTo: g.trailingAnchor), chipScroll.heightAnchor.constraint(equalToConstant: 40),
            chips.topAnchor.constraint(equalTo: chipScroll.topAnchor), chips.bottomAnchor.constraint(equalTo: chipScroll.bottomAnchor),
            chips.leadingAnchor.constraint(equalTo: chipScroll.leadingAnchor), chips.trailingAnchor.constraint(equalTo: chipScroll.trailingAnchor),
            chips.heightAnchor.constraint(equalTo: chipScroll.heightAnchor),
            scroll.topAnchor.constraint(equalTo: chipScroll.bottomAnchor, constant: 8), scroll.leadingAnchor.constraint(equalTo: panel.leadingAnchor),
            scroll.trailingAnchor.constraint(equalTo: panel.trailingAnchor), scroll.bottomAnchor.constraint(equalTo: panel.bottomAnchor),
            stack.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor, constant: 4),
            stack.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor, constant: -40),
            stack.leadingAnchor.constraint(equalTo: scroll.frameLayoutGuide.leadingAnchor, constant: 16),
            stack.trailingAnchor.constraint(equalTo: scroll.frameLayoutGuide.trailingAnchor, constant: -16),
        ])
        rebuild()
    }
    required init?(coder: NSCoder) { fatalError() }

    private func setPeek(_ on: Bool) { UIView.animate(withDuration: 0.12) { self.panel.alpha = on ? 0 : 1; self.backgroundColor = UIColor(white: 0.06, alpha: on ? 0 : 1) } }
    private var members: [Layer] { Editor.scene.layers.filter { $0.type == .MODEL && $0.xf("scList", 0) > 0.5 } }
    private var cur: Layer? { members.first { $0.id == sel } }
    private func apply(_ f: (Layer) -> Void) { members.forEach(f) }
    private func rerender(now: Bool = false) {
        renderWork?.cancel()
        let w = DispatchWorkItem { [weak self] in self?.host?.render() }
        renderWork = w
        if now { w.perform() } else { DispatchQueue.main.asyncAfter(deadline: .now() + 0.12, execute: w) }
    }

    // MARK: build
    private func rebuild() {
        if cur == nil { sel = members.first?.id ?? -1 }
        // chips
        chips.arrangedSubviews.forEach { chips.removeArrangedSubview($0); $0.removeFromSuperview() }
        for o in members {
            let b = UIButton(type: .system)
            b.setTitle(o.name + (o.xf("scOn", 0) > 0.5 ? "" : " (off)"), for: .normal)
            b.titleLabel?.font = .systemFont(ofSize: 14, weight: .semibold)
            let on = o.id == sel
            b.setTitleColor(on ? .black : .white, for: .normal); b.backgroundColor = on ? accent : UIColor(white: 0.18, alpha: 1)
            b.layer.cornerRadius = 14; b.contentEdgeInsets = UIEdgeInsets(top: 0, left: 14, bottom: 0, right: 14)
            b.addAction(UIAction { [weak self] _ in self?.sel = o.id; self?.rebuild() }, for: .touchUpInside)
            chips.addArrangedSubview(b)
        }
        let free = Editor.scene.layers.filter { $0.type == .MODEL && $0.xf("scList", 0) < 0.5 }
        let add = UIButton(type: .system); add.setTitle("+ Add model", for: .normal); add.setTitleColor(accent, for: .normal)
        add.titleLabel?.font = .systemFont(ofSize: 14, weight: .bold); add.layer.cornerRadius = 14
        add.layer.borderWidth = 1; add.layer.borderColor = accent.cgColor; add.contentEdgeInsets = UIEdgeInsets(top: 0, left: 14, bottom: 0, right: 14)
        add.menu = UIMenu(children: free.isEmpty ? [UIAction(title: "No other 3D models in the project", attributes: .disabled) { _ in }]
                          : free.map { m in UIAction(title: m.name) { [weak self] _ in self?.addToGroup(m) } })
        add.showsMenuAsPrimaryAction = true
        chips.addArrangedSubview(add)
        // group header
        top.arrangedSubviews.forEach { top.removeArrangedSubview($0); $0.removeFromSuperview() }
        let first = members.first
        if let f = first {
            top.addArrangedSubview(head("Group · \(members.count) model\(members.count == 1 ? "" : "s")"))
            top.addArrangedSubview(slider("Group frequency", f.xf("scMaster", 1), 0, 3, "%.2f×") { [weak self] v in self?.apply { $0.xset("scMaster", v) }; self?.rerender() })
            top.addArrangedSubview(toggle("Models avoid each other", f.xf("scAvoid", 0) > 0.5) { [weak self] v in self?.apply { $0.xset("scAvoid", v ? 1 : 0) }; self?.rerender(now: true) })
        }
        // body
        stack.arrangedSubviews.forEach { stack.removeArrangedSubview($0); $0.removeFromSuperview() }
        guard let l = cur else {
            stack.addArrangedSubview(note("No scatter models yet. Tap \"+ Add model\" to put a 3D model in the group (or select a model in Scene 3D and use Add to scatter list)."))
            return
        }
        build(l)
    }

    private func addToGroup(_ m: Layer) {
        host?.pushUndo()
        let ref = members.first
        m.xset("scList", 1); m.xset("scOn", 1)
        m.xset("scTarget", ref?.xf("scTarget", -3) ?? -3)
        for k in ["scGroundSize", "scGroundY", "scAirH", "scMaster", "scAvoid"] { if let r = ref, r.xf(k, -9999) != -9999 { m.xset(k, r.xf(k, 0)) } }
        if m.xf("scCount", 0) == 0 { m.xset("scCount", 30) }
        m.xset("scSeed", Float(Int.random(in: 1...999)))
        sel = m.id; rebuild(); rerender(now: true)
    }

    private func build(_ l: Layer) {
        func f(_ n: String, _ k: String, _ lo: Float, _ hi: Float, _ d: Float, _ fmt: String = "%.2f") {
            stack.addArrangedSubview(slider(n, l.xf(k, d), lo, hi, fmt) { [weak self] v in l.xset(k, v); self?.rerender() })
        }
        func t(_ n: String, _ k: String) { stack.addArrangedSubview(toggle(n, l.xf(k, 0) > 0.5) { [weak self] v in l.xset(k, v ? 1 : 0); self?.rerender(now: true) }) }
        // target surface (shared by the group)
        stack.addArrangedSubview(head("Surface"))
        let tv = Int(l.xf("scTarget", -1))
        let tgts = Editor.scene.layers.filter { ($0.type == .MODEL || $0.type == .CAMERA || $0.is3d) && !members.contains(where: { m in m === $0 }) && !($0.imagePath ?? "").lowercased().hasSuffix(".vdb") }
        let curName = tv == -2 ? "Ground plane" : tv == -3 ? "Air (random volume)" : (Editor.scene.layers.first { $0.id == tv }?.name ?? "None")
        let opts: [(String, Int)] = [("Ground plane", -2), ("Air (random volume)", -3)] + tgts.map { ($0.name, $0.id) }
        stack.addArrangedSubview(menuButton("Target: \(curName)", opts.map { o in UIAction(title: o.0) { [weak self] _ in
            self?.host?.pushUndo(); self?.apply { $0.xset("scTarget", Float(o.1)) }; self?.rerender(now: true); self?.rebuild() } }))
        if tv == -2 || tv == -3 {
            func g(_ n: String, _ k: String, _ lo: Float, _ hi: Float, _ d: Float, _ fmt: String) {
                stack.addArrangedSubview(slider(n, l.xf(k, d), lo, hi, fmt) { [weak self] v in self?.apply { $0.xset(k, v) }; self?.rerender() })
            }
            if tv == -3 { g("Air height", "scAirH", 0.5, 30, 4, "%.1f") }
            g("Area size", "scGroundSize", 1, 120, 10, "%.0f"); g(tv == -3 ? "Air centre height" : "Ground height", "scGroundY", -5, 5, 0, "%.2f")
        }
        t("Scatter on", "scOn"); t("Keep the original model too", "scKeep")
        stack.addArrangedSubview(head("Amount · frequency"))
        f("Frequency (this model)", "scFreq", 0, 3, 1, "%.2f×"); f("Count", "scCount", 1, 3000, 60, "%.0f"); f("Seed", "scSeed", 1, 999, 1, "%.0f"); f("Jitter", "scJitter", 0, 1, 0)
        stack.addArrangedSubview(button("Re-roll seed") { [weak self] in self?.host?.pushUndo(); l.xset("scSeed", Float(Int.random(in: 1...999))); self?.rerender(now: true); self?.rebuild() })
        stack.addArrangedSubview(head("Distribution"))
        stack.addArrangedSubview(segment(["Random", "Even spacing"], Int(l.xf("scMode", 0))) { [weak self] i in l.xset("scMode", Float(i)); self?.rerender(now: true) })
        f("Minimum distance", "scMinDist", 0.01, 3, 0.2)
        stack.addArrangedSubview(head("Scale"))
        f("Scale", "scScale", 0.02, 4, 1); f("Random scale", "scScaleRnd", 0, 1, 0.3); f("Squash / stretch", "scSquash", 0, 1, 0)
        stack.addArrangedSubview(head("Rotation"))
        f("Align to surface", "scAlign", 0, 1, 1); f("Random yaw", "scYaw", 0, 360, 360, "%.0f"); f("Random tilt", "scTilt", 0, 90, 0, "%.0f")
        f("Offset X", "scRotX", -180, 180, 0, "%.0f"); f("Offset Y", "scRotY", -180, 180, 0, "%.0f"); f("Offset Z", "scRotZ", -180, 180, 0, "%.0f")
        stack.addArrangedSubview(head("Placement"))
        f("Lift along normal", "scLift", -2, 2, 0); f("Random lift", "scLiftRnd", 0, 2, 0); t("Flip surface normals", "scFlip")
        stack.addArrangedSubview(head("Filters"))
        f("Min slope", "scSlopeMin", 0, 180, 0, "%.0f"); f("Max slope", "scSlopeMax", 0, 180, 180, "%.0f")
        f("Min height", "scHMin", -20, 20, -10); f("Max height", "scHMax", -20, 20, 10)
        stack.addArrangedSubview(head("Noise mask (clumps)"))
        f("Noise scale", "scNoiseScale", 0.2, 30, 3); f("Noise threshold", "scNoiseThr", 0, 1, 0)
        stack.addArrangedSubview(head("Animation"))
        f("Grow-in duration (s)", "scGrow", 0, 5, 0); f("Grow stagger", "scStagger", 0, 1, 0.5)
        f("Sway angle", "scSway", 0, 30, 0, "%.1f"); f("Sway speed", "scSwaySpeed", 0, 4, 1)
        stack.addArrangedSubview(button("Reset this model's scatter settings") { [weak self] in
            self?.host?.pushUndo()
            l.x3s = l.x3s.split(separator: ";").filter { !$0.hasPrefix("sc") || $0.hasPrefix("scList") || $0.hasPrefix("scTarget") || $0.hasPrefix("scOn") }.joined(separator: ";")
            self?.rerender(now: true); self?.rebuild()
        })
        let rm = button("Remove from group") { [weak self] in
            self?.host?.pushUndo(); l.xset("scList", 0); l.xset("scOn", 0); self?.rerender(now: true); self?.sel = -1; self?.rebuild()
        }
        stack.addArrangedSubview(rm)
    }

    // MARK: widgets
    private func head(_ t: String) -> UIView { let l = UILabel(); l.text = t.uppercased(); l.font = .systemFont(ofSize: 12, weight: .bold); l.textColor = accent; return l }
    private func note(_ t: String) -> UIView { let l = UILabel(); l.text = t; l.font = .systemFont(ofSize: 13); l.textColor = .gray; l.numberOfLines = 0; return l }
    private func button(_ t: String, _ f: @escaping () -> Void) -> UIView {
        let b = UIButton(type: .system); b.setTitle(t, for: .normal); b.setTitleColor(.white, for: .normal)
        b.backgroundColor = UIColor(white: 0.18, alpha: 1); b.layer.cornerRadius = 10; b.heightAnchor.constraint(equalToConstant: 42).isActive = true
        b.addAction(UIAction { _ in f() }, for: .touchUpInside); return b
    }
    private func menuButton(_ t: String, _ actions: [UIAction]) -> UIView {
        let b = UIButton(type: .system); b.setTitle(t + "  ▾", for: .normal); b.setTitleColor(.white, for: .normal)
        b.backgroundColor = accent.withAlphaComponent(0.35); b.layer.cornerRadius = 10; b.heightAnchor.constraint(equalToConstant: 42).isActive = true
        b.menu = UIMenu(children: actions); b.showsMenuAsPrimaryAction = true; return b
    }
    private func toggle(_ t: String, _ on: Bool, _ f: @escaping (Bool) -> Void) -> UIView {
        let l = UILabel(); l.text = t; l.textColor = .white; l.font = .systemFont(ofSize: 15)
        let s = UISwitch(); s.isOn = on; s.onTintColor = accent
        s.addAction(UIAction { [weak self] _ in self?.host?.pushUndo(); f(s.isOn) }, for: .valueChanged)
        let r = UIStackView(arrangedSubviews: [l, s]); r.alignment = .center; return r
    }
    private func segment(_ items: [String], _ sel: Int, _ f: @escaping (Int) -> Void) -> UIView {
        let s = UISegmentedControl(items: items); s.selectedSegmentIndex = sel; s.selectedSegmentTintColor = accent
        s.setTitleTextAttributes([.foregroundColor: UIColor.black], for: .selected); s.setTitleTextAttributes([.foregroundColor: UIColor.white], for: .normal)
        s.addAction(UIAction { _ in f(s.selectedSegmentIndex) }, for: .valueChanged); return s
    }
    private func slider(_ t: String, _ v: Float, _ lo: Float, _ hi: Float, _ fmt: String, _ f: @escaping (Float) -> Void) -> UIView {
        let name = UILabel(); name.text = t; name.textColor = .white; name.font = .systemFont(ofSize: 14)
        let val = UILabel(); val.textColor = .lightGray; val.font = .monospacedDigitSystemFont(ofSize: 13, weight: .regular); val.textAlignment = .right
        val.text = String(format: fmt, v)
        let s = UISlider(); s.minimumValue = lo; s.maximumValue = hi; s.value = min(max(v, lo), hi); s.minimumTrackTintColor = accent
        s.addAction(UIAction { _ in f(s.value); val.text = String(format: fmt, s.value) }, for: .valueChanged)
        s.addAction(UIAction { [weak self] _ in self?.host?.pushUndo() }, for: .touchDown)
        s.addAction(UIAction { [weak self] _ in self?.rerender(now: true) }, for: [.touchUpInside, .touchUpOutside])
        let c = UIStackView(arrangedSubviews: [UIStackView(arrangedSubviews: [name, val]), s]); c.axis = .vertical; c.spacing = 2; return c
    }
}
