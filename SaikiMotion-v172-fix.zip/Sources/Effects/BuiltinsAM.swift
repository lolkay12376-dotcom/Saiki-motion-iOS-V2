// BuiltinsAM.swift — Alight Motion style effects ported from the XML files (ids kept exactly as in the XML):
//   nova.effect.am-auto-shake · nova.effect.am-oscillate · nova.effect.am-posterize · nova.effect.am-grunge ·
//   nova.effect.am-pulse-opacity-legacy · com.alightcreative.gradientoverlay (toji-gradientoverlay).
// Display names carry the file prefix ("AM - …", "Toji - …"). Shake/Oscillate/Pulse are "transform" effects in AM; here
// they run in the pixel pass (the layer content is moved / faded), so content moved past the layer edge is clipped.

import Foundation

let amFxIds: Set<String> = ["nova.effect.am-auto-shake", "nova.effect.am-oscillate", "nova.effect.am-posterize",
                            "nova.effect.am-grunge", "nova.effect.am-pulse-opacity-legacy", "com.alightcreative.gradientoverlay"]

/// 2D simplex noise, inlined (no helper functions needed). `s` makes every local name unique.
private func snz(_ s: String, _ vx: String, _ vy: String, _ out: String) -> String {
    let t = """
    { vec2 v§ = vec2(\(vx), \(vy));
      vec2 i§ = floor(v§ + vec2((v§.x + v§.y) * 0.366025403784439));
      vec2 a§ = v§ - i§ + vec2((i§.x + i§.y) * 0.211324865405187);
      float s§ = step(a§.y, a§.x); vec2 o§ = vec2(s§, 1.0 - s§);
      vec2 b§ = a§ - o§ + vec2(0.211324865405187); vec2 c§ = a§ - vec2(0.577350269189626);
      i§ = mod(i§, 289.0);
      vec3 p§ = vec3(i§.y) + vec3(0.0, o§.y, 1.0); p§ = mod((p§ * 34.0 + 1.0) * p§, 289.0);
      p§ = p§ + vec3(i§.x) + vec3(0.0, o§.x, 1.0); p§ = mod((p§ * 34.0 + 1.0) * p§, 289.0);
      vec3 m§ = max(vec3(0.5) - vec3(dot(a§, a§), dot(b§, b§), dot(c§, c§)), vec3(0.0)); m§ = m§ * m§; m§ = m§ * m§;
      vec3 x§ = 2.0 * fract(p§ * 0.024390243902439) - 1.0; vec3 h§ = abs(x§) - 0.5; vec3 q§ = floor(x§ + 0.5); vec3 k§ = x§ - q§;
      m§ = m§ * (1.79284291400159 - 0.85373472095314 * (k§ * k§ + h§ * h§));
      vec3 g§ = vec3(k§.x * a§.x + h§.x * a§.y, k§.y * b§.x + h§.y * b§.y, k§.z * c§.x + h§.z * c§.y);
      \(out) = 130.0 * dot(m§, g§); }
    """
    return t.replacingOccurrences(of: "§", with: s) + "\n"
}

func amFx() -> [EffectDef] {
    func col(_ h: UInt32) -> Int32 { Int32(bitPattern: h) }
    let wave = ["Sine", "Triangle"]
    var out: [EffectDef] = []

    // ---- Auto-Shake ----
    out.append(EffectDef(id: "nova.effect.am-auto-shake", name: "AM - Auto-Shake",
        desc: "Moves the layer randomly over time within specified parameters (Alight Motion's Auto-Shake).",
        category: "Distort", props: [
            PropDef("asMag", "Magnitude", 0, 2000, 50, 0), PropDef("asFreq", "Frequency", 0, 16, 2, 2),
            PropDef("asEvo", "Evolution", 0, 2000, 0, 2), PropDef("asSeed", "Seed", 0, 5, 0, 2),
            PropDef("asAng", "Angle", 0, 3600, 45, 1), PropDef("asSlack", "Slack", 0, 1, 0.25, 2),
            PropDef("asZ", "Z Shake", 0, 2000, 0, 0),
        ], colors: [], previewAnim: "fade", glsl: """
    float e = asEvo + asFreq * uTime;
    float n0 = 0.0; float n1 = 0.0; float n2 = 0.0;
    \(snz("a", "e", "mod(asSeed * 49235.319798, 289.0)", "n0"))
    \(snz("b", "e + 7468.329", "mod(asSeed * 19337.940385, 289.0)", "n1"))
    \(snz("c", "e + 14192.277", "mod(asSeed * 71401.168533, 289.0)", "n2"))
    float dx = n0 * asMag; float dy = n1 * asMag * asSlack;
    float ar = asAng * 0.0174533;
    float ox = dx * cos(ar) - dy * sin(ar); float oy = dx * sin(ar) + dy * cos(ar);
    float zoom = max(1.0 + n2 * asZ * 0.002, 0.05);
    vec2 suv = (uv - 0.5 - vec2(ox, -oy) / uRes) / zoom + 0.5;
    float inside = step(0.0, suv.x) * step(suv.x, 1.0) * step(0.0, suv.y) * step(suv.y, 1.0);
    return src(clamp(suv, 0.0, 1.0)) * inside;
"""))

    // ---- Oscillate ----
    out.append(EffectDef(id: "nova.effect.am-oscillate", name: "AM - Oscillate",
        desc: "Moves the layer back and forth repeatedly, along an angle, in depth or in orbit (Alight Motion's Oscillate).",
        category: "Distort", props: [
            PropDef("osDir", "Direction", 0, 2, 0, 0, ["Angle", "Depth", "Orbit"]), PropDef("osAng", "Angle", -3600, 3600, 45, 1),
            PropDef("osFreq", "Frequency", 0, 16, 2, 2), PropDef("osMag", "Magnitude", 0, 4000, 25, 0),
            PropDef("osType", "Wave", 0, 1, 0, 0, wave), PropDef("osPh", "Phase", 0, 1000, 0, 2),
        ], colors: [], previewAnim: "fade", glsl: """
    float cyc = osFreq * uTime;
    float ph = osPh;
    float m = sin((cyc * 2.0 + ph * 2.0) * 3.14159);
    float x1 = cyc + 2.0 * ph;
    if (osType > 0.5) { m = 4.0 * abs(fract(x1 - 0.25) - 0.5) - 1.0; }
    float ar = (90.0 - osAng) * 0.0174533;
    vec2 d = vec2(0.0);
    float z = 0.0;
    if (osDir < 0.5 || osDir > 1.5) { d = vec2(sin(ar), cos(ar)) * (osMag * m); }
    if (osDir > 0.5) {
        float mz = sin((cyc * 2.0 + (ph + 0.25) * 2.0) * 3.14159);
        if (osType > 0.5) { mz = 4.0 * abs(fract(x1 + 0.125 * 2.0 - 0.25) - 0.5) - 1.0; }
        z = osMag * (osDir > 1.5 ? mz : m);
    }
    float zoom = max(1.0 + z * 0.002, 0.05);
    vec2 suv = (uv - 0.5 - vec2(d.x, -d.y) / uRes) / zoom + 0.5;
    float inside = step(0.0, suv.x) * step(suv.x, 1.0) * step(0.0, suv.y) * step(suv.y, 1.0);
    return src(clamp(suv, 0.0, 1.0)) * inside;
"""))

    // ---- Posterize (AM) ----
    out.append(EffectDef(id: "nova.effect.am-posterize", name: "AM - Posterize",
        desc: "Alight Motion's Posterize: floor((color * steps + d) - d) / steps per channel, d = offset + 0.05.",
        category: "Stylize", props: [PropDef("pzSteps", "Steps", 2, 255, 10, 0), PropDef("pzOff", "Offset", -1, 1, 0, 3)],
        colors: [], previewAnim: "fade", glsl: """
    vec4 s = src(uv);
    float d = pzOff + 0.05;
    vec3 c = floor(s.rgb * pzSteps + d) - d;
    c = clamp(c / pzSteps, 0.0, 1.0);
    return vec4(min(c, vec3(s.a)), s.a);
"""))

    // ---- Pulse Opacity (legacy) ----
    out.append(EffectDef(id: "nova.effect.am-pulse-opacity-legacy", name: "AM - Pulse Opacity (legacy)",
        desc: "Alight Motion's old Pulse Opacity: the layer's opacity pulses with a sine or triangle wave.",
        category: "Transform and time", props: [
            PropDef("poFreq", "Frequency", 0.1, 16, 2, 1), PropDef("poStr", "Strength", 0, 1, 1, 2),
            PropDef("poPh", "Start Phase", 0, 2, 0, 2), PropDef("poType", "Wave", 0, 1, 0, 0, wave),
        ], colors: [], previewAnim: "fade", glsl: """
    vec4 s = src(uv);
    float x = poFreq * uTime + poPh * 0.5;
    float m = sin(x * 6.2831853);
    if (poType > 0.5) { m = 4.0 * abs(fract(x - 0.25) - 0.5) - 1.0; }
    float op = 1.0 - poStr * (0.5 - 0.5 * m);
    return s * op;
"""))

    // ---- Gradient Overlay (Toji) ----
    out.append(EffectDef(id: "com.alightcreative.gradientoverlay", name: "Toji - Gradient Overlay",
        desc: "Alight Motion's Gradient Overlay: linear, radial or sweep gradient over the layer with Normal, Multiply or Screen blend.",
        category: "Color", props: [
            PropDef("goAng", "Angle", 0, 3600, 0, 1), PropDef("goOffX", "Offset X", -2000, 2000, 0, 0), PropDef("goOffY", "Offset Y", -2000, 2000, 0, 0),
            PropDef("goScale", "Scale", 0, 10, 1, 2), PropDef("goAlpha", "Alpha", 0, 1, 0.75, 3),
            PropDef("goType", "Type", 0, 2, 0, 0, ["Linear", "Radial", "Sweep"]),
            PropDef("goBlend", "Blend mode", 0, 2, 0, 0, ["Normal", "Multiply", "Screen"]),
        ], colors: [ColorParam("goC1", "Color 1", col(0xFFEE5533)), ColorParam("goC2", "Color 2", col(0xFFFFEE88))],
        previewAnim: "fade", glsl: """
    vec4 tex = src(uv);
    float a = goAng * 0.0174533;
    vec2 st = uv - 0.5;
    st = st - vec2(goOffX, -goOffY) / 500.0;
    st = st * goScale;
    st = vec2(st.x * sin(a) - st.y * cos(a), st.x * cos(a) + st.y * sin(a));
    st = st + 0.5;
    float t = st.x;
    if (goType > 0.5 && goType < 1.5) { t = length(st - 0.5) * 2.0; }
    else if (goType > 1.5) {
        vec2 xy = st - 0.5;
        float aa = atan(xy.x, xy.y);
        t = mod((aa - 0.0) + 6.28, 6.28) / 6.28;
    }
    t = clamp(t, 0.0, 1.0);
    vec4 gc = mix(goC1, goC2, t);
    vec3 base = tex.rgb / max(tex.a, 0.0001);
    vec3 r = gc.rgb;
    if (goBlend > 0.5 && goBlend < 1.5) { r = base * gc.rgb; }
    else if (goBlend > 1.5) { r = 1.0 - (1.0 - base) * (1.0 - gc.rgb); }
    vec4 res = vec4(r, 1.0) * tex.a;
    return mix(tex, res, goAlpha);
"""))

    // ---- Grunge (procedural textures; 4 texture slots) ----
    var gp: [PropDef] = [PropDef("gStr", "Edge Size", 0, 2, 0.35, 2)]
    var gc: [ColorParam] = []
    let dflt: [(Float, Float, Float, Float, Float, Float, UInt32)] = [   // on, region, grain, blend, burn, alpha, color
        (1, 0, 1, 1, 0.5, 1, 0xFFFF5566), (1, 1, 3, 2, -0.5, 1, 0xFFFF6633), (0, 0, 5, 1, 0, 1, 0xFF886644), (0, 2, 7, 1, 0, 1, 0xFF333333)]
    for i in 1...4 {
        let d = dflt[i - 1], n = "Texture \(i) "
        gp += [PropDef("gT\(i)On", n + "active", 0, 1, d.0, 0, ["Off", "On"]), PropDef("gT\(i)Reg", n + "region", 0, 3, d.1, 0, ["Edge", "Center", "Fill", "Glow"]),
               PropDef("gT\(i)Gr", n + "grain", 1, 16, d.2, 0), PropDef("gT\(i)Sc", n + "scale", 0.01, 50, 1, 2),
               PropDef("gT\(i)Ang", n + "angle", -3600, 3600, 0, 1), PropDef("gT\(i)Gam", n + "gamma", 0.01, 9.99, 1, 3),
               PropDef("gT\(i)Con", n + "contrast", -1, 1, 0, 2), PropDef("gT\(i)Al", n + "alpha", 0, 1, d.5, 2),
               PropDef("gT\(i)Bur", n + "dodge/burn", -1, 1, d.4, 2), PropDef("gT\(i)Spr", n + "spread", 0, 1, 0, 2),
               PropDef("gT\(i)Chk", n + "choke", 0, 1, 0, 2), PropDef("gT\(i)Inv", n + "invert grain", 0, 1, 0, 0, ["Off", "On"]),
               PropDef("gT\(i)Bl", n + "blend", 0, 4, d.3, 0, ["Normal", "Multiply", "Screen", "Expand", "Copy Original"])]
        gc.append(ColorParam("gT\(i)C", n + "color", col(d.6)))
    }
    var gcode = """
    float asp = uRes.x / max(uRes.y, 1.0);
    vec4 s0 = src(uv);
    float a = s0.a;
    vec3 c0 = s0.rgb / max(a, 0.0001);
    vec3 c = c0;
    float ab = 0.0;
    float gR = gStr * 0.12 * uRes.y + 1.0;
    for (int i = 0; i < 8; i++) {
        float an = float(i) * 0.785398;
        ab += src(uv + vec2(cos(an), sin(an)) * gR / uRes).a;
        ab += src(uv + vec2(cos(an), sin(an)) * gR * 0.5 / uRes).a;
    }
    ab = ab / 16.0;
    float em = clamp((1.0 - ab) * 2.0, 0.0, 1.0);
    float lum0 = dot(c0, vec3(0.2126, 0.7152, 0.0722));

    """
    for i in 1...4 {
        var oct = ""
        for _ in 0..<3 {
            oct += "{ vec2 ip = floor(qq); vec2 fp = fract(qq); fp = fp * fp * (3.0 - 2.0 * fp); nn += amp * mix(mix(hash21(ip), hash21(ip + vec2(1.0, 0.0)), fp.x), mix(hash21(ip + vec2(0.0, 1.0)), hash21(ip + vec2(1.0, 1.0)), fp.x), fp.y); amp = amp * 0.5; qq = qq * 2.03 + vec2(17.0, 9.0); }\n"
        }
        gcode += """
        if (gT\(i)On > 0.5) {
            float ang = gT\(i)Ang * 0.0174533;
            vec2 qq = (uv - 0.5) * vec2(asp, 1.0) * 4.0 / gT\(i)Sc;
            qq = vec2(qq.x * cos(ang) - qq.y * sin(ang), qq.x * sin(ang) + qq.y * cos(ang)) * (1.0 + gT\(i)Gr * 0.45) + vec2(gT\(i)Gr * 13.7, gT\(i)Gr * 5.3);
            float nn = 0.0; float amp = 0.5;
            \(oct)
            float gg = pow(clamp(nn / 0.875, 0.0, 1.0), max(gT\(i)Gam, 0.01));
            gg = clamp((gg - 0.5) * (1.0 + gT\(i)Con * 2.0) + 0.5, 0.0, 1.0);
            if (gT\(i)Inv > 0.5) { gg = 1.0 - gg; }
            float dd = smoothstep(0.35 + gT\(i)Chk * 0.4 - gT\(i)Spr * 0.3, 0.8, gg);
            float rm = a * em;
            if (gT\(i)Reg > 0.5 && gT\(i)Reg < 1.5) { rm = a * (1.0 - em); }
            else if (gT\(i)Reg > 1.5 && gT\(i)Reg < 2.5) { rm = a; }
            else if (gT\(i)Reg > 2.5) { rm = a * smoothstep(0.4, 0.9, lum0); }
            vec3 gcol = gT\(i)C.rgb * (1.0 - gT\(i)Bur * 0.5);
            float amt = clamp(dd * rm * gT\(i)Al, 0.0, 1.0);
            if (gT\(i)Bl < 0.5) { c = mix(c, gcol, amt); }
            else if (gT\(i)Bl < 1.5) { c = mix(c, c * gcol, amt); }
            else if (gT\(i)Bl < 2.5) { c = mix(c, 1.0 - (1.0 - c) * (1.0 - gcol), amt); }
            else if (gT\(i)Bl < 3.5) { c = c + gcol * amt; }
            else { c = mix(c, c0, amt); }
        }

        """
    }
    gcode += "    return vec4(max(c, vec3(0.0)) * a, a);\n"
    out.append(EffectDef(id: "nova.effect.am-grunge", name: "AM - Grunge",
        desc: "Layers of procedural grunge, grime, specks and stains on the edge, center or whole layer (Alight Motion's Grunge, 4 texture slots).",
        category: "Stylize", props: gp, colors: gc, previewAnim: "fade", glsl: gcode))
    return out
}
