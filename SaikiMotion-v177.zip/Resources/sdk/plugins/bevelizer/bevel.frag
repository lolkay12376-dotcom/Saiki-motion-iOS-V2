// Pass 3: normals from the height map, then lighting + chrome environment.
vec4 aurea_main(vec2 uv) {
    vec4 src = texture(aurea_source, uv);
    if (src.a <= 0.0001) return vec4(0.0);

    vec3 layerRgb = aurea_unpremultiply(src).rgb;

    // Height gradient (central differences, smoothed by a wide step).
    float stp = max(1.5, bevelSize * 0.12);
    vec2 ex = aurea_px_to_uv(vec2(stp, 0.0));
    vec2 ey = aurea_px_to_uv(vec2(0.0, stp));
    float hl = texture(height, uv - ex).r;
    float hr = texture(height, uv + ex).r;
    float hu = texture(height, uv - ey).r;
    float hd = texture(height, uv + ey).r;
    float hpx = bevelDepth * bevelSize;               // bevel height in px
    vec2 g = vec2(hr - hl, hd - hu) / (2.0 * stp) * hpx;
    {
        int bt = int(bevelType + 0.5);
        float glen = length(g);
        vec2 gd = g / max(glen, 1e-4);
        if (bt == 1) g = gd * pow(glen, 0.6) * 1.3;
        else if (bt == 2) g = -g * 0.8;
        else if (bt == 3) g = -gd * pow(glen, 0.7);
        else if (bt == 4) g = gd * min(glen * 2.5, 3.0);
    }
    vec3 n = normalize(vec3(-g, 1.0));
    if (engrave > 0.5) n.xy = -n.xy;

    // Light (uv y points down, so "up" is -y).
    vec3 L = normalize(vec3(cos(lightAngle), -sin(lightAngle), mix(0.15, 2.0, lightHeight)));
    float s = dot(n, L) - L.z;                         // 0 on flat areas
    float lit  = clamp(s * 2.0, 0.0, 1.0);
    float dark = clamp(-s * 2.0, 0.0, 1.0);

    vec3 base = mix(layerRgb, tint.rgb, tintAmount);
    vec3 col = base;
    col = mix(col, hiColor.rgb, lit * 0.6);
    col = mix(col, shColor.rgb, dark * 0.7);

    // Specular highlight.
    vec3 hv = normalize(L + vec3(0.0, 0.0, 1.0));
    float sp = pow(max(dot(n, hv), 0.0), shininess);
    col += hiColor.rgb * sp * specular;

    // Procedural chrome environment: dark -> tint -> white bands.
    vec3 R = reflect(vec3(0.0, 0.0, -1.0), n);
    float e = 0.5 + 0.5 * sin((R.y * 0.8 + R.x * 0.3) * bands * AUREA_PI + 1.0);
    e = smoothstep(0.1, 0.9, e);
    vec3 midC = mix(tint.rgb, envColor.rgb, envMix);
    vec3 env = (e < 0.5)
        ? mix(shColor.rgb, midC, e * 2.0)
        : mix(midC, hiColor.rgb, (e - 0.5) * 2.0);
    float slope = clamp((1.0 - n.z) * 5.0, 0.0, 1.0);  // chrome only where the surface tilts
    col = mix(col, env, chrome * slope);

    col += rimColor.rgb * pow(1.0 - n.z, 2.0) * rimAmt;
    col *= mix(1.0, 0.55 + 0.45 * clamp(dot(n, L), 0.0, 1.0), ambient);
    float al = src.a * opacity;
    return vec4(col * al, al);                   // linear, premultiplied
}
