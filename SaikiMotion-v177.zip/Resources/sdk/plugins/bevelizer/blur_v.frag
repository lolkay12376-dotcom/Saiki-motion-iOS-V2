// Pass 2: vertical blur, then turn the blurred alpha into a bevel height profile.
vec4 aurea_main(vec2 uv) {
    float acc = 0.0;
    for (int i = 0; i < 32; ++i) {
        float y = (float(i) + 0.5) / 32.0 * 2.0 - 1.0;
        acc += texture(hblur, uv + aurea_px_to_uv(vec2(0.0, y * bevelSize))).r;
    }
    acc /= 32.0;
    // 0.5 sits on the edge of a straight shape; ramp up toward the inside.
    float t = clamp((acc - 0.5) * 2.0, 0.0, 1.0);
    float circle = sqrt(max(0.0, 1.0 - (1.0 - t) * (1.0 - t)));
    float h = mix(t, circle, rounding);
    return vec4(h, h, h, 1.0);
}
