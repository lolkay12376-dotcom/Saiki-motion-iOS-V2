// Sangue escorrendo (Bleed) para AUREA.
// Um arquivo, 8 passes: AUREA_PASS_INDEX escolhe o passe. Medidas em px de uma comp 1920x1080 (Kref).

float Kref() { return min(aurea.layer.x / 1920.0, aurea.layer.y / 1080.0); }
vec2 offRef(vec2 p) { return aurea_px_to_uv(p * Kref()); }
vec2 refPos(vec2 uv) { return aurea_layer_uv(uv) * aurea.layer.xy / Kref(); }
float gauss(float x, float s) { return exp(-0.5 * x * x / (s * s)); }

float hash1(vec2 p) {
    vec3 q = fract(vec3(p.xyx) * 0.1031);
    q += dot(q, q.yzx + 33.33);
    return fract((q.x + q.y) * q.z);
}
vec3 hash3(vec3 p) {
    p = fract(p * vec3(0.1031, 0.1030, 0.0973));
    p += dot(p, p.yxz + 33.33);
    return fract((p.xxy + p.yxx) * p.zyx);
}

// Uma gota: risco de ponta redonda embaixo, d em px de referência a partir da ponta.
float gota(vec2 d, float larg, float alt) {
    float u = d.x / larg;
    float v = 0.94 + d.y / alt;
    float cauda = exp(-0.5 * u * u / (0.18 * 0.18)) * (0.07 + 0.8 * v)
                * smoothstep(0.0, 0.03, v) * (1.0 - smoothstep(0.93, 0.99, v));
    float rh = 0.36 * larg;
    float ponta = 0.89 * (1.0 - smoothstep(0.55 * rh, 1.3 * rh, length(d)));
    return max(cauda, ponta);
}

// Gotas que caem (cobertura 0..1) no ponto uv.
float gotasAt(vec2 uv) {
    vec2 P = refPos(uv);
    float a = 576.0 * max(pressure, 0.0) / 25.0;
    if (a <= 0.0 || density <= 0.0) return 0.0;
    float tau = aurea.time.x * pressure / 25.0;
    float T = clamp(sqrt(2.0 * 1150.0 / a) + 0.3, 1.0, 4.0);
    const float CW = 48.0;
    float quantas = min(2.75 * T * density / 25.0, 24.0);
    float c0 = floor(P.x / CW);
    float resto = 1.0;
    for (int dc = -1; dc <= 1; dc++) {
        float c = c0 + float(dc);
        for (int s = 0; s < 24; s++) {
            if (float(s) >= quantas) break;
            vec2 id = vec2(c, float(s) + 31.0 * randomSeed);
            if (float(s) + 1.0 > quantas && hash1(id + 7.7) > fract(quantas)) continue;
            float fase = tau / T + hash1(id);
            float n = floor(fase);
            float idade = (fase - n) * T;
            vec3 r = hash3(vec3(id, n) + 0.37);
            float tam = (0.5 + r.z) * dropSize / 100.0;
            float larg = 25.0 * tam;
            float alt = 205.0 * tam * (1.0 + 0.17 * idade);
            vec2 cab = vec2((c + r.x) * CW, mix(70.0, 720.0, r.y) - 40.0 * idade + 0.5 * a * idade * idade);
            vec2 d = P - cab;
            if (abs(d.x) > 0.6 * larg || d.y > 0.5 * larg || d.y < -alt) continue;
            float op = min(1.0, 0.62 + 0.5 * idade) * (1.0 - smoothstep(T - 0.15, T, idade));
            resto *= 1.0 - op * gota(d, larg, alt);
        }
    }
    return 1.0 - resto;
}

// Brilho médio da Blood Color em sRGB (é o que move a direção do Vector Blur).
float bloodMedia() {
    vec3 c = aurea_linear_to_srgb(bloodColor.rgb);
    return (c.r + c.g + c.b) / 3.0;
}

// Linear Wipe: 1 de um lado da transição, 0 do outro.
float wipeAt(vec2 uv) {
    vec2 q = aurea.layer.xy / Kref();
    vec2 u = vec2(sin(angle), -cos(angle));     // angle já vem em radianos
    float t = dot(refPos(uv), u);
    float t0 = min(min(0.0, q.x * u.x), min(q.y * u.y, dot(q, u)));
    float t1 = max(max(0.0, q.x * u.x), max(q.y * u.y, dot(q, u)));
    float tc = mix(t0, t1, completion / 100.0);
    return clamp((t - tc) / max(feather * 4.0 / 3.0, 0.001) + 0.5, 0.0, 1.0);
}

#if AUREA_PASS_INDEX == 0
// Passe 0: R = estêncil (máximo do alfa 1000 px acima); G = blur σ28 de (1 − alfa); B = blur σ6 do alfa.
vec4 aurea_main(vec2 uv) {
    float est = 0.0;
    for (int i = 0; i <= 125; i++)
        est = max(est, texture(aurea_source, uv - offRef(vec2(0.0, 8.0 * float(i)))).a);
    float sr = 0.0, tr = 0.0;
    for (int j = -9; j <= 9; j++)
    for (int i = -9; i <= 9; i++) {
        vec2 o = vec2(float(i), float(j)) * 8.0;
        float w = gauss(length(o), 28.3);
        sr += w * (1.0 - texture(aurea_source, uv + offRef(o)).a);
        tr += w;
    }
    float sb = 0.0, tb = 0.0;
    for (int j = -9; j <= 9; j++)
    for (int i = -9; i <= 9; i++) {
        vec2 o = vec2(float(i), float(j)) * 2.0;
        float w = gauss(length(o), 6.0);
        sb += w * texture(aurea_source, uv + offRef(o)).a;
        tb += w;
    }
    return vec4(est, sr / tr, sb / tb, 1.0);
}

#elif AUREA_PASS_INDEX == 1
// Passe 1: CC Vector Blur 500 na forma; a direção vem do brilho do sangue × blur do alfa.
vec4 aurea_main(vec2 uv) {
    float brilho = bloodMedia() * texture(mask, uv).b;
    float th = 2.0 * 3.14159265 * brilho;
    vec2 dir = vec2(sin(th), -cos(th));
    float soma = 0.0, tot = 0.0;
    for (int i = 0; i < 125; i++) {
        float w = 1.0 - float(i) / 125.0;
        soma += w * texture(aurea_source, uv + offRef(dir * 4.0 * float(i))).a;
        tot += w;
    }
    return vec4(soma / tot, 0.0, 0.0, 1.0);
}

#elif AUREA_PASS_INDEX == 2
// Passe 2: alfa da camada "Drops" (antes do segundo Vector Blur), depois Vector Blur 75.
// R = alfa, G = parte do sangue.
vec4 aurea_main(vec2 uv) {
    float b2 = 0.0, tb = 0.0;
    for (int j = -6; j <= 6; j++)
    for (int i = -6; i <= 6; i++) {
        vec2 o = vec2(float(i), float(j)) * 3.0;
        float w = gauss(length(o), 6.0);
        b2 += w * texture(vecA, uv + offRef(o)).r;
        tb += w;
    }
    b2 /= tb;
    float th = 2.0 * 3.14159265 * bloodMedia() * 0.5 * b2;
    vec2 dir = vec2(sin(th), -cos(th));
    vec2 soma = vec2(0.0);
    float tot = 0.0;
    for (int i = 0; i < 38; i++) {
        float w = 1.0 - float(i) / 38.0;
        vec2 q = uv + offRef(dir * (75.0 / 38.0) * float(i));
        float v = 0.5 * texture(vecA, q).r;
        float s = texture(aurea_source, q).a;
        float alfa = v + s * texture(mask, q).g * (1.0 - v);
        soma += w * vec2(alfa, v);
        tot += w;
    }
    return vec4(soma / tot, 0.0, 1.0);
}

#elif AUREA_PASS_INDEX == 3
// Passe 3: gotas que caem × estêncil, deslocadas pela forma, com limiar.
// R = gotas, G = gotas ∪ forma, B = cor do sangue.
vec4 aurea_main(vec2 uv) {
    float s = texture(aurea_source, uv).a;
    vec2 desl = vec2(10.0 * (2.0 * objectColor.r - 1.0), -10.0 * (2.0 * objectColor.g - 1.0)) * s;
    vec2 q = clamp(uv + offRef(desl), 0.0, 1.0);
    float e = 0.0, tot = 0.0;
    for (int i = -2; i <= 2; i++)
    for (int j = -2; j <= 2; j++) {
        float w = exp(-0.5 * float(i * i + j * j) * 16.0 / (5.66 * 5.66));
        e += w * texture(mask, q + offRef(vec2(float(i), float(j)) * 4.0)).r;
        tot += w;
    }
    float m = 0.5 * gotasAt(q) * e / tot;
    vec2 v = texture(vecB, q).rg;
    float a6 = m + (1.0 - m) * v.r;
    float larg = max(fwidth(a6), 1e-4);
    float D = smoothstep(0.43137 - larg, 0.43137 + larg, a6);
    return vec4(D, D + s * (1.0 - D), clamp((1.0 - m) * v.g / max(a6, 1e-4), 0.0, 1.0), 1.0);
}

#elif AUREA_PASS_INDEX == 4
// Passe 4: Roughen (blur σ3 de drops∪forma -> ao) e relevo do CC Glass (blur σ4.8 das gotas).
// R = roughen, G = relevo.
vec4 aurea_main(vec2 uv) {
    float a = 0.0, ta = 0.0;
    for (int j = -4; j <= 4; j++)
    for (int i = -4; i <= 4; i++) {
        vec2 o = vec2(float(i), float(j)) * 2.0;
        float w = gauss(length(o), 3.0);
        a += w * texture(drops, uv + offRef(o)).g;
        ta += w;
    }
    float b = 0.0, tb = 0.0;
    for (int j = -5; j <= 5; j++)
    for (int i = -5; i <= 5; i++) {
        vec2 o = vec2(float(i), float(j)) * 3.0;
        float w = gauss(length(o), 4.8);
        b += w * texture(drops, uv + offRef(o)).r;
        tb += w;
    }
    return vec4(a / ta, b / tb, 0.0, 1.0);
}

#elif AUREA_PASS_INDEX == 5
// Passe 5: a camada Bevel (Calculations + Bevel Type), borrada com σ 5.66.
vec4 bevelAt(vec2 uv) {
    float s = texture(aurea_source, uv).a;
    vec4 g = texture(drops, uv);
    float op = clamp(bevelOpacity / 100.0, 0.0, 1.0);
    float D = g.r;
    vec3 cd = bloodColor.rgb * g.b;
    vec3 ca = mix(vec3(1.0), objectColor.rgb, clamp(s * 60.0, 0.0, 1.0));
    float aa = 0.5 * s;
    vec4 apm = vec4(objectColor.rgb * aa, aa);
    int bt = int(bevelType + 0.5);
    if (bt == 0) return vec4(apm.rgb * (1.0 - op * D) + cd * op * D, op * D + aa * (1.0 - op * D));
    if (bt == 1) { float al = aa + op * D - aa * op * D; return vec4(mix(ca, max(ca, cd), op) * al, al); }
    if (bt == 2) { float al = D * op; return vec4(mix(ca, min(ca, cd), op) * al, al); }
    if (bt == 3) return apm * mix(1.0, D, op);
    return apm * mix(1.0, dot(cd * D, vec3(0.299, 0.587, 0.114)), op);
}

vec4 aurea_main(vec2 uv) {
    vec4 soma = vec4(0.0);
    float tot = 0.0;
    for (int j = -6; j <= 6; j++)
    for (int i = -6; i <= 6; i++) {
        vec2 o = vec2(float(i), float(j)) * 3.0;
        float w = gauss(length(o), 5.66);
        soma += w * bevelAt(uv + offRef(o));
        tot += w;
    }
    return soma / tot;
}

#elif AUREA_PASS_INDEX == 6
// Passe 6: borrões σ6 dos estilos: R = ao (roughen com limiar), G = bisel × Linear Wipe.
vec4 aurea_main(vec2 uv) {
    float a = 0.0, b = 0.0, tb = 0.0;
    for (int j = -6; j <= 6; j++)
    for (int i = -6; i <= 6; i++) {
        vec2 o = vec2(float(i), float(j)) * 3.0;
        vec2 q = uv + offRef(o);
        float w = gauss(length(o), 6.0);
        a += w * clamp((texture(rough, q).r - 0.48) * 4.0 + 0.5, 0.0, 1.0);
        b += w * texture(bevel, q).a * wipeAt(q);
        tb += w;
    }
    return vec4(a / tb, b / tb, 0.0, 1.0);
}

#elif AUREA_PASS_INDEX == 7
// Passe 7 (saída): corpo + bisel + reflexo do CC Glass. Saída pré-multiplicada.
float satinCanal(vec2 uv, float rad, int canal) {
    vec2 d = offRef(11.0 * vec2(cos(rad), -sin(rad)));
    vec4 m = texture(edges, clamp(uv + d, 0.0, 1.0));
    vec4 n = texture(edges, clamp(uv - d, 0.0, 1.0));
    return 1.0 - abs(canal == 0 ? m.r - n.r : m.g - n.g);
}

vec4 aurea_main(vec2 uv) {
    float ao = clamp((texture(rough, uv).r - 0.48) * 4.0 + 0.5, 0.0, 1.0);

    // Corpo: Blood Color com o Satin de 45°.
    vec3 corpo = bloodColor.rgb * (1.0 - satinAmt * satinCanal(uv, 0.7853982, 0));
    corpo = mix(corpo, darkColor.rgb, darkAmt * smoothstep(0.3, 0.9, texture(rough, uv).g));

    // Bisel: a camada Bevel cortada pelo Linear Wipe, com Satin de 19° e relevo.
    vec4 b = texture(bevel, uv) * wipeAt(uv);
    vec3 cb = b.a > 1e-4 ? b.rgb / b.a : vec3(0.0);
    const float G = 12.0;
    vec2 gx = offRef(vec2(G, 0.0)), gy = offRef(vec2(0.0, G));
    float hx = (texture(edges, clamp(uv + gx, 0.0, 1.0)).g - texture(edges, clamp(uv - gx, 0.0, 1.0)).g) / (2.0 * G);
    float hy = (texture(edges, clamp(uv + gy, 0.0, 1.0)).g - texture(edges, clamp(uv - gy, 0.0, 1.0)).g) / (2.0 * G);
    const float KB = 6.0, SA = 0.9961947, CA = 0.0871557;
    float nl = (KB * hy * CA + SA) / sqrt(1.0 + KB * KB * (hx * hx + hy * hy));
    float realce = clamp(3000.0 * (nl - SA), 0.0, 1.0);
    vec3 bisel = cb * (1.0 - 0.5 * satinCanal(uv, 0.3316126, 1)) + bevelColor.rgb * bevelLight * realce;

    vec3 cor = corpo + b.a * bisel * (1.0 - corpo);

    // Reflexo fino do CC Glass: inclinação do relevo voltada para a luz a 200°.
    const float E = 2.0;
    vec2 ex = offRef(vec2(E, 0.0)), ey = offRef(vec2(0.0, E));
    float gxr = (texture(rough, clamp(uv + ex, 0.0, 1.0)).g - texture(rough, clamp(uv - ex, 0.0, 1.0)).g) / (2.0 * E);
    float gyr = (texture(rough, clamp(uv + ey, 0.0, 1.0)).g - texture(rough, clamp(uv - ey, 0.0, 1.0)).g) / (2.0 * E);
    vec2 dg = vec2(gxr, gyr) - vec2(0.01368, -0.03759);
    float reflexo = 2.5 * glossAmt * exp(-dot(dg, dg) / (2.0 * 0.006 * 0.006));

    vec3 rgb = min(cor + reflexo * glossColor.rgb, 1.0);
    return vec4(rgb * ao * opacity, ao * opacity);
}
#endif
