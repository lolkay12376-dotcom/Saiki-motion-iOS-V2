// Pass 1: horizontal blur of the shape alpha at 3 radii (r=bevel, g=dome, b=glow). Full resolution.
vec4 aurea_main(vec2 uv) {
    int qn = int(quality + 0.5);
    int half_ = qn == 0 ? 5 : (qn == 1 ? 8 : 14);
    float R1 = 6.0 * bevelx;
    float R2 = R1 * 3.5;
    float R3 = 22.0 + 10.0 * bevelx;
    vec3 acc = vec3(0.0);
    float wsum = 0.0;
    for (int i = -16; i <= 16; ++i) {
        if (abs(i) > half_) continue;
        float t = float(i) / float(half_);
        float w = exp(-t * t * 3.0);
        float a1 = texture(aurea_source, uv + aurea_px_to_uv(vec2(t * R1, 0.0))).a;
        float a2 = texture(aurea_source, uv + aurea_px_to_uv(vec2(t * R2, 0.0))).a;
        float a3 = texture(aurea_source, uv + aurea_px_to_uv(vec2(t * R3, 0.0))).a;
        acc += w * vec3(a1, a2, a3);
        wsum += w;
    }
    return vec4(acc / wsum, 1.0);
}
