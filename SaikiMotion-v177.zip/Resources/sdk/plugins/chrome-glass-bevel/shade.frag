// Pass 3: chrome / glass shading from the height maps, with quality-dependent supersampling
vec3 cosPal(vec3 a, vec3 b, vec3 c, vec3 d, float t) {
    return a + b * cos(6.2831853 * (c * t + d));
}
vec3 palette(int p, float t) {
    if (p == 0) return cosPal(vec3(0.74), vec3(0.26), vec3(1.0), vec3(0.0, 0.02, 0.05), t);
    if (p == 1) return cosPal(vec3(0.38, 0.45, 0.85), vec3(0.35, 0.3, 0.3), vec3(1.0), vec3(0.0, 0.1, 0.25), t);
    if (p == 2) return cosPal(vec3(0.62, 0.82, 0.96), vec3(0.38, 0.18, 0.1), vec3(1.0), vec3(0.0, 0.1, 0.2), t);
    if (p == 3) return cosPal(vec3(0.62, 0.55, 0.78), vec3(0.4, 0.4, 0.4), vec3(1.0), vec3(0.0, 0.33, 0.67), t);
    if (p == 4) return cosPal(vec3(0.78, 0.58, 0.22), vec3(0.3, 0.28, 0.2), vec3(1.0), vec3(0.0, 0.05, 0.1), t);
    return cosPal(vec3(0.84, 0.82, 0.9), vec3(0.18, 0.18, 0.2), vec3(1.0), vec3(0.0, 0.33, 0.67), t);
}
vec3 glowColor(int p) {
    if (p == 0) return vec3(0.8, 0.85, 1.0);
    if (p == 1) return vec3(0.3, 0.4, 1.0);
    if (p == 2) return vec3(0.5, 0.85, 1.0);
    if (p == 3) return vec3(0.8, 0.5, 1.0);
    if (p == 4) return vec3(1.0, 0.7, 0.25);
    return vec3(1.0, 0.85, 0.95);
}
// Shades one sample; returns premultiplied linear rgb in .rgb and alpha in .a
vec4 shadeAt(vec2 uv, int p, float db) {
    float a = texture(aurea_source, uv).a;
    vec3 H = texture(hm, uv).rgb;
    vec2 d = aurea_px_to_uv(vec2(db));
    float R1 = 6.0 * bevelx;
    float R2 = R1 * 3.5;
    // Sobel gradient of the height maps (per layer px)
    vec3 tl = texture(hm, uv + vec2(-d.x, -d.y)).rgb;
    vec3 tc = texture(hm, uv + vec2( 0.0, -d.y)).rgb;
    vec3 tr = texture(hm, uv + vec2( d.x, -d.y)).rgb;
    vec3 ml = texture(hm, uv + vec2(-d.x,  0.0)).rgb;
    vec3 mr = texture(hm, uv + vec2( d.x,  0.0)).rgb;
    vec3 bl = texture(hm, uv + vec2(-d.x,  d.y)).rgb;
    vec3 bc = texture(hm, uv + vec2( 0.0,  d.y)).rgb;
    vec3 br = texture(hm, uv + vec2( d.x,  d.y)).rgb;
    vec3 gx = ((tr + 2.0 * mr + br) - (tl + 2.0 * ml + bl)) / (8.0 * db);
    vec3 gy = ((bl + 2.0 * bc + br) - (tl + 2.0 * tc + tr)) / (8.0 * db);
    vec2 g1 = vec2(gx.r, gy.r) * R1 * 1.6;
    vec2 g2 = vec2(gx.g, gy.g) * R2 * 0.9;
    vec2 g = (g1 + g2 * 0.7) * depthx * 1.6;
    {
        int bt = int(bevelType + 0.5);
        float glen = length(g);
        vec2 gd = g / max(glen, 1e-4);
        if (bt == 1) g = gd * pow(glen, 0.6) * 1.3;
        else if (bt == 2) g = -g * 0.8;
        else if (bt == 3) g = -gd * pow(glen, 0.7);
        else if (bt == 4) g = gd * min(glen * 2.5, 3.0);
        if (engrave > 0.5) g = -g;
    }
    vec3 n = normalize(vec3(-g, 1.0));

    float ca = cos(lightang), sa = sin(lightang);
    vec2 r = n.xy * 2.0 * n.z;
    vec2 rr = vec2(ca * r.x + sa * r.y, -sa * r.x + ca * r.y);
    float s = rr.y * 2.2 + rr.x * 0.7 + (H.r - 0.5) * 0.6;
    float raw = 0.5 + 0.5 * sin(s * 3.14159 * 1.5 + 1.0);
    float band = clamp((raw - 0.5) * (reflx * 2.2) + 0.5, 0.0, 1.0);
    band = smoothstep(0.0, 1.0, band);

    float tpal = band * 0.55 + rr.x * 0.25 * irid + rr.y * 0.15 * irid + hueshift;
    vec3 col = palette(p, tpal) * mix(0.10, 1.15, band);
    float lm = dot(col, vec3(0.3333));
    col = mix(col, aurea_linear_to_srgb(tintColor.rgb) * lm * 1.6, tintAmt);
    col += aurea_linear_to_srgb(shColor.rgb) * (1.0 - band) * 0.5;

    vec3 L = normalize(vec3(ca * 0.6, -sa * 0.6, mix(0.3, 1.4, lightHeight)));
    vec3 Hh = normalize(L + vec3(0.0, 0.0, 1.0));
    float spec = pow(max(dot(n, Hh), 0.0), shinePow) * shine * 1.5;
    float rim = pow(1.0 - n.z, 1.6) * 0.9 * rimAmt;
    col += aurea_linear_to_srgb(hiColor.rgb) * (spec + rim * 0.5);
    col *= bright;

    float sw = 0.0;
    if (sweep > 0.0) {
        vec2 lp = aurea_layer_uv(uv);
        float u = (lp.x * cos(sweepAng) + lp.y * sin(sweepAng)) * 0.8;
        float ph = fract(aurea.time.x * sweepspd * 0.25) * 2.2 - 0.6;
        float x = u - ph;
        sw = (exp(-x * x * 900.0 / (sweepW * sweepW)) + 0.5 * exp(-(x - 0.06) * (x - 0.06) * 2500.0 / (sweepW * sweepW))) * sweep;
    }
    col += aurea_linear_to_srgb(sweepColor.rgb) * sw * 1.2 * smoothstep(0.1, 0.6, H.g);

    vec3 lin = aurea_srgb_to_linear(clamp(col, 0.0, 4.0));
    return vec4(lin * a, a);
}
vec4 aurea_main(vec2 uv) {
    int p = int(preset + 0.5);
    int qn = int(quality + 0.5);
    float db = qn == 0 ? 2.0 : (qn == 1 ? 2.5 : 3.5);

    // supersampling: 1 / 2 / 4 rotated-grid samples
    vec4 acc = vec4(0.0);
    float ns = 1.0;
    if (qn == 0) {
        acc = shadeAt(uv, p, db);
    } else if (qn == 1) {
        acc = shadeAt(uv + aurea_px_to_uv(vec2(0.25, 0.25)), p, db)
            + shadeAt(uv - aurea_px_to_uv(vec2(0.25, 0.25)), p, db);
        ns = 2.0;
    } else {
        for (int i = 0; i < 4; ++i) {
            float fi = float(i);
            vec2 o = vec2(fract(fi * 0.7548776662 + 0.5), fract(fi * 0.5698402910 + 0.5)) - 0.5;
            acc += shadeAt(uv + aurea_px_to_uv(o * 0.95), p, db);
        }
        ns = 4.0;
    }
    acc /= ns;
    vec3 outRGB = acc.rgb;
    float outA = acc.a;

    vec3 H = texture(hm, uv).rgb;
    float gl = H.b * (1.0 - outA) * glow;
    vec3 gc = aurea_srgb_to_linear(mix(glowColor(p), palette(p, hueshift + 0.3), 0.3));
    gc = mix(gc, glowTintC.rgb, glowTint);
    outRGB += gc * gl * 0.9;
    outA = max(outA, min(gl * 0.8, 1.0));

    if (stars > 0.0) {
        vec2 px = aurea_uv_to_px(uv);
        float cell = 70.0 / max(starDensity, 0.2);
        vec2 id = floor(px / cell);
        vec2 rnd = aurea_hash2(id + 3.0);
        vec2 c = (id + 0.2 + 0.6 * rnd) * cell;
        float on = step(aurea_hash(id + 11.0), stars * 0.6);
        float mask = smoothstep(0.2, 0.55, texture(hm, aurea_px_to_uv(c)).g);
        float tw = 0.5 + 0.5 * sin(aurea.time.x * 3.0 + aurea_hash(id) * 6.2831);
        vec2 q = px - c;
        float arm1 = exp(-abs(q.y) / 1.2) * exp(-abs(q.x) / (14.0 * starSize));
        float arm2 = exp(-abs(q.x) / 1.2) * exp(-abs(q.y) / (14.0 * starSize));
        float core = exp(-length(q) / (3.5 * starSize));
        float st = (arm1 + arm2 + core) * on * mask * tw;
        outRGB += starColor.rgb * st;
        outA = max(outA, min(st, 1.0));
    }
    return vec4(outRGB * opacity, outA * opacity);
}
