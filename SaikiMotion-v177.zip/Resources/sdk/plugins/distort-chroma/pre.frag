// Pass 1 (1/4 res): box-average the layer over exactly the tap spacing of the
// first blur level, so the later (wider) blur levels never alias into ripples.
vec4 aurea_main(vec2 uv) {
    float width = max(max(warpBlur, 0.0) * warpSize * 6.0 * 0.25, 6.0);   // layer px
    float step_px = width / 11.0;
    vec2 sz = vec2(textureSize(aurea_source, 0));
    vec4 acc = vec4(0.0);
    for (int iy = -5; iy <= 5; ++iy) {
        for (int ix = -5; ix <= 5; ++ix) {
            vec2 p = uv + aurea_px_to_uv(vec2(float(ix), float(iy)) * step_px);
            p = vec2(1.0) - abs(vec2(1.0) - mod(p, vec2(2.0)));
            p = clamp(p, vec2(0.5) / sz, vec2(1.0) - vec2(0.5) / sz);   // never touch the transparent border
            acc += textureLod(aurea_source, p, 0.0);
        }
    }
    return acc / 121.0;
}
