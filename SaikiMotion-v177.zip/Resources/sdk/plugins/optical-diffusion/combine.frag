// Optical Diffusion v1.1 for AUREA - pass 7/7 (final output)
// Micro diffusion (Poisson blur of the raw source, full detail) + dual-octave
// highlight bloom (tight + wide) + luma-preserving halation tint + mist grade.
// Color space: linear, premultiplied alpha.

// 12 golden-spiral offsets in the unit disc with baked gaussian-ish weights
// (steep exp(-3 r^2) profile: center-dominated -> smooth, no stipple).
const vec2 PD[12] = vec2[12](
    vec2(-0.150,  0.138), vec2( 0.031, -0.352), vec2( 0.264,  0.344),
    vec2(-0.493, -0.087), vec2( 0.471, -0.298), vec2(-0.159,  0.592),
    vec2(-0.305, -0.587), vec2( 0.664,  0.243), vec2(-0.693,  0.286),
    vec2( 0.335, -0.716), vec2( 0.248,  0.791), vec2(-0.747, -0.438)
);
const float PW[12] = float[12](
    0.8827, 0.6873, 0.5688, 0.4717, 0.3941, 0.3247,
    0.2697, 0.2225, 0.1844, 0.1529, 0.1278, 0.1059
);

vec4 aurea_main(vec2 uv) {
    // --- filter character: tent blend across the 5 presets ---
    float f  = clamp(filter_type, 0.0, 4.0);
    float w0 = clamp(1.0 - abs(f - 0.0), 0.0, 1.0);
    float w1 = clamp(1.0 - abs(f - 1.0), 0.0, 1.0);
    float w2 = clamp(1.0 - abs(f - 2.0), 0.0, 1.0);
    float w3 = clamp(1.0 - abs(f - 3.0), 0.0, 1.0);
    float w4 = clamp(1.0 - abs(f - 4.0), 0.0, 1.0);
    float ws = max(w0 + w1 + w2 + w3 + w4, 1e-4);
    w0 /= ws; w1 /= ws; w2 /= ws; w3 /= ws; w4 /= ws;

    float liftC = w0 * 0.35 + w1 * 0.85 + w2 * 0.25 + w3 * 1.00 + w4 * 0.45;
    float softC = w0 * 0.75 + w1 * 0.85 + w2 * 1.10 + w3 * 0.90 + w4 * 1.30;
    float glowC = w0 * 0.90 + w1 * 1.05 + w2 * 0.60 + w3 * 1.70 + w4 * 0.45;
    float flatC = w0 * 0.50 + w1 * 0.80 + w2 * 0.55 + w3 * 1.00 + w4 * 0.60;

    vec4 src = texture(aurea_source, uv);

    // ---- micro diffusion: small Poisson blur of the raw source (full res) ----
    float soft = clamp(softness, 0.0, 1.0);
    float rad  = mix(0.8, 8.5, soft) * mix(0.75, 1.25, clamp(softC * 0.75, 0.0, 1.0));
    float smix = clamp(soft * softC * 0.8, 0.0, 0.95);

    vec4 acc = src;
    float pwsum = 1.0;
    for (int i = 0; i < 12; i++) {
        vec4 c = texture(aurea_source, uv + aurea_px_to_uv(PD[i] * rad));
        acc += c * PW[i];
        pwsum += PW[i];
    }
    vec4 base = mix(src, acc / pwsum, smix);

    // ---- dual-octave highlight bloom (tight + wide, smooth multi-scale tail) ----
    vec3 bloomRGB = texture(glow, uv).rgb + texture(wide, uv).rgb * 0.55;
    float bloomAmt = clamp(bloom, 0.0, 1.0);
    float gain = bloomAmt * glowC * 1.1;
    float gL = aurea_luma(bloomRGB);

    // halation tint, luma preserving
    vec3 hal = halation_color.rgb;
    float halL = max(aurea_luma(hal), 1e-4);
    vec3 tinted = hal * (gL / halL);
    vec3 gcol = mix(bloomRGB, tinted, clamp(warmth, 0.0, 1.0));

    // scatter compensation: ease the direct image where the veil is strong
    float veil = clamp(gL, 0.0, 1.0);
    vec3 direct = base.rgb * (1.0 - 0.25 * glowC * bloomAmt * veil);

    vec4 sum = vec4(direct, base.a) + vec4(gcol, clamp(gL, 0.0, 1.0)) * gain;

    // ---- mist grade (straight alpha) ----
    vec4 st = aurea_unpremultiply(sum);
    float lum = aurea_luma(st.rgb);

    // gentle shadow lift, strongest where the image is dark
    float liftw = 1.0 - smoothstep(0.0, 0.5, lum);
    st.rgb += shadow_lift * liftC * 0.025 * liftw;

    // subtle contrast flattening around perceptual mid grey
    float cc = flatC * 0.08;
    st.rgb = mix(st.rgb, vec3(0.21) + (st.rgb - vec3(0.21)) * (1.0 - cc), 0.5);

    vec4 outc = aurea_premultiply(vec4(max(st.rgb, vec3(0.0)), clamp(st.a, 0.0, 1.0)));
    return mix(src, outc, clamp(amount, 0.0, 1.0));
}
