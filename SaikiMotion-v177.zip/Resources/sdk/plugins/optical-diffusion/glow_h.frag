// Optical Diffusion v1.1 for AUREA - pass 3/7
// Glow chain, horizontal: sigma doubles vs the capture pass.
// Chained doubling Gaussians are safe: this pass samples "cap", which is
// already smooth at ~1.25*scl texels, and 0.4*sigma = 1.0*scl stays inside
// that smoothness scale -> no missed features, no clumpy falloff.
// Target "glow_h", 0.5 scale. Linear, premultiplied alpha.

const float KW[12] = float[12](
    0.0000276, 0.0006097, 0.0072059, 0.0457700, 0.1566795, 0.2897073,
    0.2897073, 0.1566795, 0.0457700, 0.0072059, 0.0006097, 0.0000276
);
const float KM[12] = float[12](
    -4.2584, -3.4766, -2.6985, -1.9239, -1.1529, -0.3840,
     0.3840,  1.1529,  1.9239,  2.6985,  3.4766,  4.2584
);

vec4 gauss1d(sampler2D tex, vec2 uv, vec2 dir, float sigma) {
    vec4 acc = vec4(0.0);
    for (int j = 0; j < 12; j++) {
        vec2 o = dir * aurea.resolution.zw * (KM[j] * sigma);
        acc += texture(tex, uv + o) * KW[j];
    }
    return acc;
}

vec4 aurea_main(vec2 uv) {
    float f  = clamp(filter_type, 0.0, 4.0);
    float w0 = clamp(1.0 - abs(f - 0.0), 0.0, 1.0);
    float w1 = clamp(1.0 - abs(f - 1.0), 0.0, 1.0);
    float w2 = clamp(1.0 - abs(f - 2.0), 0.0, 1.0);
    float w3 = clamp(1.0 - abs(f - 3.0), 0.0, 1.0);
    float w4 = clamp(1.0 - abs(f - 4.0), 0.0, 1.0);
    float ws = max(w0 + w1 + w2 + w3 + w4, 1e-4);
    w0 /= ws; w1 /= ws; w2 /= ws; w3 /= ws; w4 /= ws;

    float sprC = w0 * 0.90 + w1 * 1.00 + w2 * 0.70 + w3 * 1.40 + w4 * 0.50;
    float scl  = mix(0.60, 3.0, clamp(spread * sprC, 0.0, 1.0));

    return gauss1d(cap, uv, vec2(1.0, 0.0), 2.5 * scl);
}
