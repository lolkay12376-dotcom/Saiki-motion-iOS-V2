// Unmult: removes black. The brightest channel becomes the alpha and the
// colour is divided by it, so the result composited over black equals the
// source (in linear mode) while black areas become fully transparent.
//
// Parameters (macros from plugin.json):
//   amount     - blend between the source and the unmultiplied result
//   blackPoint - key values at or below this become fully transparent
//   gain       - opacity multiplier applied after the black point
//   gammaKey   - 0/1: compute the key in sRGB-encoded space

vec4 aurea_main(vec2 uv) {
    // Linear RGB, premultiplied alpha (colorSpace: linear).
    vec4 src = texture(aurea_source, uv);
    vec3 rgb = max(src.rgb, vec3(0.0));

    const float EPS = 1e-5;
    vec3 straight;
    float key;

    if (gammaKey > 0.5) {
        // Classic look: key in the perceptual (sRGB-encoded) domain.
        vec3 e = aurea_linear_to_srgb(rgb);
        key = max(e.r, max(e.g, e.b));
        float kc = clamp(key, EPS, 1.0);
        straight = aurea_srgb_to_linear(e / kc);
    } else {
        // Physically exact: unmultiplied colour over black == source.
        key = max(rgb.r, max(rgb.g, rgb.b));
        float kc = clamp(key, EPS, 1.0);
        straight = rgb / kc;
    }

    // Shape the opacity: black point (levels) then gain.
    float bp = clamp(blackPoint, 0.0, 0.95);
    float a = clamp((key - bp) / (1.0 - bp) * gain, 0.0, 1.0);

    // Return premultiplied alpha, as the engine expects.
    vec4 result = vec4(straight * a, a);

    return mix(src, result, clamp(amount, 0.0, 1.0));
}
