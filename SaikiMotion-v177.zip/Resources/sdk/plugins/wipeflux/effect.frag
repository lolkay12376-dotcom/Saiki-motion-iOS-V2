vec3 wff_to_srgb(vec3 v) {
    v = max(v, vec3(0.0));
    vec3 lo = v * 12.92;
    vec3 hi = 1.055 * pow(v, vec3(0.4166667)) - vec3(0.055);
    return mix(hi, lo, vec3(lessThan(v, vec3(0.0031308))));
}

vec3 wff_to_linear(vec3 v) {
    v = clamp(v, vec3(0.0), vec3(1.0));
    vec3 lo = v / 12.92;
    vec3 hi = pow((v + vec3(0.055)) / 1.055, vec3(2.4));
    return mix(hi, lo, vec3(lessThan(v, vec3(0.04045))));
}

vec2 wff_hash(vec2 p) {
    return fract(sin(vec2(dot(p, vec2(127.1, 311.7)), dot(p, vec2(269.5, 183.3)))) * 43758.5453);
}

float wff_worley(vec2 p, float sd, float tm) {
    vec2 i = floor(p);
    vec2 fp = fract(p);
    float best = 8.0;
    for (int y = -1; y <= 1; ++y) {
        for (int x = -1; x <= 1; ++x) {
            vec2 g = vec2(float(x), float(y));
            vec2 h = wff_hash(i + g + vec2(sd * 13.0));
            vec2 o = vec2(0.5) + 0.5 * sin(vec2(tm) + 6.2831853 * h);
            vec2 d = g + o - fp;
            best = min(best, dot(d, d));
        }
    }
    return sqrt(best);
}

float wff_key(vec2 q) {
    vec2 p = q * wf_frequency;
    p.x *= wf_freq_relx;
    float tm = aurea.time.x * wf_morph_speed;
    p += wf_bubble_amount * 0.35 * vec2(sin(p.y * 1.7 + tm * 0.7 + wf_seed),
                                        sin(p.x * 1.3 - tm * 0.9 + wf_seed * 2.0));
    float sm = wf_bubble_smooth;
    float norm = sqrt(0.85 * 0.85 + sm * sm) - sm;
    float sum = 0.0;
    float amp = 1.0;
    float tot = 0.0;
    for (int i = 0; i < 4; ++i) {
        if (float(i) >= wf_octaves - 0.5) break;
        float f1 = wff_worley(p, wf_seed + float(i), tm);
        sum += amp * clamp((sqrt(f1 * f1 + sm * sm) - sm) / norm, 0.0, 1.0);
        tot += amp;
        amp *= 0.5;
        p = p * 2.0 + vec2(5.3, 1.7);
    }
    return sum / max(tot, 0.0001);
}

vec4 aurea_main(vec2 uv) {
    vec4 s = texture(aurea_source, uv);
    float big = max(aurea.layer.x, aurea.layer.y);
    vec2 ext = aurea.layer.xy / big;
    vec2 q = (uv - vec2(0.5)) * ext;

    float k = wff_key(q);

    float G = abs(wf_grad_add);
    vec2 gd = vec2(cos(wf_grad_angle), sin(wf_grad_angle));
    float g = clamp(dot(q, gd) / (0.5 * length(ext)) * 0.5 + 0.5, 0.0, 1.0);
    if (wf_grad_add < 0.0) g = 1.0 - g;
    float t = wf_wipe_percent;
    float local = t * (1.0 + G) - G * g;

    float soft = max(wf_edge_softness * 0.25, 0.01);
    float T = mix(-soft, 1.0 + soft, local);
    float diff = T - k;
    float w = smoothstep(-soft, soft, diff);
    float vis = (wf_direction < 0.5) ? 1.0 - w : w;

    vec4 res = s * vis;
    float ad = abs(diff);
    if (wf_border_width > 0.0) {
        float hw = wf_border_width * 0.25;
        float bm = 1.0 - smoothstep(hw, hw + soft, ad);
        res = res * (1.0 - bm) + vec4(wf_border_color.rgb * bm, bm);
    }
    if (wf_border_glow > 0.0) {
        float n = 0.5 + 0.5 * sin(q.x * 16.0 + aurea.time.x * 2.0) * sin(q.y * 16.0 - aurea.time.x * 2.3);
        float gl = exp(-ad / max(wf_glow_width * 0.5, 0.001)) * wf_border_glow * (0.5 + n);
        gl *= step(0.0001, t) * step(t, 0.9999);
        res.rgb += vec3(gl);
        res.a = max(res.a, clamp(gl, 0.0, 1.0));
    }
    return res;
}
