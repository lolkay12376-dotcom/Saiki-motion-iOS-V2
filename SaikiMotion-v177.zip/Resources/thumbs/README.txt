Drop the files from Files > SaikiMotion > ThumbExport here (a_*.jpg and o_*.jpg), then rebuild.
