// EditorAudioFx.swift — "Audio effects" section of the audio layer panel + the custom Equalizer graph.

import UIKit

private enum EqSel { static var band = 2 }

extension EditorViewController {

    /// Audio effects as normal effect rows (handle · icon · name · eye · chevron · more), shown in the Applied tab.
    func buildAudioFxPanel(_ p: UIStackView, _ l: Layer) {
        var rows: [UIView] = [], idxs: [Int] = [], handles: [UIView] = []
        for idx in 0..<l.afx.count {
            let t = l.afx[idx].type
            let key = "\(l.id):afx\(idx)"
            let isOpen = expanded.contains(key)
            let c = vStack()
            let hdr = audioFxHeader(l, idx, key, isOpen)
            handles.append((hdr as? UIStackView)?.arrangedSubviews.first ?? hdr)
            c.addArrangedSubview(hdr)
            if isOpen {
                if t == "eq" {
                    buildEqUi(c, l, idx)
                } else {
                    buildFxCurve(c, l, idx)
                    for d in AFxDefs.params(t) { fxRow(c, l, idx, d) }
                }
                if AFxDefs.hasBlend(t) {
                    fxRow(c, l, idx, AFxParam("blend", "Blend (dry ↔ wet)", 0, 1, AFxDefs.defaultBlend(t), 2))
                }
            }
            let pr = put(p, c, 0, 3, 6)
            rows.append(pr.superview ?? pr); idxs.append(idx)
        }
        if rows.count > 1 {
            for (n, h) in handles.enumerated() {
                let pan = ClosurePan()
                pan.cb = { [weak self] g in
                    self?.dragFx(l, g, n, rows, idxs) { a, b in let e = l.afx.remove(at: a); l.afx.insert(e, at: b); self?.audioFxChanged() }
                }
                h.addGestureRecognizer(pan)
            }
        }
    }

    /// Writes one parameter through its keyframe track: edits the value, or adds a key at the playhead when the parameter is animated / auto-key is on.
    func afxSet(_ l: Layer, _ idx: Int, _ k: String, _ v: Float) {
        guard idx < l.afx.count else { return }
        let key = l.afxKey(l.afx[idx], k)
        let tr = l.track(key)
        tr.set(Editor.time, v, autoKeyOn)
        if tr.keys.isEmpty {
            tr.base = v
            if k == "blend" { l.afx[idx].blend = v } else { l.afx[idx].p[k] = v }
        }
        audioFxChanged()
    }

    /// The curve picture of an effect; dragging its dot edits two parameters at once.
    private func buildFxCurve(_ p: UIStackView, _ l: Layer, _ idx: Int) {
        let it = l.afxAt(l.afx[idx], Editor.time)
        let cv = AudioFxCurveView(frame: .zero)
        cv.type = it.type
        cv.item = it
        cv.onBegin = { [weak self] in self?.pushUndo() }
        cv.onDrag = { [weak self] xk, xv, yk, yv in
            guard let self = self else { return }
            self.afxSet(l, idx, xk, xv); self.afxSet(l, idx, yk, yv)
            self.syncRows()
        }
        let kx = AudioFxCurveView.handleKeys(it.type)
        let trs: [Track] = [kx?.0, kx?.1].compactMap { $0 }.map { l.track(l.afxKey(l.afx[idx], $0)) }
        cv.keyed = !trs.isEmpty && trs.allSatisfy { $0.keyAt(Editor.time) != nil }
        put(p, cv, 170)
        if let kx = kx {
            put(p, pill(cv.keyed ? "Remove curve keyframe" : "Keyframe curve here", "diamond") { [weak self] in
                guard let self = self else { return }
                self.pushUndo()
                let t = Editor.time
                for k in [kx.0, kx.1] {
                    let tr = l.track(l.afxKey(l.afx[idx], k))
                    let cur = tr.eval(t)
                    if tr.base != cur && tr.keys.isEmpty { tr.base = cur }
                    if cv.keyed { if tr.keyAt(t) != nil { tr.toggleKey(t) }; if tr.keys.isEmpty { tr.base = cur; l.afx[idx].p[k] = cur } }
                    else if tr.keyAt(t) == nil { tr.toggleKey(t) }
                }
                self.audioFxChanged(); self.refreshPanel()
            }, 38)
        }
        if let h = AudioFxCurveView.handleKeys(it.type) {
            let nx = AFxDefs.params(it.type).first { $0.key == h.0 }?.label ?? "", ny = AFxDefs.params(it.type).first { $0.key == h.1 }?.label ?? ""
            text(p, "Drag the dot: ← → \(nx), ↑ ↓ \(ny). Tap a parameter name, then the diamond, to keyframe it.", C.DIM, 12)
        }
    }

    private func audioFxHeader(_ l: Layer, _ idx: Int, _ key: String, _ isOpen: Bool) -> UIView {
        let bar = hRow()
        bar.backgroundColor = argbToUIColor(C.CARD)
        bar.isLayoutMarginsRelativeArrangement = true
        bar.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 14, bottom: 0, trailing: 2)
        bar.addArrangedSubview(wrap(IconView("handle", C.DIM, 20), 36, 48, 0, 0, 0, 0))
        bar.addArrangedSubview(wrap(IconView("afx_\(l.afx[idx].type)", C.GREEN, 22), 30, 48, 0, 0, 0, 0))
        let t = UILabel()
        t.text = AFxDefs.name(l.afx[idx].type)
        t.textColor = argbToUIColor(C.TEXT)
        t.font = boldFont(16)
        t.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
        bar.addArrangedSubview(t)
        let off = !l.afx[idx].on
        let eye = IconView(off ? "eye_off" : "eye", off ? C.DIM : C.GREEN, 20)
        eye.onClick = { [weak self] in
            guard let self = self, idx < l.afx.count else { return }
            self.pushUndo(); l.afx[idx].on.toggle(); self.audioFxChanged(); self.refreshPanel()
        }
        bar.addArrangedSubview(wrap(eye, 40, 48, 0, 0, 0, 0))
        let chev = IconView(isOpen ? "chev_up" : "chev_down", C.DIM, 20)
        chev.onClick = { [weak self] in
            guard let self = self else { return }
            if self.expanded.contains(key) { self.expanded.remove(key) } else { self.expanded.insert(key) }
            self.refreshPanel()
        }
        bar.addArrangedSubview(wrap(chev, 40, 48, 0, 0, 0, 0))
        let more = IconView("more", C.TEXT, 20)
        more.onClick = { [weak self] in
            guard let self = self else { return }
            Dlg(self).setTitle(AFxDefs.name(l.afx[idx].type)).setIconItems(["Duplicate", "Reset to default", "Remove"], ["dup", "adjust", "trash"]) { [weak self] _, w in
                guard let self = self, idx < l.afx.count else { return }
                self.pushUndo()
                let old = l.afx[idx]
                switch w {
                case 0:
                    var n = old; n.uid = AudioFxItem.newUid()
                    l.afxCopyTracks(from: old.uid, to: n.uid)
                    l.afx.insert(n, at: idx + 1)
                case 1:
                    l.afxDropTracks(old.uid)
                    var n = AudioFxItem(type: old.type); n.uid = old.uid
                    l.afx[idx] = n
                default:
                    l.afxDropTracks(old.uid)
                    l.afx.remove(at: idx)
                }
                self.audioFxChanged(); self.refreshPanel()
            }.show()
        }
        bar.addArrangedSubview(wrap(more, 40, 48, 0, 0, 0, 0))
        return bar
    }

    /// One effect parameter as a normal keyframable row (name tap → graph, diamond → key, auto-key aware).
    private func fxRow(_ p: UIStackView, _ l: Layer, _ idx: Int, _ d: AFxParam) {
        guard idx < l.afx.count else { return }
        let it = l.afx[idx]
        let key = l.afxKey(it, d.key)
        let pd = PropDef(key, d.label, d.lo, d.hi, d.def, d.dec)
        Registry.dyn[key] = pd
        let tr: Track
        if let t = l.props[key] { tr = t } else { tr = Track(d.key == "blend" ? it.blend : it.v(d.key)); l.props[key] = tr }
        if tr.keys.isEmpty { tr.base = d.key == "blend" ? it.blend : it.v(d.key) }
        if let opts = d.options {
            text(p, d.label, C.DIM, 12)
            let cur = Int(tr.eval(Editor.time).rounded())
            p.addArrangedSubview(chipRow(opts, cur) { [weak self] i in
                guard let self = self else { return }
                self.pushUndo(); self.afxSet(l, idx, d.key, Float(i)); self.refreshPanel()
            })
            let has = tr.keyAt(Editor.time) != nil
            put(p, pill(has ? "Remove \(d.label) keyframe" : "Keyframe \(d.label) here", "diamond") { [weak self] in
                guard let self = self else { return }
                self.pushUndo()
                let cur = tr.eval(Editor.time)
                tr.toggleKey(Editor.time)
                if tr.keys.isEmpty { tr.base = cur; l.afx[idx].p[d.key] = cur }
                self.audioFxChanged(); self.refreshPanel()
            }, 36)
            return
        }
        let s = RulerSlider(frame: .zero)
        s.label = d.label; s.lo = d.lo; s.hi = d.hi; s.dec = d.dec
        s.value = tr.eval(Editor.time)
        s.onBegin = { [weak self] in
            guard let self = self else { return }
            self.pushUndo(); self.selKey = key; self.syncRows(s)
        }
        s.onChange = { [weak self] v in
            guard let self = self else { return }
            self.afxSet(l, idx, d.key, v)
            self.syncRows(s)
        }
        s.onLabelTap = { [weak self] in
            guard let self = self else { return }
            self.selKey = key
            self.syncRows()
            if tr.keys.count >= 2 { self.graphProp = key; self.graphKey = 0; self.openPanel(P_GRAPH) }
            else { self.toast("Tap the diamond to keyframe \(d.label); add 2 keys to edit its graph") }
        }
        put(p, s, 60)
        rows.append(Row(s, pd, l))
    }

    private func buildEqUi(_ p: UIStackView, _ l: Layer, _ idx: Int) {
        let eq = AudioEqView(frame: .zero)
        eq.item = l.afxAt(l.afx[idx], Editor.time)
        eq.selected = EqSel.band
        eq.onBegin = { [weak self] in self?.pushUndo() }
        eq.onChange = { [weak self] it in
            guard let self = self, idx < l.afx.count else { return }
            let cur = l.afxAt(l.afx[idx], Editor.time)
            for (k, v) in it.p where abs(v - cur.v(k)) > 1e-6 { self.afxSet(l, idx, k, v) }
            self.syncRows()
        }
        eq.onSelect = { [weak self] b in EqSel.band = b; self?.refreshPanel() }
        put(p, eq, 230)
        text(p, "Drag a dot: left/right = frequency, up/down = gain. Tap a dot to pick it, double-tap to flatten it.", C.DIM, 12)
        let b = max(0, min(4, EqSel.band))
        for k in ["q\(b)", "f\(b)", "g\(b)"] {
            if let d = AFxDefs.params("eq").first(where: { $0.key == k }) { fxRow(p, l, idx, d) }
        }
        if let d = AFxDefs.params("eq").first(where: { $0.key == "out" }) { fxRow(p, l, idx, d) }
        put(p, pill("Reset equalizer") { [weak self] in
            guard let self = self, idx < l.afx.count else { return }
            self.pushUndo()
            let u = l.afx[idx].uid; l.afxDropTracks(u)
            var n = AudioFxItem(type: "eq"); n.uid = u; l.afx[idx] = n
            self.audioFxChanged(); self.refreshPanel()
        }, 40)
    }
}

/// Custom equalizer: log-frequency / gain graph with 5 draggable band dots and the live combined response curve.
final class AudioEqView: UIView {
    var item = AudioFxItem(type: "eq") { didSet { setNeedsDisplay() } }
    var selected = 2
    var onBegin: (() -> Void)?
    var onChange: ((AudioFxItem) -> Void)?
    var onSelect: ((Int) -> Void)?

    private var drag = -1
    private let fMin: Float = 20, fMax: Float = 20000, gMax: Float = 18
    private let bandColors: [UIColor] = [.systemRed, .systemOrange, .systemGreen, .systemTeal, .systemPurple]

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        isOpaque = false
        let pan = UIPanGestureRecognizer(target: self, action: #selector(onPan(_:)))
        addGestureRecognizer(pan)
        let dbl = UITapGestureRecognizer(target: self, action: #selector(onDouble(_:)))
        dbl.numberOfTapsRequired = 2
        addGestureRecognizer(dbl)
        let tap = UITapGestureRecognizer(target: self, action: #selector(onTap(_:)))
        tap.require(toFail: dbl)
        addGestureRecognizer(tap)
    }
    required init?(coder: NSCoder) { fatalError() }

    private var plot: CGRect { bounds.insetBy(dx: 10, dy: 14) }
    private func xFor(_ f: Float) -> CGFloat { plot.minX + CGFloat(log(f / fMin) / log(fMax / fMin)) * plot.width }
    private func fFor(_ x: CGFloat) -> Float { fMin * pow(fMax / fMin, Float((x - plot.minX) / plot.width)) }
    private func yFor(_ g: Float) -> CGFloat { plot.midY - CGFloat(g / gMax) * plot.height / 2 }
    private func gFor(_ y: CGFloat) -> Float { Float((plot.midY - y) / (plot.height / 2)) * gMax }

    private func nearest(_ pt: CGPoint) -> Int {
        var best = -1, bd = CGFloat(44 * 44)
        for i in 0..<5 {
            let dx = xFor(item.v("f\(i)")) - pt.x, dy = yFor(item.v("g\(i)")) - pt.y
            let d = dx * dx + dy * dy
            if d < bd { bd = d; best = i }
        }
        return best
    }

    @objc private func onTap(_ g: UITapGestureRecognizer) {
        let i = nearest(g.location(in: self))
        if i >= 0 { selected = i; setNeedsDisplay(); onSelect?(i) }
    }
    @objc private func onDouble(_ g: UITapGestureRecognizer) {
        let i = nearest(g.location(in: self))
        guard i >= 0 else { return }
        onBegin?(); item.p["g\(i)"] = 0; selected = i; onChange?(item); onSelect?(i)
    }
    @objc private func onPan(_ g: UIPanGestureRecognizer) {
        let pt = g.location(in: self)
        switch g.state {
        case .began:
            drag = nearest(pt)
            if drag >= 0 { onBegin?(); selected = drag }
        case .changed:
            guard drag >= 0 else { return }
            item.p["f\(drag)"] = min(fMax, max(fMin, fFor(pt.x)))
            item.p["g\(drag)"] = min(gMax, max(-gMax, gFor(pt.y)))
            onChange?(item)
        case .ended, .cancelled:
            if drag >= 0 { onSelect?(drag) }
            drag = -1
        default: break
        }
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let r = bounds
        c.setFillColor(argbToUIColor(C.CARD2).cgColor)
        UIBezierPath(roundedRect: r, cornerRadius: 12).fill()
        let pl = plot
        // grid
        c.setStrokeColor(UIColor.white.withAlphaComponent(0.10).cgColor); c.setLineWidth(1)
        for f in [50, 100, 200, 500, 1000, 2000, 5000, 10000] as [Float] {
            c.move(to: CGPoint(x: xFor(f), y: pl.minY)); c.addLine(to: CGPoint(x: xFor(f), y: pl.maxY))
        }
        for g in [-12, -6, 6, 12] as [Float] { c.move(to: CGPoint(x: pl.minX, y: yFor(g))); c.addLine(to: CGPoint(x: pl.maxX, y: yFor(g))) }
        c.strokePath()
        c.setStrokeColor(UIColor.white.withAlphaComponent(0.30).cgColor)
        c.move(to: CGPoint(x: pl.minX, y: yFor(0))); c.addLine(to: CGPoint(x: pl.maxX, y: yFor(0))); c.strokePath()
        let lab: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 9), .foregroundColor: UIColor.white.withAlphaComponent(0.45)]
        for (f, s) in [(100, "100"), (1000, "1k"), (10000, "10k")] as [(Float, String)] { (s as NSString).draw(at: CGPoint(x: xFor(f) + 2, y: pl.maxY - 11), withAttributes: lab) }
        for g in [12, 0, -12] as [Float] { ("\(Int(g))" as NSString).draw(at: CGPoint(x: pl.minX + 2, y: yFor(g) - 11), withAttributes: lab) }

        // combined response
        let sr: Float = 44100
        var bq: [Biquad] = []
        for i in 0..<5 {
            let k: Biquad.Kind = i == 0 ? .lowShelf : (i == 4 ? .highShelf : .peak)
            bq.append(Biquad(k, f: item.v("f\(i)"), q: item.v("q\(i)"), gainDb: item.v("g\(i)"), sr: sr))
        }
        let path = UIBezierPath()
        let n = 160
        for s in 0...n {
            let x = pl.minX + pl.width * CGFloat(s) / CGFloat(n)
            var db: Float = item.v("out")
            for b in bq { db += b.magnitudeDb(fFor(x), sr: sr) }
            let pt = CGPoint(x: x, y: min(pl.maxY, max(pl.minY, yFor(db))))
            if s == 0 { path.move(to: pt) } else { path.addLine(to: pt) }
        }
        let fill = path.copy() as! UIBezierPath
        fill.addLine(to: CGPoint(x: pl.maxX, y: yFor(0))); fill.addLine(to: CGPoint(x: pl.minX, y: yFor(0))); fill.close()
        argbToUIColor(C.GREEN).withAlphaComponent(0.18).setFill(); fill.fill()
        argbToUIColor(C.GREEN).setStroke(); path.lineWidth = 2.5; path.lineJoinStyle = .round; path.stroke()

        // band dots
        for i in 0..<5 {
            let p = CGPoint(x: xFor(item.v("f\(i)")), y: yFor(item.v("g\(i)")))
            let rad: CGFloat = i == selected ? 13 : 10
            bandColors[i].withAlphaComponent(i == selected ? 0.35 : 0.2).setFill()
            UIBezierPath(ovalIn: CGRect(x: p.x - rad - 5, y: p.y - rad - 5, width: (rad + 5) * 2, height: (rad + 5) * 2)).fill()
            bandColors[i].setFill()
            UIBezierPath(ovalIn: CGRect(x: p.x - rad, y: p.y - rad, width: rad * 2, height: rad * 2)).fill()
            UIColor.white.setStroke(); let ring = UIBezierPath(ovalIn: CGRect(x: p.x - rad, y: p.y - rad, width: rad * 2, height: rad * 2)); ring.lineWidth = i == selected ? 2.5 : 1.2; ring.stroke()
            ("\(i + 1)" as NSString).draw(at: CGPoint(x: p.x - 3, y: p.y - 6),
                withAttributes: [.font: UIFont.boldSystemFont(ofSize: 11), .foregroundColor: UIColor.white])
        }
        // readout of the selected band
        let b = max(0, min(4, selected))
        let f = item.v("f\(b)"), g = item.v("g\(b)")
        let fs = f >= 1000 ? String(format: "%.2f kHz", f / 1000) : String(format: "%.0f Hz", f)
        let txt = "\(AFxDefs.eqNames[b])  \(fs)  \(String(format: "%+.1f dB", g))  Q \(String(format: "%.2f", item.v("q\(b)")))"
        (txt as NSString).draw(at: CGPoint(x: pl.minX + 6, y: pl.minY - 2),
            withAttributes: [.font: UIFont.boldSystemFont(ofSize: 11), .foregroundColor: UIColor.white.withAlphaComponent(0.85)])
    }
}

/// Browse card for an audio effect (same look as the visual effect cards, with an audio icon instead of a preview).
final class AudioFxCard: TapView {
    var badge = false { didSet { setNeedsLayout() } }
    init(_ name: String, icon: String = "audio") {
        super.init(frame: .zero)
        backgroundColor = argbToUIColor(C.CARD)
        layer.cornerRadius = 14
        clipsToBounds = true
        let ic = IconView(icon, C.GREEN, 48)
        ic.isUserInteractionEnabled = false
        ic.translatesAutoresizingMaskIntoConstraints = false
        addSubview(ic)
        let t = UILabel(); t.text = name; t.textColor = argbToUIColor(C.TEXT); t.font = boldFont(16)
        let c = UILabel(); c.text = "Audio"; c.textColor = argbToUIColor(C.DIM); c.font = sysFont(13)
        let st = UIStackView(arrangedSubviews: [t, c]); st.axis = .vertical; st.spacing = 2
        st.translatesAutoresizingMaskIntoConstraints = false
        addSubview(st)
        NSLayoutConstraint.activate([
            ic.centerXAnchor.constraint(equalTo: centerXAnchor), ic.topAnchor.constraint(equalTo: topAnchor, constant: 26),
            ic.widthAnchor.constraint(equalToConstant: 48), ic.heightAnchor.constraint(equalToConstant: 48),
            st.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16), st.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -12),
            st.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -16),
        ])
    }
    required init?(coder: NSCoder) { fatalError() }
}

/// Picture of what an effect does, redrawn live: comb response (flanger), notches (phaser), LFO voices (chorus), waveform (modulator),
/// auto-pan path, reverb decay, filter / tilt response, echo taps, distortion transfer curve, compressor transfer curve.
/// One draggable dot edits the two most important parameters at once.
final class AudioFxCurveView: UIView {
    var type = "flanger"
    var item = AudioFxItem(type: "flanger") { didSet { setNeedsDisplay() } }
    var keyed = false { didSet { setNeedsDisplay() } }
    var onBegin: (() -> Void)?
    var onDrag: ((String, Float, String, Float) -> Void)?

    static func handleKeys(_ t: String) -> (String, String)? {
        switch t {
        case "flanger": return ("delay", "fb")
        case "chorus": return ("rate", "depth")
        case "phaser": return ("freq", "depth")
        case "modulator": return ("freq", "depth")
        case "pan": return ("pan", "depth")
        case "reverb": return ("room", "damp")
        case "muffle": return ("cut", "res")
        case "tone": return ("pivot", "tone")
        case "echo": return ("time", "fb")
        case "dist": return ("tone", "drive")
        case "comp": return ("thresh", "ratio")
        case "wah": return ("freq", "depth")
        case "crush": return ("rate", "bits")
        default: return nil
        }
    }

    private var plot: CGRect { bounds.insetBy(dx: 12, dy: 16) }
    private let accent = argbToUIColor(C.GREEN)

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear; isOpaque = false
        addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(onPan(_:))))
    }
    required init?(coder: NSCoder) { fatalError() }

    // value <-> 0…1 mapping (log for wide positive ranges such as Hz / ms / ratio)
    private func def(_ k: String) -> AFxParam? { AFxDefs.params(type).first { $0.key == k } }
    private func isLog(_ d: AFxParam) -> Bool { d.lo > 0 && d.hi / d.lo >= 15 }
    private func norm(_ d: AFxParam, _ v: Float) -> CGFloat {
        let x = min(max(v, d.lo), d.hi)
        return isLog(d) ? CGFloat(log(x / d.lo) / log(d.hi / d.lo)) : CGFloat((x - d.lo) / (d.hi - d.lo))
    }
    private func denorm(_ d: AFxParam, _ u: CGFloat) -> Float {
        let c = Float(min(max(u, 0), 1))
        return isLog(d) ? d.lo * pow(d.hi / d.lo, c) : d.lo + (d.hi - d.lo) * c
    }
    private func handlePoint() -> CGPoint? {
        guard let h = Self.handleKeys(type), let dx = def(h.0), let dy = def(h.1) else { return nil }
        return CGPoint(x: plot.minX + norm(dx, item.v(h.0)) * plot.width, y: plot.maxY - norm(dy, item.v(h.1)) * plot.height)
    }

    @objc private func onPan(_ g: UIPanGestureRecognizer) {
        guard let h = Self.handleKeys(type), let dx = def(h.0), let dy = def(h.1) else { return }
        if g.state == .began { onBegin?() }
        guard g.state == .began || g.state == .changed else { return }
        let pt = g.location(in: self), p = plot
        let xv = denorm(dx, (pt.x - p.minX) / p.width), yv = denorm(dy, (p.maxY - pt.y) / p.height)
        item.p[h.0] = xv; item.p[h.1] = yv
        onDrag?(h.0, xv, h.1, yv)
    }

    // ---------------------------------------------------------------- drawing helpers
    private func pts(_ n: Int, _ f: (CGFloat) -> CGFloat) -> [CGPoint] {
        let p = plot
        return (0...n).map { i in
            let u = CGFloat(i) / CGFloat(n)
            return CGPoint(x: p.minX + u * p.width, y: p.maxY - min(max(f(u), -0.04), 1.04) * p.height)
        }
    }
    private func curve(_ pt: [CGPoint], _ col: UIColor, _ w: CGFloat = 2.5, fill: Bool = false) {
        guard let f = pt.first else { return }
        let b = UIBezierPath(); b.move(to: f)
        for q in pt.dropFirst() { b.addLine(to: q) }
        if fill, let last = pt.last {
            let c = b.copy() as! UIBezierPath
            c.addLine(to: CGPoint(x: last.x, y: plot.maxY)); c.addLine(to: CGPoint(x: f.x, y: plot.maxY)); c.close()
            col.withAlphaComponent(0.16).setFill(); c.fill()
        }
        col.setStroke(); b.lineWidth = w; b.lineJoinStyle = .round; b.stroke()
    }
    private func grid(_ vx: Int, _ hy: Int) {
        let p = plot, path = UIBezierPath()
        for i in 0...vx { let x = p.minX + p.width * CGFloat(i) / CGFloat(vx); path.move(to: CGPoint(x: x, y: p.minY)); path.addLine(to: CGPoint(x: x, y: p.maxY)) }
        for i in 0...hy { let y = p.minY + p.height * CGFloat(i) / CGFloat(hy); path.move(to: CGPoint(x: p.minX, y: y)); path.addLine(to: CGPoint(x: p.maxX, y: y)) }
        UIColor.white.withAlphaComponent(0.08).setStroke(); path.lineWidth = 1; path.stroke()
    }
    private func label(_ s: String, _ pt: CGPoint, _ a: CGFloat = 0.5) {
        (s as NSString).draw(at: pt, withAttributes: [.font: UIFont.systemFont(ofSize: 9), .foregroundColor: UIColor.white.withAlphaComponent(a)])
    }
    private func fmt(_ k: String) -> String { String(format: "%.\(def(k)?.dec ?? 2)f", item.v(k)) }

    private func cmul(_ a: (Float, Float), _ b: (Float, Float)) -> (Float, Float) { (a.0 * b.0 - a.1 * b.1, a.0 * b.1 + a.1 * b.0) }

    // ---------------------------------------------------------------- the pictures
    override func draw(_ rect: CGRect) {
        guard let ctx = UIGraphicsGetCurrentContext() else { return }
        ctx.setFillColor(argbToUIColor(C.CARD2).cgColor)
        UIBezierPath(roundedRect: bounds, cornerRadius: 12).fill()
        let a = accent, dim = accent.withAlphaComponent(0.35)
        let sr: Float = 44100

        switch type {
        case "flanger":
            grid(5, 4)
            let d0 = item.v("delay"), dp = item.v("depth"), fb = item.v("fb")
            func resp(_ dMs: Float) -> (CGFloat) -> CGFloat {
                return { u in
                    let th = 2 * Float.pi * Float(u) * 10000 * dMs * 0.001
                    let c = cos(th), s = sin(th)
                    let dr = 1 - fb * c, di = fb * s, q = max(dr * dr + di * di, 1e-6)
                    let re = 1 + (c * dr - s * di) / q, im = (-s * dr - c * di) / q
                    return CGFloat((10 * log10(max(re * re + im * im, 1e-4)) + 30) / 42)
                }
            }
            curve(pts(260, resp(d0)), dim, 1.5); curve(pts(260, resp(d0 + dp)), dim, 1.5)
            curve(pts(260, resp(d0 + dp * 0.5)), a, 2.5, fill: true)
            label("0", CGPoint(x: plot.minX + 2, y: plot.maxY - 10)); label("5 kHz", CGPoint(x: plot.midX, y: plot.maxY - 10)); label("10 kHz", CGPoint(x: plot.maxX - 30, y: plot.maxY - 10))

        case "phaser":
            grid(4, 4)
            let fc = item.v("freq"), dp = item.v("depth"), ns = max(2, Int(item.v("stages").rounded()))
            func resp(_ c: Float) -> (CGFloat) -> CGFloat {
                return { [self] u in
                    let f = 40 * pow(16000 / 40, Float(u)), w = 2 * Float.pi * f / sr
                    let z: (Float, Float) = (cos(w), -sin(w))
                    var P: (Float, Float) = (1, 0)
                    for s in 0..<ns {
                        let fs = min(sr * 0.45, c * exp2(AFxPhaser.stagger(s))), t = tan(Float.pi * fs / sr), aa = (1 - t) / (1 + t)
                        let num: (Float, Float) = (aa + z.0, z.1), den: (Float, Float) = (1 + aa * z.0, aa * z.1)
                        let dd = max(den.0 * den.0 + den.1 * den.1, 1e-9)
                        let q: (Float, Float) = ((num.0 * den.0 + num.1 * den.1) / dd, (num.1 * den.0 - num.0 * den.1) / dd)
                        P = cmul(P, q)
                    }
                    let re = 0.5 * (1 + P.0), im = 0.5 * P.1
                    return CGFloat((10 * log10(max(re * re + im * im, 1e-5)) + 40) / 43)
                }
            }
            let sw = exp2(2.5 * dp)
            curve(pts(240, resp(max(30, fc / sw))), dim, 1.5); curve(pts(240, resp(min(sr * 0.4, fc * sw))), dim, 1.5)
            curve(pts(240, resp(fc)), a, 2.5, fill: true)
            label("100", CGPoint(x: plot.minX + plot.width * 0.17, y: plot.maxY - 10)); label("1k", CGPoint(x: plot.minX + plot.width * 0.46, y: plot.maxY - 10)); label("10k", CGPoint(x: plot.minX + plot.width * 0.83, y: plot.maxY - 10))

        case "chorus":
            grid(4, 4)
            let dy = item.v("delay"), dp = item.v("depth"), nv = item.v("voices")
            for v in 0..<4 {
                let vg = min(max(nv - Float(v), 0), 1)
                if vg <= 0.01 { continue }
                let base: Float = dy * (1 + 0.12 * Float(v)), off: Float = Float(v) / 4
                let line = pts(120) { (u: CGFloat) -> CGFloat in
                    let m: Float = 0.5 + 0.5 * sin(2 * Float.pi * (Float(u) * 2 + off))
                    return CGFloat((base + dp * m) / 62)
                }
                curve(line, a.withAlphaComponent(0.25 + 0.75 * CGFloat(vg)), v == 0 ? 2.8 : 1.8)
            }
            label("delay time of each voice (0–60 ms)", CGPoint(x: plot.minX + 4, y: plot.minY - 2))

        case "modulator":
            grid(4, 4)
            let w = Int(item.v("wave").rounded()), mode = Int(item.v("mode").rounded()), d = item.v("depth")
            curve(pts(260) { u in
                let m = afxLfo(Float(u * 2).truncatingRemainder(dividingBy: 1), w)
                let g = mode == 0 ? (1 - d) + d * m : 1 - d * (0.5 - 0.5 * m)
                return CGFloat((g + 1) / 2)
            }, a, 2.5, fill: true)
            label("gain", CGPoint(x: plot.minX + 4, y: plot.minY - 2))

        case "pan":
            grid(4, 4)
            let pn = item.v("pan"), rt = item.v("rate"), dp = item.v("depth")
            curve(pts(200) { u in
                let p = min(max(pn + min(rt * 20, 1) * dp * sin(2 * Float.pi * Float(u) * 2), -1), 1)
                return CGFloat((p + 1) / 2)
            }, a, 2.5)
            label("R", CGPoint(x: plot.minX + 4, y: plot.minY - 2)); label("L", CGPoint(x: plot.minX + 4, y: plot.maxY - 10))

        case "reverb":
            grid(4, 4)
            let fbk = item.v("room") * 0.28 + 0.7, pre = item.v("pre") * 0.001, dmp = item.v("damp")
            let rt = 60 / max(-20 * log10(fbk), 0.05) * 0.0295
            let tmax = max(1, (rt + pre) * 1.1)
            func env(_ r: Float) -> (CGFloat) -> CGFloat {
                return { u in let t = Float(u) * tmax - pre; return t < 0 ? 1 : CGFloat(max(0, 1 - t / max(r, 0.05)) )}
            }
            curve(pts(80, env(rt * (1 - 0.6 * dmp))), dim, 1.5)           // high frequencies die sooner when damped
            curve(pts(80, env(rt)), a, 2.5, fill: true)
            label(String(format: "RT60 ≈ %.1f s", rt), CGPoint(x: plot.minX + 4, y: plot.minY - 2), 0.8)

        case "muffle":
            grid(4, 4)
            let cut = item.v("cut"), res = item.v("res"), two = item.v("slope") > 0.5
            let b1 = Biquad(.lowpass, f: cut, q: res, gainDb: 0, sr: sr), b2 = Biquad(.lowpass, f: cut, q: 0.707, gainDb: 0, sr: sr)
            curve(pts(200) { u in
                let f = 20 * pow(1000, Float(u))
                return CGFloat((b1.magnitudeDb(f, sr: sr) + (two ? b2.magnitudeDb(f, sr: sr) : 0) + 48) / 60)
            }, a, 2.5, fill: true)
            label("100", CGPoint(x: plot.minX + plot.width * 0.23, y: plot.maxY - 10)); label("1k", CGPoint(x: plot.minX + plot.width * 0.56, y: plot.maxY - 10)); label("10k", CGPoint(x: plot.minX + plot.width * 0.89, y: plot.maxY - 10))

        case "tone":
            grid(4, 4)
            let t = item.v("tone"), pv = item.v("pivot"), lv = item.v("level")
            let b1 = Biquad(.lowShelf, f: pv, q: 0.7, gainDb: -t * 12, sr: sr), b2 = Biquad(.highShelf, f: pv, q: 0.7, gainDb: t * 12, sr: sr)
            curve(pts(200) { u in
                let f = 20 * pow(1000, Float(u))
                return CGFloat((b1.magnitudeDb(f, sr: sr) + b2.magnitudeDb(f, sr: sr) + lv + 18) / 36)
            }, a, 2.5, fill: true)

        case "echo":
            grid(8, 2)
            let T = item.v("time"), fb = item.v("fb")
            let span: Float = 3000
            func bar(_ x: Float, _ h: Float, _ col: UIColor, _ w: CGFloat) {
                let px = plot.minX + CGFloat(x / span) * plot.width
                col.setStroke(); let b = UIBezierPath(); b.move(to: CGPoint(x: px, y: plot.maxY)); b.addLine(to: CGPoint(x: px, y: plot.maxY - CGFloat(h) * plot.height)); b.lineWidth = w; b.lineCapStyle = .round; b.stroke()
            }
            bar(0, 1, UIColor.white.withAlphaComponent(0.7), 4)
            var k = 1
            while k < 60 { let x = Float(k) * T, h = pow(fb, Float(k)); if x > span || h < 0.02 { break }; bar(x, h, a, 4); k += 1 }
            label("0", CGPoint(x: plot.minX + 2, y: plot.maxY - 10)); label("3 s", CGPoint(x: plot.maxX - 18, y: plot.maxY - 10))

        case "dist":
            grid(4, 4)
            let dr = pow(10, item.v("drive") / 20), sh = Int(item.v("shape").rounded()), lv = pow(10, item.v("level") / 20)
            curve(pts(200) { u in
                let x = (Float(u) * 2 - 1) * dr
                var y: Float
                switch sh {
                case 1: y = max(-1, min(1, x))
                case 2: y = x; var k = 0; while abs(y) > 1 && k < 6 { y = y > 1 ? 2 - y : (y < -1 ? -2 - y : y); k += 1 }
                default: y = tanh(x)
                }
                return CGFloat((y * lv + 1) / 2)
            }, a, 2.5)
            label("in → out", CGPoint(x: plot.minX + 4, y: plot.minY - 2))

        case "wah":
            grid(4, 4)
            let fc = item.v("freq"), dp = item.v("depth"), q = max(0.3, item.v("res"))
            func resp(_ c: Float) -> (CGFloat) -> CGFloat {
                return { u in
                    let x = 40 * pow(16000 / 40, Float(u)) / c
                    let m = (x / q) / max(((1 - x * x) * (1 - x * x) + (x / q) * (x / q)).squareRoot(), 1e-6)
                    return CGFloat((20 * log10(max(m, 1e-3)) + 36) / 42)
                }
            }
            let sw = exp2(2.5 * dp)
            curve(pts(200, resp(max(30, fc / sw))), dim, 1.5); curve(pts(200, resp(fc * sw)), dim, 1.5)
            curve(pts(200, resp(fc)), a, 2.5, fill: true)
            label("100", CGPoint(x: plot.minX + plot.width * 0.17, y: plot.maxY - 10)); label("1k", CGPoint(x: plot.minX + plot.width * 0.46, y: plot.maxY - 10)); label("10k", CGPoint(x: plot.minX + plot.width * 0.83, y: plot.maxY - 10))

        case "crush":
            grid(4, 4)
            let bt = item.v("bits"), rt = item.v("rate")
            let lv = pow(2, max(bt, 1) - 1)
            curve(pts(2) { u in CGFloat(u) }, dim, 1.2)
            curve(pts(240) { u in
                let x = Float(u) * 2 - 1
                let y = max(-1, min(1, (x * lv).rounded() / lv))
                return CGFloat((y + 1) / 2)
            }, a, 2.5)
            label(String(format: "%.1f bit  ·  %.0f Hz", bt, rt), CGPoint(x: plot.maxX - 90, y: plot.minY - 2), 0.8)

        case "comp":
            grid(6, 6)
            let T = item.v("thresh"), R = max(1, item.v("ratio")), W = item.v("knee"), mk = item.v("makeup")
            let lo: Float = -60, hi: Float = 12
            func out(_ x: Float) -> Float {
                let o = x - T
                var y = x
                if W < 0.01 { if o > 0 { y = T + o / R } }
                else if 2 * o > W { y = T + o / R }
                else if 2 * abs(o) <= W { let q = o + W / 2; y = x + (1 / R - 1) * q * q / (2 * W) }
                return y + mk
            }
            curve(pts(2) { u in CGFloat(Float(u) * 60 / (hi - lo)) }, dim, 1.2)          // 1:1 reference
            curve(pts(160) { u in CGFloat((out(lo + Float(u) * 60) - lo) / (hi - lo)) }, a, 2.5)
            let tx = plot.minX + CGFloat((T - lo) / 60) * plot.width
            UIColor.white.withAlphaComponent(0.25).setStroke()
            let dl = UIBezierPath(); dl.move(to: CGPoint(x: tx, y: plot.minY)); dl.addLine(to: CGPoint(x: tx, y: plot.maxY)); dl.setLineDash([3, 3], count: 2, phase: 0); dl.stroke()
            label("in (dB)", CGPoint(x: plot.maxX - 34, y: plot.maxY - 10)); label("out", CGPoint(x: plot.minX + 4, y: plot.minY - 2))

        default: break
        }

        if keyed {                                  // diamond = this moment is keyframed
            let c = CGPoint(x: bounds.maxX - 18, y: 16), d = UIBezierPath()
            d.move(to: CGPoint(x: c.x, y: c.y - 7)); d.addLine(to: CGPoint(x: c.x + 7, y: c.y)); d.addLine(to: CGPoint(x: c.x, y: c.y + 7)); d.addLine(to: CGPoint(x: c.x - 7, y: c.y)); d.close()
            accent.setFill(); d.fill()
        }
        // readout + draggable dot
        if let h = Self.handleKeys(type), let pt = handlePoint() {
            let txt = "\(def(h.0)?.label ?? "")  \(fmt(h.0))      \(def(h.1)?.label ?? "")  \(fmt(h.1))"
            (txt as NSString).draw(at: CGPoint(x: plot.minX + 4, y: bounds.maxY - 15),
                withAttributes: [.font: UIFont.boldSystemFont(ofSize: 10), .foregroundColor: UIColor.white.withAlphaComponent(0.8)])
            accent.withAlphaComponent(0.25).setFill()
            UIBezierPath(ovalIn: CGRect(x: pt.x - 17, y: pt.y - 17, width: 34, height: 34)).fill()
            accent.setFill()
            UIBezierPath(ovalIn: CGRect(x: pt.x - 9, y: pt.y - 9, width: 18, height: 18)).fill()
            UIColor.white.setStroke(); let ring = UIBezierPath(ovalIn: CGRect(x: pt.x - 9, y: pt.y - 9, width: 18, height: 18)); ring.lineWidth = 2; ring.stroke()
        }
    }
}
