// EditorAudioLibrary.swift — the "Audio" folder. Users paste audio files into
// Files › SaikiMotion › Audio; the editor's Audio tool lists everything in it.

import UIKit
import UniformTypeIdentifiers

enum AudioLibrary {
    static let exts: Set<String> = ["mp3", "m4a", "wav", "aac", "aif", "aiff", "caf", "flac", "ogg", "mp4"]

    /// <Documents>/SaikiMotion/Audio (created on first access so it shows up in the Files app).
    static var dir: URL {
        let u = Paths.root.appendingPathComponent("Audio", isDirectory: true)
        try? FileManager.default.createDirectory(at: u, withIntermediateDirectories: true)
        return u
    }

    static func files() -> [URL] {
        let all = (try? FileManager.default.contentsOfDirectory(at: dir, includingPropertiesForKeys: nil,
                                                                options: [.skipsHiddenFiles])) ?? []
        return all.filter { exts.contains($0.pathExtension.lowercased()) }
            .sorted { $0.lastPathComponent.localizedCaseInsensitiveCompare($1.lastPathComponent) == .orderedAscending }
    }
}

final class AudioLibraryController: UITableViewController {
    var files: [URL] = []
    var onPick: ((URL) -> Void)?
    var onBrowse: (() -> Void)?

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Audio library"
        files = AudioLibrary.files()
        tableView.backgroundColor = UIColor(white: 0.07, alpha: 1)
        navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: .close, target: self, action: #selector(close))
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Browse Files", style: .plain, target: self, action: #selector(browse))
    }
    @objc private func close() { dismiss(animated: true) }
    @objc private func browse() { dismiss(animated: true) { [onBrowse] in onBrowse?() } }

    override func tableView(_ t: UITableView, numberOfRowsInSection s: Int) -> Int { max(files.count, 1) }
    override func tableView(_ t: UITableView, cellForRowAt ip: IndexPath) -> UITableViewCell {
        let c = UITableViewCell(style: .default, reuseIdentifier: nil)
        c.backgroundColor = .clear
        c.textLabel?.textColor = .white
        c.textLabel?.numberOfLines = 0
        if files.isEmpty {
            c.textLabel?.text = "Empty. Paste audio into Files › SaikiMotion › Audio, then reopen this list."
            c.textLabel?.textColor = .lightGray
            c.selectionStyle = .none
        } else {
            c.textLabel?.text = files[ip.row].lastPathComponent
        }
        return c
    }
    override func tableView(_ t: UITableView, didSelectRowAt ip: IndexPath) {
        t.deselectRow(at: ip, animated: true)
        guard ip.row < files.count else { return }
        let u = files[ip.row]
        dismiss(animated: true) { [onPick] in onPick?(u) }
    }
}

extension EditorViewController {
    /// Opens the audio library; picking a file adds it as an audio layer (same path as the Files picker).
    func showAudioLibrary() {
        let vc = AudioLibraryController()
        vc.onPick = { [weak self] url in
            guard let self = self else { return }
            self.pendingPick = R_AUDIOFILE
            let dummy = UIDocumentPickerViewController(forOpeningContentTypes: [.audio], asCopy: true)
            self.documentPicker(dummy, didPickDocumentsAt: [url])
        }
        vc.onBrowse = { [weak self] in self?.pickFile(R_AUDIOFILE, [.audio]) }
        let nav = UINavigationController(rootViewController: vc)
        nav.overrideUserInterfaceStyle = .dark
        present(nav, animated: true)
    }
}
