// EditorDepth.swift — "Install Depth Anything" panel inside the Depth Map effect.

import UIKit
import AVFoundation

extension EditorViewController {
    func addDepthAnythingPanel(_ c: UIStackView, _ l: Layer, _ entry: String) {
        let sel = DepthAnything.selected
        func label(_ t: String, _ col: UIColor = .lightGray) -> UILabel {
            let x = UILabel(); x.text = t; x.textColor = col; x.font = .systemFont(ofSize: 12); x.numberOfLines = 0; return x
        }
        put(c, label("AI DEPTH  ·  Depth Anything V2", .white))
        for k in DepthModelKind.allCases {
            let on = k == sel
            let t = (DepthAnything.isInstalled(k) ? "✓ " : "") + "\(k.title) — \(k.detail)"
            put(c, pill(t, nil, on ? C.BLUE : C.CARD2, on ? C.ONDARK : C.TEXT) { [weak self] in
                DepthAnything.selected = k; self?.refreshPanel()
            }, 42)
        }
        if !DepthAnything.isInstalled(sel) {
            let status = label("Not installed. Needs an internet connection once; the model stays on this device.")
            put(c, status)
            put(c, pill("Install Depth Anything (\(sel.title))", "layers", C.BLUE) { [weak self, weak status] in
                guard let self = self else { return }
                status?.text = "Starting download…"
                DepthAnything.install(sel, progress: { f, msg in
                    status?.text = "\(msg) \(Int(f * 100))%"
                }, done: { err in
                    if let err = err { self.toast("Install failed: \(err.localizedDescription)") }
                    else { self.toast("Depth Anything \(sel.title) installed") }
                    self.refreshPanel()
                })
            }, 46)
        } else {
            put(c, label("Installed. Generates a depth layer from the layer's current frame; it is added as a new layer and set as this effect's Depth Source."))
            put(c, pill("Generate AI Depth Map", "layers", C.BLUE) { [weak self] in
                self?.generateDepthLayer(l, entry, sel)
            }, 46)
            put(c, pill("Delete \(sel.title) model", nil, C.CARD2, C.RED) { [weak self] in
                DepthAnything.remove(sel); self?.refreshPanel()
            }, 40)
        }
    }

    private func frameImage(_ l: Layer, _ done: @escaping (UIImage?) -> Void) {
        if l.type == .IMAGE, let img = UIImage(contentsOfFile: l.imagePath ?? "") { done(img); return }
        if l.type == .VIDEO {
            let t = max(0, Double(Editor.time - l.start + l.srcOffset))
            let gen = AVAssetImageGenerator(asset: AVURLAsset(url: URL(fileURLWithPath: l.imagePath ?? "")))
            gen.appliesPreferredTrackTransform = true
            gen.requestedTimeToleranceBefore = .zero; gen.requestedTimeToleranceAfter = .zero
            DispatchQueue.global(qos: .userInitiated).async {
                let cg = try? gen.copyCGImage(at: CMTime(seconds: t, preferredTimescale: 600), actualTime: nil)
                DispatchQueue.main.async { done(cg.map { UIImage(cgImage: $0) }) }
            }
            return
        }
        done(nil)
    }

    private func generateDepthLayer(_ l: Layer, _ entry: String, _ kind: DepthModelKind) {
        toast("Generating depth map…")
        frameImage(l) { [weak self] img in
            guard let self = self else { return }
            guard let img = img else { self.toast("Depth maps work on image and video layers."); return }
            DepthAnything.depth(for: img, kind: kind) { out, err in
                guard let out = out, let png = out.pngData() else { self.toast(err ?? "Depth failed"); return }
                do {
                    try? FileManager.default.createDirectory(at: Projects.mediaDir(), withIntermediateDirectories: true)
                    let path = Projects.mediaDir().appendingPathComponent("\(nowMs())_depth.png").path
                    try png.write(to: URL(fileURLWithPath: path))
                    self.pushUndo()
                    let before = Set(Editor.scene.layers.map { $0.id })
                    self.addMedia(path, .IMAGE)
                    if let nl = Editor.scene.layers.first(where: { !before.contains($0.id) }) {
                        nl.name = "Depth (\(kind.title))"
                        l.inputs[entry + ":Depth Source"] = nl.id
                        nl.visible = false
                    }
                    self.refreshPanel(); self.render()
                    self.toast("Depth layer added and linked")
                } catch { self.toast("Could not save depth map") }
            }
        }
    }
}
