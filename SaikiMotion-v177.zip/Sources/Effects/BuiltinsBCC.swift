// BuiltinsBCC.swift — BCC Grunge, BCC Caustics, BCC Extruded EPS-SVG (2.5D) and Linear Wipe.

func bccFx() -> [EffectDef] {
    var out: [EffectDef] = []

    // MARK: Linear Wipe
    out.append(EffectDef(
        id: "wipelinear", name: "Linear Wipe", desc: "Simple linear wipe. Animate Completion 0 to 100% to wipe the layer away; Angle rotates the wipe direction and Feather softens the edge.",
        category: "Transitions", props: [
            PropDef("wpDone", "Completion", 0, 1, 0, 3),
            PropDef("wpAngle", "Angle", -180, 180, 0, 1, nil, true, 180),
            PropDef("wpFeather", "Feather", 0, 1, 0.1, 3),
            PropDef("wpInvert", "Reverse", 0, 1, 0, 0, ["Off", "On"]),
        ], glsl: """
    vec4 c = src(uv);
    float ar = uRes.x / uRes.y;
    vec2 d = vec2(cos(radians(wpAngle)), -sin(radians(wpAngle)));
    vec2 p = (uv - 0.5) * vec2(ar, 1.0);
    float ext = max(abs(d.x) * ar + abs(d.y), 0.0001);
    float t = dot(p, d) / ext + 0.5;
    float f = max(wpFeather * 0.5, 0.0005);
    float tt = wpInvert > 0.5 ? 1.0 - t : t;
    float pos = wpDone * (1.0 + 2.0 * f) - f;
    float vis = smoothstep(pos - f, pos + f, tt);
    return c * vis;
"""))

    // MARK: BCC Grunge
    out.append(EffectDef(
        id: "bccgrunge", name: "BCC Grunge", desc: "Grungy, degraded, torn-up looks: procedural grunge textures blended with 10 apply modes plus displacement, bump lighting, erosion, shake, flicker, scratches, dust, scan lines, vignette, chromatic aberration, noise, grain, blur and glow. Link a Map Layer (any layer, e.g. a depth map) to drive displacement and erosion.",
        category: "BCC", props: [
            PropDef("grTexOn", "Use Texture", 0, 1, 1, 0, ["Off", "On"]),
            PropDef("grTex", "Texture", 0, 5, 0, 0, ["Concrete", "Torn Paper", "Scratched Metal", "Rust", "Dirt", "Film Burn"]),
            PropDef("grMode", "Apply Mode", 0, 9, 1, 0, ["Normal", "Multiply", "Screen", "Overlay", "Soft Light", "Hard Light", "Add", "Difference", "Color Burn", "Linear Burn"]),
            PropDef("grMix", "Apply Mix", 0, 1, 1, 2),
            PropDef("grBright", "Brightness", -1, 1, 0, 2),
            PropDef("grContrast", "Contrast", 0, 3, 1, 2),
            PropDef("grSat", "Saturation", 0, 3, 1, 2),
            PropDef("grTintAmt", "Tint Amount", 0, 1, 0, 2),
            PropDef("grPosX", "Texture Position X", -2, 2, 0, 3),
            PropDef("grPosY", "Texture Position Y", -2, 2, 0, 3),
            PropDef("grRot", "Texture Rotation", -180, 180, 0, 1, nil, true, 180),
            PropDef("grScale", "Texture Scale", 0.1, 8, 1, 2),
            PropDef("grOpacity", "Texture Opacity", 0, 1, 1, 2),
            PropDef("grSrcAlpha", "Use Source Alpha", 0, 1, 1, 0, ["Off", "On"]),
            PropDef("grDispAmt", "Displacement Amount", 0, 0.2, 0, 3),
            PropDef("grDispMap", "Displacement Map", 0, 1, 0, 0, ["Texture", "Map Layer"]),
            PropDef("grBump", "Bump Amount", 0, 1, 0, 2),
            PropDef("grBumpH", "Bump Height", 0, 10, 3, 2),
            PropDef("grLightAng", "Light Angle", -180, 180, 135, 0, nil, true, 180),
            PropDef("grSpec", "Specular", 0, 2, 0.3, 2),
            PropDef("grErode", "Erosion Amount", 0, 1, 0, 3),
            PropDef("grErSmooth", "Erosion Smoothness", 0, 1, 0.2, 2),
            PropDef("grErMap", "Erosion Map", 0, 1, 0, 0, ["Texture", "Map Layer"]),
            PropDef("grErInv", "Erosion Inverse", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("grShake", "Shake Amount", 0, 0.1, 0, 3),
            PropDef("grShakeSpd", "Shake Speed", 0, 30, 8, 1),
            PropDef("grShakeRnd", "Shake Random", 0, 1, 0.5, 2),
            PropDef("grFlick", "Flicker Amount", 0, 1, 0, 2),
            PropDef("grFlickSpd", "Flicker Speed", 0, 30, 10, 1),
            PropDef("grScr", "Scratches Density", 0, 1, 0, 2),
            PropDef("grScrW", "Scratches Width", 0.2, 4, 1, 2),
            PropDef("grScrOp", "Scratches Opacity", 0, 1, 0.8, 2),
            PropDef("grDust", "Dust Density", 0, 1, 0, 2),
            PropDef("grScan", "Scan Lines", 0, 1, 0, 2),
            PropDef("grScanSz", "Scan Line Size", 1, 40, 4, 1),
            PropDef("grScanSpd", "Scan Roll Speed", -5, 5, 0.5, 2),
            PropDef("grVig", "Vignette Amount", 0, 1, 0, 2),
            PropDef("grVigRad", "Vignette Radius", 0.1, 2, 0.8, 2),
            PropDef("grCA", "Chromatic Aberration", 0, 0.03, 0, 4),
            PropDef("grNoise", "Noise Amount", 0, 1, 0, 2),
            PropDef("grGrain", "Grain Amount", 0, 1, 0, 2),
            PropDef("grBlur", "Blur", 0, 0.02, 0, 4),
            PropDef("grGlow", "Glow Intensity", 0, 2, 0, 2),
            PropDef("grGlowThr", "Glow Threshold", 0, 1, 0.6, 2),
            PropDef("grSeed", "Random Seed", 0, 1000, 0, 0),
        ], colors: [
            ColorParam("grTint", "Tint Color", Int32(bitPattern: 0xFFB08A5A)),
            ColorParam("grScrCol", "Scratch Color", Int32(bitPattern: 0xFFFFFFFF)),
            ColorParam("grGlowCol", "Glow Color", Int32(bitPattern: 0xFFFFC890)),
        ], inputs: ["Map Layer"], glsl: """
    float ar = uRes.x / uRes.y;
    float sd = grSeed * 1.37;
    // shake
    vec2 uv2 = uv;
    if (grShake > 0.0) {
        float st = floor(uTime * grShakeSpd);
        float st2 = mix(uTime * grShakeSpd, st, grShakeRnd);
        vec2 j = vec2(hash21(vec2(st, 1.0 + sd)), hash21(vec2(st, 2.0 + sd))) - 0.5;
        vec2 w = vec2(sin(st2 * 1.7), cos(st2 * 2.3)) * 0.5;
        uv2 += mix(w, j, grShakeRnd) * 2.0 * grShake;
    }
    // procedural texture
    vec2 tp = rot((uv2 - 0.5) * vec2(ar, 1.0) - vec2(grPosX, grPosY), radians(grRot)) / max(grScale, 0.05) * 3.0 + vec2(sd);
    float n1 = fbm(tp), n2 = fbm(tp * 4.0 + 7.0), n3 = vnoise(tp * 30.0);
    float tg = 0.5; float tg2 = 0.5;
    float tsel = floor(grTex + 0.5);
    if (tsel < 0.5) { tg = n1 * 0.7 + n3 * 0.3; tg2 = n2; }
    else if (tsel < 1.5) { tg = smoothstep(0.42, 0.58, n1 + (n2 - 0.5) * 0.25); tg2 = n2; }
    else if (tsel < 2.5) { float ln = vnoise(vec2(tp.x * 0.6, tp.y * 60.0)); tg = clamp(n1 * 0.5 + ln * 0.7, 0.0, 1.0); tg2 = ln; }
    else if (tsel < 3.5) { tg = clamp(n1 * n1 * 2.0 + n2 * 0.3, 0.0, 1.0); tg2 = n2; }
    else if (tsel < 4.5) { tg = clamp(n2 * 0.6 + n1 * 0.4 - 0.1 + n3 * 0.2, 0.0, 1.0); tg2 = n3; }
    else { tg = clamp(1.0 - pow(n1, 1.5) * 1.5, 0.0, 1.0); tg2 = n2; }
    vec4 mp = vec4(0.5);
    if (uHas0 > 0.5) { mp = in0(uv2); }
    float dmap = (grDispMap > 0.5 && uHas0 > 0.5) ? luma(mp.rgb) : tg;
    float dmap2 = (grDispMap > 0.5 && uHas0 > 0.5) ? mp.g : tg2;
    vec2 su = uv2 + vec2(dmap - 0.5, dmap2 - 0.5) * grDispAmt * vec2(1.0 / ar, 1.0) * 2.0;
    // source (blur + chromatic aberration)
    vec4 s = src(su);
    if (grBlur > 0.0) {
        vec4 acc = s;
        for (int i = 0; i < 8; i++) {
            float a = float(i) * 0.7854;
            acc += src(su + vec2(cos(a), sin(a)) * grBlur * vec2(1.0 / ar, 1.0));
        }
        s = acc / 9.0;
    }
    float sa = s.a;
    vec3 rgb = s.rgb / max(sa, 0.0001);
    if (grCA > 0.0) {
        vec2 cav = (su - 0.5) * grCA * 2.0;
        vec4 sr = src(su + cav), sb = src(su - cav);
        rgb = vec3(sr.r / max(sr.a, 0.0001), rgb.g, sb.b / max(sb.a, 0.0001));
        sa = max(sa, max(sr.a, sb.a));
    }
    // texture apply
    if (grTexOn > 0.5) {
        vec3 tc = vec3(tg);
        if (tsel > 2.5 && tsel < 3.5) { tc = mix(vec3(0.45, 0.2, 0.08), vec3(0.85, 0.5, 0.2), tg); }
        if (tsel > 4.5) { tc = mix(vec3(1.0, 0.45, 0.1), vec3(1.0, 0.95, 0.8), tg); }
        vec3 bl = tc;
        float m = floor(grMode + 0.5);
        if (m < 0.5) { bl = tc; }
        else if (m < 1.5) { bl = rgb * tc; }
        else if (m < 2.5) { bl = 1.0 - (1.0 - rgb) * (1.0 - tc); }
        else if (m < 3.5) { bl = mix(2.0 * rgb * tc, 1.0 - 2.0 * (1.0 - rgb) * (1.0 - tc), step(vec3(0.5), rgb)); }
        else if (m < 4.5) { bl = (1.0 - 2.0 * tc) * rgb * rgb + 2.0 * tc * rgb; }
        else if (m < 5.5) { bl = mix(2.0 * rgb * tc, 1.0 - 2.0 * (1.0 - rgb) * (1.0 - tc), step(vec3(0.5), tc)); }
        else if (m < 6.5) { bl = rgb + tc; }
        else if (m < 7.5) { bl = abs(rgb - tc); }
        else if (m < 8.5) { bl = 1.0 - (1.0 - rgb) / max(tc, 0.01); }
        else { bl = rgb + tc - 1.0; }
        bl = mix(tc, bl, grMix);
        rgb = mix(rgb, clamp(bl, 0.0, 1.0), grOpacity);
        if (grBump > 0.0) {
            vec2 px = 1.5 / uRes;
            vec2 q1 = tp + vec2(px.x * 3.0, 0.0), q2 = tp + vec2(0.0, px.y * 3.0);
            float hx = fbm(q1) * 0.7 + vnoise(q1 * 30.0) * 0.3;
            float hy = fbm(q2) * 0.7 + vnoise(q2 * 30.0) * 0.3;
            vec3 nrm = normalize(vec3((tg - hx) * grBumpH * 8.0, (tg - hy) * grBumpH * 8.0, 1.0));
            vec3 L = normalize(vec3(cos(radians(grLightAng)), -sin(radians(grLightAng)), 0.8));
            float df = clamp(dot(nrm, L), 0.0, 1.0);
            float sp = pow(clamp(dot(nrm, normalize(L + vec3(0.0, 0.0, 1.0))), 0.0, 1.0), 24.0) * grSpec;
            rgb = mix(rgb, rgb * (0.4 + df * 0.9) + vec3(sp), grBump);
        }
    }
    // colour
    rgb += vec3(grBright);
    rgb = (rgb - 0.5) * grContrast + 0.5;
    float lm = luma(rgb);
    rgb = mix(vec3(lm), rgb, grSat);
    rgb = mix(rgb, grTint.rgb * (lm + 0.25), grTintAmt);
    // alpha + erosion
    float a = grSrcAlpha > 0.5 ? sa : max(sa, grTexOn * grOpacity);
    if (grErode > 0.0) {
        float e = (grErMap > 0.5 && uHas0 > 0.5) ? luma(mp.rgb) : tg;
        if (grErInv > 0.5) { e = 1.0 - e; }
        float sm = max(grErSmooth, 0.01);
        float th = grErode * (1.0 + sm);
        a *= smoothstep(th - sm, th, e);
    }
    // flicker
    if (grFlick > 0.0) {
        float fl = hash21(vec2(floor(uTime * grFlickSpd), 5.0 + sd)) - 0.5;
        rgb *= 1.0 + fl * 2.0 * grFlick;
    }
    // scratches
    if (grScr > 0.0) {
        float cols = 90.0;
        float cx = floor(uv2.x * cols);
        float life = floor(uTime * 6.0 + hash21(vec2(cx, sd)) * 10.0);
        float h = hash21(vec2(cx, life + sd));
        if (h < grScr * 0.35) {
            float xo = (hash21(vec2(cx, life + 9.0)) - 0.5) * 0.7;
            float lx = abs(fract(uv2.x * cols) - 0.5 - xo);
            float y0 = hash21(vec2(cx, life + 3.0));
            float len = 0.1 + hash21(vec2(cx, life + 4.0)) * 0.6;
            float inY = step(y0, uv2.y) * step(uv2.y, y0 + len);
            float ln = (1.0 - smoothstep(0.0, 0.07 * grScrW, lx)) * inY;
            rgb = mix(rgb, grScrCol.rgb, ln * grScrOp);
        }
    }
    // dust
    if (grDust > 0.0) {
        vec2 dc = floor(uv2 * vec2(ar, 1.0) * 220.0);
        float dh = hash21(dc + sd);
        float dd = step(1.0 - grDust * 0.03, dh) * (1.0 - smoothstep(0.2, 0.5, length(fract(uv2 * vec2(ar, 1.0) * 220.0) - 0.5)));
        rgb = mix(rgb, vec3(1.0), dd * 0.8);
    }
    // scan lines
    if (grScan > 0.0) {
        float sl = sin((uv2.y * uRes.y / max(grScanSz, 1.0) + uTime * grScanSpd * 10.0) * 3.14159);
        rgb *= 1.0 - grScan * 0.5 * (0.5 + 0.5 * sl);
    }
    // vignette
    if (grVig > 0.0) {
        float vg = length((uv - 0.5) * vec2(ar, 1.0)) / max(grVigRad, 0.05);
        rgb *= 1.0 - grVig * smoothstep(0.4, 1.2, vg);
    }
    // noise + grain
    if (grNoise > 0.0) { rgb += (hash21(uv * uRes + floor(uTime * 24.0) * 7.1 + sd) - 0.5) * grNoise * 0.6; }
    if (grGrain > 0.0) {
        vec3 gr = vec3(hash21(uv * uRes * 0.8 + floor(uTime * 24.0)), hash21(uv * uRes * 0.8 + 11.0 + floor(uTime * 24.0)), hash21(uv * uRes * 0.8 + 23.0 + floor(uTime * 24.0))) - 0.5;
        rgb += gr * grGrain * 0.4;
    }
    // glow
    if (grGlow > 0.0) {
        vec3 gl = vec3(0.0);
        for (int i = 0; i < 8; i++) {
            float an = float(i) * 0.7854;
            vec4 g = src(su + vec2(cos(an), sin(an)) * 0.02 * vec2(1.0 / ar, 1.0));
            gl += max(g.rgb / max(g.a, 0.0001) - vec3(grGlowThr), vec3(0.0));
        }
        rgb += gl / 8.0 * grGlow * grGlowCol.rgb * 2.0;
    }
    rgb = clamp(rgb, 0.0, 1.5);
    return vec4(rgb * a, a);
"""))

    // MARK: BCC Caustics
    out.append(EffectDef(
        id: "bcccaustics", name: "BCC Caustics", desc: "Light refracting through moving water, projected onto a surface (pool-bottom ripples, plasma, smoky fields). The wave map comes from fractal noise, this layer or a linked Map Layer (a depth map works well).",
        category: "BCC", props: [
            PropDef("caView", "View", 0, 2, 0, 0, ["Final Output", "Wave Map", "Caustics Only"]),
            PropDef("caMode", "Compositing", 0, 4, 0, 0, ["Add", "Screen", "Multiply", "Overlay", "None (over color)"]),
            PropDef("caWave", "Wave Source", 0, 2, 2, 0, ["Filtered Layer", "Map Layer", "Fractals"]),
            PropDef("caCh", "Wave Channel", 0, 4, 0, 0, ["Luminance", "Alpha", "Red", "Green", "Blue"]),
            PropDef("caSmooth", "Wave Smoothing", 0, 1, 0.2, 2),
            PropDef("caHeight", "Wave Height", 0, 10, 3, 2),
            PropDef("caScale", "Wave Area Scale", 0.1, 5, 1, 2),
            PropDef("caProj", "Projection Distance", 0, 4, 1, 2),
            PropDef("caBright", "Brightness", 0, 4, 1.2, 2),
            PropDef("caContrast", "Contrast", 0, 4, 1.4, 2),
            PropDef("caWisp", "Wispiness", 0.2, 4, 1.2, 2),
            PropDef("caSoft", "Softness", 0, 1, 0.1, 2),
            PropDef("caColSrc", "Color Source", 0, 2, 0, 0, ["Color", "Filtered Layer", "Map Layer"]),
            PropDef("caAlpha", "Alpha Source", 0, 2, 0, 0, ["Unmult Image", "Opaque", "Filtered Layer"]),
            PropDef("caFreq", "Fractal Frequency", 0.2, 12, 3, 2),
            PropDef("caDetail", "Fractal Detail", 1, 6, 3, 0),
            PropDef("caX", "X Position", -2, 2, 0, 3),
            PropDef("caY", "Y Position", -2, 2, 0, 3),
            PropDef("caMut", "Mutation Rate", 0, 5, 0.5, 2),
            PropDef("caSeed", "Random Seed", 0, 1000, 0, 0),
            PropDef("caMix", "Mix with Original", 0, 1, 1, 2),
        ], colors: [
            ColorParam("caColor", "Color", Int32(bitPattern: 0xFF9FE0FF)),
            ColorParam("caBase", "Background Color", Int32(bitPattern: 0xFF0A3A5A)),
        ], inputs: ["Map Layer"], glsl: """
    float ar = uRes.x / uRes.y;
    vec4 s = src(uv);
    vec4 mp = (uHas0 > 0.5) ? in0(uv) : s;
    vec2 p = ((uv - 0.5) * vec2(ar, 1.0) - vec2(caX, caY)) * caScale;
    float t = uTime * caMut;
    float sd = caSeed * 1.7;
    float eps = 0.004 + caSmooth * 0.03;
    float lap = 0.0;
    float h0 = 0.0;
    for (int k = 0; k < 5; k++) {
        vec2 o = vec2(0.0);
        if (k == 1) { o = vec2(eps, 0.0); } else if (k == 2) { o = vec2(-eps, 0.0); } else if (k == 3) { o = vec2(0.0, eps); } else if (k == 4) { o = vec2(0.0, -eps); }
        float h = 0.0;
        if (caWave < 1.5) {
            vec2 qu = (p + o) / (caScale * vec2(ar, 1.0)) + 0.5 + vec2(caX, caY) / vec2(ar, 1.0);
            vec4 w = (caWave < 0.5) ? src(qu) : ((uHas0 > 0.5) ? in0(qu) : src(qu));
            if (caCh < 0.5) { h = luma(w.rgb); } else if (caCh < 1.5) { h = w.a; } else if (caCh < 2.5) { h = w.r; } else if (caCh < 3.5) { h = w.g; } else { h = w.b; }
        } else {
            vec2 q = (p + o) * caFreq * 0.5 + vec2(sd, sd * 0.6);
            float amp = 1.0; float nr = 0.0;
            for (int i = 0; i < 6; i++) {
                if (float(i) >= caDetail) { break; }
                h += vnoise(q + vec2(t * 0.6 + float(i) * 3.1, t * 0.4)) * amp;
                nr += amp;
                q = rot(q, 0.7) * 2.0; amp *= 0.5;
            }
            h /= max(nr, 0.001);
        }
        if (k == 0) { lap -= 4.0 * h; h0 = h; } else { lap += h; }
    }
    float inten = 1.0 - lap / (eps * eps) * caHeight * 0.0006 * caProj;
    float c = pow(clamp(abs(inten), 0.0, 3.0), caWisp);
    c = clamp((c - 0.5) * caContrast + 0.5, 0.0, 4.0) * caBright;
    if (caSoft > 0.0) { c = mix(c, h0 * caBright * 1.2, caSoft * 0.5); }
    vec3 col = caColor.rgb;
    if (caColSrc > 1.5) { col = mp.rgb / max(mp.a, 0.0001); }
    else if (caColSrc > 0.5) { col = s.rgb / max(s.a, 0.0001); }
    vec3 cc = col * c;
    if (caView > 1.5) { return vec4(cc, 1.0); }
    if (caView > 0.5) { return vec4(vec3(h0), 1.0); }
    float al = 1.0;
    if (caAlpha < 0.5) { al = clamp(max(cc.r, max(cc.g, cc.b)), 0.0, 1.0); }
    else if (caAlpha > 1.5) { al = s.a; }
    vec3 base = s.rgb;
    vec3 res;
    if (caMode < 0.5) { res = base + cc; }
    else if (caMode < 1.5) { res = 1.0 - (1.0 - base) * (1.0 - clamp(cc, 0.0, 1.0)); }
    else if (caMode < 2.5) { res = base * (0.4 + cc); }
    else if (caMode < 3.5) { res = mix(2.0 * base * cc, 1.0 - 2.0 * (1.0 - base) * (1.0 - cc), step(vec3(0.5), base)); }
    else { res = caBase.rgb * s.a + cc * al; }
    float oa = (caMode > 3.5) ? max(s.a, al) : s.a;
    vec4 fx = vec4(clamp(res, 0.0, 2.0), oa);
    return mix(s, fx, caMix);
"""))

    // MARK: BCC Extruded EPS-SVG (2.5D)
    out.append(EffectDef(
        id: "bccextrude", name: "BCC Extruded EPS-SVG", desc: "Extrudes the layer's artwork (vector pen shape, SVG-style shape, text or any alpha) into a 3D-looking solid with bevel, lighting and rotation. The layer becomes 3D so the comp camera, nulls and the basic 3D transform all work with it. Link a Depth Map layer to vary the depth per pixel.",
        category: "BCC", props: [
            PropDef("exDepth", "Extrusion Depth", 0, 1, 0.12, 3),
            PropDef("exRotX", "Rotate X", -90, 90, 20, 1, nil, true, 90),
            PropDef("exRotY", "Rotate Y", -90, 90, -25, 1, nil, true, 90),
            PropDef("exRotZ", "Rotate Z", -180, 180, 0, 1, nil, true, 180),
            PropDef("exPosX", "Position X", -1, 1, 0, 3),
            PropDef("exPosY", "Position Y", -1, 1, 0, 3),
            PropDef("exScale", "Master Scale", 0.1, 3, 1, 2),
            PropDef("exBevel", "Bevel Amount", 0, 1, 0.4, 2),
            PropDef("exFront", "Front Texture Strength", 0, 1, 1, 2),
            PropDef("exAmb", "Ambient Intensity", 0, 1, 0.35, 2),
            PropDef("exLightAng", "Light Angle", -180, 180, 45, 0, nil, true, 180),
            PropDef("exSpec", "Specular Strength", 0, 2, 0.5, 2),
            PropDef("exDM", "Depth Map Amount", 0, 2, 1, 2),
            PropDef("exOpacity", "Opacity", 0, 1, 1, 2),
        ], colors: [
            ColorParam("exSide", "Side Color", Int32(bitPattern: 0xFFC8A04A)),
            ColorParam("exFrontCol", "Front Color", Int32(bitPattern: 0xFFFFFFFF)),
        ], inputs: ["Depth Map"], glsl: """
    float ar = uRes.x / uRes.y;
    vec2 p = (uv - 0.5) * vec2(ar, 1.0) - vec2(exPosX, exPosY);
    p = rot(p, radians(exRotZ)) / max(exScale, 0.05);
    float rx = radians(exRotX), ry = radians(exRotY);
    vec2 ev = vec2(sin(ry), -sin(rx)) * exDepth;
    vec2 shr = vec2(1.0 - 0.5 * (1.0 - cos(ry)), 1.0 - 0.5 * (1.0 - cos(rx)));
    vec2 fp = p / shr;
    vec2 fuv = vec2(fp.x / ar + 0.5, fp.y + 0.5);
    vec4 f = src(fuv);
    vec3 L = normalize(vec3(cos(radians(exLightAng)), -sin(radians(exLightAng)), 0.7));
    vec3 fcol = mix(exFrontCol.rgb, f.rgb / max(f.a, 0.0001), exFront);
    float fl = 0.75 + 0.25 * dot(normalize(vec3(-sin(ry), sin(rx), cos(rx) * cos(ry))), L);
    float dpm = 1.0;
    if (uHas0 > 0.5) { dpm = mix(1.0, luma(in0(uv).rgb) * 2.0, clamp(exDM, 0.0, 1.0)); }
    vec3 rgb = vec3(0.0); float a = 0.0;
    float hit = -1.0;
    if (f.a > 0.5) {
        rgb = fcol * fl; a = f.a;
        // front bevel highlight
        float edge = 0.0;
        float bw = 0.004 + exBevel * 0.012;
        edge = 1.0 - (src(fuv + vec2(bw, 0.0)).a + src(fuv - vec2(bw, 0.0)).a + src(fuv + vec2(0.0, bw)).a + src(fuv - vec2(0.0, bw)).a) * 0.25;
        rgb += vec3(edge) * exBevel * 0.8;
    } else {
        for (int i = 1; i < 40; i++) {
            float k = float(i) / 40.0;
            vec2 pp = (p - ev * k * dpm * 0.5) / shr;
            vec2 uu = vec2(pp.x / ar + 0.5, pp.y + 0.5);
            float sa = src(uu).a;
            if (sa > 0.5) { hit = k; break; }
        }
        if (hit > 0.0) {
            vec2 ed = normalize(ev + vec2(0.0001));
            vec3 nrm = normalize(vec3(-ed.y, ed.x, 0.2));
            float df = clamp(dot(nrm, L) * 0.5 + 0.5, 0.0, 1.0);
            float sp = pow(clamp(dot(nrm, L), 0.0, 1.0), 12.0) * exSpec;
            float dark = 1.0 - hit * 0.45;
            rgb = exSide.rgb * (exAmb + (1.0 - exAmb) * df) * dark + vec3(sp) * 0.5;
            a = 1.0;
        }
    }
    a *= exOpacity;
    return vec4(clamp(rgb, 0.0, 1.5) * a, a);
"""))
    return out
}
