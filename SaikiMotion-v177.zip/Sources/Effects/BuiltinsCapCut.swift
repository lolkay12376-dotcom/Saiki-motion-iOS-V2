// BuiltinsCapCut.swift — CapCut-style effects ported from the supplied XML files (ids kept as in the XML):
//   nova.effect.capcut.voronoi · nova.effect.capcut.fuzzy · nova.effect.capcut.golden.hour
// (+ Voronoi Cells generator.) They show up under the "CapCut" group and all use the CapCut sample picture as their thumbnail.

import Foundation

let capcutFxIds: Set<String> = ["nova.effect.capcut.voronoi", "nova.effect.capcut.fuzzy", "nova.effect.capcut.golden.hour"]

func capcutFx() -> [EffectDef] {
    var out: [EffectDef] = []

    out.append(EffectDef(id: "nova.effect.capcut.voronoi", name: "Voronoi (CapCut)",
        desc: "Voronoi-cell mosaic.", category: "Distort", props: [
            PropDef("density", "Density", 4, 80, 25, 0),
        ], glsl: """
    float asp = uRes.x / uRes.y;
    vec2 g0 = uv * vec2(asp, 1.0) * density;
    vec2 i = floor(g0); vec2 f = fract(g0);
    vec2 nearest = vec2(0.0);
    float md = 10.0;
    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            vec2 g = vec2(float(x), float(y));
            vec2 p = i + g;
            vec2 o = fract(sin(vec2(dot(p, vec2(127.1, 311.7)), dot(p, vec2(269.5, 183.3)))) * 43758.5453);
            float d = distance(f, g + o);
            if (d < md) { md = d; nearest = i + g + o; }
        }
    }
    vec2 cellUv = nearest / density / vec2(asp, 1.0);
    return src(clamp(cellUv, 0.0, 1.0));
"""))

    out.append(EffectDef(id: "nova.effect.capcut.fuzzy", name: "Fuzzy (CapCut)",
        desc: "Diffuse fuzzy blur with mild chromatism.", category: "Blur", props: [
            PropDef("amount", "Intensity", 0, 2, 0.6, 2),
        ], glsl: """
    vec2 ts = (1.0 / uRes) * (amount * 6.0);
    vec4 acc = src(uv);
    acc += src(uv + vec2(ts.x, 0.0));
    acc += src(uv + vec2(-ts.x, 0.0));
    acc += src(uv + vec2(0.0, ts.y));
    acc += src(uv + vec2(0.0, -ts.y));
    acc += src(uv + ts);
    acc += src(uv - ts);
    acc += src(uv + vec2(ts.x, -ts.y));
    acc += src(uv + vec2(-ts.x, ts.y));
    acc /= 9.0;
    float cs = amount * 0.004;
    acc.r = src(uv + vec2(cs, 0.0)).r * 0.4 + acc.r * 0.6;
    acc.b = src(uv - vec2(cs, 0.0)).b * 0.4 + acc.b * 0.6;
    return acc;
"""))

    out.append(EffectDef(id: "nova.effect.capcut.golden.hour", name: "Golden Hour (CapCut)",
        desc: "Late-afternoon golden light.", category: "Color", props: [
            PropDef("intensity", "Intensity", 0, 1, 1, 2),
        ], glsl: """
    vec4 s = src(uv);
    float y = dot(s.rgb, vec3(0.299, 0.587, 0.114));
    vec3 shadow = vec3(0.35, 0.22, 0.12);
    vec3 mid = vec3(1.05, 0.85, 0.50);
    vec3 highlight = vec3(1.15, 1.00, 0.75);
    vec3 tint = y < 0.5 ? mix(shadow, mid, y * 2.0) : mix(mid, highlight, (y - 0.5) * 2.0);
    vec3 col = s.rgb * tint * 1.15;
    return vec4(mix(s.rgb, col, intensity), s.a);
"""))

    // Voronoi Cells (nova.effect.voronoi) — generator over the image; not a CapCut effect, so it keeps the default thumbnail.
    out.append(EffectDef(id: "nova.effect.voronoi", name: "Voronoi Cells",
        desc: "Cell pattern from nearest-point distance over a scattered grid.", category: "Generate", props: [
            PropDef("density", "Density", 2, 80, 12, 1),
            PropDef("jitter", "Irregularity", 0, 1, 1, 2),
            PropDef("speed", "Speed", 0, 4, 0, 2),
            PropDef("seed", "Seed", 0, 99, 0, 0),
            PropDef("edgeWidth", "Edge width", 0, 0.5, 0.08, 3),
            PropDef("colorByCell", "Vary per cell", 0, 1, 0.6, 2),
            PropDef("blend", "Over image", 0, 1, 1, 2),
        ], colors: [
            ColorParam("cellColor", "Cell", Int32(bitPattern: 0x88FF3366)),
            ColorParam("edgeColor", "Edge", Int32(bitPattern: 0xFF000000)),
        ], glsl: """
    vec4 original = src(uv);
    vec2 p = vec2(uv.x * (uRes.x / uRes.y), uv.y) * density;
    float t = uTime * speed;
    vec2 i = floor(p); vec2 f = fract(p);
    float f1 = 9.0, f2 = 9.0;
    vec2 owner = vec2(0.0);
    for (int y = -1; y <= 1; y++) {
        for (int x = -1; x <= 1; x++) {
            vec2 nb = vec2(float(x), float(y));
            vec2 c = i + nb;
            vec2 h = fract(sin(vec2(dot(c, vec2(127.1, 311.7)), dot(c, vec2(269.5, 183.3))) + vec2(seed * 13.7)) * 43758.5453);
            vec2 pt = nb + 0.5 + (h - 0.5) * jitter + 0.35 * jitter * vec2(sin(t + h.x * 6.2831), cos(t + h.y * 6.2831));
            float d = length(pt - f);
            if (d < f1) { f2 = f1; f1 = d; owner = i + nb; }
            else if (d < f2) { f2 = d; }
        }
    }
    float idc = fract(sin(dot(owner, vec2(419.2, 371.9)) + seed * 13.7) * 9999.9);
    float edge = 1.0 - smoothstep(edgeWidth * 0.5, edgeWidth, f2 - f1);
    vec3 base = cellColor.rgb;
    vec3 cellCol = mix(base, base * (0.5 + idc), colorByCell);
    float shade = 1.0 - smoothstep(0.0, 0.6, f1);
    vec3 pat = mix(cellCol * (0.55 + 0.45 * shade), edgeColor.rgb, edge);
    float patA = mix(cellColor.a, edgeColor.a, edge);
    vec3 col = mix(original.rgb, pat, blend * patA);
    float a = mix(original.a, max(original.a, patA), blend);
    return vec4(col, a);
"""))
    return out
}
