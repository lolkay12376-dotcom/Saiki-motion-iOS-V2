// BuiltinsControls.swift — "Controls" tab: expression-only effects (nothing is drawn, they just hold values).
// Read them from any parameter's expression: slider("L"), angle("L"), checkbox("L"), pointx("L"), pointy("L"),
// point3x/y/z("L"), colorr/g/b("L"), layerctl("L"). Add ", n" for the n-th control of that kind on the layer.

import Foundation

enum ControlFx {
    static let ids = ["slidercontrol", "anglecontrol", "checkboxcontrol", "colorcontrol",
                      "pointcontrol", "point3dcontrol", "layercontrol"]

    /// expression function → (effect id, parameter key). Colour functions use the "_r/_g/_b" colour tracks.
    static let fns: [String: (String, String)] = [
        "slider": ("slidercontrol", "slider"), "angle": ("anglecontrol", "angle"),
        "checkbox": ("checkboxcontrol", "checkbox"),
        "pointx": ("pointcontrol", "px"), "pointy": ("pointcontrol", "py"),
        "point3x": ("point3dcontrol", "px"), "point3y": ("point3dcontrol", "py"), "point3z": ("point3dcontrol", "pz"),
        "colorr": ("colorcontrol", "color_r"), "colorg": ("colorcontrol", "color_g"), "colorb": ("colorcontrol", "color_b"),
        "layerctl": ("layercontrol", "layer"),
    ]

    static func all() -> [EffectDef] {
        func mk(_ id: String, _ name: String, _ fn: String, _ anim: String, _ props: [PropDef],
                _ colors: [ColorParam] = []) -> EffectDef {
            let d = EffectDef(id: id, name: name,
                desc: "Expression control: holds a value and draws nothing. Read it with \(fn)(\"Layer name\") or \(fn)(\"Layer name\", 2) for the second one.",
                category: "Controls", props: props, colors: colors, glsl: "return src(uv);")
            d.previewAnim = anim
            return d
        }
        return [
            mk("slidercontrol", "Slider Control", "slider", "ctl_slider",
               [PropDef("slider", "Slider", -100000, 100000, 0, 2)]),
            mk("anglecontrol", "Angle Control", "angle", "ctl_angle",
               [PropDef("angle", "Angle", -100000, 100000, 0, 1)]),
            mk("checkboxcontrol", "Checkbox Control", "checkbox", "ctl_check",
               [PropDef("checkbox", "Checkbox (0 / 1)", 0, 1, 0, 0)]),
            mk("colorcontrol", "Color Control", "colorr/colorg/colorb", "ctl_color", [],
               [ColorParam("color", "Color", Int32(bitPattern: 0xFFFF2DCC))]),
            mk("pointcontrol", "Point Control", "pointx / pointy", "ctl_point",
               [PropDef("px", "Point X", -100000, 100000, 960, 1), PropDef("py", "Point Y", -100000, 100000, 540, 1)]),
            mk("point3dcontrol", "3D Point Control", "point3x / point3y / point3z", "ctl_point3d",
               [PropDef("px", "Point X", -100000, 100000, 960, 1), PropDef("py", "Point Y", -100000, 100000, 540, 1),
                PropDef("pz", "Point Z", -100000, 100000, 0, 1)]),
            mk("layercontrol", "Layer Control", "layerctl", "ctl_layer",
               [PropDef("layer", "Layer (number, 0 = none)", 0, 9999, 0, 0)]),
        ]
    }
}
