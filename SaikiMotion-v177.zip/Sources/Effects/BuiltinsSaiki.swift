// BuiltinsSaiki.swift — Unmult, Gradient Shadow+, Copy Background, Exposure/Gamma.

func saikiFx() -> [EffectDef] {
    var out: [EffectDef] = []

    // Unmult: black becomes transparent (src is premultiplied: v = visible colour over black)
    out.append(EffectDef(
        id: "unmult", name: "Unmult", desc: "Removes black: brightness becomes alpha and colours are kept. Ideal for flares, glows and light-on-black footage.",
        category: "Keying", props: [
            PropDef("umAmount", "Amount", 0, 1, 1, 2),
            PropDef("umGain", "Alpha Gain", 0, 4, 1, 2),
            PropDef("umThr", "Black Level", 0, 0.5, 0, 3),
        ], glsl: """
    vec4 c = src(uv);
    vec3 v = max(c.rgb - vec3(umThr), vec3(0.0)) / max(1.0 - umThr, 0.001);
    float a = clamp(max(max(v.r, v.g), v.b) * umGain, 0.0, 1.0);
    vec3 rgb = (a > 0.0001) ? v * min(a / max(max(max(v.r, v.g), v.b), 0.0001), 1.0) : vec3(0.0);
    return mix(c, vec4(rgb, a), umAmount);
"""))

    // Gradient Shadow+: shadow streak that fades along its length
    out.append(EffectDef(
        id: "gradshadow", name: "Gradient Shadow+", desc: "Drop shadow with a gradient falloff along its length. Progress sets the length, Angle the direction, Offset the start distance; Blending Mode and Alpha Blend control how it mixes with the layer.",
        category: "Light and glow", props: [
            PropDef("gsProgress", "Progress", 0, 1, 0.5, 2),
            PropDef("gsAngle", "Angle", -180, 180, 135, 1, nil, true, 180),
            PropDef("gsAlpha", "Alpha", 0, 1, 1, 2),
            PropDef("gsOffset", "Offset", 0, 0.3, 0, 3),
            PropDef("gsSoft", "Softness", 0, 0.05, 0.004, 3),
            PropDef("gsBright", "Brightness", 0, 2, 1, 2),
            PropDef("gsMode", "Blending Mode", 0, 3, 0, 0, ["Normal", "Multiply", "Add", "Screen"]),
            PropDef("gsBlend", "Alpha Blend", 0, 1, 1, 2),
        ], colors: [
            ColorParam("gsColor", "Color", Int32(bitPattern: 0xFF000000)),
        ], glsl: """
    vec4 c = src(uv);
    float a = radians(gsAngle);
    vec2 asp = vec2(uRes.y / uRes.x, 1.0);
    vec2 dir = vec2(cos(a), -sin(a)) * asp;
    float len = gsProgress * 0.5;
    float sh = 0.0;
    float ws = 0.0;
    for (int i = 0; i < 28; i++) {
        float k = (float(i) + 0.5) / 28.0;
        vec2 p = uv - dir * (gsOffset + k * len);
        float fall = pow(1.0 - k, 1.5);
        float s = src(p).a;
        if (gsSoft > 0.0) {
            vec2 so = vec2(gsSoft) * asp;
            s = (s * 2.0 + src(p + so).a + src(p - so).a + src(p + vec2(so.x, -so.y)).a + src(p - vec2(so.x, -so.y)).a) / 6.0;
        }
        sh = max(sh, s * fall);
    }
    sh = clamp(sh * gsAlpha, 0.0, 1.0) * (1.0 - c.a * gsBlend);
    vec3 col = gsColor.rgb * gsBright;
    vec3 sc = col * sh;
    vec3 rgb = c.rgb;
    float oa = c.a;
    if (gsMode < 0.5) { rgb = c.rgb + sc; oa = c.a + sh; }
    else if (gsMode < 1.5) { rgb = c.rgb * mix(vec3(1.0), col, sh) + sc * (1.0 - c.a); oa = c.a + sh * (1.0 - c.a); }
    else if (gsMode < 2.5) { rgb = c.rgb + sc; oa = max(c.a, sh); }
    else { rgb = c.rgb + sc * (1.0 - c.rgb); oa = c.a + sh * (1.0 - c.a); }
    return vec4(rgb, clamp(oa, 0.0, 1.0));
"""))

    // Copy Background: the composite of everything below, kept only where this layer is opaque
    out.append(EffectDef(
        id: "copybg", name: "Copy Background", desc: "Copies the background (all layers below) into this layer, only where this layer is opaque, so it acts as an adjustment layer shaped by the layer's alpha. Stack blur, colour or distort effects after it. Layer Mix brings back the layer's own colour.",
        category: "Generate", props: [
            PropDef("cbOpacity", "Opacity", 0, 1, 1, 2),
            PropDef("cbMix", "Layer Mix", 0, 1, 0, 2),
        ], glsl: """
    vec4 s = src(uv);
    vec4 b = (uHas0 > 0.5) ? in0(uv) : s;
    vec4 bg = vec4(b.rgb * s.a * cbOpacity, s.a * cbOpacity);
    return mix(bg, s, cbMix);
"""))

    // Exposure & Gamma
    out.append(EffectDef(
        id: "exposuregamma", name: "Exposure & Gamma", desc: "Exposure in stops, black-point offset and gamma, applied to straight colour (alpha untouched).",
        category: "Color", props: [
            PropDef("egExp", "Exposure", -5, 5, 0, 2),
            PropDef("egOff", "Offset", -0.5, 0.5, 0, 3),
            PropDef("egGamma", "Gamma", 0.1, 4, 1, 2),
        ], glsl: """
    vec4 c = src(uv);
    vec3 s = c.rgb / max(c.a, 0.0001);
    s = s * exp2(egExp) + vec3(egOff);
    s = pow(max(s, vec3(0.0)), vec3(1.0 / max(egGamma, 0.01)));
    return vec4(s * c.a, c.a);
"""))
    return out
}
