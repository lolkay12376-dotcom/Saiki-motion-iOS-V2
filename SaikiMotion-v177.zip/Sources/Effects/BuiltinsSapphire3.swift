// BuiltinsSapphire3.swift — Sapphire-style Texture Folded and Edge Rays.
//
// Written from the Sapphire parameter docs. Mocha / crop / filter-quality controls are not included
// (they need the tracker or the host); everything that shapes the look is.

import Foundation

/// Colour-difference edge of the source at `p` (premultiplied RGB, so transparent areas give no edge).
/// Writes the vec3 result into `out` (declared here). `thick` is the edge thickness in image heights.
private func edgeAt(_ p: String, _ out: String) -> String {
    """
    vec3 \(out);
    {
        vec2 ex = vec2(eth / asp.x, 0.0);
        vec2 ey = vec2(0.0, eth);
        vec4 a0 = src(\(p) + ex); vec4 a1 = src(\(p) - ex);
        vec4 a2 = src(\(p) + ey); vec4 a3 = src(\(p) - ey);
        vec4 dd = abs(a0 - a1) + abs(a2 - a3);
        \(out) = mix(dd.rgb, vec3(dd.a), erFromA) * erEdgeBr;
        if (erShAmp > 0.0) {
            vec2 sq = (\(p) - 0.5) * asp * erShFreq + vec2(erShSX, erShSY) + vec2(erShVX, erShVY) * uTime + vec2(erShSeed * 31.7, erShSeed * 7.3);
            \(out) *= mix(1.0, vnoise(sq) * 2.0, clamp(erShAmp, 0.0, 1.0));
        }
    }

    """
}

/// One ray-marching loop accumulating into `acc` (a vec3 or one swizzled channel) with ray length `len`.
private func rayLoop(_ acc: String, _ swz: String, _ len: String) -> String {
    """
    for (int i = 0; i < 24; i++) {
        float tt = (float(i) + 0.5 + jit) / 24.0;
        float tr = mix(-erRev, 1.0, tt);
        float wt = ((1.0 - erBias) * (1.0 - abs(tr)) + erBias * abs(tr)) * 2.0;
        vec2 sp = cen + (uv - cen) * (1.0 - \(len) * tr);
        \(edgeAt("sp", "ee"))
        \(acc) += ee\(swz) * wt;
    }

    """
}

func sapphire3Fx() -> [EffectDef] {
    var out: [EffectDef] = []
    let combine = ["Texture Only", "Mult", "Add", "Screen", "Difference", "Overlay"]

    // MARK: Texture Folded
    out.append(EffectDef(
        id: "texturefolded", name: "Texture Folded",
        desc: "Abstract folded-cloth / liquid texture. Fold Speed makes it undulate over time. Put it on a solid, or use Combine to mix it with the layer.",
        category: "Generate", props: [
            PropDef("tfFreq", "Frequency", 0.01, 60, 4, 2),
            PropDef("tfFreqX", "Frequency Rel X", 0.01, 10, 1, 2),
            PropDef("tfOct", "Octaves", 1, 10, 1, 0),
            PropDef("tfSeed", "Seed", 0, 100, 0.432, 3),
            PropDef("tfFoldAmp", "Fold Amp", -720, 720, 72, 1),
            PropDef("tfFoldFreq", "Fold Freq", 0.01, 20, 0.5, 2),
            PropDef("tfFoldOct", "Fold Octaves", 1, 10, 1, 0),
            PropDef("tfShX", "Shift X", -100, 100, 0, 3),
            PropDef("tfShY", "Shift Y", -100, 100, 0, 3),
            PropDef("tfFSX", "Fold Start X", -100, 100, 0, 3),
            PropDef("tfFSY", "Fold Start Y", -100, 100, 0, 3),
            PropDef("tfFVX", "Fold Speed X", -10, 10, 1, 3),
            PropDef("tfFVY", "Fold Speed Y", -10, 10, 0, 3),
            PropDef("tfPreScale", "Pre Scale Lights", 0, 4, 1, 2),
            PropDef("tfPreOff", "Pre Offset Darks", -1, 1, 0, 2),
            PropDef("tfBr1", "Brightness1", 0, 4, 1, 2),
            PropDef("tfM1On", "Mid Color1 Enable", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("tfM2On", "Mid Color2 Enable", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("tfM3On", "Mid Color3 Enable", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("tfOff0", "Offset0", -2, 2, 0, 2),
            PropDef("tfScale", "Scale Lights", 0, 4, 1, 2),
            PropDef("tfOffD", "Offset Darks", -2, 2, 0, 2),
            PropDef("tfHue", "Hue Shift", -2, 2, 0, 3),
            PropDef("tfSat", "Saturation", -2, 8, 1, 2),
            PropDef("tfBgBr", "Bg Brightness", 0, 4, 1, 2),
            PropDef("tfCombine", "Combine", 0, 5, 0, 0, combine),
            PropDef("tfOutOp", "Output Opacity", 0, 1, 0, 0, ["Copy From Input", "All Opaque"]),
            PropDef("tfMaskUse", "Mask Use", 0, 1, 0, 0, ["Luma", "Alpha"]),
            PropDef("tfInvMask", "Invert Mask", 0, 1, 0, 0, ["Off", "On"]),
        ], colors: [
            ColorParam("tfC1", "Color1", Int32(bitPattern: 0xFFFFFFFF)),
            ColorParam("tfM1", "Mid Color1", Int32(bitPattern: 0xFFB3B3B3)),
            ColorParam("tfM2", "Mid Color2", Int32(bitPattern: 0xFF808080)),
            ColorParam("tfM3", "Mid Color3", Int32(bitPattern: 0xFF333333)),
            ColorParam("tfC0", "Color0", Int32(bitPattern: 0xFF000000)),
        ], inputs: ["Mask"], glsl: """
    vec2 asp = vec2(uRes.x / uRes.y, 1.0);
    vec2 q0 = (uv - 0.5) * asp;
    vec2 sd = vec2(tfSeed * 13.1, tfSeed * 5.7);
    // two rounds of position-dependent rotation: this is what folds the noise like cloth
    vec2 p = q0 * tfFreq * vec2(tfFreqX, 1.0) + vec2(tfShX, tfShY);
    for (int k = 0; k < 2; k++) {
        vec2 fq = p * (tfFoldFreq / max(tfFreq, 0.01)) + vec2(tfFSX, tfFSY) + vec2(tfFVX, tfFVY) * uTime + sd + float(k) * 7.31;
        float fa = 0.0; float fm = 1.0; float ft = 0.0;
        for (int j = 0; j < 10; j++) {
            if (float(j) < tfFoldOct) {
                fa += fm * (vnoise(fq) - 0.5);
                ft += fm; fm *= 0.5; fq *= 2.0;
            }
        }
        fa = fa / max(ft, 0.0001) * 2.0;
        float ang = radians(tfFoldAmp) * fa;
        p = rot(p, ang) + vec2(cos(ang + 1.7), sin(ang + 1.7)) * 0.35 * abs(fa);
    }
    float n = 0.0; float am = 1.0; float tot = 0.0;
    vec2 np = p + sd;
    for (int i = 0; i < 10; i++) {
        if (float(i) < tfOct) {
            n += am * vnoise(np);
            tot += am; am *= 0.5; np = rot(np, 0.9) * 2.0 + 3.1;
        }
    }
    n = n / max(tot, 0.0001);
    float t = clamp((n - 0.5) * 2.2 + 0.5, 0.0, 1.0);
    t = clamp(t * tfPreScale + tfPreOff, 0.0, 1.0);
    t = t * t * (3.0 - 2.0 * t) * 0.6 + t * 0.4;
    vec3 c1 = tfC1.rgb * tfBr1;
    vec3 pc = tfC0.rgb + tfOff0; float pp = 0.0; vec3 res = c1; float dn = 0.0;
    if (tfM3On > 0.5) { if (dn < 0.5) { if (t <= 0.2) { res = mix(pc, tfM3.rgb, t / 0.2); dn = 1.0; } else { pc = tfM3.rgb; pp = 0.2; } } }
    if (tfM2On > 0.5) { if (dn < 0.5) { if (t <= 0.45) { res = mix(pc, tfM2.rgb, (t - pp) / max(0.45 - pp, 0.001)); dn = 1.0; } else { pc = tfM2.rgb; pp = 0.45; } } }
    if (tfM1On > 0.5) { if (dn < 0.5) { if (t <= 0.7) { res = mix(pc, tfM1.rgb, (t - pp) / max(0.7 - pp, 0.001)); dn = 1.0; } else { pc = tfM1.rgb; pp = 0.7; } } }
    if (dn < 0.5) { res = mix(pc, c1, (t - pp) / max(1.0 - pp, 0.001)); }
    vec3 col = res * tfScale + tfOffD;
    vec3 hsv = rgb2hsv(max(col, vec3(0.0)));
    hsv.x = fract(hsv.x + tfHue);
    col = hsv2rgb(hsv);
    float gl = luma(col);
    col = max(mix(vec3(gl), col, tfSat), vec3(0.0));
    vec4 s = src(uv);
    vec3 bg = s.a > 0.0001 ? s.rgb / s.a * tfBgBr : vec3(0.0);
    vec3 r = col;
    if (tfCombine > 4.5) { r = mix(2.0 * bg * col, 1.0 - 2.0 * (1.0 - bg) * (1.0 - col), step(0.5, bg)); }
    else if (tfCombine > 3.5) { r = abs(bg - col); }
    else if (tfCombine > 2.5) { r = 1.0 - (1.0 - bg) * (1.0 - col); }
    else if (tfCombine > 1.5) { r = bg + col; }
    else if (tfCombine > 0.5) { r = bg * col; }
    float a = tfOutOp > 0.5 ? 1.0 : s.a;
    vec4 o = vec4(r * a, a);
    if (uHas0 > 0.5) {
        vec4 mk = in0(uv);
        float mm = tfMaskUse < 0.5 ? luma(mk.rgb) : mk.a;
        if (tfInvMask > 0.5) { mm = 1.0 - mm; }
        o = mix(s, o, mm);
    }
    return o;
"""))

    // MARK: Edge Rays
    out.append(EffectDef(
        id: "edgerays", name: "Edge Rays",
        desc: "Beams of light shooting out from the edges of the layer. Optional Background and Matte layers.",
        category: "Light and glow", props: [
            PropDef("erCX", "Center X", -2, 2, 0, 3),
            PropDef("erCY", "Center Y", -2, 2, 0, 3),
            PropDef("erLen", "Rays Length", -5, 3, 0.25, 3),
            PropDef("erLR", "Length Red", 0, 4, 1, 2),
            PropDef("erLG", "Length Green", 0, 4, 1, 2),
            PropDef("erLB", "Length Blue", 0, 4, 1, 2),
            PropDef("erRev", "Reverse Rays", 0, 2, 0, 2),
            PropDef("erBright", "Rays Brightness", 0, 20, 2, 2),
            PropDef("erDark", "Enable Dark Rays", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("erBias", "Bias Outer Bright", 0, 1, 0, 2),
            PropDef("erShow", "Show", 0, 2, 0, 0, ["Result", "Edges", "Rays"]),
            PropDef("erThick", "Edge Thickness", 0.002, 0.2, 0.022, 3),
            PropDef("erEdgeBr", "Edge Brightness", 0, 10, 1, 2),
            PropDef("erShAmp", "Shimmer Amp", 0, 1, 0.5, 2),
            PropDef("erShFreq", "Shimmer Freq", 0.1, 200, 40, 1),
            PropDef("erShSeed", "Shimmer Seed", 0, 100, 0.123, 3),
            PropDef("erShSX", "Shimmer Shift X", -100, 100, 0, 3),
            PropDef("erShSY", "Shimmer Shift Y", -100, 100, 0, 3),
            PropDef("erShVX", "Shimmer Speed X", -20, 20, 0, 3),
            PropDef("erShVY", "Shimmer Speed Y", -20, 20, 0, 3),
            PropDef("erAtmAmp", "Atmosphere Amp", 0, 2, 0, 2),
            PropDef("erAtmFreq", "Atmosphere Freq", 0.1, 20, 1, 2),
            PropDef("erAtmDet", "Atmosphere Detail", 0, 1, 0.6, 2),
            PropDef("erAtmSpd", "Atmosphere Speed", -10, 10, 1, 2),
            PropDef("erAffA", "Affect Alpha", 0, 4, 1, 2),
            PropDef("erFromA", "Rays From Alpha", 0, 1, 0, 2),
            PropDef("erUnder", "Rays Under Source", 0, 1, 0, 2),
            PropDef("erSrcOp", "Source Opacity", 0, 1, 1, 2),
            PropDef("erBgBr", "Bg Brightness", 0, 4, 1, 2),
            PropDef("erMType", "Matte Type", 0, 2, 0, 0, ["Luma", "Color", "Alpha"]),
            PropDef("erInvM", "Invert Matte", 0, 1, 0, 0, ["Off", "On"]),
        ], colors: [
            ColorParam("erCol", "Rays Color", Int32(bitPattern: 0xFFFFFFFF)),
        ], inputs: ["Background", "Matte"], glsl: """
    vec2 asp = vec2(uRes.x / uRes.y, 1.0);
    vec2 cen = vec2(0.5 + erCX * 0.5, 0.5 + erCY * 0.5);
    float eth = max(erThick, 0.002) * 0.5;
    float jit = hash21(floor(uv * uRes)) - 0.5;
    vec4 s0 = src(uv);
    vec3 rays = vec3(0.0);
    float lr = erLen * erLR; float lg = erLen * erLG; float lb = erLen * erLB;
    if (abs(lr - lg) + abs(lb - lg) < 0.0005) {
        \(rayLoop("rays", "", "lr"))
    } else {
        \(rayLoop("rays.r", ".r", "lr"))
        \(rayLoop("rays.g", ".g", "lg"))
        \(rayLoop("rays.b", ".b", "lb"))
    }
    rays = rays * erBright * 0.25;
    if (erAtmAmp > 0.0) {
        vec2 ap = (uv - cen) * asp * erAtmFreq * 3.0 + vec2(uTime * erAtmSpd * 0.3, -uTime * erAtmSpd * 0.17);
        float an = mix(vnoise(ap), fbm(ap), erAtmDet);
        rays *= max(1.0 + erAtmAmp * (an * 2.0 - 1.0) * 1.6, 0.0);
    }
    if (uHas1 > 0.5) {
        vec4 mt = in1(uv);
        if (erInvM > 0.5) { mt = vec4(1.0) - mt; }
        if (erMType < 0.5) { rays *= luma(mt.rgb); }
        else if (erMType < 1.5) { rays *= mt.rgb; }
        else { rays *= mt.a; }
    }
    if (erShow > 1.5) { return vec4(rays, clamp(max(max(rays.r, rays.g), rays.b), 0.0, 1.0)); }
    if (erShow > 0.5) {
        \(edgeAt("uv", "e0"))
        return vec4(e0, clamp(max(max(e0.r, e0.g), e0.b), 0.0, 1.0));
    }
    vec4 bgc = uHas0 > 0.5 ? in0(uv) * erBgBr : vec4(0.0);
    vec4 sc = s0 * erSrcOp;
    vec3 add = rays * erCol.rgb;
    vec3 base = sc.rgb + bgc.rgb * (1.0 - sc.a);
    vec3 rgbA = base + add;
    vec3 rgbB = sc.rgb + (bgc.rgb + add) * (1.0 - sc.a);
    vec3 rgb = mix(rgbA, rgbB, erUnder);
    if (erDark > 0.5 && luma(erCol.rgb) < 0.5) {
        vec3 dk = base * (vec3(1.0) - clamp(rays, 0.0, 1.0) * (vec3(1.0) - erCol.rgb));
        rgb = dk;
    }
    float ba = sc.a + bgc.a * (1.0 - sc.a);
    float ra = max(max(add.r, add.g), add.b) * erAffA;
    float a = clamp(ba + ra * (1.0 - ba), 0.0, 1.0);
    return vec4(rgb, a);
"""))
    return out
}
