// BuiltinsSapphire5.swift — S_Clouds, S_CloudsPsyko, S_Invert, S_Monochrome (Sapphire parameter docs).
// Mocha controls are not included. Pixel-based sizes use fxs = uRes.y / 1080 so the look matches at any preview/export size.

import Foundation

private func s5MaskProps(_ k: String) -> [PropDef] {
    [PropDef(k + "MaskUse", "Mask Use", 0, 1, 0, 0, ["Luma", "Alpha"]),
     PropDef(k + "InvMask", "Invert Mask", 0, 1, 0, 0, ["Off", "On"])]
}
/// Needs `vec4 s0` and `vec4 o` in scope.
private func s5MaskTail(_ k: String) -> String {
    """
        if (uHas0 > 0.5) {
            vec4 mk = in0(uv);
            float mm = \(k)MaskUse < 0.5 ? luma(mk.rgb) : mk.a;
            if (\(k)InvMask > 0.5) { mm = 1.0 - mm; }
            o = mix(s0, o, mm);
        }
        return o;
    """
}
/// Emits statements that define `float n` (0..1 cloud value) from the prefix's params.
private func s5Noise(_ k: String) -> String {
    """
        float asp = uRes.x / uRes.y;
        vec2 q = (uv - 0.5) * vec2(asp, 1.0) * \(k)Freq * 3.0 * vec2(\(k)FreqX, 1.0);
        q += vec2(\(k)ShX, \(k)ShY) + vec2(\(k)SpX, \(k)SpY) * uTime * 0.5 + vec2(\(k)Seed * 37.0, \(k)Seed * 11.0);
        float n = 0.0; float amp = 0.5; float tot = 0.0;
        for (int i = 0; i < 10; i++) {
            if (float(i) >= \(k)Oct) { break; }
            float fi = float(i);
            vec2 bo = vec2(0.0);
            if (\(k)Boil > 0.5) {
                float ang = hash11(fi * 7.13 + \(k)Seed) * 6.2831 + uTime * \(k)BSpd * (0.3 + \(k)BDet * fi * 0.35);
                bo = vec2(cos(ang), sin(ang)) * (0.6 + 0.2 * fi);
            }
            n += amp * vnoise(q + bo + vec2(fi * 17.3, fi * 9.1));
            tot += amp; amp *= 0.5; q *= 2.0;
        }
        n = clamp(n / max(tot, 0.0001) * 1.35 - 0.175, 0.0, 1.0);
    """
}
private let s5NoiseProps: (String, Float) -> [PropDef] = { k, seed in
    [PropDef(k + "Freq", "Frequency", 0.01, 30, 2, 2),
     PropDef(k + "FreqX", "Frequency Rel X", 0.01, 5, 0.4, 2),
     PropDef(k + "Oct", "Octaves", 1, 10, 8, 0),
     PropDef(k + "Seed", "Seed", 0, 100, seed, 3),
     PropDef(k + "Boil", "Boiling Mode", 0, 1, 0, 0, ["Off", "On"]),
     PropDef(k + "BDet", "Boil Details", 0, 1, 0.55, 2),
     PropDef(k + "BSpd", "Boil Speed", -10, 10, 1, 2),
     PropDef(k + "ShX", "Shift Start X", -50, 50, 0, 2),
     PropDef(k + "ShY", "Shift Start Y", -50, 50, 0, 2),
     PropDef(k + "SpX", "Shift Speed X", -10, 10, 0.5, 2),
     PropDef(k + "SpY", "Shift Speed Y", -10, 10, 0, 2)]
}
private func s5cat(_ parts: [PropDef]...) -> [PropDef] { parts.flatMap { $0 } }
private let s5CombineOpts = ["Clouds Only", "Mult", "Add", "Screen", "Difference", "Overlay"]
private func s5Combine(_ k: String) -> String {
    """
        vec4 s0 = src(uv);
        vec3 bg = (s0.a > 0.0001 ? s0.rgb / s0.a : vec3(0.0)) * \(k)BgBr;
        vec3 res = cl;
        if (\(k)Comb > 4.5) { res = mix(2.0 * bg * cl, 1.0 - 2.0 * (1.0 - bg) * (1.0 - cl), step(0.5, bg)); }
        else if (\(k)Comb > 3.5) { res = abs(bg - cl); }
        else if (\(k)Comb > 2.5) { res = 1.0 - (1.0 - bg) * (1.0 - cl); }
        else if (\(k)Comb > 1.5) { res = bg + cl; }
        else if (\(k)Comb > 0.5) { res = bg * cl; }
        float oa = \(k)OutOp > 0.5 ? s0.a : 1.0;
        vec4 o = vec4(max(res, vec3(0.0)) * oa, oa);
    """
}
private func s5CombineProps(_ k: String) -> [PropDef] {
    [PropDef(k + "BgBr", "Bg Brightness", 0, 4, 1, 2),
     PropDef(k + "Comb", "Combine", 0, 5, 0, 0, s5CombineOpts),
     PropDef(k + "OutOp", "Output Opacity", 0, 1, 1, 0, ["All Opaque", "Copy From Input"])]
}

func sapphire5Fx() -> [EffectDef] {
    var out: [EffectDef] = []

    // MARK: S_Clouds
    out.append(EffectDef(
        id: "sclouds", name: "S_Clouds",
        desc: "Procedural fractal noise texture colored between Color0 and Color1 (with optional mid colors). Shift Speed scrolls it, Boiling Mode evolves it.",
        category: "Generate",
        props: s5cat(s5NoiseProps("scl", 0.234), [
            PropDef("sclPreS", "Pre Scale Lights", 0, 4, 1, 2),
            PropDef("sclPreO", "Pre Offset Darks", -2, 2, 0, 2),
            PropDef("sclBr1", "Brightness1", 0, 4, 1, 2),
            PropDef("sclM1E", "Mid Color1 Enable", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("sclM2E", "Mid Color2 Enable", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("sclM3E", "Mid Color3 Enable", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("sclOff0", "Offset0", -2, 2, 0, 2),
            PropDef("sclScL", "Scale Lights", 0, 4, 1, 2),
            PropDef("sclOffD", "Offset Darks", -2, 2, 0, 2),
            PropDef("sclHue", "Hue Shift", -2, 2, 0, 2),
            PropDef("sclSat", "Saturation", -2, 8, 1, 2),
        ], s5CombineProps("scl"), s5MaskProps("scl")),
        colors: [ColorParam("sclC1", "Color1", Int32(bitPattern: 0xFFFFFFFF)),
                 ColorParam("sclM1", "Mid Color1", Int32(bitPattern: 0xFFB3B3B3)),
                 ColorParam("sclM2", "Mid Color2", Int32(bitPattern: 0xFF808080)),
                 ColorParam("sclM3", "Mid Color3", Int32(bitPattern: 0xFF333333)),
                 ColorParam("sclC0", "Color0", Int32(bitPattern: 0xFF000000))],
        inputs: ["Mask"], glsl: """
    \(s5Noise("scl"))
    n = clamp(n * sclPreS + sclPreO, 0.0, 1.0);
    vec3 c1 = sclC1.rgb * sclBr1; vec3 c0 = sclC0.rgb + sclOff0;
    vec3 m1 = sclM1E > 0.5 ? sclM1.rgb : mix(c0, c1, 0.75);
    vec3 m2 = sclM2E > 0.5 ? sclM2.rgb : mix(c0, c1, 0.5);
    vec3 m3 = sclM3E > 0.5 ? sclM3.rgb : mix(c0, c1, 0.25);
    vec3 cl;
    if (n < 0.25) { cl = mix(c0, m3, n * 4.0); }
    else if (n < 0.5) { cl = mix(m3, m2, (n - 0.25) * 4.0); }
    else if (n < 0.75) { cl = mix(m2, m1, (n - 0.5) * 4.0); }
    else { cl = mix(m1, c1, (n - 0.75) * 4.0); }
    cl = cl * sclScL + sclOffD * (1.0 - cl);
    if (abs(sclHue) > 0.0001) { vec3 h = rgb2hsv(max(cl, vec3(0.0))); h.x = fract(h.x + sclHue); cl = hsv2rgb(h) ; }
    cl = max(mix(vec3(luma(cl)), cl, sclSat), vec3(0.0));
    \(s5Combine("scl"))
    \(s5MaskTail("scl"))
"""))

    // MARK: S_CloudsPsyko
    out.append(EffectDef(
        id: "scloudspsyko", name: "S_CloudsPsyko",
        desc: "Procedural noise passed through a cosine colorizer. Shift Speed scrolls the pattern and Phase Speed rotates the colors over time.",
        category: "Generate",
        props: s5cat(s5NoiseProps("scp", 0.23), [
            PropDef("scpCF", "Color Freq", 0.01, 30, 4, 2),
            PropDef("scpFR", "Freq Red", 0, 4, 1, 2),
            PropDef("scpFG", "Freq Green", 0, 4, 1.1, 2),
            PropDef("scpFB", "Freq Blue", 0, 4, 1.2, 2),
            PropDef("scpPh", "Phase Start", -10, 10, -0.5, 2),
            PropDef("scpPS", "Phase Speed", -10, 10, 0.3, 2),
            PropDef("scpBr", "Brightness", 0, 4, 1, 2),
            PropDef("scpSat", "Saturation", 0, 4, 1, 2),
            PropDef("scpOff", "Offset", -1, 1, 0, 2),
        ], s5CombineProps("scp"), s5MaskProps("scp")),
        colors: [ColorParam("scpSC", "Scale Color", Int32(bitPattern: 0xFFFFFFFF))],
        inputs: ["Mask"], glsl: """
    \(s5Noise("scp"))
    float ph = scpPh + scpPS * uTime;
    vec3 cl = 0.5 + 0.5 * cos(6.2831853 * (n * scpCF * vec3(scpFR, scpFG, scpFB) + ph + vec3(0.0, 0.33, 0.67)));
    cl = max(mix(vec3(luma(cl)), cl, scpSat) * scpBr * scpSC.rgb + scpOff, vec3(0.0));
    \(s5Combine("scp"))
    \(s5MaskTail("scp"))
"""))

    // MARK: S_Invert
    out.append(EffectDef(
        id: "sinvert", name: "S_Invert",
        desc: "Inverts the clip: luma, chroma, red, green, blue and alpha can be inverted independently, with basic grading of the inverted result.",
        category: "Color",
        props: [
            PropDef("sivLuma", "Invert Luma", 0, 1, 1, 0, ["Off", "On"]),
            PropDef("sivChr", "Invert Chroma", 0, 1, 1, 0, ["Off", "On"]),
            PropDef("sivR", "Invert Red", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("sivG", "Invert Green", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("sivB", "Invert Blue", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("sivA", "Invert Alpha", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("sivRem", "Remult By Alpha", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("sivSL", "Scale Lights", 0, 4, 1, 2),
            PropDef("sivOD", "Offset Darks", -2, 2, 0, 2),
            PropDef("sivSat", "Saturation", -2, 8, 1, 2),
        ] + s5MaskProps("siv"),
        colors: [ColorParam("sivTL", "Tint Lights", Int32(bitPattern: 0xFFFFFFFF)),
                 ColorParam("sivTD", "Tint Darks", Int32(bitPattern: 0xFF000000))],
        inputs: ["Mask"], glsl: """
    vec4 s0 = src(uv);
    vec3 c = s0.a > 0.0001 ? s0.rgb / s0.a : vec3(0.0);
    float y = luma(c); vec3 ch = c - vec3(y);
    float y2 = sivLuma > 0.5 ? 1.0 - y : y;
    vec3 ch2 = sivChr > 0.5 ? -ch : ch;
    vec3 r = vec3(y2) + ch2;
    if (sivR > 0.5) { r.r = 1.0 - r.r; }
    if (sivG > 0.5) { r.g = 1.0 - r.g; }
    if (sivB > 0.5) { r.b = 1.0 - r.b; }
    float a = sivA > 0.5 ? 1.0 - s0.a : s0.a;
    r = r * sivSL * sivTL.rgb + sivTD.rgb * (1.0 - clamp(r, 0.0, 1.0)) + sivOD * (1.0 - clamp(r, 0.0, 1.0));
    r = mix(vec3(luma(r)), r, sivSat);
    r = max(r, vec3(0.0));
    if (sivRem > 0.5) { r *= a; }
    vec4 o = vec4(r * a, a);
    \(s5MaskTail("siv"))
"""))

    // MARK: S_Monochrome
    out.append(EffectDef(
        id: "smonochrome", name: "S_Monochrome",
        desc: "Black and white using adjustable red/green/blue weights, like a color filter on a B&W camera. Weights are normalised to sum to 1.",
        category: "Color",
        props: [
            PropDef("smoR", "Weight Red", -1, 1, 0.3, 2),
            PropDef("smoG", "Weight Green", -1, 1, 0.5, 2),
            PropDef("smoB", "Weight Blue", -1, 1, 0.2, 2),
            PropDef("smoBr", "Brightness", 0, 4, 1, 2),
            PropDef("smoMix", "Mix With Source", 0, 1, 0, 2),
        ] + s5MaskProps("smo"), inputs: ["Mask"], glsl: """
    vec4 s0 = src(uv);
    vec3 c = s0.a > 0.0001 ? s0.rgb / s0.a : vec3(0.0);
    float sm = smoR + smoG + smoB;
    vec3 w = abs(sm) > 0.0001 ? vec3(smoR, smoG, smoB) / sm : vec3(0.3, 0.5, 0.2);
    float g = max(dot(c, w) * smoBr, 0.0);
    vec3 r = mix(vec3(g), c, smoMix);
    vec4 o = vec4(r * s0.a, s0.a);
    \(s5MaskTail("smo"))
"""))

    return out
}
