// BuiltinsUniverse3.swift — uni.Glo Fi II, uni.Ecto, uni.Carousel and their dashboard presets (from the Universe docs).
// Resolve node steps / Unmult-host options are not needed here; Ecto has its own Unmult switch.

import Foundation

typealias GofiScheme = (String, UInt32, UInt32, UInt32)
let gofiSchemes: [GofiScheme] = [
    ("Chlorophyll", 0xFFB8FFB0, 0xFF3FCB4A, 0xFF0B5A1E), ("Nostalgic", 0xFFFFE066, 0xFFFF6FA8, 0xFF5B2A9A),
    ("Ice", 0xFFE8FBFF, 0xFF6CC8FF, 0xFF1A4FA8), ("Warm", 0xFFFFF0B0, 0xFFFF9A3A, 0xFFB01E1E),
    ("Ember", 0xFFFFD27A, 0xFFFF5A1F, 0xFF4A0E0E), ("Ocean", 0xFFB8F3FF, 0xFF1FA7C9, 0xFF0A2E6B),
    ("Sunset", 0xFFFFE0A0, 0xFFFF5E8A, 0xFF5A1E8C), ("Neon", 0xFFFFFFFF, 0xFFFF2BD6, 0xFF2B2BFF),
    ("Mono", 0xFFFFFFFF, 0xFFA0A0A0, 0xFF303030), ("Royal", 0xFFE6D0FF, 0xFF8A4BFF, 0xFF2A0F66),
    ("Toxic", 0xFFF4FF8A, 0xFF9AE600, 0xFF2A5A00), ("Candy", 0xFFFFD6F0, 0xFFFF8AD0, 0xFF7A5CFF),
]
let ectoColors: [(String, UInt32, UInt32)] = [
    ("Aqualight", 0xFFE8FFFF, 0xFF3FD0E0), ("Chroma", 0xFFA0FF70, 0xFF00B000), ("Cool", 0xFFD8E0FF, 0xFF3050FF),
    ("Phantom", 0xFFFFFFFF, 0xFFB0B0B0), ("Proton Beam", 0xFFFFA0FF, 0xFFE020D0), ("Slimer", 0xFFC0FFC0, 0xFF20B040),
    ("The Twinkle", 0xFFFFE070, 0xFFFF7A00), ("Warm", 0xFFFF8070, 0xFFE01010),
]
let ectoLooks: [(String, UInt32, UInt32, Float)] = [
    ("A Ghost", 0xFFFFFFFF, 0xFF6A6AFF, 0), ("Baja Blast", 0xFFA0FF90, 0xFF00D020, 2), ("Castle Byers", 0xFFFF9080, 0xFFFF1010, 1),
    ("Dry Ice", 0xFFE0FFFF, 0xFF30B0FF, 0), ("Film Glow", 0xFFE0E8FF, 0xFF4060FF, 0), ("Flame Outlines", 0xFFFFE060, 0xFFFF3000, 3),
    ("Flames", 0xFFFFC060, 0xFFFF2000, 3), ("Ghost Wind", 0xFFE0D0FF, 0xFF6030FF, 0), ("Golden State", 0xFFFFE9A0, 0xFFFFA000, 1),
    ("Green Laser", 0xFFA0FFA0, 0xFF00E040, 2), ("Heat Haze", 0xFFFFE0A0, 0xFFFF4000, 3), ("Hot Neon", 0xFFFFC8E8, 0xFFFF2080, 2),
    ("Infection", 0xFFFFE080, 0xFFFF6000, 1), ("Ladyhawke", 0xFFFFA090, 0xFFD01010, 1), ("Laser Whip", 0xFFFFB090, 0xFFFF3010, 2),
    ("Lightning", 0xFFE8E8FF, 0xFF3030FF, 2), ("Limelight", 0xFFE0FFF8, 0xFF30D0C0, 0), ("Neon Glow", 0xFFFFA0F0, 0xFFD020D0, 2),
    ("Optical Glow", 0xFFFFFFFF, 0xFF7080FF, 0), ("Outline", 0xFFC8D8FF, 0xFF2060FF, 2), ("Outrun", 0xFFFFA0E0, 0xFFFF10A0, 2),
    ("Poltergeist", 0xFFFFFFFF, 0xFF4A5AFF, 1), ("Smokey", 0xFFFFFFFF, 0xFF6060E0, 1), ("Space Coast", 0xFFFFFFFF, 0xFF30C8FF, 0),
    ("The Deep", 0xFFA0FFE8, 0xFF00B090, 0), ("The Librarian", 0xFFE0A0FF, 0xFF8020FF, 1),
]
private func vf(_ c: UInt32) -> String {
    String(format: "vec3(%.3f, %.3f, %.3f)", Float((c >> 16) & 255) / 255, Float((c >> 8) & 255) / 255, Float(c & 255) / 255)
}
private let blendOpts = ["Normal", "Add", "Screen", "Multiply", "Difference"]
/// GLSL: `vec3 out` = a blended with b by float `m`.
private func blendCode(_ m: String, _ a: String, _ b: String, _ out: String) -> String {
    """
        vec3 \(out) = \(b);
        if (\(m) > 3.5) { \(out) = abs(\(a) - \(b)); } else if (\(m) > 2.5) { \(out) = \(a) * \(b); }
        else if (\(m) > 1.5) { \(out) = 1.0 - (1.0 - \(a)) * (1.0 - \(b)); } else if (\(m) > 0.5) { \(out) = \(a) + \(b); }
    """
}
/// GLSL: declares `float out` = fractal value (0..1) at point expression p.
private func fractal(_ out: String, _ p: String) -> String {
    """
        float \(out) = 0.0; float \(out)_a = 0.5; float \(out)_t = 0.0; vec2 \(out)_q = \(p);
        for (int i = 0; i < 10; i++) {
            if (float(i) >= ecCx) { break; }
            \(out) += \(out)_a * vnoise(\(out)_q); \(out)_t += \(out)_a; \(out)_a *= mix(0.35, 0.65, ecDet / 300.0); \(out)_q = \(out)_q * 2.03 + 5.1;
        }
        \(out) = \(out) / max(\(out)_t, 0.0001);
        float \(out)_r = 1.0 - abs(2.0 * \(out) - 1.0);
        \(out) = ecPat < 0.5 ? \(out) : (ecPat < 1.5 ? 0.5 + 0.5 * sin(\(out) * 12.0) : (ecPat < 2.5 ? \(out)_r : \(out)_r * \(out)_r));
    """
}

func universe3Fx() -> [EffectDef] {
    var out: [EffectDef] = []

    // MARK: uni.Glo Fi II
    var gfPick = ""
    for (i, s) in gofiSchemes.enumerated() {
        gfPick += "    \(i == 0 ? "if" : "else if") (gfMap < \(Float(i) + 1.5)) { hi = \(vf(s.1)); mid = \(vf(s.2)); sh = \(vf(s.3)); }\n"
    }
    out.append(EffectDef(
        id: "ugofi", name: "uni.Glo Fi II",
        desc: "Self-animating fractal glow for text: Gaussian bloom plus a horizontal/vertical streak, colorized by highlights/midtones/shadows. Open the Dashboard for 36 presets.",
        category: "Universe", props: [
            PropDef("gfMap", "Color Map", 0, 12, 0, 0, ["Custom"] + gofiSchemes.map { $0.0 }),
            PropDef("gfLoop", "Loop Duration (Sec)", 0.5, 60, 6, 1),
            PropDef("gfSpeed", "Speed", 0, 5, 1, 2),
            PropDef("gfBright", "Brightness", 0, 4, 1.5, 2),
            PropDef("gfBoost", "Boost", 0, 4, 1, 2),
            PropDef("gfDir", "Directional Blur", 0, 2, 0, 0, ["None", "Horizontal", "Vertical"]),
            PropDef("gfGSize", "Gaussian Blur Size", 0, 200, 60, 1),
            PropDef("gfGMix", "Gaussian Blur Mix", 0, 100, 70, 1),
            PropDef("gfSSize", "Streak Blur Size", 0, 200, 40, 1),
            PropDef("gfSMix", "Streak Blur Mix", 0, 100, 100, 1),
            PropDef("gfSat", "Saturation", 0, 200, 100, 1),
            PropDef("gfPost", "Post Glow", 0, 4, 0.5, 2),
            PropDef("gfCon", "Contrast", 0, 4, 1.5, 2),
            PropDef("gfScale", "Scale", 0, 1000, 100, 0),
            PropDef("gfSX", "Scroll X", -50, 50, 0, 2),
            PropDef("gfSY", "Scroll Y", -50, 50, 0, 2),
            PropDef("gfSeed", "Random Seed", 0, 100, 1, 0),
            PropDef("gfMix", "Glow Mix", 0, 100, 100, 1),
            PropDef("gfHDR", "Allow HDR Results", 0, 1, 0, 0, ["Off", "On"]),
        ],
        colors: [ColorParam("gfHi", "Highlights", Int32(bitPattern: gofiSchemes[0].1)),
                 ColorParam("gfMd", "Midtones", Int32(bitPattern: gofiSchemes[0].2)),
                 ColorParam("gfSh", "Shadows", Int32(bitPattern: gofiSchemes[0].3))],
        glsl: """
    vec4 s0 = src(uv);
    float asp = uRes.x / uRes.y; float fxs = uRes.y / 1080.0; vec2 px = vec2(1.0) / uRes;
    vec3 hi = gfHi.rgb; vec3 mid = gfMd.rgb; vec3 sh = gfSh.rgb;
    if (gfMap > 0.5) {
    \(gfPick)    }
    float jit = 0.5 + (hash21(uv * uRes) - 0.5) * 0.12;
    float R = gfGSize * 1.5 * fxs; float RS = gfSSize * 3.0 * fxs;
    float gs = 0.0; float gw = 0.0; float ss = 0.0; float sw = 0.0;
    vec2 ax = gfDir > 1.5 ? vec2(0.0, 1.0) : vec2(1.0, 0.0);
    for (int i = 0; i < 24; i++) {
        float f = (float(i) + jit) / 24.0;
        float an = float(i) * 2.39996 + jit * 6.2831853;
        float w = 1.0 - sqrt(f);
        gs += luma(src(uv + vec2(cos(an), sin(an)) * sqrt(f) * R * px).rgb) * w; gw += w;
        float s = f * 2.0 - 1.0; float w2 = exp(-abs(s) * 3.0);
        ss += luma(src(uv + ax * s * RS * px).rgb) * w2; sw += w2;
    }
    float gb = gs / max(gw, 0.0001) * gfGMix / 100.0;
    float sb = gfDir > 0.5 ? ss / max(sw, 0.0001) * gfSMix / 100.0 * 1.5 : 0.0;
    float tt = uTime * gfSpeed * 6.2831853 / max(gfLoop, 0.1);
    vec2 pc = vec2(cos(tt), sin(tt)) * 0.7;
    vec2 pp = (uv - 0.5) * vec2(asp, 1.0) * gfScale / 100.0 * 3.0 + vec2(gfSX, gfSY) + gfSeed * 17.0 + pc;
    float pn = fbm(pp) * 0.65 + fbm(pp * 2.0 + pc.yx * 1.3) * 0.35;
    float pat = mix(1.0, 0.35 + 1.3 * clamp((pn - 0.5) * gfCon + 0.5, 0.0, 1.0), step(0.5, gfScale));
    float e = (gb + sb) * gfBright * gfBoost * pat;
    float tc = clamp(e, 0.0, 1.0);
    vec3 col = tc < 0.5 ? mix(sh, mid, tc * 2.0) : mix(mid, hi, (tc - 0.5) * 2.0);
    col = mix(vec3(luma(col)), col, gfSat / 100.0);
    vec3 gl2 = col * min(e * 1.5, gfHDR > 0.5 ? 4.0 : 1.0);
    gl2 += hi * pow(tc, 3.0) * gfPost;
    vec3 g = gl2 * gfMix / 100.0;
    vec3 res = s0.rgb + g;
    if (gfHDR < 0.5) { res = min(res, vec3(1.0)); }
    return vec4(res, min(max(s0.a, max(g.r, max(g.g, g.b))), 1.0));
"""))

    // MARK: uni.Ecto
    var ecPick = ""
    for (i, c) in ectoColors.enumerated() {
        ecPick += "    \(i == 0 ? "if" : "else if") (ecPre < \(Float(i) + 1.5)) { cIn = \(vf(c.1)); cOut = \(vf(c.2)); }\n"
    }
    out.append(EffectDef(
        id: "uecto", name: "uni.Ecto",
        desc: "Ghostly, electric or fiery glow for text with an animated fractal distortion field and dancing flames. Open the Dashboard for 34 presets.",
        category: "Universe", props: [
            PropDef("ecUn", "Unmult", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("ecTS", "Tint Strength", 0, 100, 0, 1),
            PropDef("ecDS", "Distort Source", 0, 100, 50, 1),
            PropDef("ecDD", "Distort Detail", 0, 100, 20, 1),
            PropDef("ecPL", "Preserve Luma", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("ecInt", "Glow Intensity", 0, 10, 3, 2),
            PropDef("ecDist", "Distortion", 0, 100, 40, 1),
            PropDef("ecSize", "Size", 1, 100, 20, 1),
            PropDef("ecPre", "Color Preset", 0, 8, 0, 0, ["Custom"] + ectoColors.map { $0.0 }),
            PropDef("ecGS", "Glow Color from Source", 0, 100, 0, 1),
            PropDef("ecCon", "Contrast", 0, 100, 50, 1),
            PropDef("ecIT", "Inner Thickness", 0, 2, 1, 2),
            PropDef("ecOT", "Outer Thickness", 0, 2, 1, 2),
            PropDef("ecFill", "Fill", 0, 100, 100, 1),
            PropDef("ecII", "Inner Intensity", 0, 100, 100, 1),
            PropDef("ecOI", "Outer Intensity", 0, 100, 100, 1),
            PropDef("ecSW", "Spill Width", 0, 5, 2, 2),
            PropDef("ecSI", "Spill Intensity", 0, 10, 1, 2),
            PropDef("ecSS", "Spill Source", 0, 2, 0, 0, ["Inner Color", "Outer Color", "Source"]),
            PropDef("ecSF", "Spill Soften", 0, 100, 50, 1),
            PropDef("ecNoise", "Noise", 0, 100, 0, 1),
            PropDef("ecOX", "Offset Position X", -0.5, 0.5, 0, 3),
            PropDef("ecOY", "Offset Position Y", -0.5, 0.5, 0, 3),
            PropDef("ecIB", "Internal Blend", 0, 4, 0, 0, blendOpts),
            PropDef("ecPat", "Pattern", 0, 3, 0, 0, ["Clouds", "Plasma", "Electric", "Brimstone"]),
            PropDef("ecCx", "Complexity", 1, 10, 5, 0),
            PropDef("ecScale", "Scale", 1, 100, 30, 1),
            PropDef("ecDet", "Detail", 1, 300, 231, 0),
            PropDef("ecAsp", "Aspect", 0, 10, 0, 2),
            PropDef("ecDir", "Direction", -360, 360, 90, 1),
            PropDef("ecFlow", "Flow", 0, 100, 24, 1),
            PropDef("ecEvo", "Evolution", 0, 100, 71, 1),
            PropDef("ecPS", "Pulse Speed", 0, 50, 5, 1),
            PropDef("ecPI", "Pulse Intensity", 0, 100, 0, 1),
            PropDef("ecMask", "Use Mask", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("ecMShape", "Mask Shape", 0, 1, 0, 0, ["Ellipse", "Rectangle"]),
            PropDef("ecMX", "Mask Position X", -0.5, 1.5, 0.5, 3),
            PropDef("ecMY", "Mask Position Y", -0.5, 1.5, 0.5, 3),
            PropDef("ecMW", "Mask Width", 0, 3, 0.8, 3),
            PropDef("ecMH", "Mask Height", 0, 3, 0.5, 3),
            PropDef("ecMA", "Mask Angle", -360, 360, 0, 1),
            PropDef("ecFe", "Mask Feather Size", 0, 100, 20, 1),
            PropDef("ecMInv", "Mask Invert", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("ecMS", "Mask Spill", 0, 1, 0, 0, ["Off", "On"]),
            PropDef("ecGO", "Glow Opacity", 0, 100, 100, 1),
            PropDef("ecSO", "Source Opacity", 0, 100, 100, 1),
            PropDef("ecBM", "Blend Mode", 0, 4, 0, 0, blendOpts),
            PropDef("ecGB", "Glow Behind", 0, 1, 1, 0, ["Off", "On"]),
        ],
        colors: [ColorParam("ecTint", "Tint", Int32(bitPattern: 0xFFFF2020)),
                 ColorParam("ecIn", "Inner Color", Int32(bitPattern: 0xFFE0E8FF)),
                 ColorParam("ecOut", "Outer Color", Int32(bitPattern: 0xFF3060FF))],
        glsl: """
    vec4 s0 = src(uv);
    float asp = uRes.x / uRes.y; float fxs = uRes.y / 1080.0; float t = uTime;
    vec3 cIn = ecIn.rgb; vec3 cOut = ecOut.rgb;
    if (ecPre > 0.5) {
    \(ecPick)    }
    vec2 dirv = vec2(cos(radians(ecDir)), sin(radians(ecDir)));
    vec2 p0 = (uv - 0.5) * vec2(asp * (1.0 + ecAsp), 1.0) * 120.0 / max(ecScale, 1.0)
            + dirv * ecFlow * t * 0.05 + vec2(sin(t * ecEvo * 0.05), cos(t * ecEvo * 0.05)) * 2.0;
    \(fractal("fa", "p0"))
    \(fractal("fb", "p0 + vec2(7.3, 3.1)"))
    vec2 dv = vec2(fa, fb) - 0.5;
    vec4 sc = src(uv + dv * (ecDS / 100.0) * (ecDD / 100.0 + 0.1) * 0.15);
    if (ecUn > 0.5) { sc = vec4(sc.rgb, max(max(sc.r, sc.g), sc.b)); }
    vec3 su = sc.rgb / max(sc.a, 0.0001);
    vec3 tcol = mix(su, ecTint.rgb * (ecPL > 0.5 ? luma(su) / max(luma(ecTint.rgb), 0.05) : 1.0), ecTS / 100.0);
    float R = ecSize * 3.0 * fxs; vec2 px = vec2(1.0) / uRes;
    float jit = hash21(uv * uRes);
    vec2 cen = uv - vec2(ecOX, ecOY) + dv * ecNoise / 100.0 * 0.05;
    float ai = 0.0; float ni = 0.0; float ao = 0.0; float wo = 0.0; vec3 acol = vec3(0.0);
    for (int i = 0; i < 24; i++) {
        float f = (float(i) + jit) / 24.0; float rf = sqrt(f);
        float an = float(i) * 2.39996 + jit * 6.2831853;
        vec4 t4 = src(cen + vec2(cos(an), sin(an)) * rf * R * px + dv * ecDist / 100.0 * 0.12);
        float v = ecUn > 0.5 ? max(max(t4.r, t4.g), t4.b) : t4.a;
        float w = (1.0 - rf) + 0.05;
        if (rf < 0.4) { ai += v; ni += 1.0; }
        ao += v * w; wo += w; acol += t4.rgb * w;
    }
    float inn = ai / max(ni, 1.0); float outv = ao / max(wo, 0.0001);
    vec3 scol = acol / max(wo, 0.0001); scol = scol / max(max(scol.r, max(scol.g, scol.b)), 0.0001);
    float ig = 1.0 + ecInt * ecInt * 0.12;
    float pul = 1.0 + ecPI / 100.0 * (0.5 + 0.5 * sin(t * ecPS));
    float gi = clamp(inn * (1.0 + ecIT * 2.0) * ig * pul, 0.0, 1.0);
    float go = clamp(outv * (1.0 + ecOT * 2.0) * ig, 0.0, 1.0);
    gi = clamp((gi - 0.5) * (ecCon / 50.0) + 0.5, 0.0, 1.0) * step(0.001, inn);
    go = clamp((go - 0.5) * (ecCon / 50.0) + 0.5, 0.0, 1.0) * step(0.001, outv);
    vec3 cI = mix(cIn, scol, ecGS / 100.0); vec3 cO = mix(cOut, scol, ecGS / 100.0);
    vec3 gl3 = (cI * gi * ecII / 100.0 + cO * go * ecOI / 100.0 * (1.0 - gi)) * ecFill / 100.0;
    gl3 *= 1.0 + (hash21(uv * uRes + t) - 0.5) * ecNoise / 100.0 * 0.5;
    float m = 1.0;
    if (ecMask > 0.5) {
        vec2 p = (uv - vec2(ecMX, ecMY)) * vec2(asp, 1.0);
        float ca = cos(radians(ecMA)); float sa = sin(radians(ecMA));
        p = vec2(ca * p.x + sa * p.y, -sa * p.x + ca * p.y);
        float hw = max(ecMW * 0.5, 0.001); float hh = max(ecMH * 0.5, 0.001);
        float dd = ecMShape < 0.5 ? length(p / vec2(hw, hh)) : max(abs(p.x) / hw, abs(p.y) / hh);
        float fe = ecFe / 100.0 * 0.5 + 0.002;
        m = 1.0 - smoothstep(1.0 - fe, 1.0 + fe, dd);
        if (ecMInv > 0.5) { m = 1.0 - m; }
        gl3 *= m;
        if (ecMS > 0.5) { su *= m; }
    }
    float sp = clamp(go * ecSW * 0.4, 0.0, 1.0) * (1.0 - ecSF / 100.0 * 0.7) * sc.a;
    vec3 spc = (ecSS < 0.5 ? cI : (ecSS < 1.5 ? cO : tcol)) * ecSI;
    \(blendCode("ecIB", "tcol", "spc", "bl"))
    vec3 sres = mix(tcol, bl, sp) * (ecMS > 0.5 ? m : 1.0);
    vec4 so = vec4(sres * sc.a * ecSO / 100.0, sc.a * ecSO / 100.0);
    float ga = clamp(max(gl3.r, max(gl3.g, gl3.b)), 0.0, 1.0) * ecGO / 100.0;
    vec4 g = vec4(gl3 * ecGO / 100.0, ga);
    vec4 o = ecGB > 0.5 ? so + g * (1.0 - so.a) : g + so * (1.0 - g.a);
    if (ecBM > 3.5) { o = vec4(abs(so.rgb - g.rgb), max(so.a, g.a)); }
    else if (ecBM > 2.5) { o = vec4(so.rgb * g.rgb + so.rgb * (1.0 - g.a), max(so.a, g.a)); }
    else if (ecBM > 1.5) { o = vec4(1.0 - (1.0 - so.rgb) * (1.0 - g.rgb), max(so.a, g.a)); }
    else if (ecBM > 0.5) { o = so + g; }
    return vec4(min(o.rgb, vec3(1.0)), min(o.a, 1.0));
"""))

    // MARK: uni.Carousel
    out.append(EffectDef(
        id: "ucarousel", name: "uni.Carousel",
        desc: "Vintage cross-processing, film fading, vignette and light leaks inside a slide-projector frame. Open the Dashboard for 10 presets.",
        category: "Universe", props: [
            PropDef("caFr", "Frame Style", 0, 4, 0, 0, ["16x9", "Square", "16x9 Soft", "Square Soft", "None"]),
            PropDef("caOff", "Image Offset", -100, 100, 0, 1),
            PropDef("caVig", "Vignette Amount", 0, 100, 40, 1),
            PropDef("caProc", "Color Process", 0, 100, 50, 1),
            PropDef("caR", "Red", 0, 100, 60, 1),
            PropDef("caG", "Green", 0, 100, 40, 1),
            PropDef("caB", "Blue", 0, 100, 70, 1),
            PropDef("caFade", "Fading", 0, 100, 30, 1),
            PropDef("caCon", "Contrast", 0, 2, 1.1, 2),
            PropDef("caLS", "Light Style", 0, 5, 1, 0, ["None", "Left", "Right", "Top", "Bottom", "Both Sides"]),
            PropDef("caOp", "Light Opacity", 0, 100, 60, 1),
            PropDef("caFS", "Flicker Strength", 0, 100, 25, 1),
            PropDef("caFSp", "Flicker Speed", 0, 30, 6, 1),
            PropDef("caFlip", "Flip Light Leak", 0, 1, 0, 0, ["Off", "On"]),
        ],
        colors: [ColorParam("caLC", "Light Color", Int32(bitPattern: 0xFFFF9A50))],
        glsl: """
    float asp = uRes.x / uRes.y; float t = uTime;
    vec4 s0 = src(uv);
    vec4 c0 = src(vec2(uv.x - caOff / 100.0 * 0.25, uv.y));
    vec3 c = c0.rgb / max(c0.a, 0.0001);
    vec3 cr = vec3(c.r * c.r * (3.0 - 2.0 * c.r), mix(c.g, c.g * c.g * (3.0 - 2.0 * c.g), 0.5) + 0.03, c.b * 0.78 + 0.16);
    cr = mix(cr, vec3(cr.r * 1.08, cr.g, cr.b * 1.1), 0.5);
    vec3 wgt = vec3(caR, caG, caB) / 100.0 * caProc / 100.0;
    c = mix(c, cr, clamp(wgt, 0.0, 1.0));
    c = mix(c, c * 0.72 + 0.24, caFade / 100.0);
    c = (c - 0.5) * caCon + 0.5;
    vec2 lu = vec2(caFlip > 0.5 ? 1.0 - uv.x : uv.x, uv.y);
    float ed = caLS < 1.5 ? lu.x : (caLS < 2.5 ? 1.0 - lu.x : (caLS < 3.5 ? lu.y : (caLS < 4.5 ? 1.0 - lu.y : min(lu.x, 1.0 - lu.x))));
    float leak = caLS < 0.5 ? 0.0 : exp(-ed * 4.0) * (0.6 + 0.8 * fbm(vec2(lu.y * 3.0 + lu.x * 2.0, t * 0.2)));
    float fl = 1.0 + caFS / 100.0 * (hash11(floor(t * caFSp)) - 0.5) * 2.0;
    c += caLC.rgb * leak * caOp / 100.0 * fl;
    bool sq = caFr > 0.5 && caFr < 1.5 || caFr > 2.5 && caFr < 3.5;
    float fa = sq ? 1.0 : 1.7777778;
    vec2 hf = asp > fa ? vec2(fa / asp * 0.5, 0.5) : vec2(0.5, asp / fa * 0.5);
    if (caFr > 3.5) { hf = vec2(0.5); }
    vec2 pa = (uv - 0.5) * vec2(asp, 1.0); vec2 hh = hf * vec2(asp, 1.0);
    float cr2 = 0.04; float sft = (caFr > 1.5 && caFr < 2.5 || caFr > 2.5 && caFr < 3.5) ? 0.04 : 0.003;
    vec2 qd = abs(pa) - hh + cr2;
    float dd = length(max(qd, 0.0)) + min(max(qd.x, qd.y), 0.0) - cr2;
    float fm = caFr > 3.5 ? 1.0 : 1.0 - smoothstep(-sft, sft, dd + sft);
    float dn = length(pa / max(hh, vec2(0.001)));
    float vg = 1.0 - caVig / 100.0 * smoothstep(0.55, 1.4, dn);
    return vec4(max(c, vec3(0.0)) * fm * vg * s0.a, s0.a);
"""))
    return out
}

extension UniversePresets {
    static let gofi: [UniversePreset] = {
        var l: [UniversePreset] = []
        for (d, tag) in [(0, ""), (1, "H "), (2, "V ")] {
            for s in gofiSchemes {
                l.append(UniversePreset(name: tag + s.0, vals: ["gfDir": Float(d), "gfMap": 0],
                                        cols: ["gfHi": s.1, "gfMd": s.2, "gfSh": s.3], tint: s.2, bloom: 1.3))
            }
        }
        return l
    }()
    static let ecto: [UniversePreset] = {
        var l: [UniversePreset] = []
        for c in ectoColors {
            l.append(UniversePreset(name: c.0, cols: ["ecIn": c.1, "ecOut": c.2], tint: c.2, bloom: 1.2))
        }
        for k in ectoLooks {
            let wild: Float = k.3 == 0 ? 20 : (k.3 == 2 ? 30 : 65)
            l.append(UniversePreset(name: k.0, vals: ["ecPat": k.3, "ecDist": wild, "ecFlow": k.3 == 3 ? 40 : 24],
                                    cols: ["ecIn": k.1, "ecOut": k.2], tint: k.2, bloom: 1.2))
        }
        return l
    }()
    static let carousel: [UniversePreset] = [
        UniversePreset(name: "Acid Stardust", vals: ["caFr": 1, "caProc": 80, "caR": 70, "caG": 60, "caB": 40, "caFade": 45, "caLS": 5, "caOp": 70], cols: ["caLC": 0xFFFFD890], tint: 0xFF301808, bloom: 0),
        UniversePreset(name: "Electric Vision", vals: ["caFr": 2, "caProc": 70, "caR": 40, "caG": 50, "caB": 90, "caVig": 55, "caLS": 1, "caOp": 75], cols: ["caLC": 0xFFFF70A0], tint: 0xFF180830, bloom: 0),
        UniversePreset(name: "Enchanted Light", vals: ["caFr": 2, "caProc": 45, "caFade": 40, "caLS": 1, "caOp": 85], cols: ["caLC": 0xFFFFB060], tint: 0xFF302008, bloom: 0),
        UniversePreset(name: "Mars Eyes", vals: ["caFr": 2, "caProc": 60, "caR": 90, "caG": 30, "caB": 30, "caLS": 1, "caOp": 70], cols: ["caLC": 0xFFFF6040], tint: 0xFF301008, bloom: 0),
        UniversePreset(name: "Pink Dahlias", vals: ["caFr": 4, "caProc": 55, "caR": 80, "caG": 30, "caB": 70, "caFade": 35, "caLS": 1, "caOp": 70], cols: ["caLC": 0xFFFF90B0], tint: 0xFF301020, bloom: 0),
        UniversePreset(name: "Rose Clouds", vals: ["caFr": 3, "caProc": 40, "caR": 70, "caG": 40, "caB": 60, "caFade": 55, "caLS": 5, "caOp": 55], cols: ["caLC": 0xFFFFB0C0], tint: 0xFF281018, bloom: 0),
        UniversePreset(name: "Strawberry Lemonade", vals: ["caFr": 2, "caProc": 50, "caR": 80, "caG": 60, "caB": 30, "caLS": 1, "caOp": 80], cols: ["caLC": 0xFFFFD060], tint: 0xFF301808, bloom: 0),
        UniversePreset(name: "Summer Goth", vals: ["caFr": 1, "caProc": 75, "caR": 50, "caG": 30, "caB": 90, "caVig": 60, "caFade": 40, "caLS": 5, "caOp": 55], cols: ["caLC": 0xFFB090FF], tint: 0xFF201038, bloom: 0),
        UniversePreset(name: "Tiger Dream", vals: ["caFr": 2, "caProc": 55, "caR": 80, "caG": 60, "caB": 20, "caFade": 35, "caLS": 1, "caOp": 85], cols: ["caLC": 0xFFFFA030], tint: 0xFF302008, bloom: 0),
        UniversePreset(name: "Waves of Azul", vals: ["caFr": 2, "caProc": 65, "caR": 20, "caG": 60, "caB": 90, "caVig": 50, "caLS": 2, "caOp": 60], cols: ["caLC": 0xFF50B0FF], tint: 0xFF082030, bloom: 0),
    ]
    static let words: [String: String] = ["uecto": "Ecto", "ugofi": "Glo Fi"]
    static let thumbRes: [String: String] = ["ucarousel": "fx_woman", "uedge": "fx_girl", "uglow": "fx_girl"]
}
