// DepthAnything.swift — in-app install + Core ML inference for Depth Anything V2 (Small / Large).
// Small: Apple's Core ML build (Apache-2.0), downloaded file by file. Large: community Core ML port (CC-BY-NC-4.0, non-commercial), a zipped mlpackage.

import UIKit
import CoreML
import Vision
import Compression

enum DepthModelKind: String, CaseIterable {
    case small, large
    var title: String { self == .small ? "Small" : "Large" }
    var detail: String { self == .small ? "≈50 MB · fast · Apache-2.0" : "≈620 MB · best detail · non-commercial license (CC-BY-NC-4.0)" }
}

enum DepthAnything {
    private static let smallBase = "https://huggingface.co/apple/coreml-depth-anything-v2-small/resolve/main/DepthAnythingV2SmallF16.mlpackage/"
    private static let smallFiles = ["Manifest.json", "Data/com.apple.CoreML/model.mlmodel", "Data/com.apple.CoreML/weights/weight.bin"]
    private static let largeZip = "https://huggingface.co/LloydAI/DepthAnything_v2-Large-CoreML/resolve/main/DepthAnything_v2-Large.mlpackage.zip"

    static var selected: DepthModelKind {
        get { DepthModelKind(rawValue: UserDefaults.standard.string(forKey: "depthModel") ?? "") ?? .small }
        set { UserDefaults.standard.set(newValue.rawValue, forKey: "depthModel") }
    }
    static func dir() -> URL {
        let d = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("DepthAnything", isDirectory: true)
        try? FileManager.default.createDirectory(at: d, withIntermediateDirectories: true)
        return d
    }
    static func compiled(_ k: DepthModelKind) -> URL { dir().appendingPathComponent("\(k.rawValue).mlmodelc", isDirectory: true) }
    static func isInstalled(_ k: DepthModelKind) -> Bool { FileManager.default.fileExists(atPath: compiled(k).path) }
    static func remove(_ k: DepthModelKind) { try? FileManager.default.removeItem(at: compiled(k)); cache[k] = nil }

    private static var cache: [DepthModelKind: VNCoreMLModel] = [:]
    private static var active: Downloader?

    private static func fail(_ m: String) -> NSError { NSError(domain: "DepthAnything", code: 1, userInfo: [NSLocalizedDescriptionKey: m]) }

    // MARK: install
    /// progress(0...1, status) and done(error) are called on the main queue.
    static func install(_ k: DepthModelKind, progress: @escaping (Double, String) -> Void, done: @escaping (Error?) -> Void) {
        let work = dir().appendingPathComponent("tmp_\(k.rawValue)", isDirectory: true)
        try? FileManager.default.removeItem(at: work)
        try? FileManager.default.createDirectory(at: work, withIntermediateDirectories: true)
        func finish(_ e: Error?) { active = nil; try? FileManager.default.removeItem(at: work); DispatchQueue.main.async { done(e) } }
        func compileAndStore(_ pkg: URL) {
            DispatchQueue.main.async { progress(0.97, "Optimizing for this device…") }
            DispatchQueue.global(qos: .userInitiated).async {
                do {
                    let tmp = try MLModel.compileModel(at: pkg)
                    let dst = compiled(k)
                    try? FileManager.default.removeItem(at: dst)
                    try FileManager.default.moveItem(at: tmp, to: dst)
                    cache[k] = nil
                    finish(nil)
                } catch { finish(error) }
            }
        }
        let dl = Downloader()
        active = dl
        if k == .small {
            let pkg = work.appendingPathComponent("DepthAnythingV2SmallF16.mlpackage", isDirectory: true)
            let weights: [Double] = [0.01, 0.04, 0.95]
            func step(_ i: Int) {
                if i >= smallFiles.count { compileAndStore(pkg); return }
                let rel = smallFiles[i]
                guard let url = URL(string: smallBase + rel) else { finish(fail("Bad URL")); return }
                let base = weights[..<i].reduce(0, +)
                dl.start(url, progress: { f in DispatchQueue.main.async { progress((base + weights[i] * f) * 0.95, "Downloading Depth Anything Small…") } }) { r in
                    switch r {
                    case .failure(let e): finish(e)
                    case .success(let tmp):
                        do {
                            let dst = pkg.appendingPathComponent(rel)
                            try FileManager.default.createDirectory(at: dst.deletingLastPathComponent(), withIntermediateDirectories: true)
                            try? FileManager.default.removeItem(at: dst)
                            try FileManager.default.moveItem(at: tmp, to: dst)
                            step(i + 1)
                        } catch { finish(error) }
                    }
                }
            }
            step(0)
        } else {
            guard let url = URL(string: largeZip) else { finish(fail("Bad URL")); return }
            dl.start(url, progress: { f in DispatchQueue.main.async { progress(f * 0.85, "Downloading Depth Anything Large…") } }) { r in
                switch r {
                case .failure(let e): finish(e)
                case .success(let zip):
                    DispatchQueue.main.async { progress(0.86, "Unpacking…") }
                    DispatchQueue.global(qos: .userInitiated).async {
                        do {
                            let out = work.appendingPathComponent("x", isDirectory: true)
                            try unzip(zip, to: out)
                            try? FileManager.default.removeItem(at: zip)
                            let en = FileManager.default.enumerator(at: out, includingPropertiesForKeys: nil)
                            var found: URL? = nil
                            while let u = en?.nextObject() as? URL { if u.pathExtension == "mlpackage" { found = u; break } }
                            guard let pkg = found else { throw fail("The download did not contain a model.") }
                            compileAndStore(pkg)
                        } catch { finish(error) }
                    }
                }
            }
        }
    }

    // MARK: inference
    /// Returns a grayscale depth image (white = near) the size of `image` (long side capped at 2048).
    static func depth(for image: UIImage, kind: DepthModelKind, done: @escaping (UIImage?, String?) -> Void) {
        DispatchQueue.global(qos: .userInitiated).async {
            do {
                guard isInstalled(kind) else { throw fail("Model not installed.") }
                let vm: VNCoreMLModel
                if let m = cache[kind] { vm = m } else {
                    let cfg = MLModelConfiguration(); cfg.computeUnits = .all
                    vm = try VNCoreMLModel(for: try MLModel(contentsOf: compiled(kind), configuration: cfg)); cache[kind] = vm
                }
                let norm = normalized(image)
                guard let cg = norm.cgImage else { throw fail("Could not read the image.") }
                let req = VNCoreMLRequest(model: vm); req.imageCropAndScaleOption = .scaleFill
                try VNImageRequestHandler(cgImage: cg, options: [:]).perform([req])
                var w = 0, h = 0; var vals: [Float] = []
                if let o = req.results?.first as? VNPixelBufferObservation {
                    (w, h, vals) = readBuffer(o.pixelBuffer)
                } else if let o = req.results?.first as? VNCoreMLFeatureValueObservation, let a = o.featureValue.multiArrayValue {
                    let n = a.shape.count; h = a.shape[n - 2].intValue; w = a.shape[n - 1].intValue
                    vals = (0..<(w * h)).map { a[$0].floatValue }
                }
                guard w > 0, h > 0, vals.count >= w * h else { throw fail("Unexpected model output.") }
                let lo = vals.min() ?? 0, hi = vals.max() ?? 1, sc = 255 / max(hi - lo, 1e-6)
                var px = [UInt8](repeating: 0, count: w * h)
                for i in 0..<(w * h) { px[i] = UInt8(max(0, min(255, (vals[i] - lo) * sc))) }
                guard let prov = CGDataProvider(data: Data(px) as CFData),
                      let small = CGImage(width: w, height: h, bitsPerComponent: 8, bitsPerPixel: 8, bytesPerRow: w, space: CGColorSpaceCreateDeviceGray(),
                                          bitmapInfo: CGBitmapInfo(rawValue: 0), provider: prov, decode: nil, shouldInterpolate: true, intent: .defaultIntent)
                else { throw fail("Could not build the depth image.") }
                let sz = norm.size
                let fmt = UIGraphicsImageRendererFormat(); fmt.scale = 1; fmt.preferredRange = .standard
                let out = UIGraphicsImageRenderer(size: sz, format: fmt).image { c in
                    c.cgContext.interpolationQuality = .high
                    UIImage(cgImage: small).draw(in: CGRect(origin: .zero, size: sz))
                }
                DispatchQueue.main.async { done(out, nil) }
            } catch { DispatchQueue.main.async { done(nil, error.localizedDescription) } }
        }
    }

    private static func normalized(_ img: UIImage) -> UIImage {
        let m: CGFloat = 2048; let s = min(1, m / max(img.size.width * img.scale, img.size.height * img.scale))
        let sz = CGSize(width: max(1, (img.size.width * img.scale * s).rounded()), height: max(1, (img.size.height * img.scale * s).rounded()))
        let fmt = UIGraphicsImageRendererFormat(); fmt.scale = 1
        return UIGraphicsImageRenderer(size: sz, format: fmt).image { _ in img.draw(in: CGRect(origin: .zero, size: sz)) }
    }

    private static func readBuffer(_ pb: CVPixelBuffer) -> (Int, Int, [Float]) {
        CVPixelBufferLockBaseAddress(pb, .readOnly); defer { CVPixelBufferUnlockBaseAddress(pb, .readOnly) }
        let w = CVPixelBufferGetWidth(pb), h = CVPixelBufferGetHeight(pb), bpr = CVPixelBufferGetBytesPerRow(pb)
        guard let base = CVPixelBufferGetBaseAddress(pb) else { return (0, 0, []) }
        let fmt = CVPixelBufferGetPixelFormatType(pb)
        var out = [Float](repeating: 0, count: w * h)
        for y in 0..<h {
            let row = base + y * bpr
            for x in 0..<w {
                switch fmt {
                case kCVPixelFormatType_OneComponent8: out[y * w + x] = Float(row.load(fromByteOffset: x, as: UInt8.self))
                case kCVPixelFormatType_OneComponent32Float, kCVPixelFormatType_DepthFloat32, kCVPixelFormatType_DisparityFloat32:
                    out[y * w + x] = row.load(fromByteOffset: x * 4, as: Float.self)
                case kCVPixelFormatType_OneComponent16Half, kCVPixelFormatType_DepthFloat16, kCVPixelFormatType_DisparityFloat16:
                    #if arch(arm64)
                    out[y * w + x] = Float(row.load(fromByteOffset: x * 2, as: Float16.self))
                    #endif
                default: out[y * w + x] = Float(row.load(fromByteOffset: x * 4, as: UInt8.self))   // BGRA: blue channel
                }
            }
        }
        return (w, h, out)
    }

    // MARK: minimal zip extractor (stored + deflate, no zip64)
    private static func u16(_ d: Data, _ o: Int) -> Int { Int(d[d.startIndex + o]) | Int(d[d.startIndex + o + 1]) << 8 }
    private static func u32(_ d: Data, _ o: Int) -> Int { u16(d, o) | u16(d, o + 2) << 16 }

    static func unzip(_ zip: URL, to out: URL) throws {
        let fh = try FileHandle(forReadingFrom: zip); defer { try? fh.close() }
        let size = Int(try fh.seekToEnd())
        let tailLen = min(size, 70000)
        try fh.seek(toOffset: UInt64(size - tailLen))
        let tail = try fh.read(upToCount: tailLen) ?? Data()
        var e = tail.count - 22
        while e >= 0 && u32(tail, e) != 0x06054b50 { e -= 1 }
        guard e >= 0 else { throw fail("Bad zip file.") }
        let count = u16(tail, e + 10), cdSize = u32(tail, e + 12), cdOff = u32(tail, e + 16)
        guard cdOff != 0xFFFFFFFF else { throw fail("Zip64 archives are not supported.") }
        try fh.seek(toOffset: UInt64(cdOff))
        let cd = try fh.read(upToCount: cdSize) ?? Data()
        var p = 0
        for _ in 0..<count {
            guard p + 46 <= cd.count, u32(cd, p) == 0x02014b50 else { break }
            let method = u16(cd, p + 10), cs = u32(cd, p + 20), us = u32(cd, p + 24)
            let nl = u16(cd, p + 28), el = u16(cd, p + 30), cl = u16(cd, p + 32), lo = u32(cd, p + 42)
            let name = String(data: cd.subdata(in: (cd.startIndex + p + 46)..<(cd.startIndex + p + 46 + nl)), encoding: .utf8) ?? ""
            p += 46 + nl + el + cl
            if name.hasSuffix("/") || name.hasPrefix("__MACOSX") || name.contains("..") { continue }
            guard cs != 0xFFFFFFFF, us != 0xFFFFFFFF else { throw fail("Zip64 archives are not supported.") }
            try fh.seek(toOffset: UInt64(lo))
            let lh = try fh.read(upToCount: 30) ?? Data()
            guard lh.count == 30, u32(lh, 0) == 0x04034b50 else { throw fail("Bad zip entry.") }
            let dataOff = lo + 30 + u16(lh, 26) + u16(lh, 28)
            let dst = out.appendingPathComponent(name)
            try FileManager.default.createDirectory(at: dst.deletingLastPathComponent(), withIntermediateDirectories: true)
            FileManager.default.createFile(atPath: dst.path, contents: nil)
            let oh = try FileHandle(forWritingTo: dst); defer { try? oh.close() }
            try fh.seek(toOffset: UInt64(dataOff))
            if method == 0 {
                var left = cs
                while left > 0 { let c = try fh.read(upToCount: min(left, 1 << 20)) ?? Data(); if c.isEmpty { break }; oh.write(c); left -= c.count }
            } else if method == 8 {
                try inflate(fh, cs, oh)
            } else { throw fail("Unsupported zip compression.") }
        }
    }

    private static func inflate(_ fh: FileHandle, _ compSize: Int, _ out: FileHandle) throws {
        let cap = 1 << 20
        let dst = UnsafeMutablePointer<UInt8>.allocate(capacity: cap); defer { dst.deallocate() }
        var st = compression_stream(dst_ptr: dst, dst_size: 0, src_ptr: UnsafePointer(dst), src_size: 0, state: nil)
        guard compression_stream_init(&st, COMPRESSION_STREAM_DECODE, COMPRESSION_ZLIB) == COMPRESSION_STATUS_OK else { throw fail("Decompression failed.") }
        defer { compression_stream_destroy(&st) }
        var left = compSize; var status = COMPRESSION_STATUS_OK
        while status == COMPRESSION_STATUS_OK {
            let chunk = left > 0 ? (try fh.read(upToCount: min(left, 1 << 20)) ?? Data()) : Data()
            left -= chunk.count
            let final = left <= 0 || chunk.isEmpty
            chunk.withUnsafeBytes { (raw: UnsafeRawBufferPointer) in
                st.src_ptr = raw.bindMemory(to: UInt8.self).baseAddress ?? UnsafePointer(dst)
                st.src_size = chunk.count
                repeat {
                    st.dst_ptr = dst; st.dst_size = cap
                    status = compression_stream_process(&st, final ? Int32(COMPRESSION_STREAM_FINALIZE.rawValue) : 0)
                    let n = cap - st.dst_size
                    if n > 0 { out.write(Data(bytes: dst, count: n)) }
                } while status == COMPRESSION_STATUS_OK && (st.src_size > 0 || st.dst_size == 0)
            }
            if chunk.isEmpty && status == COMPRESSION_STATUS_OK { break }
        }
        if status == COMPRESSION_STATUS_ERROR { throw fail("Decompression failed.") }
    }
}

/// One download at a time with progress (URLSession delegate).
final class Downloader: NSObject, URLSessionDownloadDelegate {
    private var prog: ((Double) -> Void)?
    private var comp: ((Result<URL, Error>) -> Void)?
    private lazy var session = URLSession(configuration: .default, delegate: self, delegateQueue: nil)
    func start(_ url: URL, progress: @escaping (Double) -> Void, completion: @escaping (Result<URL, Error>) -> Void) {
        prog = progress; comp = completion
        session.downloadTask(with: url).resume()
    }
    func urlSession(_ s: URLSession, downloadTask t: URLSessionDownloadTask, didWriteData b: Int64, totalBytesWritten w: Int64, totalBytesExpectedToWrite e: Int64) {
        if e > 0 { prog?(Double(w) / Double(e)) }
    }
    func urlSession(_ s: URLSession, downloadTask t: URLSessionDownloadTask, didFinishDownloadingTo loc: URL) {
        if let r = t.response as? HTTPURLResponse, r.statusCode >= 400 {
            comp?(.failure(NSError(domain: "DepthAnything", code: r.statusCode, userInfo: [NSLocalizedDescriptionKey: "Download failed (HTTP \(r.statusCode))."]))); comp = nil; return
        }
        let keep = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        do { try FileManager.default.moveItem(at: loc, to: keep); comp?(.success(keep)) } catch { comp?(.failure(error)) }
        comp = nil
    }
    func urlSession(_ s: URLSession, task: URLSessionTask, didCompleteWithError e: Error?) {
        if let e = e { comp?(.failure(e)); comp = nil }
        s.finishTasksAndInvalidate()
    }
}
