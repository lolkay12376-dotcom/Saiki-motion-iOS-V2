// TwixtorTime.swift — source-time mapping for layers carrying the Twixtor effect.

import Foundation

struct TwixSource { let a: Float; let b: Float; let frac: Float; let fps: Float; let entry: String }

extension Layer {
    /// Source frame pair (A, B) and the in-between position for the layer's own Twixtor effect, if any.
    func twixSource(_ t: Float) -> TwixSource? {
        guard let e = fx.first(where: { !fxOff.contains($0) && Registry.get($0)?.id == "twixtor" }) else { return nil }
        func pv(_ k: String, _ def: Float) -> Float {
            let key = e + "__" + k
            if let tr = props[key] { return tr.eval(editTime(key, t)) }
            return def
        }
        let fps = max(1, pv("twInFps", 24))
        let s: Float = pv("twMode", 0) < 0.5 ? max(0, (t - start) * pv("twSpeed", 100) / 100 + srcOffset)
                                            : max(0, pv("twFrame", 0) / fps + srcOffset)
        let f = s * fps
        let fl = floor(f + 1e-4)
        return TwixSource(a: fl / fps, b: (fl + 1) / fps, frac: max(0, f - fl), fps: fps, entry: e)
    }
}
