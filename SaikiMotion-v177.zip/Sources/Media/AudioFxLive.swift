// AudioFxLive.swift — real-time playback of audio layers that carry effects.
//
// Each such layer plays through AVAudioEngine:  player node → custom effect Audio Unit → main mixer.
// The Audio Unit runs the same DSP as the exporter (AudioFx.swift), so editing a slider is heard immediately
// and the render sounds identical. Only the effects whose settings changed are rebuilt, so dragging one
// slider never resets the others (reverb tails, LFO phases).

import Foundation
import AVFoundation
import AudioToolbox

final class AFxAudioUnit: AUAudioUnit {
    static let desc = AudioComponentDescription(componentType: kAudioUnitType_Effect, componentSubType: 0x61667863,
                                                componentManufacturer: 0x536B6D6F, componentFlags: 0, componentFlagsMask: 0)
    private static var registered = false
    static func register() {
        if registered { return }
        registered = true
        AUAudioUnit.registerSubclass(AFxAudioUnit.self, as: desc, name: "SaikiMotion: Audio FX", version: 1)
    }

    private var ins: AUAudioUnitBusArray!
    private var outs: AUAudioUnitBusArray!
    private let lock = UnsafeMutablePointer<os_unfair_lock>.allocate(capacity: 1)
    private struct Slot { var uid: Int; var type: String; var p: AFxBase }
    private var slots: [Slot] = []                 // main thread only
    private var pending: [AFxBase] = []            // handed to the render thread under `lock`
    private var dirty = false
    private var local: [AFxBase] = []              // render thread only
    private var scratch: UnsafeMutablePointer<Float>? = nil
    private var scratchN = 0
    private var rate: Float = 44100
    private var chain: [AudioFxItem] = []

    override init(componentDescription: AudioComponentDescription, options: AudioComponentInstantiationOptions = []) throws {
        lock.initialize(to: os_unfair_lock())
        try super.init(componentDescription: componentDescription, options: options)
        let f = AVAudioFormat(standardFormatWithSampleRate: 44100, channels: 2)!
        ins = AUAudioUnitBusArray(audioUnit: self, busType: .input, busses: [try AUAudioUnitBus(format: f)])
        outs = AUAudioUnitBusArray(audioUnit: self, busType: .output, busses: [try AUAudioUnitBus(format: f)])
        maximumFramesToRender = 4096
    }
    deinit { scratch?.deallocate(); lock.deallocate() }

    override var inputBusses: AUAudioUnitBusArray { ins }
    override var outputBusses: AUAudioUnitBusArray { outs }

    override func allocateRenderResources() throws {
        try super.allocateRenderResources()
        scratchN = Int(maximumFramesToRender) + 64
        scratch = UnsafeMutablePointer<Float>.allocate(capacity: scratchN)
        rate = Float(outs[0].format.sampleRate)
        slots.removeAll()
        setChain(chain, sampleRate: rate)
    }
    override func deallocateRenderResources() {
        super.deallocateRenderResources()
        scratch?.deallocate(); scratch = nil
    }

    /// Main thread: new (keyframe-evaluated) settings. Existing processors are only *updated* — their delay lines, LFO phases
    /// and reverb tails keep running and every parameter glides — so a slider drag or keyframe never rebuilds anything (no buzz).
    /// A processor is created only when an effect is added / switched on or its type changes.
    func setChain(_ items: [AudioFxItem], sampleRate: Float) {
        chain = items
        if sampleRate != rate { rate = sampleRate; slots.removeAll() }
        var ns: [Slot] = []
        var changed = false
        for it in items where it.on {
            if let s = slots.first(where: { $0.uid == it.uid && $0.type == it.type }) { s.p.update(it); ns.append(s) }
            else if let p = AudioFxProc.make(it, sr: rate) { ns.append(Slot(uid: it.uid, type: it.type, p: p)); changed = true }
        }
        if ns.count != slots.count { changed = true }
        else { for i in 0..<ns.count where ns[i].p !== slots[i].p { changed = true } }
        slots = ns
        if changed {
            os_unfair_lock_lock(lock); pending = ns.map { $0.p }; dirty = true; os_unfair_lock_unlock(lock)
        }
    }

    override var internalRenderBlock: AUInternalRenderBlock {
        return { [unowned self] actionFlags, timestamp, frameCount, _, outputData, _, pull in
            guard let pull = pull else { return kAudioUnitErr_NoConnection }
            let st = pull(actionFlags, timestamp, frameCount, 0, outputData)
            if st != noErr { return st }
            let abl = UnsafeMutableAudioBufferListPointer(outputData)
            guard abl.count >= 1, let l = abl[0].mData?.assumingMemoryBound(to: Float.self) else { return noErr }
            let n = Int(frameCount)
            if os_unfair_lock_trylock(self.lock) {          // only swaps the processor list; a missed lock keeps the previous list (never drops to dry)
                if self.dirty { self.local = self.pending; self.dirty = false }
                os_unfair_lock_unlock(self.lock)
            }
            let ps = self.local
            if !ps.isEmpty {
                if abl.count >= 2, let r = abl[1].mData?.assumingMemoryBound(to: Float.self) {
                    for p in ps { p.process(l, r, n) }
                } else if let sc = self.scratch, n <= self.scratchN {        // mono: process a copy as the right channel
                    for i in 0..<n { sc[i] = l[i] }
                    for p in ps { p.process(l, sc, n) }
                }
            }
            return noErr
        }
    }
}

/// One engine for every effected layer.
final class AudioFxLive {
    private struct Entry {
        var file: AVAudioFile
        var node: AVAudioPlayerNode
        var unit: AFxAudioUnit
        var av: AVAudioUnit
        var segStart: Double = 0
        var playing = false
        var path: String
    }
    private let engine = AVAudioEngine()
    private var entries: [Int: Entry] = [:]
    private var pending = Set<Int>()
    private var failed = Set<String>()

    func has(_ id: Int) -> Bool { entries[id] != nil }
    /// True while a layer's file is still being opened (play dry-silent for a moment instead of falling back).
    func isPending(_ id: Int) -> Bool { pending.contains(id) }

    /// Creates / updates the chain of a layer. `done` runs on main when a new entry became ready.
    func sync(_ l: Layer, path: String, done: @escaping () -> Void) {
        let id = l.id
        if let e = entries[id], e.path == path { e.unit.setChain(l.afxChainAt(Editor.time), sampleRate: Float(e.file.processingFormat.sampleRate)); return }
        if entries[id] != nil { remove(id) }
        if pending.contains(id) || failed.contains(path) { return }
        pending.insert(id)
        let chainCopy = l.afxChainAt(Editor.time)
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            var f = try? AVAudioFile(forReading: URL(fileURLWithPath: path))
            if f == nil {      // video container: pull the sound out first
                let tmp = FileManager.default.temporaryDirectory.appendingPathComponent("fxsrc-\(abs(path.hashValue)).m4a")
                if FileManager.default.fileExists(atPath: tmp.path) || AudioTools.extractAudio(path, tmp) { f = try? AVAudioFile(forReading: tmp) }
            }
            DispatchQueue.main.async {
                guard let self = self else { return }
                guard let file = f else { self.pending.remove(id); self.failed.insert(path); return }
                AFxAudioUnit.register()
                AVAudioUnit.instantiate(with: AFxAudioUnit.desc, options: []) { av, _ in
                    DispatchQueue.main.async {
                        self.pending.remove(id)
                        guard let av = av, let au = av.auAudioUnit as? AFxAudioUnit else { self.failed.insert(path); return }
                        let node = AVAudioPlayerNode()
                        self.engine.attach(node); self.engine.attach(av)
                        let fmt = file.processingFormat
                        self.engine.connect(node, to: av, format: fmt)
                        self.engine.connect(av, to: self.engine.mainMixerNode, format: fmt)
                        au.setChain(chainCopy, sampleRate: Float(fmt.sampleRate))
                        self.entries[id] = Entry(file: file, node: node, unit: au, av: av, path: path)
                        done()
                    }
                }
            }
        }
    }

    /// Playback tick: pushes keyframed parameter values (evaluated at the playhead) into the running processors.
    func setItems(_ id: Int, _ items: [AudioFxItem]) {
        guard let e = entries[id] else { return }
        e.unit.setChain(items, sampleRate: Float(e.file.processingFormat.sampleRate))
    }

    func remove(_ id: Int) {
        guard let e = entries.removeValue(forKey: id) else { return }
        e.node.stop()
        engine.detach(e.node); engine.detach(e.av)
    }

    func prune(keep: Set<Int>) { for id in Array(entries.keys) where !keep.contains(id) { remove(id) } }

    func removeAll() {
        for id in Array(entries.keys) { remove(id) }
        if engine.isRunning { engine.stop() }
    }

    func pauseAll() {
        for (id, var e) in entries where e.playing { e.node.pause(); e.playing = false; entries[id] = e }
    }

    /// Keeps the layer locked to the timeline. `want` = seconds into the source file.
    func tick(_ id: Int, inside: Bool, want: Double, volume: Float, restart: Bool) {
        guard var e = entries[id] else { return }
        e.node.volume = volume
        if inside {
            var drift = 0.0
            if e.playing, let nt = e.node.lastRenderTime, let pt = e.node.playerTime(forNodeTime: nt) {
                drift = abs(e.segStart + Double(pt.sampleTime) / pt.sampleRate - want)
            }
            if !e.playing || restart || drift > 0.14 {
                let sr = e.file.processingFormat.sampleRate
                let start = AVAudioFramePosition(max(0, want) * sr)
                if start < e.file.length {
                    e.node.stop()
                    e.node.scheduleSegment(e.file, startingFrame: start, frameCount: AVAudioFrameCount(e.file.length - start), at: nil, completionHandler: nil)
                    if !engine.isRunning { try? engine.start() }
                    e.node.play()
                    e.segStart = max(0, want); e.playing = true
                }
            }
        } else if e.playing {
            e.node.pause(); e.playing = false
        }
        entries[id] = e
    }
}
