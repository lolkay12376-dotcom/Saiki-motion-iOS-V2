// Puppet.swift — puppet pin warp (Model + math).
// Pins live in the layer's quad space (-1...1, y up, same space as the
// renderer's aPos). Each pin's motion is two ordinary tracks on the layer
// ("pp<id>x" / "pp<id>y" = offset from rest), so keyframes, auto-key,
// undo, save and export all work with no special cases. Auto-sway adds a
// procedural wave on top, scaled root→tip along a chain of pins.

import Foundation
import OpenGLES

final class PuppetPin {
    var id: Int
    var rx: Float
    var ry: Float
    init(_ id: Int, _ rx: Float, _ ry: Float) { self.id = id; self.rx = rx; self.ry = ry }
}

/// One sway effect on a puppet. A puppet can hold several; kind 0 = Wave (procedural),
/// kind 1 = Physics (reacts to the layer's / parents' movement, gravity and wind).
/// Physics values can be linked to keyframes or expressions: put a track on
/// "sw<index>stiff", "sw<index>damp", "sw<index>grav" or "sw<index>wind".
final class SwayLayer {
    var kind = 0
    var chain: [Int] = []
    var speed: Float = 0.8, deg: Float = 20, wave: Float = 0.5, tip: Float = 1.5, rand: Float = 0
    var seed = 1
    var weight = 1                       // physics: 0 light, 1 medium, 2 heavy
    var stiff: Float = 45, damp: Float = 40, grav: Float = 0, wind: Float = 0
    var on = true
    func toJson() -> JObj {
        let o = JObj()
        o.put("kind", Int64(kind)).put("on", on).put("speed", Double(speed)).put("deg", Double(deg))
        o.put("wave", Double(wave)).put("tip", Double(tip)).put("rand", Double(rand)).put("seed", Int64(seed))
        o.put("weight", Int64(weight)).put("stiff", Double(stiff)).put("damp", Double(damp))
        o.put("grav", Double(grav)).put("wind", Double(wind))
        let ca = JArr(); for c in chain { _ = ca.put(Int64(c)) }
        o.put("chain", ca)
        return o
    }
    static func fromJson(_ o: JObj) -> SwayLayer {
        let s = SwayLayer()
        s.kind = clamp(o.optInt("kind", 0), 0, 1); s.on = o.optBool("on", true)
        s.speed = o.optFloat("speed", 0.8); s.deg = o.optFloat("deg", 20); s.wave = o.optFloat("wave", 0.5)
        s.tip = o.optFloat("tip", 1.5); s.rand = o.optFloat("rand", 0); s.seed = o.optInt("seed", 1)
        s.weight = clamp(o.optInt("weight", 1), 0, 2)
        s.stiff = o.optFloat("stiff", 45); s.damp = o.optFloat("damp", 40)
        s.grav = o.optFloat("grav", 0); s.wind = o.optFloat("wind", 0)
        if let ca = o.optJSONArray("chain") { for i in 0..<ca.count { s.chain.append(ca.optInt(i)) } }
        return s
    }
}

final class Puppet {
    var on = true
    var pins: [PuppetPin] = []
    var nextId = 1
    var density = 1                 // 0 low, 1 medium, 2 high
    var showMesh = true
    var stiffness: Float = 2        // falloff power (higher = more local)
    var swayOn = false
    var lockRoot = true
    var swayStrength = 1            // 0 gentle, 1 medium, 2 strong
    var swayChain: [Int] = []       // pin ids, root first
    var swaySpeed: Float = 0.8      // cycles per second
    var swayDeg: Float = 20         // swing angle at the tip (degrees)
    var swayWave: Float = 0.5       // phase lag per pin (radians)
    var swayTip: Float = 1.5        // root→tip weight exponent
    var swayRand: Float = 0         // 0...1
    var swaySeed = 1
    var sways: [SwayLayer] = []     // every wave / physics effect on this layer
    var swaySel = 0                 // editor only

    func pin(_ id: Int) -> PuppetPin? { pins.first { $0.id == id } }
    func number(_ id: Int) -> Int { (pins.firstIndex { $0.id == id } ?? 0) + 1 }

    func toJson() -> JObj {
        let o = JObj()
        o.put("on", on).put("nextId", Int64(nextId)).put("density", Int64(density))
        o.put("showMesh", showMesh).put("stiffness", Double(stiffness))
        o.put("swayOn", swayOn).put("lockRoot", lockRoot)
        o.put("swayStrength", Int64(swayStrength)).put("swaySpeed", Double(swaySpeed))
        o.put("swayDeg", Double(swayDeg)).put("swayWave", Double(swayWave)).put("swayTip", Double(swayTip))
        o.put("swayRand", Double(swayRand)).put("swaySeed", Int64(swaySeed))
        let pa = JArr()
        for p in pins {
            pa.put(JObj().put("id", Int64(p.id)).put("rx", Double(p.rx)).put("ry", Double(p.ry)))
        }
        o.put("pins", pa)
        let sa = JArr(); for w in sways { _ = sa.put(w.toJson()) }
        o.put("sways", sa)
        let ca = JArr(); for c in swayChain { _ = ca.put(Int64(c)) }
        o.put("chain", ca)
        return o
    }

    static func fromJson(_ o: JObj) -> Puppet {
        let p = Puppet()
        p.on = o.optBool("on", true)
        p.nextId = max(1, o.optInt("nextId", 1))
        p.density = clamp(o.optInt("density", 1), 0, 3)
        p.showMesh = o.optBool("showMesh", true)
        p.stiffness = o.optFloat("stiffness", 2)
        p.swayOn = o.optBool("swayOn")
        p.lockRoot = o.optBool("lockRoot", true)
        p.swayStrength = clamp(o.optInt("swayStrength", 1), 0, 2)
        p.swaySpeed = o.optFloat("swaySpeed", 0.8)
        p.swayDeg = o.optFloat("swayDeg", 20); p.swayWave = o.optFloat("swayWave", 0.5)
        p.swayTip = o.optFloat("swayTip", 1.5); p.swayRand = o.optFloat("swayRand", 0)
        p.swaySeed = o.optInt("swaySeed", 1)
        if let pa = o.optJSONArray("pins") {
            for i in 0..<pa.count {
                if let po = pa.optJSONObject(i) {
                    p.pins.append(PuppetPin(po.optInt("id"), po.optFloat("rx"), po.optFloat("ry")))
                }
            }
        }
        if let ca = o.optJSONArray("chain") {
            for i in 0..<ca.count { p.swayChain.append(ca.optInt(i)) }
        }
        if let sa = o.optJSONArray("sways") {
            for i in 0..<sa.count { if let so = sa.optJSONObject(i) { p.sways.append(SwayLayer.fromJson(so)) } }
        } else if p.swayOn && !p.swayChain.isEmpty {
            let w = SwayLayer()
            w.chain = p.swayChain; w.speed = p.swaySpeed; w.deg = p.swayDeg; w.wave = p.swayWave
            w.tip = p.swayTip; w.rand = p.swayRand; w.seed = p.swaySeed
            p.sways = [w]
        }
        return p
    }
}

/// Shared state between the Puppet panel and the viewport overlay.
enum PuppetEdit {
    static var mode = 0              // 0 add, 1 select, 2 multi
    static var sel: [Int] = []       // selected pin ids (last = primary)
    static var fine = false
    static var onChange: (() -> Void)? = nil
}

enum PuppetMath {
    static let segs = [7, 12, 18, 28]
    private static let lock = NSLock()
    private static var gCaches: [Int: (key: [Float], out: [Float])] = [:]

    static func rnd(_ seed: Int, _ k: Int) -> Float {
        var x = UInt32(truncatingIfNeeded: seed &* 7919 &+ k &* 104729 &+ 12345)
        x = x &* 1664525 &+ 1013904223
        x ^= x >> 13
        x = x &* 1664525 &+ 1013904223
        return Float(x >> 8) / Float(1 << 24) * 2 - 1
    }

    /// Wave sway: each chained pin swings around the root pin, more toward the tip.
    static func waveOffset(_ p: Puppet, _ s: SwayLayer, _ pin: PuppetPin, _ t: Float,
                           _ qs: (Float, Float)) -> (Float, Float) {
        guard let k = s.chain.firstIndex(of: pin.id), let root = p.pin(s.chain[0]) else { return (0, 0) }
        let n = s.chain.count
        let base: Float = p.lockRoot ? (n > 1 ? Float(k) / Float(n - 1) : 0) : Float(k + 1) / Float(n)
        let w = base <= 0 ? 0 : pow(base, max(s.tip, 0.1))
        let r = rnd(s.seed, k)
        let ph = 2 * Float.pi * s.speed * t - Float(k) * s.wave + s.rand * r * Float.pi
        let amp = 1 + s.rand * r * 0.5
        if k == 0 { return p.lockRoot ? (0, 0) : (0.03 * s.deg / 20 * w * sin(ph), 0) }
        let ang = s.deg * Float.pi / 180 * w * sin(ph) * amp
        let vx = (pin.rx - root.rx) * qs.0, vy = (pin.ry - root.ry) * qs.1
        let c = cos(ang), sn = sin(ang)
        let rx = vx * c - vy * sn, ry = vx * sn + vy * c
        return ((rx - vx) / max(qs.0, 0.0001), (ry - vy) / max(qs.1, 0.0001))
    }

    /// Value of a physics setting: the stored number, or the layer track (keyframes / expression) when one exists.
    private static func pv(_ l: Layer, _ idx: Int, _ key: String, _ v: Float, _ t: Float) -> Float {
        l.props["sw\(idx)\(key)"] != nil ? l.p("sw\(idx)\(key)", t) : v
    }

    private static var physCache: [Int: (key: [Float], out: [Int: (Float, Float)])] = [:]

    /// Physics sway for every chained pin. Stateless: a spring/damper is integrated over the last
    /// ~1.2 s of the layer's own motion (including its parents), so scrubbing and export agree.
    static func physicsOffsets(_ l: Layer, _ p: Puppet, _ s: SwayLayer, _ idx: Int, _ t: Float,
                               _ qs: (Float, Float)) -> [Int: (Float, Float)] {
        let stiff = pv(l, idx, "stiff", s.stiff, t), damp = pv(l, idx, "damp", s.damp, t)
        let grav = pv(l, idx, "grav", s.grav, t), wind = pv(l, idx, "wind", s.wind, t)
        let m0 = Xf.matrix(l, t), m1 = Xf.matrix(l, t - 0.25), m2 = Xf.matrix(l, t - 0.6)
        var key: [Float] = [Float(l.id), t, stiff, damp, grav, wind, Float(s.weight), s.deg, qs.0, qs.1]
        key += m0 + m1 + m2
        for id in s.chain { if let q = p.pin(id) { key += [Float(id), q.rx, q.ry] } }
        let ck = l.id &* 64 &+ idx
        if let c = physCache[ck], c.key == key { return c.out }
        var out: [Int: (Float, Float)] = [:]
        let n = s.chain.count
        let mass: Float = [0.6, 1, 1.7][s.weight]
        let w2 = (20 + stiff * 8) / mass, c = 1 + damp * 0.4
        let g = grav * 0.06 * mass, wd = wind * 0.05
        let steps = 72, dt: Float = 1.0 / 60, t0 = max(0, t - Float(steps) * dt)
        let hw = qs.0 / 2, hh = qs.1 / 2
        let det = m0[0] * m0[3] - m0[1] * m0[2]
        for (k, id) in s.chain.enumerated() {
            guard let pin = p.pin(id), !(k == 0 && p.lockRoot), abs(det) > 1e-8 else { continue }
            let base: Float = n > 1 ? Float(k + (p.lockRoot ? 0 : 1)) / Float(p.lockRoot ? n - 1 : n) : 1
            let wt = pow(max(base, 0), max(s.tip, 0.1))
            func anchor(_ tt: Float) -> (Float, Float) { Xf.apply(Xf.matrix(l, tt), pin.rx * hw, pin.ry * hh) }
            var x = anchor(t0), v: (Float, Float) = (0, 0)
            var tt = t0
            while tt < t - 1e-5 {
                let h = min(dt, t - tt); tt += h
                let a = anchor(tt)
                let gust = 1 + 0.5 * sin(2 * Float.pi * 0.7 * tt + Float(k))
                for _ in 0..<2 {
                    let hh2 = h / 2
                    let ax = w2 * (a.0 - x.0) - c * v.0 + wd * gust * wt
                    let ay = w2 * (a.1 - x.1) - c * v.1 - g * wt
                    v.0 += ax * hh2; v.1 += ay * hh2
                    x.0 += v.0 * hh2; x.1 += v.1 * hh2
                }
            }
            let a = anchor(t)
            let k2 = s.deg / 20                      // Strength scales how far the pin may lag
            var dx = (x.0 - a.0) * k2, dy = (x.1 - a.1) * k2
            let lim = max(hw, hh) * 1.2, len = (dx * dx + dy * dy).squareRoot()
            if len > lim { dx *= lim / len; dy *= lim / len }
            let lx = (m0[3] * dx - m0[2] * dy) / det, ly = (-m0[1] * dx + m0[0] * dy) / det
            out[id] = (lx / max(hw, 0.0001), ly / max(hh, 0.0001))
        }
        if physCache.count > 200 { physCache.removeAll() }
        physCache[ck] = (key, out)
        return out
    }

    /// Offset from rest of one pin at time t (keyed tracks + every sway layer).
    static func offset(_ l: Layer, _ p: Puppet, _ pin: PuppetPin, _ t: Float,
                       _ qs: (Float, Float)? = nil) -> (Float, Float) {
        var ox = (l.props["pp\(pin.id)x"]?.eval(t) ?? 0) + (l.rigOff["pp\(pin.id)x"] ?? 0)
        var oy = (l.props["pp\(pin.id)y"]?.eval(t) ?? 0) + (l.rigOff["pp\(pin.id)y"] ?? 0)
        if !p.swayOn || p.sways.isEmpty { return (ox, oy) }
        let q = qs ?? Xf.quadSize(l)
        for (i, s) in p.sways.enumerated() where s.on && s.chain.contains(pin.id) {
            if s.kind == 0 { let o = waveOffset(p, s, pin, t, q); ox += o.0; oy += o.1 }
            else if let o = physicsOffsets(l, p, s, i, t, q)[pin.id] { ox += o.0; oy += o.1 }
        }
        return (ox, oy)
    }

    static func pinPos(_ l: Layer, _ p: Puppet, _ pin: PuppetPin, _ t: Float,
                       _ qs: (Float, Float)? = nil) -> (Float, Float) {
        let o = offset(l, p, pin, t, qs)
        return (pin.rx + o.0, pin.ry + o.1)
    }

    @inline(__always) static func wgt(_ d2: Float, _ pw: Float) -> Float {
        let e = d2 + 0.00001
        return pw == 2 ? 1 / e : pow(e, -pw * 0.5)
    }

    /// Displacement of a rest point (inverse-distance weighted, with a hold
    /// weight so far-away points stay put).
    static func disp(_ pins: [(Float, Float, Float, Float)], _ pw: Float, _ x: Float, _ y: Float) -> (Float, Float) {
        var sx: Float = 0, sy: Float = 0, sw = pow(1.4, -pw)
        for q in pins {
            let dx = x - q.0, dy = y - q.1
            let w = wgt(dx * dx + dy * dy, pw)
            sx += w * q.2; sy += w * q.3; sw += w
        }
        return (sx / sw, sy / sw)
    }

    static func activePins(_ l: Layer, _ p: Puppet, _ t: Float) -> [(Float, Float, Float, Float)] {
        let qs = (p.swayOn && !p.sways.isEmpty) ? Xf.quadSize(l) : (1, 1)
        return p.pins.map { let o = offset(l, p, $0, t, qs); return ($0.rx, $0.ry, o.0, o.1) }
    }

    /// Deformed grid vertex positions (aPos space), row-major, (n+1)² points. Cached so the
    /// renderer and the overlay share one computation per change.
    static func gridPositions(_ l: Layer, _ p: Puppet, _ t: Float) -> [Float] {
        let n = segs[p.density]
        let pins = activePins(l, p, t)
        var key: [Float] = [Float(l.id), Float(n), p.stiffness]
        for q in pins { key.append(q.0); key.append(q.1); key.append(q.2); key.append(q.3) }
        let ck = l.id &* 8 &+ p.density
        lock.lock()
        if let c = gCaches[ck], c.key == key { lock.unlock(); return c.out }
        lock.unlock()
        var out = [Float](); out.reserveCapacity((n + 1) * (n + 1) * 2)
        for j in 0...n {
            let y = -1 + 2 * Float(j) / Float(n)
            for i in 0...n {
                let x = -1 + 2 * Float(i) / Float(n)
                let d = disp(pins, p.stiffness, x, y)
                out.append(x + d.0); out.append(y + d.1)
            }
        }
        lock.lock()
        if gCaches.count > 400 { gCaches.removeAll() }
        gCaches[ck] = (key, out); lock.unlock()
        return out
    }

    private static var topoCache: [Int: ([Float], [UInt16])] = [:]
    static func topology(_ n: Int) -> ([Float], [UInt16]) {
        if let c = topoCache[n] { return c }
        var uv = [Float](), idx = [UInt16]()
        for j in 0...n { for i in 0...n { uv.append(Float(i) / Float(n)); uv.append(Float(j) / Float(n)) } }
        for j in 0..<n { for i in 0..<n {
            let a = UInt16(j * (n + 1) + i), b = a + 1, c = a + UInt16(n + 1), d = c + 1
            idx += [a, b, c, b, d, c]
        } }
        topoCache[n] = (uv, idx)
        return (uv, idx)
    }

    /// Mesh for the renderer, or nil when the layer has no active puppet.
    static func mesh(_ l: Layer, _ t: Float) -> (pos: [Float], uv: [Float], idx: [UInt16])? {
        guard let p = l.puppet, p.on, !p.pins.isEmpty else { return nil }
        let (uv, idx) = topology(segs[p.density])
        return (gridPositions(l, p, t), uv, idx)
    }
}

extension Gl {
    /// Draws an indexed triangle mesh: aPos = deformed quad-space position, aUv = rest uv.
    static func drawMesh(_ program: GLProgram, _ pos: [Float], _ uv: [Float], _ idx: [UInt16]) {
        program.use()
        glBindBuffer(GLenum(GL_ARRAY_BUFFER), 0)
        glBindBuffer(GLenum(GL_ELEMENT_ARRAY_BUFFER), 0)
        let aPos = glGetAttribLocation(program.handle, "aPos")
        let aUv = glGetAttribLocation(program.handle, "aUv")
        guard aPos >= 0, aUv >= 0 else { return }
        glEnableVertexAttribArray(GLuint(aPos))
        glEnableVertexAttribArray(GLuint(aUv))
        pos.withUnsafeBufferPointer { pp in
            uv.withUnsafeBufferPointer { up in
                idx.withUnsafeBufferPointer { ip in
                    glVertexAttribPointer(GLuint(aPos), 2, GLenum(GL_FLOAT), GLboolean(GL_FALSE), 8, pp.baseAddress)
                    glVertexAttribPointer(GLuint(aUv), 2, GLenum(GL_FLOAT), GLboolean(GL_FALSE), 8, up.baseAddress)
                    glDrawElements(GLenum(GL_TRIANGLES), GLsizei(idx.count), GLenum(GL_UNSIGNED_SHORT), ip.baseAddress)
                }
            }
        }
        glDisableVertexAttribArray(GLuint(aPos))
        glDisableVertexAttribArray(GLuint(aUv))
    }
}
