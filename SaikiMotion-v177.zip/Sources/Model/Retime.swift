// Retime.swift — keeps a media layer's other keyframes (position, scale, effect params …) glued to the footage
// when its Time Remap / speed changes. A key that sat on source moment S stays on S after the remap changes.

import Foundation

final class RetimeSnap {
    let layer: Layer
    let oldF: (Float) -> Float          // scene time -> source time, as it was before the edit
    var origTimes: [(Track, Key, Float)] = []
    init(_ l: Layer) {
        layer = l
        oldF = l.srcMap()
        for (k, tr) in l.props where !k.hasPrefix("remap") {
            for key in tr.keys { origTimes.append((tr, key, key.t)) }
        }
    }
}

extension Layer {
    /// Scene time -> source time (offset-free) from the current remap state.
    func srcMap() -> (Float) -> Float {
        let st = start
        if let rt = props["remapT"], !rt.keys.isEmpty {
            let c = Track(rt.base); c.keys = rt.keys.map { $0.copy() }
            return { c.eval($0) }
        }
        if let sp = props["remapSpeed"] {
            let c = Track(sp.base); c.keys = sp.keys.map { $0.copy() }
            return { ($0 - st) * c.eval($0) }
        }
        return { $0 - st }
    }

    func retimeSnapshot() -> RetimeSnap? {
        (type == .VIDEO || type == .MODEL) ? RetimeSnap(self) : nil
    }

    /// Re-places the snapshotted keys for the CURRENT remap state (idempotent: always computed from the originals).
    func retime(_ snap: RetimeSnap?) {
        guard let snap = snap, snap.layer === self else { return }
        let f = srcMap()
        let span = max(end - start, 0.1)
        let lo = start, hi = start + span * 10
        let n = 512
        func inverse(_ s: Float, _ fallback: Float) -> Float {
            var prevT = lo, prevV = f(lo)
            if abs(prevV - s) < 1e-5 { return prevT }
            for i in 1...n {
                let t = lo + (hi - lo) * Float(i) / Float(n)
                let v = f(t)
                if (prevV - s) * (v - s) <= 0 && abs(v - prevV) > 1e-7 {
                    var a = prevT, b = t, fa = prevV
                    for _ in 0..<22 {
                        let m = (a + b) / 2, fm = f(m)
                        if (fa - s) * (fm - s) <= 0 { b = m } else { a = m; fa = fm }
                    }
                    return (a + b) / 2
                }
                prevT = t; prevV = v
            }
            return fallback
        }
        var seen = Set<ObjectIdentifier>()
        var tracks: [Track] = []
        for (tr, key, t0) in snap.origTimes {
            key.t = (t0 < start - 1e-4 || t0 > end + 1e-4) ? t0 : inverse(snap.oldF(t0), t0)
            if seen.insert(ObjectIdentifier(tr)).inserted { tracks.append(tr) }
        }
        for tr in tracks { tr.keys.sort { $0.t < $1.t } }
    }
}
