// VPath.swift — vector pen path model + CoreGraphics rasteriser (shape layers with shape == .PATH).
import UIKit

/// Point in the layer's unit square (-1...1, y down). Handles are offsets from the point.
struct VPt { var x: Float; var y: Float; var ix: Float = 0; var iy: Float = 0; var ox: Float = 0; var oy: Float = 0
    var curved: Bool { ix != 0 || iy != 0 || ox != 0 || oy != 0 } }

struct VPath {
    var pts: [VPt] = []
    var closed = false
    var hashKey: Int { var h = Hasher(); h.combine(closed); for p in pts { h.combine(p.x); h.combine(p.y); h.combine(p.ix); h.combine(p.iy); h.combine(p.ox); h.combine(p.oy) }; return h.finalize() }

    /// Segment i -> i+1 (wraps when closed) as 4 control points in the given mapping.
    func segment(_ i: Int, _ m: (Float, Float) -> CGPoint) -> (CGPoint, CGPoint, CGPoint, CGPoint)? {
        let n = pts.count
        guard n > 1, i < (closed ? n : n - 1) else { return nil }
        let a = pts[i], b = pts[(i + 1) % n]
        return (m(a.x, a.y), m(a.x + a.ox, a.y + a.oy), m(b.x + b.ix, b.y + b.iy), m(b.x, b.y))
    }

    func bezier(_ m: (Float, Float) -> CGPoint) -> UIBezierPath {
        let p = UIBezierPath()
        guard let f = pts.first else { return p }
        p.move(to: m(f.x, f.y))
        for i in 0..<(closed ? pts.count : pts.count - 1) {
            guard let s = segment(i, m) else { break }
            p.addCurve(to: s.3, controlPoint1: s.1, controlPoint2: s.2)
        }
        if closed { p.close() }
        return p
    }

    /// Splits segment i at t (de Casteljau) and inserts the new point; the curve shape is unchanged.
    mutating func split(_ i: Int, at t: Float) {
        let n = pts.count, j = (i + 1) % n
        let a = pts[i], b = pts[j]
        func l(_ p: SIMD2<Float>, _ q: SIMD2<Float>) -> SIMD2<Float> { p + (q - p) * t }
        let p0 = SIMD2(a.x, a.y), p1 = SIMD2(a.x + a.ox, a.y + a.oy), p2 = SIMD2(b.x + b.ix, b.y + b.iy), p3 = SIMD2(b.x, b.y)
        let q0 = l(p0, p1), q1 = l(p1, p2), q2 = l(p2, p3), r0 = l(q0, q1), r1 = l(q1, q2), s = l(r0, r1)
        pts[i].ox = q0.x - a.x; pts[i].oy = q0.y - a.y
        pts[j].ix = q2.x - b.x; pts[j].iy = q2.y - b.y
        pts.insert(VPt(x: s.x, y: s.y, ix: r0.x - s.x, iy: r0.y - s.y, ox: r1.x - s.x, oy: r1.y - s.y), at: i + 1)
    }
}

enum VPathRaster {
    /// Closed paths are filled, open paths stroked. Square RGBA image; path -1...1 maps to the full square.
    static func image(_ vp: VPath, color: Int32, side: CGFloat = 512) -> UIImage {
        let c = UInt32(bitPattern: color)
        let col = UIColor(red: CGFloat((c >> 16) & 0xFF) / 255, green: CGFloat((c >> 8) & 0xFF) / 255,
                          blue: CGFloat(c & 0xFF) / 255, alpha: CGFloat((c >> 24) & 0xFF) / 255)
        let f = UIGraphicsImageRendererFormat(); f.scale = 1; f.opaque = false
        return UIGraphicsImageRenderer(size: CGSize(width: side, height: side), format: f).image { _ in
            let path = vp.bezier { CGPoint(x: CGFloat($0 * 0.5 + 0.5) * side, y: CGFloat($1 * 0.5 + 0.5) * side) }
            col.setFill(); col.setStroke()
            if vp.closed { path.fill() } else { path.lineWidth = side * 0.03; path.lineCapStyle = .round; path.lineJoinStyle = .round; path.stroke() }
        }
    }
}
