//  MetalPasses.swift
//  Metal migration stage 3: pipeline cache, full-screen triangle, blit and composite
//  (all six blend modes + masks + RGB shift) as direct ports of the GL passes.
//
//  UV CONVENTION: shader math keeps GL's convention (vUv.y = 0 at the BOTTOM of the image) so
//  effect GLSL ports unchanged. Textures are stored top-row-first (Metal), so every texture
//  read goes through flipV(): sample(uv.x, 1 - uv.y). Render targets need no flip.

import Foundation
import Metal
import UIKit

enum MetalSL {
    /// Shared by the built-in passes and by native effect MSL.
    static let header = """
#include <metal_stdlib>
using namespace metal;
struct VOut { float4 pos [[position]]; float2 uv; };
struct FxCommon { float2 res; float2 lc; float2 lx; float2 ly; float time; float has0; float has1; float pad; };
constexpr sampler linearClamp(coord::normalized, address::clamp_to_edge, filter::linear);
inline float2 flipV(float2 uv) { return float2(uv.x, 1.0 - uv.y); }

"""

    static let passes = header + """
vertex VOut fsVertex(uint vid [[vertex_id]]) {
    float2 p = float2(vid == 1 ? 3.0 : -1.0, vid == 2 ? 3.0 : -1.0);
    VOut o; o.pos = float4(p, 0.0, 1.0); o.uv = p * 0.5 + 0.5; return o;
}

fragment float4 blitFragment(VOut in [[stage_in]], texture2d<float> t [[texture(0)]]) {
    return t.sample(linearClamp, flipV(in.uv));
}


inline float lumF(float3 c) { return dot(c, float3(0.3, 0.59, 0.11)); }
inline float3 clipCol(float3 c) {
    float l = lumF(c), n = min(min(c.r, c.g), c.b), x = max(max(c.r, c.g), c.b);
    if (n < 0.0) c = l + (c - l) * l / max(l - n, 1e-5);
    if (x > 1.0) c = l + (c - l) * (1.0 - l) / max(x - l, 1e-5);
    return c;
}
inline float3 setLum(float3 c, float l) { return clipCol(c + (l - lumF(c))); }
inline float satF(float3 c) { return max(max(c.r, c.g), c.b) - min(min(c.r, c.g), c.b); }
inline float3 setSat(float3 c, float s) {
    float mx = max(max(c.r, c.g), c.b), mn = min(min(c.r, c.g), c.b);
    return mx <= mn ? float3(0.0) : (c - mn) * s / (mx - mn);
}
inline float3 burn3(float3 d, float3 s) { return select(1.0 - min(1.0, (1.0 - d) / max(s, 1e-4)), float3(0.0), s <= 0.0); }
inline float3 dodge3(float3 d, float3 s) { return select(min(1.0, d / max(1.0 - s, 1e-4)), float3(1.0), s >= 1.0); }
inline float3 blendFn(int m, float3 d, float3 s) {
    switch (m) {
    case 11: return min(d, s);
    case 12: return burn3(d, s);
    case 13: return max(d + s - 1.0, 0.0);
    case 14: return lumF(d) <= lumF(s) ? d : s;
    case 15: return max(d, s);
    case 16: return dodge3(d, s);
    case 17: return lumF(d) >= lumF(s) ? d : s;
    case 18: return select(1.0 - 2.0 * (1.0 - d) * (1.0 - s), 2.0 * d * s, d <= 0.5);
    case 19: {
        float3 D = select(sqrt(d), ((16.0 * d - 12.0) * d + 4.0) * d, d <= 0.25);
        return select(d + (2.0 * s - 1.0) * (D - d), d - (1.0 - 2.0 * s) * d * (1.0 - d), s <= 0.5);
    }
    case 20: return select(1.0 - 2.0 * (1.0 - d) * (1.0 - s), 2.0 * d * s, s <= 0.5);
    case 21: return select(dodge3(d, 2.0 * s - 1.0), burn3(d, 2.0 * s), s <= 0.5);
    case 22: return clamp(d + 2.0 * s - 1.0, 0.0, 1.0);
    case 23: return select(max(d, 2.0 * s - 1.0), min(d, 2.0 * s), s <= 0.5);
    case 24: return select(float3(0.0), float3(1.0), d + s >= 1.0);
    case 25: return abs(d - s);
    case 26: return d + s - 2.0 * d * s;
    case 27: return max(d - s, 0.0);
    case 28: return select(min(d / max(s, 1e-4), 1.0), float3(1.0), s <= 0.0);
    case 31: return setLum(setSat(s, satF(d)), lumF(d));
    case 32: return setLum(setSat(d, satF(s)), lumF(d));
    case 33: return setLum(s, lumF(d));
    case 34: return setLum(d, lumF(s));
    }
    return s;
}

struct CompParams { float alpha; float mode; float maskMode; float rgbShift; };

// Port of SceneRenderer.compositeFragment (GLSL). Keep the two in sync.
fragment float4 compositeFragment(VOut in [[stage_in]], constant CompParams& u [[buffer(0)]],
                                  texture2d<float> uScene [[texture(0)]],
                                  texture2d<float> uSrc [[texture(1)]],
                                  texture2d<float> uMask [[texture(2)]]) {
    float2 vUv = in.uv;
    float4 s = uSrc.sample(linearClamp, flipV(vUv));
    if (u.rgbShift != 0.0) {
        s.r = uSrc.sample(linearClamp, flipV(clamp(vUv + float2(u.rgbShift, 0.0), 0.0, 1.0))).r;
        s.b = uSrc.sample(linearClamp, flipV(clamp(vUv - float2(u.rgbShift, 0.0), 0.0, 1.0))).b;
    }
    float4 sRaw = s;
    s *= u.alpha;
    if (u.mode > 4.5 && u.mode < 9.5) {
        return mix(uScene.sample(linearClamp, flipV(vUv)), sRaw, u.alpha);
    }
    if (u.maskMode > 0.5) {
        float4 mk = uMask.sample(linearClamp, flipV(vUv));
        float m = 1.0;
        if (u.maskMode < 1.5) { m = mk.a; }
        else if (u.maskMode < 2.5) { m = 1.0 - mk.a; }
        else if (u.maskMode < 3.5) { m = dot(mk.rgb, float3(0.299, 0.587, 0.114)); }
        else { m = 1.0 - dot(mk.rgb, float3(0.299, 0.587, 0.114)); }
        s *= m;
    }
    float4 d = uScene.sample(linearClamp, flipV(vUv));
    if (u.mode > 98.5) { return s; }      // matte pass: masked source only
    if (u.mode > 9.5) {
        int m = int(u.mode + 0.5);
        if (m == 10) {                    // Dissolve: stochastic per-pixel coverage
            float h = fract(sin(dot(floor(in.pos.xy), float2(12.9898, 78.233))) * 43758.5453);
            return h < s.a ? float4(s.rgb / max(s.a, 1e-4), 1.0) : d;
        }
        float3 sc = s.rgb / max(s.a, 1e-4), dc = d.rgb / max(d.a, 1e-4);
        float3 B = blendFn(m, dc, sc);
        float3 rgb = d.rgb * (1.0 - s.a) + s.a * ((1.0 - d.a) * sc + d.a * B);
        return float4(rgb, s.a + d.a * (1.0 - s.a));
    }
    if (u.mode < 0.5) {
        return s + d * (1.0 - s.a);
    } else if (u.mode < 1.5) {
        return d + s;
    } else if (u.mode < 2.5) {
        float3 scr = 1.0 - (1.0 - d.rgb) * (1.0 - s.rgb);
        return mix(d, float4(scr, max(d.a, s.a)), s.a);
    } else if (u.mode < 3.5) {
        float3 mul = d.rgb * s.rgb;
        return mix(d, float4(mul, d.a * s.a), s.a);
    }
    return d + s;
}
"""
}

/// Same field order/layout as FxCommon in MSL.
struct FxCommon {
    var res = SIMD2<Float>(1, 1)
    var lc = SIMD2<Float>(0, 0)
    var lx = SIMD2<Float>(2, 0)
    var ly = SIMD2<Float>(0, 2)
    var time: Float = 0
    var has0: Float = 0
    var has1: Float = 0
    var pad: Float = 0
}

private struct CompParams { var alpha: Float; var mode: Float; var maskMode: Float; var rgbShift: Float }

final class MetalPasses {
    static let shared: MetalPasses? = MetalCore.shared.map { MetalPasses($0) }

    let core: MetalCore
    /// 1x1 transparent texture bound wherever a pass has no mask / input.
    let dummy: MTLTexture
    private(set) var buildError: String?
    private var lib: MTLLibrary?
    private var pipes: [String: MTLRenderPipelineState] = [:]
    private let lock = NSLock()

    private init(_ c: MetalCore) {
        core = c
        let d = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .rgba8Unorm, width: 1, height: 1, mipmapped: false)
        d.usage = .shaderRead
        d.storageMode = .shared
        dummy = c.device.makeTexture(descriptor: d)!
        var zero: [UInt8] = [0, 0, 0, 0]
        dummy.replace(region: MTLRegionMake2D(0, 0, 1, 1), mipmapLevel: 0, withBytes: &zero, bytesPerRow: 4)
        do {
            lib = try c.device.makeLibrary(source: MetalSL.passes, options: nil)
        } catch {
            buildError = String(String(describing: error).prefix(400))
        }
    }

    /// Pipeline for `fragment` (looked up in `library`, default the built-in pass library) writing `format`.
    func pipeline(fragment: String, library: MTLLibrary? = nil, libKey: String = "base",
                  format: MTLPixelFormat) -> MTLRenderPipelineState? {
        let key = "\(libKey)/\(fragment)/\(format.rawValue)"
        lock.lock(); defer { lock.unlock() }
        if let p = pipes[key] { return p }
        guard let base = lib, let vf = base.makeFunction(name: "fsVertex"),
              let ff = (library ?? base).makeFunction(name: fragment) else { return nil }
        let d = MTLRenderPipelineDescriptor()
        d.vertexFunction = vf
        d.fragmentFunction = ff
        d.colorAttachments[0].pixelFormat = format
        guard let p = try? core.device.makeRenderPipelineState(descriptor: d) else { return nil }
        pipes[key] = p
        return p
    }

    /// Same as pipeline() but premultiplied "over" blending (for stacking several copies of a volume).
    func pipelineOver(fragment: String, library: MTLLibrary?, libKey: String, format: MTLPixelFormat) -> MTLRenderPipelineState? {
        let key = "\(libKey)/\(fragment)/\(format.rawValue)/over"
        lock.lock(); defer { lock.unlock() }
        if let p = pipes[key] { return p }
        guard let base = lib, let vf = base.makeFunction(name: "fsVertex"),
              let ff = (library ?? base).makeFunction(name: fragment) else { return nil }
        let d = MTLRenderPipelineDescriptor()
        d.vertexFunction = vf; d.fragmentFunction = ff
        let c = d.colorAttachments[0]!
        c.pixelFormat = format; c.isBlendingEnabled = true
        c.rgbBlendOperation = .add; c.alphaBlendOperation = .add
        c.sourceRGBBlendFactor = .one; c.sourceAlphaBlendFactor = .one
        c.destinationRGBBlendFactor = .oneMinusSourceAlpha; c.destinationAlphaBlendFactor = .oneMinusSourceAlpha
        guard let p = try? core.device.makeRenderPipelineState(descriptor: d) else { return nil }
        pipes[key] = p
        return p
    }

    /// Like encode() but keeps what is already in `target` (no clear).
    func encodeLoad(_ cb: MTLCommandBuffer, into target: MetalTarget, pso: MTLRenderPipelineState,
                    _ setup: (MTLRenderCommandEncoder) -> Void) {
        guard let enc = cb.makeRenderCommandEncoder(descriptor: target.passDescriptor()) else { return }
        enc.setRenderPipelineState(pso)
        setup(enc)
        enc.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 3)
        enc.endEncoding()
    }

    /// Encodes one full-screen pass into `target` (overwrites every pixel, no blending — like GL).
    func encode(_ cb: MTLCommandBuffer, into target: MetalTarget, pso: MTLRenderPipelineState,
                _ setup: (MTLRenderCommandEncoder) -> Void) {
        guard let enc = cb.makeRenderCommandEncoder(
            descriptor: target.passDescriptor(clear: MTLClearColor(red: 0, green: 0, blue: 0, alpha: 0))) else { return }
        enc.setRenderPipelineState(pso)
        setup(enc)
        enc.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 3)
        enc.endEncoding()
    }

    // MARK: - blit

    /// Copies (resamples) `src` into `target`. Replaces SceneRenderer.blit for full-screen copies.
    @discardableResult
    func blit(_ cb: MTLCommandBuffer, src: MTLTexture, to target: MetalTarget) -> Bool {
        guard let pso = pipeline(fragment: "blitFragment", format: target.tex.pixelFormat) else { return false }
        encode(cb, into: target, pso: pso) { $0.setFragmentTexture(src, index: 0) }
        return true
    }

    // MARK: - composite (blend modes)

    /// mode: 0 normal 1 add 2 screen 3 multiply 4 accumulate 5 running average.
    /// maskMode: 0 none 1 alpha 2 inv alpha 3 luma 4 inv luma. `scene` and `out` must differ.
    @discardableResult
    func composite(_ cb: MTLCommandBuffer, scene: MTLTexture, src: MTLTexture, mask: MTLTexture? = nil,
                   alpha: Float, mode: Int, maskMode: Int = 0, rgbShift: Float = 0,
                   to out: MetalTarget) -> Bool {
        guard let pso = pipeline(fragment: "compositeFragment", format: out.tex.pixelFormat) else { return false }
        var u = CompParams(alpha: alpha, mode: Float(mode), maskMode: Float(maskMode), rgbShift: rgbShift)
        encode(cb, into: out, pso: pso) { enc in
            enc.setFragmentBytes(&u, length: MemoryLayout<CompParams>.stride, index: 0)
            enc.setFragmentTexture(scene, index: 0)
            enc.setFragmentTexture(src, index: 1)
            enc.setFragmentTexture(mask ?? self.dummy, index: 2)
        }
        return true
    }

    /// Mirror of SceneRenderer.composite(target:…): composites `src` over `target` through `scratch`,
    /// then swaps the two textures so no copy-back is needed.
    @discardableResult
    func composite(_ cb: MTLCommandBuffer, target: MetalTarget, scratch: MetalTarget, src: MTLTexture,
                   mask: MTLTexture? = nil, alpha: Float, mode: Int, maskMode: Int = 0,
                   rgbShift: Float = 0) -> Bool {
        guard composite(cb, scene: target.tex, src: src, mask: mask, alpha: alpha, mode: mode,
                        maskMode: maskMode, rgbShift: rgbShift, to: scratch) else { return false }
        swap(&target.tex, &scratch.tex)
        return true
    }

    // MARK: - helpers

    /// Creates a shader-readable RGBA8 texture from top-row-first bytes (test patterns, later image layers).
    func makeTexture(width: Int, height: Int, rgba: [UInt8]) -> MTLTexture? {
        let d = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .rgba8Unorm, width: width, height: height, mipmapped: false)
        d.usage = .shaderRead
        d.storageMode = .shared
        guard let t = core.device.makeTexture(descriptor: d) else { return nil }
        rgba.withUnsafeBytes {
            t.replace(region: MTLRegionMake2D(0, 0, width, height), mipmapLevel: 0,
                      withBytes: $0.baseAddress!, bytesPerRow: width * 4)
        }
        return t
    }

    /// Runs `body` on a fresh command buffer and waits for it (tests / thumbnails only).
    func runSync(_ body: (MTLCommandBuffer) -> Void) {
        guard let cb = core.queue.makeCommandBuffer() else { return }
        body(cb)
        cb.commit()
        cb.waitUntilCompleted()
    }
}
