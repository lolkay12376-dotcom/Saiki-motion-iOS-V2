// MistGen.swift — procedural ground mist / mist / valley fog / haze volumes (Render).
// Spec file text: "SAIKIMIST kind seed height fall cover scale detail warp edge stretch dir"
import Foundation

enum MistGen {
    static let kinds = ["Ground mist", "Mist bank", "Valley fog", "Haze"]

    private static func hash(_ x: Int, _ y: Int, _ z: Int, _ s: Int) -> Float {
        var h = UInt32(truncatingIfNeeded: x &* 374761393 &+ y &* 668265263 &+ z &* 1274126177 &+ s &* 362437)
        h = (h ^ (h >> 13)) &* 1274126177; h ^= h >> 16
        return Float(h & 0xFFFFFF) / Float(0xFFFFFF)
    }
    private static func noise(_ x: Float, _ y: Float, _ z: Float, _ s: Int) -> Float {
        let xi = Int(floor(x)), yi = Int(floor(y)), zi = Int(floor(z))
        let fx = x - Float(xi), fy = y - Float(yi), fz = z - Float(zi)
        let u = fx * fx * (3 - 2 * fx), v = fy * fy * (3 - 2 * fy), w = fz * fz * (3 - 2 * fz)
        func h(_ a: Int, _ b: Int, _ c: Int) -> Float { hash(xi + a, yi + b, zi + c, s) }
        let x00 = h(0, 0, 0) + (h(1, 0, 0) - h(0, 0, 0)) * u, x10 = h(0, 1, 0) + (h(1, 1, 0) - h(0, 1, 0)) * u
        let x01 = h(0, 0, 1) + (h(1, 0, 1) - h(0, 0, 1)) * u, x11 = h(0, 1, 1) + (h(1, 1, 1) - h(0, 1, 1)) * u
        let y0 = x00 + (x10 - x00) * v, y1 = x01 + (x11 - x01) * v
        return y0 + (y1 - y0) * w
    }
    private static func fbm(_ x: Float, _ y: Float, _ z: Float, _ s: Int) -> Float {
        var a: Float = 0.5, f: Float = 1, r: Float = 0
        for _ in 0..<4 { r += a * noise(x * f, y * f, z * f, s); f *= 2.03; a *= 0.5 }
        return r / 0.9375
    }
    private static func sstep(_ a: Float, _ b: Float, _ x: Float) -> Float {
        let t = min(max((x - a) / max(b - a, 1e-4), 0), 1); return t * t * (3 - 2 * t)
    }

    static func make(_ spec: String) -> VdbVolume {
        let p = spec.split(separator: " ").dropFirst().map { Float($0) ?? 0 }
        func a(_ i: Int, _ d: Float) -> Float { i < p.count ? p[i] : d }
        let kind = Int(a(0, 0)), seed = Int(a(1, 1))
        let height = max(a(2, 0.3), 0.04), fall = a(3, 2.5), cover = a(4, 0.6), scale = max(a(5, 1), 0.2)
        let detail = a(6, 0.5), warp = a(7, 0.4), edge = max(a(8, 0.25), 0.03), stretch = a(9, 0.3), dir = a(10, 0) * Float.pi / 180
        let nx = 128, ny = 40, nz = 128
        var g = VdbVolume.Grid(); g.nx = nx; g.ny = ny; g.nz = nz; g.voxelSize = 1
        var data = [Float](repeating: 0, count: nx * ny * nz)
        let cd = cosf(dir), sd = sinf(dir), sx = 1 - 0.75 * min(max(stretch, 0), 1)
        // per-column work (warp offsets, edge fade, valley pooling) is done once, not per voxel
        var colW = [SIMD4<Float>](repeating: .zero, count: nx * nz)
        for z in 0..<nz { for x in 0..<nx {
            let fx = Float(x) / Float(nx - 1), fz = Float(z) / Float(nz - 1)
            let wx = (fbm(fx * 2.2 * scale, 3.1, fz * 2.2 * scale, seed + 7) - 0.5) * warp * 1.6
            let wz = (fbm(fx * 2.2 * scale, 9.7, fz * 2.2 * scale, seed + 13) - 0.5) * warp * 1.6
            let fade = sstep(0, edge, min(fx, 1 - fx)) * sstep(0, edge, min(fz, 1 - fz))
            let pool = kind == 2 ? 0.35 + 1.3 * fbm(fx * 1.3 * scale, 5.5, fz * 1.3 * scale, seed + 21) : 1
            colW[x + nx * z] = SIMD4(wx, wz, fade, pool)
        } }
        data.withUnsafeMutableBufferPointer { buf in
            let ptr = buf.baseAddress!
            colW.withUnsafeBufferPointer { cw in
                DispatchQueue.concurrentPerform(iterations: nz) { z in
                    let fz = Float(z) / Float(nz - 1)
                    for y in 0..<ny {
                        let fy = Float(y) / Float(ny - 1)
                        for x in 0..<nx {
                            let fx = Float(x) / Float(nx - 1)
                            let c = cw[x + nx * z]
                            if c.z <= 0.001 { continue }
                            let v = fy / (height * c.w)
                            if v >= 1 { continue }
                            var prof: Float
                            switch kind {
                            case 1: prof = sstep(0, 0.18, v) * (1 - sstep(0.55, 1, v))                  // floating bank, soft top and bottom
                            case 3: prof = (1 - v * v) * 0.8                                            // haze: gentle, almost uniform
                            default: prof = expf(-v * fall) * (1 - sstep(0.6, 1, v))                    // hugs the ground, thins upward
                            }
                            let rx = (fx - 0.5 + c.x) * cd - (fz - 0.5 + c.y) * sd, rz = (fx - 0.5 + c.x) * sd + (fz - 0.5 + c.y) * cd
                            let u = rx * 3.4 * scale * sx + 40, w = rz * 3.4 * scale + 40
                            var n = fbm(u, fy * 2.5 * scale + Float(seed), w, seed)
                            n += (noise(u * 5, fy * 7, w * 5, seed + 3) - 0.5) * detail * 0.55          // fine wisps
                            n += (noise(u * 11, fy * 14, w * 11, seed + 5) - 0.5) * detail * 0.25
                            let t = 1 - min(max(cover, 0), 1)
                            let d = sstep(t - 0.18, t + 0.3, n)
                            ptr[x + nx * (y + ny * z)] = d * prof * c.z * (kind == 3 ? 0.6 : 1)
                        }
                    }
                }
            }
        }
        g.data = data
        let vol = VdbVolume(); vol.grids = [g]
        vol.bounds = (1, 0.3, 1)
        return vol
    }
}

/// Mist settings live on the layer (x3s keys): shape keys rebuild the volume (debounced), look keys are live.
enum MistSettings {
    static let shapeKeys = ["mHeight", "mFall", "mCover", "mScale", "mDetail", "mWarp", "mEdge", "mStretch", "mDir"]
    static let defaults: [Int: [Float]] = [      // height, fall, cover, scale, detail, warp, edge, stretch, dir
        0: [0.22, 3.0, 0.62, 1.0, 0.6, 0.5, 0.25, 0.35, 20],
        1: [0.55, 2.0, 0.55, 0.9, 0.5, 0.45, 0.25, 0.3, 0],
        2: [0.45, 2.5, 0.7, 0.7, 0.45, 0.6, 0.2, 0.2, 0],
        3: [0.9, 1.0, 0.8, 0.5, 0.25, 0.3, 0.3, 0.1, 0]]
    static let looks = ["Neutral", "Cool morning", "Warm sunrise", "Swamp", "Dusk"]

    static func writeFile(_ l: Layer) -> String? {
        var s = "SAIKIMIST \(Int(l.xf("mKind", 0))) \(Int(l.xf("mSeed", 1)))"
        for (i, k) in shapeKeys.enumerated() { s += " \(l.xf(k, defaults[Int(l.xf("mKind", 0))]?[i] ?? 0.5))" }
        guard let d = s.data(using: .utf8) else { return nil }
        return ProjectIO.writeDataIntoSandbox(d, name: "mist_\(nowMs()).vdb")
    }

    static func setup(_ l: Layer, kind: Int) {
        l.xset("mist", 1); l.xset("mKind", Float(kind)); l.xset("mSeed", Float(nowMs() % 9973))
        for (i, k) in shapeKeys.enumerated() { l.xset(k, defaults[kind]![i]) }
        applyLook(l, 0)
        l.vdbDens = kind == 3 ? 0.6 : 1.4; l.vdbEnv = true; l.vdbSurround = true
        l.xset("vdbSteps", 48); l.xset("vdbShadow", 0.6); l.xset("vdbContrast", 0.8)
    }

    static func applyLook(_ l: Layer, _ i: Int) {
        let t: [(UInt32, Float)] = [(0xFFE6EAEE, 1.0), (0xFFC8D8EC, 1.0), (0xFFFFD8B0, 1.3), (0xFFB4C89A, 0.85), (0xFFB09CD0, 0.8)]
        l.vdbTint = Int32(bitPattern: t[i].0); l.vdbBright = t[i].1
    }

    private static var work: DispatchWorkItem?
    /// New shape after the slider settles: build off the main thread, then swap the file in.
    static func rebuildSoon(_ l: Layer, _ done: @escaping () -> Void) {
        work?.cancel()
        let w = DispatchWorkItem {
            guard let p = writeFile(l) else { return }
            _ = VdbVolume.load(p)
            DispatchQueue.main.async {
                let old = l.imagePath
                l.imagePath = p
                if let o = old { VdbVolume.evict(o); try? FileManager.default.removeItem(atPath: o) }
                done()
            }
        }
        work = w
        DispatchQueue.global(qos: .userInitiated).asyncAfter(deadline: .now() + 0.3, execute: w)
    }
}
