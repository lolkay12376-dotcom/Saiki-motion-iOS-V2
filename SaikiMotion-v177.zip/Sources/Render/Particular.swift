// Particular.swift — 3D particle emitter (Render). Pure function of (params, time): scrubbing, caching and export match.
// Positions are layer-local 3D (x/y world units, z depth); the Metal/GL particle renderers project them with the comp camera.

import Foundation

/// Custom life graph (up to 12 points, x = life 0..1, y = 0..1). Stored as plain layer tracks so it saves with the project.
enum PtCurve {
    static let cap = 12
    static let defaults: [String: [(Float, Float)]] = [
        "Op": [(0, 0), (0.2, 1), (0.8, 1), (1, 0)], "Sz": [(0, 0.5), (1, 0.5)], "Sp": [(0, 0.5), (1, 0.5)]]
    static func read(_ g: (String) -> Float, _ id: String) -> [(Float, Float)] {
        let n = min(cap, max(0, Int(g("ptCv\(id)N").rounded())))
        return (0..<n).map { (g("ptCv\(id)X\($0)"), g("ptCv\(id)Y\($0)")) }.sorted { $0.0 < $1.0 }
    }
    static func active(_ g: (String) -> Float, _ id: String) -> [(Float, Float)]? {
        if g("ptCv\(id)On") < 0.5 { return nil }
        let p = read(g, id)
        return p.count >= 2 ? p : nil
    }
    static func eval(_ p: [(Float, Float)], _ x: Float) -> Float {
        guard let f = p.first, let l = p.last else { return 1 }
        if x <= f.0 { return f.1 }
        if x >= l.0 { return l.1 }
        for i in 1..<p.count where x <= p[i].0 {
            let a = p[i - 1], b = p[i], d = max(b.0 - a.0, 0.0001)
            return a.1 + (b.1 - a.1) * (x - a.0) / d
        }
        return l.1
    }
    static func write(_ l: Layer, _ id: String, _ p: [(Float, Float)], pre: String = "") {
        l.track(pre + "ptCv\(id)N").base = Float(p.count)
        for (i, q) in p.enumerated() where i < cap { l.track(pre + "ptCv\(id)X\(i)").base = q.0; l.track(pre + "ptCv\(id)Y\(i)").base = q.1 }
    }
    static var allKeys: [String] {
        ["Op", "Sz", "Sp"].flatMap { id in ["On", "N"].map { "ptCv\(id)\($0)" } + (0..<cap).flatMap { ["ptCv\(id)X\($0)", "ptCv\(id)Y\($0)"] } }
    }
}

/// Particle groups: extra emitters stacked on one layer. Group n>0 stores its parameters under the key prefix "g<n>".
enum PtGroup {
    static let maxExtra = 3
    static func pre(_ g: Int) -> String { g <= 0 ? "" : "g\(g)" }
    static func strip(_ k: String) -> String {
        let u = Array(k.unicodeScalars)
        if u.count > 4, u[0] == "g", u[1].value >= 49, u[1].value <= 51, u[2] == "p", u[3] == "t" { return String(k.dropFirst(2)) }
        return k
    }
    static func count(_ g: (String) -> Float) -> Int { 1 + min(maxExtra, max(0, Int(g("ptGroups").rounded()))) }
    static func reader(_ g: @escaping (String) -> Float, _ gi: Int) -> (String) -> Float { gi <= 0 ? g : { g(pre(gi) + $0) } }
}

/// Surface samples of the 3D model a "Model" emitter sits on (particle-layer-local space), filled by the scene renderer each frame.
enum PtModelSource {
    private static var pts: [Int: [SIMD3<Float>]] = [:]
    private static let lock = NSLock()
    static func set(_ id: Int, _ p: [SIMD3<Float>]) { lock.lock(); pts[id] = p; lock.unlock() }
    static func get(_ id: Int) -> [SIMD3<Float>] { lock.lock(); defer { lock.unlock() }; return pts[id] ?? [] }
}

enum ParticularSim {
    static let emitterNames = ["Point", "Box", "Sphere", "Grid", "Disc", "Ring", "Line", "Cone", "Cylinder", "Torus", "Helix", "Plane", "Shell", "Image", "Video", "Ring XY", "Disc XY", "Model", "Path"]
    static let motionNames = ["Default", "Bidirectional", "Directional", "Disc", "Inward", "Tangent", "Outward"]
    static let behaviorNames = ["Continuous", "Explode", "Dissolve"]
    static let defA: UInt32 = 0xFFFFE08A, defB: UInt32 = 0xFFFF5A1F

    /// Fade in / fade out used by the renderers (a custom opacity graph replaces the fade ramps).
    static func fades(_ g: (String) -> Float) -> (Float, Float) {
        if PtCurve.active(g, "Op") != nil { return (0.001, 0.001) }
        return (max(0.001, g("ptFadeIn")), max(0.001, g("ptFadeOut")))
    }

    /// Divergence-free curl noise (two octaves of an analytic sine potential).
    private static func curl(_ x: Float, _ y: Float, _ z: Float, _ t: Float) -> (Float, Float, Float) {
        func oct(_ x: Float, _ y: Float, _ z: Float, _ t: Float) -> (Float, Float, Float) {
            let a = cos(x * 1.2 + y * 0.6 + t * 1.1 + 3.1), b = cos(z * 1.1 + x * 0.8 + t * 0.7 + 1.7), c = cos(y * 1.3 + z * 0.7 + t * 0.9)
            return (0.6 * a - 1.1 * b, 0.7 * c - 1.2 * a, 0.8 * b - 1.3 * c)
        }
        let o1 = oct(x, y, z, t), o2 = oct(x * 2.1 + 5.2, y * 2.1 + 1.3, z * 2.1 + 9.1, t * 1.3)
        return (o1.0 + 0.5 * o2.0, o1.1 + 0.5 * o2.1, o1.2 + 0.5 * o2.2)
    }

    /// Particles the field will contain (so callers can ask for a sparser `step`).
    /// Trail copies / spacing. Motion blur (when no trails are set) re-uses the copies as shutter samples along the particle's path.
    static func trailCfg(_ g: (String) -> Float) -> (Int, Float, Bool) {
        let mb = g("ptMBlur")
        if mb > 0.001 && g("ptTrail") < 0.5 {
            let n = max(3, min(10, Int(g("ptMBSamples").rounded())))
            return (n - 1, max(0.004, mb * 0.1), true)
        }
        return (max(0, min(10, Int(g("ptTrail").rounded()))), max(0.02, g("ptTrailLen")), false)
    }

    static func total(_ g: (String) -> Float) -> Int {
        let trail = trailCfg(g).0
        return max(1, min(Int(g("ptRate") * max(g("ptLife"), 0.1)), 6000 / (1 + trail))) * (1 + trail)
    }

    static func field(_ g: (String) -> Float, t: Float, step: Int = 1) -> [Particle] {
        let life = max(g("ptLife"), 0.1)
        let (trail, trailLen, mbOn) = trailCfg(g)
        let copies = 1 + trail
        let vol = g("ptVolume")
        let la = g("ptVolLight") * Float.pi / 180
        var lx = cos(la) * 0.8, ly = sin(la) * 0.8, lz: Float = 0.6
        let ll = max((lx * lx + ly * ly + lz * lz).squareRoot(), 0.0001); lx /= ll; ly /= ll; lz /= ll
        let pathLUT: [SIMD3<Float>] = Int(g("ptEmType").rounded()) == 18 ? PtPath.lut(g) : []
        let pathMode = Int(g("ptPathMode").rounded()), pathFlow = g("ptPathFlow"), pathSpeed = g("ptPathSpeed")
        func pp(_ u: Float) -> SIMD3<Float> {
            let f = (u - floor(u)) * Float(pathLUT.count - 1), i = min(pathLUT.count - 2, Int(f)), t = f - Float(i)
            return pathLUT[i] + (pathLUT[i + 1] - pathLUT[i]) * t
        }
        let modelPts: [SIMD3<Float>] = Int(g("ptEmType").rounded()) == 17 ? PtModelSource.get(Int(g("ptModelLayer").rounded())) : []
        let n = max(1, min(Int(g("ptRate") * life), 6000 / copies))
        let seed = g("ptSeed")
        let em = Int(g("ptEmType").rounded()), mo = Int(g("ptMotion").rounded())
        let behavior = Int(g("ptBehavior").rounded())
        let explode = behavior == 1, dissolve = behavior == 2
        let sx = g("ptSizeX"), sy = g("ptSizeY"), sz = g("ptSizeZ")        // radius per axis
        let px = g("ptPosX"), py = g("ptPosY"), pz = g("ptPosZ")
        let vel = g("ptVel"), vr = g("ptVelRand"), spread = g("ptSpread"), lr = g("ptLifeRand")
        var ax = g("ptDirX"), ay = g("ptDirY"), az = g("ptDirZ")
        let al = max((ax * ax + ay * ay + az * az).squareRoot(), 0.0001)
        ax /= al; ay /= al; az /= al
        let grav = g("ptGravity"), wx = g("ptWindX"), wy = g("ptWindY"), wz = g("ptWindZ")
        let air = g("ptAir"), turb = g("ptTurb"), tf = max(g("ptTurbFreq"), 0.05), tsp = g("ptTurbSpeed")
        let swirl = g("ptSwirl"), swPull = g("ptSwirlPull")
        let att = g("ptAttract"), atx = g("ptAttX") - px, aty = g("ptAttY") - py, atz = g("ptAttZ") - pz
        let floorOn = g("ptFloorOn") >= 0.5, floorY = g("ptFloorY"), bounce = g("ptBounce")
        let szr = g("ptSizeRand"), s0 = g("ptSizeStart"), s1 = g("ptSizeEnd")
        let softB = g("ptSoft"), dof = g("ptDof"), focus = g("ptFocus")
        let curlK = g("ptCurl"), curlS = max(g("ptCurlScale"), 0.05), curlSp = g("ptCurlSpeed")
        let waveA = g("ptWaveAmp"), waveF = g("ptWaveFreq"), waveSp = g("ptWaveSpeed"), waveFlow = g("ptWaveFlow")
        let flut = g("ptFlutter"), flutF = max(g("ptFlutterFreq"), 0.1)
        let spin = g("ptSpin"), spinR = g("ptSpinRand"), scat = g("ptScatter"), quant = g("ptQuant")
        let twk = g("ptTwinkle"), twkR = g("ptTwinkleRate")
        let shAmp = g("ptShockAmp"), shSpd = g("ptShockSpeed"), shW = max(g("ptShockWidth"), 0.01), shPer = g("ptShockPeriod"), shGlow = g("ptShockGlow")
        let dStart = g("ptDissStart"), dDur = max(g("ptDissDur"), 0.05), dSweep = g("ptDissSweep")
        let imgId = Int(g("ptEmImgId").rounded()), imgFps = max(g("ptEmFps"), 0.1)
        let fin = fades(g).0
        let cells = max(2, Int(g("ptGridN").rounded()))
        let cells3 = cells * cells * cells
        func gf(_ k: Int) -> Float { Float(k) / Float(cells - 1) - 0.5 }
        let opC = PtCurve.active(g, "Op"), szC = PtCurve.active(g, "Sz"), spC = PtCurve.active(g, "Sp")
        let spCum: [Float] = {
            guard let c = spC else { return [] }
            var r: [Float] = [0]
            for k in 1...32 { r.append(r[k - 1] + (PtCurve.eval(c, Float(k - 1) / 32) + PtCurve.eval(c, Float(k) / 32)) / 32) }
            return r
        }()
        let imgFrames = (em == 13 || em == 14) ? PtImages.frameCount(imgId) : 0
        var out: [Particle] = []
        out.reserveCapacity(n * copies / max(step, 1) + 1)
        var pixCache = [[PtPix]?](repeating: nil, count: max(imgFrames, 1))
        let time = max(0, t)
        let TAU: Float = 6.2831853
        for i in Swift.stride(from: 0, to: n, by: max(step, 1)) {
            let fi = Float(i)
            let h0 = hash(seed * 131 + fi), h1 = hash(seed * 977 + fi * 7), h2 = hash(seed * 3313 + fi * 13)
            let h3 = hash(seed * 6151 + fi * 29), h4 = hash(seed * 17 + fi * 3), h5 = hash(seed * 4001 + fi * 19)
            let h6 = hash(seed * 811 + fi * 23), h7 = hash(seed * 523 + fi * 31), h8 = hash(seed * 7919 + fi * 37)
            let lf = max(0.05, life * (1 - lr * h6 * 0.8))
            var age0 = explode ? time : time - h0 * lf
            age0 = age0.truncatingRemainder(dividingBy: lf)
            if age0 < 0 { age0 += lf }

            var bx: Float = 0, by: Float = 0, bz: Float = 0
            var pj = SIMD3<Float>(0, 0, 0)
            var pr: Float = 1, pg: Float = 1, pb: Float = 1
            switch em {
            case 1:
                bx = (h1 * 2 - 1) * sx; by = (h2 * 2 - 1) * sy; bz = (h5 * 2 - 1) * sz
            case 2:
                let u = h2 * 2 - 1, a = h1 * TAU, r = cbrt(h5), rr = (1 - u * u).squareRoot()
                bx = rr * cos(a) * r * sx; by = rr * sin(a) * r * sy; bz = u * r * sz
            case 3:
                let c = i % cells3
                bx = gf(c % cells) * 2 * sx; by = gf((c / cells) % cells) * 2 * sy; bz = gf(c / (cells * cells)) * 2 * sz
            case 4:
                let a = h1 * TAU, r = h5.squareRoot()
                bx = cos(a) * r * sx; bz = sin(a) * r * sz; by = (h2 * 2 - 1) * sy * 0.1
            case 5:
                let a = h1 * TAU
                bx = cos(a) * sx; bz = sin(a) * sz; by = (h2 * 2 - 1) * sy * 0.1
            case 6:
                bx = (h1 * 2 - 1) * sx
            case 7:
                let hh = h2, a = h1 * TAU, r = h5.squareRoot() * hh
                bx = cos(a) * r * sx; bz = sin(a) * r * sz; by = (hh * 2 - 1) * sy
            case 8:
                let a = h1 * TAU, r = h5.squareRoot()
                bx = cos(a) * r * sx; bz = sin(a) * r * sz; by = (h2 * 2 - 1) * sy
            case 9:
                let a = h1 * TAU, b = h2 * TAU, k = sx + sy * cos(b)
                bx = k * cos(a); bz = k * sin(a); by = sy * sin(b)
            case 10:
                let a = h2 * TAU * 3
                bx = cos(a) * sx; bz = sin(a) * sz; by = (h2 * 2 - 1) * sy
            case 11:
                bx = (h1 * 2 - 1) * sx; by = (h2 * 2 - 1) * sy; bz = (h5 * 2 - 1) * sz * 0.05
            case 12:
                let u = h2 * 2 - 1, a = h1 * TAU, rr = (1 - u * u).squareRoot()
                bx = rr * cos(a) * sx; by = rr * sin(a) * sy; bz = u * sz
            case 13, 14:
                var pix: [PtPix] = []
                if imgFrames > 0 {
                    let fr = em == 14 ? Int(floor(max(0, dissolve ? time : time - age0) * imgFps)) % imgFrames : 0
                    if pixCache[fr] == nil { pixCache[fr] = PtImages.points(imgId, frame: fr) }
                    pix = pixCache[fr] ?? []
                }
                if pix.isEmpty {
                    bx = (h1 * 2 - 1) * sx; by = (h2 * 2 - 1) * sy; bz = (h5 * 2 - 1) * sz * 0.05
                } else {
                    let q = pix[min(pix.count - 1, Int(h1 * Float(pix.count)))]
                    bx = q.x * 2 * sx; by = q.y * 2 * sy; bz = (h5 * 2 - 1) * sz * 0.05
                    pr = q.r; pg = q.g; pb = q.b
                }
            case 15:
                let a = h1 * TAU
                bx = cos(a) * sx; by = sin(a) * sy; bz = (h5 * 2 - 1) * sz * 0.02
            case 16:
                let a = h1 * TAU, r = h5.squareRoot()
                bx = cos(a) * r * sx; by = sin(a) * r * sy; bz = (h2 * 2 - 1) * sz * 0.02
            case 18:   // path: spawn along the drawn curve (or at a travelling head), jittered by the radius
                pj = SIMD3((h2 * 2 - 1) * sx, (h5 * 2 - 1) * sx, (h3 * 2 - 1) * sx)
                if pathLUT.isEmpty { bx = (h1 * 2 - 1) * sx * 4; by = (h2 * 2 - 1) * sy; bz = (h5 * 2 - 1) * sz }
                else {
                    let u0 = pathMode == 1 ? (time - age0) * pathSpeed : h1
                    let q = pp(u0)
                    bx = q.x + pj.x; by = q.y + pj.y; bz = q.z + pj.z
                }
            case 17:
                if modelPts.isEmpty {
                    bx = (h1 * 2 - 1) * sx; by = (h2 * 2 - 1) * sy; bz = (h5 * 2 - 1) * sz
                } else {
                    let q = modelPts[min(modelPts.count - 1, Int(h1 * Float(modelPts.count)))]
                    bx = q.x + (h2 * 2 - 1) * 0.008; by = q.y + (h5 * 2 - 1) * 0.008; bz = q.z + (h3 * 2 - 1) * 0.008
                }
            default: break
            }
            // Volumetric shading: lit side towards the light, self-shadowed core / underside (multiplies the sprite colour).
            if vol > 0.001 && em != 13 && em != 14 {
                let nx = bx / max(sx, 0.001), ny = by / max(sy, 0.001), nz = bz / max(sz, 0.001)
                let nl = max((nx * nx + ny * ny + nz * nz).squareRoot(), 0.0001)
                let lit = min(1, max(0, 0.5 + 0.5 * (nx * lx + ny * ly + nz * lz) / nl))
                let rim = min(1, nl)
                let s = max(0.05, 1 - vol * (0.7 * (1 - lit) + 0.3 * (1 - rim) * (1 - lit * 0.5)))
                pr = s; pg = s * (0.96 + 0.04 * lit); pb = s * (0.88 + 0.12 * lit)
            }

            let u = h3 * 2 - 1, a = h4 * TAU, rr = (1 - u * u).squareRoot()
            let rx = rr * cos(a), ry = rr * sin(a), rz = u
            var vx = rx, vy = ry, vz = rz
            switch mo {
            case 1:
                let s: Float = h0 < 0.5 ? -1 : 1
                vx = ax * s + rx * spread; vy = ay * s + ry * spread; vz = az * s + rz * spread
            case 2:
                vx = ax + rx * spread; vy = ay + ry * spread; vz = az + rz * spread
            case 3:
                let d = rx * ax + ry * ay + rz * az
                vx = rx - d * ax; vy = ry - d * ay; vz = rz - d * az
            case 4, 6:
                let l = max((bx * bx + by * by + bz * bz).squareRoot(), 0.0001), s: Float = mo == 4 ? -1 : 1
                vx = s * bx / l + rx * spread * 0.3; vy = s * by / l + ry * spread * 0.3; vz = s * bz / l + rz * spread * 0.3
            case 5:
                let l = max((bx * bx + bz * bz).squareRoot(), 0.0001)
                vx = -bz / l + rx * spread * 0.3; vy = ry * spread * 0.3; vz = bx / l + rz * spread * 0.3
            default: break
            }
            let spd: Float = vel * (1 - vr * h7) * (quant > 0.0001 ? 0.5 + hash(floor(bx / quant) * 13.7 + seed) : 1)   // each snapped column falls at its own speed
            let birthT = time - age0

            // Position at a given age (pure function of age + the per-particle constants above).
            func place(_ age: Float) -> (Float, Float, Float, Float) {
                let p = age / lf
                var travel = age
                if spC != nil {
                    let f = min(max(p, 0), 1) * 32, k = min(31, Int(f))
                    travel = lf * (spCum[k] + (spCum[k + 1] - spCum[k]) * (f - Float(k)))
                } else if air > 0.001 { let k = air * 4; travel = (1 - exp(-k * age)) / k }
                var pbx = bx, pby = by, pbz = bz
                if em == 18 && pathMode == 0 && !pathLUT.isEmpty && abs(pathFlow) > 0.0001 {   // particles travel along the path
                    let q = pp(h1 + age * pathFlow)
                    pbx = q.x + pj.x; pby = q.y + pj.y; pbz = q.z + pj.z
                }
                var x = pbx + vx * spd * travel + 0.5 * wx * age * age
                var y = pby + vy * spd * travel + 0.5 * (wy - grav) * age * age
                var z = pbz + vz * spd * travel + 0.5 * wz * age * age
                if turb > 0.001 {
                    let ph = age * 0.9 * tsp + h1 * TAU
                    x += sin(y * tf * 3 + ph) * turb * 0.15
                    y += sin(z * tf * 3 + ph * 1.3 + 1.7) * turb * 0.15
                    z += sin(x * tf * 3 + ph * 0.7 + 3.1) * turb * 0.15
                }
                if curlK > 0.001 && age > 0 {
                    let K = 6, dt = age / Float(K)
                    var qx: Float = 0, qy: Float = 0, qz: Float = 0
                    for k in 0..<K {
                        let tt = Float(k) * dt
                        let sx0: Float = (bx + vx * spd * tt + qx) * curlS
                        let sy0: Float = (by + vy * spd * tt + qy) * curlS
                        let sz0: Float = (bz + vz * spd * tt + qz) * curlS
                        let c = curl(sx0, sy0, sz0, (birthT + tt) * curlSp)
                        let kk: Float = curlK * dt * 0.6
                        qx += c.0 * kk; qy += c.1 * kk; qz += c.2 * kk
                    }
                    x += qx; y += qy; z += qz
                }
                if waveA > 0.001 || abs(waveFlow) > 0.001 {
                    let wt = birthT + age
                    y += waveA * sin(waveF * x + waveSp * wt) * cos(waveF * 0.8 * z + waveSp * 0.7 * wt + 1.3)
                    x += waveFlow * age
                }
                if flut > 0.001 {
                    let fph = h1 * TAU
                    x += sin(age * flutF + fph) * flut * 0.18 * (0.4 + 0.6 * h2)
                    z += cos(age * flutF * 0.8 + fph * 1.3) * flut * 0.18 * (0.4 + 0.6 * h5)
                    y += sin(age * flutF * 1.7 + fph) * flut * 0.03
                }
                var boost: Float = 0
                if shAmp > 0.001 {                                  // expanding shockwave front pushes particles radially
                    let r0 = max((bx * bx + by * by + bz * bz).squareRoot(), 0.0001)
                    let wt = shPer > 0.01 ? (birthT + age).truncatingRemainder(dividingBy: shPer) : (birthT + age)
                    let d = (r0 - shSpd * wt) / shW, gs = exp(-d * d)
                    x += bx / r0 * shAmp * gs; y += by / r0 * shAmp * gs; z += bz / r0 * shAmp * gs
                    boost = gs
                }
                if scat > 0.001 && age > 0 {
                    let sc = scat * pow(age, 1.3) * 0.5
                    x += rx * sc; y += ry * sc; z += rz * sc
                }
                if abs(swirl) > 0.001 || swPull > 0.001 {          // spiral around the emitter's Y axis
                    let ang = swirl * age, ca = cos(ang), sa = sin(ang), k = 1 - swPull * p
                    let nx = (x * ca - z * sa) * k, nz = (x * sa + z * ca) * k
                    x = nx; z = nz
                }
                if att > 0.001 {                                    // attractor point pulls particles in over their life
                    let m = min(1, att * p)
                    x += (atx - x) * m; y += (aty - y) * m; z += (atz - z) * m
                }
                if quant > 0.0001 {
                    x = (floor(x / quant) + 0.5) * quant; z = (floor(z / quant) + 0.5) * quant
                    y = (floor(y / (quant * 1.3)) + 0.5) * quant * 1.3
                }
                x += px; y += py; z += pz
                if floorOn && y < floorY { y = floorY + (floorY - y) * bounce }
                return (x, y, z, boost)
            }

            // Dissolve: hold at the emitter shape, then release each particle at its own moment.
            var mainAge = age0
            var held = false
            if dissolve {
                let sweep = min(1, max(0, bx / max(sx, 0.0001) * 0.5 + 0.5))
                let thr = h6 * (1 - dSweep) + sweep * dSweep
                mainAge = time - (dStart + thr * dDur)
                if mainAge < 0 { held = true; mainAge = 0 }
                else if mainAge >= lf { continue }
            }
            for c in 0..<copies {
                if held && c > 0 { break }
                let age = mainAge - Float(c) * trailLen / Float(max(trail, 1))
                if age < 0 && !held { continue }
                let p0 = max(0, age) / lf
                let p = dissolve ? min(1, fin + p0 * (1 - fin)) : p0
                let pos = place(max(0, age))
                let tf2: Float = mbOn ? (c == 0 ? 1 : 0.55 * (1 - Float(c) / Float(copies)) + 0.1) : 1 - Float(c) / Float(copies)
                let base = (1 - szr) + szr * h2 * 1.8
                let size = base * (szC != nil ? PtCurve.eval(szC!, p) * 2 : s0 + (s1 - s0) * p) * (mbOn ? 1 : 1 - 0.5 * Float(c) / Float(copies)) * (1 + pos.3 * shGlow)
                let soft = min(1, max(0, softB + abs(pos.2 - focus) * dof * 0.8))
                var alpha: Float = (opC != nil ? PtCurve.eval(opC!, p) : 1) * tf2
                if twk > 0.001 { alpha *= 1 - twk * (0.5 + 0.5 * sin(max(0, age) * max(twkR, 0.1) * TAU + h5 * TAU)) }
                out.append(Particle(x: pos.0, y: pos.1, z: pos.2, size: size, life: p, soft: soft, alpha: alpha,
                                    rot: h4 * TAU * spinR + spin * max(0, age) * (0.6 + 0.8 * h6), vari: h8, cr: pr, cg: pg, cb: pb))
            }
        }
        return out
    }

    private static func hash(_ x: Float) -> Float {
        var n = UInt32(truncatingIfNeeded: Int64(x * 8192.0))
        n = n &* 747796405 &+ 2891336453
        n = ((n >> ((n >> 28) + 4)) ^ n) &* 277803737
        n = (n >> 22) ^ n
        return Float(n % 100000) / 100000
    }
}
