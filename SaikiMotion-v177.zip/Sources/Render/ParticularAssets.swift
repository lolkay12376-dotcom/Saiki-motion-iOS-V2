// ParticularAssets.swift — Particular extras (Render): multi-stop gradients, sprite sheets (built-in + imported image / video),
// image-emitter sampling, and the preset library (.saikiparticle files). Everything a preset needs is plain Float layer tracks,
// so presets, projects and the designer's Cancel snapshot all share one representation: [String: Float].

import Foundation
import UIKit
import AVFoundation
import simd

// MARK: - Path emitter data (drawn in the designer, stored as plain Float tracks)

enum PtPath {
    static let cap = 24
    static var allKeys: [String] { ["ptPathN"] + (0..<cap).flatMap { ["ptPathX\($0)", "ptPathY\($0)", "ptPathZ\($0)"] } }
    static func read(_ g: (String) -> Float) -> [SIMD3<Float>] {
        let n = min(cap, max(0, Int(g("ptPathN").rounded())))
        return (0..<n).map { SIMD3(g("ptPathX\($0)"), g("ptPathY\($0)"), g("ptPathZ\($0)")) }
    }
    static func params(_ pts: [SIMD3<Float>], closed: Bool = false) -> [String: Float] {
        var d: [String: Float] = ["ptPathN": Float(min(cap, pts.count)), "ptPathClosed": closed ? 1 : 0]
        for (i, p) in pts.prefix(cap).enumerated() { d["ptPathX\(i)"] = p.x; d["ptPathY\(i)"] = p.y; d["ptPathZ\(i)"] = p.z }
        return d
    }
    static func write(_ l: Layer, _ pts: [SIMD3<Float>], pre: String = "") {
        for (k, v) in params(pts) where k != "ptPathClosed" { l.track(pre + k).base = v }
    }
    /// n points evenly spaced by arc length along the polyline.
    static func resample(_ pts: [SIMD3<Float>], _ n: Int) -> [SIMD3<Float>] {
        guard pts.count >= 2, n >= 2 else { return pts }
        var cum: [Float] = [0]
        for i in 1..<pts.count { cum.append(cum[i - 1] + simd_length(pts[i] - pts[i - 1])) }
        let total = cum[cum.count - 1]
        guard total > 1e-6 else { return Array(repeating: pts[0], count: n) }
        var out: [SIMD3<Float>] = [], j = 1
        for k in 0..<n {
            let t = total * Float(k) / Float(n - 1)
            while j < cum.count - 1 && cum[j] < t { j += 1 }
            let seg = max(cum[j] - cum[j - 1], 1e-6), f = min(1, max(0, (t - cum[j - 1]) / seg))
            out.append(pts[j - 1] + (pts[j] - pts[j - 1]) * f)
        }
        return out
    }
    /// Smooth (Catmull-Rom) path as 128 evenly spaced samples; empty when fewer than 2 points.
    static func lut(_ g: (String) -> Float) -> [SIMD3<Float>] {
        let c = read(g), n = c.count
        guard n >= 2 else { return [] }
        let closed = g("ptPathClosed") >= 0.5
        func at(_ i: Int) -> SIMD3<Float> { closed ? c[((i % n) + n) % n] : c[min(n - 1, max(0, i))] }
        var dense: [SIMD3<Float>] = []
        for i in 0..<(closed ? n : n - 1) {
            let p0 = at(i - 1), p1 = at(i), p2 = at(i + 1), p3 = at(i + 2)
            for s in 0..<12 {
                let t = Float(s) / 12, t2 = t * t, t3 = t2 * t
                let two: Float = 2, three: Float = 3, four: Float = 4, five: Float = 5, half: Float = 0.5
                let a: SIMD3<Float> = p1 * two
                let b: SIMD3<Float> = (p2 - p0) * t
                var c0: SIMD3<Float> = p0 * two
                c0 = c0 - p1 * five
                c0 = c0 + p2 * four
                c0 = c0 - p3
                let c: SIMD3<Float> = c0 * t2
                var d0: SIMD3<Float> = p1 * three
                d0 = d0 - p0
                d0 = d0 - p2 * three
                d0 = d0 + p3
                let d: SIMD3<Float> = d0 * t3
                let sum: SIMD3<Float> = a + b + c + d
                dense.append(sum * half)
            }
        }
        dense.append(closed ? c[0] : c[n - 1])
        return resample(dense, 128)
    }
}

// MARK: - Parameter access

enum PtParams {
    /// Default of any Particular parameter (registry default, birth/death colour defaults, else 0).
    static func def(_ key: String) -> Float {
        let k = PtGroup.strip(key)
        if let d = Registry.propDef(k) { return d.def }
        for (n, c) in [("ptColA", ParticularSim.defA), ("ptColB", ParticularSim.defB)] where k.hasPrefix(n + "_") {
            switch k.suffix(1) {
            case "a": return Float((c >> 24) & 0xFF) / 255
            case "r": return Float((c >> 16) & 0xFF) / 255
            case "g": return Float((c >> 8) & 0xFF) / 255
            default: return Float(c & 0xFF) / 255
            }
        }
        return 0
    }
    static func reader(_ d: [String: Float]) -> (String) -> Float { { d[$0] ?? def($0) } }
    static func colorKeys(_ n: String) -> [String] { ["_r", "_g", "_b", "_a"].map { n + $0 } }
    /// Every key a preset can carry.
    static var allKeys: [String] {
        var base: [String] = []
        if let d = Registry.get("particular") { base += d.props.map { $0.key } }
        base += colorKeys("ptColA") + colorKeys("ptColB") + PtCurve.allKeys + PtGradient.allKeys + PtPath.allKeys
        var k = base
        for gi in 1...PtGroup.maxExtra { k += base.filter { $0 != "ptGroups" }.map { PtGroup.pre(gi) + $0 } }
        return k
    }
    /// Keys of one group (no prefix), without the group count itself.
    static var baseKeys: [String] { allKeys.filter { PtGroup.strip($0) == $0 && $0 != "ptGroups" } }
    static func color(_ n: String, _ c: UInt32) -> [String: Float] {
        [n + "_a": Float((c >> 24) & 0xFF) / 255, n + "_r": Float((c >> 16) & 0xFF) / 255, n + "_g": Float((c >> 8) & 0xFF) / 255, n + "_b": Float(c & 0xFF) / 255]
    }
}

// MARK: - Gradient over particle life

struct PtStop { var p: Float; var r: Float; var g: Float; var b: Float; var a: Float
    var argb: UInt32 {
        func q(_ v: Float) -> UInt32 { UInt32(max(0, min(255, v * 255 + 0.5))) }
        return q(a) << 24 | q(r) << 16 | q(g) << 8 | q(b)
    }
    static func from(_ c: UInt32, _ p: Float) -> PtStop {
        PtStop(p: p, r: Float((c >> 16) & 0xFF) / 255, g: Float((c >> 8) & 0xFF) / 255, b: Float(c & 0xFF) / 255, a: Float((c >> 24) & 0xFF) / 255)
    }
}

enum PtGradient {
    static let cap = 8
    static func read(_ g: (String) -> Float) -> [PtStop] {
        let n = min(cap, max(0, Int(g("ptGrN").rounded())))
        return (0..<n).map { PtStop(p: g("ptGrP\($0)"), r: g("ptGrR\($0)"), g: g("ptGrG\($0)"), b: g("ptGrB\($0)"), a: g("ptGrA\($0)")) }.sorted { $0.p < $1.p }
    }
    static func active(_ g: (String) -> Float) -> [PtStop]? {
        if g("ptGrOn") < 0.5 { return nil }
        let s = read(g)
        return s.count >= 2 ? s : nil
    }
    static func params(_ s: [PtStop], on: Bool = true) -> [String: Float] {
        var d: [String: Float] = ["ptGrOn": on ? 1 : 0, "ptGrN": Float(min(cap, s.count))]
        for (i, q) in s.enumerated() where i < cap { d["ptGrP\(i)"] = q.p; d["ptGrR\(i)"] = q.r; d["ptGrG\(i)"] = q.g; d["ptGrB\(i)"] = q.b; d["ptGrA\(i)"] = q.a }
        return d
    }
    static func write(_ l: Layer, _ s: [PtStop], pre: String = "") {
        for (k, v) in params(s, on: true) { l.track(pre + k).base = v }
    }
    static var allKeys: [String] {
        ["ptGrOn", "ptGrN", "ptGrBy"] + (0..<cap).flatMap { ["ptGrP\($0)", "ptGrR\($0)", "ptGrG\($0)", "ptGrB\($0)", "ptGrA\($0)"] }
    }
    static func evenly(_ colors: [UInt32]) -> [PtStop] {
        colors.enumerated().map { PtStop.from($0.element, colors.count > 1 ? Float($0.offset) / Float(colors.count - 1) : 0) }
    }
    static func eval(_ s: [PtStop], _ x: Float) -> SIMD4<Float> {
        guard let f = s.first, let l = s.last else { return SIMD4(1, 1, 1, 1) }
        func v(_ q: PtStop) -> SIMD4<Float> { SIMD4(q.r, q.g, q.b, q.a) }
        if x <= f.p { return v(f) }
        if x >= l.p { return v(l) }
        for i in 1..<s.count where x <= s[i].p {
            let a = s[i - 1], b = s[i], t = (x - a.p) / max(b.p - a.p, 0.0001)
            return v(a) + (v(b) - v(a)) * t
        }
        return v(l)
    }
    /// 16 samples for the shader.
    static func lut(_ s: [PtStop]?) -> [SIMD4<Float>] {
        guard let s = s else { return [SIMD4<Float>](repeating: SIMD4(1, 1, 1, 1), count: 16) }
        return (0..<16).map { eval(s, Float($0) / 15) }
    }

    static let presets: [(String, [UInt32])] = [
        ("Fire", [0xFFFFF2B0, 0xFFFFB020, 0xFFFF4A00, 0xFF8A0F00, 0x00300000]),
        ("Ember", [0xFFFFE08A, 0xFFFF7A1F, 0xFFC62800, 0x00400000]),
        ("Lava", [0xFFFFFF9A, 0xFFFF8800, 0xFFC1121F, 0xFF3A0000]),
        ("Sparks", [0xFFFFFFFF, 0xFFFFE27A, 0xFFFF7A1F, 0x00FF3B00]),
        ("Thermal", [0xFFFFFFFF, 0xFFFFFF00, 0xFFFF6A00, 0xFFFF0000, 0xFF400000]),
        ("Gold", [0xFFFFF4C2, 0xFFFFD34D, 0xFFD18A00, 0xFF6B3E00]),
        ("Glisten", [0xFFFFF8E0, 0xFFF2D49A, 0xFFC9A063, 0x00706040]),
        ("Ice", [0xFFFFFFFF, 0xFFA8E6FF, 0xFF38BDF8, 0x001E3A8A]),
        ("Ocean", [0xFFB8F3FF, 0xFF22A6D9, 0xFF0B4F8A, 0xFF031B3D]),
        ("Aurora", [0xFF7CFFB2, 0xFF2BD9C8, 0xFF5B6CFF, 0xFFB05BFF]),
        ("Sunset", [0xFFFFD27A, 0xFFFF7A59, 0xFFD6336C, 0xFF5B2A86]),
        ("Neon", [0xFFFF2BD6, 0xFF8A2BFF, 0xFF2BFFE0]),
        ("Plasma", [0xFFFFFFFF, 0xFFFF6AD5, 0xFF7C3AED, 0xFF1D1B6B]),
        ("Galaxy", [0xFFFFFFFF, 0xFFA8B8FF, 0xFF6A4CFF, 0xFF2A0F6B]),
        ("Twilight", [0xFFFFC4A3, 0xFFB05BFF, 0xFF1D1B6B]),
        ("Rose", [0xFFFF8FA3, 0xFFE01E37, 0xFF8A0A22]),
        ("Blood", [0xFFFF5A5A, 0xFFB00020, 0xFF3A0008]),
        ("Sakura", [0xFFFFFFFF, 0xFFFFD6E4, 0xFFFF9FC0]),
        ("Candy", [0xFFFF8AD8, 0xFFFFE66D, 0xFF6DE6FF]),
        ("Rainbow", [0xFFFF3B3B, 0xFFFFB020, 0xFFFFF04A, 0xFF3BE06B, 0xFF3B9BFF, 0xFF9B4BFF]),
        ("Matrix", [0xFF00561F, 0xFF00E050, 0xFFB8FFC8, 0xFFFFFFFF]),
        ("Toxic", [0xFFEFFF8A, 0xFF9BE000, 0xFF2F7A00]),
        ("Forest", [0xFFD9FF9A, 0xFF4DBB4A, 0xFF14532D]),
        ("Mint", [0xFFEFFFF8, 0xFF86F5CF, 0xFF1BB894]),
        ("Smoke", [0xFFFFFFFF, 0xFF9A9AA6, 0x003A3A44]),
        ("Steel", [0xFFFFFFFF, 0xFFB7C4D6, 0xFF5E6E85]),
        ("White Fade", [0xFFFFFFFF, 0xFFFFFFFF, 0x00FFFFFF]),
        ("Cyan Fade", [0xFFFFFFFF, 0xFF38BDF8, 0x000B4F8A]),
    ]
}

// MARK: - Imported images / videos (sprite sheets and emitter shapes)

struct PtPix { var x: Float; var y: Float; var r: Float; var g: Float; var b: Float }

/// Imported media lives in Documents/ParticleSprites/<id>_<cells>.png, always a 512x512 sheet:
/// cells == 1 → one image; cells == 16 → a 4x4 flipbook of video frames. The id is stored in a Float track.
enum PtImages {
    static let size = 512
    private static var cache: [Int: (CGImage, Int)] = [:]
    private static var pts: [String: [PtPix]] = [:]
    private static let lock = NSLock()

    static var dir: URL {
        let d = (FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first ?? FileManager.default.temporaryDirectory).appendingPathComponent("ParticleSprites")
        try? FileManager.default.createDirectory(at: d, withIntermediateDirectories: true)
        return d
    }
    static func grid(_ cells: Int) -> Int { cells <= 1 ? 1 : (cells <= 4 ? 2 : 4) }

    private static func file(_ id: Int) -> (URL, Int)? {
        guard id > 0, let fs = try? FileManager.default.contentsOfDirectory(at: dir, includingPropertiesForKeys: nil) else { return nil }
        for f in fs where f.lastPathComponent.hasPrefix("\(id)_") && f.pathExtension == "png" {
            let c = Int(f.deletingPathExtension().lastPathComponent.split(separator: "_").last ?? "1") ?? 1
            return (f, c)
        }
        return nil
    }
    static func load(_ id: Int) -> (CGImage, Int)? {
        lock.lock(); defer { lock.unlock() }
        if let c = cache[id] { return c }
        guard let (u, c) = file(id), let im = UIImage(contentsOfFile: u.path)?.cgImage else { return nil }
        cache[id] = (im, c)
        return (im, c)
    }
    static func frameCount(_ id: Int) -> Int { load(id)?.1 ?? 0 }
    static func data(_ id: Int) -> (Data, Int)? {
        guard let (u, c) = file(id), let d = try? Data(contentsOf: u) else { return nil }
        return (d, c)
    }

    private static func newId() -> Int {
        var id = Int.random(in: 1000...16_000_000)
        while file(id) != nil { id = Int.random(in: 1000...16_000_000) }
        return id
    }
    private static func fit(_ im: CGImage, in r: CGRect) -> CGRect {
        let s = min(r.width / CGFloat(im.width), r.height / CGFloat(im.height))
        let w = CGFloat(im.width) * s, h = CGFloat(im.height) * s
        return CGRect(x: r.midX - w / 2, y: r.midY - h / 2, width: w, height: h)
    }
    private static func sheet(_ frames: [CGImage]) -> UIImage {
        let g = grid(frames.count), cs = CGFloat(size / g)
        let f = UIGraphicsImageRendererFormat(); f.scale = 1; f.opaque = false
        return UIGraphicsImageRenderer(size: CGSize(width: size, height: size), format: f).image { r in
            let c = r.cgContext
            for (i, im) in frames.enumerated() {
                let cell = CGRect(x: CGFloat(i % g) * cs, y: CGFloat(i / g) * cs, width: cs, height: cs)
                let d = fit(im, in: cell.insetBy(dx: 1, dy: 1))
                c.saveGState(); c.translateBy(x: 0, y: d.minY * 2 + d.height); c.scaleBy(x: 1, y: -1)   // CGImage draws bottom-up
                c.draw(im, in: d); c.restoreGState()
            }
        }
    }
    @discardableResult static func add(frames: [CGImage]) -> Int? {
        guard !frames.isEmpty, let png = sheet(frames).pngData() else { return nil }
        let id = newId()
        let u = dir.appendingPathComponent("\(id)_\(frames.count <= 1 ? 1 : 16).png")
        do { try png.write(to: u) } catch { return nil }
        return id
    }
    /// Photo on a black background -> transparent background (alpha from brightness).
    static func keyBlack(_ im: UIImage) -> UIImage {
        guard let cg = im.cgImage else { return im }
        let s = min(1.0, 1024.0 / CGFloat(max(cg.width, cg.height)))
        let w = max(1, Int(CGFloat(cg.width) * s)), h = max(1, Int(CGFloat(cg.height) * s))
        var d = [UInt8](repeating: 0, count: w * h * 4)
        let ok: Bool = d.withUnsafeMutableBytes { raw in
            guard let c = CGContext(data: raw.baseAddress, width: w, height: h, bitsPerComponent: 8, bytesPerRow: w * 4,
                                    space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            c.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h)); return true
        }
        guard ok else { return im }
        for i in 0..<(w * h) {
            let r = Float(d[i * 4]), g = Float(d[i * 4 + 1]), b = Float(d[i * 4 + 2])
            let a = min(1, max(0, (max(r, g, b) / 255 - 0.05) / 0.1))
            d[i * 4] = UInt8(r * a); d[i * 4 + 1] = UInt8(g * a); d[i * 4 + 2] = UInt8(b * a); d[i * 4 + 3] = UInt8(a * 255)
        }
        let out: CGImage? = d.withUnsafeMutableBytes { raw in
            CGContext(data: raw.baseAddress, width: w, height: h, bitsPerComponent: 8, bytesPerRow: w * 4,
                      space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)?.makeImage()
        }
        return out.map { UIImage(cgImage: $0) } ?? im
    }
    static func add(image: UIImage) -> Int? { image.cgImage.flatMap { add(frames: [$0]) } }
    static func add(data: Data, cells: Int) -> Int? {
        let id = newId()
        let u = dir.appendingPathComponent("\(id)_\(cells <= 1 ? 1 : 16).png")
        do { try data.write(to: u) } catch { return nil }
        return id
    }
    /// 16 evenly spaced frames of a video into a flipbook.
    static func add(video url: URL, _ done: @escaping (Int?) -> Void) {
        let a = AVURLAsset(url: url)
        let dur = max(0.1, CMTimeGetSeconds(a.duration))
        let gen = AVAssetImageGenerator(asset: a)
        gen.appliesPreferredTrackTransform = true
        gen.maximumSize = CGSize(width: 256, height: 256)
        gen.requestedTimeToleranceBefore = .positiveInfinity; gen.requestedTimeToleranceAfter = .positiveInfinity
        let times = (0..<16).map { NSValue(time: CMTime(seconds: dur * Double($0) / 16, preferredTimescale: 600)) }
        var frames: [Int: CGImage] = [:], left = 16
        gen.generateCGImagesAsynchronously(forTimes: times) { req, im, _, _, _ in
            let i = times.firstIndex { $0.timeValue == req } ?? 0
            DispatchQueue.main.async {
                if let im = im { frames[i] = im }
                left -= 1
                if left == 0 {
                    let ordered = (0..<16).compactMap { frames[$0] }
                    done(ordered.count == 16 ? add(frames: ordered) : nil)
                }
            }
        }
    }

    /// Emitter points of one frame (alpha, or brightness for opaque media), x/y in -0.5…0.5, with pixel colour.
    static func points(_ id: Int, frame: Int) -> [PtPix] {
        let key = "\(id)#\(frame)"
        lock.lock(); if let p = pts[key] { lock.unlock(); return p }; lock.unlock()
        guard let (im, cells) = load(id) else { return [] }
        let g = grid(cells), cs = size / g, f = ((frame % max(cells, 1)) + max(cells, 1)) % max(cells, 1)
        var data = [UInt8](repeating: 0, count: size * size * 4)
        let ok: Bool = data.withUnsafeMutableBytes { raw in
            guard let c = CGContext(data: raw.baseAddress, width: size, height: size, bitsPerComponent: 8, bytesPerRow: size * 4,
                                    space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            c.draw(im, in: CGRect(x: 0, y: 0, width: size, height: size)); return true
        }
        guard ok else { return [] }
        var out: [PtPix] = []
        let step = max(1, cs / 128), ox = (f % g) * cs, oy = (f / g) * cs
        var yy = 0
        while yy < cs {
            var xx = 0
            while xx < cs {
                let i = ((oy + yy) * size + ox + xx) * 4
                let a = Float(data[i + 3]) / 255
                if a > 0.2 {
                    let r = Float(data[i]) / 255 / a, gg = Float(data[i + 1]) / 255 / a, b = Float(data[i + 2]) / 255 / a
                    let luma = 0.3 * r + 0.59 * gg + 0.11 * b
                    if a < 0.98 || luma > 0.07 {
                        out.append(PtPix(x: (Float(xx) + 0.5) / Float(cs) - 0.5, y: 0.5 - (Float(yy) + 0.5) / Float(cs), r: min(1, r), g: min(1, gg), b: min(1, b)))
                    }
                }
                xx += step
            }
            yy += step
        }
        lock.lock(); pts[key] = out; lock.unlock()
        return out
    }
}

// MARK: - Sprite sets

struct PtSpriteSet { let key: String; let atlas: CGImage; let cells: Int; let grid: Int; var cellImages: [CGImage]
    /// 512x512 premultiplied RGBA bytes (row 0 = top) for GPU upload.
    func rgba() -> [UInt8]? {
        let w = 512
        var data = [UInt8](repeating: 0, count: w * w * 4)
        let ok: Bool = data.withUnsafeMutableBytes { raw in
            guard let c = CGContext(data: raw.baseAddress, width: w, height: w, bitsPerComponent: 8, bytesPerRow: w * 4,
                                    space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            c.draw(atlas, in: CGRect(x: 0, y: 0, width: w, height: w)); return true
        }
        return ok ? data : nil
    }
}

enum PtSprites {
    static let names = ["Dot", "Square", "Star", "Glyph", "Petal", "Bokeh", "Custom", "Pink Petal", "Cloud", "Leaf", "Maple Leaf"]
    private static var cache: [String: PtSpriteSet] = [:]
    private static let lock = NSLock()

    private static func render(_ draw: (CGContext) -> Void) -> CGImage? {
        let f = UIGraphicsImageRendererFormat(); f.scale = 1; f.opaque = false
        return UIGraphicsImageRenderer(size: CGSize(width: 512, height: 512), format: f).image { draw($0.cgContext) }.cgImage
    }
    private static func crop(_ a: CGImage, _ cells: Int, _ grid: Int) -> [CGImage] {
        let cs = 512 / grid
        return (0..<cells).compactMap { a.cropping(to: CGRect(x: ($0 % grid) * cs, y: ($0 / grid) * cs, width: cs, height: cs)) }
    }

    static func set(kind: Int, customId: Int) -> PtSpriteSet? {
        if kind <= 0 { return nil }
        let key = kind == 6 ? "c\(customId)" : "k\(kind)"
        lock.lock(); if let s = cache[key] { lock.unlock(); return s }; lock.unlock()
        var atlas: CGImage? = nil, cells = 1
        switch kind {
        case 1:
            atlas = render { c in
                c.setFillColor(UIColor.white.cgColor)
                c.addPath(CGPath(roundedRect: CGRect(x: 96, y: 96, width: 320, height: 320), cornerWidth: 30, cornerHeight: 30, transform: nil)); c.fillPath()
            }
        case 2:
            atlas = render { c in
                let cs = CGColorSpaceCreateDeviceRGB()
                let g = CGGradient(colorsSpace: cs, colors: [UIColor.white.cgColor, UIColor(white: 1, alpha: 0).cgColor] as CFArray, locations: [0, 1])!
                c.drawRadialGradient(g, startCenter: CGPoint(x: 256, y: 256), startRadius: 0, endCenter: CGPoint(x: 256, y: 256), endRadius: 70, options: [])
                c.setFillColor(UIColor.white.cgColor)
                for (w, h) in [(480.0, 26.0), (26.0, 480.0)] {
                    let p = UIBezierPath(); p.move(to: CGPoint(x: 256 - w / 2, y: 256)); p.addQuadCurve(to: CGPoint(x: 256, y: 256 - h / 2), controlPoint: CGPoint(x: 256 - 14, y: 256 - 14))
                    p.addQuadCurve(to: CGPoint(x: 256 + w / 2, y: 256), controlPoint: CGPoint(x: 256 + 14, y: 256 - 14))
                    p.addQuadCurve(to: CGPoint(x: 256, y: 256 + h / 2), controlPoint: CGPoint(x: 256 + 14, y: 256 + 14))
                    p.addQuadCurve(to: CGPoint(x: 256 - w / 2, y: 256), controlPoint: CGPoint(x: 256 - 14, y: 256 + 14)); p.close()
                    c.addPath(p.cgPath); c.fillPath()
                }
            }
        case 3:
            cells = 16
            let chars = ["ｱ", "ｲ", "ｳ", "ｴ", "ｵ", "ｶ", "ｷ", "ｸ", "ｹ", "ｺ", "ｻ", "ｼ", "ｽ", "0", "1", "7"]
            atlas = render { c in
                UIGraphicsPushContext(c)
                let ps = NSMutableParagraphStyle(); ps.alignment = .center
                let at: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 92, weight: .bold), .foregroundColor: UIColor.white, .paragraphStyle: ps]
                for (i, ch) in chars.enumerated() { (ch as NSString).draw(in: CGRect(x: (i % 4) * 128, y: (i / 4) * 128 + 12, width: 128, height: 110), withAttributes: at) }
                UIGraphicsPopContext()
            }
        case 4:
            cells = 2
            let ims = ["pt_petal1", "pt_petal2"].compactMap { n in Bundle.main.url(forResource: n, withExtension: "png").flatMap { UIImage(contentsOfFile: $0.path)?.cgImage } }
            if ims.count == 2 {
                atlas = render { c in
                    for (i, im) in ims.enumerated() {
                        let r = CGRect(x: CGFloat(i) * 256 + 8, y: 8, width: 240, height: 240)
                        c.saveGState(); c.translateBy(x: 0, y: r.minY * 2 + r.height); c.scaleBy(x: 1, y: -1); c.draw(im, in: r); c.restoreGState()
                    }
                }
            }
        case 7:
            cells = 2
            let ims = ["pt_petal3", "pt_petal4"].compactMap { n in Bundle.main.url(forResource: n, withExtension: "png").flatMap { UIImage(contentsOfFile: $0.path)?.cgImage } }
            if ims.count == 2 {
                atlas = render { c in
                    for (i, im) in ims.enumerated() {
                        let r = CGRect(x: CGFloat(i) * 256 + 8, y: 8, width: 240, height: 240)
                        c.saveGState(); c.translateBy(x: 0, y: r.minY * 2 + r.height); c.scaleBy(x: 1, y: -1); c.draw(im, in: r); c.restoreGState()
                    }
                }
            }
        case 5:
            atlas = render { c in
                let cs = CGColorSpaceCreateDeviceRGB()
                let g = CGGradient(colorsSpace: cs, colors: [UIColor(white: 1, alpha: 0.35).cgColor, UIColor(white: 1, alpha: 0.5).cgColor, UIColor(white: 1, alpha: 0.95).cgColor, UIColor(white: 1, alpha: 0).cgColor] as CFArray, locations: [0, 0.7, 0.9, 1])!
                c.drawRadialGradient(g, startCenter: CGPoint(x: 256, y: 256), startRadius: 0, endCenter: CGPoint(x: 256, y: 256), endRadius: 250, options: [])
            }
        case 6:
            if let (im, n) = PtImages.load(customId) {
                atlas = im; cells = n <= 1 ? 1 : 16
            }
        case 10:  // photographic maple leaf (bundled, with alpha); pairs with pt_leaf_bump.png for the bump map
            if let u = Bundle.main.url(forResource: "pt_leaf", withExtension: "png") { atlas = UIImage(contentsOfFile: u.path)?.cgImage }
        case 8:   // volumetric cloud puffs: shaded underside + lit top, 4 variants
            cells = 4
            atlas = render { c in
                let cs = CGColorSpaceCreateDeviceRGB()
                func blob(_ x: CGFloat, _ y: CGFloat, _ r: CGFloat, _ w: CGFloat, _ a: CGFloat) {
                    let g = CGGradient(colorsSpace: cs, colors: [UIColor(white: w, alpha: a).cgColor, UIColor(white: w, alpha: 0).cgColor] as CFArray, locations: [0, 1])!
                    c.drawRadialGradient(g, startCenter: CGPoint(x: x, y: y), startRadius: 0, endCenter: CGPoint(x: x, y: y), endRadius: r, options: [])
                }
                var s: UInt32 = 12345
                func rnd() -> CGFloat { s = s &* 1664525 &+ 1013904223; return CGFloat((s >> 8) & 0xFFFF) / 65535 }
                for cell in 0..<4 {
                    let ox = CGFloat(cell % 2) * 256 + 128, oy = CGFloat(cell / 2) * 256 + 128
                    var bl: [(CGFloat, CGFloat, CGFloat)] = []
                    for _ in 0..<9 { let a = rnd() * 6.2832, d = rnd() * 55; bl.append((ox + cos(a) * d, oy + sin(a) * d * 0.7, 38 + rnd() * 34)) }
                    for b in bl { blob(b.0 + 5, b.1 + 9, b.2, 0.62, 0.55) }
                    for b in bl { blob(b.0 - 3, b.1 - 6, b.2 * 0.85, 1.0, 0.5) }
                }
            }
        case 9:   // two-tone satin leaf: white / copper
            cells = 2
            atlas = render { c in
                let cols: [(UIColor, UIColor)] = [(UIColor(white: 1, alpha: 1), UIColor(white: 0.74, alpha: 1)),
                                                  (UIColor(red: 1, green: 0.74, blue: 0.6, alpha: 1), UIColor(red: 0.68, green: 0.33, blue: 0.2, alpha: 1))]
                for i in 0..<2 {
                    c.saveGState(); c.translateBy(x: CGFloat(i) * 256 + 128, y: 128); c.rotate(by: -0.6)
                    let p = UIBezierPath(); p.move(to: CGPoint(x: -105, y: 0))
                    p.addQuadCurve(to: CGPoint(x: 105, y: 0), controlPoint: CGPoint(x: 0, y: -78))
                    p.addQuadCurve(to: CGPoint(x: -105, y: 0), controlPoint: CGPoint(x: 0, y: 44)); p.close()
                    c.addPath(p.cgPath); c.clip()
                    let g = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: [cols[i].0.cgColor, cols[i].1.cgColor] as CFArray, locations: [0, 1])!
                    c.drawLinearGradient(g, start: CGPoint(x: 0, y: -60), end: CGPoint(x: 0, y: 40), options: [])
                    c.restoreGState()
                }
            }
        default: break
        }
        guard let a = atlas else { return nil }
        let grid = kind == 6 ? PtImages.grid(cells) : (cells <= 1 ? 1 : (cells <= 4 ? 2 : 4))
        let s = PtSpriteSet(key: key, atlas: a, cells: cells, grid: grid, cellImages: crop(a, cells, grid))
        lock.lock(); cache[key] = s; lock.unlock()
        return s
    }
    static func set(_ g: (String) -> Float) -> PtSpriteSet? { set(kind: Int(g("ptSprite").rounded()), customId: Int(g("ptSpriteId").rounded())) }
}

// MARK: - Presets (.saikiparticle)

struct PtPreset {
    var id: String, name: String, cat: String
    var params: [String: Float]
    var thumbT: Float = 1.6
    var custom = false
    var url: URL? = nil
}

enum PtPresetStore {
    static let ext = "saikiparticle"
    static var dir: URL {
        let d = (FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first ?? FileManager.default.temporaryDirectory).appendingPathComponent("ParticlePresets")
        try? FileManager.default.createDirectory(at: d, withIntermediateDirectories: true)
        return d
    }

    /// File contents: plain JSON, with any imported sprite / emitter image embedded so the file is self-contained.
    static func encode(name: String, params: [String: Float]) -> Data? {
        var o: [String: Any] = ["format": "saikiparticle", "version": 1, "name": name, "params": params.mapValues { Double($0) }]
        if let id = params["ptSpriteId"].map({ Int($0) }), (params["ptSprite"] ?? 0) == 6, let (d, c) = PtImages.data(id) { o["sprite"] = d.base64EncodedString(); o["spriteCells"] = c }
        if let id = params["ptEmImgId"].map({ Int($0) }), id > 0, let (d, c) = PtImages.data(id) { o["emImage"] = d.base64EncodedString(); o["emCells"] = c }
        if let id = params["ptBumpId"].map({ Int($0) }), id > 0, let (d, c) = PtImages.data(id) { o["bump"] = d.base64EncodedString(); o["bumpCells"] = c }
        return try? JSONSerialization.data(withJSONObject: o, options: [.prettyPrinted, .sortedKeys])
    }
    static func decode(_ data: Data) -> PtPreset? {
        guard let o = try? JSONSerialization.jsonObject(with: data) as? [String: Any], (o["format"] as? String) == "saikiparticle",
              let raw = o["params"] as? [String: Any] else { return nil }
        var p: [String: Float] = [:]
        for (k, v) in raw { if let n = v as? NSNumber { p[k] = n.floatValue } }
        if let b = o["sprite"] as? String, let d = Data(base64Encoded: b), let id = PtImages.add(data: d, cells: (o["spriteCells"] as? Int) ?? 1) { p["ptSpriteId"] = Float(id) }
        if let b = o["emImage"] as? String, let d = Data(base64Encoded: b), let id = PtImages.add(data: d, cells: (o["emCells"] as? Int) ?? 1) { p["ptEmImgId"] = Float(id) }
        if let b = o["bump"] as? String, let d = Data(base64Encoded: b), let id = PtImages.add(data: d, cells: (o["bumpCells"] as? Int) ?? 1) { p["ptBumpId"] = Float(id) }
        let name = (o["name"] as? String) ?? "Imported"
        return PtPreset(id: "u" + UUID().uuidString, name: name, cat: "Mine", params: p, thumbT: 1.6, custom: true)
    }
    static func list() -> [PtPreset] {
        let fs = (try? FileManager.default.contentsOfDirectory(at: dir, includingPropertiesForKeys: [.contentModificationDateKey])) ?? []
        let items: [(Date, PtPreset)] = fs.filter { $0.pathExtension == ext }.compactMap { u -> (Date, PtPreset)? in
            guard let d = try? Data(contentsOf: u), var p = decodeStored(d) else { return nil }
            p.id = "f" + u.lastPathComponent; p.url = u
            return ((try? u.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? Date.distantPast, p)
        }
        return items.sorted { $0.0 > $1.0 }.map { $0.1 }
    }
    /// Stored files keep their media ids as-is (embedded media only matters when a file arrives from outside).
    private static func decodeStored(_ data: Data) -> PtPreset? {
        guard let o = try? JSONSerialization.jsonObject(with: data) as? [String: Any], (o["format"] as? String) == "saikiparticle",
              let raw = o["params"] as? [String: Any] else { return nil }
        var p: [String: Float] = [:]
        for (k, v) in raw { if let n = v as? NSNumber { p[k] = n.floatValue } }
        return PtPreset(id: "", name: (o["name"] as? String) ?? "Preset", cat: "Mine", params: p, thumbT: 1.6, custom: true)
    }
    @discardableResult static func save(name: String, params: [String: Float]) -> PtPreset? {
        let safe = name.components(separatedBy: CharacterSet(charactersIn: "/\\:?*\"<>|")).joined().trimmingCharacters(in: .whitespaces)
        let nm = safe.isEmpty ? "Preset" : safe
        var u = dir.appendingPathComponent(nm + "." + ext), n = 2
        while FileManager.default.fileExists(atPath: u.path) { u = dir.appendingPathComponent("\(nm) \(n)." + ext); n += 1 }
        guard let d = encode(name: nm, params: params) else { return nil }
        do { try d.write(to: u) } catch { return nil }
        return PtPreset(id: "f" + u.lastPathComponent, name: nm, cat: "Mine", params: params, thumbT: 1.6, custom: true, url: u)
    }
    /// Imports a file from outside: media is unpacked, then it is saved into the library.
    static func importFile(_ url: URL) -> PtPreset? {
        guard let d = try? Data(contentsOf: url), let p = decode(d) else { return nil }
        return save(name: p.name, params: p.params)
    }
    static func delete(_ p: PtPreset) { if let u = p.url { try? FileManager.default.removeItem(at: u) } }
    /// A temporary .saikiparticle file ready to share.
    static func exportURL(name: String, params: [String: Float]) -> URL? {
        guard let d = encode(name: name, params: params) else { return nil }
        let u = FileManager.default.temporaryDirectory.appendingPathComponent(name + "." + ext)
        do { try d.write(to: u) } catch { return nil }
        return u
    }
}

// MARK: - Built-in presets

enum PtBuiltins {
    static let all: [PtPreset] = {
        var out: [PtPreset] = []
        func add(_ name: String, _ cat: String, _ t: Float, _ d: [String: Float], grad: [UInt32]? = nil, a: UInt32? = nil, b: UInt32? = nil, groups: [[String: Float]] = []) {
            var p = d
            for g in groups { p.merge(g) { $1 } }
            if !groups.isEmpty { p["ptGroups"] = Float(groups.count) }
            if let g = grad { p.merge(PtGradient.params(PtGradient.evenly(g))) { $1 } }
            if let a = a { p.merge(PtParams.color("ptColA", a)) { $1 } }
            if let b = b { p.merge(PtParams.color("ptColB", b)) { $1 } }
            out.append(PtPreset(id: "b" + name, name: name, cat: cat, params: p, thumbT: t))
        }
        /// One extra particle group (n = 1…3): every key is stored under the group prefix.
        func G(_ n: Int, _ d: [String: Float], grad: [UInt32]? = nil) -> [String: Float] {
            var q = d
            if let g = grad { q.merge(PtGradient.params(PtGradient.evenly(g))) { $1 } }
            var o: [String: Float] = [:]
            for (k, v) in q { o[PtGroup.pre(n) + k] = v }
            return o
        }
        let pinkG: [UInt32] = [0xFFFFFFFF, 0xFFFFC2E1, 0xFFFF7AB8, 0x00D03A86]
        // Signature looks
        add("Realistic Firework", "Signature", 1.2, [
            "ptEmType": 2, "ptBehavior": 1, "ptSizeX": 0.03, "ptSizeY": 0.03, "ptSizeZ": 0.03, "ptPosY": 0.25, "ptRate": 190, "ptLife": 2.4, "ptLifeRand": 0.25,
            "ptVel": 1.5, "ptVelRand": 0.45, "ptAir": 0.55, "ptGravity": 0.55, "ptSize": 0.008, "ptSoft": 0.6, "ptSizeEnd": 0.25, "ptTrail": 5, "ptTrailLen": 0.35,
            "ptTwinkle": 0.7, "ptTwinkleRate": 7, "ptFadeIn": 0.02, "ptFadeOut": 0.5],
            grad: [0xFFFFFFFF, 0xFFFFD36B, 0xFFFF6A1F, 0x00C81E00])
        add("Dissolve", "Signature", 1.3, [
            "ptEmType": 11, "ptBehavior": 2, "ptSizeX": 0.7, "ptSizeY": 0.9, "ptSizeZ": 0.2, "ptRate": 1400, "ptLife": 2.5, "ptVel": 0.12, "ptSpread": 0.5,
            "ptDissStart": 0.3, "ptDissDur": 2, "ptDissSweep": 0.85, "ptScatter": 0.8, "ptWindY": 0.35, "ptWindX": 0.45, "ptCurl": 0.8, "ptSize": 0.007, "ptSoft": 0.2,
            "ptFadeIn": 0.05, "ptFadeOut": 0.45],
            grad: [0xFFFFFFFF, 0xFFFFE9B0, 0xFFFFB347, 0x00FF7A00])
        add("Digital Rain", "Signature", 2.4, [
            "ptEmType": 1, "ptSizeX": 0.9, "ptSizeY": 0, "ptSizeZ": 0.3, "ptPosY": 1.3, "ptMotion": 2, "ptDirX": 0, "ptDirY": -1, "ptDirZ": 0, "ptVel": 0.9, "ptVelRand": 0.3,
            "ptSpread": 0, "ptLife": 3.2, "ptLifeRand": 0, "ptRate": 155, "ptQuant": 0.07, "ptTrail": 7, "ptTrailLen": 0.45, "ptSprite": 3, "ptSpriteTint": 1,
            "ptSize": 0.016, "ptSoft": 0, "ptSizeRand": 0.1, "ptFadeIn": 0.05, "ptFadeOut": 0.15],
            grad: [0xFF00561F, 0xFF00E050, 0xFFB8FFC8, 0xFFFFFFFF])
        add("Rose Petals", "Signature", 2.5, [
            "ptEmType": 1, "ptSizeX": 1, "ptSizeY": 0.1, "ptSizeZ": 0.8, "ptPosY": 1.3, "ptMotion": 2, "ptDirY": -1, "ptVel": 0.2, "ptSpread": 0.3, "ptGravity": 0.25, "ptAir": 0.5,
            "ptWindX": 0.15, "ptFlutter": 1.2, "ptFlutterFreq": 2.2, "ptSpin": 1.6, "ptSpinRand": 1, "ptCurl": 0.5, "ptCurlScale": 0.8, "ptLife": 6, "ptRate": 12, "ptSize": 0.05,
            "ptSoft": 0, "ptSizeRand": 0.5, "ptDof": 0.5, "ptSprite": 4, "ptSpriteTint": 0, "ptFadeIn": 0.1, "ptFadeOut": 0.15])
        add("Fluid Wave", "Signature", 2.0, [
            "ptEmType": 1, "ptSizeX": 1.4, "ptSizeY": 0.01, "ptSizeZ": 0.9, "ptPosY": -0.1, "ptVel": 0, "ptLife": 6, "ptLifeRand": 0, "ptRate": 600, "ptSize": 0.006, "ptSoft": 0.8,
            "ptWaveAmp": 0.25, "ptWaveFreq": 3.2, "ptWaveSpeed": 2.2, "ptCurl": 0.3, "ptDof": 0.4, "ptFadeIn": 0.2, "ptFadeOut": 0.2],
            grad: [0xFFB8F3FF, 0xFF22A6D9, 0xFF0B4F8A, 0xFF031B3D])
        add("Golden Glisten", "Signature", 3.0, [
            "ptEmType": 1, "ptSizeX": 1.2, "ptSizeY": 0.3, "ptSizeZ": 1, "ptPosY": -1.1, "ptMotion": 2, "ptDirX": 0.25, "ptDirY": 1, "ptVel": 0.35, "ptVelRand": 0.8, "ptSpread": 0.6,
            "ptAir": 0.1, "ptCurl": 0.6, "ptCurlScale": 0.7, "ptLife": 5, "ptRate": 300, "ptSize": 0.01, "ptSizeRand": 0.9, "ptSprite": 1, "ptSpin": 1.5, "ptSpinRand": 1,
            "ptTwinkle": 0.8, "ptTwinkleRate": 2.5, "ptDof": 0.9, "ptSoft": 0.3, "ptFadeIn": 0.1, "ptFadeOut": 0.4],
            grad: [0xFFFFF8E0, 0xFFF2D49A, 0xFFC9A063, 0x00706040])
        add("Petal Vortex", "Signature", 2.8, [
            "ptEmType": 5, "ptSizeX": 0.9, "ptSizeY": 0.1, "ptSizeZ": 0.9, "ptPosY": -0.8, "ptMotion": 2, "ptDirY": 1, "ptVel": 0.55, "ptSpread": 0.1, "ptSwirl": 1.6, "ptSwirlPull": 0.25,
            "ptFlutter": 0.6, "ptSpin": 2, "ptSpinRand": 1, "ptCurl": 0.3, "ptLife": 5, "ptRate": 28, "ptSize": 0.04, "ptSoft": 0, "ptSprite": 4, "ptSpriteTint": 0, "ptDof": 0.3,
            "ptFadeIn": 0.1, "ptFadeOut": 0.2])
        // Leaf Vortex: the reference look (white / copper leaves in a twisting column, falling light streaks, glints)
        add("Leaf Vortex", "Signature", 3.0, [
            "ptEmType": 10, "ptSizeX": 0.16, "ptSizeY": 0.75, "ptSizeZ": 0.16, "ptPosY": -0.05, "ptMotion": 2, "ptDirY": 1, "ptVel": 0.05, "ptVelRand": 0.6, "ptSpread": 0.4,
            "ptSwirl": 1.4, "ptSwirlPull": 0.15, "ptCurl": 0.55, "ptCurlScale": 0.9, "ptCurlSpeed": 0.4, "ptTurb": 0.2, "ptFlutter": 1.1, "ptFlutterFreq": 2.6,
            "ptSpin": 2.2, "ptSpinRand": 1, "ptLife": 4, "ptLifeRand": 0.3, "ptRate": 85, "ptSize": 0.036, "ptSizeRand": 0.6, "ptSoft": 0, "ptDof": 0.25,
            "ptSprite": 9, "ptSpriteTint": 0, "ptFadeIn": 0.12, "ptFadeOut": 0.15, "ptMBlur": 0.8, "ptMBSamples": 5],
            groups: [
                G(1, ["ptEmType": 1, "ptSizeX": 0.5, "ptSizeY": 0, "ptSizeZ": 0.25, "ptPosY": 1.25, "ptMotion": 2, "ptDirY": -1, "ptVel": 0.7, "ptVelRand": 0.4, "ptSpread": 0,
                      "ptLife": 2.6, "ptRate": 95, "ptTrail": 10, "ptTrailLen": 0.9, "ptSize": 0.0028, "ptSoft": 0.25, "ptOpacity": 0.45, "ptFadeIn": 0.15, "ptFadeOut": 0.4],
                  grad: [0xFFFFFFFF, 0xFFE8E8F0]),
                G(2, ["ptEmType": 10, "ptSizeX": 0.16, "ptSizeY": 0.75, "ptSizeZ": 0.16, "ptPosY": -0.05, "ptVel": 0, "ptLife": 1.1, "ptRate": 7, "ptSize": 0.11, "ptSizeRand": 0.7,
                      "ptSprite": 2, "ptSpriteTint": 1, "ptTwinkle": 0.6, "ptTwinkleRate": 4, "ptSoft": 0.3, "ptSwirl": 1.4, "ptSpin": 0.5, "ptFadeIn": 0.3, "ptFadeOut": 0.4],
                  grad: [0xFFFFFFFF, 0xFFFFE2C4, 0x00FFB070])])
        // Volumetric / 3D model / motion blur
        add("Cumulus Clouds", "Volumetric", 5.0, [
            "ptEmType": 2, "ptSizeX": 0.55, "ptSizeY": 0.28, "ptSizeZ": 0.3, "ptPosY": 0.2, "ptVel": 0.02, "ptWindX": 0.05, "ptCurl": 0.15, "ptCurlScale": 0.5,
            "ptLife": 10, "ptRate": 14, "ptSize": 0.22, "ptSizeRand": 0.5, "ptSoft": 0.4, "ptOpacity": 0.55, "ptSprite": 8, "ptSpriteTint": 1, "ptSpin": 0.05, "ptSpinRand": 1,
            "ptFadeIn": 0.25, "ptFadeOut": 0.25, "ptVolume": 0.9, "ptVolLight": 50], a: 0xFFFFFFFF, b: 0xFFDCE8FF)
        add("Storm Clouds", "Volumetric", 5.0, [
            "ptEmType": 2, "ptSizeX": 0.9, "ptSizeY": 0.18, "ptSizeZ": 0.4, "ptPosY": 0.55, "ptVel": 0.02, "ptWindX": 0.08, "ptCurl": 0.25, "ptCurlScale": 0.6,
            "ptLife": 12, "ptRate": 18, "ptSize": 0.3, "ptSizeRand": 0.5, "ptSoft": 0.4, "ptOpacity": 0.6, "ptSprite": 8, "ptSpriteTint": 1, "ptSpinRand": 1,
            "ptFadeIn": 0.25, "ptFadeOut": 0.25, "ptVolume": 1, "ptVolLight": -60], a: 0xFF8A93A6, b: 0xFF2E3446,
            groups: [G(1, ["ptEmType": 1, "ptSizeX": 0.7, "ptSizeY": 0.15, "ptSizeZ": 0.2, "ptPosY": 0.55, "ptRate": 2, "ptLife": 1, "ptSize": 0.5, "ptSprite": 5, "ptSoft": 1,
                           "ptTwinkle": 1, "ptTwinkleRate": 6, "ptOpacity": 0.7, "ptVel": 0], grad: [0xFFEAF2FF, 0x00A8C4FF])])
        add("Ground Fog", "Volumetric", 6.0, [
            "ptEmType": 1, "ptSizeX": 1.4, "ptSizeY": 0.08, "ptSizeZ": 0.8, "ptPosY": -0.75, "ptWindX": 0.08, "ptCurl": 0.3, "ptCurlScale": 0.5, "ptLife": 9, "ptRate": 14,
            "ptSize": 0.3, "ptSizeEnd": 1.4, "ptSizeRand": 0.5, "ptSoft": 0.6, "ptOpacity": 0.35, "ptSprite": 8, "ptSpriteTint": 1, "ptSpinRand": 1,
            "ptFadeIn": 0.3, "ptFadeOut": 0.3, "ptVolume": 0.5, "ptVolLight": 80], a: 0xFFD7E3F0, b: 0xFF9FB4CC)
        add("Nebula", "Volumetric", 6.0, [
            "ptEmType": 2, "ptSizeX": 0.8, "ptSizeY": 0.5, "ptSizeZ": 0.5, "ptVel": 0.01, "ptCurl": 0.4, "ptCurlScale": 0.6, "ptLife": 12, "ptRate": 12, "ptSize": 0.4,
            "ptSizeRand": 0.6, "ptSoft": 1, "ptOpacity": 0.35, "ptSprite": 8, "ptSpriteTint": 1, "ptSpin": 0.03, "ptSpinRand": 1, "ptFadeIn": 0.3, "ptFadeOut": 0.3, "ptVolume": 0.6],
            grad: [0xFF7A3CFF, 0xFFFF4FA3, 0xFF2BC4FF, 0x003060FF],
            groups: [G(1, ["ptEmType": 2, "ptSizeX": 1, "ptSizeY": 0.7, "ptSizeZ": 0.7, "ptVel": 0, "ptRate": 40, "ptLife": 6, "ptSize": 0.012, "ptSoft": 0.4, "ptTwinkle": 0.9,
                           "ptTwinkleRate": 1.5, "ptFadeIn": 0.2, "ptFadeOut": 0.2], grad: [0xFFFFFFFF, 0xFFCFE0FF])])
        add("Model Aura", "3D Model", 3.0, [
            "ptEmType": 17, "ptMotion": 6, "ptVel": 0.1, "ptVelRand": 0.6, "ptRate": 500, "ptLife": 2.2, "ptSize": 0.006, "ptSoft": 0.8, "ptCurl": 0.8, "ptWindY": 0.2,
            "ptTwinkle": 0.5, "ptTwinkleRate": 3, "ptMBlur": 1, "ptMBSamples": 5, "ptFadeIn": 0.1, "ptFadeOut": 0.5],
            grad: [0xFFFFFFFF, 0xFFFFD36B, 0xFFFF6A1F, 0x00C81E00],
            groups: [G(1, ["ptEmType": 17, "ptMotion": 6, "ptVel": 0.05, "ptRate": 30, "ptLife": 3, "ptSize": 0.12, "ptOpacity": 0.18, "ptSprite": 8, "ptSpriteTint": 1, "ptSoft": 0.6,
                           "ptVolume": 0.6, "ptFadeIn": 0.3, "ptFadeOut": 0.4], grad: [0xFFB8E8FF, 0x003070FF])])
        add("Speed Streaks", "Motion Blur", 1.2, [
            "ptEmType": 1, "ptSizeX": 0.9, "ptSizeY": 0.5, "ptSizeZ": 0.6, "ptMotion": 2, "ptDirX": -1, "ptVel": 2.2, "ptVelRand": 0.5, "ptSpread": 0.02, "ptLife": 1.6, "ptRate": 140,
            "ptSize": 0.01, "ptSoft": 0.5, "ptMBlur": 3, "ptMBSamples": 10, "ptFadeIn": 0.1, "ptFadeOut": 0.3], grad: [0xFFFFFFFF, 0xFF7FD9FF, 0x002A8CFF])
        add("Falling Maple Leaf", "Nature", 3.5, [
            "ptEmType": 1, "ptSizeX": 0.9, "ptSizeY": 0.05, "ptSizeZ": 0.6, "ptPosY": 1.3, "ptMotion": 2, "ptDirY": -1, "ptVel": 0.2, "ptVelRand": 0.3, "ptSpread": 0.2,
            "ptGravity": 0.25, "ptAir": 0.5, "ptWindX": 0.12, "ptFlutter": 1.4, "ptFlutterFreq": 1.6, "ptCurl": 0.35, "ptCurlScale": 0.8, "ptSpin": 1.1, "ptSpinRand": 1,
            "ptLife": 7, "ptLifeRand": 0.2, "ptRate": 4, "ptSize": 0.09, "ptSizeRand": 0.35, "ptSoft": 0, "ptDof": 0.3, "ptSprite": 10, "ptSpriteTint": 0,
            "ptBump": 1.3, "ptTumble": 0.8, "ptVolLight": 40, "ptFadeIn": 0.05, "ptFadeOut": 0.12, "ptMBlur": 0.4, "ptMBSamples": 4])
        // More looks
        add("Snow", "Nature", 3.0, ["ptEmType": 1, "ptSizeX": 1.2, "ptSizeY": 0.05, "ptSizeZ": 0.8, "ptPosY": 1.4, "ptMotion": 2, "ptDirY": -1, "ptVel": 0.25, "ptSpread": 0.2, "ptRate": 80,
                                    "ptLife": 8, "ptFlutter": 0.5, "ptFlutterFreq": 1.4, "ptSoft": 0.8, "ptSize": 0.014, "ptDof": 0.6, "ptFadeIn": 0.1, "ptFadeOut": 0.15],
            grad: [0xFFFFFFFF, 0xFFE6F2FF])
        add("Fireflies", "Nature", 3.0, ["ptEmType": 1, "ptSizeX": 1.2, "ptSizeY": 0.7, "ptSizeZ": 0.8, "ptVel": 0.05, "ptRate": 18, "ptLife": 6, "ptCurl": 1.2, "ptCurlScale": 0.6,
                                         "ptTwinkle": 0.9, "ptTwinkleRate": 0.8, "ptSize": 0.014, "ptSoft": 1, "ptDof": 0.5, "ptFadeIn": 0.2, "ptFadeOut": 0.3],
            grad: [0xFFF4FF8A, 0xFFB8F23A, 0x0070B000])
        add("Embers", "Fire", 2.2, ["ptEmType": 4, "ptSizeX": 0.6, "ptSizeZ": 0.4, "ptPosY": -1.1, "ptMotion": 2, "ptDirY": 1, "ptVel": 0.4, "ptVelRand": 0.7, "ptSpread": 0.5, "ptWindY": 0.3,
                                    "ptTurb": 1, "ptRate": 90, "ptLife": 4, "ptSize": 0.008, "ptSoft": 0.5, "ptTrail": 2, "ptTrailLen": 0.15, "ptSizeEnd": 0.2, "ptFadeIn": 0.05, "ptFadeOut": 0.5],
            grad: PtGradient.presets[1].1)
        add("Sparks Fountain", "Fire", 1.4, ["ptEmType": 0, "ptMotion": 2, "ptDirY": 1, "ptVel": 1.6, "ptVelRand": 0.4, "ptSpread": 0.25, "ptGravity": 1.4, "ptAir": 0.1, "ptRate": 120,
                                              "ptLife": 2, "ptPosY": -1, "ptSize": 0.008, "ptSoft": 0.3, "ptTrail": 3, "ptTrailLen": 0.12, "ptFloorOn": 1, "ptFloorY": -1.05, "ptBounce": 0.4, "ptFadeIn": 0.02, "ptFadeOut": 0.3],
            grad: PtGradient.presets[3].1)
        add("Confetti", "Party", 0.9, ["ptEmType": 0, "ptBehavior": 1, "ptMotion": 0, "ptVel": 1.6, "ptVelRand": 0.6, "ptAir": 0.5, "ptGravity": 1.2, "ptRate": 100, "ptLife": 3, "ptPosY": -0.2,
                                       "ptSpin": 4, "ptSpinRand": 1, "ptSprite": 1, "ptSize": 0.014, "ptSizeRand": 0.6, "ptGrBy": 1, "ptFadeIn": 0.02, "ptFadeOut": 0.2],
            grad: PtGradient.presets[19].1)
        add("Magic Dust", "Magic", 2.4, ["ptEmType": 2, "ptSizeX": 0.5, "ptSizeY": 0.5, "ptSizeZ": 0.4, "ptVel": 0.1, "ptRate": 80, "ptLife": 4, "ptCurl": 1, "ptSprite": 2, "ptSize": 0.02,
                                         "ptTwinkle": 0.8, "ptTwinkleRate": 3, "ptSpin": 1, "ptSpinRand": 1, "ptFadeIn": 0.2, "ptFadeOut": 0.3],
            grad: PtGradient.presets[9].1)
        add("Starfield", "Space", 2.0, ["ptEmType": 1, "ptSizeX": 2, "ptSizeY": 1.4, "ptSizeZ": 4, "ptMotion": 2, "ptDirX": 0, "ptDirY": 0, "ptDirZ": 1, "ptVel": 1.2, "ptSpread": 0, "ptRate": 200,
                                        "ptLife": 6, "ptSize": 0.006, "ptSoft": 0.2, "ptFadeIn": 0.1, "ptFadeOut": 0.1], grad: [0xFFFFFFFF, 0xFFBFD4FF])
        add("Galaxy Spiral", "Space", 3.0, ["ptEmType": 4, "ptSizeX": 1.1, "ptSizeZ": 1.1, "ptVel": 0, "ptSwirl": 0.8, "ptRate": 120, "ptLife": 8, "ptSize": 0.006, "ptSoft": 0.5,
                                            "ptDof": 0.3, "ptFadeIn": 0.2, "ptFadeOut": 0.3], grad: PtGradient.presets[13].1)
        add("Bubbles", "Nature", 2.5, ["ptEmType": 1, "ptSizeX": 1, "ptSizeY": 0.05, "ptSizeZ": 0.6, "ptPosY": -1.3, "ptMotion": 2, "ptDirY": 1, "ptVel": 0.35, "ptSpread": 0.2, "ptRate": 14,
                                       "ptLife": 6, "ptWaveFreq": 2, "ptFlutter": 0.5, "ptSprite": 5, "ptSize": 0.045, "ptSizeRand": 0.7, "ptOpacity": 0.6, "ptFadeIn": 0.1, "ptFadeOut": 0.2],
            grad: [0xFFFFFFFF, 0xFFA8E6FF])
        add("Plasma Curl", "Magic", 2.0, ["ptEmType": 2, "ptSizeX": 0.3, "ptSizeY": 0.3, "ptSizeZ": 0.3, "ptVel": 0.2, "ptRate": 70, "ptLife": 3, "ptCurl": 2.2, "ptCurlScale": 1.2,
                                          "ptTrail": 4, "ptTrailLen": 0.3, "ptSize": 0.01, "ptSoft": 0.7, "ptFadeIn": 0.1, "ptFadeOut": 0.3], grad: PtGradient.presets[12].1)
        add("Smoke Wisps", "Fire", 2.5, ["ptEmType": 0, "ptPosY": -0.8, "ptMotion": 2, "ptDirY": 1, "ptVel": 0.3, "ptSpread": 0.3, "ptRate": 18, "ptLife": 4, "ptCurl": 0.8, "ptSoft": 1,
                                         "ptSize": 0.05, "ptSizeStart": 0.5, "ptSizeEnd": 3, "ptOpacity": 0.3, "ptFadeIn": 0.2, "ptFadeOut": 0.5], grad: PtGradient.presets[24].1)
        add("Energy Orb", "Magic", 2.0, ["ptEmType": 12, "ptSizeX": 0.5, "ptSizeY": 0.5, "ptSizeZ": 0.5, "ptVel": 0, "ptSwirl": 2.5, "ptCurl": 0.8, "ptRate": 90, "ptLife": 3, "ptTrail": 3,
                                         "ptTrailLen": 0.25, "ptSize": 0.008, "ptSoft": 0.6, "ptFadeIn": 0.1, "ptFadeOut": 0.3], grad: PtGradient.presets[12].1)
        add("Rain", "Nature", 1.5, ["ptEmType": 1, "ptSizeX": 1.3, "ptSizeY": 0.05, "ptSizeZ": 0.8, "ptPosY": 1.5, "ptMotion": 2, "ptDirX": 0.1, "ptDirY": -1, "ptVel": 2.2, "ptSpread": 0,
                                    "ptRate": 120, "ptLife": 1.4, "ptTrail": 3, "ptTrailLen": 0.06, "ptSize": 0.006, "ptSoft": 0.3, "ptOpacity": 0.7, "ptFadeIn": 0.02, "ptFadeOut": 0.1],
            grad: [0xFFE6F4FF, 0xFFA8D4FF])

        // Fireworks
        add("Golden Willow", "Fireworks", 1.6, ["ptEmType": 2, "ptBehavior": 1, "ptSizeX": 0.03, "ptSizeY": 0.03, "ptSizeZ": 0.03, "ptPosY": 0.35, "ptRate": 150, "ptLife": 3.4, "ptLifeRand": 0.2,
                                               "ptVel": 1.3, "ptVelRand": 0.4, "ptAir": 0.7, "ptGravity": 0.45, "ptTrail": 10, "ptTrailLen": 0.6, "ptSize": 0.007, "ptSoft": 0.5, "ptSizeEnd": 0.3,
                                               "ptTwinkle": 0.4, "ptTwinkleRate": 5, "ptFadeIn": 0.02, "ptFadeOut": 0.6], grad: [0xFFFFFFFF, 0xFFFFD36B, 0xFFE0952B, 0x00A05A10])
        add("Pink Peony", "Fireworks", 1.2, ["ptEmType": 12, "ptBehavior": 1, "ptSizeX": 0.03, "ptSizeY": 0.03, "ptSizeZ": 0.03, "ptPosY": 0.3, "ptRate": 220, "ptLife": 2.4, "ptVel": 1.4, "ptVelRand": 0.25,
                                            "ptAir": 0.55, "ptGravity": 0.5, "ptTrail": 4, "ptTrailLen": 0.3, "ptSize": 0.009, "ptSoft": 0.6, "ptFadeIn": 0.02, "ptFadeOut": 0.45],
            grad: [0xFFFFFFFF, 0xFFFFB3D9, 0xFFFF4FA3, 0x00B0206A])
        add("Chrysanthemum", "Fireworks", 1.3, ["ptEmType": 2, "ptBehavior": 1, "ptSizeX": 0.03, "ptSizeY": 0.03, "ptSizeZ": 0.03, "ptPosY": 0.3, "ptRate": 120, "ptLife": 2.8, "ptVel": 1.5, "ptVelRand": 0.2,
                                                "ptAir": 0.6, "ptGravity": 0.5, "ptTrail": 6, "ptTrailLen": 0.45, "ptSize": 0.008, "ptSoft": 0.5, "ptFadeIn": 0.02, "ptFadeOut": 0.5],
            grad: [0xFFFFFFFF, 0xFFFFD36B, 0xFFFF5A1F, 0x00A01800],
            groups: [G(1, ["ptEmType": 2, "ptBehavior": 1, "ptSizeX": 0.03, "ptSizeY": 0.03, "ptSizeZ": 0.03, "ptPosY": 0.3, "ptRate": 140, "ptLife": 2, "ptVel": 0.75, "ptVelRand": 0.3,
                              "ptAir": 0.6, "ptGravity": 0.4, "ptSize": 0.007, "ptSoft": 0.6, "ptFadeIn": 0.02, "ptFadeOut": 0.5, "ptTwinkle": 0.6], grad: [0xFFFFFFFF, 0xFFA8E6FF, 0x0038BDF8])])
        add("Ring Firework", "Fireworks", 1.2, ["ptEmType": 15, "ptBehavior": 1, "ptSizeX": 0.04, "ptSizeY": 0.04, "ptSizeZ": 0.02, "ptPosY": 0.3, "ptMotion": 6, "ptRate": 140, "ptLife": 2.2, "ptLifeRand": 0,
                                               "ptVel": 1.5, "ptVelRand": 0.05, "ptAir": 0.55, "ptGravity": 0.3, "ptTrail": 5, "ptTrailLen": 0.3, "ptSize": 0.009, "ptSoft": 0.5, "ptFadeIn": 0.02, "ptFadeOut": 0.5],
            grad: [0xFFFFFFFF, 0xFF8FD8FF, 0xFF3A7BFF, 0x001A2A9A])
        add("Crackle Firework", "Fireworks", 1.8, ["ptEmType": 2, "ptBehavior": 1, "ptSizeX": 0.03, "ptSizeY": 0.03, "ptSizeZ": 0.03, "ptPosY": 0.3, "ptRate": 100, "ptLife": 3, "ptVel": 1.4, "ptVelRand": 0.3,
                                                  "ptAir": 0.6, "ptGravity": 0.5, "ptTrail": 3, "ptTrailLen": 0.3, "ptSize": 0.008, "ptFadeIn": 0.02, "ptFadeOut": 0.5],
            grad: [0xFFFFFFFF, 0xFFFFD36B, 0x00FF6A00],
            groups: [G(1, ["ptEmType": 2, "ptBehavior": 1, "ptSizeX": 0.03, "ptSizeY": 0.03, "ptSizeZ": 0.03, "ptPosY": 0.3, "ptRate": 130, "ptLife": 3, "ptVel": 1.2, "ptVelRand": 0.5, "ptAir": 0.6, "ptGravity": 0.55,
                              "ptSize": 0.005, "ptSoft": 0, "ptTwinkle": 1, "ptTwinkleRate": 14, "ptFadeIn": 0.02, "ptFadeOut": 0.4], grad: [0xFFFFFFFF, 0xFFFFFFFF, 0x0000FFFF])])
        add("Rainbow Firework", "Fireworks", 1.2, ["ptEmType": 12, "ptBehavior": 1, "ptSizeX": 0.03, "ptSizeY": 0.03, "ptSizeZ": 0.03, "ptPosY": 0.3, "ptRate": 230, "ptLife": 2.4, "ptVel": 1.4, "ptVelRand": 0.2,
                                                   "ptAir": 0.55, "ptGravity": 0.5, "ptTrail": 3, "ptTrailLen": 0.25, "ptSize": 0.009, "ptGrBy": 1, "ptFadeIn": 0.02, "ptFadeOut": 0.45], grad: PtGradient.presets[19].1)
        add("Palm Firework", "Fireworks", 1.8, ["ptEmType": 0, "ptBehavior": 1, "ptPosY": 0.2, "ptRate": 40, "ptLife": 3, "ptVel": 1.3, "ptVelRand": 0.25, "ptAir": 0.5, "ptGravity": 0.8, "ptTrail": 10, "ptTrailLen": 0.8,
                                              "ptSize": 0.016, "ptSoft": 0.5, "ptFadeIn": 0.02, "ptFadeOut": 0.5], grad: [0xFFFFFFFF, 0xFFFFC857, 0xFFE07A10, 0x00802800])
        add("Sparkler", "Fireworks", 1.0, ["ptEmType": 0, "ptPosY": -0.4, "ptMotion": 0, "ptVel": 1.2, "ptVelRand": 0.6, "ptRate": 300, "ptLife": 0.6, "ptGravity": 1, "ptTrail": 2, "ptTrailLen": 0.08, "ptSize": 0.006,
                                         "ptSoft": 0.3, "ptTwinkle": 0.8, "ptTwinkleRate": 12, "ptFadeIn": 0.02, "ptFadeOut": 0.4], grad: PtGradient.presets[3].1)
        // Pink / rose
        let petalFall: [String: Float] = ["ptEmType": 6, "ptSizeX": 0.5, "ptSizeY": 0.02, "ptSizeZ": 0.1, "ptPosY": 1.3, "ptMotion": 2, "ptDirX": 0.15, "ptDirY": -1, "ptVel": 0.5, "ptVelRand": 0.4, "ptSpread": 0.25,
                                          "ptGravity": 0.7, "ptAir": 0.3, "ptFlutter": 1.3, "ptFlutterFreq": 2.4, "ptSpin": 1.5, "ptSpinRand": 1, "ptCurl": 0.6, "ptCurlScale": 0.8, "ptLife": 5, "ptLifeRand": 0.3,
                                          "ptRate": 22, "ptSize": 0.05, "ptSizeRand": 0.6, "ptSoft": 0, "ptSprite": 7, "ptSpriteTint": 0, "ptDof": 0.4, "ptFadeIn": 0.08, "ptFadeOut": 0.15]
        let glitterFall: [String: Float] = ["ptEmType": 6, "ptSizeX": 0.5, "ptSizeY": 0.02, "ptSizeZ": 0.1, "ptPosY": 1.3, "ptMotion": 2, "ptDirX": 0.15, "ptDirY": -1, "ptVel": 0.55, "ptVelRand": 0.5, "ptSpread": 0.45,
                                            "ptGravity": 0.8, "ptAir": 0.2, "ptCurl": 0.6, "ptLife": 4, "ptRate": 220, "ptSize": 0.009, "ptSizeRand": 0.9, "ptSprite": 2, "ptSpriteTint": 1, "ptSpin": 2, "ptSpinRand": 1,
                                            "ptTwinkle": 0.9, "ptTwinkleRate": 4, "ptDof": 0.5, "ptSoft": 0.4, "ptFadeIn": 0.08, "ptFadeOut": 0.25]
        let bokehFall: [String: Float] = ["ptEmType": 6, "ptSizeX": 0.5, "ptSizeY": 0.02, "ptSizeZ": 0.2, "ptPosY": 1.3, "ptMotion": 2, "ptDirY": -1, "ptVel": 0.45, "ptSpread": 0.35, "ptGravity": 0.7, "ptLife": 5, "ptRate": 25,
                                          "ptSize": 0.03, "ptSizeRand": 0.8, "ptSprite": 5, "ptSpriteTint": 1, "ptOpacity": 0.35, "ptDof": 0.7, "ptFadeIn": 0.1, "ptFadeOut": 0.3]
        add("Pink Rose Waterfall", "Pink", 3.2, petalFall, groups: [G(1, glitterFall, grad: pinkG), G(2, bokehFall, grad: [0xFFFFE6F2, 0xFFFF9FCC, 0x00FF5FA8])])
        add("Red Rose Waterfall", "Pink", 3.2, petalFall.merging(["ptSprite": 4]) { $1 }, groups: [G(1, glitterFall, grad: [0xFFFFFFFF, 0xFFFFD27A, 0xFFFF4A5A, 0x00A0102A])])
        add("Pink Petal Rain", "Pink", 3.0, petalFall.merging(["ptEmType": 1, "ptSizeX": 1, "ptSizeZ": 0.8, "ptRate": 14, "ptDirX": 0, "ptVel": 0.2, "ptGravity": 0.3]) { $1 }, groups: [G(1, glitterFall.merging(["ptEmType": 1, "ptSizeX": 1, "ptSizeZ": 0.8, "ptRate": 90, "ptDirX": 0, "ptVel": 0.2, "ptGravity": 0.3]) { $1 }, grad: pinkG)])
        add("Pink Glisten", "Pink", 3.0, ["ptEmType": 1, "ptSizeX": 1.2, "ptSizeY": 0.3, "ptSizeZ": 1, "ptPosY": -1.1, "ptMotion": 2, "ptDirX": 0.25, "ptDirY": 1, "ptVel": 0.35, "ptVelRand": 0.8, "ptSpread": 0.6, "ptAir": 0.1,
                                          "ptCurl": 0.6, "ptCurlScale": 0.7, "ptLife": 5, "ptRate": 300, "ptSize": 0.01, "ptSizeRand": 0.9, "ptSprite": 2, "ptSpin": 1.5, "ptSpinRand": 1, "ptTwinkle": 0.8, "ptTwinkleRate": 2.5,
                                          "ptDof": 0.9, "ptSoft": 0.3, "ptFadeIn": 0.1, "ptFadeOut": 0.4], grad: pinkG)
        // Shockwaves
        let ring: [String: Float] = ["ptEmType": 15, "ptBehavior": 1, "ptSizeX": 0.05, "ptSizeY": 0.05, "ptSizeZ": 0.02, "ptMotion": 6, "ptRate": 250, "ptLife": 1.2, "ptLifeRand": 0, "ptVel": 1.6, "ptVelRand": 0.06,
                                     "ptAir": 0.6, "ptSize": 0.01, "ptSoft": 0.5, "ptTrail": 3, "ptTrailLen": 0.1, "ptFadeIn": 0.02, "ptFadeOut": 0.6]
        add("Shockwave Ring", "Shockwave", 0.7, ring, grad: [0xFFFFFFFF, 0xFF8FD8FF, 0x000070FF])
        add("Double Shockwave", "Shockwave", 0.8, ring, grad: [0xFFFFFFFF, 0xFF8FD8FF, 0x000070FF],
            groups: [G(1, ring.merging(["ptVel": 1.0, "ptSize": 0.014, "ptRate": 180, "ptLife": 1.4]) { $1 }, grad: [0xFFFFFFFF, 0xFFFFB347, 0x00FF4A00])])
        add("Shockwave Sphere", "Shockwave", 0.7, ring.merging(["ptEmType": 12, "ptSizeZ": 0.05, "ptRate": 500]) { $1 }, grad: [0xFFFFFFFF, 0xFFB8F3FF, 0x002288FF])
        add("Ground Slam", "Shockwave", 0.8, ring.merging(["ptEmType": 5, "ptSizeX": 0.05, "ptSizeZ": 0.05, "ptSizeY": 0.01, "ptPosY": -0.7, "ptVel": 1.8, "ptRate": 260]) { $1 },
            grad: [0xFFFFFFFF, 0xFFFFD9A0, 0x00FF9A30],
            groups: [G(1, ["ptEmType": 5, "ptBehavior": 1, "ptSizeX": 0.3, "ptSizeZ": 0.3, "ptSizeY": 0.01, "ptPosY": -0.7, "ptMotion": 2, "ptDirY": 1, "ptVel": 0.5, "ptSpread": 0.5, "ptGravity": 0.5,
                              "ptRate": 40, "ptLife": 1.6, "ptSize": 0.04, "ptSoft": 1, "ptSizeEnd": 2.5, "ptOpacity": 0.5, "ptFadeIn": 0.05, "ptFadeOut": 0.6], grad: PtGradient.presets[24].1)])
        add("Ripple Field", "Shockwave", 1.4, ["ptEmType": 16, "ptSizeX": 0.9, "ptSizeY": 0.9, "ptVel": 0, "ptRate": 800, "ptLife": 4, "ptLifeRand": 0, "ptSize": 0.006, "ptSoft": 0.4, "ptFadeIn": 0.3, "ptFadeOut": 0.3,
                                               "ptShockAmp": 0.25, "ptShockSpeed": 0.8, "ptShockWidth": 0.1, "ptShockPeriod": 2, "ptShockGlow": 2.5], grad: PtGradient.presets[11].1)
        add("Sonic Boom", "Shockwave", 0.6, ring.merging(["ptSizeX": 0.02, "ptSizeY": 0.02, "ptVel": 2.6, "ptAir": 0.3, "ptTrail": 8, "ptTrailLen": 0.15, "ptRate": 300, "ptLife": 1]) { $1 },
            grad: [0xFFFFFFFF, 0xFFA8E6FF, 0x0038BDF8],
            groups: [G(1, ["ptEmType": 12, "ptBehavior": 1, "ptSizeX": 0.05, "ptSizeY": 0.05, "ptSizeZ": 0.05, "ptMotion": 6, "ptVel": 1.2, "ptAir": 0.6, "ptRate": 40, "ptLife": 1.2, "ptSize": 0.05, "ptSoft": 1,
                              "ptOpacity": 0.25, "ptFadeIn": 0.05, "ptFadeOut": 0.6], grad: [0xFFFFFFFF, 0xFFA8E6FF, 0x00000000])])
        add("Pink Shockwave", "Shockwave", 0.8, ring.merging(["ptSprite": 2, "ptSpriteTint": 1, "ptSize": 0.014, "ptSpin": 3, "ptSpinRand": 1]) { $1 }, grad: pinkG,
            groups: [G(1, glitterFall.merging(["ptEmType": 12, "ptBehavior": 1, "ptSizeX": 0.05, "ptSizeY": 0.05, "ptSizeZ": 0.05, "ptPosY": 0, "ptMotion": 6, "ptDirX": 0, "ptDirY": 0, "ptVel": 1.1, "ptAir": 0.5, "ptGravity": 0.2, "ptRate": 150, "ptLife": 1.8]) { $1 }, grad: pinkG)])
        add("Fire Blast", "Shockwave", 0.9, ["ptEmType": 12, "ptBehavior": 1, "ptSizeX": 0.05, "ptSizeY": 0.05, "ptSizeZ": 0.05, "ptMotion": 6, "ptVel": 1.6, "ptVelRand": 0.4, "ptAir": 0.7, "ptRate": 120, "ptLife": 1.6, "ptTurb": 1,
                                             "ptSize": 0.03, "ptSoft": 1, "ptSizeEnd": 2, "ptOpacity": 0.7, "ptFadeIn": 0.03, "ptFadeOut": 0.6], grad: PtGradient.presets[0].1,
            groups: [G(1, ["ptEmType": 0, "ptBehavior": 1, "ptMotion": 0, "ptVel": 1.8, "ptVelRand": 0.5, "ptAir": 0.3, "ptGravity": 0.8, "ptRate": 140, "ptLife": 1.6, "ptTrail": 3, "ptTrailLen": 0.1, "ptSize": 0.007,
                              "ptSoft": 0.3, "ptFadeIn": 0.02, "ptFadeOut": 0.4], grad: PtGradient.presets[3].1)])
        add("Speed Lines", "Shockwave", 0.8, ring.merging(["ptSizeX": 0.15, "ptSizeY": 0.15, "ptVel": 2.2, "ptAir": 0.1, "ptTrail": 10, "ptTrailLen": 0.2, "ptRate": 120, "ptSize": 0.005, "ptSoft": 0]) { $1 }, grad: [0xFFFFFFFF, 0xFFFFFFFF, 0x00FFFFFF])
        add("Energy Ripples", "Shockwave", 1.5, ["ptEmType": 3, "ptGridN": 12, "ptSizeX": 0.9, "ptSizeY": 0.9, "ptSizeZ": 0.01, "ptVel": 0, "ptRate": 600, "ptLife": 3, "ptLifeRand": 0, "ptSize": 0.01, "ptSoft": 0.5,
                                                 "ptFadeIn": 0.3, "ptFadeOut": 0.3, "ptShockAmp": 0.3, "ptShockSpeed": 1, "ptShockWidth": 0.15, "ptShockPeriod": 2.5, "ptShockGlow": 3], grad: PtGradient.presets[12].1)
        // Path presets: the curve is stored in the preset (ptPath* keys), so it can be redrawn in the designer
        let wave: [SIMD3<Float>] = (0..<14).map { let t = Float($0) / 13; return SIMD3(-1.0 + 2.0 * t, 0.35 * sin(t * 6.2832 * 1.5), 0.45 * cos(t * 6.2832 * 1.2)) }
        let loop: [SIMD3<Float>] = (0..<16).map { let t = Float($0) / 16 * 6.2832; return SIMD3(0.85 * sin(t), 0.32 * sin(2 * t) + 0.1, 0.5 * cos(t)) }
        let loopP = PtPath.params(loop, closed: true)
        add("Golden Trail", "Path", 3.0, loopP.merging([
            "ptEmType": 18, "ptPathMode": 1, "ptPathSpeed": 0.22, "ptSizeX": 0.012, "ptVel": 0.04, "ptSpread": 1, "ptCurl": 0.35, "ptCurlScale": 1.2,
            "ptLife": 2.4, "ptLifeRand": 0.2, "ptRate": 420, "ptSize": 0.008, "ptSizeRand": 0.5, "ptSizeEnd": 0.3, "ptSoft": 0.7, "ptTwinkle": 0.4, "ptTwinkleRate": 5,
            "ptFadeIn": 0.01, "ptFadeOut": 0.65, "ptGlow": 1.2, "ptGlowSize": 3]) { $1 },
            grad: [0xFFFFFFFF, 0xFFFFD36B, 0xFFE0A030, 0x00A06010],
            groups: [G(1, loopP.merging([
                "ptEmType": 18, "ptPathMode": 1, "ptPathSpeed": 0.22, "ptSizeX": 0.004, "ptVel": 0, "ptLife": 0.12, "ptRate": 120, "ptSize": 0.05, "ptSprite": 2, "ptSpriteTint": 1,
                "ptSoft": 0.3, "ptFadeIn": 0.2, "ptFadeOut": 0.5, "ptGlow": 2, "ptGlowSize": 3]) { $1 }, grad: [0xFFFFFFFF, 0xFFFFE9B0])])
        add("Starlight River", "Path", 3.5, PtPath.params(wave).merging([
            "ptEmType": 18, "ptPathMode": 0, "ptPathFlow": 0.22, "ptSizeX": 0.05, "ptVel": 0, "ptCurl": 0.5, "ptCurlScale": 1, "ptLife": 4.5, "ptLifeRand": 0.25, "ptRate": 150,
            "ptSize": 0.009, "ptSizeRand": 0.7, "ptSoft": 0.6, "ptTwinkle": 0.5, "ptTwinkleRate": 2, "ptDof": 0.3, "ptFadeIn": 0.15, "ptFadeOut": 0.25,
            "ptMBlur": 0.6, "ptMBSamples": 4, "ptGlow": 1, "ptGlowSize": 3]) { $1 },
            grad: [0xFFFFFFFF, 0xFF8FE8FF, 0xFF3A8CFF, 0x002040B0])
        add("Aurora Veil", "Volumetric", 6.0, [
            "ptEmType": 1, "ptSizeX": 1.3, "ptSizeY": 0.25, "ptSizeZ": 0.3, "ptPosY": 0.5, "ptVel": 0.02, "ptWindX": 0.1, "ptWaveAmp": 0.18, "ptWaveFreq": 1.6, "ptWaveSpeed": 0.5,
            "ptCurl": 0.2, "ptCurlScale": 0.5, "ptLife": 10, "ptRate": 13, "ptSize": 0.28, "ptSizeRand": 0.5, "ptSoft": 1, "ptOpacity": 0.3, "ptSprite": 8, "ptSpriteTint": 1,
            "ptSpinRand": 1, "ptFadeIn": 0.3, "ptFadeOut": 0.3, "ptVolume": 0.3, "ptGlow": 0.5, "ptGlowSize": 2],
            grad: [0x0000FFA0, 0xFF3DFFB0, 0xFF2BD4E0, 0xFF8A5CFF, 0x005030C0])
        add("Glow Lanterns", "Glow", 4.0, [
            "ptEmType": 1, "ptSizeX": 1, "ptSizeY": 0.1, "ptSizeZ": 0.7, "ptPosY": -1.1, "ptMotion": 2, "ptDirY": 1, "ptVel": 0.18, "ptVelRand": 0.5, "ptSpread": 0.15,
            "ptWindX": 0.06, "ptCurl": 0.3, "ptCurlScale": 0.6, "ptLife": 9, "ptRate": 5, "ptSize": 0.03, "ptSizeRand": 0.4, "ptSoft": 0.5, "ptDof": 0.4,
            "ptTwinkle": 0.25, "ptTwinkleRate": 1.2, "ptFadeIn": 0.15, "ptFadeOut": 0.3, "ptGlow": 1.6, "ptGlowSize": 4],
            grad: [0xFFFFF0C0, 0xFFFFB347, 0xFFFF6A1F, 0x00C81E00])
        add("Neon Comets", "Glow", 2.0, [
            "ptEmType": 1, "ptSizeX": 0.9, "ptSizeY": 0.5, "ptSizeZ": 0.4, "ptMotion": 2, "ptDirX": 1, "ptDirY": -0.4, "ptVel": 1.2, "ptVelRand": 0.6, "ptSpread": 0.1,
            "ptCurl": 0.5, "ptCurlScale": 0.8, "ptLife": 2.2, "ptRate": 22, "ptSize": 0.012, "ptSoft": 0.7, "ptMBlur": 2, "ptMBSamples": 8,
            "ptFadeIn": 0.05, "ptFadeOut": 0.5, "ptGlow": 2, "ptGlowSize": 3],
            grad: [0xFFFFFFFF, 0xFF4FF3FF, 0xFFB14DFF, 0x00FF3DB5])
        // glow on the existing light-emitting looks
        for (n, gl, gs) in [("Realistic Firework", 0.8, 3.0), ("Fireflies", 1.4, 4.0), ("Embers", 0.9, 3.0), ("Golden Glisten", 0.6, 3.0)] as [(String, Float, Float)] {
            if let i = out.firstIndex(where: { $0.name == n }) { out[i].params["ptGlow"] = gl; out[i].params["ptGlowSize"] = gs }
        }
        return out
    }()
}
