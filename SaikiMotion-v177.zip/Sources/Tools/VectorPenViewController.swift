// VectorPenViewController.swift — full-screen vector pen. Tools: Pen (tap = add point, tap a line = insert,
// drag = move, tap first point = close), Curve (drag a point to pull out handles, drag handles, drag a line to bend it),
// Delete (tap a point), Close toggle. Done creates / updates a SHAPE layer with shape == .PATH.
import UIKit

private final class PenCanvas: UIView {
    enum Tool { case pen, curve, delete }
    private enum Drag { case none, point(Int), inH(Int), outH(Int), seg(Int, VPath, SIMD2<Float>) }

    var path = VPath() { didSet { setNeedsDisplay() } }
    var tool: Tool = .pen { didSet { setNeedsDisplay() } }
    var selected = -1
    var onBeginEdit: (() -> Void)?
    private var drag: Drag = .none
    private var moved = false, downPt = CGPoint.zero
    private let orange = UIColor(red: 1, green: 0.54, blue: 0.1, alpha: 1)

    private var box: CGRect { let s = min(bounds.width, bounds.height) - 32; return CGRect(x: (bounds.width - s) / 2, y: (bounds.height - s) / 2, width: s, height: s) }
    private func pt(_ x: Float, _ y: Float) -> CGPoint { CGPoint(x: box.minX + CGFloat(x * 0.5 + 0.5) * box.width, y: box.minY + CGFloat(y * 0.5 + 0.5) * box.height) }
    private func unit(_ p: CGPoint) -> SIMD2<Float> { SIMD2(Float((p.x - box.minX) / box.width) * 2 - 1, Float((p.y - box.minY) / box.height) * 2 - 1) }
    private func dist(_ a: CGPoint, _ b: CGPoint) -> CGFloat { hypot(a.x - b.x, a.y - b.y) }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        UIColor(white: 0.07, alpha: 1).setFill(); c.fill(bounds)
        UIColor(white: 0.12, alpha: 1).setFill(); c.fill(box)
        UIColor(white: 0.2, alpha: 1).setStroke(); c.setLineWidth(1)
        for i in 1..<4 { let f = CGFloat(i) / 4
            c.move(to: CGPoint(x: box.minX + f * box.width, y: box.minY)); c.addLine(to: CGPoint(x: box.minX + f * box.width, y: box.maxY))
            c.move(to: CGPoint(x: box.minX, y: box.minY + f * box.height)); c.addLine(to: CGPoint(x: box.maxX, y: box.minY + f * box.height)) }
        c.strokePath()
        guard !path.pts.isEmpty else { return }
        let bz = path.bezier { pt($0, $1) }
        if path.closed { orange.withAlphaComponent(0.25).setFill(); bz.fill() }
        orange.setStroke(); bz.lineWidth = 2.5; bz.stroke()
        for (i, p) in path.pts.enumerated() {
            let c0 = pt(p.x, p.y)
            if (tool == .curve || i == selected) && p.curved {
                for h in [pt(p.x + p.ix, p.y + p.iy), pt(p.x + p.ox, p.y + p.oy)] {
                    UIColor.white.withAlphaComponent(0.6).setStroke()
                    let l = UIBezierPath(); l.move(to: c0); l.addLine(to: h); l.lineWidth = 1; l.stroke()
                    UIColor.cyan.setFill(); UIBezierPath(ovalIn: CGRect(x: h.x - 5, y: h.y - 5, width: 10, height: 10)).fill()
                }
            }
            (i == selected ? UIColor.yellow : UIColor.white).setFill()
            let r: CGFloat = i == selected ? 8 : 6
            UIBezierPath(rect: CGRect(x: c0.x - r, y: c0.y - r, width: r * 2, height: r * 2)).fill()
            if i == 0 && !path.closed && path.pts.count >= 3 && tool == .pen { orange.setStroke(); let o = UIBezierPath(ovalIn: CGRect(x: c0.x - 14, y: c0.y - 14, width: 28, height: 28)); o.lineWidth = 2; o.stroke() }
        }
    }

    private func hitPoint(_ p: CGPoint) -> Int? { path.pts.indices.reversed().first { dist(pt(path.pts[$0].x, path.pts[$0].y), p) < 22 } }
    private func hitSeg(_ p: CGPoint) -> (Int, Float)? {
        var best: (Int, Float, CGFloat)? = nil
        for i in 0..<(path.closed ? path.pts.count : max(0, path.pts.count - 1)) {
            guard let s = path.segment(i, { pt($0, $1) }) else { continue }
            for k in 0...24 { let t = CGFloat(k) / 24, u = 1 - t
                let q = CGPoint(x: u*u*u*s.0.x + 3*u*u*t*s.1.x + 3*u*t*t*s.2.x + t*t*t*s.3.x, y: u*u*u*s.0.y + 3*u*u*t*s.1.y + 3*u*t*t*s.2.y + t*t*t*s.3.y)
                let d = dist(q, p); if d < 18 && d < (best?.2 ?? .infinity) { best = (i, Float(t), d) } }
        }
        return best.map { ($0.0, $0.1) }
    }

    override func touchesBegan(_ touches: Set<UITouch>, with e: UIEvent?) {
        guard let p = touches.first?.location(in: self) else { return }
        downPt = p; moved = false; drag = .none
        if selected >= 0, selected < path.pts.count {            // handles of the selected point first
            let q = path.pts[selected]
            if q.curved {
                if dist(pt(q.x + q.ix, q.y + q.iy), p) < 20 { onBeginEdit?(); drag = .inH(selected); return }
                if dist(pt(q.x + q.ox, q.y + q.oy), p) < 20 { onBeginEdit?(); drag = .outH(selected); return }
            }
        }
        if let i = hitPoint(p) {
            selected = i
            switch tool {
            case .delete: onBeginEdit?(); path.pts.remove(at: i); selected = -1; if path.pts.count < 3 { path.closed = false }
            case .pen:
                if i == 0 && path.pts.count >= 3 && !path.closed { onBeginEdit?(); path.closed = true } else { onBeginEdit?(); drag = .point(i) }
            case .curve: onBeginEdit?(); drag = .point(i)
            }
        } else if let (i, t) = hitSeg(p), tool != .delete {
            onBeginEdit?()
            if tool == .pen { path.split(i, at: t); selected = i + 1; drag = .point(i + 1) }
            else { drag = .seg(i, path, unit(p)) }
        } else if tool == .pen {
            onBeginEdit?()
            let u = unit(p); path.pts.append(VPt(x: u.x, y: u.y)); selected = path.pts.count - 1; drag = .point(selected)
        } else { selected = -1 }
        setNeedsDisplay()
    }

    override func touchesMoved(_ touches: Set<UITouch>, with e: UIEvent?) {
        guard let p = touches.first?.location(in: self) else { return }
        if dist(p, downPt) > 3 { moved = true }
        let u = unit(p)
        switch drag {
        case .none: return
        case .point(let i):
            if tool == .curve {                                    // pull symmetric handles out of the point
                let d = u - SIMD2(path.pts[i].x, path.pts[i].y)
                path.pts[i].ox = d.x; path.pts[i].oy = d.y; path.pts[i].ix = -d.x; path.pts[i].iy = -d.y
            } else { path.pts[i].x = u.x; path.pts[i].y = u.y }
        case .outH(let i):
            path.pts[i].ox = u.x - path.pts[i].x; path.pts[i].oy = u.y - path.pts[i].y
            path.pts[i].ix = -path.pts[i].ox; path.pts[i].iy = -path.pts[i].oy
        case .inH(let i):
            path.pts[i].ix = u.x - path.pts[i].x; path.pts[i].iy = u.y - path.pts[i].y
            path.pts[i].ox = -path.pts[i].ix; path.pts[i].oy = -path.pts[i].iy
        case .seg(let i, let start, let u0):                       // bend a line: both handles follow the finger
            let d = (u - u0) * (4.0 / 3.0), j = (i + 1) % start.pts.count
            path.pts[i].ox = start.pts[i].ox + d.x; path.pts[i].oy = start.pts[i].oy + d.y
            path.pts[j].ix = start.pts[j].ix + d.x; path.pts[j].iy = start.pts[j].iy + d.y
        }
        setNeedsDisplay()
    }
    override func touchesEnded(_ touches: Set<UITouch>, with e: UIEvent?) { drag = .none }
    override func touchesCancelled(_ touches: Set<UITouch>, with e: UIEvent?) { drag = .none }
}

final class VectorPenViewController: UIViewController {
    var onDone: ((VPath) -> Void)?
    private let canvas = PenCanvas()
    private var undoStack: [VPath] = []
    private var tools: [(UIButton, PenCanvas.Tool?)] = []
    private let hint = UILabel(), closeBtn = UIButton(type: .system)
    private let orange = UIColor(red: 1, green: 0.54, blue: 0.1, alpha: 1)

    init(path: VPath) { super.init(nibName: nil, bundle: nil); canvas.path = path; modalPresentationStyle = .fullScreen }
    required init?(coder: NSCoder) { fatalError() }

    private func btn(_ sym: String, _ fallback: String = "scribble", _ action: @escaping () -> Void) -> UIButton {
        let b = UIButton(type: .system)
        b.setImage(UIImage(systemName: sym) ?? UIImage(systemName: fallback), for: .normal)
        b.tintColor = .white; b.backgroundColor = UIColor(white: 0.16, alpha: 1); b.layer.cornerRadius = 12
        b.addAction(UIAction { _ in action() }, for: .touchUpInside)
        b.widthAnchor.constraint(equalToConstant: 52).isActive = true; b.heightAnchor.constraint(equalToConstant: 48).isActive = true
        return b
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        canvas.onBeginEdit = { [weak self] in guard let s = self else { return }; s.undoStack.append(s.canvas.path) }
        let cancel = btn("xmark") { [weak self] in self?.dismiss(animated: true) }
        let done = btn("checkmark") { [weak self] in
            guard let s = self else { return }
            if s.canvas.path.pts.count >= 2 { s.onDone?(s.canvas.path) }
            s.dismiss(animated: true)
        }
        done.tintColor = .black; done.backgroundColor = orange
        hint.textColor = .lightGray; hint.font = .systemFont(ofSize: 13); hint.textAlignment = .center; hint.numberOfLines = 2
        let top = UIStackView(arrangedSubviews: [cancel, hint, done]); top.alignment = .center; top.spacing = 8
        let pen = btn("plus.diamond") { }, curve = btn("point.topleft.down.curvedto.point.bottomright.up") { }, del = btn("minus.circle") { }
        for (b, t) in [(pen, PenCanvas.Tool.pen), (curve, .curve), (del, .delete)] {
            b.addAction(UIAction { [weak self] _ in self?.setTool(t) }, for: .touchUpInside); tools.append((b, t))
        }
        let close = btn("circle") { [weak self] in
            guard let s = self, s.canvas.path.pts.count >= 3 else { return }
            s.undoStack.append(s.canvas.path); s.canvas.path.closed.toggle(); s.refreshHint()
        }
        let undo = btn("arrow.uturn.backward") { [weak self] in
            guard let s = self, let p = s.undoStack.popLast() else { return }
            s.canvas.path = p; s.canvas.selected = -1
        }
        let bottom = UIStackView(arrangedSubviews: [undo, UIView(), pen, curve, del, close]); bottom.spacing = 10
        for v in [top, canvas, bottom] as [UIView] { v.translatesAutoresizingMaskIntoConstraints = false; view.addSubview(v) }
        let g = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            top.topAnchor.constraint(equalTo: g.topAnchor, constant: 8), top.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 12), top.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -12),
            bottom.bottomAnchor.constraint(equalTo: g.bottomAnchor, constant: -8), bottom.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 12), bottom.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -12),
            canvas.topAnchor.constraint(equalTo: top.bottomAnchor, constant: 8), canvas.bottomAnchor.constraint(equalTo: bottom.topAnchor, constant: -8),
            canvas.leadingAnchor.constraint(equalTo: view.leadingAnchor), canvas.trailingAnchor.constraint(equalTo: view.trailingAnchor)])
        setTool(.pen)
    }

    private func setTool(_ t: PenCanvas.Tool) {
        canvas.tool = t
        for (b, k) in tools { b.backgroundColor = k == t ? orange : UIColor(white: 0.16, alpha: 1); b.tintColor = k == t ? .black : .white }
        refreshHint()
    }
    private func refreshHint() {
        closeBtn.isSelected = canvas.path.closed
        switch canvas.tool {
        case .pen: hint.text = "Pen: tap to add points, tap a line to insert, drag to move.\(canvas.path.closed ? " (closed)" : " Tap the first point to close.")"
        case .curve: hint.text = "Curve: drag a point to pull out handles, drag a line to bend it."
        case .delete: hint.text = "Delete: tap a point to remove it."
        }
    }
}
