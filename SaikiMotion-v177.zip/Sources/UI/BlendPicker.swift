// BlendPicker.swift — grouped (collapsible ^) blend-mode picker with live sample icons.
// Icons are rendered with the real compositeFragment shader, so they always match the output.
import UIKit
import Metal

enum BlendModes {
    /// id = value stored in Layer.blend (must match compositeFragment in MetalPasses).
    static let groups: [(title: String, modes: [(name: String, id: Int)])] = [
        ("Dissolve modes", [("Normal", 0), ("Dissolve", 10)]),
        ("Darken", [("Darken", 11), ("Multiply", 3), ("Color Burn", 12), ("Linear Burn", 13), ("Darker Color", 14)]),
        ("Lighten", [("Add", 1), ("Lighten", 15), ("Screen", 2), ("Color Dodge", 16), ("Lighter Color", 17)]),
        ("Contrast", [("Overlay", 18), ("Soft Light", 19), ("Hard Light", 20), ("Vivid Light", 21),
                      ("Linear Light", 22), ("Pin Light", 23), ("Hard Mix", 24)]),
        ("Inversion", [("Difference", 25), ("Exclusion", 26), ("Subtract", 27), ("Divide", 28)]),
        ("Component", [("Hue", 31), ("Saturation", 32), ("Color", 33), ("Luminosity", 34)]),
    ]
    static func name(_ id: Int) -> String { groups.flatMap { $0.modes }.first { $0.id == id }?.name ?? "Normal" }

    private static var cache: [Int: UIImage] = [:]
    private static let S = 64

    /// Sample: blue→yellow backdrop with a pink→green soft circle blended on top.
    static func icon(_ mode: Int) -> UIImage? {
        if let c = cache[mode] { return c }
        guard let ps = MetalPasses.shared else { return nil }
        let n = S
        var bg = [UInt8](repeating: 255, count: n * n * 4), fg = [UInt8](repeating: 0, count: n * n * 4)
        for y in 0..<n { for x in 0..<n {
            let i = (y * n + x) * 4, fx = Float(x) / Float(n - 1), fy = Float(y) / Float(n - 1)
            bg[i] = UInt8(30 + 220 * fx); bg[i + 1] = UInt8(60 + 140 * fx); bg[i + 2] = UInt8(200 - 140 * fx)
            let dx = Float(x) - Float(n) / 2, dy = Float(y) - Float(n) / 2
            let a = min(1, max(0, (Float(n) * 0.38 - (dx * dx + dy * dy).squareRoot()) / 2))
            fg[i] = UInt8(a * (230 - 170 * fy)); fg[i + 1] = UInt8(a * (60 + 170 * fy)); fg[i + 2] = UInt8(a * (120 + 40 * fy)); fg[i + 3] = UInt8(a * 255)
        } }
        guard let tb = ps.makeTexture(width: n, height: n, rgba: bg), let tf = ps.makeTexture(width: n, height: n, rgba: fg) else { return nil }
        let out = MetalTarget(ps.core, n, n)
        ps.runSync { _ = ps.composite($0, scene: tb, src: tf, alpha: 1, mode: mode, to: out) }
        guard let img = out.readImage() else { return nil }
        cache[mode] = img
        return img
    }
}

private final class BlendTile: UIControl {
    init(name: String, icon: UIImage?, selected: Bool) {
        super.init(frame: .zero)
        let iv = UIImageView(image: icon); iv.contentMode = .scaleAspectFill
        iv.layer.cornerRadius = 8; iv.clipsToBounds = true; iv.backgroundColor = UIColor(white: 0.18, alpha: 1)
        iv.layer.borderWidth = selected ? 2.5 : 0; iv.layer.borderColor = UIColor(red: 1, green: 0.54, blue: 0.1, alpha: 1).cgColor
        iv.isUserInteractionEnabled = false
        let l = UILabel(); l.text = name; l.font = .systemFont(ofSize: 11, weight: selected ? .bold : .regular)
        l.textColor = selected ? UIColor(red: 1, green: 0.54, blue: 0.1, alpha: 1) : .white
        l.textAlignment = .center; l.adjustsFontSizeToFitWidth = true; l.minimumScaleFactor = 0.7
        let st = UIStackView(arrangedSubviews: [iv, l]); st.axis = .vertical; st.spacing = 4; st.isUserInteractionEnabled = false
        st.translatesAutoresizingMaskIntoConstraints = false; addSubview(st)
        iv.heightAnchor.constraint(equalTo: iv.widthAnchor).isActive = true
        NSLayoutConstraint.activate([st.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 4), st.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -4),
                                     st.topAnchor.constraint(equalTo: topAnchor, constant: 4), st.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -4)])
    }
    required init?(coder: NSCoder) { fatalError() }
}

private final class GroupHeader: UIControl {
    let chev = UIImageView()
    init(_ title: String, open: Bool, current: String?) {
        super.init(frame: .zero)
        backgroundColor = UIColor(white: 0.11, alpha: 1); layer.cornerRadius = 10
        let t = UILabel(); t.text = title; t.font = .systemFont(ofSize: 16, weight: .bold); t.textColor = .white
        let cur = UILabel(); cur.text = open ? nil : current; cur.font = .systemFont(ofSize: 13); cur.textColor = UIColor(red: 1, green: 0.54, blue: 0.1, alpha: 1)
        chev.image = UIImage(systemName: open ? "chevron.up" : "chevron.down"); chev.tintColor = .lightGray
        let st = UIStackView(arrangedSubviews: [t, UIView(), cur, chev]); st.spacing = 8; st.alignment = .center; st.isUserInteractionEnabled = false
        st.translatesAutoresizingMaskIntoConstraints = false; addSubview(st)
        NSLayoutConstraint.activate([st.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 14), st.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -14),
                                     st.topAnchor.constraint(equalTo: topAnchor), st.bottomAnchor.constraint(equalTo: bottomAnchor),
                                     heightAnchor.constraint(equalToConstant: 48)])
    }
    required init?(coder: NSCoder) { fatalError() }
}

enum BlendPicker {
    private static var open: Set<String> = []
    private static var seeded = false

    static func build(current: Int, onPick: @escaping (Int) -> Void, onToggle: @escaping () -> Void) -> UIView {
        if !seeded { seeded = true; open = [BlendModes.groups[0].title] }
        if let g = BlendModes.groups.first(where: { $0.modes.contains { $0.id == current } }) { open.insert(g.title) }
        let root = UIStackView(); root.axis = .vertical; root.spacing = 8
        for g in BlendModes.groups {
            let isOpen = open.contains(g.title)
            let h = GroupHeader(g.title, open: isOpen, current: g.modes.first { $0.id == current }?.name)
            h.addAction(UIAction { _ in
                if isOpen { open.remove(g.title) } else { open.insert(g.title) }
                onToggle()
            }, for: .touchUpInside)
            root.addArrangedSubview(h)
            guard isOpen else { continue }
            for row in stride(from: 0, to: g.modes.count, by: 4) {
                let r = UIStackView(); r.distribution = .fillEqually; r.spacing = 6
                for k in row..<(row + 4) {
                    if k < g.modes.count {
                        let m = g.modes[k]
                        let t = BlendTile(name: m.name, icon: BlendModes.icon(m.id), selected: m.id == current)
                        t.addAction(UIAction { _ in onPick(m.id) }, for: .touchUpInside)
                        r.addArrangedSubview(t)
                    } else { r.addArrangedSubview(UIView()) }
                }
                root.addArrangedSubview(r)
            }
        }
        return root
    }
}
