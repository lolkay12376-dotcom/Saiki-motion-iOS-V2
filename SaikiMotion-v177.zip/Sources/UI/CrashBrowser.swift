// CrashBrowser.swift — Settings > Crash: browse, copy and export crash logs and effect crash logs (UI).
import UIKit

final class CrashBrowserViewController: UITableViewController {
    private var dir: URL?                       // nil = root
    private var items: [(title: String, sub: String, url: URL, isDir: Bool)] = []

    init(dir: URL? = nil) { self.dir = dir; super.init(style: .insetGrouped) }
    required init?(coder: NSCoder) { fatalError() }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = argbToUIColor(C.BG)
        title = dir == nil ? "Crash" : (dir!.lastPathComponent == "EffectCrashLogs" ? "Effect crash logs" : dir!.lastPathComponent)
        if dir == nil {
            navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: .close, target: self, action: #selector(close))
            navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Export thumbnails", style: .plain, target: self, action: #selector(exportThumbs))
        } else if dir!.deletingLastPathComponent().lastPathComponent == "EffectCrashLogs" {
            let id = dir!.lastPathComponent
            let on = EffectCrashLog.isBroken(id)
            navigationItem.rightBarButtonItem = UIBarButtonItem(title: on ? "Re-enable" : "Disable", style: .plain, target: self, action: #selector(toggleBroken))
        }
        reload()
    }
    @objc private func close() { dismiss(animated: true) }
    @objc private func exportThumbs() {
        navigationItem.rightBarButtonItem?.isEnabled = false
        navigationItem.rightBarButtonItem?.title = "Rendering…"
        EffectThumbs.exportBaked { [weak self] folder, n in
            guard let self = self else { return }
            self.navigationItem.rightBarButtonItem?.isEnabled = true
            self.navigationItem.rightBarButtonItem?.title = "Export thumbnails"
            let msg = folder == nil ? "Nothing was exported." :
                "\(n) effects saved to Files > SaikiMotion > ThumbExport. Copy all files into Resources/thumbs in the project and rebuild."
            let a = UIAlertController(title: "Thumbnails", message: msg, preferredStyle: .alert)
            a.addAction(UIAlertAction(title: "OK", style: .default))
            self.present(a, animated: true)
        }
    }
    @objc private func toggleBroken() {
        let id = dir!.lastPathComponent
        EffectCrashLog.setBroken(id, !EffectCrashLog.isBroken(id))
        navigationItem.rightBarButtonItem?.title = EffectCrashLog.isBroken(id) ? "Re-enable" : "Disable"
        reload()
    }
    private func reload() {
        let fm = FileManager.default
        items = []
        if dir == nil {
            let c = CrashLog.crashDir(), e = EffectCrashLog.rootDir()
            try? fm.createDirectory(at: c, withIntermediateDirectories: true)
            try? fm.createDirectory(at: e, withIntermediateDirectories: true)
            items = [("Crash logs", "\(CrashLog.reportCount()) reports", c, true),
                     ("Effect crash logs", "\(EffectCrashLog.count()) effects with problems", e, true)]
        } else {
            let isEffectRoot = dir!.lastPathComponent == "EffectCrashLogs"
            let list = ((try? fm.contentsOfDirectory(at: dir!, includingPropertiesForKeys: [.isDirectoryKey, .contentModificationDateKey])) ?? [])
                .filter { !$0.lastPathComponent.hasPrefix(".") }
            let df = DateFormatter(); df.dateStyle = .medium; df.timeStyle = .short
            for u in list {
                let rv = try? u.resourceValues(forKeys: [.isDirectoryKey, .contentModificationDateKey])
                let isD = rv?.isDirectory ?? false
                var sub = rv?.contentModificationDate.map { df.string(from: $0) } ?? ""
                if isD && isEffectRoot {
                    let n = ((try? fm.contentsOfDirectory(atPath: u.path)) ?? []).count
                    sub = "\(n) log\(n == 1 ? "" : "s")" + (EffectCrashLog.isBroken(u.lastPathComponent) ? "  •  switched off" : "")
                }
                items.append((u.lastPathComponent, sub, u, isD))
            }
            items.sort { $0.title > $1.title }
        }
        tableView.reloadData()
    }
    override func tableView(_ t: UITableView, numberOfRowsInSection s: Int) -> Int { max(items.count, 1) }
    override func tableView(_ t: UITableView, cellForRowAt ip: IndexPath) -> UITableViewCell {
        let c = UITableViewCell(style: .subtitle, reuseIdentifier: nil)
        c.backgroundColor = argbToUIColor(C.CARD)
        c.textLabel?.textColor = argbToUIColor(C.TEXT); c.detailTextLabel?.textColor = argbToUIColor(C.DIM)
        if items.isEmpty { c.textLabel?.text = "Nothing here — no crashes or freezes recorded."; c.selectionStyle = .none; return c }
        let it = items[ip.row]
        c.textLabel?.text = it.title; c.detailTextLabel?.text = it.sub
        c.accessoryType = .disclosureIndicator
        return c
    }
    override func tableView(_ t: UITableView, didSelectRowAt ip: IndexPath) {
        t.deselectRow(at: ip, animated: true)
        guard ip.row < items.count else { return }
        let it = items[ip.row]
        navigationController?.pushViewController(it.isDir ? CrashBrowserViewController(dir: it.url) : LogViewController(url: it.url), animated: true)
    }
    override func tableView(_ t: UITableView, trailingSwipeActionsConfigurationForRowAt ip: IndexPath) -> UISwipeActionsConfiguration? {
        guard ip.row < items.count, dir != nil else { return nil }
        let a = UIContextualAction(style: .destructive, title: "Delete") { [weak self] _, _, done in
            guard let self = self else { return }
            try? FileManager.default.removeItem(at: self.items[ip.row].url); self.reload(); done(true)
        }
        return UISwipeActionsConfiguration(actions: [a])
    }
}

final class LogViewController: UIViewController {
    private let url: URL
    private let tv = UITextView()
    init(url: URL) { self.url = url; super.init(nibName: nil, bundle: nil) }
    required init?(coder: NSCoder) { fatalError() }
    override func viewDidLoad() {
        super.viewDidLoad()
        title = url.lastPathComponent
        view.backgroundColor = argbToUIColor(C.BG)
        tv.isEditable = false
        tv.font = .monospacedSystemFont(ofSize: 12, weight: .regular)
        tv.backgroundColor = argbToUIColor(C.BG); tv.textColor = argbToUIColor(C.TEXT)
        tv.text = (try? String(contentsOf: url, encoding: .utf8)) ?? (try? String(contentsOf: url, encoding: .isoLatin1)) ?? "(could not read this file)"
        tv.frame = view.bounds; tv.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.addSubview(tv)
        navigationItem.rightBarButtonItems = [
            UIBarButtonItem(title: "Export", style: .plain, target: self, action: #selector(exportIt)),
            UIBarButtonItem(title: "Copy", style: .plain, target: self, action: #selector(copyIt)),
        ]
    }
    @objc private func copyIt() {
        UIPasteboard.general.string = tv.text
        navigationItem.rightBarButtonItems?[1].title = "Copied"
    }
    @objc private func exportIt() {
        let v = UIActivityViewController(activityItems: [url], applicationActivities: nil)
        v.popoverPresentationController?.barButtonItem = navigationItem.rightBarButtonItems?[0]
        present(v, animated: true)
    }
}
