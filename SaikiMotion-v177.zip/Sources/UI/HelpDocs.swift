// HelpDocs.swift — in-app documentation (Settings > Help). Currently: Puppet.

import UIKit

enum HelpDocs {
    static let puppet: [(String, String)] = [
        ("Puppet: overview", "Puppet bends an image layer by pinning points on it. Drag a pin and the picture warps around it; pins you don't touch hold their place. Open it from the layer's toolbar (Puppet). The panel has three tabs: Pin, Mesh and Sway."),
        ("Pin tab", "Add: tap the layer to drop a pin. Select: tap a pin to pick it. Multi: pick several pins and move them together. Drag a pin to deform the layer. With Auto-key on, every drag records a keyframe on that pin (tracks named pp<id>x / pp<id>y), so you can edit, ease and graph them like any other property. Fine mode slows dragging for small moves. Delete removes the selected pins; Clear removes all."),
        ("Mesh tab", "Density sets how many triangles cover the layer (low / medium / high / ultra). Higher density follows pins more smoothly but costs more to preview. Stiffness controls how local a pin's pull is: higher keeps the warp close to the pin, lower spreads it wide. Show Mesh draws the triangle grid on the preview."),
        ("Sway tab: Auto Sway", "Auto Sway animates the pins for you. The master switch turns every sway on the layer on or off. Lock root keeps the first pin of each chain fixed so the effect hangs from it, like hair from a scalp or a flag from a pole."),
        ("Sway: stacking effects", "A layer can have many sway effects. Tap + Wave or + Physics to add one; each shows as a chip (Wave 1, Physics 2 ...). Select a chip to edit it, disable it, or delete it. All enabled effects are added together, so you can run a slow Wave for the breeze plus Physics for reaction to movement. Each effect has its own pin chain."),
        ("Pin chain", "Tap pins from root to tip. The number on the pin button is its place in the chain. The root moves least and the tip moves most. All in order picks every pin in the order they were placed. At least 2 pins are needed."),
        ("Wave", "Procedural swinging that needs no animation. Speed: cycles per second. Strength: swing angle at the tip in degrees. Wave: delay between pins, which makes the motion ripple along the chain. Tip weight: how quickly the effect grows toward the tip. Randomness and Seed vary each pin. Light / Medium / Heavy are quick strength presets."),
        ("Physics", "Physics makes the chain react to movement. Move, rotate or scale the layer (or its parent, or animate its pins) and the chain lags behind, overshoots and settles like a real object. Light / Medium / Heavy sets the mass: light is bouncy, heavy is slow and sags. Stiffness is how hard the chain pulls back to its rest pose. Damping is how fast the swinging dies down. Gravity pulls the chain downward. Wind pushes it sideways in gusts (negative values blow left). Strength scales how far it may lag. Physics is calculated from the layer's recent motion, so it looks the same when scrubbing, playing and exporting."),
        ("Linking to keyframes and expressions", "On a Physics effect, tap Link stiffness / damping / gravity / wind. This creates a layer track named sw<n>stiff, sw<n>damp, sw<n>grav or sw<n>wind (n is the effect's position, starting at 0). Keyframe the track or add an expression to it in the graph editor, for example to make wind rise over time, or to drive gravity from a marker. Tap the button again to unlink and return to the slider value."),
        ("Tips", "Use two or three pins per limb or strand. Put pins outside the area you want to keep still, and one pin on a fixed spot to anchor it. For a character that walks or jumps, add Physics to hair and clothes, put the layer in a parent that moves, and keep Lock root on. If the warp looks stretched, add a pin near the stretched spot or raise density."),
    ]

    static func show(from vc: UIViewController, title: String, sections: [(String, String)]) {
        let d = DocVC(); d.docTitle = title; d.sections = sections
        d.modalPresentationStyle = .fullScreen
        vc.present(d, animated: true)
    }
}

final class DocVC: UIViewController {
    var docTitle = ""; var sections: [(String, String)] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = argbToUIColor(C.BG)
        let bar = UIView(); bar.backgroundColor = argbToUIColor(C.PANEL)
        let t = UILabel(); t.text = docTitle; t.textColor = argbToUIColor(C.TEXT); t.font = .systemFont(ofSize: 18, weight: .semibold)
        let x = UIButton(type: .system); x.setTitle("Close", for: .normal); x.tintColor = argbToUIColor(C.GREEN)
        x.addTarget(self, action: #selector(close), for: .touchUpInside)
        let tv = UITextView(); tv.isEditable = false; tv.backgroundColor = .clear; tv.textContainerInset = UIEdgeInsets(top: 14, left: 16, bottom: 30, right: 16)
        let out = NSMutableAttributedString()
        for (h, b) in sections {
            out.append(NSAttributedString(string: h + "\n", attributes: [.font: UIFont.systemFont(ofSize: 17, weight: .bold), .foregroundColor: argbToUIColor(C.GREEN)]))
            out.append(NSAttributedString(string: b + "\n\n", attributes: [.font: UIFont.systemFont(ofSize: 15), .foregroundColor: argbToUIColor(C.TEXT)]))
        }
        tv.attributedText = out
        for v in [bar, tv] as [UIView] { v.translatesAutoresizingMaskIntoConstraints = false; view.addSubview(v) }
        for v in [t, x] as [UIView] { v.translatesAutoresizingMaskIntoConstraints = false; bar.addSubview(v) }
        NSLayoutConstraint.activate([
            bar.topAnchor.constraint(equalTo: view.topAnchor), bar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            bar.trailingAnchor.constraint(equalTo: view.trailingAnchor), bar.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 48),
            t.leadingAnchor.constraint(equalTo: bar.leadingAnchor, constant: 16), t.bottomAnchor.constraint(equalTo: bar.bottomAnchor, constant: -12),
            x.trailingAnchor.constraint(equalTo: bar.trailingAnchor, constant: -16), x.centerYAnchor.constraint(equalTo: t.centerYAnchor),
            tv.topAnchor.constraint(equalTo: bar.bottomAnchor), tv.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tv.trailingAnchor.constraint(equalTo: view.trailingAnchor), tv.bottomAnchor.constraint(equalTo: view.bottomAnchor)])
    }
    @objc private func close() { dismiss(animated: true) }
}
