// LayersSheet.swift — the Layers popup: a clipboard row (Copy / Paste / Properties / Duplicate /
// Preset) on top, then a list of layer actions. Swipe sideways for page 2 (Mask Group, Grid,
// guides and arrange tools).

import UIKit

final class LayersSheet: UIViewController, UIScrollViewDelegate {
    struct Item { let title: String; let icon: String; let on: Bool; let act: () -> Void }
    var clipboardReady = false
    var clipTools: [Item] = []          // exactly the 5 round buttons
    var pages: [[Item]] = []
    private let scroll = UIScrollView()
    private let dots = UIPageControl()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.black.withAlphaComponent(0.35)
        view.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(close)))
        let W: CGFloat = min(UIScreen.main.bounds.width - 32, 460)
        let rowH: CGFloat = 52, listH = rowH * 7
        let card = UIView(frame: CGRect(x: 0, y: 0, width: W, height: 28 + 86 + 1 + listH + 24))
        card.backgroundColor = argbToUIColor(C.CARD); card.layer.cornerRadius = 14; card.clipsToBounds = true
        card.center = CGPoint(x: view.bounds.midX, y: view.bounds.midY)
        card.autoresizingMask = [.flexibleTopMargin, .flexibleBottomMargin, .flexibleLeftMargin, .flexibleRightMargin]
        view.addSubview(card)

        let head = UILabel(frame: CGRect(x: 18, y: 8, width: W - 36, height: 22))
        head.text = clipboardReady ? "Clipboard ready" : "Clipboard empty"
        head.font = .systemFont(ofSize: 15); head.textColor = argbToUIColor(C.DIM); card.addSubview(head)

        let cw = W / 5
        for (i, it) in clipTools.enumerated() {
            let b = UIButton(type: .system)
            b.frame = CGRect(x: CGFloat(i) * cw, y: 32, width: cw, height: 82)
            let col = it.on ? argbToUIColor(C.TEXT) : argbToUIColor(C.DIM).withAlphaComponent(0.55)
            b.tintColor = col
            b.setImage(Icons.image(it.icon, size: 28, color: it.on ? C.TEXT : C.DIM).withRenderingMode(.alwaysOriginal), for: .normal)
            b.setTitle(it.title, for: .normal); b.setTitleColor(col, for: .normal)
            b.titleLabel?.font = .systemFont(ofSize: 12); b.titleLabel?.adjustsFontSizeToFitWidth = true
            b.titleEdgeInsets = UIEdgeInsets(top: 52, left: -28, bottom: 0, right: 0)
            b.imageEdgeInsets = UIEdgeInsets(top: -14, left: 0, bottom: 0, right: -b.titleLabel!.intrinsicContentSize.width)
            b.isEnabled = it.on; b.tag = i
            b.addTarget(self, action: #selector(clipTap(_:)), for: .touchUpInside)
            card.addSubview(b)
        }
        let line = UIView(frame: CGRect(x: 0, y: 116, width: W, height: 1))
        line.backgroundColor = argbToUIColor(C.CARD2); card.addSubview(line)

        scroll.frame = CGRect(x: 0, y: 117, width: W, height: listH)
        scroll.isPagingEnabled = true; scroll.showsHorizontalScrollIndicator = false
        scroll.bounces = false; scroll.delegate = self
        scroll.contentSize = CGSize(width: W * CGFloat(max(pages.count, 1)), height: listH)
        card.addSubview(scroll)
        for (pi, page) in pages.enumerated() {
            for (i, it) in page.enumerated() {
                let b = UIButton(type: .system)
                b.frame = CGRect(x: W * CGFloat(pi), y: CGFloat(i) * rowH, width: W, height: rowH)
                b.setImage(Icons.image(it.icon, size: 22, color: it.on ? C.GREEN : C.TEXT).withRenderingMode(.alwaysOriginal), for: .normal)
                b.setTitle("  " + it.title, for: .normal)
                b.setTitleColor(argbToUIColor(C.TEXT), for: .normal)
                b.titleLabel?.font = .systemFont(ofSize: 17, weight: .medium)
                b.contentHorizontalAlignment = .left
                b.contentEdgeInsets = UIEdgeInsets(top: 0, left: 20, bottom: 0, right: 0)
                b.tag = pi * 100 + i
                b.addTarget(self, action: #selector(rowTap(_:)), for: .touchUpInside)
                scroll.addSubview(b)
            }
        }
        dots.numberOfPages = pages.count; dots.hidesForSinglePage = true
        dots.frame = CGRect(x: 0, y: 117 + listH, width: W, height: 24)
        dots.isUserInteractionEnabled = false
        card.addSubview(dots)
    }

    func scrollViewDidScroll(_ s: UIScrollView) { dots.currentPage = Int(round(s.contentOffset.x / max(s.bounds.width, 1))) }
    @objc private func close() { dismiss(animated: true) }
    @objc private func clipTap(_ b: UIButton) { let a = clipTools[b.tag].act; dismiss(animated: true) { a() } }
    @objc private func rowTap(_ b: UIButton) { let a = pages[b.tag / 100][b.tag % 100].act; dismiss(animated: true) { a() } }
}
