// MBLEditor.swift — "Magic Bullet Looks" editor (mobile layout of the desktop UI): live preview, Controls panel for the
// selected tool, a tool chain grouped Subject / Matte / Lens / Camera / Post with icon cards, a Tools picker (icon grid
// with category tabs) and an Intensity slider. Parameters live on the layer (entry__mbXxx); Close discards, ✓ keeps.

import UIKit

struct MBLTool {
    let id: String, name: String, cat: String
    let vals: [(String, Float, Float)]          // key, neutral, value when added
    var sliders: [(String, String)] = []        // label, key
    var colors: [(String, String)] = []
}

let mblCats = ["Subject", "Matte", "Lens", "Camera", "Post"]
let mblTools: [MBLTool] = {
    var hsl: [(String, Float, Float)] = [("mbHsl", 0, 1)]
    for i in 0..<8 { hsl += [("mbH\(i)", 0, 0), ("mbS\(i)", 0, 0), ("mbL\(i)", 0, 0)] }
    var lgg: [(String, Float, Float)] = [("mbLg", 0, 1), ("mbLgSp", 1, 1), ("mbLgStr", 100, 100), ("mbLgExp", 0, 0)]
    for p in ["Li", "Ga", "Gn"] { for c in ["R", "G", "B"] { lgg.append(("mb" + p + c, 1, 1)) } }
    return [
        MBLTool(id: "diffusion", name: "Diffusion", cat: "Matte",
                vals: [("mbDfSize", 0, 30), ("mbDfGrade", 3, 3), ("mbDfGlow", 50, 50), ("mbDfHi", 75, 75), ("mbDfBias", 0, 0), ("mbDfExp", 0, 0)],
                sliders: [("Size", "mbDfSize"), ("Grade", "mbDfGrade"), ("Glow", "mbDfGlow"), ("Highlights Only", "mbDfHi"),
                          ("Highlight Bias", "mbDfBias"), ("Exposure Compensation", "mbDfExp")], colors: [("Color", "mbDfC")]),
        MBLTool(id: "edge", name: "Edge Softness", cat: "Lens",
                vals: [("mbEsBlur", 0, 3), ("mbEsQ", 3, 3), ("mbEsX", 0, 0), ("mbEsY", 0, 0), ("mbEsRad", 1, 1), ("mbEsAsp", 1, 1), ("mbEsSpr", 0.5, 0.5)],
                sliders: [("Blur Size", "mbEsBlur"), ("Quality", "mbEsQ"), ("Center X", "mbEsX"), ("Center Y", "mbEsY"),
                          ("Radius", "mbEsRad"), ("Aspect", "mbEsAsp"), ("Spread", "mbEsSpr")]),
        MBLTool(id: "chroma", name: "Chromatic Aberration", cat: "Lens",
                vals: [("mbCaR", 0, 1), ("mbCaG", 0, 0), ("mbCaB", 0, 0)],
                sliders: [("Red/Cyan", "mbCaR"), ("Green/Magenta", "mbCaG"), ("Blue/Yellow", "mbCaB")]),
        MBLTool(id: "exposure", name: "Exposure", cat: "Post", vals: [("mbExpo", 0, 0.01)], sliders: [("Exposure (stops)", "mbExpo")]),
        MBLTool(id: "warmcool", name: "Warm/Cool", cat: "Post", vals: [("mbWarm", 0, 0.2)], sliders: [("Warm / Cool", "mbWarm")]),
        MBLTool(id: "renoiser", name: "Renoiser", cat: "Post", vals: [("mbGrain", 0, 0.3), ("mbGrainSz", 1.5, 1.5)],
                sliders: [("Amount", "mbGrain"), ("Grain size", "mbGrainSz")]),
        MBLTool(id: "bleach", name: "Print Bleach Bypass", cat: "Post", vals: [("mbBB", 0, 50), ("mbBBe", 0, 0)], sliders: [("Silver Retention", "mbBB"), ("Exposure Compensation", "mbBBe")]),
        MBLTool(id: "contrast", name: "Contrast", cat: "Post", vals: [("mbCon", 0, 0.2), ("mbConPiv", 0.18, 0.18)],
                sliders: [("Contrast", "mbCon"), ("Pivot", "mbConPiv")]),
        MBLTool(id: "huesat", name: "Hue/Saturation", cat: "Post", vals: [("mbHue", 0, 0), ("mbSat", 1, 1.01)],
                sliders: [("Hue", "mbHue"), ("Saturation", "mbSat")]),
        MBLTool(id: "hsl", name: "HSL Colors", cat: "Post", vals: hsl),
        MBLTool(id: "duotone", name: "Duotone", cat: "Post", vals: [("mbDuo", 0, 1), ("mbDuoSA", 1, 1), ("mbDuoSB", 1, 1), ("mbDuoLo", 0, 0), ("mbDuoHi", 1, 1)],
                sliders: [("Amount", "mbDuo"), ("Highlights strength", "mbDuoSA"), ("Shadows strength", "mbDuoSB"), ("Low", "mbDuoLo"), ("High", "mbDuoHi")],
                colors: [("Shadows", "mbDuoS"), ("Highlights", "mbDuoH")]),

        MBLTool(id: "nbby", name: "Neg Bleach Bypass", cat: "Post", vals: [("mbNB", 0, 50), ("mbNBe", 0, 0)], sliders: [("Silver Retention", "mbNB"), ("Exposure Compensation", "mbNBe")]),
        MBLTool(id: "lgg", name: "Lift/Gamma/Gain", cat: "Post",
                vals: lgg,
                sliders: [("Lift Red", "mbLiR"), ("Lift Green", "mbLiG"), ("Lift Blue", "mbLiB"), ("Gamma Red", "mbGaR"), ("Gamma Green", "mbGaG"), ("Gamma Blue", "mbGaB"),
                          ("Gain Red", "mbGnR"), ("Gain Green", "mbGnG"), ("Gain Blue", "mbGnB"), ("Gamma Space", "mbLgSp"), ("Strength", "mbLgStr"), ("Exposure Compensation", "mbLgExp")]),
        MBLTool(id: "bw", name: "Black & White", cat: "Post", vals: [("mbBw", 0, 1), ("mbBwR", 0.3, 0.3), ("mbBwG", 0.59, 0.59), ("mbBwB", 0.11, 0.11)],
                sliders: [("Red Component", "mbBwR"), ("Green Component", "mbBwG"), ("Blue Component", "mbBwB")]),
        MBLTool(id: "twostrip", name: "2-Strip Process", cat: "Post", vals: [("mbTsOn", 0, 1), ("mbTsE", 1, 1), ("mbTsS", 0.5, 0.5)], sliders: [("Gain", "mbTsE"), ("Mix", "mbTsS")]),
        MBLTool(id: "lightflex", name: "Lightflex", cat: "Post", vals: [("mbFl", 0, 1), ("mbFlB", 0, 0), ("mbFlE", 0, 0)],
                sliders: [("Boost", "mbFlB"), ("Exposure Compensation", "mbFlE")], colors: [("Color", "mbFlC")]),
        MBLTool(id: "shoulder", name: "Auto Shoulder", cat: "Post", vals: [("mbAs", 0, 50)], sliders: [("Strength", "mbAs")]),
        MBLTool(id: "vignette", name: "Vignette", cat: "Post",
                vals: [("mbVgStr", 0, 100), ("mbVgExp", 0, 0), ("mbVgRad", 1, 1), ("mbVgSpr", 0.5, 0.5), ("mbVgFall", 0.5, 0.5), ("mbVgX", 0, 0), ("mbVgY", 0, 0), ("mbVgAsp", 1, 1)],
                sliders: [("Strength", "mbVgStr"), ("Exposure Compensation", "mbVgExp"), ("Radius", "mbVgRad"), ("Spread", "mbVgSpr"), ("Falloff", "mbVgFall"),
                          ("Center X", "mbVgX"), ("Center Y", "mbVgY"), ("Aspect", "mbVgAsp")], colors: [("Color", "mbVgC")]),
        MBLTool(id: "spot", name: "Spot Exposure", cat: "Post",
                vals: [("mbSpOn", 0, 1), ("mbSpS", 0, 1), ("mbSpRad", 0.6, 0.6), ("mbSpSpr", 0.5, 0.5), ("mbSpFall", 0.5, 0.5), ("mbSpX", 0, 0), ("mbSpY", 0, 0), ("mbSpAsp", 1, 1), ("mbSpInv", 0, 0)],
                sliders: [("Stops", "mbSpS"), ("Radius", "mbSpRad"), ("Spread", "mbSpSpr"), ("Falloff", "mbSpFall"), ("Center X", "mbSpX"), ("Center Y", "mbSpY"),
                          ("Aspect", "mbSpAsp"), ("Invert", "mbSpInv")], colors: [("Color", "mbSpC")]),
        MBLTool(id: "grad", name: "Grad Exposure", cat: "Post",
                vals: [("mbGxOn", 0, 1), ("mbGxStops", 0, -1), ("mbGxStr", 100, 100), ("mbGxFall", 0.5, 0.5), ("mbGxSx", 0.5, 0.5), ("mbGxSy", 0.25, 0.25), ("mbGxEx", 0.5, 0.5), ("mbGxEy", 0.75, 0.75)],
                sliders: [("Stops", "mbGxStops"), ("Strength", "mbGxStr"), ("Falloff", "mbGxFall"), ("Start X", "mbGxSx"), ("Start Y", "mbGxSy"), ("End X", "mbGxEx"), ("End Y", "mbGxEy")],
                colors: [("Color", "mbGxC")]),
        MBLTool(id: "curves", name: "Curves", cat: "Post", vals: [("mbCurvAmt", 0, 1)]),
    ]
}()

/// Icons redrawn to match the Magic Bullet tiles.
func mblIcon(_ id: String, _ s: CGFloat = 64) -> UIImage {
    UIGraphicsImageRenderer(size: CGSize(width: s, height: s)).image { r in
        let g = r.cgContext, rect = CGRect(x: 0, y: 0, width: s, height: s), ctr = CGPoint(x: s / 2, y: s / 2)
        func rr(_ c: UIColor) { c.setFill(); UIBezierPath(roundedRect: rect, cornerRadius: 6).fill() }
        func grad(_ cols: [UIColor], _ a: CGPoint, _ b: CGPoint) {
            let gr = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: cols.map { $0.cgColor } as CFArray, locations: nil)!
            g.saveGState(); UIBezierPath(roundedRect: rect, cornerRadius: 6).addClip()
            g.drawLinearGradient(gr, start: a, end: b, options: []); g.restoreGState()
        }
        func wheel(_ inner: CGFloat) {
            for i in 0..<72 {
                let a0 = CGFloat(i) / 72 * .pi * 2, a1 = (CGFloat(i) + 1.2) / 72 * .pi * 2
                UIColor(hue: CGFloat(i) / 72, saturation: 0.85, brightness: 1, alpha: 1).setFill()
                let p = UIBezierPath(); p.move(to: ctr); p.addArc(withCenter: ctr, radius: s * 0.44, startAngle: a0, endAngle: a1, clockwise: true); p.fill()
            }
            (inner > 0 ? UIColor.black : UIColor(white: 0.9, alpha: 1)).setFill()
            UIBezierPath(arcCenter: ctr, radius: s * (inner > 0 ? inner : 0.1), startAngle: 0, endAngle: .pi * 2, clockwise: true).fill()
        }
        switch id {
        case "exposure":
            rr(UIColor(white: 0.1, alpha: 1)); UIColor(white: 0.6, alpha: 1).setFill()
            UIBezierPath(arcCenter: ctr, radius: s * 0.44, startAngle: 0, endAngle: .pi * 2, clockwise: true).fill()
            UIColor(white: 0.95, alpha: 1).setFill()
            UIBezierPath(arcCenter: ctr, radius: s * 0.2, startAngle: 0, endAngle: .pi * 2, clockwise: true).fill()
            UIColor(white: 0.35, alpha: 1).setStroke()
            for i in 0..<6 { let a = CGFloat(i) / 6 * .pi * 2; let p = UIBezierPath(); p.lineWidth = 2
                p.move(to: CGPoint(x: ctr.x + cos(a) * s * 0.2, y: ctr.y + sin(a) * s * 0.2))
                p.addLine(to: CGPoint(x: ctr.x + cos(a + 0.9) * s * 0.44, y: ctr.y + sin(a + 0.9) * s * 0.44)); p.stroke() }
        case "warmcool":
            rr(UIColor(white: 0.1, alpha: 1)); UIColor(white: 0.55, alpha: 1).setFill()
            UIBezierPath(arcCenter: ctr, radius: s * 0.44, startAngle: 0, endAngle: .pi * 2, clockwise: true).fill()
        case "renoiser":
            rr(UIColor(white: 0.75, alpha: 1))
            for _ in 0..<160 { UIColor(white: CGFloat.random(in: 0.35...1), alpha: 1).setFill()
                UIBezierPath(rect: CGRect(x: .random(in: 8...s - 10), y: .random(in: 8...s - 10), width: 2, height: 2)).fill() }
        case "bleach":
            grad([UIColor(red: 0.95, green: 0.8, blue: 0.5, alpha: 1), UIColor(red: 0.35, green: 0.25, blue: 0.1, alpha: 1)], CGPoint(x: 0, y: 0), CGPoint(x: s, y: s))
            UIColor(red: 0.85, green: 0.1, blue: 0.1, alpha: 1).setStroke()
            let p = UIBezierPath(); p.lineWidth = 3; p.move(to: CGPoint(x: s * 0.5, y: s * 0.18)); p.addLine(to: CGPoint(x: s * 0.82, y: s * 0.78))
            p.addLine(to: CGPoint(x: s * 0.18, y: s * 0.78)); p.close(); p.stroke()
        case "contrast": grad([.white, UIColor(white: 0.05, alpha: 1)], CGPoint(x: 0, y: 0), CGPoint(x: s, y: s))
        case "huesat": rr(UIColor(white: 0.1, alpha: 1)); wheel(0)
        case "hsl":
            rr(UIColor(white: 0.1, alpha: 1)); wheel(0.32)
        case "duotone": grad([UIColor(white: 0.95, alpha: 1), UIColor(red: 0.8, green: 0.6, blue: 0.45, alpha: 1), UIColor(red: 0.05, green: 0.1, blue: 0.25, alpha: 1)], CGPoint(x: 0, y: 0), CGPoint(x: 0, y: s))
        case "curves":
            rr(.black); UIColor.white.setStroke()
            let p = UIBezierPath(); p.lineWidth = 2.5; p.move(to: CGPoint(x: 4, y: s - 4)); p.addLine(to: CGPoint(x: s - 4, y: 4)); p.stroke()
        case "chroma":
            rr(.black); UIColor.white.setStroke()
            let p = UIBezierPath(arcCenter: ctr, radius: s * 0.38, startAngle: 0, endAngle: .pi * 2, clockwise: true); p.lineWidth = 4; p.stroke()
        case "edge":
            rr(.white); UIColor.black.setFill(); let n = 8, q = s / CGFloat(n)
            for y in 0..<n { for x in 0..<n where (x + y) % 2 == 0 { UIBezierPath(rect: CGRect(x: CGFloat(x) * q, y: CGFloat(y) * q, width: q, height: q)).fill() } }
        case "diffusion":
            rr(.black)
            ("D" as NSString).draw(at: CGPoint(x: s * 0.26, y: s * 0.06), withAttributes: [.font: UIFont.italicSystemFont(ofSize: s * 0.8).withTraits(.traitBold), .foregroundColor: UIColor.white])
        case "nbby": grad([UIColor(red: 0.8, green: 0.7, blue: 0.5, alpha: 1), UIColor(white: 0.1, alpha: 1)], CGPoint(x: 0, y: 0), CGPoint(x: s, y: s))
            UIColor.white.setStroke(); let p = UIBezierPath(); p.lineWidth = 3; p.move(to: CGPoint(x: s * 0.5, y: s * 0.2)); p.addLine(to: CGPoint(x: s * 0.8, y: s * 0.76)); p.addLine(to: CGPoint(x: s * 0.2, y: s * 0.76)); p.close(); p.stroke()
        case "lgg": rr(UIColor(white: 0.1, alpha: 1))
            for (i, g) in [CGFloat(0.15), 0.5, 0.9].enumerated() { UIColor(white: g, alpha: 1).setFill(); UIBezierPath(arcCenter: CGPoint(x: s * (0.22 + 0.28 * CGFloat(i)), y: s * (i == 1 ? 0.35 : 0.65)), radius: s * 0.15, startAngle: 0, endAngle: .pi * 2, clockwise: true).fill() }
        case "bw": grad([.white, .black], CGPoint(x: 0, y: 0), CGPoint(x: s, y: 0))
        case "twostrip": grad([UIColor.red, UIColor.cyan], CGPoint(x: 0, y: 0), CGPoint(x: s, y: s))
        case "lightflex": grad([UIColor(white: 0.1, alpha: 1), UIColor(red: 1, green: 0.9, blue: 0.6, alpha: 1)], CGPoint(x: 0, y: s), CGPoint(x: s, y: 0))
        case "shoulder": rr(.black); UIColor.white.setStroke(); let p = UIBezierPath(); p.lineWidth = 2.5; p.move(to: CGPoint(x: 4, y: s - 4)); p.addQuadCurve(to: CGPoint(x: s - 4, y: s * 0.2), controlPoint: CGPoint(x: s * 0.7, y: s * 0.1)); p.stroke()
        case "vignette", "spot":
            rr(UIColor(white: 0.05, alpha: 1)); let gr = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: [UIColor(white: id == "spot" ? 1 : 0.85, alpha: 1).cgColor, UIColor(white: 0.05, alpha: 1).cgColor] as CFArray, locations: nil)!
            g.saveGState(); UIBezierPath(roundedRect: rect, cornerRadius: 6).addClip(); g.drawRadialGradient(gr, startCenter: ctr, startRadius: 0, endCenter: ctr, endRadius: s * 0.55, options: []); g.restoreGState()
        case "grad": grad([UIColor(white: 0.95, alpha: 1), UIColor(white: 0.1, alpha: 1)], CGPoint(x: 0, y: 0), CGPoint(x: 0, y: s))
        default: rr(UIColor(white: 0.2, alpha: 1))
        }
    }
}
private extension UIFont { func withTraits(_ t: UIFontDescriptor.SymbolicTraits) -> UIFont {
    UIFont(descriptor: fontDescriptor.withSymbolicTraits([fontDescriptor.symbolicTraits, t]) ?? fontDescriptor, size: pointSize) } }

final class MBLEditorViewController: UIViewController {
    private let lay: Layer, entry: String, onDone: () -> Void, def: EffectDef?
    private var defs: [String: PropDef] = [:], snap: [String: Float] = [:], snapMods: String?
    private var savedVideoCb: (() -> Void)?
    private lazy var pv: PreviewView = {
        savedVideoCb = MetalSceneRenderer.onVideoFrame
        let v = PreviewView(); v.quality = 2; return v
    }()
    private let chainStack = UIStackView(), body = UIStackView()
    private var curTool: String? = nil, curveCh = "M", hslIdx = 0, holdInt: Float? = nil, pickCat = "Post"
    private let gold = UIColor(red: 0.96, green: 0.65, blue: 0.14, alpha: 1)
    private var portraitC: [NSLayoutConstraint] = [], landscapeC: [NSLayoutConstraint] = [], isLandscape: Bool? = nil

    init(_ l: Layer, _ entry: String, onDone: @escaping () -> Void) {
        self.lay = l; self.entry = entry; self.onDone = onDone; self.def = Registry.get(entry)
        super.init(nibName: nil, bundle: nil)
        for p in def?.props ?? [] { defs[p.key] = p }
        for (k, t) in l.props where k.hasPrefix(entry + "__") { snap[k] = t.base }
        snapMods = l.pbrMaps["mbmods:" + entry]
    }
    required init?(coder: NSCoder) { fatalError() }

    // MARK: params
    private func key(_ k: String) -> String { entry + "__" + k }
    private func val(_ k: String) -> Float {
        let kk = key(k)
        if let tr = lay.props[kk] { return tr.eval(lay.editTime(kk, Editor.time)) }
        return defs[k]?.def ?? 0
    }
    private func set(_ k: String, _ v: Float) { lay.track(key(k)).base = v; pv.requestDraw() }
    private func comp(_ k: String, _ s: String, _ d: Float) -> Float {
        let kk = key(k) + "_" + s
        if let tr = lay.props[kk] { return tr.eval(lay.editTime(kk, Editor.time)) }
        return d
    }
    private func fmt(_ k: String, _ v: Float) -> String {
        if k.count == 3, k.hasPrefix("mb"), let l = k.last, l.isNumber { return String(format: "%.0f%%", v * 100) }
        if ["mbDfSize", "mbDfGlow", "mbDfHi", "mbEsBlur"].contains(k) { return String(format: "%.2f%%", v) }
        if ["mbEsX", "mbEsY"].contains(k) { return String(format: "%.0f%%", v) }
        if k.hasPrefix("mbCa") { return String(format: "%+.3f", v) }
        let d = defs[k]?.dec ?? 2
        return String(format: "%.\(d)f", v)
    }

    // MARK: chain
    private var mods: [String] {
        get { (lay.pbrMaps["mbmods:" + entry] ?? "").split(separator: ",").map(String.init).filter { id in mblTools.contains { $0.id == id } } }
        set { lay.pbrMaps["mbmods:" + entry] = newValue.joined(separator: ",") }
    }
    private func tool(_ id: String) -> MBLTool { mblTools.first { $0.id == id }! }
    private func addMod(_ id: String) {
        var m = mods
        if !m.contains(id) { m.append(id); for (k, _, v) in tool(id).vals { set(k, v) } }
        mods = m; curTool = id; pv.requestDraw(); showTab()
    }
    private func removeMod(_ id: String) {
        mods = mods.filter { $0 != id }
        for (k, n, _) in tool(id).vals { set(k, n) }
        if id == "curves" { for ch in looksCurveChannels { for i in 0..<7 { set("mbCv\(ch)\(i)", Float(i) / 6) } } }
        if curTool == id { curTool = mods.last }
        pv.requestDraw(); showTab()
    }

    // MARK: layout
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(white: 0.07, alpha: 1)
        let safe = view.safeAreaLayoutGuide
        let bar = UIView(); bar.translatesAutoresizingMaskIntoConstraints = false
        func icon(_ n: String, _ a: @escaping () -> Void) -> UIButton {
            let b = UIButton(type: .system); b.setImage(UIImage(systemName: n), for: .normal); b.tintColor = .white
            b.addAction(UIAction { _ in a() }, for: .touchUpInside); return b
        }
        let close = icon("xmark") { [weak self] in self?.finish(apply: false) }
        let ok = icon("checkmark") { [weak self] in self?.finish(apply: true) }
        ok.tintColor = gold
        let title = UILabel(); title.text = "MAGIC BULLET LOOKS"
        title.font = .systemFont(ofSize: 13, weight: .heavy); title.textColor = UIColor(white: 0.85, alpha: 1)
        for v in [close, ok, title] as [UIView] { v.translatesAutoresizingMaskIntoConstraints = false; bar.addSubview(v) }
        view.addSubview(bar)

        let box = UIView(); box.translatesAutoresizingMaskIntoConstraints = false; box.backgroundColor = .black; box.clipsToBounds = true
        view.addSubview(box)
        pv.translatesAutoresizingMaskIntoConstraints = false; box.addSubview(pv)
        let cmp = UIButton(type: .system)
        cmp.setTitle("Hold: before", for: .normal); cmp.titleLabel?.font = .systemFont(ofSize: 12, weight: .semibold)
        cmp.setTitleColor(.white, for: .normal); cmp.backgroundColor = UIColor(white: 0, alpha: 0.6); cmp.layer.cornerRadius = 13
        cmp.contentEdgeInsets = UIEdgeInsets(top: 5, left: 12, bottom: 5, right: 12); cmp.translatesAutoresizingMaskIntoConstraints = false
        cmp.addAction(UIAction { [weak self] _ in guard let s = self else { return }; s.holdInt = s.val("mbInt"); s.set("mbInt", 0) }, for: .touchDown)
        cmp.addAction(UIAction { [weak self] _ in guard let s = self, let h = s.holdInt else { return }; s.set("mbInt", h); s.holdInt = nil },
                      for: [.touchUpInside, .touchUpOutside, .touchCancel])
        box.addSubview(cmp)

        // bottom: Intensity row + tool chain
        let bottom = UIView(); bottom.translatesAutoresizingMaskIntoConstraints = false; bottom.backgroundColor = UIColor(white: 0.1, alpha: 1)
        view.addSubview(bottom)
        let inten = sliderRow("Intensity", "mbInt", pct: true)
        let toolsBtn = UIButton(type: .system)
        toolsBtn.setTitle("＋ Tools", for: .normal); toolsBtn.titleLabel?.font = .systemFont(ofSize: 13, weight: .bold)
        toolsBtn.setTitleColor(.black, for: .normal); toolsBtn.backgroundColor = gold; toolsBtn.layer.cornerRadius = 14
        toolsBtn.contentEdgeInsets = UIEdgeInsets(top: 4, left: 12, bottom: 4, right: 12)
        toolsBtn.addAction(UIAction { [weak self] _ in self?.showPicker(nil) }, for: .touchUpInside)
        let irow = UIStackView(arrangedSubviews: [inten, toolsBtn]); irow.spacing = 12; irow.alignment = .center
        irow.translatesAutoresizingMaskIntoConstraints = false; bottom.addSubview(irow)
        let scroll = UIScrollView(); scroll.translatesAutoresizingMaskIntoConstraints = false
        scroll.showsHorizontalScrollIndicator = false; scroll.alwaysBounceHorizontal = true
        chainStack.axis = .horizontal; chainStack.spacing = 14; chainStack.alignment = .top
        chainStack.translatesAutoresizingMaskIntoConstraints = false
        scroll.addSubview(chainStack); bottom.addSubview(scroll)

        let bodyScroll = UIScrollView(); bodyScroll.translatesAutoresizingMaskIntoConstraints = false; bodyScroll.keyboardDismissMode = .onDrag
        body.axis = .vertical; body.spacing = 14; body.translatesAutoresizingMaskIntoConstraints = false
        bodyScroll.addSubview(body); view.addSubview(bodyScroll)

        let aspect = CGFloat(max(Editor.project.w, 1)) / CGFloat(max(Editor.project.h, 1))
        let fillH = pv.heightAnchor.constraint(equalTo: box.heightAnchor); fillH.priority = UILayoutPriority(750)
        let fillW = pv.widthAnchor.constraint(equalTo: box.widthAnchor); fillW.priority = UILayoutPriority(749)
        NSLayoutConstraint.activate([
            bar.topAnchor.constraint(equalTo: safe.topAnchor), bar.leadingAnchor.constraint(equalTo: safe.leadingAnchor),
            bar.trailingAnchor.constraint(equalTo: safe.trailingAnchor), bar.heightAnchor.constraint(equalToConstant: 44),
            close.leadingAnchor.constraint(equalTo: bar.leadingAnchor, constant: 14), close.centerYAnchor.constraint(equalTo: bar.centerYAnchor),
            title.centerXAnchor.constraint(equalTo: bar.centerXAnchor), title.centerYAnchor.constraint(equalTo: bar.centerYAnchor),
            ok.trailingAnchor.constraint(equalTo: bar.trailingAnchor, constant: -14), ok.centerYAnchor.constraint(equalTo: bar.centerYAnchor),
            pv.centerXAnchor.constraint(equalTo: box.centerXAnchor), pv.centerYAnchor.constraint(equalTo: box.centerYAnchor),
            pv.widthAnchor.constraint(lessThanOrEqualTo: box.widthAnchor), pv.heightAnchor.constraint(lessThanOrEqualTo: box.heightAnchor),
            pv.widthAnchor.constraint(equalTo: pv.heightAnchor, multiplier: aspect), fillH, fillW,
            cmp.trailingAnchor.constraint(equalTo: box.trailingAnchor, constant: -10), cmp.bottomAnchor.constraint(equalTo: box.bottomAnchor, constant: -10),
            irow.topAnchor.constraint(equalTo: bottom.topAnchor, constant: 8),
            irow.leadingAnchor.constraint(equalTo: bottom.leadingAnchor, constant: 14), irow.trailingAnchor.constraint(equalTo: bottom.trailingAnchor, constant: -14),
            scroll.topAnchor.constraint(equalTo: irow.bottomAnchor, constant: 6), scroll.heightAnchor.constraint(equalToConstant: 98),
            scroll.leadingAnchor.constraint(equalTo: bottom.leadingAnchor), scroll.trailingAnchor.constraint(equalTo: bottom.trailingAnchor),
            scroll.bottomAnchor.constraint(equalTo: safe.bottomAnchor, constant: -6),
            chainStack.leadingAnchor.constraint(equalTo: scroll.contentLayoutGuide.leadingAnchor, constant: 14),
            chainStack.trailingAnchor.constraint(equalTo: scroll.contentLayoutGuide.trailingAnchor, constant: -14),
            chainStack.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor),
            chainStack.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor),
            chainStack.heightAnchor.constraint(equalTo: scroll.frameLayoutGuide.heightAnchor),
            body.topAnchor.constraint(equalTo: bodyScroll.contentLayoutGuide.topAnchor, constant: 10),
            body.bottomAnchor.constraint(equalTo: bodyScroll.contentLayoutGuide.bottomAnchor, constant: -24),
            body.leadingAnchor.constraint(equalTo: bodyScroll.frameLayoutGuide.leadingAnchor, constant: 16),
            body.trailingAnchor.constraint(equalTo: bodyScroll.frameLayoutGuide.trailingAnchor, constant: -16),
            body.widthAnchor.constraint(equalTo: bodyScroll.frameLayoutGuide.widthAnchor, constant: -32),
        ])
        portraitC = [
            box.topAnchor.constraint(equalTo: bar.bottomAnchor), box.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            box.trailingAnchor.constraint(equalTo: view.trailingAnchor), box.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.34),
            bottom.leadingAnchor.constraint(equalTo: view.leadingAnchor), bottom.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            bottom.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            bodyScroll.topAnchor.constraint(equalTo: box.bottomAnchor), bodyScroll.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            bodyScroll.trailingAnchor.constraint(equalTo: view.trailingAnchor), bodyScroll.bottomAnchor.constraint(equalTo: bottom.topAnchor),
        ]
        landscapeC = [
            box.topAnchor.constraint(equalTo: bar.bottomAnchor), box.leadingAnchor.constraint(equalTo: safe.leadingAnchor),
            box.bottomAnchor.constraint(equalTo: view.bottomAnchor), box.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.5),
            bottom.leadingAnchor.constraint(equalTo: box.trailingAnchor), bottom.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            bottom.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            bodyScroll.topAnchor.constraint(equalTo: bar.bottomAnchor), bodyScroll.leadingAnchor.constraint(equalTo: box.trailingAnchor),
            bodyScroll.trailingAnchor.constraint(equalTo: safe.trailingAnchor), bodyScroll.bottomAnchor.constraint(equalTo: bottom.topAnchor),
        ]
        curTool = mods.last
        updateLayoutMode(); showTab()
    }
    private func updateLayoutMode() {
        let land = view.bounds.width > view.bounds.height
        guard land != isLandscape else { return }
        isLandscape = land
        NSLayoutConstraint.deactivate(land ? portraitC : landscapeC); NSLayoutConstraint.activate(land ? landscapeC : portraitC)
    }
    override func viewDidLayoutSubviews() { super.viewDidLayoutSubviews(); updateLayoutMode() }
    override func viewDidAppear(_ animated: Bool) { super.viewDidAppear(animated); pv.requestDraw() }

    // MARK: chain strip
    private func card(_ id: String) -> UIView {
        let t = tool(id), on = curTool == id
        let b = UIButton(type: .custom)
        b.setImage(mblIcon(id), for: .normal); b.imageView?.contentMode = .scaleAspectFill
        b.layer.cornerRadius = 8; b.clipsToBounds = true
        b.layer.borderWidth = on ? 2.5 : 0; b.layer.borderColor = gold.cgColor
        b.addAction(UIAction { [weak self] _ in self?.curTool = id; self?.showTab() }, for: .touchUpInside)
        let x = UIButton(type: .system)
        x.setImage(UIImage(systemName: "xmark.circle.fill"), for: .normal); x.tintColor = UIColor(white: 0.85, alpha: 1)
        x.addAction(UIAction { [weak self] _ in self?.removeMod(id) }, for: .touchUpInside)
        let l = UILabel(); l.text = t.name; l.font = .systemFont(ofSize: 9, weight: .medium); l.textColor = on ? .white : UIColor(white: 0.6, alpha: 1)
        l.textAlignment = .center; l.adjustsFontSizeToFitWidth = true; l.minimumScaleFactor = 0.6
        let w = UIView()
        for v in [b, x, l] as [UIView] { v.translatesAutoresizingMaskIntoConstraints = false; w.addSubview(v) }
        NSLayoutConstraint.activate([
            w.widthAnchor.constraint(equalToConstant: 60), b.topAnchor.constraint(equalTo: w.topAnchor), b.leadingAnchor.constraint(equalTo: w.leadingAnchor),
            b.widthAnchor.constraint(equalToConstant: 60), b.heightAnchor.constraint(equalToConstant: 60),
            x.topAnchor.constraint(equalTo: w.topAnchor, constant: -4), x.trailingAnchor.constraint(equalTo: w.trailingAnchor, constant: 4),
            x.widthAnchor.constraint(equalToConstant: 24), x.heightAnchor.constraint(equalToConstant: 24),
            l.topAnchor.constraint(equalTo: b.bottomAnchor, constant: 2), l.leadingAnchor.constraint(equalTo: w.leadingAnchor), l.trailingAnchor.constraint(equalTo: w.trailingAnchor),
        ])
        return w
    }
    private func group(_ cat: String) -> UIView {
        let ids = mods.filter { tool($0).cat == cat }
        let row = UIStackView(); row.spacing = 8; row.alignment = .top
        if ids.isEmpty {
            let e = UIView(); e.backgroundColor = UIColor(white: 0.13, alpha: 1); e.layer.cornerRadius = 8
            e.translatesAutoresizingMaskIntoConstraints = false
            e.widthAnchor.constraint(equalToConstant: 60).isActive = true; e.heightAnchor.constraint(equalToConstant: 60).isActive = true
            row.addArrangedSubview(e)
        } else { ids.forEach { row.addArrangedSubview(card($0)) } }
        let lab = UIButton(type: .system); lab.setTitle(cat, for: .normal); lab.titleLabel?.font = .systemFont(ofSize: 11, weight: .semibold)
        lab.setTitleColor(UIColor(white: 0.75, alpha: 1), for: .normal); lab.backgroundColor = UIColor(white: 0.16, alpha: 1); lab.layer.cornerRadius = 6
        lab.addAction(UIAction { [weak self] _ in self?.showPicker(cat) }, for: .touchUpInside)
        lab.translatesAutoresizingMaskIntoConstraints = false; lab.heightAnchor.constraint(equalToConstant: 22).isActive = true
        let col = UIStackView(arrangedSubviews: [row, lab]); col.axis = .vertical; col.spacing = 6; col.alignment = .fill
        return col
    }

    private func showTab() {
        chainStack.arrangedSubviews.forEach { $0.removeFromSuperview() }
        for c in mblCats { chainStack.addArrangedSubview(group(c)) }
        body.arrangedSubviews.forEach { $0.removeFromSuperview() }
        guard let id = curTool, mods.contains(id) else {
            let l = UILabel(); l.numberOfLines = 0; l.textColor = UIColor(white: 0.55, alpha: 1); l.font = .systemFont(ofSize: 14)
            l.text = "No tool selected.\nTap ＋ Tools (or a category) and pick an effect. Nothing changes until you add one."
            body.addArrangedSubview(l); return
        }
        let t = tool(id)
        let h = UILabel(); h.text = t.name; h.font = .systemFont(ofSize: 17, weight: .bold); h.textColor = .white
        let rs = UIButton(type: .system); rs.setTitle("↺ Reset", for: .normal); rs.tintColor = gold
        rs.addAction(UIAction { [weak self] _ in
            for (k, _, v) in t.vals { self?.set(k, v) }
            if id == "curves" { for ch in looksCurveChannels { for i in 0..<7 { self?.set("mbCv\(ch)\(i)", Float(i) / 6) } } }
            self?.showTab()
        }, for: .touchUpInside)
        body.addArrangedSubview(UIStackView(arrangedSubviews: [h, UIView(), rs]))
        if id == "curves" { curvesPanel() } else if id == "hsl" { hslPanel() } else {
            for (n, k) in t.sliders { body.addArrangedSubview(sliderRow(n, k)) }
            for (n, k) in t.colors { body.addArrangedSubview(colorRow(n, k)) }
        }
    }

    // MARK: panels
    private func curvesPanel() {
        let names: [(String, String, UIColor)] = [("M", "RGB", .white), ("R", "Red", UIColor(red: 1, green: 0.3, blue: 0.3, alpha: 1)),
                                                  ("G", "Green", UIColor(red: 0.3, green: 0.95, blue: 0.3, alpha: 1)), ("B", "Blue", UIColor(red: 0.4, green: 0.6, blue: 1, alpha: 1))]
        let row = UIStackView(); row.spacing = 8; row.distribution = .fillEqually
        for (id, n, c) in names {
            let b = UIButton(type: .system); b.setTitle(n, for: .normal); b.titleLabel?.font = .systemFont(ofSize: 13, weight: .semibold)
            let on = curveCh == id
            b.setTitleColor(on ? .black : .white, for: .normal); b.backgroundColor = on ? c : UIColor(white: 0.18, alpha: 1); b.layer.cornerRadius = 6
            b.translatesAutoresizingMaskIntoConstraints = false; b.heightAnchor.constraint(equalToConstant: 32).isActive = true
            b.addAction(UIAction { [weak self] _ in self?.curveCh = id; self?.showTab() }, for: .touchUpInside)
            row.addArrangedSubview(b)
        }
        body.addArrangedSubview(row)
        let ch = curveCh
        let g = LooksCurveGraphView()
        g.color = names.first { $0.0 == ch }?.2 ?? .white
        g.values = (0..<7).map { val("mbCv\(ch)\($0)") }
        g.onChange = { [weak self] i, v in self?.set("mbCv\(ch)\(i)", v) }
        g.translatesAutoresizingMaskIntoConstraints = false; g.heightAnchor.constraint(equalToConstant: 260).isActive = true
        body.addArrangedSubview(g)
        body.addArrangedSubview(sliderRow("Amount", "mbCurvAmt", pct: true))
    }

    private func hslPanel() {
        let cols: [UIColor] = [.red, .orange, .yellow, .green, .cyan, .blue, .purple, .magenta]
        let dots = UIStackView(); dots.spacing = 10; dots.distribution = .fillEqually
        for i in 0..<8 {
            let b = UIButton(type: .custom); b.backgroundColor = cols[i]; b.layer.cornerRadius = 16
            b.layer.borderWidth = i == hslIdx ? 3 : 0; b.layer.borderColor = UIColor.white.cgColor
            b.translatesAutoresizingMaskIntoConstraints = false; b.heightAnchor.constraint(equalToConstant: 32).isActive = true
            b.addAction(UIAction { [weak self] _ in self?.hslIdx = i; self?.showTab() }, for: .touchUpInside)
            dots.addArrangedSubview(b)
        }
        body.addArrangedSubview(dots)
        let n = UILabel(); n.text = mblHslNames[hslIdx]; n.textColor = UIColor(white: 0.7, alpha: 1); n.font = .systemFont(ofSize: 12, weight: .semibold)
        body.addArrangedSubview(n)
        body.addArrangedSubview(sliderRow("Hue", "mbH\(hslIdx)"))
        body.addArrangedSubview(sliderRow("Saturation", "mbS\(hslIdx)"))
        body.addArrangedSubview(sliderRow("Lightness", "mbL\(hslIdx)"))
    }

    private func sliderRow(_ title: String, _ k: String, pct: Bool = false) -> UIView {
        guard let pd = defs[k] else { return UIView() }
        let t = UILabel(); t.text = title; t.font = .systemFont(ofSize: 14, weight: .medium); t.textColor = .white
        let v = UILabel(); v.font = .monospacedDigitSystemFont(ofSize: 13, weight: .regular); v.textColor = gold; v.textAlignment = .right
        v.setContentHuggingPriority(.required, for: .horizontal)
        let s = UISlider(); s.minimumValue = pd.min; s.maximumValue = pd.max; s.value = val(k); s.tintColor = gold
        let show: (Float) -> String = { [weak self] x in pct ? String(format: "%.0f%%", x * 100) : (self?.fmt(k, x) ?? "") }
        v.text = show(s.value)
        s.addAction(UIAction { [weak self, weak s, weak v] _ in guard let s = s, let v = v else { return }; self?.set(k, s.value); v.text = show(s.value) }, for: .valueChanged)
        let top = UIStackView(arrangedSubviews: [t, UIView(), v]); top.spacing = 8
        if pct { let r = UIStackView(arrangedSubviews: [t, s, v]); r.spacing = 10; r.alignment = .center
            t.setContentHuggingPriority(.required, for: .horizontal); return r }
        let col = UIStackView(arrangedSubviews: [top, s]); col.axis = .vertical; col.spacing = 2
        return col
    }

    private func colorRow(_ title: String, _ k: String) -> UIView {
        let cp = def?.colors.first { $0.key == k }
        let u = UInt32(bitPattern: cp?.def ?? Int32(bitPattern: 0xFF808080))
        let w = UIColorWell(); w.supportsAlpha = false; w.title = title
        w.selectedColor = UIColor(red: CGFloat(comp(k, "r", Float((u >> 16) & 0xFF) / 255)), green: CGFloat(comp(k, "g", Float((u >> 8) & 0xFF) / 255)),
                                  blue: CGFloat(comp(k, "b", Float(u & 0xFF) / 255)), alpha: 1)
        w.addAction(UIAction { [weak self, weak w] _ in
            guard let self = self, let c = w?.selectedColor else { return }
            var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0; c.getRed(&r, green: &g, blue: &b, alpha: &a)
            self.lay.track(self.key(k) + "_r").base = Float(r); self.lay.track(self.key(k) + "_g").base = Float(g)
            self.lay.track(self.key(k) + "_b").base = Float(b); self.lay.track(self.key(k) + "_a").base = 1
            self.pv.requestDraw()
        }, for: .valueChanged)
        let t = UILabel(); t.text = title; t.font = .systemFont(ofSize: 14, weight: .medium); t.textColor = .white
        let row = UIStackView(arrangedSubviews: [t, UIView(), w]); row.alignment = .center
        return row
    }

    // MARK: tools picker (icon grid + category tabs)
    private var pickerBody: UIStackView?
    private func showPicker(_ cat: String?) {
        if let c = cat { pickCat = c }
        let vc = UIViewController(); vc.view.backgroundColor = UIColor(white: 0.08, alpha: 1)
        let tabs = UIStackView(); tabs.distribution = .fillEqually; tabs.translatesAutoresizingMaskIntoConstraints = false
        let grid = UIStackView(); grid.axis = .vertical; grid.spacing = 14; grid.translatesAutoresizingMaskIntoConstraints = false
        let sc = UIScrollView(); sc.translatesAutoresizingMaskIntoConstraints = false; sc.addSubview(grid)
        let ttl = UILabel(); ttl.text = "TOOLS"; ttl.font = .systemFont(ofSize: 13, weight: .heavy); ttl.textColor = .white; ttl.translatesAutoresizingMaskIntoConstraints = false
        func fill() {
            tabs.arrangedSubviews.forEach { $0.removeFromSuperview() }; grid.arrangedSubviews.forEach { $0.removeFromSuperview() }
            for c in mblCats {
                let b = UIButton(type: .system); b.setTitle(c, for: .normal); b.titleLabel?.font = .systemFont(ofSize: 12, weight: .semibold)
                b.setTitleColor(c == pickCat ? gold : UIColor(white: 0.65, alpha: 1), for: .normal)
                b.addAction(UIAction { [weak self] _ in self?.pickCat = c; fill() }, for: .touchUpInside); tabs.addArrangedSubview(b)
            }
            let list = mblTools.filter { $0.cat == pickCat }
            if list.isEmpty {
                let l = UILabel(); l.text = "More \(pickCat) tools are coming soon."; l.textColor = UIColor(white: 0.5, alpha: 1); l.font = .systemFont(ofSize: 14); grid.addArrangedSubview(l); return
            }
            for chunk in stride(from: 0, to: list.count, by: 3) {
                let row = UIStackView(); row.distribution = .fillEqually; row.spacing = 12; row.alignment = .top
                for t in list[chunk..<min(chunk + 3, list.count)] {
                    let b = UIButton(type: .custom); b.setImage(mblIcon(t.id, 96), for: .normal); b.imageView?.contentMode = .scaleAspectFit
                    b.layer.cornerRadius = 10; b.clipsToBounds = true; b.alpha = mods.contains(t.id) ? 0.4 : 1
                    b.addAction(UIAction { [weak self, weak vc] _ in self?.addMod(t.id); vc?.dismiss(animated: true) }, for: .touchUpInside)
                    let l = UILabel(); l.text = t.name; l.font = .systemFont(ofSize: 11); l.textColor = UIColor(white: 0.75, alpha: 1); l.textAlignment = .center; l.numberOfLines = 2
                    b.translatesAutoresizingMaskIntoConstraints = false; b.heightAnchor.constraint(equalTo: b.widthAnchor).isActive = true
                    let c = UIStackView(arrangedSubviews: [b, l]); c.axis = .vertical; c.spacing = 4; row.addArrangedSubview(c)
                }
                while row.arrangedSubviews.count < 3 { row.addArrangedSubview(UIView()) }
                grid.addArrangedSubview(row)
            }
        }
        fill()
        [ttl, tabs, sc].forEach { vc.view.addSubview($0) }
        let g = vc.view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            ttl.topAnchor.constraint(equalTo: vc.view.topAnchor, constant: 16), ttl.centerXAnchor.constraint(equalTo: vc.view.centerXAnchor),
            tabs.topAnchor.constraint(equalTo: ttl.bottomAnchor, constant: 8), tabs.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 8),
            tabs.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -8), tabs.heightAnchor.constraint(equalToConstant: 34),
            sc.topAnchor.constraint(equalTo: tabs.bottomAnchor, constant: 8), sc.leadingAnchor.constraint(equalTo: vc.view.leadingAnchor),
            sc.trailingAnchor.constraint(equalTo: vc.view.trailingAnchor), sc.bottomAnchor.constraint(equalTo: vc.view.bottomAnchor),
            grid.topAnchor.constraint(equalTo: sc.contentLayoutGuide.topAnchor, constant: 8), grid.bottomAnchor.constraint(equalTo: sc.contentLayoutGuide.bottomAnchor, constant: -24),
            grid.leadingAnchor.constraint(equalTo: sc.frameLayoutGuide.leadingAnchor, constant: 16), grid.trailingAnchor.constraint(equalTo: sc.frameLayoutGuide.trailingAnchor, constant: -16),
            grid.widthAnchor.constraint(equalTo: sc.frameLayoutGuide.widthAnchor, constant: -32),
        ])
        if let sh = vc.sheetPresentationController { sh.detents = [.medium(), .large()] }
        present(vc, animated: true)
    }

    // MARK: finish
    private func finish(apply: Bool) {
        if !apply {
            for k in Array(lay.props.keys) where k.hasPrefix(entry + "__") { if let b = snap[k] { lay.props[k]?.base = b } else { lay.props[k] = nil } }
            lay.pbrMaps["mbmods:" + entry] = snapMods
        }
        MetalSceneRenderer.onVideoFrame = savedVideoCb
        let done = onDone
        dismiss(animated: true) { done() }
    }
}

/// Tiny closure target for gesture recognizers.
final class BlockTarget: NSObject {
    let cb: () -> Void
    init(_ cb: @escaping () -> Void) { self.cb = cb }
    @objc func fire() { cb() }
}
