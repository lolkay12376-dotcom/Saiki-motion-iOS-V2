// ParticularDraw.swift — CPU drawing of a Particular field (UI). One routine draws the designer viewport, the preset
// thumbnails and the tile art, using the same sprite-size, fade, gradient and falloff maths as the Metal point-sprite
// shader (MetalParticles.swift), so what the designer shows is what the viewport renders.

import UIKit

typealias PtProject = (Float, Float, Float) -> (x: CGFloat, y: CGFloat, k: Float, depth: Float)?

enum PtDraw {
    private static var dots: [Int: CGImage] = [:]
    private static var adapt: Double = 1
    private static var tinted: [String: CGImage] = [:]
    /// Cell image pre-tinted with a 4-bit colour (a clip-mask per particle is far slower than one cached draw).
    private static func tintedCell(_ im: CGImage, _ key: String, _ r: Int, _ g: Int, _ b: Int) -> CGImage? {
        let k = "\(key)|\(r)\(g)\(b)"
        lock.lock(); if let t = tinted[k] { lock.unlock(); return t }; lock.unlock()
        let w = im.width, h = im.height
        guard let c = CGContext(data: nil, width: w, height: h, bitsPerComponent: 8, bytesPerRow: 0, space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return nil }
        let rc = CGRect(x: 0, y: 0, width: w, height: h)
        c.clip(to: rc, mask: im)
        c.setFillColor(red: CGFloat(r) / 15, green: CGFloat(g) / 15, blue: CGFloat(b) / 15, alpha: 1); c.fill(rc)
        let out = c.makeImage()
        lock.lock(); if tinted.count > 500 { tinted.removeAll() }; tinted[k] = out; lock.unlock()
        return out
    }
    private static let lock = NSLock()

    @inline(__always) private static func smooth(_ e0: Float, _ e1: Float, _ x: Float) -> Float {
        if e1 <= e0 { return x < e0 ? 0 : 1 }
        let t = min(1, max(0, (x - e0) / (e1 - e0)))
        return t * t * (3 - 2 * t)
    }

    /// Soft round sprite tinted with `rgb` (5 bits per channel) — falloff matches the fragment shader (`soft` 0…5 buckets).
    private static func dot(_ r: Int, _ g: Int, _ b: Int, _ soft: Int) -> CGImage? {
        let key = ((r * 32 + g) * 32 + b) * 8 + soft
        lock.lock(); if let d = dots[key] { lock.unlock(); return d }; lock.unlock()
        let s = CGFloat(soft) / 5, r0 = (1 - s) * 0.47
        let f = UIGraphicsImageRendererFormat(); f.scale = 1; f.opaque = false
        let col = UIColor(red: CGFloat(r) / 31, green: CGFloat(g) / 31, blue: CGFloat(b) / 31, alpha: 1)
        let img = UIGraphicsImageRenderer(size: CGSize(width: 40, height: 40), format: f).image { ctx in
            let c = ctx.cgContext
            let stops: [CGFloat] = [0, 0.25, 0.5, 0.75, 1], al: [CGFloat] = [1, 0.84, 0.5, 0.16, 0]
            let cols = al.map { col.withAlphaComponent($0).cgColor } as CFArray
            let loc = stops.map { r0 * 2 + (1 - r0 * 2) * $0 }
            let gr = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: cols, locations: loc.map { min(1, $0) })!
            c.drawRadialGradient(gr, startCenter: CGPoint(x: 20, y: 20), startRadius: 0, endCenter: CGPoint(x: 20, y: 20), endRadius: 20, options: [])
        }.cgImage
        lock.lock(); if dots.count > 700 { dots.removeAll() }; dots[key] = img; lock.unlock()
        return img
    }

    /// Draws the field into `c` (a `size`-sized area). `col` returns RGBA components of a colour parameter.
    static func render(_ c: CGContext, size: CGSize, g: (String) -> Float, col: (String, UInt32) -> [CGFloat],
                       time: Float, cam: PtProject, layerOpacity: Float = 1, cap: Int = 2200, compH: CGFloat = 1920, adaptive: Bool = false) {
        let t0 = CFAbsoluteTimeGetCurrent()
        defer { if adaptive {   // keep the viewport smooth: shed particles when a frame is slow, win them back when fast
            let ms = (CFAbsoluteTimeGetCurrent() - t0) * 1000
            lock.lock(); adapt = ms > 14 ? max(0.2, adapt * 0.8) : (ms < 6 ? min(1, adapt * 1.08) : adapt); lock.unlock() } }
        lock.lock(); let ad = adaptive ? adapt : 1; lock.unlock()
        let hasSprite = PtSprites.set(g) != nil
        let cap = max(120, Int(Double(cap) * Double(ad) * (hasSprite ? 0.45 : 1.0)))
        let step = max(1, ParticularSim.total(g) / cap)
        let field = ParticularSim.field(g, t: time, step: step)
        let stride = 1
        let fd = ParticularSim.fades(g), fin = fd.0, fout = fd.1
        let op = g("ptOpacity") * layerOpacity, psz = g("ptSize")
        let grad = PtGradient.active(g), byRand = g("ptGrBy") >= 0.5
        let ca = col("ptColA", ParticularSim.defA), cb = col("ptColB", ParticularSim.defB)
        let sprite = PtSprites.set(g), tint = g("ptSpriteTint"), anim = g("ptSpriteAnim") >= 0.5, imgCol = CGFloat(g("ptImgColor"))
        let emT = Int(g("ptEmType").rounded()), useImgCol = emT == 13 || emT == 14
        let minPx = 4 * size.height / compH
        let glow = g("ptGlow"), glowSize = g("ptGlowSize")

        struct Item { var x: CGFloat; var y: CGFloat; var depth: Float; var ps: CGFloat; var q: Particle }
        var list: [Item] = []
        list.reserveCapacity(field.count / stride + 1)
        for (i, q) in field.enumerated() where i % stride == 0 {
            guard let p = cam(q.x, q.y, q.z) else { continue }
            let ps = max(minPx, CGFloat(psz * Float(size.height) * 0.5 * q.size * p.k * (1 + q.soft * 0.35)))
            list.append(Item(x: p.x, y: p.y, depth: p.depth, ps: ps, q: q))
        }
        list.sort { $0.depth > $1.depth }
        for it in list {
            let q = it.q
            let life = min(max(q.life, 0), 1)
            let fade = smooth(0, fin, life) * (1 - smooth(1 - fout, 1, life))
            var rgba: [CGFloat]
            if let gr = grad {
                let v = PtGradient.eval(gr, byRand ? q.vari : life)
                rgba = [CGFloat(v.x), CGFloat(v.y), CGFloat(v.z), CGFloat(v.w)]
            } else {
                let l = CGFloat(life)
                rgba = (0..<4).map { ca[$0] + (cb[$0] - ca[$0]) * l }
            }
            if useImgCol && imgCol > 0 {
                rgba[0] += (CGFloat(q.cr) - rgba[0]) * imgCol; rgba[1] += (CGFloat(q.cg) - rgba[1]) * imgCol; rgba[2] += (CGFloat(q.cb) - rgba[2]) * imgCol
            }
            let a = CGFloat(fade * op * q.alpha) * rgba[3]
            if a < 0.004 { continue }
            let r = CGRect(x: -it.ps / 2, y: -it.ps / 2, width: it.ps, height: it.ps)
            c.saveGState()
            c.translateBy(x: it.x, y: it.y)
            if glow > 0.001, let d5 = dot(Int(min(1, max(0, rgba[0])) * 31 + 0.5), Int(min(1, max(0, rgba[1])) * 31 + 0.5), Int(min(1, max(0, rgba[2])) * 31 + 0.5), 5) {
                let big = it.ps * CGFloat(1 + glowSize)
                c.setAlpha(min(1, a * CGFloat(glow) * 0.5)); c.draw(d5, in: CGRect(x: -big / 2, y: -big / 2, width: big, height: big)); c.setAlpha(1)
            }
            if let sp = sprite, sp.cells > 0 {
                c.rotate(by: CGFloat(q.rot)); c.scaleBy(x: 1, y: -1)
                let idx = min(sp.cells - 1, Int(floor(anim ? Double(min(life, 0.999)) * Double(sp.cells) : Double(q.vari) * Double(sp.cells))))
                if idx >= 0 && idx < sp.cellImages.count {
                    if tint > 0.5 {
                        let q4 = { (v: CGFloat) in Int(min(1, max(0, v)) * 15 + 0.5) }
                        if let ti = tintedCell(sp.cellImages[idx], "\(sp.key)#\(idx)", q4(rgba[0]), q4(rgba[1]), q4(rgba[2])) { c.setAlpha(min(1, a)); c.draw(ti, in: r) }
                    } else {
                        c.setAlpha(min(1, a)); c.draw(sp.cellImages[idx], in: r)
                    }
                }
            } else {
                let rr = Int(min(1, max(0, rgba[0])) * 31 + 0.5), gg = Int(min(1, max(0, rgba[1])) * 31 + 0.5), bb = Int(min(1, max(0, rgba[2])) * 31 + 0.5)
                if let d = dot(rr, gg, bb, Int(min(5, q.soft * 5 + 0.5))) {
                    c.setAlpha(min(1, a))
                    let e = r.insetBy(dx: -it.ps * 0.02, dy: -it.ps * 0.02)
                    c.draw(d, in: e)
                }
            }
            c.restoreGState()
        }
    }

    /// Free orbit camera (also the preset-thumbnail camera). Sizes use the real camera's size law (3 / depth).
    static func orbit(yaw: CGFloat, pitch: CGFloat, dist: CGFloat, fovDeg: Float, size: CGSize) -> PtProject {
        let cy = cos(yaw), sy = sin(yaw), cp = cos(pitch), sp = sin(pitch)
        let f = 1 / CGFloat(tan(fovDeg * Float.pi / 360))
        return { x, y, z in
            let X = CGFloat(x), Y = CGFloat(y), Z = CGFloat(z)
            let x1 = X * cy + Z * sy, z1 = -X * sy + Z * cy
            let y2 = Y * cp - z1 * sp, z2 = Y * sp + z1 * cp
            let d = dist - z2
            if d < 0.2 { return nil }
            let k = size.height * 0.5 * f / d
            return (size.width / 2 + x1 * k, size.height / 2 - y2 * k, Float(3 / d), Float(d))
        }
    }

    /// The real comp camera: layer transform, layer rotation / depth and the comp view-projection (same steps as MetalParticleRenderer.draw).
    static func comp(vp: [Float], m: [Float], layerZ: Float, rotXDeg: Float, rotYDeg: Float, use3D: Bool, aspect: Float, size: CGSize) -> PtProject {
        let pd = Float.pi / 180
        let prx = rotXDeg * pd, pry = -rotYDeg * pd
        let pcx = cos(prx), psx = sin(prx), pcy = cos(pry), psy = sin(pry)
        let pRot = prx != 0 || pry != 0
        return { x0, y0, z0 in
            var x = x0, y = y0, z = z0
            if pRot {
                let x1 = x * pcy + z * psy, z1 = -x * psy + z * pcy
                let y2 = y * pcx - z1 * psx, z2 = y * psx + z1 * pcx
                x = x1; y = y2; z = z2
            }
            z += layerZ
            var wx = m[0] * x + m[2] * y + m[4], wy = m[1] * x + m[3] * y + m[5]
            var nx: Float, ny: Float, k: Float, depth: Float
            if use3D {
                let cx = vp[0] * wx + vp[4] * wy + vp[8] * z + vp[12]
                let cy = vp[1] * wx + vp[5] * wy + vp[9] * z + vp[13]
                let cw = vp[3] * wx + vp[7] * wy + vp[11] * z + vp[15]
                if cw <= 0.05 { return nil }
                nx = cx / max(abs(cw), 0.0001); ny = cy / max(abs(cw), 0.0001); k = 3 / max(cw, 0.05); depth = cw
            } else {
                let pf = 1 / max(0.2, 1 - z / 3)
                wx *= pf; wy *= pf
                nx = wx / aspect; ny = wy; k = pf; depth = 1 / pf
            }
            return (CGFloat(nx * 0.5 + 0.5) * size.width, CGFloat(0.5 - ny * 0.5) * size.height, k, depth)
        }
    }
}

// MARK: - Thumbnails (a real render of the particle, cached)

enum PtThumb {
    private static var cache: [String: UIImage] = [:]
    private static let lock = NSLock()
    private static let queue = DispatchQueue(label: "saiki.pt.thumb", qos: .utility)

    static func cached(_ key: String) -> UIImage? { lock.lock(); defer { lock.unlock() }; return cache[key] }

    static func color(_ d: [String: Float], _ pre: String = "") -> (String, UInt32) -> [CGFloat] {
        return { k, _ in ["_r", "_g", "_b", "_a"].map { CGFloat(d[pre + k + $0] ?? PtParams.def(pre + k + $0)) } }
    }

    static func render(_ params: [String: Float], time: Float, yaw: CGFloat = 0.25, pitch: CGFloat = 0.12, dist: CGFloat = 3.3, size: CGFloat = 96) -> UIImage {
        let S: CGFloat = 420
        let f = UIGraphicsImageRendererFormat(); f.scale = 2; f.opaque = true
        return UIGraphicsImageRenderer(size: CGSize(width: size, height: size), format: f).image { r in
            let c = r.cgContext
            c.scaleBy(x: size / S, y: size / S)
            c.setFillColor(UIColor(white: 0.03, alpha: 1).cgColor); c.fill(CGRect(x: 0, y: 0, width: S, height: S))
            let g = PtParams.reader(params)
            let n = PtGroup.count(g)
            for gi in 0..<n {
                PtDraw.render(c, size: CGSize(width: S, height: S), g: PtGroup.reader(g, gi), col: color(params, PtGroup.pre(gi)), time: time,
                              cam: PtDraw.orbit(yaw: yaw, pitch: pitch, dist: dist, fovDeg: 55, size: CGSize(width: S, height: S)), cap: 450 / n, compH: 1000)
            }
        }
    }

    /// Renders on a background queue; `done` runs on main. Same key → cached image.
    static func make(_ key: String, _ params: [String: Float], time: Float, yaw: CGFloat = 0.25, pitch: CGFloat = 0.12, dist: CGFloat = 3.3, _ done: @escaping (UIImage) -> Void) {
        if let i = cached(key) { done(i); return }
        queue.async {
            let img = render(params, time: time, yaw: yaw, pitch: pitch, dist: dist)
            lock.lock(); cache[key] = img; lock.unlock()
            DispatchQueue.main.async { done(img) }
        }
    }

    /// Params for a small "what does this emitter look like" snapshot.
    static func emitterParams(_ type: Int) -> [String: Float] {
        var p: [String: Float] = ["ptEmType": Float(type), "ptBehavior": 1, "ptVel": 0, "ptLife": 2, "ptRate": 260, "ptSize": 0.03, "ptSoft": 0.3,
                                  "ptSizeX": 0.6, "ptSizeY": 0.6, "ptSizeZ": 0.6, "ptFadeIn": 0.001, "ptFadeOut": 0.001, "ptSizeRand": 0.2, "ptSwirl": 0, "ptGravity": 0, "ptTurb": 0]
        if type == 9 { p["ptSizeY"] = 0.22 }
        if type == 6 { p["ptSizeX"] = 0.8 }
        if type == 0 { p["ptSize"] = 0.05; p["ptRate"] = 40 }
        p.merge(PtParams.color("ptColA", 0xFFFFFFFF)) { $1 }; p.merge(PtParams.color("ptColB", 0xFF9DDCFF)) { $1 }
        return p
    }
}
