// Full-screen physics (pendulum) editor: live chain preview on top, one card per pendulum below,
// add / delete pendulums, plus the shared "augmented physics" settings (inertia + tilt follow).

import UIKit

/// Draws the pendulum chain live from the real simulation.
private final class ChainPreview: UIView {
    var group: Layer!, rig: Rig!, pg: PhysGroup!
    private var link: CADisplayLink?
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = argbToUIColor(C.CARD2); layer.cornerRadius = 12; clipsToBounds = true
    }
    required init?(coder: NSCoder) { fatalError() }
    func start() { link?.invalidate(); link = CADisplayLink(target: self, selector: #selector(tick)); link?.add(to: .main, forMode: .common) }
    func stop() { link?.invalidate(); link = nil }
    @objc private func tick() { Rig.liveActive = true; setNeedsDisplay() }
    override func draw(_ rect: CGRect) {
        guard let ctx = UIGraphicsGetCurrentContext(), let g = group, let r = rig, let pg = pg else { return }
        _ = pg.angles(g, r, Editor.time)
        let a = pg.lastRaw
        var p = CGPoint(x: bounds.midX, y: 24), ang: CGFloat = 0
        let seg = min(70, (bounds.height - 40) / CGFloat(a.count))
        ctx.setStrokeColor(argbToUIColor(C.GREEN).cgColor); ctx.setLineWidth(3)
        ctx.setFillColor(argbToUIColor(C.TEXT).cgColor)
        ctx.fillEllipse(in: CGRect(x: p.x - 5, y: p.y - 5, width: 10, height: 10))
        for v in a {
            ang += CGFloat(v)
            let q = CGPoint(x: p.x + sin(ang) * seg, y: p.y + cos(ang) * seg)
            ctx.move(to: p); ctx.addLine(to: q); ctx.strokePath()
            ctx.fillEllipse(in: CGRect(x: q.x - 6, y: q.y - 6, width: 12, height: 12))
            p = q
        }
    }
}

final class PhysicsScreenViewController: UIViewController {
    var pushUndo: () -> Void = {}
    var onChange: () -> Void = {}
    private let group: Layer, rig: Rig, pg: PhysGroup
    private let preview = ChainPreview(frame: .zero)
    private let stack = UIStackView()

    init(group: Layer, rig: Rig, pg: PhysGroup) { self.group = group; self.rig = rig; self.pg = pg; super.init(nibName: nil, bundle: nil) }
    required init?(coder: NSCoder) { fatalError() }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = argbToUIColor(C.BG)
        let title = UILabel(); title.text = "Physics — \(pg.name)"; title.textColor = argbToUIColor(C.TEXT); title.font = .boldSystemFont(ofSize: 18)
        let close = bar("Done") { [weak self] in self?.dismiss(animated: true) { self?.onChange() } }
        let add = bar("＋ Pendulum") { [weak self] in
            guard let self = self else { return }
            self.pushUndo(); self.pg.pends.append(PhysPend()); self.rebuild(); self.onChange()
        }
        let top = UIStackView(arrangedSubviews: [title, UIView(), add, close]); top.spacing = 10; top.alignment = .center
        preview.group = group; preview.rig = rig; preview.pg = pg
        let scroll = UIScrollView()
        stack.axis = .vertical; stack.spacing = 12
        for v in [top, preview, scroll] as [UIView] { v.translatesAutoresizingMaskIntoConstraints = false; view.addSubview(v) }
        stack.translatesAutoresizingMaskIntoConstraints = false; scroll.addSubview(stack)
        let g = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            top.topAnchor.constraint(equalTo: g.topAnchor, constant: 8), top.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 16), top.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -16),
            preview.topAnchor.constraint(equalTo: top.bottomAnchor, constant: 10), preview.leadingAnchor.constraint(equalTo: top.leadingAnchor), preview.trailingAnchor.constraint(equalTo: top.trailingAnchor),
            preview.heightAnchor.constraint(equalTo: g.heightAnchor, multiplier: 0.3),
            scroll.topAnchor.constraint(equalTo: preview.bottomAnchor, constant: 10), scroll.leadingAnchor.constraint(equalTo: g.leadingAnchor), scroll.trailingAnchor.constraint(equalTo: g.trailingAnchor), scroll.bottomAnchor.constraint(equalTo: g.bottomAnchor),
            stack.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor), stack.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor, constant: -24),
            stack.leadingAnchor.constraint(equalTo: scroll.frameLayoutGuide.leadingAnchor, constant: 16), stack.trailingAnchor.constraint(equalTo: scroll.frameLayoutGuide.trailingAnchor, constant: -16)])
        rebuild()
    }
    override func viewDidAppear(_ a: Bool) { super.viewDidAppear(a); preview.start() }
    override func viewWillDisappear(_ a: Bool) { super.viewWillDisappear(a); preview.stop() }

    private func bar(_ t: String, _ act: @escaping () -> Void) -> UIButton {
        let b = UIButton(type: .system); b.setTitle(t, for: .normal)
        b.backgroundColor = argbToUIColor(C.GREEN); b.setTitleColor(argbToUIColor(C.BG), for: .normal)
        b.titleLabel?.font = .boldSystemFont(ofSize: 15); b.layer.cornerRadius = 10
        b.contentEdgeInsets = UIEdgeInsets(top: 8, left: 12, bottom: 8, right: 12)
        b.addAction(UIAction { _ in act() }, for: .touchUpInside); return b
    }

    private func slider(_ name: String, _ lo: Float, _ hi: Float, _ v: Float, _ set: @escaping (Float) -> Void) -> UIView {
        let l = UILabel(); l.textColor = argbToUIColor(C.TEXT); l.font = .systemFont(ofSize: 13)
        func txt(_ x: Float) { l.text = "\(name): \(String(format: "%.2f", x))" }
        txt(v)
        let s = UISlider(); s.minimumValue = lo; s.maximumValue = hi; s.value = v; s.tintColor = argbToUIColor(C.GREEN)
        s.addAction(UIAction { [weak self, unowned s] _ in set(s.value); txt(s.value); Rig.liveActive = true; self?.onChange() }, for: .valueChanged)
        s.addAction(UIAction { [weak self] _ in self?.pushUndo() }, for: .touchDown)
        let st = UIStackView(arrangedSubviews: [l, s]); st.axis = .vertical; st.spacing = 2; return st
    }

    private func card(_ title: String, _ rows: [UIView]) -> UIView {
        let t = UILabel(); t.text = title; t.textColor = argbToUIColor(C.GREEN); t.font = .boldSystemFont(ofSize: 15)
        let st = UIStackView(arrangedSubviews: [t] + rows); st.axis = .vertical; st.spacing = 10
        st.isLayoutMarginsRelativeArrangement = true; st.layoutMargins = UIEdgeInsets(top: 12, left: 12, bottom: 12, right: 12)
        let c = UIView(); c.backgroundColor = argbToUIColor(C.CARD2); c.layer.cornerRadius = 12
        st.translatesAutoresizingMaskIntoConstraints = false; c.addSubview(st)
        NSLayoutConstraint.activate([st.topAnchor.constraint(equalTo: c.topAnchor), st.bottomAnchor.constraint(equalTo: c.bottomAnchor),
                                     st.leadingAnchor.constraint(equalTo: c.leadingAnchor), st.trailingAnchor.constraint(equalTo: c.trailingAnchor)])
        return c
    }

    private func rebuild() {
        stack.arrangedSubviews.forEach { $0.removeFromSuperview() }
        let q = pg
        stack.addArrangedSubview(card("Pendulum 1", [
            slider("Duration (short = snappy)", 0.1, 2, q.length) { q.length = $0 },
            slider("Reaction", 0, 1, q.reaction) { q.reaction = $0 },
            slider("Damping", 0, 1, q.damping) { q.damping = $0 }]))
        for (i, pd) in q.pends.enumerated() {
            let del = UIButton(type: .system); del.setTitle("Delete pendulum \(i + 2)", for: .normal)
            del.setTitleColor(argbToUIColor(C.TEXT), for: .normal)
            del.addAction(UIAction { [weak self] _ in
                guard let self = self else { return }
                self.pushUndo(); q.pends.remove(at: i)
                for o in q.outs { if o.pend == i + 1 { o.pend = 0 } else if o.pend > i + 1 { o.pend -= 1 } }
                self.rebuild(); self.onChange() }, for: .touchUpInside)
            stack.addArrangedSubview(card("Pendulum \(i + 2) — hangs from \(i + 1)", [
                slider("Duration", 0.1, 2, pd.length) { pd.length = $0 },
                slider("Reaction", 0, 1, pd.reaction) { pd.reaction = $0 },
                slider("Damping", 0, 1, pd.damping) { pd.damping = $0 }, del]))
        }
        stack.addArrangedSubview(card("Augmented physics (whole chain)", [
            slider("Tilt follow (0 = inertia only)", 0, 1, q.follow) { q.follow = $0 },
            slider("Inertia (input gain)", 0, 4, q.strength) { q.strength = $0 },
            slider("Ease of swinging", 0.5, 0.99, q.ease) { q.ease = $0 },
            slider("Gravity (pull to rest)", 0.1, 3, q.gravity) { q.gravity = $0 },
            slider("Max angle (°)", 5, 90, q.maxDeg) { q.maxDeg = $0 },
            slider("Input delay (s)", 0, 0.5, q.delay) { q.delay = $0 }]))
    }
}
