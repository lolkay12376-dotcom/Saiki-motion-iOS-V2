// PreviewView.swift — the GL preview surface (UI).
//
// A GLKView with its own GLES context that renders the scene through
// SceneRenderer every time the editor asks (requestDraw). It also serves as
// the VideoSource: video layers get their frames from per-layer async
// samplers, and an arriving frame schedules the next draw.

import UIKit
import OpenGLES
import GLKit

final class PreviewView: GLKView, VideoSource {

    var quality = 1 {
        didSet { setNeedsDisplay() }
    }

    private var renderer: SceneRenderer?
    /// Metal overlay (stage 4): shown only for frames MetalSceneRenderer can render; GL draws the rest.
    private let metalView = MetalPreviewView()
    private var samplers: [Int: VideoFrames.Sampler] = [:]

    init() {
        let ctx = GLContext.make() ?? EAGLContext(api: .openGLES2)!
        super.init(frame: .zero, context: ctx)
        drawableColorFormat = .RGBA8888
        drawableDepthFormat = .formatNone
        drawableStencilFormat = .formatNone
        drawableMultisample = .multisampleNone
        enableSetNeedsDisplay = true
        isOpaque = true
        backgroundColor = UIColor.black
        contentMode = .redraw
        addSubview(metalView)
        MetalSceneRenderer.onVideoFrame = { [weak self] in self?.setNeedsDisplay() }
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    /// Kotlin: preview.onResume() — GLKView has no pause; redraw instead.
    func requestDraw() {
        setNeedsDisplay()
    }

    /// Kotlin: preview.onPause() — drop the async video samplers.
    func releaseVideos() {
        samplers.removeAll()
        MetalSceneRenderer.shared?.releaseVideos()
    }

    /// Memory warning: also drop the cached image-layer textures (they reload on demand).
    func trimMemory() {
        samplers.removeAll()
        MetalSceneRenderer.shared?.trimMemory()
        if let ctx = context as? EAGLContext {
            EAGLContext.setCurrent(ctx)
            renderer?.trimMemory()
        }
    }

    /// Identity of a cached frame: view size + quality.
    var cacheKey: (Int, Int, Int) { (Int(bounds.width), Int(bounds.height), quality) }

    /// Renders one frame at `t` straight into the frame cache, off screen: the picture on
    /// screen, Editor.time and the playhead are not touched. Used by the idle live cache.
    func cacheFrame(at t: Float) -> Bool {
        guard let ctx = context as? EAGLContext, bounds.width > 1, bounds.height > 1 else { return false }
        if RenderBackend.useMetal || RenderBackend.needsMetal(Editor.scene),
           let img = MetalSceneRenderer.thumbnail(project: Editor.project, scene: Editor.scene, time: t, quality: quality) {
            let k = cacheKey
            FrameCache.store(Editor.project.id, k.0, k.1, k.2, t, img)
            return true
        }
        EAGLContext.setCurrent(ctx)
        if renderer == nil { renderer = SceneRenderer(context: ctx); SceneRenderer.gizmoSource = renderer }
        guard let renderer = renderer else { return false }
        renderer.quality = quality
        _ = renderer.draw(project: Editor.project, scene: Editor.scene, time: t, video: nil)
        guard let img = renderer.snapshot() else { return false }
        let k = cacheKey
        FrameCache.store(Editor.project.id, k.0, k.1, k.2, t, img)
        return true
    }

    /// Bakes frame `idx` of a pre-rendered group into the pre-render cache (off screen).
    func warm(_ path: String) {
        guard let ctx = context as? EAGLContext else { return }
        EAGLContext.setCurrent(ctx)
        if renderer == nil { renderer = SceneRenderer(context: ctx); SceneRenderer.gizmoSource = renderer }
        renderer?.warm(path)
    }

    func preRenderFrame(_ g: Layer, idx: Int) -> Bool {
        guard let ctx = context as? EAGLContext, bounds.width > 1, bounds.height > 1 else { return false }
        EAGLContext.setCurrent(ctx)
        if renderer == nil { renderer = SceneRenderer(context: ctx); SceneRenderer.gizmoSource = renderer }
        guard let renderer = renderer else { return false }
        renderer.quality = quality
        return renderer.preRenderFrame(g, idx: idx, project: Editor.project, scene: Editor.scene, video: nil)
    }

    // Adaptive preview quality: while playing, if frames take too long (many effects, 4K video) the preview
    // renders at lower resolution; it goes back to full quality when playback stops or the load drops.
    private var govLevel = 0, govLast = 0.0, govSlow = 0, govFast = 0
    private var govQuality: Int { quality + govLevel }
    private func govern() {
        guard FrameCache.playing else {
            if govLevel != 0 { govLevel = 0; govSlow = 0; govFast = 0; DispatchQueue.main.async { [weak self] in self?.setNeedsDisplay() } }
            govLast = 0
            return
        }
        let now = CACurrentMediaTime(), dt = now - govLast
        govLast = now
        guard dt > 0, dt < 0.5 else { return }
        let target = 1.0 / Double(max(1, min(Editor.project.fps, 30)))
        if dt > target * 1.5 { govSlow += 1; govFast = 0 } else if dt < target * 1.15 { govFast += 1; govSlow = 0 }
        if govSlow >= 4 && govLevel < 2 { govLevel += 1; govSlow = 0 }
        if govFast >= 120 && govLevel > 0 { govLevel -= 1; govFast = 0 }
    }

    override func draw(_ rect: CGRect) {
        guard let ctx = context as? EAGLContext else { return }
        govern()
        // Not laid out yet (0x0 drawable) — drawing now would just fail.
        guard bounds.width > 1, bounds.height > 1 else { return }
        // Metal path (flag on + every layer/effect of this frame supported): present there, skip GL.
        if RenderBackend.useMetal || RenderBackend.needsMetal(Editor.scene),
           metalView.render(project: Editor.project, scene: Editor.scene, time: Editor.time, quality: govQuality) {
            metalView.isHidden = false
            return
        }
        metalView.isHidden = true
        EAGLContext.setCurrent(ctx)
        if renderer == nil {
            renderer = SceneRenderer(context: ctx)
        }
        guard let renderer = renderer else { return }
        SceneRenderer.gizmoSource = renderer      // 3D gizmo projects through this exact renderer
        renderer.quality = govQuality
        // Frames with real-time physics must never come from the cache: a cached frame skips Rig.apply, so nothing sways.
        let useCache = FrameCache.enabled && (FrameCache.playing || FrameCache.scrubbing) && !Rig.hasLivePhysics(Editor.scene.layers)
        let pid = Editor.project.id
        if useCache {
            let sw = Int(bounds.width), sh = Int(bounds.height)
            if let img = FrameCache.lookup(pid, sw, sh, quality, Editor.time),
               let ctex = Gl.upload(img) {
                bindDrawable()
                glViewport(0, 0, GLsizei(drawableWidth), GLsizei(drawableHeight))
                glDisable(GLenum(GL_BLEND))
                glClearColor(0, 0, 0, 1)
                glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
                renderer.present(ctex, flipY: true)
                Gl.delete(ctex)
                return
            }
        }
        let t0 = CACurrentMediaTime()
        let tex = renderer.draw(project: Editor.project, scene: Editor.scene,
                                time: Editor.time, video: self)
        // Only frames that were slow to build are worth caching; reading back cheap
        // frames costs more than re-rendering them (this was causing playback lag).
        if useCache && govLevel == 0 && CACurrentMediaTime() - t0 > 0.012 {
            let sw = Int(bounds.width), sh = Int(bounds.height)
            if !FrameCache.has(pid, sw, sh, quality, Editor.time), let img = renderer.snapshot() {
                FrameCache.store(pid, sw, sh, quality, Editor.time, img)
            }
        }

        // present: blit the scene texture into the drawable.
        // A GLKView's drawable is NOT framebuffer 0 — binding 0 draws into
        // nothing (the blank viewport). bindDrawable() binds the real one.
        bindDrawable()
        glViewport(0, 0, GLsizei(drawableWidth), GLsizei(drawableHeight))
        glDisable(GLenum(GL_BLEND))
        glClearColor(0, 0, 0, 1)
        glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
        renderer.present(tex)
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        metalView.frame = bounds
        setNeedsDisplay()
    }

    // MARK: - VideoSource

    func videoTexture(layerId: Int, path: String, srcTime: Float) -> GLuint {
        if let s = samplers[layerId] {
            return s.texture(at: srcTime)
        }
        let s = VideoFrames.Sampler(path: path)
        s.onUploaded = { [weak self] in
            self?.setNeedsDisplay()
        }
        samplers[layerId] = s
        return s.texture(at: srcTime)
    }

    func videoFrameArrived() -> Bool {
        false
    }
}
