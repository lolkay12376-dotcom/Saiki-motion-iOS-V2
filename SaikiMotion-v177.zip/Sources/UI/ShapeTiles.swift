// ShapeTiles.swift — shape picker grid with real shape previews (UI).
import UIKit

enum ShapeGlyph {
    /// Outline of a shape kind inside `r` (preview only; the renderer draws the real shape).
    static func path(_ k: ShapeKind, _ r: CGRect, round: CGFloat = 0.12) -> UIBezierPath {
        let cx = r.midX, cy = r.midY, w = r.width, h = r.height, m = min(w, h) / 2
        func poly(_ n: Int, _ rot: CGFloat = -.pi / 2) -> UIBezierPath {
            let p = UIBezierPath()
            for i in 0..<n {
                let a = rot + CGFloat(i) * 2 * .pi / CGFloat(n)
                let pt = CGPoint(x: cx + cos(a) * m, y: cy + sin(a) * m)
                i == 0 ? p.move(to: pt) : p.addLine(to: pt)
            }
            p.close(); return p
        }
        switch k {
        case .RECT: return UIBezierPath(rect: r)
        case .ROUND: return UIBezierPath(roundedRect: r, cornerRadius: min(m * 0.9, max(2, round * m * 2.5)))
        case .CIRCLE: return UIBezierPath(ovalIn: CGRect(x: cx - m, y: cy - m, width: m * 2, height: m * 2))
        case .ELLIPSE: return UIBezierPath(ovalIn: r)
        case .TRIANGLE:
            let p = UIBezierPath(); p.move(to: CGPoint(x: r.minX, y: r.maxY)); p.addLine(to: CGPoint(x: r.maxX, y: r.maxY))
            p.addLine(to: CGPoint(x: cx, y: r.minY)); p.close(); return p
        case .DIAMOND: return poly(4)
        case .PENTAGON: return poly(5)
        case .HEXAGON: return poly(6)
        case .OCTAGON: return poly(8, -.pi / 2 + .pi / 8)
        case .PATH: return UIBezierPath(rect: r)
        case .STAR:
            let p = UIBezierPath()
            for i in 0..<10 {
                let a = -CGFloat.pi / 2 + CGFloat(i) * .pi / 5, rad = i % 2 == 0 ? m : m * 0.45
                let pt = CGPoint(x: cx + cos(a) * rad, y: cy + sin(a) * rad)
                i == 0 ? p.move(to: pt) : p.addLine(to: pt)
            }
            p.close(); return p
        case .ARROW:
            let p = UIBezierPath()
            let pts: [(CGFloat, CGFloat)] = [(0, 0.32), (0.6, 0.32), (0.6, 0.05), (1, 0.5), (0.6, 0.95), (0.6, 0.68), (0, 0.68)]
            for (i, q) in pts.enumerated() {
                let pt = CGPoint(x: r.minX + q.0 * w, y: r.minY + q.1 * h)
                i == 0 ? p.move(to: pt) : p.addLine(to: pt)
            }
            p.close(); return p
        case .CHEVRON:
            let p = UIBezierPath()
            let pts: [(CGFloat, CGFloat)] = [(0, 0), (0.55, 0), (1, 0.5), (0.55, 1), (0, 1), (0.45, 0.5)]
            for (i, q) in pts.enumerated() {
                let pt = CGPoint(x: r.minX + q.0 * w, y: r.minY + q.1 * h)
                i == 0 ? p.move(to: pt) : p.addLine(to: pt)
            }
            p.close(); return p
        case .PLUS:
            let p = UIBezierPath()
            let pts: [(CGFloat, CGFloat)] = [(0.33, 0), (0.67, 0), (0.67, 0.33), (1, 0.33), (1, 0.67), (0.67, 0.67),
                                             (0.67, 1), (0.33, 1), (0.33, 0.67), (0, 0.67), (0, 0.33), (0.33, 0.33)]
            for (i, q) in pts.enumerated() {
                let pt = CGPoint(x: r.minX + q.0 * w, y: r.minY + q.1 * h)
                i == 0 ? p.move(to: pt) : p.addLine(to: pt)
            }
            p.close(); return p
        case .HEART:
            let p = UIBezierPath()
            p.move(to: CGPoint(x: cx, y: r.maxY))
            p.addCurve(to: CGPoint(x: r.minX, y: r.minY + h * 0.32), controlPoint1: CGPoint(x: cx - w * 0.15, y: r.maxY - h * 0.15), controlPoint2: CGPoint(x: r.minX, y: cy + h * 0.1))
            p.addCurve(to: CGPoint(x: cx, y: r.minY + h * 0.28), controlPoint1: CGPoint(x: r.minX, y: r.minY - h * 0.05), controlPoint2: CGPoint(x: cx - w * 0.1, y: r.minY))
            p.addCurve(to: CGPoint(x: r.maxX, y: r.minY + h * 0.32), controlPoint1: CGPoint(x: cx + w * 0.1, y: r.minY), controlPoint2: CGPoint(x: r.maxX, y: r.minY - h * 0.05))
            p.addCurve(to: CGPoint(x: cx, y: r.maxY), controlPoint1: CGPoint(x: r.maxX, y: cy + h * 0.1), controlPoint2: CGPoint(x: cx + w * 0.15, y: r.maxY - h * 0.15))
            p.close(); return p
        case .RING:
            let p = UIBezierPath(ovalIn: CGRect(x: cx - m, y: cy - m, width: m * 2, height: m * 2))
            p.append(UIBezierPath(ovalIn: CGRect(x: cx - m * 0.55, y: cy - m * 0.55, width: m * 1.1, height: m * 1.1)))
            p.usesEvenOddFillRule = true; return p
        }
    }
}

final class ShapeTile: UIControl {
    let kind: ShapeKind
    var chosen = false { didSet { setNeedsDisplay() } }
    var onPick: ((ShapeKind) -> Void)?
    init(_ k: ShapeKind, chosen: Bool) {
        kind = k; self.chosen = chosen
        super.init(frame: .zero)
        backgroundColor = .clear
        addTarget(self, action: #selector(tap), for: .touchUpInside)
    }
    required init?(coder: NSCoder) { fatalError() }
    @objc private func tap() { onPick?(kind) }
    override func draw(_ rect: CGRect) {
        let card = UIBezierPath(roundedRect: bounds.insetBy(dx: 2, dy: 2), cornerRadius: 10)
        argbToUIColor(chosen ? C.GREEN : C.CARD2).setFill(); card.fill()
        let g = ShapeGlyph.path(kind, CGRect(x: 0, y: 0, width: bounds.width, height: bounds.height - 12).insetBy(dx: 14, dy: 12))
        argbToUIColor(chosen ? C.ONDARK : C.TEXT).setFill(); g.fill()
        let s = NSAttributedString(string: kind.title, attributes: [.font: UIFont.systemFont(ofSize: 9, weight: .medium),
                                   .foregroundColor: argbToUIColor(chosen ? C.ONDARK : C.DIM)])
        let sz = s.size(); s.draw(at: CGPoint(x: (bounds.width - sz.width) / 2, y: bounds.height - sz.height - 4))
    }
}

/// Grid of shape tiles (5 per row). `selected` highlights the current shape.
func shapeGrid(selected: ShapeKind?, _ onPick: @escaping (ShapeKind) -> Void) -> UIView {
    let col = UIStackView(); col.axis = .vertical; col.spacing = 4
    let kinds = ShapeKind.allKinds
    for start in stride(from: 0, to: kinds.count, by: 5) {
        let row = UIStackView(); row.axis = .horizontal; row.distribution = .fillEqually; row.spacing = 4
        for k in kinds[start..<min(start + 5, kinds.count)] {
            let t = ShapeTile(k, chosen: k == selected); t.onPick = onPick
            t.heightAnchor.constraint(equalToConstant: 64).isActive = true
            row.addArrangedSubview(t)
        }
        for _ in (min(start + 5, kinds.count) - start)..<5 { row.addArrangedSubview(UIView()) }
        col.addArrangedSubview(row)
    }
    return col
}
