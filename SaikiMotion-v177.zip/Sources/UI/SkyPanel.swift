// SkyPanel.swift — Environment > Custom gradient sky: pick colours, it becomes the lighting / reflection environment AND a visible sky dome.
import UIKit
import simd

final class SkyPanel: UIView {
    private weak var host: EditorViewController?
    private let accent = UIColor(red: 1, green: 0.55, blue: 0.08, alpha: 1)
    private var cols: [UIColor] = [UIColor(red: 0.10, green: 0.25, blue: 0.75, alpha: 1), UIColor(red: 0.45, green: 0.70, blue: 1.0, alpha: 1),
                                   UIColor(red: 1.0, green: 0.75, blue: 0.50, alpha: 1), UIColor(red: 0.20, green: 0.18, blue: 0.16, alpha: 1)]
    private var sunOn = true, bright: Float = 2.5
    private let status = UILabel()
    private let names = ["Top (zenith)", "Upper sky", "Horizon", "Ground"]

    static func present(in host: EditorViewController, over view: UIView) {
        if view.subviews.contains(where: { $0 is SkyPanel }) { return }
        let v = SkyPanel(host: host)
        v.translatesAutoresizingMaskIntoConstraints = false; view.addSubview(v)
        NSLayoutConstraint.activate([v.leadingAnchor.constraint(equalTo: view.leadingAnchor), v.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                                     v.topAnchor.constraint(equalTo: view.topAnchor), v.bottomAnchor.constraint(equalTo: view.bottomAnchor)])
    }

    init(host: EditorViewController) {
        self.host = host
        super.init(frame: .zero)
        backgroundColor = UIColor(white: 0, alpha: 0.55)
        build()
    }
    required init?(coder: NSCoder) { fatalError() }

    private func label(_ t: String, _ size: CGFloat = 14, _ w: UIFont.Weight = .regular, _ c: UIColor = .white) -> UILabel {
        let l = UILabel(); l.text = t; l.textColor = c; l.font = .systemFont(ofSize: size, weight: w); return l
    }

    private func build() {
        let card = UIView(); card.backgroundColor = UIColor(white: 0.09, alpha: 1); card.layer.cornerRadius = 22
        card.translatesAutoresizingMaskIntoConstraints = false; addSubview(card)
        let x = UIButton(type: .system); x.setImage(UIImage(systemName: "xmark"), for: .normal); x.tintColor = .white
        x.addAction(UIAction { [weak self] _ in self?.removeFromSuperview() }, for: .touchUpInside)
        var rows: [UIView] = [{ let h = UIStackView(arrangedSubviews: [label("Custom sky", 22, .bold), UIView(), x]); h.alignment = .center; return h }(),
                              label("Four colours blend from the top of the sky down to the ground. It lights and reflects everything 3D and shows as the sky.", 12, .regular, UIColor(white: 0.7, alpha: 1))]
        (rows[1] as? UILabel)?.numberOfLines = 3
        for (i, n) in names.enumerated() {
            let w = UIColorWell(); w.supportsAlpha = false; w.selectedColor = cols[i]
            w.addAction(UIAction { [weak self, weak w] _ in if let c = w?.selectedColor { self?.cols[i] = c } }, for: .valueChanged)
            let r = UIStackView(arrangedSubviews: [label(n), UIView(), w]); r.alignment = .center; rows.append(r)
        }
        let sw = UISwitch(); sw.isOn = sunOn; sw.onTintColor = accent
        sw.addAction(UIAction { [weak self, weak sw] _ in self?.sunOn = sw?.isOn ?? true }, for: .valueChanged)
        rows.append({ let r = UIStackView(arrangedSubviews: [label("Sun glow at the horizon"), UIView(), sw]); r.alignment = .center; return r }())
        let bl = label("Light strength"), val = label(String(format: "%.1f", bright), 12, .regular, UIColor(white: 0.7, alpha: 1))
        let s = UISlider(); s.minimumValue = 0.3; s.maximumValue = 8; s.value = bright; s.tintColor = accent
        s.addAction(UIAction { [weak self, weak s, weak val] _ in guard let s = s else { return }; self?.bright = s.value; val?.text = String(format: "%.1f", s.value) }, for: .valueChanged)
        rows.append({ let r = UIStackView(arrangedSubviews: [bl, s, val]); r.spacing = 8; r.alignment = .center; return r }())
        var c = UIButton.Configuration.filled(); c.title = "Apply sky"; c.baseBackgroundColor = accent; c.baseForegroundColor = .black; c.cornerStyle = .large
        let ap = UIButton(configuration: c); ap.addAction(UIAction { [weak self] _ in self?.apply() }, for: .touchUpInside)
        rows.append(ap)
        status.textColor = UIColor(white: 0.7, alpha: 1); status.font = .systemFont(ofSize: 12); status.numberOfLines = 2; rows.append(status)
        let stack = UIStackView(arrangedSubviews: rows); stack.axis = .vertical; stack.spacing = 12; stack.translatesAutoresizingMaskIntoConstraints = false
        card.addSubview(stack)
        NSLayoutConstraint.activate([
            card.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 12), card.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -12),
            card.centerYAnchor.constraint(equalTo: centerYAnchor),
            stack.leadingAnchor.constraint(equalTo: card.leadingAnchor, constant: 16), stack.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -16),
            stack.topAnchor.constraint(equalTo: card.topAnchor, constant: 16), stack.bottomAnchor.constraint(equalTo: card.bottomAnchor, constant: -16)])
    }

    private func rgba(_ c: UIColor) -> SIMD3<Float> {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0; c.getRed(&r, green: &g, blue: &b, alpha: &a)
        return SIMD3(Float(r), Float(g), Float(b))
    }

    /// Equirect picture: row 0 = zenith, middle = horizon, last = ground.
    private func image() -> UIImage? {
        let W = 1024, H = 512
        var px = [UInt8](repeating: 255, count: W * H * 4)
        let c = cols.map { rgba($0) }
        for y in 0..<H {
            let v = Float(y) / Float(H - 1)        // 0 top, 1 bottom
            var col: SIMD3<Float>
            if v < 0.25 { col = simd_mix(c[0], c[1], SIMD3(repeating: v / 0.25)) }
            else if v < 0.5 { col = simd_mix(c[1], c[2], SIMD3(repeating: (v - 0.25) / 0.25)) }
            else if v < 0.55 { col = simd_mix(c[2], c[3], SIMD3(repeating: (v - 0.5) / 0.05)) }
            else { col = c[3] }
            for x in 0..<W {
                var p = col
                if sunOn {
                    let u = Float(x) / Float(W)
                    let dx = min(abs(u - 0.25), 1 - abs(u - 0.25)) * 4, dy = (v - 0.45) * 3
                    let g = expf(-(dx * dx + dy * dy) * 6)
                    p += SIMD3(1.0, 0.85, 0.6) * g * 0.8
                }
                let o = (y * W + x) * 4
                px[o] = UInt8(max(0, min(255, p.x * 255))); px[o + 1] = UInt8(max(0, min(255, p.y * 255))); px[o + 2] = UInt8(max(0, min(255, p.z * 255)))
            }
        }
        guard let prov = CGDataProvider(data: Data(px) as CFData),
              let cg = CGImage(width: W, height: H, bitsPerComponent: 8, bitsPerPixel: 32, bytesPerRow: W * 4, space: CGColorSpaceCreateDeviceRGB(),
                               bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.noneSkipLast.rawValue), provider: prov, decode: nil, shouldInterpolate: true, intent: .defaultIntent) else { return nil }
        return UIImage(cgImage: cg)
    }

    private func apply() {
        guard let h = host, let img = image(), let jpg = img.jpegData(compressionQuality: 0.95), let png = img.pngData() else { status.text = "Could not build the sky."; return }
        let stamp = nowMs()
        guard let envPath = ProjectIO.writeDataIntoSandbox(png, name: "env_custom_\(stamp).png") else { status.text = "Could not save the sky."; return }
        GlobalEnv.path = envPath; R3D.set("envGain", bright)
        if let glb = EnvPanel.skyGLB(jpg), let sp = ProjectIO.writeDataIntoSandbox(glb, name: "sky_custom_\(stamp).glb") {
            for old in Editor.scene.layers.filter({ $0.name.hasPrefix("Sky · ") }) { Editor.scene.layers.removeAll { $0 === old } }
            h.addMedia(sp, .MODEL)
            if let l = Editor.scene.layers.last(where: { $0.imagePath == sp }) { l.name = "Sky · Custom"; l.track("scale").base = 40; l.m3Env = false }
        }
        h.refreshPanel(); h.render()
        status.text = "Custom sky applied."
    }
}
