// UniverseDashboard.swift — full-screen dashboard for Universe Glow / Universe Prism Displacement ("Open Dashboard…").
// Live preview, preset grid with thumbnails of the neon skyline sample, every parameter. Close reverts, Apply keeps.

import UIKit
import CoreImage

final class UniverseDashboardViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {
    private let lay: Layer
    private let entry: String
    private let onDone: () -> Void
    private let def: EffectDef?
    private let presets: [UniversePreset]
    private var snap: [String: Float] = [:]
    private var savedVideoCb: (() -> Void)?
    private lazy var pv: PreviewView = {
        savedVideoCb = MetalSceneRenderer.onVideoFrame
        let v = PreviewView(); v.quality = 2
        return v
    }()
    private let accent = argbToUIColor(C.BLUE)
    private let rows = UIStackView()
    private var grid: UICollectionView!
    private var refreshers: [() -> Void] = []
    private var thumbs: [Int: UIImage] = [:]

    init(_ l: Layer, _ entry: String, onDone: @escaping () -> Void) {
        self.lay = l; self.entry = entry; self.onDone = onDone
        self.def = Registry.get(entry)
        self.presets = UniversePresets.list(for: Registry.get(entry)?.id ?? "uglow")
        super.init(nibName: nil, bundle: nil)
        modalPresentationStyle = .overFullScreen
        for (k, t) in l.props where k.hasPrefix(entry + "__") { snap[k] = t.base }
    }
    required init?(coder: NSCoder) { fatalError() }

    private func key(_ k: String) -> String { entry + "__" + k }
    private func val(_ k: String) -> Float {
        if let t = lay.props[key(k)] { return t.eval(lay.editTime(key(k), Editor.time)) }
        return def?.props.first { $0.key == k }?.def ?? 0
    }
    private func set(_ k: String, _ v: Float) { lay.track(key(k)).base = v }
    private func setColor(_ k: String, _ argb: UInt32) {
        let comps: [(String, UInt32)] = [("_a", 24), ("_r", 16), ("_g", 8), ("_b", 0)]
        for (suf, sh) in comps { lay.track(key(k) + suf).base = Float((argb >> sh) & 0xFF) / 255 }
    }
    private func colorVal(_ cp: ColorParam) -> UIColor {
        let d = UInt32(bitPattern: cp.def)
        func comp(_ suf: String, _ sh: UInt32) -> CGFloat {
            if let t = lay.props[key(cp.key) + suf] { return CGFloat(t.base) }
            return CGFloat((d >> sh) & 0xFF) / 255
        }
        return UIColor(red: comp("_r", 16), green: comp("_g", 8), blue: comp("_b", 0), alpha: 1)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(white: 0.08, alpha: 1)
        let safe = view.safeAreaLayoutGuide

        let close = UIButton(type: .system)
        close.setImage(UIImage(systemName: "xmark"), for: .normal); close.setTitle("  Close", for: .normal); close.tintColor = .white
        close.addAction(UIAction { [weak self] _ in self?.finish(apply: false) }, for: .touchUpInside)
        let apply = UIButton(type: .system)
        apply.setTitle("Apply Effect", for: .normal); apply.titleLabel?.font = .systemFont(ofSize: 15, weight: .bold)
        apply.setTitleColor(.white, for: .normal); apply.backgroundColor = accent; apply.layer.cornerRadius = 8
        apply.contentEdgeInsets = UIEdgeInsets(top: 0, left: 16, bottom: 0, right: 16)
        apply.addAction(UIAction { [weak self] _ in self?.finish(apply: true) }, for: .touchUpInside)
        let title = UILabel(); title.text = UniversePresets.title[def?.id ?? ""] ?? def?.name ?? ""
        title.font = .systemFont(ofSize: 18, weight: .semibold); title.textColor = .white
        let bar = UIView()
        for v in [close, apply, title] as [UIView] { v.translatesAutoresizingMaskIntoConstraints = false; bar.addSubview(v) }

        let box = UIView(); box.backgroundColor = .black; box.clipsToBounds = true
        let aspect = CGFloat(max(Editor.project.w, 1)) / CGFloat(max(Editor.project.h, 1))
        pv.translatesAutoresizingMaskIntoConstraints = false
        box.addSubview(pv)

        let head = UILabel(); head.text = "PRESETS"; head.font = .systemFont(ofSize: 13, weight: .semibold); head.textColor = UIColor(white: 0.7, alpha: 1)

        let fl = UICollectionViewFlowLayout()
        fl.scrollDirection = .horizontal; fl.itemSize = CGSize(width: 116, height: 84); fl.minimumLineSpacing = 8; fl.minimumInteritemSpacing = 6
        fl.sectionInset = UIEdgeInsets(top: 0, left: 12, bottom: 0, right: 12)
        grid = UICollectionView(frame: .zero, collectionViewLayout: fl)
        grid.backgroundColor = .clear; grid.dataSource = self; grid.delegate = self
        grid.register(UniversePresetCell.self, forCellWithReuseIdentifier: "c")
        grid.showsHorizontalScrollIndicator = false

        let scroll = UIScrollView(); rows.axis = .vertical; rows.spacing = 8
        rows.translatesAutoresizingMaskIntoConstraints = false; scroll.addSubview(rows)
        for pd in def?.props ?? [] { rows.addArrangedSubview(row(pd)) }
        for cp in def?.colors ?? [] { rows.addArrangedSubview(colorRow(cp)) }

        for v in [bar, box, head, grid, scroll] as [UIView] { v.translatesAutoresizingMaskIntoConstraints = false; view.addSubview(v) }
        let fillH = pv.heightAnchor.constraint(equalTo: box.heightAnchor); fillH.priority = UILayoutPriority(750)
        let fillW = pv.widthAnchor.constraint(equalTo: box.widthAnchor); fillW.priority = UILayoutPriority(749)
        let gridH: CGFloat = presets.count > 6 ? 176 : 88
        NSLayoutConstraint.activate([
            bar.topAnchor.constraint(equalTo: safe.topAnchor), bar.leadingAnchor.constraint(equalTo: safe.leadingAnchor),
            bar.trailingAnchor.constraint(equalTo: safe.trailingAnchor), bar.heightAnchor.constraint(equalToConstant: 52),
            close.leadingAnchor.constraint(equalTo: bar.leadingAnchor, constant: 12), close.centerYAnchor.constraint(equalTo: bar.centerYAnchor),
            title.centerXAnchor.constraint(equalTo: bar.centerXAnchor), title.centerYAnchor.constraint(equalTo: bar.centerYAnchor),
            apply.trailingAnchor.constraint(equalTo: bar.trailingAnchor, constant: -12), apply.centerYAnchor.constraint(equalTo: bar.centerYAnchor),
            apply.heightAnchor.constraint(equalToConstant: 34),
            box.topAnchor.constraint(equalTo: bar.bottomAnchor), box.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            box.trailingAnchor.constraint(equalTo: view.trailingAnchor), box.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.3),
            pv.centerXAnchor.constraint(equalTo: box.centerXAnchor), pv.centerYAnchor.constraint(equalTo: box.centerYAnchor),
            pv.widthAnchor.constraint(lessThanOrEqualTo: box.widthAnchor), pv.heightAnchor.constraint(lessThanOrEqualTo: box.heightAnchor),
            pv.widthAnchor.constraint(equalTo: pv.heightAnchor, multiplier: aspect), fillH, fillW,
            head.topAnchor.constraint(equalTo: box.bottomAnchor, constant: 10), head.leadingAnchor.constraint(equalTo: safe.leadingAnchor, constant: 14),
            grid.topAnchor.constraint(equalTo: head.bottomAnchor, constant: 6), grid.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            grid.trailingAnchor.constraint(equalTo: view.trailingAnchor), grid.heightAnchor.constraint(equalToConstant: gridH),
            scroll.topAnchor.constraint(equalTo: grid.bottomAnchor, constant: 10), scroll.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scroll.trailingAnchor.constraint(equalTo: view.trailingAnchor), scroll.bottomAnchor.constraint(equalTo: safe.bottomAnchor),
            rows.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor), rows.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor, constant: -16),
            rows.leadingAnchor.constraint(equalTo: scroll.frameLayoutGuide.leadingAnchor, constant: 16),
            rows.trailingAnchor.constraint(equalTo: scroll.frameLayoutGuide.trailingAnchor, constant: -16),
            rows.widthAnchor.constraint(equalTo: scroll.frameLayoutGuide.widthAnchor, constant: -32),
        ])
        buildThumbs()
    }
    override func viewDidAppear(_ a: Bool) { super.viewDidAppear(a); pv.requestDraw(); DispatchQueue.main.async { [weak self] in self?.pv.requestDraw() } }

    // MARK: rows
    private func row(_ pd: PropDef) -> UIView {
        let name = UILabel(); name.text = pd.label; name.textColor = .white; name.font = .systemFont(ofSize: 13)
        if let opts = pd.options {
            if opts.count == 2 {
                let sw = UISwitch(); sw.onTintColor = accent
                sw.addAction(UIAction { [weak self] _ in self?.set(pd.key, sw.isOn ? 1 : 0); self?.pv.requestDraw() }, for: .valueChanged)
                refreshers.append { [weak self] in sw.isOn = (self?.val(pd.key) ?? 0) >= 0.5 }
                sw.isOn = val(pd.key) >= 0.5
                return UIStackView(arrangedSubviews: [name, UIView(), sw])
            }
            let b = UIButton(type: .system); b.tintColor = accent; b.showsMenuAsPrimaryAction = true
            func rebuild(_ btn: UIButton) {
                let cur = Int(val(pd.key).rounded())
                btn.setTitle(opts[min(max(cur, 0), opts.count - 1)] + " ▾", for: .normal)
                btn.menu = UIMenu(children: opts.enumerated().map { (i, o) in
                    UIAction(title: o, state: i == cur ? .on : .off) { [weak self, weak btn] _ in
                        self?.set(pd.key, Float(i)); self?.pv.requestDraw()
                        if let btn = btn { rebuild(btn) }
                    }
                })
            }
            rebuild(b)
            refreshers.append { rebuild(b) }
            return UIStackView(arrangedSubviews: [name, UIView(), b])
        }
        let num = UILabel(); num.textColor = accent; num.font = .monospacedDigitSystemFont(ofSize: 13, weight: .medium); num.textAlignment = .right
        let s = UISlider(); s.minimumValue = pd.min; s.maximumValue = pd.max; s.tintColor = accent
        func fmt(_ v: Float) -> String { String(format: "%.\(pd.dec)f", v) }
        s.value = val(pd.key); num.text = fmt(s.value)
        s.addAction(UIAction { [weak self] _ in self?.set(pd.key, s.value); num.text = fmt(s.value); self?.pv.requestDraw() }, for: .valueChanged)
        refreshers.append { [weak self] in let v = self?.val(pd.key) ?? 0; s.value = v; num.text = fmt(v) }
        let top = UIStackView(arrangedSubviews: [name, num]); top.distribution = .fill
        num.widthAnchor.constraint(equalToConstant: 64).isActive = true
        let col = UIStackView(arrangedSubviews: [top, s]); col.axis = .vertical; col.spacing = 2
        return col
    }
    private func colorRow(_ cp: ColorParam) -> UIView {
        let name = UILabel(); name.text = cp.label; name.textColor = .white; name.font = .systemFont(ofSize: 13)
        let well = UIColorWell(); well.supportsAlpha = false; well.selectedColor = colorVal(cp)
        well.addAction(UIAction { [weak self] _ in
            guard let self = self, let c = well.selectedColor else { return }
            var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
            c.getRed(&r, green: &g, blue: &b, alpha: &a)
            let argb = (UInt32(255) << 24) | (UInt32(r * 255) << 16) | (UInt32(g * 255) << 8) | UInt32(b * 255)
            self.setColor(cp.key, argb); self.pv.requestDraw()
        }, for: .valueChanged)
        refreshers.append { [weak self] in if let c = self?.colorVal(cp) { well.selectedColor = c } }
        return UIStackView(arrangedSubviews: [name, UIView(), well])
    }

    // MARK: presets
    private func applyPreset(_ p: UniversePreset) {
        for pd in def?.props ?? [] { set(pd.key, pd.def) }
        for cp in def?.colors ?? [] { setColor(cp.key, UInt32(bitPattern: cp.def)) }
        for (k, v) in p.vals { set(k, v) }
        for (k, c) in p.cols { setColor(k, c) }
        for r in refreshers { r() }
        pv.requestDraw()
    }
    private func buildThumbs() {
        let id = def?.id ?? ""
        let word = UniversePresets.words[id]
        var photo: UIImage? = nil
        if word == nil {
            let nm = UniversePresets.thumbRes[id] ?? "fx_neon_skyline"
            guard let path = Bundle.main.path(forResource: nm, ofType: "jpg") ?? Bundle.main.path(forResource: nm, ofType: "png"), let full = UIImage(contentsOfFile: path) else { return }
            let sz = CGSize(width: 232, height: 130)
            photo = UIGraphicsImageRenderer(size: sz).image { _ in full.draw(in: CGRect(origin: .zero, size: sz)) }
        }
        let list = presets
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            let ctx = CIContext()
            for (i, p) in list.enumerated() {
                var baseUI: UIImage
                if let w = word {
                    let c = p.tint ?? 0xFFFFFFFF
                    let col = UIColor(red: CGFloat((c >> 16) & 255) / 255, green: CGFloat((c >> 8) & 255) / 255, blue: CGFloat(c & 255) / 255, alpha: 1)
                    let sz = CGSize(width: 232, height: 130)
                    baseUI = UIGraphicsImageRenderer(size: sz).image { g in
                        UIColor.black.setFill(); g.fill(CGRect(origin: .zero, size: sz))
                        let st = NSAttributedString(string: w, attributes: [.font: UIFont(name: "Georgia-Bold", size: 44) ?? UIFont.boldSystemFont(ofSize: 44), .foregroundColor: UIColor.white.blended(col)])
                        let r = st.size(); st.draw(at: CGPoint(x: (sz.width - r.width) / 2, y: (sz.height - r.height) / 2))
                    }
                } else if let ph = photo { baseUI = ph } else { continue }
                guard let base = CIImage(image: baseUI) else { continue }
                var img = base
                if p.bloom > 0, let f = CIFilter(name: "CIBloom") {
                    f.setValue(img, forKey: kCIInputImageKey)
                    f.setValue(Double(p.bloom) * 8.0, forKey: kCIInputRadiusKey)
                    f.setValue(Double(min(p.bloom, 1.5)), forKey: kCIInputIntensityKey)
                    img = f.outputImage ?? img
                }
                if word == nil, let t = p.tint, let gen = CIFilter(name: "CIConstantColorGenerator"), let sb = CIFilter(name: "CIScreenBlendMode") {
                    gen.setValue(CIColor(red: CGFloat((t >> 16) & 255) / 255, green: CGFloat((t >> 8) & 255) / 255, blue: CGFloat(t & 255) / 255), forKey: kCIInputColorKey)
                    if let g = gen.outputImage?.cropped(to: base.extent) {
                        sb.setValue(g, forKey: kCIInputImageKey); sb.setValue(img, forKey: kCIInputBackgroundImageKey)
                        img = sb.outputImage ?? img
                    }
                }
                if let cg = ctx.createCGImage(img, from: base.extent) {
                    let ui = UIImage(cgImage: cg)
                    DispatchQueue.main.async { self?.thumbs[i] = ui; self?.grid.reloadItems(at: [IndexPath(item: i, section: 0)]) }
                }
            }
        }
    }

    func collectionView(_ cv: UICollectionView, numberOfItemsInSection s: Int) -> Int { presets.count }
    func collectionView(_ cv: UICollectionView, cellForItemAt ip: IndexPath) -> UICollectionViewCell {
        let c = cv.dequeueReusableCell(withReuseIdentifier: "c", for: ip) as! UniversePresetCell
        c.configure(presets[ip.item].name, thumbs[ip.item]); return c
    }
    func collectionView(_ cv: UICollectionView, didSelectItemAt ip: IndexPath) { applyPreset(presets[ip.item]) }

    private func finish(apply: Bool) {
        if !apply {
            for k in Array(lay.props.keys) where k.hasPrefix(entry + "__") {
                if let b = snap[k] { lay.props[k]?.base = b } else { lay.props[k] = nil }
            }
        }
        MetalSceneRenderer.onVideoFrame = savedVideoCb
        let done = onDone
        dismiss(animated: true) { done() }
    }
}

private final class UniversePresetCell: UICollectionViewCell {
    private let img = UIImageView(); private let l = UILabel()
    override init(frame: CGRect) {
        super.init(frame: frame)
        img.contentMode = .scaleAspectFill; img.clipsToBounds = true; img.backgroundColor = UIColor(white: 0.15, alpha: 1)
        img.layer.cornerRadius = 4; img.layer.borderWidth = 1; img.layer.borderColor = UIColor(white: 0.25, alpha: 1).cgColor
        l.font = .systemFont(ofSize: 11, weight: .semibold); l.textColor = UIColor(white: 0.85, alpha: 1); l.textAlignment = .center
        l.adjustsFontSizeToFitWidth = true; l.minimumScaleFactor = 0.7
        for v in [img, l] as [UIView] { v.translatesAutoresizingMaskIntoConstraints = false; contentView.addSubview(v) }
        NSLayoutConstraint.activate([
            img.topAnchor.constraint(equalTo: contentView.topAnchor), img.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            img.trailingAnchor.constraint(equalTo: contentView.trailingAnchor), img.heightAnchor.constraint(equalToConstant: 64),
            l.topAnchor.constraint(equalTo: img.bottomAnchor, constant: 3), l.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            l.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
        ])
    }
    required init?(coder: NSCoder) { fatalError() }
    func configure(_ name: String, _ image: UIImage?) { l.text = name; img.image = image }
}

private extension UIColor {
    /// 30% this color, 70% the given color (glow text tint).
    func blended(_ c: UIColor) -> UIColor {
        var r1: CGFloat = 0, g1: CGFloat = 0, b1: CGFloat = 0, a1: CGFloat = 0, r2: CGFloat = 0, g2: CGFloat = 0, b2: CGFloat = 0, a2: CGFloat = 0
        getRed(&r1, green: &g1, blue: &b1, alpha: &a1); c.getRed(&r2, green: &g2, blue: &b2, alpha: &a2)
        return UIColor(red: r1 * 0.3 + r2 * 0.7, green: g1 * 0.3 + g2 * 0.7, blue: b1 * 0.3 + b2 * 0.7, alpha: 1)
    }
}
