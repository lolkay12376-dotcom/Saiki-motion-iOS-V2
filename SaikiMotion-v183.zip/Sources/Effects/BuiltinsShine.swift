// BuiltinsShine.swift — "Shine": volumetric light rays from a source point (sun through clouds, headlights in fog,
// underwater beams). Pre-process threshold, Ray Length, Shimmer, Boost Light, Colorize (1/3/5-colour gradient),
// Fractal Noise (smoky rays with parallax), Source/Shine opacity, Blend Mode, plus an optional elliptical mask.
//
// Source Point Type: "2D" pins the source to a frame position. "3D (Camera-aware)" places it at a world position
// (X/Y/Z) and projects it through the scene camera every frame (ShineCam.resolve, called by the Metal renderer), so
// camera moves, orbits and zooms carry the rays with them and the ray length follows the perspective scale. The mode
// only does anything when it is enabled; use it on an adjustment layer so the effect sees the whole camera view.
// Open the dashboard ("Open Dashboard…") for presets, every control and the yellow on-screen gizmo.

import Foundation

private let shOnOff = ["Off", "On"]

/// Preset: name, parameter values, gradient colours (Highlights, Mid High, Midtones, Mid Low, Shadows as 0xRRGGBB).
let shinePresets: [(name: String, v: [String: Float], cols: [UInt32])] = [
    ("Default", [:], [0xFFFFFF, 0xFFE066, 0x00C8F0, 0xFFA060, 0x0A5CFF]),
    ("Sunbeam", ["shRay": 6, "shBoost": 20, "shShAmt": 30, "shFnAmt": 35, "shCol": 3, "shThr": 35], [0xFFFFFF, 0xFFF1B0, 0xFFC857, 0xFF9A3C, 0xC2410C]),
    ("Fire", ["shRay": 5, "shBoost": 30, "shShAmt": 45, "shFnAmt": 50, "shCol": 3, "shThr": 25], [0xFFFFE0, 0xFFD23C, 0xFF7A00, 0xD01C00, 0x420000]),
    ("Ice", ["shRay": 4, "shBoost": 15, "shShAmt": 15, "shFnAmt": 20, "shCol": 2], [0xFFFFFF, 0xD6F4FF, 0x7FD4FF, 0x3A8CFF, 0x0A2A8A]),
    ("Electric", ["shRay": 7, "shBoost": 40, "shShAmt": 60, "shShDet": 40, "shFnAmt": 10, "shCol": 2], [0xFFFFFF, 0xE0D0FF, 0xA070FF, 0x6030FF, 0x1A0A6A]),
    ("Underwater", ["shRay": 8, "shBoost": 10, "shShAmt": 25, "shFnAmt": 45, "shFnScale": 18, "shCol": 2, "shThr": 40], [0xE8FFFF, 0xA0F0E0, 0x40C8D0, 0x1890B0, 0x063A60]),
    ("Headlights in Fog", ["shRay": 9, "shBoost": 25, "shFnAmt": 55, "shFnScale": 25, "shCol": 1, "shThr": 45], [0xFFF8E8, 0xFFF8E8, 0xFFF8E8, 0xFFF8E8, 0xFFF8E8]),
]

enum ShineCam {
    /// World point -> screen. nx/ny are NDC (-1...1, y up); scale = on-screen size of one world unit relative to the neutral view.
    static func project(_ l: Layer, time: Float, width: Int, height: Int, _ x: Float, _ y: Float, _ z: Float) -> (nx: Float, ny: Float, scale: Float, visible: Bool) {
        let ar = Float(width) / Float(max(height, 1))
        if let vp = MetalCam.vp(for: l, time: time, width: width, height: height) {
            let cw = vp[3] * x + vp[7] * y + vp[11] * z + vp[15]
            if cw < 0.02 { return (0, 0, 1, false) }
            return ((vp[0] * x + vp[4] * y + vp[8] * z + vp[12]) / cw, (vp[1] * x + vp[5] * y + vp[9] * z + vp[13]) / cw, abs(vp[5]) / cw, true)
        }
        let w = 1 - z / 3
        if w < 0.02 { return (0, 0, 1, false) }
        return (x / ar / w, y / w, 1 / w, true)
    }

    /// Screen NDC -> world X/Y on the plane z (so the gizmo can drag a 3D source on the screen).
    static func unproject(_ l: Layer, time: Float, width: Int, height: Int, _ u: Float, _ v: Float, _ z: Float) -> (Float, Float)? {
        let ar = Float(width) / Float(max(height, 1))
        if let vp = MetalCam.vp(for: l, time: time, width: width, height: height) {
            let a1 = vp[0] - u * vp[3], b1 = vp[4] - u * vp[7], c1 = u * (vp[11] * z + vp[15]) - (vp[8] * z + vp[12])
            let a2 = vp[1] - v * vp[3], b2 = vp[5] - v * vp[7], c2 = v * (vp[11] * z + vp[15]) - (vp[9] * z + vp[13])
            let det = a1 * b2 - a2 * b1
            if abs(det) < 1e-8 { return nil }
            return ((c1 * b2 - c2 * b1) / det, (a1 * c2 - a2 * c1) / det)
        }
        let w = 1 - z / 3
        return (u * ar * w, v * w)
    }

    /// Called by the Metal renderer for every "shine" step: in 3D mode it projects the world source through the camera
    /// and writes the hidden screen-space values (shX, shY, shSc, shVis) the shader reads.
    static func resolve(_ def: EffectDef, _ props: inout [Float], layer l: Layer, time: Float, width: Int, height: Int) {
        func ix(_ k: String) -> Int? { def.props.firstIndex { $0.key == k } }
        guard let t = ix("shType"), t < props.count, props[t] > 0.5,
              let wx = ix("shWX"), let wy = ix("shWY"), let wz = ix("shWZ"),
              let sx = ix("shX"), let sy = ix("shY"), let sc = ix("shSc"), let vis = ix("shVis") else { return }
        let p = project(l, time: time, width: width, height: height, props[wx], props[wy], props[wz])
        props[sx] = (p.nx * 0.5 + 0.5) * 100
        props[sy] = (0.5 - p.ny * 0.5) * 100
        props[sc] = min(max(p.scale, 0.05), 6)
        props[vis] = p.visible ? 1 : 0
    }
}

func shineFx() -> [EffectDef] {
    func col(_ h: UInt32) -> Int32 { Int32(bitPattern: 0xFF000000 | h) }
    let props: [PropDef] = [
        PropDef("shType", "Source Point Type", 0, 1, 0, 0, ["2D", "3D (Camera-aware)"]),
        PropDef("shX", "Source X (%)", -50, 150, 50, 1), PropDef("shY", "Source Y (%)", -50, 150, 35, 1),
        PropDef("shWX", "3D Source X", -4, 4, 0, 2), PropDef("shWY", "3D Source Y", -4, 4, 0.3, 2), PropDef("shWZ", "3D Source Z", -6, 6, 0, 2),
        PropDef("shSc", "(perspective scale)", 0.05, 6, 1, 2), PropDef("shVis", "(source visible)", 0, 1, 1, 0),
        PropDef("shThr", "Pre-process Threshold", 0, 100, 30, 1),
        PropDef("shRay", "Ray Length", 0, 20, 4, 1), PropDef("shQ", "Quality", 0, 2, 1, 0, ["Low", "Medium", "High"]),
        PropDef("shBoost", "Boost Light", 0, 100, 0, 1),
        PropDef("shShAmt", "Shimmer Amount", 0, 100, 0, 1), PropDef("shShDet", "Shimmer Detail", 0, 100, 10, 1),
        PropDef("shShInf", "Source Point Influence", 0, 100, 0, 1), PropDef("shShRad", "Shimmer Radius", 0, 100, 10, 1),
        PropDef("shShPh", "Shimmer Phase", -360, 360, 0, 1, nil, true, 180), PropDef("shShRed", "Reduce Flickering", 0, 1, 0, 0, shOnOff),
        PropDef("shCol", "Colorize", 0, 3, 2, 0, ["None", "1-Color", "3-Color Gradient", "5-Color Gradient"]),
        PropDef("shBase", "Base On", 0, 5, 0, 0, ["Lightness", "Luminance", "Alpha", "Red", "Green", "Blue"]),
        PropDef("shFnAmt", "Fractal Noise Amount", 0, 100, 0, 1), PropDef("shFnScale", "Fractal Noise Scale", 1, 60, 10, 1),
        PropDef("shFnDet", "Fractal Noise Detail", 1, 6, 3, 0), PropDef("shFnEvo", "Fractal Noise Evolution", 0, 10, 1, 2),
        PropDef("shFnPar", "Fractal Noise Parallax", 0, 100, 0, 1),
        PropDef("shSrcOp", "Source Opacity", 0, 100, 100, 1), PropDef("shOp", "Shine Opacity", 0, 100, 100, 1),
        PropDef("shBlend", "Blend Mode", 0, 5, 3, 0, ["None (Shine only)", "Normal", "Add", "Screen", "Overlay", "Multiply"]),
        PropDef("shMask", "Limit to Mask", 0, 1, 0, 0, shOnOff),
        PropDef("shMX", "Mask X (%)", 0, 100, 50, 1), PropDef("shMY", "Mask Y (%)", 0, 100, 50, 1),
        PropDef("shMW", "Mask Width (%)", 1, 200, 40, 1), PropDef("shMH", "Mask Height (%)", 1, 200, 45, 1),
        PropDef("shMFe", "Mask Feather (px)", 0, 500, 100, 0), PropDef("shMOp", "Mask Opacity", 0, 100, 100, 1),
        PropDef("shMEx", "Mask Expansion (px)", -300, 300, 0, 0), PropDef("shMInv", "Mask Inverted", 0, 1, 0, 0, shOnOff),
    ]
    let colors: [ColorParam] = [
        ColorParam("shCHi", "Highlights", col(0xFFFFFF)), ColorParam("shCMH", "Mid High", col(0xFFE066)),
        ColorParam("shCMid", "Midtones", col(0x00C8F0)), ColorParam("shCML", "Mid Low", col(0xFFA060)),
        ColorParam("shCSh", "Shadows", col(0x0A5CFF)),
    ]
    return [EffectDef(
        id: "shine", name: "Shine",
        desc: "Light rays from a source point. 2D pins it to the frame; 3D (Camera-aware) places it in the scene and follows the camera (use on an adjustment layer). Tap Open Dashboard for presets, the on-screen gizmo and every control.",
        category: "Light and glow", props: props, colors: colors, previewAnim: "fade", glsl: """
    vec2 px = 1.0 / uRes;
    float asp = uRes.x / max(uRes.y, 1.0);
    vec4 s0 = src(uv);
    float a0 = s0.a;
    vec2 S = vec2(shX * 0.01, 1.0 - shY * 0.01);
    float sc = max(shSc, 0.05);
    vec2 d = S - uv;
    vec2 da = vec2(d.x * asp, d.y);
    float dist = length(da);
    float L = clamp(shRay * 0.1 * sc, 0.0, 1.0);
    float nF = shQ < 0.5 ? 16.0 : (shQ < 1.5 ? 32.0 : 56.0);
    float thr = shThr * 0.01;
    vec3 acc = vec3(0.0);
    float wsum = 0.0;
    float jit = hash21(uv * uRes + uTime) * 0.9;
    for (int i = 0; i < 56; i++) {
        if (float(i) < nF) {
            float t = (float(i) + jit) / nF;
            vec3 sm = src(uv + d * (t * L)).rgb;
            float sl = dot(sm, vec3(0.299, 0.587, 0.114));
            float wt = pow(1.0 - t, 1.6);
            acc += sm * smoothstep(thr, thr + 0.25, sl) * wt;
            wsum += wt;
        }
    }
    vec3 rays = acc / max(wsum, 0.0001) * (1.5 + 2.5 * L) * (1.0 + shBoost * 0.08);
    if (shShAmt > 0.01) {
        float ang = atan(-d.y, -d.x * asp);
        float fq = 2.0 + shShDet * 0.35;
        float infl = shShInf * 0.01 * dist * (shShRad * 0.2 + 0.5);
        vec2 np = vec2(cos(ang), sin(ang)) * fq + vec2(shShPh / 57.29578 + infl * 3.0, infl);
        float n1 = vnoise(np);
        float n2 = vnoise(np * 2.1 + 7.3);
        float nn = shShRed > 0.5 ? n1 : (n1 * 0.65 + n2 * 0.35);
        rays *= max(1.0 + (nn - 0.5) * 2.4 * shShAmt * 0.01, 0.0);
    }
    if (shFnAmt > 0.01) {
        vec2 q = (uv - S) * vec2(asp, 1.0) * (1.0 + shFnPar * 0.03 * dist) * (60.0 / max(shFnScale, 1.0) * 0.4);
        q += vec2(uTime * 0.3, uTime * 0.17) * shFnEvo;
        float fa = 0.0;
        float fw = 0.5;
        float fs = 0.0;
        for (int o = 0; o < 6; o++) {
            if (float(o) < shFnDet) { fa += fw * vnoise(q); fs += fw; q = q * 2.03 + 3.1; fw *= 0.5; }
        }
        float fnv = fa / max(fs, 0.0001);
        rays *= mix(1.0, clamp(fnv * 2.2, 0.0, 2.0), shFnAmt * 0.01);
    }
    float rl = dot(rays, vec3(0.299, 0.587, 0.114));
    if (shBase < 0.5) { rl = (max(rays.r, max(rays.g, rays.b)) + min(rays.r, min(rays.g, rays.b))) * 0.5; }
    else if (shBase > 1.5 && shBase < 2.5) { rl = max(rays.r, max(rays.g, rays.b)); }
    else if (shBase > 2.5 && shBase < 3.5) { rl = rays.r; }
    else if (shBase > 3.5 && shBase < 4.5) { rl = rays.g; }
    else if (shBase > 4.5) { rl = rays.b; }
    float tg = clamp(rl, 0.0, 1.0);
    if (shCol > 2.5) {
        vec3 g5 = tg < 0.25 ? mix(shCSh.rgb, shCML.rgb, tg * 4.0) : (tg < 0.5 ? mix(shCML.rgb, shCMid.rgb, (tg - 0.25) * 4.0) : (tg < 0.75 ? mix(shCMid.rgb, shCMH.rgb, (tg - 0.5) * 4.0) : mix(shCMH.rgb, shCHi.rgb, (tg - 0.75) * 4.0)));
        rays = g5 * rl;
    } else if (shCol > 1.5) {
        vec3 g3 = tg < 0.5 ? mix(shCSh.rgb, shCMid.rgb, tg * 2.0) : mix(shCMid.rgb, shCHi.rgb, (tg - 0.5) * 2.0);
        rays = g3 * rl;
    } else if (shCol > 0.5) {
        rays = shCHi.rgb * rl;
    }
    float mk = 1.0;
    if (shMask > 0.5) {
        vec2 mc = vec2(shMX * 0.01, 1.0 - shMY * 0.01);
        float pxs = uRes.y / 1080.0;
        vec2 hp = max(vec2(shMW * 0.005 * uRes.x, shMH * 0.005 * uRes.y) + shMEx * pxs, vec2(1.0));
        vec2 pd = (uv - mc) * uRes;
        float e = length(pd / hp);
        float dpx = (e - 1.0) * min(hp.x, hp.y);
        float m = clamp(0.5 - dpx / max(shMFe * pxs, 0.5), 0.0, 1.0);
        m = m * m * (3.0 - 2.0 * m);
        if (shMInv > 0.5) { m = 1.0 - m; }
        mk = mix(1.0, m, shMOp * 0.01);
    }
    rays *= shOp * 0.01 * mk * shVis;
    vec3 base = s0.rgb * (shSrcOp * 0.01);
    float aS = a0 * (shSrcOp * 0.01);
    vec3 rc = clamp(rays, vec3(0.0), vec3(1.0));
    float k = clamp(dot(rc, vec3(0.299, 0.587, 0.114)) * 1.6, 0.0, 1.0);
    vec3 o = base;
    if (shBlend < 0.5) { o = rays; }
    else if (shBlend < 1.5) { o = base * (1.0 - k) + rays; }
    else if (shBlend < 2.5) { o = base + rays; }
    else if (shBlend < 3.5) { o = base + rc - base * rc; }
    else if (shBlend < 4.5) {
        vec3 bs = base / max(aS, 0.0001);
        vec3 ov = vec3(bs.r < 0.5 ? 2.0 * bs.r * rc.r : 1.0 - 2.0 * (1.0 - bs.r) * (1.0 - rc.r),
                       bs.g < 0.5 ? 2.0 * bs.g * rc.g : 1.0 - 2.0 * (1.0 - bs.g) * (1.0 - rc.g),
                       bs.b < 0.5 ? 2.0 * bs.b * rc.b : 1.0 - 2.0 * (1.0 - bs.b) * (1.0 - rc.b));
        o = mix(base, ov * aS, k) + rays * 0.35;
    } else { o = base * (1.0 + rays * 2.0); }
    float oa = clamp(aS + (1.0 - aS) * dot(rc, vec3(0.299, 0.587, 0.114)) * 1.6, 0.0, 1.0);
    return vec4(max(o, vec3(0.0)), oa);
""")]
}
