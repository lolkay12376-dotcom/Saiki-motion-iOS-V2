// ShineDashboard.swift — full-screen dashboard for the Shine effect ("Open Dashboard…"): live preview with a yellow
// on-screen gizmo (source point, mask ellipse + feather), preset chips and every parameter in collapsible sections.
// In 3D (Camera-aware) mode the gizmo sits where the world source projects through the scene camera and dragging it
// moves the source on its Z plane. Close reverts everything, ✓ keeps it.

import UIKit

final class ShineDashboardViewController: UIViewController {
    let lay: Layer, entry: String, onDone: () -> Void, def: EffectDef?
    private var snap: [String: Float] = [:]
    private var savedVideoCb: (() -> Void)?
    lazy var pv: PreviewView = {
        savedVideoCb = MetalSceneRenderer.onVideoFrame
        let v = PreviewView(); v.quality = 2; return v
    }()
    private let gold = UIColor(red: 0.98, green: 0.78, blue: 0.2, alpha: 1)
    private let rows = UIStackView()
    private var rowViews: [String: UIView] = [:]
    private var refreshers: [() -> Void] = []
    private var gizmo: ShineGizmoView?
    private var expanded: Set<String> = ["Source Point", "Rays"]

    static let hidden: Set<String> = ["shSc", "shVis"]
    private static let sections: [(String, [String])] = [
        ("Source Point", ["shType", "shX", "shY", "shWX", "shWY", "shWZ"]),
        ("Rays", ["shThr", "shRay", "shQ", "shBoost"]),
        ("Shimmer", ["shShAmt", "shShDet", "shShInf", "shShRad", "shShPh", "shShRed"]),
        ("Colorize", ["shCol", "shBase"]),
        ("Fractal Noise", ["shFnAmt", "shFnScale", "shFnDet", "shFnEvo", "shFnPar"]),
        ("Blend", ["shSrcOp", "shOp", "shBlend"]),
        ("Mask", ["shMask", "shMX", "shMY", "shMW", "shMH", "shMFe", "shMOp", "shMEx", "shMInv"]),
    ]

    init(_ l: Layer, _ entry: String, onDone: @escaping () -> Void) {
        self.lay = l; self.entry = entry; self.onDone = onDone; self.def = Registry.get(entry)
        super.init(nibName: nil, bundle: nil)
        modalPresentationStyle = .overFullScreen
        for (k, t) in l.props where k.hasPrefix(entry + "__") { snap[k] = t.base }
    }
    required init?(coder: NSCoder) { fatalError() }

    // MARK: params
    func key(_ k: String) -> String { entry + "__" + k }
    func val(_ k: String) -> Float {
        if let t = lay.props[key(k)] { return t.eval(lay.editTime(key(k), Editor.time)) }
        return def?.props.first { $0.key == k }?.def ?? 0
    }
    func set(_ k: String, _ v: Float) { lay.track(key(k)).base = v; pv.requestDraw(); gizmo?.refresh() }
    private func comp(_ k: String, _ s: String, _ d: Float) -> Float {
        let kk = key(k) + "_" + s
        if let t = lay.props[kk] { return t.eval(lay.editTime(kk, Editor.time)) }
        return d
    }
    private func setColor(_ k: String, _ rgb: UInt32) {
        lay.track(key(k) + "_r").base = Float((rgb >> 16) & 0xFF) / 255; lay.track(key(k) + "_g").base = Float((rgb >> 8) & 0xFF) / 255
        lay.track(key(k) + "_b").base = Float(rgb & 0xFF) / 255; lay.track(key(k) + "_a").base = 1
    }

    // MARK: layout
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(white: 0.07, alpha: 1)
        let safe = view.safeAreaLayoutGuide
        func icon(_ n: String, _ a: @escaping () -> Void) -> UIButton {
            let b = UIButton(type: .system); b.setImage(UIImage(systemName: n), for: .normal); b.tintColor = .white
            b.addAction(UIAction { _ in a() }, for: .touchUpInside); return b
        }
        let close = icon("xmark") { [weak self] in self?.finish(apply: false) }
        let ok = icon("checkmark") { [weak self] in self?.finish(apply: true) }; ok.tintColor = gold
        let title = UILabel(); title.text = "SHINE"; title.font = .systemFont(ofSize: 14, weight: .heavy); title.textColor = UIColor(white: 0.9, alpha: 1)
        let bar = UIView()
        for v in [close, ok, title] as [UIView] { v.translatesAutoresizingMaskIntoConstraints = false; bar.addSubview(v) }

        let box = UIView(); box.backgroundColor = .black; box.clipsToBounds = true
        let aspect = CGFloat(max(Editor.project.w, 1)) / CGFloat(max(Editor.project.h, 1))
        pv.translatesAutoresizingMaskIntoConstraints = false; box.addSubview(pv)
        let gz = ShineGizmoView(); gz.owner = self; gz.frame = pv.bounds; gz.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        pv.addSubview(gz); gizmo = gz

        // preset chips
        let chips = UIStackView(); chips.spacing = 8
        for p in shinePresets {
            let b = UIButton(type: .system); b.setTitle(p.name, for: .normal); b.titleLabel?.font = .systemFont(ofSize: 13, weight: .semibold)
            b.setTitleColor(.white, for: .normal); b.backgroundColor = UIColor(white: 0.18, alpha: 1); b.layer.cornerRadius = 8
            b.contentEdgeInsets = UIEdgeInsets(top: 8, left: 14, bottom: 8, right: 14)
            b.addAction(UIAction { [weak self] _ in self?.apply(preset: p) }, for: .touchUpInside)
            chips.addArrangedSubview(b)
        }
        chips.translatesAutoresizingMaskIntoConstraints = false
        let chipScroll = UIScrollView(); chipScroll.showsHorizontalScrollIndicator = false; chipScroll.addSubview(chips)

        let scroll = UIScrollView()
        rows.axis = .vertical; rows.spacing = 10; rows.translatesAutoresizingMaskIntoConstraints = false; scroll.addSubview(rows)
        buildRows()

        for v in [bar, box, chipScroll, scroll] as [UIView] { v.translatesAutoresizingMaskIntoConstraints = false; view.addSubview(v) }
        let fillH = pv.heightAnchor.constraint(equalTo: box.heightAnchor); fillH.priority = UILayoutPriority(750)
        let fillW = pv.widthAnchor.constraint(equalTo: box.widthAnchor); fillW.priority = UILayoutPriority(749)
        NSLayoutConstraint.activate([
            bar.topAnchor.constraint(equalTo: safe.topAnchor), bar.leadingAnchor.constraint(equalTo: safe.leadingAnchor),
            bar.trailingAnchor.constraint(equalTo: safe.trailingAnchor), bar.heightAnchor.constraint(equalToConstant: 44),
            close.leadingAnchor.constraint(equalTo: bar.leadingAnchor, constant: 14), close.centerYAnchor.constraint(equalTo: bar.centerYAnchor),
            ok.trailingAnchor.constraint(equalTo: bar.trailingAnchor, constant: -14), ok.centerYAnchor.constraint(equalTo: bar.centerYAnchor),
            title.centerXAnchor.constraint(equalTo: bar.centerXAnchor), title.centerYAnchor.constraint(equalTo: bar.centerYAnchor),
            box.topAnchor.constraint(equalTo: bar.bottomAnchor), box.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            box.trailingAnchor.constraint(equalTo: view.trailingAnchor), box.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.36),
            pv.centerXAnchor.constraint(equalTo: box.centerXAnchor), pv.centerYAnchor.constraint(equalTo: box.centerYAnchor),
            pv.widthAnchor.constraint(lessThanOrEqualTo: box.widthAnchor), pv.heightAnchor.constraint(lessThanOrEqualTo: box.heightAnchor),
            pv.widthAnchor.constraint(equalTo: pv.heightAnchor, multiplier: aspect), fillH, fillW,
            chipScroll.topAnchor.constraint(equalTo: box.bottomAnchor, constant: 8), chipScroll.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            chipScroll.trailingAnchor.constraint(equalTo: view.trailingAnchor), chipScroll.heightAnchor.constraint(equalToConstant: 38),
            chips.leadingAnchor.constraint(equalTo: chipScroll.contentLayoutGuide.leadingAnchor, constant: 14),
            chips.trailingAnchor.constraint(equalTo: chipScroll.contentLayoutGuide.trailingAnchor, constant: -14),
            chips.topAnchor.constraint(equalTo: chipScroll.contentLayoutGuide.topAnchor), chips.bottomAnchor.constraint(equalTo: chipScroll.contentLayoutGuide.bottomAnchor),
            chips.heightAnchor.constraint(equalTo: chipScroll.frameLayoutGuide.heightAnchor),
            scroll.topAnchor.constraint(equalTo: chipScroll.bottomAnchor, constant: 8), scroll.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scroll.trailingAnchor.constraint(equalTo: view.trailingAnchor), scroll.bottomAnchor.constraint(equalTo: safe.bottomAnchor),
            rows.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor), rows.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor, constant: -20),
            rows.leadingAnchor.constraint(equalTo: scroll.frameLayoutGuide.leadingAnchor, constant: 16),
            rows.trailingAnchor.constraint(equalTo: scroll.frameLayoutGuide.trailingAnchor, constant: -16),
            rows.widthAnchor.constraint(equalTo: scroll.frameLayoutGuide.widthAnchor, constant: -32),
        ])
        updateVisibility()
    }
    override func viewDidAppear(_ a: Bool) {
        super.viewDidAppear(a); pv.requestDraw(); gizmo?.refresh()
        DispatchQueue.main.async { [weak self] in self?.pv.requestDraw() }
    }
    override func viewDidLayoutSubviews() { super.viewDidLayoutSubviews(); gizmo?.refresh() }

    // MARK: rows
    private func buildRows() {
        rows.arrangedSubviews.forEach { $0.removeFromSuperview() }
        rowViews = [:]; refreshers = []
        for (name, keys) in Self.sections {
            let body = UIStackView(); body.axis = .vertical; body.spacing = 8
            for k in keys { if let pd = def?.props.first(where: { $0.key == k }) { let r = row(pd); rowViews[k] = r; body.addArrangedSubview(r) } }
            if name == "Colorize" { for cp in def?.colors ?? [] { let r = colorRow(cp); rowViews[cp.key] = r; body.addArrangedSubview(r) } }
            body.isHidden = !expanded.contains(name)
            let h = UIButton(type: .system)
            func title() { h.setTitle((expanded.contains(name) ? "▾  " : "▸  ") + name.uppercased(), for: .normal) }
            title()
            h.titleLabel?.font = .systemFont(ofSize: 12, weight: .heavy); h.setTitleColor(gold, for: .normal); h.contentHorizontalAlignment = .left
            h.addAction(UIAction { [weak self, weak body] _ in
                guard let self = self, let body = body else { return }
                if self.expanded.contains(name) { self.expanded.remove(name) } else { self.expanded.insert(name) }
                body.isHidden = !self.expanded.contains(name); title()
            }, for: .touchUpInside)
            let sec = UIStackView(arrangedSubviews: [h, body]); sec.axis = .vertical; sec.spacing = 8
            rows.addArrangedSubview(sec)
        }
    }

    private func row(_ pd: PropDef) -> UIView {
        let name = UILabel(); name.text = pd.label; name.textColor = .white; name.font = .systemFont(ofSize: 14)
        if let opts = pd.options {
            if opts.count == 2 {
                let sw = UISwitch(); sw.onTintColor = gold; sw.isOn = val(pd.key) >= 0.5
                sw.addAction(UIAction { [weak self] _ in self?.set(pd.key, sw.isOn ? 1 : 0); self?.updateVisibility() }, for: .valueChanged)
                refreshers.append { [weak self] in sw.isOn = (self?.val(pd.key) ?? 0) >= 0.5 }
                return UIStackView(arrangedSubviews: [name, UIView(), sw])
            }
            let b = UIButton(type: .system); b.tintColor = gold; b.showsMenuAsPrimaryAction = true
            func rebuild() {
                let cur = min(max(Int(val(pd.key).rounded()), 0), opts.count - 1)
                b.setTitle(opts[cur] + "  ▾", for: .normal)
                b.menu = UIMenu(children: opts.enumerated().map { (i, o) in
                    UIAction(title: o, state: i == cur ? .on : .off) { [weak self] _ in self?.set(pd.key, Float(i)); rebuild(); self?.updateVisibility() }
                })
            }
            rebuild(); refreshers.append(rebuild)
            return UIStackView(arrangedSubviews: [name, UIView(), b])
        }
        let v = UILabel(); v.font = .monospacedDigitSystemFont(ofSize: 13, weight: .regular); v.textColor = gold; v.textAlignment = .right
        let s = UISlider(); s.minimumValue = pd.min; s.maximumValue = pd.max; s.value = val(pd.key); s.tintColor = gold
        let show: (Float) -> String = { String(format: "%.\(pd.dec)f", $0) }
        v.text = show(s.value)
        s.addAction(UIAction { [weak self, weak s, weak v] _ in guard let s = s, let v = v else { return }; self?.set(pd.key, s.value); v.text = show(s.value) }, for: .valueChanged)
        refreshers.append { [weak self, weak s, weak v] in guard let self = self, let s = s, let v = v else { return }; s.value = self.val(pd.key); v.text = show(s.value) }
        let top = UIStackView(arrangedSubviews: [name, UIView(), v])
        let col = UIStackView(arrangedSubviews: [top, s]); col.axis = .vertical; col.spacing = 2
        return col
    }

    private func colorRow(_ cp: ColorParam) -> UIView {
        let u = UInt32(bitPattern: cp.def)
        let w = UIColorWell(); w.supportsAlpha = false; w.title = cp.label
        func current() -> UIColor {
            UIColor(red: CGFloat(comp(cp.key, "r", Float((u >> 16) & 0xFF) / 255)), green: CGFloat(comp(cp.key, "g", Float((u >> 8) & 0xFF) / 255)),
                    blue: CGFloat(comp(cp.key, "b", Float(u & 0xFF) / 255)), alpha: 1)
        }
        w.selectedColor = current()
        w.addAction(UIAction { [weak self, weak w] _ in
            guard let self = self, let c = w?.selectedColor else { return }
            var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0; c.getRed(&r, green: &g, blue: &b, alpha: &a)
            self.lay.track(self.key(cp.key) + "_r").base = Float(r); self.lay.track(self.key(cp.key) + "_g").base = Float(g)
            self.lay.track(self.key(cp.key) + "_b").base = Float(b); self.lay.track(self.key(cp.key) + "_a").base = 1
            self.pv.requestDraw()
        }, for: .valueChanged)
        refreshers.append { w.selectedColor = current() }
        let t = UILabel(); t.text = cp.label; t.font = .systemFont(ofSize: 14); t.textColor = .white
        let r = UIStackView(arrangedSubviews: [t, UIView(), w]); r.alignment = .center
        return r
    }

    /// 2D shows the frame X/Y; 3D shows the world X/Y/Z. Mask fields fade out while the mask is off.
    func updateVisibility() {
        let three = val("shType") > 0.5, mask = val("shMask") > 0.5
        for k in ["shX", "shY"] { rowViews[k]?.isHidden = three }
        for k in ["shWX", "shWY", "shWZ"] { rowViews[k]?.isHidden = !three }
        for k in ["shMX", "shMY", "shMW", "shMH", "shMFe", "shMOp", "shMEx", "shMInv"] { rowViews[k]?.isHidden = !mask }
        let hasGrad = val("shCol") > 1.5, five = val("shCol") > 2.5
        rowViews["shBase"]?.isHidden = val("shCol") < 0.5
        for k in ["shCHi"] { rowViews[k]?.isHidden = val("shCol") < 0.5 }
        for k in ["shCMid", "shCSh"] { rowViews[k]?.isHidden = !hasGrad }
        for k in ["shCMH", "shCML"] { rowViews[k]?.isHidden = !five }
        gizmo?.refresh()
    }

    private func apply(preset p: (name: String, v: [String: Float], cols: [UInt32])) {
        let keep: Set<String> = Set(Self.sections[0].1 + Self.sections[6].1)
        for pd in def?.props ?? [] where !keep.contains(pd.key) && !Self.hidden.contains(pd.key) { set(pd.key, pd.def) }
        for (k, v) in p.v { set(k, v) }
        let names = ["shCHi", "shCMH", "shCMid", "shCML", "shCSh"]
        for (i, n) in names.enumerated() where i < p.cols.count { setColor(n, p.cols[i]) }
        refreshers.forEach { $0() }; updateVisibility(); pv.requestDraw()
    }

    // MARK: finish
    func finish(apply: Bool) {
        if !apply {
            for k in Array(lay.props.keys) where k.hasPrefix(entry + "__") { if let b = snap[k] { lay.props[k]?.base = b } else { lay.props[k] = nil } }
        }
        MetalSceneRenderer.onVideoFrame = savedVideoCb
        let done = onDone
        dismiss(animated: true) { done() }
    }
}

// MARK: - viewport gizmo (yellow): source point + mask ellipse with feather ring
final class ShineGizmoView: UIView {
    weak var owner: ShineDashboardViewController?
    private let src = CAShapeLayer(), ell = CAShapeLayer(), fea = CAShapeLayer(), dots = CAShapeLayer()
    private let gold = UIColor(red: 0.98, green: 0.78, blue: 0.2, alpha: 1)
    private var handles: [(id: Int, p: CGPoint)] = []     // 0 source, 1 mask centre, 2 mask width, 3 mask height
    private var drag = -1

    override init(frame: CGRect) {
        super.init(frame: frame); backgroundColor = .clear
        for l in [src, ell, fea, dots] { l.fillColor = nil; l.strokeColor = gold.cgColor; l.lineWidth = 1.5; layer.addSublayer(l) }
        ell.lineDashPattern = [6, 4]; fea.lineDashPattern = [2, 4]; fea.strokeColor = gold.withAlphaComponent(0.55).cgColor
        dots.fillColor = UIColor(white: 0, alpha: 0.4).cgColor
    }
    required init?(coder: NSCoder) { fatalError() }
    override func layoutSubviews() { super.layoutSubviews(); refresh() }

    private var pw: Int { max(Editor.project.w, 1) }
    private var ph: Int { max(Editor.project.h, 1) }

    private func sourcePoint(_ o: ShineDashboardViewController) -> CGPoint? {
        let W = bounds.width, H = bounds.height
        if o.val("shType") > 0.5 {
            let p = ShineCam.project(o.lay, time: Editor.time, width: pw, height: ph, o.val("shWX"), o.val("shWY"), o.val("shWZ"))
            if !p.visible { return nil }
            return CGPoint(x: (CGFloat(p.nx) * 0.5 + 0.5) * W, y: (0.5 - CGFloat(p.ny) * 0.5) * H)
        }
        return CGPoint(x: CGFloat(o.val("shX")) * 0.01 * W, y: CGFloat(o.val("shY")) * 0.01 * H)
    }

    func refresh() {
        guard let o = owner, bounds.width > 1 else { return }
        handles = []
        let W = bounds.width, H = bounds.height, k = H / 1080
        let sp = UIBezierPath()
        if let c = sourcePoint(o) {
            sp.append(UIBezierPath(arcCenter: c, radius: 11, startAngle: 0, endAngle: .pi * 2, clockwise: true))
            for (dx, dy) in [(1, 0), (-1, 0), (0, 1), (0, -1)] as [(CGFloat, CGFloat)] {
                sp.move(to: CGPoint(x: c.x + dx * 6, y: c.y + dy * 6)); sp.addLine(to: CGPoint(x: c.x + dx * 18, y: c.y + dy * 18))
            }
            handles.append((0, c))
        }
        src.path = sp.cgPath
        if o.val("shMask") > 0.5 {
            let mc = CGPoint(x: CGFloat(o.val("shMX")) * 0.01 * W, y: CGFloat(o.val("shMY")) * 0.01 * H)
            let hx = max(CGFloat(o.val("shMW")) * 0.005 * W + CGFloat(o.val("shMEx")) * k, 2)
            let hy = max(CGFloat(o.val("shMH")) * 0.005 * H + CGFloat(o.val("shMEx")) * k, 2)
            ell.path = UIBezierPath(ovalIn: CGRect(x: mc.x - hx, y: mc.y - hy, width: hx * 2, height: hy * 2)).cgPath
            let f = CGFloat(o.val("shMFe")) * k
            fea.path = UIBezierPath(ovalIn: CGRect(x: mc.x - hx - f, y: mc.y - hy - f, width: (hx + f) * 2, height: (hy + f) * 2)).cgPath
            handles += [(1, mc), (2, CGPoint(x: mc.x + hx, y: mc.y)), (3, CGPoint(x: mc.x, y: mc.y + hy))]
        } else { ell.path = nil; fea.path = nil }
        let d = UIBezierPath()
        for h in handles where h.id != 0 { d.append(UIBezierPath(arcCenter: h.p, radius: 5, startAngle: 0, endAngle: .pi * 2, clockwise: true)) }
        dots.path = d.cgPath
    }

    private func nearest(_ l: CGPoint) -> Int? {
        let best = handles.min { hypot($0.p.x - l.x, $0.p.y - l.y) < hypot($1.p.x - l.x, $1.p.y - l.y) }
        guard let b = best, hypot(b.p.x - l.x, b.p.y - l.y) < 32 else { return nil }
        return b.id
    }
    override func point(inside point: CGPoint, with event: UIEvent?) -> Bool { nearest(point) != nil }
    override func touchesBegan(_ t: Set<UITouch>, with e: UIEvent?) { if let l = t.first?.location(in: self) { drag = nearest(l) ?? -1 } }
    override func touchesEnded(_ t: Set<UITouch>, with e: UIEvent?) { drag = -1 }
    override func touchesCancelled(_ t: Set<UITouch>, with e: UIEvent?) { drag = -1 }
    override func touchesMoved(_ t: Set<UITouch>, with e: UIEvent?) {
        guard let o = owner, let l = t.first?.location(in: self), drag >= 0, bounds.width > 1 else { return }
        let W = bounds.width, H = bounds.height, k = H / 1080
        func pct(_ v: CGFloat, _ span: CGFloat) -> Float { Float(v / span * 100) }
        switch drag {
        case 0:
            if o.val("shType") > 0.5 {
                let u = Float((l.x / W) * 2 - 1), v = Float(1 - (l.y / H) * 2)
                if let w = ShineCam.unproject(o.lay, time: Editor.time, width: pw, height: ph, u, v, o.val("shWZ")) {
                    o.set("shWX", min(max(w.0, -4), 4)); o.set("shWY", min(max(w.1, -4), 4))
                }
            } else { o.set("shX", min(max(pct(l.x, W), -50), 150)); o.set("shY", min(max(pct(l.y, H), -50), 150)) }
        case 1: o.set("shMX", min(max(pct(l.x, W), 0), 100)); o.set("shMY", min(max(pct(l.y, H), 0), 100))
        case 2:
            let mc = CGFloat(o.val("shMX")) * 0.01 * W, ex = CGFloat(o.val("shMEx")) * k
            o.set("shMW", min(max(Float((abs(l.x - mc) - ex) / W / 0.005), 1), 200))
        default:
            let mc = CGFloat(o.val("shMY")) * 0.01 * H, ex = CGFloat(o.val("shMEx")) * k
            o.set("shMH", min(max(Float((abs(l.y - mc) - ex) / H / 0.005), 1), 200))
        }
        o.updateVisibility()
    }
}
