// MmdImport.swift — MikuMikuDance import (.pmx / .mmd model + .vmd motion) → GLB (+ ".anim" baked sidecar).
//
// * Model: PMX 2.0 / 2.1 (BDEF1/2/4, SDEF, QDEF). A ".mmd" file is read as PMX when it has a "PMX " header.
// * Textures: every material texture is embedded; the zip is unpacked with its folders so relative paths work.
// * PBR: MMD diffuse/specular/sphere data is mapped to metallic-roughness. Sibling maps beside a texture
//   ("<name>_normal", "_n", "_r"/"_rough", "_m"/"_metal", "_orm", "_ao", "_e"/"_emissive") become normal /
//   roughness / metal / occlusion / emissive maps.
// * Animation: a .vmd (same name, or the first one in the folder) is baked frame by frame — keyframe Bezier
//   curves, parent chain, append (inherit) bones and CCD IK — into the sidecar GlbModel already plays.

import Foundation
import UIKit
import simd
import ImageIO

enum MmdImport {
    static var lastError = ""

    // MARK: binary reader
    private struct R {
        let b: [UInt8]; var p = 0
        init(_ b: [UInt8]) { self.b = b }
        mutating func u8() -> Int { defer { p += 1 }; return p < b.count ? Int(b[p]) : 0 }
        mutating func u16() -> Int { let v = u8(); return v | (u8() << 8) }
        mutating func i32() -> Int { let v = u16() | (u16() << 16); return Int(Int32(truncatingIfNeeded: v)) }
        mutating func f() -> Float { let v = UInt32(truncatingIfNeeded: i32()); return Float(bitPattern: v) }
        mutating func v3() -> SIMD3<Float> { let x = f(), y = f(), z = f(); return [x, y, z] }
        mutating func idx(_ size: Int, signed: Bool = true) -> Int {
            switch size {
            case 1: let v = u8(); return signed ? Int(Int8(truncatingIfNeeded: v)) : v
            case 2: let v = u16(); return signed ? Int(Int16(truncatingIfNeeded: v)) : v
            default: return i32()
            }
        }
        mutating func bytes(_ n: Int) -> [UInt8] { let e = min(b.count, p + max(n, 0)); defer { p = e }; return Array(b[min(p, e)..<e]) }
    }

    // MARK: PMX model
    private struct Bone { var name = ""; var pos = SIMD3<Float>(0, 0, 0); var parent = -1; var layer = 0; var flags = 0
        var inhParent = -1; var inhInfl: Float = 0
        var ikTarget = -1; var ikLoop = 0; var ikLimit: Float = 0; var ikLinks: [(Int, Bool, SIMD3<Float>, SIMD3<Float>)] = [] }
    private struct Vtx { var p = SIMD3<Float>(0, 0, 0), n = SIMD3<Float>(0, 1, 0), uv = SIMD2<Float>(0, 0)
        var bi: [Int] = [], bw: [Float] = [] }
    private struct Mat { var name = ""; var diff = SIMD4<Float>(1, 1, 1, 1); var spec = SIMD3<Float>(0, 0, 0); var power: Float = 5
        var amb = SIMD3<Float>(0, 0, 0); var flags = 0; var tex = -1; var sphere = -1; var sphereMode = 0; var count = 0 }

    /// Returns the .glb written beside the model (cached by modification date), or nil with lastError set.
    static func convert(_ path: String, vmd: String? = nil) -> String? {
        lastError = ""
        let fm = FileManager.default
        let stem = (path as NSString).deletingPathExtension
        let vtag = vmd.map { "_" + String(((($0 as NSString).lastPathComponent as NSString).deletingPathExtension).unicodeScalars.map { $0.isASCII && ($0.properties.isAlphabetic || ("0"..."9").contains(Character($0))) ? Character($0) : "x" }.prefix(24)) } ?? ""
        let out = stem + "_mmd" + vtag + ".glb"
        let dir = (path as NSString).deletingLastPathComponent
        let vmdPath = vmd ?? findVmd(stem: stem, dir: dir)
        func mod(_ p: String?) -> Date? { p.flatMap { (try? fm.attributesOfItem(atPath: $0))?[.modificationDate] as? Date } }
        if let o = mod(out), let a = mod(path), o > a, (mod(vmdPath).map { o > $0 } ?? true) { return out }
        guard let data = fm.contents(atPath: path), data.count > 100 else { lastError = "Cannot read the MMD file"; return nil }
        var r = R([UInt8](data))
        guard r.bytes(4) == Array("PMX ".utf8) else {
            lastError = "Only PMX models are supported (PMD: convert it to PMX in PMX Editor)"; return nil
        }
        let ver = r.f()
        let gn = r.u8()
        var g = [Int](repeating: 1, count: 8)
        for i in 0..<gn { let v = r.u8(); if i < 8 { g[i] = v } }
        let utf8 = g[0] == 1, uvAdd = g[1], vS = g[2], tS = g[3], mS = g[4], bS = g[5]
        func text(_ r: inout R) -> String {
            let n = r.i32(); guard n > 0, n < 1_000_000 else { return "" }
            return String(data: Data(r.bytes(n)), encoding: utf8 ? .utf8 : .utf16LittleEndian) ?? ""
        }
        for _ in 0..<4 { _ = text(&r) }
        _ = ver

        let vc = r.i32()
        guard vc > 0, vc < 3_000_000 else { lastError = "PMX has no vertices"; return nil }
        var vs = [Vtx](); vs.reserveCapacity(vc)
        for _ in 0..<vc {
            var v = Vtx()
            v.p = r.v3(); v.n = r.v3(); v.uv = [r.f(), r.f()]
            for _ in 0..<(uvAdd * 4) { _ = r.f() }
            switch r.u8() {
            case 0: v.bi = [r.idx(bS)]; v.bw = [1]
            case 1: let a = r.idx(bS), b = r.idx(bS), w = r.f(); v.bi = [a, b]; v.bw = [w, 1 - w]
            case 2, 4: let a = r.idx(bS), b = r.idx(bS), c = r.idx(bS), d = r.idx(bS)
                v.bi = [a, b, c, d]; v.bw = [r.f(), r.f(), r.f(), r.f()]
            case 3: let a = r.idx(bS), b = r.idx(bS), w = r.f(); v.bi = [a, b]; v.bw = [w, 1 - w]
                _ = r.v3(); _ = r.v3(); _ = r.v3()
            default: lastError = "Unsupported PMX vertex weights"; return nil
            }
            _ = r.f()
            vs.append(v)
        }
        let ic = r.i32()
        guard ic >= 3, ic < 30_000_000 else { lastError = "PMX has no faces"; return nil }
        var faces = [Int](repeating: 0, count: ic)
        for i in 0..<ic { faces[i] = r.idx(vS, signed: false) }
        var texNames: [String] = []
        for _ in 0..<r.i32() { texNames.append(text(&r)) }
        var mats: [Mat] = []
        for _ in 0..<r.i32() {
            var m = Mat()
            m.name = text(&r); _ = text(&r)
            m.diff = [r.f(), r.f(), r.f(), r.f()]; m.spec = r.v3(); m.power = r.f(); m.amb = r.v3()
            m.flags = r.u8()
            for _ in 0..<5 { _ = r.f() }                  // edge colour + size
            m.tex = r.idx(tS); m.sphere = r.idx(tS); m.sphereMode = r.u8()
            if r.u8() == 0 { _ = r.idx(tS) } else { _ = r.u8() }
            _ = text(&r)
            m.count = r.i32()
            mats.append(m)
        }
        var bones: [Bone] = []
        for _ in 0..<r.i32() {
            var b = Bone()
            b.name = text(&r); _ = text(&r)
            b.pos = r.v3(); b.parent = r.idx(bS); b.layer = r.i32(); b.flags = r.u16()
            if b.flags & 1 != 0 { _ = r.idx(bS) } else { _ = r.v3() }
            if b.flags & 0x300 != 0 { b.inhParent = r.idx(bS); b.inhInfl = r.f() }
            if b.flags & 0x400 != 0 { _ = r.v3() }
            if b.flags & 0x800 != 0 { _ = r.v3(); _ = r.v3() }
            if b.flags & 0x2000 != 0 { _ = r.i32() }
            if b.flags & 0x20 != 0 {
                b.ikTarget = r.idx(bS); b.ikLoop = r.i32(); b.ikLimit = r.f()
                for _ in 0..<max(0, min(r.i32(), 64)) {
                    let li = r.idx(bS); let has = r.u8() != 0
                    var lo = SIMD3<Float>(0, 0, 0), hi = lo
                    if has { lo = r.v3(); hi = r.v3() }
                    b.ikLinks.append((li, has, lo, hi))
                }
            }
            bones.append(b)
        }
        guard r.p <= r.b.count else { lastError = "PMX file is truncated"; return nil }

        // folder index for textures / PBR maps
        var files: [String: String] = [:]                 // lowercased relative path & file name → path
        if let en = fm.enumerator(atPath: dir) {
            for case let rel as String in en {
                let full = dir + "/" + rel
                files[rel.lowercased()] = full
                files[((rel as NSString).lastPathComponent).lowercased()] = files[((rel as NSString).lastPathComponent).lowercased()] ?? full
            }
        }
        func resolve(_ name: String) -> String? {
            let n = name.replacingOccurrences(of: "\\", with: "/")
            if fm.fileExists(atPath: dir + "/" + n) { return dir + "/" + n }
            return files[n.lowercased()] ?? files[(n as NSString).lastPathComponent.lowercased()]
        }
        func loadImage(_ p: String) -> UIImage? {
            guard let src = CGImageSourceCreateWithURL(URL(fileURLWithPath: p) as CFURL, nil),
                  let cg = CGImageSourceCreateImageAtIndex(src, 0, nil) else { return UIImage(contentsOfFile: p) }
            return UIImage(cgImage: cg)
        }
        func sibling(_ basePath: String, _ suffixes: [String]) -> UIImage? {
            let d = (basePath as NSString).deletingLastPathComponent
            let st = ((basePath as NSString).lastPathComponent as NSString).deletingPathExtension.lowercased()
            for s in suffixes {
                for e in ["png", "jpg", "jpeg", "tga", "bmp"] {
                    let k = st + s + "." + e
                    if let f = files[k] ?? files[(d as NSString).lastPathComponent.lowercased() + "/" + k], let im = loadImage(f) { return im }
                }
            }
            return nil
        }
        func pixels(_ img: UIImage, _ w: Int, _ h: Int) -> [UInt8]? {
            guard let cg = img.cgImage else { return nil }
            var d = [UInt8](repeating: 0, count: w * h * 4)
            guard let c = CGContext(data: &d, width: w, height: h, bitsPerComponent: 8, bytesPerRow: w * 4, space: CGColorSpaceCreateDeviceRGB(),
                                    bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return nil }
            c.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h)); return d
        }
        func png(_ d: [UInt8], _ w: Int, _ h: Int) -> Data? {
            var dd = d
            guard let c = CGContext(data: &dd, width: w, height: h, bitsPerComponent: 8, bytesPerRow: w * 4, space: CGColorSpaceCreateDeviceRGB(),
                                    bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue), let cg = c.makeImage() else { return nil }
            return UIImage(cgImage: cg).pngData()
        }

        // GLB assembly
        var bin = [UInt8]()
        var views: [[String: Any]] = [], accs: [[String: Any]] = [], images: [[String: Any]] = [], textures: [[String: Any]] = []
        func addView(_ bytes: [UInt8], target: Int? = nil) -> Int {
            while bin.count % 4 != 0 { bin.append(0) }
            var v: [String: Any] = ["buffer": 0, "byteOffset": bin.count, "byteLength": bytes.count]
            if let t = target { v["target"] = t }
            bin.append(contentsOf: bytes); views.append(v); return views.count - 1
        }
        func fb(_ a: [Float]) -> [UInt8] { a.withUnsafeBytes { Array($0) } }
        var texCache: [Data: Int] = [:]
        func addTex(_ d: Data) -> Int {
            if let t = texCache[d] { return t }
            let v = addView([UInt8](d))
            images.append(["bufferView": v, "mimeType": "image/png"]); textures.append(["source": images.count - 1])
            texCache[d] = textures.count - 1; return textures.count - 1
        }
        var matJson: [[String: Any]] = []
        func glMat(_ m: Mat) -> [String: Any] {
            var pbr: [String: Any] = [:]
            var j: [String: Any] = ["doubleSided": m.flags & 1 != 0 || true]
            let a = min(max(m.diff.w, 0), 1)
            let specL = (m.spec.x + m.spec.y + m.spec.z) / 3
            var rough = min(max(1 - (min(m.power, 120) / 120) * min(specL * 1.5, 1) * 0.9, 0.3), 0.95)
            var metal: Float = (m.sphere >= 0 && m.sphereMode >= 2) ? 0.25 : 0
            var base: UIImage? = nil, basePath = ""
            if m.tex >= 0, m.tex < texNames.count, let p = resolve(texNames[m.tex]) { base = loadImage(p); basePath = p }
            pbr["baseColorFactor"] = [m.diff.x, m.diff.y, m.diff.z, a]
            if let img = base, let d = img.pngData() { pbr["baseColorTexture"] = ["index": addTex(d)]; pbr["baseColorFactor"] = [m.diff.x, m.diff.y, m.diff.z, a]
                j["alphaMode"] = a < 0.999 ? "BLEND" : "MASK"; j["alphaCutoff"] = 0.5 }
            else if a < 0.999 { j["alphaMode"] = "BLEND" }
            if !basePath.isEmpty {
                let ref = base!
                let w = min(2048, max(1, Int(ref.size.width * ref.scale))), h = min(2048, max(1, Int(ref.size.height * ref.scale)))
                if let n = sibling(basePath, ["_normal", "_n", "_nrm", "_nor"]), let d = n.pngData() { j["normalTexture"] = ["index": addTex(d)] }
                if let e = sibling(basePath, ["_emissive", "_emit", "_e", "_emission"]), let d = e.pngData() { j["emissiveTexture"] = ["index": addTex(d)]; j["emissiveFactor"] = [1, 1, 1] }
                let orm = sibling(basePath, ["_orm", "_rma"])
                let ao = sibling(basePath, ["_ao", "_occlusion", "_occ"])
                let ri = sibling(basePath, ["_roughness", "_rough", "_r"]), mi = sibling(basePath, ["_metallic", "_metal", "_m"])
                if let o = orm, let d = o.pngData() { pbr["metallicRoughnessTexture"] = ["index": addTex(d)]; rough = 1; metal = 1
                    j["occlusionTexture"] = ["index": addTex(d)] }
                else if ri != nil || mi != nil {
                    var d = [UInt8](repeating: 255, count: w * h * 4)
                    let rp = ri.flatMap { pixels($0, w, h) }, mp = mi.flatMap { pixels($0, w, h) }
                    for i in 0..<(w * h) { d[i * 4] = 255; d[i * 4 + 1] = rp?[i * 4] ?? UInt8(rough * 255); d[i * 4 + 2] = mp?[i * 4] ?? UInt8(metal * 255) }
                    if let data = png(d, w, h) { pbr["metallicRoughnessTexture"] = ["index": addTex(data)]; rough = 1; metal = 1 }
                }
                if j["occlusionTexture"] == nil, let o = ao, let d = o.pngData() { j["occlusionTexture"] = ["index": addTex(d)] }
            }
            pbr["roughnessFactor"] = rough; pbr["metallicFactor"] = metal
            j["pbrMetallicRoughness"] = pbr
            return j
        }

        // primitives: one per material, own vertex subset (so the baked animation indexes them directly)
        struct Prim { var gv: [Int] = []; var idx: [UInt32] = [] }
        var prims: [[String: Any]] = [], pinfo: [Prim] = []
        var fi = 0
        for m in mats {
            let n = min(m.count, faces.count - fi)
            guard n >= 3 else { fi += max(m.count, 0); continue }
            var remap: [Int: UInt32] = [:]; var pr = Prim()
            for k in 0..<n {
                let v = min(faces[fi + k], vs.count - 1)
                if let l = remap[v] { pr.idx.append(l) } else { let l = UInt32(pr.gv.count); remap[v] = l; pr.gv.append(v); pr.idx.append(l) }
            }
            fi += m.count
            var pos: [Float] = [], nor: [Float] = [], uv: [Float] = []
            var mn: [Float] = [.infinity, .infinity, .infinity], mx: [Float] = [-.infinity, -.infinity, -.infinity]
            for v in pr.gv {
                let q = vs[v]; let P = [q.p.x, q.p.y, -q.p.z]
                pos += P; nor += [q.n.x, q.n.y, -q.n.z]; uv += [q.uv.x, q.uv.y]
                for c in 0..<3 { mn[c] = min(mn[c], P[c]); mx[c] = max(mx[c], P[c]) }
            }
            let vP = addView(fb(pos), target: 34962), vN = addView(fb(nor), target: 34962), vU = addView(fb(uv), target: 34962)
            let vI = addView(pr.idx.withUnsafeBytes { Array($0) }, target: 34963)
            accs.append(["bufferView": vP, "componentType": 5126, "count": pr.gv.count, "type": "VEC3", "min": mn, "max": mx]); let aP = accs.count - 1
            accs.append(["bufferView": vN, "componentType": 5126, "count": pr.gv.count, "type": "VEC3"]); let aN = accs.count - 1
            accs.append(["bufferView": vU, "componentType": 5126, "count": pr.gv.count, "type": "VEC2"]); let aU = accs.count - 1
            accs.append(["bufferView": vI, "componentType": 5125, "count": pr.idx.count, "type": "SCALAR"]); let aI = accs.count - 1
            matJson.append(glMat(m))
            prims.append(["attributes": ["POSITION": aP, "NORMAL": aN, "TEXCOORD_0": aU], "indices": aI, "mode": 4, "material": matJson.count - 1])
            pinfo.append(pr)
        }
        guard !prims.isEmpty else { lastError = "PMX has no drawable faces"; return nil }
        var root: [String: Any] = [
            "asset": ["version": "2.0", "generator": "SaikiMotion MMD Import"],
            "scene": 0, "scenes": [["nodes": [0]]], "nodes": [["mesh": 0]],
            "meshes": [["primitives": prims]], "materials": matJson,
            "buffers": [["byteLength": bin.count]], "bufferViews": views, "accessors": accs
        ]
        if !images.isEmpty { root["images"] = images; root["textures"] = textures }
        guard var js = try? JSONSerialization.data(withJSONObject: root) else { lastError = "MMD conversion failed"; return nil }
        while js.count % 4 != 0 { js.append(0x20) }
        while bin.count % 4 != 0 { bin.append(0) }
        var glb = Data()
        func le(_ v: UInt32) { var x = v.littleEndian; withUnsafeBytes(of: &x) { glb.append(contentsOf: $0) } }
        le(0x46546C67); le(2); le(UInt32(12 + 8 + js.count + 8 + bin.count))
        le(UInt32(js.count)); le(0x4E4F534A); glb.append(js)
        le(UInt32(bin.count)); le(0x004E4942); glb.append(contentsOf: bin)
        guard (try? glb.write(to: URL(fileURLWithPath: out))) != nil else { lastError = "Cannot write converted MMD"; return nil }
        try? fm.removeItem(atPath: out + ".anim")

        if let vp = vmdPath, let vd = fm.contents(atPath: vp) {
            bakeVmd([UInt8](vd), bones: bones, verts: vs, prims: pinfo.map { $0.gv }, out: out + ".anim")
        }
        return out
    }

    /// Standalone .vmd: bakes the motion onto the PMX model that `modelGlb` (a converted *_mmd*.glb) came from.
    /// Returns the new .glb (new path, so cached models are never stale), or nil with lastError set.
    static func applyVmd(_ vmd: String, toModelGlb modelGlb: String) -> String? {
        lastError = ""
        let name = (modelGlb as NSString).lastPathComponent
        guard let r = name.range(of: "_mmd") else { lastError = "Select an imported MMD (.pmx) model first, then import the .vmd"; return nil }
        let dir = (modelGlb as NSString).deletingLastPathComponent, stem = String(name[..<r.lowerBound])
        for e in ["pmx", "mmd", "PMX", "MMD"] {
            let p = dir + "/" + stem + "." + e
            if FileManager.default.fileExists(atPath: p) { return convert(p, vmd: vmd) }
        }
        lastError = "The original .pmx of this model is missing — re-import the model, then the .vmd"; return nil
    }

    // MARK: VMD animation
    private struct Key { var f: Int; var pos: SIMD3<Float>; var rot: simd_quatf; var c: [UInt8] }

    private static func findVmd(stem: String, dir: String) -> String? {
        let fm = FileManager.default
        if fm.fileExists(atPath: stem + ".vmd") { return stem + ".vmd" }
        let all = (try? fm.contentsOfDirectory(atPath: dir)) ?? []
        return all.filter { $0.lowercased().hasSuffix(".vmd") }.sorted().first.map { dir + "/" + $0 }
    }

    private static func bez(_ c: [UInt8], _ k: Int, _ t: Float) -> Float {     // k: 0 X, 1 Y, 2 Z, 3 rotation
        guard c.count >= 16 else { return t }
        let x1 = Float(c[k]) / 127, y1 = Float(c[4 + k]) / 127, x2 = Float(c[8 + k]) / 127, y2 = Float(c[12 + k]) / 127
        if abs(x1 - y1) < 0.001 && abs(x2 - y2) < 0.001 { return t }
        var lo: Float = 0, hi: Float = 1, s = t
        for _ in 0..<14 {
            s = (lo + hi) / 2
            let x = 3 * (1 - s) * (1 - s) * s * x1 + 3 * (1 - s) * s * s * x2 + s * s * s
            if x < t { lo = s } else { hi = s }
        }
        return 3 * (1 - s) * (1 - s) * s * y1 + 3 * (1 - s) * s * s * y2 + s * s * s
    }

    private static func bakeVmd(_ b: [UInt8], bones: [Bone], verts: [Vtx], prims: [[Int]], out: String) {
        guard b.count > 54 else { return }
        var r = R(b); r.p = 50
        let n = Int(UInt32(truncatingIfNeeded: r.i32()))
        guard n > 0, 54 + n * 111 <= b.count else { return }
        var byName: [String: Int] = [:]
        for (i, bn) in bones.enumerated() where byName[bn.name] == nil { byName[bn.name] = i }
        var keys = [[Key]](repeating: [], count: bones.count)
        var last = 0
        for _ in 0..<n {
            var raw = r.bytes(15); if let z = raw.firstIndex(of: 0) { raw = Array(raw[..<z]) }
            let name = String(data: Data(raw), encoding: .shiftJIS) ?? ""
            let f = Int(UInt32(truncatingIfNeeded: r.i32()))
            let p = r.v3(), q = simd_quatf(ix: r.f(), iy: r.f(), iz: r.f(), r: r.f())
            let c = r.bytes(64)
            if let bi = byName[name] { keys[bi].append(Key(f: f, pos: p, rot: simd_normalize(q), c: c)); last = max(last, f) }
        }
        for i in keys.indices { keys[i].sort { $0.f < $1.f } }
        guard last > 0 else { return }
        let fps: Float = 30
        let total = prims.reduce(0) { $0 + $1.count }
        var nf = last + 1
        let maxF = max(2, 200_000_000 / max(total * 24, 1))
        var step = 1; if nf > maxF { step = (nf + maxF - 1) / maxF; nf = (nf + step - 1) / step }
        guard nf > 1 else { return }

        let nb = bones.count
        let order = (0..<nb).sorted { (bones[$0].layer, $0) < (bones[$1].layer, $1) }
        var own = [simd_quatf](repeating: simd_quatf(ix: 0, iy: 0, iz: 0, r: 1), count: nb)
        var eff = own, vp = [SIMD3<Float>](repeating: .zero, count: nb), etr = vp
        var world = [simd_float4x4](repeating: matrix_identity_float4x4, count: nb)
        var done = [Bool](repeating: false, count: nb)
        func T(_ v: SIMD3<Float>) -> simd_float4x4 { var m = matrix_identity_float4x4; m.columns.3 = SIMD4(v, 1); return m }
        func restOff(_ i: Int) -> SIMD3<Float> { bones[i].pos - (bones[i].parent >= 0 && bones[i].parent < nb ? bones[bones[i].parent].pos : .zero) }
        func w(_ i: Int, _ d: Int = 0) -> simd_float4x4 {
            if done[i] || d > 64 { return world[i] }
            let loc = T(restOff(i) + etr[i]) * simd_float4x4(eff[i])
            let p = bones[i].parent
            world[i] = (p >= 0 && p < nb) ? w(p, d + 1) * loc : loc
            done[i] = true; return world[i]
        }
        func inherit(_ i: Int) {
            let bn = bones[i]
            eff[i] = own[i]; etr[i] = vp[i]
            guard bn.inhParent >= 0, bn.inhParent < nb else { return }
            if bn.flags & 0x100 != 0 {
                let q = simd_slerp(simd_quatf(ix: 0, iy: 0, iz: 0, r: 1), eff[bn.inhParent], bn.inhInfl)
                eff[i] = simd_normalize(own[i] * q)
            }
            if bn.flags & 0x200 != 0 { etr[i] = vp[i] + etr[bn.inhParent] * bn.inhInfl }
        }
        func solveIK(_ ik: Int) {
            let bn = bones[ik]
            guard bn.ikTarget >= 0, bn.ikTarget < nb, !bn.ikLinks.isEmpty else { return }
            let tgt = bn.ikTarget
            let target = SIMD3<Float>(w(ik).columns.3.x, w(ik).columns.3.y, w(ik).columns.3.z)
            var chain: [Int] = []; var c = tgt             // effector → top link
            let top = bn.ikLinks.last!.0
            for _ in 0..<64 { chain.append(c); if c == top { break }; c = bones[c].parent; if c < 0 { break } }
            let path = chain.reversed()
            var accX = [Float](repeating: 0, count: bn.ikLinks.count)
            for _ in 0..<max(1, min(bn.ikLoop, 24)) {
                for (li, link) in bn.ikLinks.enumerated() where link.0 >= 0 && link.0 < nb {
                    let lb = link.0
                    let M = w(lb), inv = M.inverse
                    let ew = w(tgt).columns.3
                    let le = simd_normalize(SIMD3((inv * ew).x, (inv * ew).y, (inv * ew).z))
                    let lt = simd_normalize(SIMD3((inv * SIMD4(target, 1)).x, (inv * SIMD4(target, 1)).y, (inv * SIMD4(target, 1)).z))
                    let dt = min(1, max(-1, simd_dot(le, lt)))
                    var ang = acos(dt)
                    if ang < 1e-5 || !ang.isFinite { continue }
                    ang = min(ang, bn.ikLimit > 0 ? bn.ikLimit : ang)
                    var axis = simd_cross(le, lt)
                    if simd_length(axis) < 1e-8 { continue }
                    axis = simd_normalize(axis)
                    var dq: simd_quatf
                    if link.1, link.2.y == 0, link.3.y == 0, link.2.z == 0, link.3.z == 0 {       // knee-like: X axis only
                        let s: Float = axis.x >= 0 ? 1 : -1
                        let nx = min(max(accX[li] + s * ang, link.2.x), link.3.x)
                        let d = nx - accX[li]; accX[li] = nx
                        dq = simd_quatf(angle: d, axis: SIMD3(1, 0, 0))
                    } else {
                        dq = simd_quatf(angle: ang, axis: axis)
                    }
                    own[lb] = simd_normalize(own[lb] * dq)
                    inherit(lb)
                    for p in path { done[p] = false }
                    for p in path { _ = w(p) }
                }
            }
        }

        var side = Data()
        func le32(_ v: UInt32) { var x = v.littleEndian; withUnsafeBytes(of: &x) { side.append(contentsOf: $0) } }
        le32(0x41424153); le32(UInt32(nf)); var fp = fps / Float(step); withUnsafeBytes(of: &fp) { side.append(contentsOf: $0) }; le32(UInt32(prims.count))
        for p in prims { le32(UInt32(p.count)) }

        for fr in 0..<nf {
            let f = fr * step
            for i in 0..<nb {
                let ks = keys[i]
                if ks.isEmpty { own[i] = simd_quatf(ix: 0, iy: 0, iz: 0, r: 1); vp[i] = .zero; continue }
                var k1 = ks.count - 1
                if let ix = ks.firstIndex(where: { $0.f > f }) { k1 = ix }
                let a = ks[max(0, ks[k1].f > f ? k1 - 1 : k1)], bk = ks[k1]
                if bk.f <= f || a.f == bk.f { own[i] = bk.rot; vp[i] = bk.pos; if bk.f > f { own[i] = a.rot; vp[i] = a.pos } }
                else {
                    let t = Float(f - a.f) / Float(bk.f - a.f)
                    own[i] = simd_slerp(a.rot, bk.rot, bez(bk.c, 3, t))
                    vp[i] = SIMD3(a.pos.x + (bk.pos.x - a.pos.x) * bez(bk.c, 0, t),
                                  a.pos.y + (bk.pos.y - a.pos.y) * bez(bk.c, 1, t),
                                  a.pos.z + (bk.pos.z - a.pos.z) * bez(bk.c, 2, t))
                }
            }
            for i in 0..<nb { done[i] = false }
            for i in order {
                inherit(i)
                done[i] = false
                if bones[i].ikTarget >= 0 { _ = w(i); solveIK(i) }
            }
            for i in order { inherit(i) }
            for i in 0..<nb { done[i] = false }
            for i in 0..<nb { _ = w(i) }
            var skin = [simd_float4x4](repeating: matrix_identity_float4x4, count: nb)
            for i in 0..<nb { skin[i] = world[i] * T(-bones[i].pos) }
            for gv in prims {
                var P = [Float](), N = [Float]()
                P.reserveCapacity(gv.count * 3); N.reserveCapacity(gv.count * 3)
                for v in gv {
                    let q = verts[v]
                    var p = SIMD3<Float>.zero, nn = SIMD3<Float>.zero
                    for (k, bi) in q.bi.enumerated() where bi >= 0 && bi < nb {
                        let m = skin[bi], wgt = q.bw[k]
                        let pp = m * SIMD4(q.p, 1), nr = m * SIMD4(q.n, 0)
                        p += SIMD3(pp.x, pp.y, pp.z) * wgt; nn += SIMD3(nr.x, nr.y, nr.z) * wgt
                    }
                    if q.bi.isEmpty { p = q.p; nn = q.n }
                    let l = max(simd_length(nn), 1e-6)
                    P += [p.x, p.y, -p.z]; N += [nn.x / l, nn.y / l, -nn.z / l]
                }
                P.withUnsafeBytes { side.append(contentsOf: $0) }; N.withUnsafeBytes { side.append(contentsOf: $0) }
            }
        }
        try? side.write(to: URL(fileURLWithPath: out))
    }

    // MARK: zip with folders (textures keep their relative paths)

    /// If the archive holds a .pmx / .mmd, unpacks the whole archive (folders kept) and returns the model path.
    static func unzipAll(_ path: String) -> String? {
        guard let d = FileManager.default.contents(atPath: path), d.count > 22 else { return nil }
        let b = [UInt8](d)
        func r16(_ o: Int) -> Int { o + 2 <= b.count ? Int(b[o]) | Int(b[o + 1]) << 8 : 0 }
        func r32(_ o: Int) -> Int { r16(o) | (r16(o + 2) << 16) }
        var e = b.count - 22
        while e >= 0, r32(e) != 0x06054b50 { e -= 1 }
        guard e >= 0 else { return nil }
        var n = r16(e + 10), p = r32(e + 16)
        var entries: [(String, Int, Int, Int)] = []
        while n > 0, p + 46 <= b.count, r32(p) == 0x02014b50 {
            let method = r16(p + 10), cs = r32(p + 20), nl = r16(p + 28), el = r16(p + 30), cl = r16(p + 32), lo = r32(p + 42)
            let nm = Array(b[(p + 46)..<min(b.count, p + 46 + nl)])
            let name = String(bytes: nm, encoding: .utf8) ?? String(data: Data(nm), encoding: .shiftJIS) ?? String(decoding: nm, as: UTF8.self)
            entries.append((name, method, cs, lo)); n -= 1; p += 46 + nl + el + cl
        }
        guard let model = entries.first(where: { ["pmx", "mmd"].contains(($0.0 as NSString).pathExtension.lowercased()) && !$0.0.hasPrefix("__MACOSX") }) else { return nil }
        let root = (path as NSString).deletingPathExtension + "_mmd"
        let fm = FileManager.default
        var result: String? = nil
        for (name, method, cs, lo) in entries where !name.hasSuffix("/") && !name.hasPrefix("__MACOSX") && !name.contains("..") {
            guard lo + 30 <= b.count else { continue }
            let ds = lo + 30 + r16(lo + 26) + r16(lo + 28)
            guard ds + cs <= b.count else { continue }
            let raw = Array(b[ds..<(ds + cs)])
            let data = method == 0 ? raw : (method == 8 ? VdbVolume.inflate(raw) : [])
            guard !data.isEmpty else { continue }
            let dst = root + "/" + name
            try? fm.createDirectory(atPath: (dst as NSString).deletingLastPathComponent, withIntermediateDirectories: true)
            try? Data(data).write(to: URL(fileURLWithPath: dst))
            if name == model.0 { result = dst }
        }
        return result
    }
}
