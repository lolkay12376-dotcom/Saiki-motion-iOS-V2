// LightPanel.swift — Scene 3D "+" > Lighting. Full panel: add Directional / Spot / Point lights, any colour each, edit them all in one place.
import UIKit

final class LightPanel: UIView {
    private weak var host: EditorViewController?
    private let accent = UIColor(red: 1, green: 0.55, blue: 0.08, alpha: 1)
    private let list = UIStackView()
    private let palette: [UInt32] = [0xFFFF3B30, 0xFFFF9500, 0xFFFFD60A, 0xFF34C759, 0xFF00C7BE, 0xFF0A84FF, 0xFFBF5AF2, 0xFFFF2D92, 0xFFFFF2D8, 0xFFFFFFFF]
    private var nextHue = 0

    static func present(in host: EditorViewController, over view: UIView) {
        if view.subviews.contains(where: { $0 is LightPanel }) { return }
        let v = LightPanel(host: host)
        v.translatesAutoresizingMaskIntoConstraints = false; view.addSubview(v)
        NSLayoutConstraint.activate([v.leadingAnchor.constraint(equalTo: view.leadingAnchor), v.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                                     v.topAnchor.constraint(equalTo: view.topAnchor), v.bottomAnchor.constraint(equalTo: view.bottomAnchor)])
    }

    init(host: EditorViewController) {
        self.host = host
        super.init(frame: .zero)
        backgroundColor = UIColor(white: 0, alpha: 0.55)
        build(); reload()
    }
    required init?(coder: NSCoder) { fatalError() }

    private func label(_ t: String, _ size: CGFloat = 13, _ w: UIFont.Weight = .regular, _ c: UIColor = UIColor(white: 0.75, alpha: 1)) -> UILabel {
        let l = UILabel(); l.text = t; l.textColor = c; l.font = .systemFont(ofSize: size, weight: w); return l
    }
    private func rgb(_ c: UInt32) -> UIColor { UIColor(red: CGFloat((c >> 16) & 255) / 255, green: CGFloat((c >> 8) & 255) / 255, blue: CGFloat(c & 255) / 255, alpha: 1) }
    private func argb(_ col: UIColor) -> UInt32 {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0; col.getRed(&r, green: &g, blue: &b, alpha: &a)
        return 0xFF000000 | UInt32(r * 255) << 16 | UInt32(g * 255) << 8 | UInt32(b * 255)
    }
    private func changed() { host?.render() }

    private func slider(_ title: String, _ lo: Float, _ hi: Float, _ v: Float, _ fmt: String = "%.2f", _ cb: @escaping (Float) -> Void) -> UIStackView {
        let l = label(title); l.widthAnchor.constraint(equalToConstant: 92).isActive = true
        let val = label(String(format: fmt, v), 12); val.textAlignment = .right; val.widthAnchor.constraint(equalToConstant: 56).isActive = true
        let s = UISlider(); s.minimumValue = lo; s.maximumValue = hi; s.value = min(max(v, lo), hi); s.tintColor = accent
        s.addAction(UIAction { [weak self] _ in self?.host?.pushUndo() }, for: .touchDown)
        s.addAction(UIAction { [weak self, weak s, weak val] _ in guard let s = s else { return }; val?.text = String(format: fmt, s.value); cb(s.value); self?.changed() }, for: .valueChanged)
        let r = UIStackView(arrangedSubviews: [l, s, val]); r.spacing = 8; r.alignment = .center; return r
    }

    private func addButton(_ title: String, _ icon: String, _ type: Int) -> UIButton {
        var c = UIButton.Configuration.filled(); c.title = title; c.image = Icons.sf( icon); c.imagePlacement = .top; c.imagePadding = 4
        c.baseBackgroundColor = UIColor(white: 0.18, alpha: 1); c.baseForegroundColor = .white; c.cornerStyle = .large
        let b = UIButton(configuration: c)
        b.addAction(UIAction { [weak self] _ in
            guard let self = self, let h = self.host else { return }
            h.pushUndo()
            _ = h.addLight(type: type, color: self.palette[self.nextHue % 8]); self.nextHue += 1      // each new light gets the next colour
            self.reload()
        }, for: .touchUpInside)
        return b
    }

    private func build() {
        let card = UIView(); card.backgroundColor = UIColor(white: 0.09, alpha: 1); card.layer.cornerRadius = 22
        card.translatesAutoresizingMaskIntoConstraints = false; addSubview(card)
        let x = UIButton(type: .system); x.setImage(Icons.sf( "xmark"), for: .normal); x.tintColor = .white
        x.addAction(UIAction { [weak self] _ in self?.removeFromSuperview() }, for: .touchUpInside)
        let head = UIStackView(arrangedSubviews: [label("Lighting", 22, .bold, .white), UIView(), x]); head.alignment = .center
        let adds = UIStackView(arrangedSubviews: [addButton("Directional", "sun.max.fill", 1), addButton("Spotlight", "flashlight.on.fill", 2), addButton("Point", "lightbulb.fill", 0)])
        adds.distribution = .fillEqually; adds.spacing = 8
        let envS = slider("Env strength", 0, 3, R3D.g("env", 1)) { R3D.set("env", $0) }      // an HDRI can drown a light: turn it down here
        let hint = label("Every light can have its own colour. They light models, PBR, terrain, water and volumes.", 12)
        hint.numberOfLines = 2
        let scroll = UIScrollView(); scroll.alwaysBounceVertical = true
        list.axis = .vertical; list.spacing = 10; list.translatesAutoresizingMaskIntoConstraints = false; scroll.addSubview(list)
        let top = UIStackView(arrangedSubviews: [head, adds, envS, hint]); top.axis = .vertical; top.spacing = 10
        top.translatesAutoresizingMaskIntoConstraints = false; scroll.translatesAutoresizingMaskIntoConstraints = false
        card.addSubview(top); card.addSubview(scroll)
        NSLayoutConstraint.activate([
            card.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 12), card.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -12),
            card.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor, constant: 40), card.bottomAnchor.constraint(equalTo: safeAreaLayoutGuide.bottomAnchor, constant: -12),
            top.leadingAnchor.constraint(equalTo: card.leadingAnchor, constant: 16), top.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -16),
            top.topAnchor.constraint(equalTo: card.topAnchor, constant: 16),
            scroll.topAnchor.constraint(equalTo: top.bottomAnchor, constant: 12), scroll.bottomAnchor.constraint(equalTo: card.bottomAnchor, constant: -8),
            scroll.leadingAnchor.constraint(equalTo: card.leadingAnchor, constant: 16), scroll.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -16),
            list.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor), list.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor),
            list.leadingAnchor.constraint(equalTo: scroll.frameLayoutGuide.leadingAnchor), list.trailingAnchor.constraint(equalTo: scroll.frameLayoutGuide.trailingAnchor)])
    }

    private func reload() {
        list.arrangedSubviews.forEach { $0.removeFromSuperview() }
        let ls = Editor.scene.layers.filter { $0.isLight }
        if ls.isEmpty { list.addArrangedSubview(label("No lights yet. Add one above.", 14)) }
        for l in ls { list.addArrangedSubview(card(l)) }
        host?.render()
    }

    private func card(_ l: Layer) -> UIView {
        let box = UIView(); box.backgroundColor = UIColor(white: 0.14, alpha: 1); box.layer.cornerRadius = 14
        let type = Int(l.xf("lightType", 0))
        let name = label(l.name, 15, .semibold, .white)
        let well = UIColorWell(); well.supportsAlpha = false; well.selectedColor = rgb(UInt32(bitPattern: l.vdbTint))
        well.addAction(UIAction { [weak self, weak well] _ in
            guard let self = self, let c = well?.selectedColor else { return }
            self.host?.pushUndo(); l.vdbTint = Int32(bitPattern: self.argb(c)); self.changed()
        }, for: .valueChanged)
        let del = UIButton(type: .system); del.setImage(Icons.sf( "trash"), for: .normal); del.tintColor = UIColor(red: 1, green: 0.4, blue: 0.4, alpha: 1)
        del.addAction(UIAction { [weak self] _ in
            self?.host?.pushUndo(); Editor.scene.layers.removeAll { $0 === l }; self?.reload(); self?.host?.refreshPanel()
        }, for: .touchUpInside)
        let top = UIStackView(arrangedSubviews: [name, UIView(), well, del]); top.spacing = 12; top.alignment = .center
        let seg = UISegmentedControl(items: ["Point", "Directional", "Spot"]); seg.selectedSegmentIndex = [0, 1, 2][type]
        seg.selectedSegmentTintColor = accent
        seg.setTitleTextAttributes([.foregroundColor: UIColor.white], for: .normal); seg.setTitleTextAttributes([.foregroundColor: UIColor.black], for: .selected)
        seg.addAction(UIAction { [weak self, weak seg] _ in
            guard let self = self, let s = seg else { return }
            self.host?.pushUndo(); l.xset("lightType", Float(s.selectedSegmentIndex)); self.reload()
        }, for: .valueChanged)
        let sw = UIStackView(); sw.spacing = 8
        for c in palette {
            let b = UIButton(type: .custom); b.backgroundColor = rgb(c); b.layer.cornerRadius = 12
            b.layer.borderWidth = 1; b.layer.borderColor = UIColor(white: 1, alpha: 0.3).cgColor
            b.widthAnchor.constraint(equalToConstant: 24).isActive = true; b.heightAnchor.constraint(equalToConstant: 24).isActive = true
            b.addAction(UIAction { [weak self, weak well] _ in
                self?.host?.pushUndo(); l.vdbTint = Int32(bitPattern: c); well?.selectedColor = self?.rgb(c); self?.changed()
            }, for: .touchUpInside)
            sw.addArrangedSubview(b)
        }
        let sc = UIScrollView(); sc.showsHorizontalScrollIndicator = false; sw.translatesAutoresizingMaskIntoConstraints = false; sc.addSubview(sw)
        NSLayoutConstraint.activate([sw.topAnchor.constraint(equalTo: sc.contentLayoutGuide.topAnchor), sw.bottomAnchor.constraint(equalTo: sc.contentLayoutGuide.bottomAnchor),
                                     sw.leadingAnchor.constraint(equalTo: sc.contentLayoutGuide.leadingAnchor), sw.trailingAnchor.constraint(equalTo: sc.contentLayoutGuide.trailingAnchor),
                                     sc.heightAnchor.constraint(equalToConstant: 26)])
        var rows: [UIView] = [top, seg, sc]
        // intensity: cubic curve so the slider is fine near 0 and reaches 10000
        let cur = cbrtf(max(l.xf("lightInt", 1), 0) / 10000)
        rows.append(slider("Intensity", 0, 1, cur, "%.0f") { l.xset("lightInt", $0 * $0 * $0 * 10000) })
        if let s = rows.last as? UIStackView, let v = s.arrangedSubviews.last as? UILabel, let sl = s.arrangedSubviews[1] as? UISlider {
            v.text = String(format: "%.0f", l.xf("lightInt", 1))
            sl.addAction(UIAction { [weak v, weak sl] _ in if let sl = sl { v?.text = String(format: "%.0f", sl.value * sl.value * sl.value * 10000) } }, for: .valueChanged)
        }
        let inf = UISwitch(); inf.isOn = Lights.infinite(l); inf.onTintColor = accent
        inf.addAction(UIAction { [weak self, weak inf] _ in
            self?.host?.pushUndo(); l.xset("lightInf", (inf?.isOn ?? true) ? 1 : 0); self?.reload()
        }, for: .valueChanged)
        rows.append({ let r = UIStackView(arrangedSubviews: [label("Infinite reach", 14, .regular, .white), UIView(), inf]); r.alignment = .center; return r }())
        if type != 1 && !Lights.infinite(l) { rows.append(slider("Range", 0.5, 200, max(l.xf("lightRange", 20), 0.5), "%.1f") { l.xset("lightRange", $0) }) }
        if type == 1 || type == 2 {
            rows.append(slider("Pitch", -90, 90, l.xf("lightPitch", -60), "%.0f") { l.xset("lightPitch", $0) })
            rows.append(slider("Yaw", -180, 180, l.xf("lightYaw", 30), "%.0f") { l.xset("lightYaw", $0) })
        }
        if type == 2 {
            rows.append(slider("Cone", 5, 89, l.xf("lightCone", 45), "%.0f") { l.xset("lightCone", $0) })
            rows.append(slider("Softness", 0, 1, l.xf("lightSoft", 0.3)) { l.xset("lightSoft", $0) })
        }
        rows.append(slider("Specular", 0, 4, l.xf("lightSpec", 1)) { l.xset("lightSpec", $0) })
        let st = UIStackView(arrangedSubviews: rows); st.axis = .vertical; st.spacing = 8; st.translatesAutoresizingMaskIntoConstraints = false
        box.addSubview(st)
        NSLayoutConstraint.activate([st.leadingAnchor.constraint(equalTo: box.leadingAnchor, constant: 12), st.trailingAnchor.constraint(equalTo: box.trailingAnchor, constant: -12),
                                     st.topAnchor.constraint(equalTo: box.topAnchor, constant: 12), st.bottomAnchor.constraint(equalTo: box.bottomAnchor, constant: -12)])
        return box
    }
}
