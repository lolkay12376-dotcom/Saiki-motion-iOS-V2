// EditorDialogs.swift — dialogs: motion blur, parent popup, expressions, scene setup, render launcher, panel menu.

import UIKit
import AVFoundation

extension EditorViewController {
        // ---------------------------------------------------------------- motion blur settings + parent popup

        func showMotionBlurSettings(_ l: Layer) {
            let box = vStack()
            box.isLayoutMarginsRelativeArrangement = true
            box.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 4, leading: 4, bottom: 4, trailing: 4)
            let on = SwitchRow()
            on.label = "Motion blur"
            on.on = l.mblur
            on.onToggle = { [weak self] v in
                guard let self = self else { return }
                self.pushUndo()
                l.mblur = v
                self.mbToggle.on = v
                self.render()
            }
            put(box, on, 52)
            let stut = SwitchRow()
            stut.label = "Stuttering"
            stut.on = l.mbStutter
            stut.onToggle = { [weak self] v in self?.pushUndo(); l.mbStutter = v; self?.render() }
            put(box, stut, 52)
            let rgb = SwitchRow()
            rgb.label = "Enable RGB sampling"
            rgb.on = l.mbRgb
            rgb.onToggle = { [weak self] v in self?.pushUndo(); l.mbRgb = v; self?.render() }
            put(box, rgb, 52)
            text(box, "Quality", C.DIM, 13)
            let smp = l.track("mbSamples")
            let q = smp.base <= 5 ? 0 : smp.base <= 10 ? 1 : 2
            box.addArrangedSubview(chipRow(["Low", "Medium", "High"], q) { [weak self] i in
                guard let self = self else { return }
                self.pushUndo()
                smp.keys.removeAll()
                smp.base = [4, 8, 16][i]
                self.render()
            })
            let amt = l.track("mbAmount")
            addPlain(box, "Blur strength", 0, 4, amt.base, 2) { [weak self] v in
                guard let self = self else { return }
                self.pushUndo()
                amt.keys.removeAll()
                amt.base = v
                self.render()
            }
            if l.type == .CAMERA { text(box, "Camera motion blur: every 3D layer below this camera is blurred by the camera's movement.", C.DIM, 12) }
            text(box, "Stuttering snaps the blur samples to whole frames. RGB sampling gives the trails a red-to-blue fringe.", C.DIM, 12)
            let sv = CapScroll()
            sv.addSubview(box)
            box.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                box.topAnchor.constraint(equalTo: sv.contentLayoutGuide.topAnchor),
                box.bottomAnchor.constraint(equalTo: sv.contentLayoutGuide.bottomAnchor),
                box.leadingAnchor.constraint(equalTo: sv.contentLayoutGuide.leadingAnchor),
                box.trailingAnchor.constraint(equalTo: sv.contentLayoutGuide.trailingAnchor),
                box.widthAnchor.constraint(equalTo: sv.frameLayoutGuide.widthAnchor)
            ])
            // a scroll view has no intrinsic height → the panel opened empty. Size it to its content.
            sv.heightAnchor.constraint(lessThanOrEqualToConstant: 380).isActive = true
            let fitH = sv.heightAnchor.constraint(equalTo: box.heightAnchor)
            fitH.priority = UILayoutPriority(750); fitH.isActive = true
            _ = Dlg(self).setTitle("Motion blur").setView(sv).setPositiveButton("Done", nil).show()
        }

        func typeIcon(_ t: LayerType) -> String {
            switch t {
            case .SHAPE: return "shape"
            case .TEXT: return "text"
            case .IMAGE, .VIDEO: return "media"
            case .CAMERA: return "camera"
            case .NULL: return "nullobj"
            case .MODEL: return "cube"
            case .PARTICLES: return "particles"
            case .GROUP: return "layers"
            case .ADJUST: return "adjust"
            case .AUDIO: return "audio"
            case .FLARE: return "flare"
            }
        }

        func showParentPopup(_ l: Layer, _ anchor: UIView) {
            let cands = Editor.scene.layers.filter { $0.id != l.id && !Layer.isDescendant($0, of: l, in: Editor.scene.layers) }
            let col = vStack()
            col.isLayoutMarginsRelativeArrangement = true
            col.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 8, leading: 8, bottom: 8, trailing: 8)
            col.backgroundColor = argbToUIColor(C.CARD)
            col.layer.cornerRadius = 16
            col.layer.borderColor = argbToUIColor(Int32(bitPattern: 0xFF3A3A42)).cgColor
            col.layer.borderWidth = 1
            let sv = CapScroll()
            sv.addSubview(col)
            col.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                col.topAnchor.constraint(equalTo: sv.contentLayoutGuide.topAnchor),
                col.bottomAnchor.constraint(lessThanOrEqualTo: sv.contentLayoutGuide.bottomAnchor),
                col.leadingAnchor.constraint(equalTo: sv.contentLayoutGuide.leadingAnchor),
                col.trailingAnchor.constraint(equalTo: sv.contentLayoutGuide.trailingAnchor),
                col.widthAnchor.constraint(equalToConstant: 240)
            ])
            func item(_ icon: String, _ name: String, _ on: Bool, _ pick: @escaping () -> Void) {
                let row = hRow()
                row.isLayoutMarginsRelativeArrangement = true
                row.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 10, bottom: 0, trailing: 10)
                row.backgroundColor = argbToUIColor(Int32(bitPattern: 0xFF2A2A30))
                row.layer.cornerRadius = 12
                if on { row.layer.borderWidth = 2; row.layer.borderColor = argbToUIColor(C.GREEN).cgColor }
                let ic = IconView(icon, on ? C.GREEN : C.TEXT, 20)
                ic.isUserInteractionEnabled = false
                row.addArrangedSubview(wrap(ic, 32, 44, 0, 0, 0, 0))
                let tv = UILabel()
                tv.text = name
                tv.textColor = argbToUIColor(C.TEXT)
                tv.font = sysFont(15)
                tv.numberOfLines = 1
                tv.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
                row.addArrangedSubview(tv)
                let tap = TapView()
                tap.addSubview(row)
                // the row was never sized (frame .zero) so the parent list looked empty
                row.translatesAutoresizingMaskIntoConstraints = false
                row.isUserInteractionEnabled = false
                NSLayoutConstraint.activate([
                    row.leadingAnchor.constraint(equalTo: tap.leadingAnchor),
                    row.trailingAnchor.constraint(equalTo: tap.trailingAnchor),
                    row.topAnchor.constraint(equalTo: tap.topAnchor),
                    row.bottomAnchor.constraint(equalTo: tap.bottomAnchor),
                ])
                tap.onClick = pick
                put(col, tap, 46, 3, 3)
            }
            item("close", "None", l.parentId < 0) { [weak self] in
                guard let self = self else { return }
                self.pushUndo()
                Xf.reparentKeepingPose(l, to: -1, Editor.time, autoKey: self.autoKeyOn)
                self.refreshTitle(); self.refreshPanel(); self.render()
                Dlg.dismissCurrent()
            }
            for c in cands {
                item(typeIcon(c.type), c.name, l.parentId == c.id) { [weak self] in
                    guard let self = self else { return }
                    self.pushUndo()
                    Xf.reparentKeepingPose(l, to: c.id, Editor.time, autoKey: self.autoKeyOn)
                    self.refreshTitle(); self.refreshPanel(); self.render()
                    Dlg.dismissCurrent()
                }
            }
            sv.heightAnchor.constraint(lessThanOrEqualToConstant: 360).isActive = true
            let fitH = sv.heightAnchor.constraint(equalTo: col.heightAnchor)
            fitH.priority = UILayoutPriority(750); fitH.isActive = true
            _ = Dlg(self).setTitle("Parent").setView(sv).setNegativeButton("Close", nil).show()
        }

        // ---------------------------------------------------------------- expressions, audio, beats

        func showExpression(_ l: Layer, _ d: PropDef) {
            let tr = l.track(d.key)
            let box = vStack()
            box.isLayoutMarginsRelativeArrangement = true
            box.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 4, leading: 4, bottom: 4, trailing: 4)
            let sw = SwitchRow()
            sw.label = "fx  (expression)"
            sw.on = tr.exprOn && !tr.exprSrc.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            sw.captionOn = "On"; sw.captionOff = "Off"
            var swOn = sw.on
            sw.onToggle = { v in swOn = v }
            put(box, sw, 52)
            text(box, "t = time, v = keyframed value. wiggle(freq, amp), sin, cos, abs, min, max, clamp, pow, sqrt, linear(t, a, b, c, d), noise, floor, round, mix, if(c, a, b), step(a, b), comparisons < > <= >= ==, pi, marker.key(\"name\"), Controls tab: slider, angle, checkbox, pointx, pointy, point3x/y/z, colorr/g/b, layerctl — e.g. angle(\"Layer\") or angle(\"Layer\", 2).", C.DIM, 12)
            let et = makeField(tr.exprSrc)
            et.font = monoFont(14)
            et.placeholder = "v + wiggle(3, 0.1)"
            put(box, et, 44)
            let presets = ["v + wiggle(3, 0.1)", "v * (1 + 0.2 * sin(t * 8))", "v + t * 90", "v + abs(sin(t * 4)) * 0.3", ""]
            box.addArrangedSubview(chipRow(["Wiggle", "Pulse", "Spin", "Bounce", "Clear"], -1) { i in
                et.text = presets[i]
            })
            let ctls = Expr.allControls()
            if !ctls.isEmpty {
                text(box, "Controls (tap to insert)", C.DIM, 12)
                box.addArrangedSubview(chipRow(ctls.map { $0.0 }, -1) { i in
                    let ins = ctls[i].1
                    let s = (et.text ?? "") as NSString
                    var pos = 0
                    if let r = et.selectedTextRange { pos = et.offset(from: et.beginningOfDocument, to: r.start) }
                    let p = min(max(0, pos), s.length)
                    et.text = s.replacingCharacters(in: NSRange(location: p, length: 0), with: ins)
                })
            }
            let names = Editor.scene.markerNames.values.sorted()
            if !names.isEmpty {
                text(box, "Named markers (tap to insert)", C.DIM, 12)
                box.addArrangedSubview(chipRow(names, -1) { i in
                    let ins = "marker.key(\"" + names[i] + "\")"
                    let s = (et.text ?? "") as NSString
                    var pos = 0
                    if let r = et.selectedTextRange {
                        pos = et.offset(from: et.beginningOfDocument, to: r.start)
                    }
                    let p = min(max(0, pos), s.length)
                    et.text = s.replacingCharacters(in: NSRange(location: p, length: 0), with: ins)
                })
            }
            Dlg(self).setTitle("Expression: " + d.label).setView(box).setPositiveButton("Apply") { [weak self] _, _ in
                guard let self = self else { return }
                self.pushUndo()
                let src = et.text ?? ""
                if !tr.setExpr(src) {
                    self.toast("Expression error")
                } else {
                    tr.exprOn = swOn && !src.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                    self.refreshPanel(); self.render()
                }
            }.setNegativeButton("Cancel", nil).show()
        }

        func snapKeys(_ l: Layer) {
            let ms = Editor.scene.markers
            for (_, tr) in l.props {
                var ch = false
                for k in tr.keys {
                    if let m = ms.min(by: { abs($0 - k.t) < abs($1 - k.t) }) {
                        if abs(m - k.t) < 0.35 { k.t = m; ch = true }
                    }
                }
                if ch { tr.keys.sort { $0.t < $1.t } }
            }
            toast("Keyframes snapped to markers")
        }

        func showPanelMenu() {
            guard let l = selected() else { return }
            Dlg(self).setTitle("Layer").setItems(["Clear all keyframes", "Reset transform", "Snap keyframes to beat markers"]) { [weak self] _, which in
                guard let self = self else { return }
                self.pushUndo()
                if which == 2 {
                    self.snapKeys(l)
                } else {
                    for (k, tr) in l.props {
                        if which == 0 {
                            tr.keys.removeAll()
                            _ = tr.setExpr("")
                            tr.exprOn = false
                        } else if Defs.transform.contains(where: { $0.key == k })
                                    || Defs.rot3d.contains(where: { $0.key == k }) || k == "z" {
                            tr.keys.removeAll()
                            tr.base = Registry.propDef(k)?.def ?? 0
                        }
                    }
                }
                self.refreshPanel(); self.render()
            }.show()
        }

        // ================================================================ scenes + export

        static let expressionDoc = """
SAIKIMOTION EXPRESSIONS

HOW TO USE
1. Open a layer panel and tap a parameter.
2. Tap the command icon in the left rail.
3. Type an expression, switch it On, tap Apply.
The parameter outline turns orange to red while an expression drives it.

VARIABLES
t           time in seconds
v           the parameter's own (keyframed) value
pi          3.14159
marker.key("name")   value of a named marker

FUNCTIONS
sin(x) cos(x) abs(x) sqrt(x) floor(x) round(x)
min(a, b)  max(a, b)  pow(a, b)
clamp(x, lo, hi)
mix(a, b, k)           a + (b - a) * k
step(a, b)             0 if b < a, else 1
if(c, a, b)            a when c is true, else b
linear(t, a, b, c, d)  maps t from a..b to c..d
wiggle(freq, amp)      smooth random motion
noise(x)               smooth noise
Comparisons: < > <= >= ==
Operators: + - * / with ( )

CONTROLS TAB (Effects > Controls)
Add a control to a layer (usually a Null), then read it anywhere:
slider("Layer")            Slider Control
angle("Layer")             Angle Control (degrees)
checkbox("Layer")          Checkbox Control (0 or 1)
pointx("Layer")  pointy("Layer")                    Point Control
point3x("Layer") point3y("Layer") point3z("Layer")  3D Point Control
colorr("Layer") colorg("Layer") colorb("Layer")     Color Control (0 to 1)
layerctl("Layer")          Layer Control (layer number)
Add ", 2" for the second control of the same kind: angle("Layer", 2)

EXAMPLES
v + wiggle(3, 0.1)                     shake
v * (1 + 0.2 * sin(t * 8))             pulse
v + t * 90                             spin
v + abs(sin(t * 4)) * 0.3              bounce
slider("Null 1") * 2                   drive from a slider
if(checkbox("Null 1"), v, 0)           switch on or off
v + angle("Null 1") * 0.5              follow an angle
linear(t, 0, 2, 0, 100)                ramp 0 to 100 over 2 seconds
clamp(v + wiggle(2, 5), 0, 100)        shake within limits
"""

        func showExpressionDoc() {
            let tv = UITextView()
            tv.text = EditorViewController.expressionDoc
            tv.isEditable = false
            tv.isSelectable = true
            tv.font = monoFont(12)
            tv.backgroundColor = argbToUIColor(C.CARD)
            tv.textColor = argbToUIColor(C.TEXT)
            tv.layer.cornerRadius = 10
            tv.heightAnchor.constraint(equalToConstant: min(view.bounds.height * 0.6, 480)).isActive = true
            Dlg(self).setTitle("Expression reference").setView(tv).setPositiveButton("Copy all") { [weak self] _, _ in
                UIPasteboard.general.string = EditorViewController.expressionDoc
                self?.toast("Copied")
            }.setNegativeButton("Close", nil).show()
        }

        func showSceneDialog() {
            let box = vStack()
            box.isLayoutMarginsRelativeArrangement = true
            box.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16)
            let dlg = Dlg(self).setTitle("Scene setup").setView(box).create()
            var applyName: (() -> Void)? = nil
            var build: (() -> Void)! = nil
            build = { [weak self] in
                guard let self = self else { return }
                box.arrangedSubviews.forEach { $0.removeFromSuperview() }
                let pr = Editor.project
                let s = Editor.scene

                // ---- project identity
                text(box, "Project name", C.GREEN, 13, true)
                let nameF = self.makeField(pr.name)
                nameF.returnKeyType = .done
                put(box, nameF, 44, 0, 0)
                applyName = {
                    let nm = (nameF.text ?? "").trimmingCharacters(in: .whitespaces)
                    if !nm.isEmpty, nm != pr.name {
                        self.pushUndo()
                        pr.name = nm
                        self.refreshTitle()
                    }
                }

                // ---- help
                text(box, "Help", C.GREEN, 13, true)
                box.addArrangedSubview(chipRow(["Expression reference"], -1) { [weak self] _ in self?.showExpressionDoc() })

                // ---- canvas + frame rate
                text(box, "Canvas", C.GREEN, 13, true)
                text(box, "\(pr.w) x \(pr.h)  ·  \(Projects.resLabel(pr.w, pr.h))", C.DIM, 12)
                let res = AspectPresets.resIndex(pr.w, pr.h)
                let customIdx = AspectPresets.names.count
                let aspect = AspectPresets.match(pr.w, pr.h) ?? customIdx
                func applyDims(_ resIdx: Int, ratio: Double) {
                    let (w, h) = AspectPresets.dims(base: [720, 1080, 1440][resIdx], ratio: ratio)
                    guard w != pr.w || h != pr.h else { return }
                    self.pushUndo()
                    pr.w = w
                    pr.h = h
                    self.refreshAll()
                    build()
                }
                func askCustom() {
                    let wf = self.makeField("\(pr.w)"), hf = self.makeField("\(pr.h)")
                    wf.keyboardType = .decimalPad; hf.keyboardType = .decimalPad
                    let row = UIStackView(arrangedSubviews: [wf, hf])
                    row.axis = .horizontal; row.spacing = 10; row.distribution = .fillEqually
                    row.translatesAutoresizingMaskIntoConstraints = false
                    Dlg(self).setTitle("Custom aspect ratio  (W : H)").setView(row)
                        .setPositiveButton("Apply") { _, _ in
                            applyDims(res, ratio: AspectPresets.parse(wf.text, hf.text))
                        }
                        .setNegativeButton("Cancel", nil).show()
                }
                text(box, "Resolution", C.DIM, 12)
                box.addArrangedSubview(chipRow(["720p", "1080p", "1440p"], res) { i in
                    applyDims(i, ratio: Double(pr.w) / Double(max(pr.h, 1)))
                })
                text(box, "Aspect ratio", C.GREEN, 13, true)
                box.addArrangedSubview(chipRow(AspectPresets.names + ["Custom"], aspect) { i in
                    if i < customIdx { applyDims(res, ratio: AspectPresets.ratios[i]) } else { askCustom() }
                })
                text(box, "Background color", C.GREEN, 13, true)
                box.addArrangedSubview(wrap(self.colorRow(s.bg) { [weak self] c in
                    s.bg = c
                    self?.render()
                }, 0, 48, 0, 0, 0, 0))
                let fpsPick = pr.fps >= 50 ? 2 : (pr.fps >= 30 ? 1 : 0)
                text(box, "Frame rate", C.GREEN, 13, true)
                box.addArrangedSubview(chipRow(["24 fps", "30 fps", "60 fps"], fpsPick) { [weak self] i in
                    guard let self = self else { return }
                    self.pushUndo()
                    pr.fps = [24, 30, 60][i]
                    self.onTimeChanged()
                    build()
                })

                // ---- pre-render (groups)
                text(box, "Pre-render", C.GREEN, 13, true)
                let preSw = SwitchRow()
                preSw.label = "Pre-render groups"
                preSw.captionOn = "On"; preSw.captionOff = "Off"
                preSw.on = PreRender.enabled
                preSw.onToggle = { [weak self] v in
                    PreRender.enabled = v
                    self?.preBurst = v
                    self?.timeline.setNeedsDisplay()
                    self?.render()
                }
                put(box, preSw, 52)
                text(box, "Select a group and tap the camera-in-frame icon in the top bar to bake it. Any change inside "
                    + "the group re-bakes it, and the final render plays the baked frames. Off = groups always render live.", C.DIM, 12)

                // ---- live render cache
                text(box, "Live render cache", C.GREEN, 13, true)
                let lc = SwitchRow()
                lc.label = "Render ahead when idle"
                lc.captionOn = "On"; lc.captionOff = "Off"
                lc.on = FrameCache.enabled
                lc.onToggle = { [weak self] v in
                    FrameCache.enabled = v
                    self?.timeline.setNeedsDisplay()
                }
                put(box, lc, 52)
                let cacheInfo = text(box, "Frames are rendered at the playhead while you are not touching anything and "
                    + "shown as a green bar on the timeline. Playback then runs from the cache, so heavy scenes stay smooth.", C.DIM, 12)
                let cacheSizeLbl = text(box, "Cache size: calculating…", C.DIM, 12)
                _ = cacheInfo
                DispatchQueue.global(qos: .utility).async {
                    let t = FrameCache.sizeText()
                    DispatchQueue.main.async { cacheSizeLbl.text = "Cache size: \(t)" }
                }
                let clearPill = self.pill("Clear render cache", nil, C.CARD2, C.RED) { [weak self] in
                    cacheSizeLbl.text = "Clearing…"
                    DispatchQueue.global(qos: .utility).async {
                        FrameCache.clearAll()
                        let t = FrameCache.sizeText()
                        DispatchQueue.main.async {
                            cacheSizeLbl.text = "Cache size: \(t)"
                            self?.timeline.setNeedsDisplay()
                            self?.render()
                        }
                    }
                }
                put(box, clearPill, 40)

                // ---- scene setup mode
                text(box, "Scene Setup mode", C.GREEN, 13, true)
                let ss = SwitchRow()
                ss.label = "Orbit with an editing camera"
                ss.captionOn = "On"; ss.captionOff = "Off"
                ss.on = self.sceneSetupOn
                ss.onToggle = { [weak self] v in
                    guard let self = self else { return }
                    self.sceneSetupOn = v
                    self.sceneSetupBtn.set("camera", v ? C.GREEN : C.TEXT)
                }
                put(box, ss, 52)
                text(box, "Drag the preview to orbit the 3D scene and pinch to dolly. Your camera layers are not touched.", C.DIM, 12)

                // ---- guides
                text(box, "Guides", C.GREEN, 13, true)
                let gs = SwitchRow()
                gs.label = "Guides"; gs.on = self.overlay.guides
                gs.onToggle = { [weak self] v in
                    guard let self = self else { return }
                    self.overlay.guides = v
                    self.overlay.setNeedsDisplay()
                }
                put(box, gs, 52)

                // ---- scenes
                text(box, "Scenes", C.GREEN, 13, true)
                var sceneNames = pr.scenes.map { $0.name }
                sceneNames.append("New scene")
                box.addArrangedSubview(chipRow(sceneNames, Editor.sceneIndex) { [weak self] i in
                    guard let self = self else { return }
                    self.pushUndo()
                    if i == pr.scenes.count {
                        pr.scenes.append(Scene("Scene \(pr.scenes.count + 1)"))
                        Editor.sceneIndex = pr.scenes.count - 1
                    } else {
                        Editor.sceneIndex = i
                    }
                    Editor.time = 0
                    self.selId = -1
                    self.panel = P_NONE
                    self.refreshAll()
                    build()
                })
                if pr.scenes.count > 1 {
                    put(box, pill("Delete this scene", nil, C.CARD2, C.RED) { [weak self] in
                        guard let self = self else { return }
                        self.pushUndo()
                        pr.scenes.removeAll { $0 === s }
                        Editor.sceneIndex = 0
                        Editor.time = 0
                        self.selId = -1
                        self.panel = P_NONE
                        self.refreshAll()
                        build()
                    }, 40)
                }
                let f = RulerSlider(frame: .zero)
                f.label = "Scene FOV"; f.lo = 15; f.hi = 90; f.value = s.fov; f.dec = 0; f.canKey = false
                f.onChange = { [weak self] v in s.fov = v; self?.render() }
                put(box, f, 60)

                // ---- help
                text(box, "Help", C.GREEN, 13, true)
                put(box, pill("Add Puppet: documentation", nil, C.CARD2, C.TEXT) { [weak self] in
                    guard let self = self else { return }
                    HelpDocs.show(from: self.presentedViewController ?? self, title: "Puppet", sections: HelpDocs.puppet)
                }, 44)
            }
            build()
            dlg.setPositiveButton("Done") { [weak self] _, _ in
                _ = self
                applyName?()
            }.show()
        }

        func showRenderDialog() {
            if playing { togglePlay() }
            Projects.save(projectId, Editor.project)
            let proj = Editor.project
            RenderUi.settings(self, proj) { [weak self] st in
                guard let self = self else { return }
                RenderUi.show(self, proj, st)
            }
        }
}
