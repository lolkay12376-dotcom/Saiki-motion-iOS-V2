// WelcomeViewController.swift — the launch "What's New" card.

import UIKit

// MARK: - What's New ---------------------------------------------------------------------

/// The original's launch card, rebuilt 1:1 from the shipped binary's
/// WelcomeViewController.viewDidLoad: black full-screen, scrollable stack
/// with the splash art at top, the kerned "SAIKI MOTION" wordmark, a big
/// "Welcome", the bordered disclaimer card (NOT A MOD / paragraph /
/// Developers / TikTok credits), the "What's New" changelog list and the
/// two-button row. Shown on every launch until "Don't show again".
final class WelcomeViewController: UIViewController {

    /// The changelog: this version's changes first, then the original's
    /// shipped UPDATES list (kept verbatim below the divider entry).
    static let UPDATES: [String] = [
        "Saiki Motion is currently in BETA — expect rough edges, and please report anything that breaks",
        "NEW — My Playground: project thumbnails, folders (create, rename, delete, move projects in and out) — all with our own icons, no emojis or system icons",
        "NEW — 3D editor: fixed the gizmo lagging behind when you move things, including the camera. The gizmo and the preview now update on the same frame",
        "NEW — Export screen: all settings sit above Cancel / Export — Quality, Frames per second (parameter slider + FPS presets), Bitrate, Include audio and Export project file",
        "NEW — Project settings: Duration removed; Aspect ratio and Background color are now at the top under Canvas",
    ]

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = argbToUIColor(Int32(bitPattern: 0xFF000000))
        isModalInPresentation = true

        // scroll + content stack (fills width, vertical, zero spacing)
        let scroll = UIScrollView()
        scroll.alwaysBounceVertical = true
        scroll.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scroll)

        let stack = UIStackView()
        stack.axis = .vertical
        stack.alignment = .fill
        stack.spacing = 0
        stack.isLayoutMarginsRelativeArrangement = true
        stack.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 28, leading: 22, bottom: 24, trailing: 22)
        stack.translatesAutoresizingMaskIntoConstraints = false
        scroll.addSubview(stack)
        NSLayoutConstraint.activate([
            scroll.topAnchor.constraint(equalTo: view.topAnchor),
            scroll.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            scroll.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scroll.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            stack.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor),
            stack.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor),
            stack.leadingAnchor.constraint(equalTo: scroll.contentLayoutGuide.leadingAnchor),
            stack.trailingAnchor.constraint(equalTo: scroll.contentLayoutGuide.trailingAnchor),
            stack.widthAnchor.constraint(equalTo: scroll.frameLayoutGuide.widthAnchor),
        ])

        // 1 - splash art (bundle image, file fallback — same as the original)
        let artImage = UIImage(named: "splash_chibi")
            ?? Bundle.main.url(forResource: "splash_chibi", withExtension: "png")
                .flatMap { UIImage(contentsOfFile: $0.path) }
        let art = UIImageView(image: artImage)
        art.contentMode = .scaleAspectFit
        stack.addArrangedSubview(art)
        art.heightAnchor.constraint(equalToConstant: 288).isActive = true

        // 2 - kerned wordmark
        let mark = UILabel()
        mark.attributedText = kerned("SAIKI MOTION", 14, C.GREEN, 0.3)
        mark.textAlignment = .center
        stack.addArrangedSubview(pad(mark, 14, 0, 0, 0))

        // 3 - Welcome
        let welcome = UILabel()
        welcome.text = "Welcome"
        welcome.textColor = argbToUIColor(Int32(bitPattern: 0xFFF2F2F2))
        welcome.font = .boldSystemFont(ofSize: 32)
        welcome.textAlignment = .center
        stack.addArrangedSubview(pad(welcome, 4, 0, 18, 0))

        // 4 - disclaimer card
        let card = UIView()
        card.backgroundColor = argbToUIColor(Int32(bitPattern: 0xFF1C2121))
        card.layer.cornerRadius = 20
        card.layer.borderWidth = 1
        card.layer.borderColor = argbToUIColor(Int32(bitPattern: 0xFF2A2A30)).cgColor
        let inner = UIStackView()
        inner.axis = .vertical
        inner.spacing = 0
        inner.isLayoutMarginsRelativeArrangement = true
        inner.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 16, leading: 18, bottom: 16, trailing: 18)
        inner.translatesAutoresizingMaskIntoConstraints = false
        card.addSubview(inner)
        NSLayoutConstraint.activate([
            inner.topAnchor.constraint(equalTo: card.topAnchor),
            inner.bottomAnchor.constraint(equalTo: card.bottomAnchor),
            inner.leadingAnchor.constraint(equalTo: card.leadingAnchor),
            inner.trailingAnchor.constraint(equalTo: card.trailingAnchor),
        ])

        let notMod = UILabel()
        notMod.text = "THIS APP IS NOT A MOD OF KEYFLOW."
        notMod.textColor = argbToUIColor(C.GREEN)
        notMod.font = .boldSystemFont(ofSize: 16)
        notMod.numberOfLines = 0
        inner.addArrangedSubview(notMod)

        let disclaimer = UILabel()
        disclaimer.attributedText = lineSpaced(
            "Saiki Motion is an independent app. We built it with a similar interface and feature set to Keyflow by Angkin, and it is free for all users. We are currently in development and we are excited for the future of Saiki Motion.",
            14, 1.2, Int32(bitPattern: 0xFFFFFFFF))
        disclaimer.numberOfLines = 0
        inner.addArrangedSubview(pad(disclaimer, 10, 0, 14, 0))

        let devs = UILabel()
        devs.text = "Developers"
        devs.textColor = argbToUIColor(Int32(bitPattern: 0xFF8C8C96))
        devs.font = .boldSystemFont(ofSize: 12)
        inner.addArrangedSubview(devs)

        let tiktok = UILabel()
        tiktok.text = "TikTok  @quintsuxf\nTikTok  @naviya903"
        tiktok.textColor = argbToUIColor(Int32(bitPattern: 0xFFFFFFFF))
        tiktok.font = .systemFont(ofSize: 15)
        tiktok.numberOfLines = 0
        inner.addArrangedSubview(pad(tiktok, 4, 0, 0, 0))

        stack.addArrangedSubview(card)

        // 5 - What's New header
        let header = UILabel()
        header.text = "What's New"
        header.textColor = argbToUIColor(C.GREEN)
        header.font = .boldSystemFont(ofSize: 13)
        stack.addArrangedSubview(pad(header, 22, 4, 0, 6))

        // 6 - changelog lines
        for u in WelcomeViewController.UPDATES {
            let line = UILabel()
            line.text = "\u{2022}  " + u
            line.textColor = argbToUIColor(Int32(bitPattern: 0xFFFFFFFF))
            line.font = .systemFont(ofSize: 14)
            line.numberOfLines = 0
            stack.addArrangedSubview(pad(line, 3, 4, 3, 4))
        }

        // 7 - button row
        let row = UIStackView()
        row.axis = .horizontal
        row.alignment = .fill
        row.distribution = .fillEqually
        row.spacing = 8

        let never = PillButton("Don't show again", nil, C.CARD2, Int32(bitPattern: 0xFFFFFFFF))
        never.onClick = { [weak self] in
            UserDefaults.standard.set(true, forKey: "hideWelcome")
            self?.dismiss(animated: true)
        }
        row.addArrangedSubview(never)
        never.heightAnchor.constraint(equalToConstant: 50).isActive = true

        let close = PillButton("Close", nil, C.GREEN, C.ONDARK)
        close.onClick = { [weak self] in
            self?.dismiss(animated: true)
        }
        row.addArrangedSubview(close)
        close.heightAnchor.constraint(equalToConstant: 50).isActive = true

        stack.addArrangedSubview(pad(row, 26, 0, 0, 0))
    }

    /// Letter-spaced bold label text (the wordmark).
    private func kerned(_ s: String, _ size: CGFloat, _ color: Int32, _ spacing: CGFloat) -> NSAttributedString {
        NSAttributedString(string: s, attributes: [
            .kern: spacing,
            .font: UIFont.boldSystemFont(ofSize: size),
            .foregroundColor: argbToUIColor(color),
        ])
    }

    /// Line-height-multiplied paragraph (the disclaimer card's body).
    private func lineSpaced(_ s: String, _ size: CGFloat, _ line: CGFloat, _ color: Int32) -> NSAttributedString {
        let p = NSMutableParagraphStyle()
        p.minimumLineHeight = size * line
        return NSAttributedString(string: s, attributes: [
            .paragraphStyle: p,
            .font: UIFont.systemFont(ofSize: size),
            .foregroundColor: argbToUIColor(color),
        ])
    }

    /// Wraps a view with directional insets so the stack stays zero-spacing.
    private func pad(_ v: UIView, _ t: CGFloat, _ l: CGFloat, _ b: CGFloat, _ r: CGFloat) -> UIView {
        let wrap = UIView()
        wrap.translatesAutoresizingMaskIntoConstraints = false
        v.translatesAutoresizingMaskIntoConstraints = false
        wrap.addSubview(v)
        NSLayoutConstraint.activate([
            v.topAnchor.constraint(equalTo: wrap.topAnchor, constant: t),
            v.bottomAnchor.constraint(equalTo: wrap.bottomAnchor, constant: -b),
            v.leadingAnchor.constraint(equalTo: wrap.leadingAnchor, constant: l),
            v.trailingAnchor.constraint(equalTo: wrap.trailingAnchor, constant: -r),
        ])
        return wrap
    }
}
