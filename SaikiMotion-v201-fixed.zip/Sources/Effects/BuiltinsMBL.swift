// BuiltinsMBL.swift — "Magic Bullet Looks": a tool-chain look studio (Edge Softness, Chromatic Aberration,
// Diffusion, Curves, HSL Colors, Exposure, Warm/Cool, Contrast, Hue/Saturation, Duotone, Renoiser, Bleach Bypass).
// Single GLSL pass. Every tool is neutral until added in MBLEditorViewController. Legacy look studio stays as "MB Looks (Legacy)".

import Foundation

let mblHslNames = ["Red", "Orange", "Yellow", "Green", "Cyan", "Blue", "Purple", "Magenta"]
let mblHslHue: [Float] = [0, 30, 60, 120, 180, 240, 270, 300]

/// S-curve mask shared by Vignette / Spot / Grad (the kernels' `potS` lo/hi curve), `u` in 0..1, `f` = Falloff.
private func mblSMask(_ u: String, _ f: String, _ out: String, _ n: String) -> String {
    "float s\(n) = clamp(\(f), 0.001, 0.999); float k\(n) = abs(s\(n) - 0.5) * 5.0 + 2.5; float x1\(n) = \(u) / s\(n); float x2\(n) = (\(u) - 1.0) / (s\(n) - 1.0); " +
    "float lo\(n) = min((x1\(n) > 0.0 ? pow(x1\(n), k\(n)) : 0.0) * s\(n), s\(n)); float hi\(n) = max((x2\(n) > 0.0 ? pow(x2\(n), k\(n)) : 0.0) * (s\(n) - 1.0) + 1.0, s\(n)); float \(out) = lo\(n) - s\(n) + hi\(n);\n"
}
/// Duotone `comLum` (SetLum + ClipColor) for colour `cv`, result in `out`.
private func mblSetLum(_ cv: String, _ out: String, _ n: String) -> String {
    "vec3 c\(n) = \(cv) + vec3(l1 - dot(\(cv), vec3(0.3, 0.59, 0.11))); float l\(n) = dot(c\(n), vec3(0.3, 0.59, 0.11)); float n\(n) = min(c\(n).r, min(c\(n).g, c\(n).b)); float m\(n) = max(c\(n).r, c\(n).b); " +
    "if (n\(n) < 0.0) { c\(n) = (c\(n) - l\(n)) * l\(n) / (l\(n) - n\(n)) + l\(n); } if (m\(n) > 1.0) { c\(n) = (c\(n) - l\(n)) * (1.0 - l\(n)) / (m\(n) - l\(n)) + l\(n); } vec3 \(out) = c\(n);\n"
}

/// Haze/Flare presets (name, [key: value], tint RGB 0...1). Index 0 = None.
let mblHazePresets: [(name: String, v: [String: Float], tint: (Float, Float, Float))] = [
    ("None", [:], (0.226, 0.181, 1.0)),
    ("Warm Sunset", ["mbHfSp": 30, "mbHfSo": 60, "mbHfRe": 65, "mbHfEx": -0.5, "mbHfRx": -1, "mbHfRf": 1, "mbHfBx": 40, "mbHfSh": 60], (1.0, 0.55, 0.2)),
    ("Cool Daylight", ["mbHfSp": 18, "mbHfSo": 55, "mbHfRe": 50, "mbHfEx": -1, "mbHfRx": -1.5, "mbHfRf": 1, "mbHfBx": 50, "mbHfSh": 70], (0.55, 0.75, 1.0)),
    ("Tungsten Spill", ["mbHfSp": 26, "mbHfSo": 70, "mbHfRe": 45, "mbHfEx": -0.8, "mbHfRx": -2, "mbHfRf": 0, "mbHfBx": 55, "mbHfSh": 75], (1.0, 0.7, 0.35)),
    ("Neon Haze", ["mbHfSp": 40, "mbHfSo": 80, "mbHfRe": 75, "mbHfEx": 0, "mbHfRx": 0, "mbHfRf": 1, "mbHfBx": 30, "mbHfSh": 40], (1.0, 0.2, 0.9)),
    ("Subtle Veil", ["mbHfSp": 10, "mbHfSo": 90, "mbHfRe": 85, "mbHfEx": -1.5, "mbHfRx": -3, "mbHfRf": 0, "mbHfBx": 70, "mbHfSh": 50], (0.8, 0.85, 1.0)),
]

func mblFx() -> [EffectDef] {
    func col(_ h: UInt32) -> Int32 { Int32(bitPattern: h) }
    var props: [PropDef] = [
        PropDef("mbInt", "Intensity", 0, 1, 1, 2),
        PropDef("mbExpo", "Exposure", -4, 4, 0, 2),
        PropDef("mbWarm", "Warm/Cool", -1, 1, 0, 2),
        PropDef("mbCon", "Contrast", -1, 1, 0, 2),
        PropDef("mbConPiv", "Pivot", 0.001, 1, 0.18, 3),
        PropDef("mbHue", "Hue", -180, 180, 0, 0),
        PropDef("mbSat", "Saturation", 0, 2, 1, 2),
        PropDef("mbBB", "Silver Retention", 0, 100, 0, 1),
        PropDef("mbDuo", "Duotone amount", 0, 1, 0, 2),
        PropDef("mbGrain", "Renoiser amount", 0, 1, 0, 2),
        PropDef("mbGrainSz", "Grain size", 1, 8, 1.5, 1),
        PropDef("mbEsBlur", "Blur Size", 0, 10, 0, 2),
        PropDef("mbEsQ", "Quality", 1, 5, 3, 0),
        PropDef("mbEsX", "Center X", -100, 100, 0, 0),
        PropDef("mbEsY", "Center Y", -100, 100, 0, 0),
        PropDef("mbEsRad", "Radius", 0.1, 3, 1, 3),
        PropDef("mbEsAsp", "Aspect", 0.2, 3, 1, 3),
        PropDef("mbEsSpr", "Spread", 0, 1, 0.5, 3),
        PropDef("mbCaR", "Red/Cyan", -10, 10, 0, 3),
        PropDef("mbCaG", "Green/Magenta", -10, 10, 0, 3),
        PropDef("mbCaB", "Blue/Yellow", -10, 10, 0, 3),
        PropDef("mbDfSize", "Size", 0, 100, 0, 2),
        PropDef("mbDfGrade", "Grade", 0, 6, 3, 2),
        PropDef("mbDfGlow", "Glow", 0, 100, 50, 2),
        PropDef("mbDfHi", "Highlights Only", 0, 100, 75, 2),
        PropDef("mbDfBias", "Highlight Bias", -1, 1, 0, 3),
        PropDef("mbDfExp", "Exposure Compensation", -3, 3, 0, 2),
        PropDef("mbHsl", "HSL on", 0, 1, 0, 0),
        PropDef("mbCurvAmt", "Curves amount", 0, 1, 0, 2),
    ]
    for i in 0..<8 {
        props.append(PropDef("mbH\(i)", "\(mblHslNames[i]) hue", -1, 1, 0, 2))
        props.append(PropDef("mbS\(i)", "\(mblHslNames[i]) saturation", -1, 1, 0, 2))
        props.append(PropDef("mbL\(i)", "\(mblHslNames[i]) lightness", -1, 1, 0, 2))
    }

    // --- tools ported from the mblooks kernels (exact maths; the parameter -> uniform mapping is ours) ---
    func rgb3(_ k: String, _ n: String, _ lo: Float, _ hi: Float, _ d: Float) -> [PropDef] {
        [PropDef(k + "R", n + " Red", lo, hi, d, 2), PropDef(k + "G", n + " Green", lo, hi, d, 2), PropDef(k + "B", n + " Blue", lo, hi, d, 2)]
    }
    props += [PropDef("mbBBe", "Exposure Compensation", -4, 4, 0, 2), PropDef("mbNB", "Silver Retention", 0, 100, 0, 1), PropDef("mbNBe", "Exposure Compensation", -4, 4, 0, 2),
              PropDef("mbLg", "LGG on", 0, 1, 0, 0), PropDef("mbLgSp", "Gamma Space", 0.1, 4, 1, 2), PropDef("mbLgStr", "Strength", 0, 100, 100, 1), PropDef("mbLgExp", "Exposure Compensation", -4, 4, 0, 2),
              PropDef("mbBw", "B&W on", 0, 1, 0, 0), PropDef("mbTsOn", "2-Strip on", 0, 1, 0, 0), PropDef("mbTsE", "Gain", 0, 2, 1, 2), PropDef("mbTsS", "Mix", 0, 1, 0.5, 2),
              PropDef("mbFl", "Lightflex on", 0, 1, 0, 0), PropDef("mbFlB", "Boost", -4, 4, 0, 2), PropDef("mbFlE", "Exposure Compensation", -4, 4, 0, 2),
              PropDef("mbAs", "Strength", 0, 100, 0, 1),
              PropDef("mbVgStr", "Strength", 0, 100, 0, 1), PropDef("mbVgExp", "Exposure Compensation", -4, 4, 0, 2), PropDef("mbVgRad", "Radius", 0.1, 2, 1, 2),
              PropDef("mbVgSpr", "Spread", 0.01, 1, 0.5, 2), PropDef("mbVgFall", "Falloff", 0.01, 0.99, 0.5, 2), PropDef("mbVgX", "Center X", -100, 100, 0, 0),
              PropDef("mbVgY", "Center Y", -100, 100, 0, 0), PropDef("mbVgAsp", "Aspect", 0.2, 3, 1, 2),
              PropDef("mbSpOn", "Spot on", 0, 1, 0, 0), PropDef("mbSpS", "Stops", -4, 4, 0, 2), PropDef("mbSpRad", "Radius", 0.1, 2, 0.6, 2), PropDef("mbSpSpr", "Spread", 0.01, 1, 0.5, 2),
              PropDef("mbSpFall", "Falloff", 0.01, 0.99, 0.5, 2), PropDef("mbSpX", "Center X", -100, 100, 0, 0), PropDef("mbSpY", "Center Y", -100, 100, 0, 0),
              PropDef("mbSpAsp", "Aspect", 0.2, 3, 1, 2), PropDef("mbSpInv", "Invert", 0, 1, 0, 0, ["Off", "On"]),
              PropDef("mbGxOn", "Grad on", 0, 1, 0, 0), PropDef("mbGxStops", "Stops", -4, 4, 0, 2), PropDef("mbGxStr", "Strength", 0, 100, 100, 1), PropDef("mbGxFall", "Falloff", 0.01, 0.99, 0.5, 2),
              PropDef("mbGxSx", "Start X", 0, 1, 0.5, 2), PropDef("mbGxSy", "Start Y", 0, 1, 0.25, 2), PropDef("mbGxEx", "End X", 0, 1, 0.5, 2), PropDef("mbGxEy", "End Y", 0, 1, 0.75, 2),
              PropDef("mbDuoSA", "Highlights strength", 0, 1, 1, 2), PropDef("mbDuoSB", "Shadows strength", 0, 1, 1, 2), PropDef("mbDuoLo", "Low", 0, 1, 0, 2), PropDef("mbDuoHi", "High", 0, 1, 1, 2)]
    // Colourista (3-way wheels: x/y puck offset + luma per range) and Mojo II
    props += [PropDef("mbCo", "Colourista on", 0, 1, 0, 0), PropDef("mbCoExp", "Exposure", -4, 4, 0, 2), PropDef("mbCoSat", "Saturation", 0, 2, 1, 2),
              PropDef("mbCoStr", "Strength", 0, 1, 1, 2)]
    for r in ["S", "M", "H"] { props += [PropDef("mbCo\(r)x", "x", -1, 1, 0, 3), PropDef("mbCo\(r)y", "y", -1, 1, 0, 3), PropDef("mbCo\(r)l", "Luma", -1, 1, 0, 3)] }
    props += [PropDef("mbMj", "Mojo on", 0, 1, 0, 0), PropDef("mbMjAmt", "Amount", 0, 1, 0, 2), PropDef("mbMjTO", "Teal / Orange", -1, 1, 0, 2),
              PropDef("mbMjWarm", "Warmth", -1, 1, 0, 2), PropDef("mbMjCon", "Contrast", -1, 1, 0, 2), PropDef("mbMjSat", "Saturation", 0, 2, 1, 2),
              PropDef("mbMjFade", "Fade", 0, 1, 0, 2)]
    // Haze/Flare (Lens): light spilling from the highlights, a lens reflection, a matte box that trims the spill, a tint
    props += [PropDef("mbHf", "Haze/Flare on", 0, 1, 0, 0), PropDef("mbHfSp", "Spillage", 0, 100, 16.5, 1), PropDef("mbHfSo", "Softness", 0, 100, 49, 1),
              PropDef("mbHfRe", "Reach", 0, 100, 53.2, 1), PropDef("mbHfEx", "Exposure", -4, 4, -1, 2), PropDef("mbHfRx", "Reflection Exposure", -4, 4, 0, 2),
              PropDef("mbHfRf", "Reflection", 0, 1, 1, 0, ["Off", "On"]), PropDef("mbHfBx", "Matte Box Size", 0, 100, 50, 1), PropDef("mbHfSh", "Matte Box Shade", 0, 100, 75, 1),
              PropDef("mbHfPre", "Preset", 0, Float(mblHazePresets.count - 1), 0, 0, mblHazePresets.map { $0.name })]
    props += rgb3("mbLi", "Lift", 0, 2, 1) + rgb3("mbGa", "Gamma", 0.1, 4, 1) + rgb3("mbGn", "Gain", 0, 4, 1)
    props += [PropDef("mbBwR", "Red Component", -1, 2, 0.3, 2), PropDef("mbBwG", "Green Component", -1, 2, 0.59, 2), PropDef("mbBwB", "Blue Component", -1, 2, 0.11, 2)]
    for ch in looksCurveChannels { for i in 0..<7 { props.append(PropDef("mbCv\(ch)\(i)", "Curve \(ch)\(i)", 0, 1, Float(i) / 6, 3)) } }

    // HSL band code: 8 hue bands, circular distance, weighted by pixel chroma
    var hsl = "if (mbHsl > 0.5) {\n float mx = max(c.r, max(c.g, c.b)); float mn = min(c.r, min(c.g, c.b)); float dl = mx - mn;\n"
    hsl += " float hh = 0.0;\n if (dl > 0.0001) { if (mx == c.r) { hh = mod((c.g - c.b) / dl, 6.0); } else if (mx == c.g) { hh = (c.b - c.r) / dl + 2.0; } else { hh = (c.r - c.g) / dl + 4.0; } hh = hh / 6.0; }\n"
    hsl += " float cw = smoothstep(0.0, 0.25, dl);\n float dH = 0.0; float dS = 0.0; float dL = 0.0;\n"
    for i in 0..<8 {
        hsl += " { float dd = abs(hh - \(mblHslHue[i] / 360)); dd = min(dd, 1.0 - dd); float w = smoothstep(0.11, 0.0, dd) * cw; dH += w * mbH\(i); dS += w * mbS\(i); dL += w * mbL\(i); }\n"
    }
    hsl += " float hr = dH * 0.5236; float cs = cos(hr); float sn = sin(hr);\n"
    hsl += " float yy = dot(c, vec3(0.299, 0.587, 0.114)); float ii = dot(c, vec3(0.596, -0.274, -0.322)); float qq = dot(c, vec3(0.211, -0.523, 0.312));\n"
    hsl += " float i2 = (ii * cs - qq * sn) * (1.0 + dS); float q2 = (ii * sn + qq * cs) * (1.0 + dS);\n"
    hsl += " yy = yy * (1.0 + dL * 0.6);\n c = vec3(yy + 0.956 * i2 + 0.621 * q2, yy - 0.272 * i2 - 0.647 * q2, yy - 1.106 * i2 + 1.703 * q2);\n}\n"
    let curves = looksCurveGlsl().replacingOccurrences(of: "lkCv", with: "mbCv").replacingOccurrences(of: "lkCurvAmt", with: "mbCurvAmt")

    return [EffectDef(
        id: "mbl", name: "Magic Bullet Looks",
        desc: "Tool-chain look studio: Edge Softness, Chromatic Aberration, Diffusion, Curves, HSL Colors, Exposure, Warm/Cool, Contrast, Hue/Saturation, Duotone, Renoiser, Haze/Flare. Tap Open Magic Bullet Looks.",
        category: "Color", props: props, colors: [
            ColorParam("mbDfC", "Diffusion color", col(0xFF1C07FF)),
            ColorParam("mbHfC", "Tint Color", col(0xFF3A2EFF)),
            ColorParam("mbDuoS", "Duotone shadows", col(0xFF1B2A49)),
            ColorParam("mbDuoH", "Duotone highlights", col(0xFFF2C98A)),
            ColorParam("mbFlC", "Lightflex color", col(0xFF000000)), ColorParam("mbVgC", "Vignette color", col(0xFF000000)),
            ColorParam("mbSpC", "Spot color", col(0xFFFFFFFF)), ColorParam("mbGxC", "Grad color", col(0xFFFFFFFF)),
        ], previewAnim: "fade", glsl: """
    vec2 px = 1.0 / uRes;
    float asp = uRes.x / max(uRes.y, 1.0);
    vec2 cc = uv - 0.5;
    vec4 s0 = src(uv);
    float a = s0.a;
    vec3 c0 = s0.rgb / max(a, 0.0001);
    vec3 c = c0;
    float oR = (mbCaR - mbCaG - mbCaB) * 0.75;
    float oG = (-mbCaR + mbCaG - mbCaB) * 0.75;
    float oB = (-mbCaR - mbCaG + mbCaB) * 0.75;
    bool hasCa = (abs(oR) + abs(oG) + abs(oB)) > 0.001;
    vec2 cdir = cc * px.x * 3.0;
    if (mbEsBlur > 0.01) {
        vec2 ec = uv - (vec2(0.5) + vec2(mbEsX, -mbEsY) * 0.005);
        float ed = length(vec2(ec.x * asp / mbEsAsp, ec.y));
        float r0 = 0.45 * mbEsRad * (1.0 - 0.6 * mbEsSpr);
        float r1 = r0 + 0.9 * mbEsRad * (0.3 + mbEsSpr);
        float etp = clamp((ed - r0) / max(r1 - r0, 0.0001), 0.0, 1.0);
        float esM = 1.0 - pow(1.0 - etp, 2.0 * etp);
        float eR = mbEsBlur * 0.01 * uRes.y * esM;
        float nT = mbEsQ * 6.0;
        vec3 acc = vec3(0.0);
        float aw = 0.0;
        for (int i = 0; i < 30; i++) {
            if (float(i) < nT) {
                float fi = float(i) + 0.5;
                float rad = sqrt(fi / nT);
                float an = fi * 2.3999632;
                vec2 o = vec2(cos(an), sin(an)) * rad * eR * px;
                vec3 sm = vec3(src(uv + o + cdir * oR).r, src(uv + o + cdir * oG).g, src(uv + o + cdir * oB).b);
                acc += sm;
                aw += 1.0;
            }
        }
        c = acc / max(aw, 1.0) / max(a, 0.0001);
    } else if (hasCa) {
        c = vec3(src(uv + cdir * oR).r, src(uv + cdir * oG).g, src(uv + cdir * oB).b) / max(a, 0.0001);
    }
    if (mbDfSize > 0.01) {
        float dR = mbDfSize * 0.01 * 0.2 * uRes.y + 2.0;
        float hiA = mbDfHi * 0.01;
        vec3 dAll = vec3(0.0);
        vec3 dHi = vec3(0.0);
        float dW = 0.0;
        for (int i = 0; i < 24; i++) {
            float fi = float(i) + 0.5;
            float rad = sqrt(fi / 24.0);
            float an = fi * 2.3999632;
            vec3 sm = src(uv + vec2(cos(an), sin(an)) * rad * dR * px).rgb;
            float wt = pow(max(1.0 - rad, 0.001), mbDfGrade * 0.5 + 0.1);
            float sl = dot(sm, vec3(0.2126, 0.7152, 0.0722));
            dAll += sm * wt;
            dHi += sm * wt * smoothstep(0.35 + mbDfBias * 0.3, 0.95 + mbDfBias * 0.3, sl);
            dW += wt;
        }
        dAll /= dW;
        dHi /= dW;
        float ex = exp2(mbDfExp);
        vec3 dMix = mix(dAll, dHi, hiA) * ex;
        c += dMix * mix(vec3(1.0), mbDfC.rgb, 0.85) * mbDfGlow * 0.02 * 2.0;
    }
    if (mbHf > 0.5 && uHas0 > 0.5) {
        float hAsp = uRes.x / max(uRes.y, 1.0);
        vec2 hc = uv - vec2(0.5);
        vec3 hz = in0(uv).rgb;
        vec3 hr = in0(vec2(0.5) - hc * 0.8).rgb * exp2(mbHfRx) * mbHfRf;
        vec3 vl = hz;
        float vw = 1.0;
        for (int i = 0; i < 8; i++) {
            float an = float(i) * 0.7853982;
            vec2 o1 = vec2(cos(an) / hAsp, sin(an));
            vl += in0(uv + o1 * 0.12).rgb + in0(uv + o1 * 0.28).rgb;
            vw += 2.0;
        }
        vl = vl / vw;
        float hBox = mix(1.6, 0.55, mbHfBx * 0.01);
        float hEdge = smoothstep(hBox * 0.6, hBox, max(abs(hc.x) * 2.0, abs(hc.y) * 2.0));
        float hMask = 1.0 - hEdge * mbHfSh * 0.01;
        vec3 hTint = mix(vec3(1.0), mbHfC.rgb / max(max(mbHfC.r, max(mbHfC.g, mbHfC.b)), 0.001), 0.85);
        float hA = mbHfSp * 0.01 * 1.8 * exp2(mbHfEx);
        vec3 haze = ((hz + hr * 0.5) * hMask * hA * 4.0 + vl * hA * 3.0) * hTint;
        c = vec3(1.0) - (vec3(1.0) - c) * exp(-haze);
    }
    // ---- linear-light block (the Looks kernels run in linear) ----
    c = pow(max(c, vec3(0.0)), vec3(2.2));
    if (abs(mbExpo) > 0.001) { c *= exp2(mbExpo); }
    if (abs(mbWarm) > 0.001) { c *= vec3(exp2(-mbWarm * 0.5) * exp2(-mbWarm * 0.25), exp2(mbWarm * 0.5), exp2(mbWarm * 0.25)); }
    if (abs(mbCon) > 0.001) {
        float cg = mbCon < 0.0 ? 1.0 / (1.0 - mbCon) : mbCon + 1.0;
        c = pow(max(c / mbConPiv, vec3(0.000001)), vec3(cg)) * mbConPiv;
    }
    if (mbLg > 0.5) {
        vec3 lA = vec3(mbLiR, mbLiG, mbLiB) - 1.0;
        vec3 b0 = pow(max(c, vec3(0.000001)), vec3(1.0 / max(mbLgSp, 0.1)));
        vec3 d0 = (b0 / max(vec3(mbGaR, mbGaG, mbGaB), vec3(0.1)) + lA) * vec3(mbGnR, mbGnG, mbGnB);
        vec3 e0 = pow(max(d0, vec3(0.000001)), vec3(1.0) - lA);
        vec3 g0 = pow(max(e0, vec3(0.000001)), vec3(max(mbLgSp, 0.1)));
        c = ((g0 - c) * mbLgStr * 0.01 + c) * exp2(mbLgExp);
    }
    if (mbTsOn > 0.5) {
        float tg = dot(c, vec3(0.0, mbTsE * mbTsS, (1.0 - mbTsS) * mbTsE));
        c = vec3(c.r * mbTsE, tg, tg);
    }
    if (mbFl > 0.5) { c = (c + mbFlC.rgb * exp2(mbFlB)) * exp2(mbFlE); }
    if (mbBB > 0.001 || abs(mbBBe) > 0.001) {
        float bl = dot(c, vec3(0.2126, 0.7152, 0.0722));
        c = ((c - c * bl) * (1.0 - mbBB * 0.01) + c * bl) * exp2(mbBBe);
    }
    if (mbNB > 0.001 || abs(mbNBe) > 0.001) {
        float bl = dot(c, vec3(0.2126, 0.7152, 0.0722));
        c = ((c - (c + bl)) * (1.0 - mbNB * 0.01) + (c + bl)) * exp2(mbNBe);
    }
    if (mbBw > 0.5) {
        float bl = c.r * mbBwR + c.g * mbBwG + c.b * mbBwB;
        c = (c - bl) * 0.001 + bl;
    }
    if (mbAs > 0.001) { vec3 xs = min(c, vec3(5.0)); c = ((vec3(1.0) - vec3(2.0) / (exp(2.0 * max(xs, vec3(-10.0))) + vec3(1.0))) - xs) * (mbAs * 0.01) + xs; }
    vec2 pp = vec2(uv.x, 1.0 - uv.y) * uRes;
    if (mbSpOn > 0.5) {
        vec2 ce = uRes * 0.5 + vec2(mbSpX, mbSpY) * uRes * 0.005;
        float aa = (pp.x - ce.x) * mbSpAsp; float bb = pp.y - ce.y;
        float dd = sqrt(aa * aa + bb * bb) / (mbSpRad * 0.6 * uRes.y);
        float tt = clamp((1.0 - clamp(dd, 0.0, 1.0)) / max(mbSpSpr, 0.01), 0.0, 1.0);
        float uu = mbSpInv > 0.5 ? 1.0 - tt : tt;
        \(mblSMask("uu", "mbSpFall", "msp", "a"))
        c = (c * (mbSpC.rgb * exp2(mbSpS)) - c) * msp + c;
    }
    if (mbGxOn > 0.5) {
        vec2 sP = vec2(mbGxSx, mbGxSy) * uRes; vec2 eP = vec2(mbGxEx, mbGxEy) * uRes;
        vec2 dv = eP - sP; float gL = max(length(dv), 0.0001);
        float gt = clamp(1.0 - dot(dv / gL, pp - sP) / gL, 0.0, 1.0);
        \(mblSMask("gt", "mbGxFall", "mgx", "b"))
        c = ((c * (mbGxC.rgb * exp2(mbGxStops)) - c) * (mbGxStr * 0.01)) * mgx + c;
    }
    if (mbVgStr > 0.001 || abs(mbVgExp) > 0.001) {
        vec2 ce = uRes * 0.5 + vec2(mbVgX, mbVgY) * uRes * 0.005;
        float aa = mbVgAsp * (pp.x - ce.x); float bb = pp.y - ce.y;
        float dd = sqrt(aa * aa + bb * bb) / (mbVgRad * 0.6 * uRes.y);
        float tt = clamp((1.0 - clamp(dd, 0.0, 1.0)) / max(mbVgSpr, 0.01), 0.0, 1.0);
        \(mblSMask("tt", "mbVgFall", "mvg", "c"))
        vec3 gv = mvg * (1.0 - mbVgC.rgb) + mbVgC.rgb;
        c = ((gv * c - c) * (mbVgStr * 0.01) + c) * exp2(mbVgExp);
    }
    c = pow(max(c, vec3(0.0)), vec3(0.4545455));
    if (abs(mbHue) > 0.5 || abs(mbSat - 1.0) > 0.001) {
        float hr = mbHue * 0.0174533; float cs = cos(hr); float sn = sin(hr);
        float yy = dot(c, vec3(0.299, 0.587, 0.114)); float ii = dot(c, vec3(0.596, -0.274, -0.322)); float qq = dot(c, vec3(0.211, -0.523, 0.312));
        float i2 = (ii * cs - qq * sn) * mbSat; float q2 = (ii * sn + qq * cs) * mbSat;
        c = vec3(yy + 0.956 * i2 + 0.621 * q2, yy - 0.272 * i2 - 0.647 * q2, yy - 1.106 * i2 + 1.703 * q2);
    }
    \(hsl)
    \(curves)
    if (mbDuo > 0.001) {
        float l1 = dot(c, vec3(0.3, 0.59, 0.11));
        float dmn = min(c.r, min(c.g, c.b)); float dmx = max(c.r, max(c.g, c.b));
        float dL = clamp((dmx + dmn) * 0.5, 0.0, 1.0);
        float dt = clamp(mbDuoHi != mbDuoLo ? (dL - mbDuoLo) / (mbDuoHi - mbDuoLo) : 0.0, 0.0, 1.0);
        float da = clamp(dt * 2.0, 0.0, 1.0); float dw1 = da * da * 0.5;
        float db = clamp(1.0 - (dt - 0.5) * 2.0, 0.0, 1.0);
        float dw = clamp(0.5 - db * db * 0.5, 0.0, 1.0) + dw1;
        \(mblSetLum("mbDuoH.rgb", "dra", "p"))
        \(mblSetLum("mbDuoS.rgb", "drb", "q"))
        vec3 dRa = (dra - c) * mbDuoSA; vec3 dRb = (drb - c) * mbDuoSB;
        c = mix(c, c + dRb + (dRa - dRb) * dw, mbDuo);
    }
    if (mbGrain > 0.001) {
        vec2 gq = floor(uv * uRes / mbGrainSz) + floor(uTime * 24.0) * 13.7;
        vec3 gv = vec3(hash21(gq) - 0.5) + (vec3(hash21(gq + 1.3), hash21(gq + 7.1), hash21(gq + 3.9)) - 0.5) * 0.3;
        c += gv * mbGrain * 0.35;
    }
    c = mix(c0, c, mbInt);
    if (mbCo > 0.5) {
        vec3 co0 = c; float cl = dot(c, vec3(0.2126, 0.7152, 0.0722));
        float wS = 1.0 - smoothstep(0.0, 0.5, cl); float wH = smoothstep(0.5, 1.0, cl); float wM = clamp(1.0 - wS - wH, 0.0, 1.0);
        vec2 pS = vec2(mbCoSx, mbCoSy); vec2 pM = vec2(mbCoMx, mbCoMy); vec2 pH = vec2(mbCoHx, mbCoHy);
        vec3 oS = vec3(pS.x, dot(pS, vec2(-0.5, 0.866)), dot(pS, vec2(-0.5, -0.866)));
        vec3 oM = vec3(pM.x, dot(pM, vec2(-0.5, 0.866)), dot(pM, vec2(-0.5, -0.866)));
        vec3 oH = vec3(pH.x, dot(pH, vec2(-0.5, 0.866)), dot(pH, vec2(-0.5, -0.866)));
        c *= exp2(mbCoExp);
        c += wS * (oS + mbCoSl) * 0.3;
        c *= vec3(1.0) + wM * (oM + mbCoMl) * 0.8;
        c *= vec3(1.0) + wH * (oH + mbCoHl) * 0.8;
        float cl2 = dot(c, vec3(0.2126, 0.7152, 0.0722)); c = mix(vec3(cl2), c, mbCoSat);
        c = mix(co0, c, mbCoStr);
    }
    if (mbMj > 0.5) {
        vec3 mj0 = c; float ml = dot(c, vec3(0.299, 0.587, 0.114));
        c += mbMjTO * (vec3(-0.05, 0.03, 0.06) * (1.0 - smoothstep(0.0, 0.6, ml)) + vec3(0.07, 0.02, -0.06) * smoothstep(0.4, 1.0, ml));
        c *= vec3(exp2(mbMjWarm * 0.2), 1.0, exp2(-mbMjWarm * 0.2));
        c = (c - 0.18) * (1.0 + mbMjCon * 0.6) + 0.18;
        float ml2 = dot(c, vec3(0.299, 0.587, 0.114)); c = mix(vec3(ml2), c, mbMjSat);
        c = c * (1.0 - mbMjFade * 0.3) + mbMjFade * 0.08;
        c = mix(mj0, c, mbMjAmt);
    }
    return vec4(max(c, vec3(0.0)) * a, a);
""")]
}
