// BuiltinsNodeVideo.swift — the "Node Video" section: NodeVideo Asset Store effects (Rays, Rays 2, Prism, Prism 1,
// Glitch Prism, Manga) ported from their decompiled shaders. Every effect here shows the Node Video sample picture
// (Resources/img/fx_nodevideo.jpg) as its gallery thumbnail (EffectThumbs.sampleIndex). The "inner mask" inputs of the
// originals are not ported (the app has no mask texture input); centre points are % of the frame from the top-left.

import Foundation

private let nvOnOff = ["Off", "On"]

func nodeVideoFx() -> [EffectDef] {
    func col(_ h: UInt32) -> Int32 { Int32(bitPattern: h) }
    let cat = "Node Video"
    func centre(_ k: String) -> [PropDef] { [PropDef(k + "X", "Center X (%)", -50, 150, 50, 1), PropDef(k + "Y", "Center Y (%)", -50, 150, 50, 1)] }
    var out: [EffectDef] = []

    // ---- Rays ----
    out.append(EffectDef(id: "nv.rays", name: "Rays (NV)", desc: "NodeVideo 'rays': bright areas above the threshold are smeared toward the centre point and added to the picture.",
        category: cat, props: centre("nvR") + [
            PropDef("nvRSam", "Samples", 1, 256, 128, 0), PropDef("nvRBri", "Brightness", 0, 2, 1, 2), PropDef("nvRDis", "Dispersion", 0, 1, 0, 2),
            PropDef("nvRAmt", "Amount", 0, 1, 1, 2), PropDef("nvRThr", "Threshold", 0, 1, 0.3, 2), PropDef("nvRWei", "Weight", 0, 10, 2, 2),
            PropDef("nvRBle", "Blend", 0, 1, 1, 2)],
        colors: [ColorParam("nvRCol", "Color", col(0xFFFFFFFF))], previewAnim: "fade", glsl: """
    vec2 ce = vec2(nvRX * 0.01, 1.0 - nvRY * 0.01);
    float n = floor(nvRSam);
    vec2 stp = (ce - uv) / n * nvRAmt;
    vec2 p = uv;
    vec4 acc = vec4(0.0);
    for (int i = 0; i < 256; i++) {
        if (float(i) < n) {
            vec4 s = src(p);
            float t = float(i) / max(n - 1.0, 1.0);
            float z = t * 3.0 - 1.5;
            vec3 w = clamp(vec3(-z, 1.0 - abs(z), z), 0.0, 1.0);
            s.rgb = nvRDis * (s.rgb * w * 3.0 - s.rgb) + s.rgb;
            s = s * nvRBri * nvRCol + acc;
            if (nvRThr < dot(src(p).rgb, vec3(0.3, 0.59, 0.11))) { acc = s; }
            p += stp;
        }
    }
    vec4 r = acc / n * nvRWei;
    return src(uv) * nvRBle + r;
"""))

    // ---- Rays 2 ----
    out.append(EffectDef(id: "nv.rays2", name: "Rays2 (NV)", desc: "NodeVideo 'rays2': like Rays with a 1/3-colour gradient along each ray, a length control and screen blending.",
        category: cat, props: centre("nvQ") + [
            PropDef("nvQSam", "Samples", 1, 256, 128, 0), PropDef("nvQBri", "Brightness", 0, 4, 4, 2), PropDef("nvQDis", "Dispersion", 0, 1, 0, 2),
            PropDef("nvQAmt", "Amount", 0, 1, 1, 2), PropDef("nvQThr", "Threshold", 0, 1, 0.3, 2), PropDef("nvQLen", "Length", 0, 2, 1, 2),
            PropDef("nvQCol", "Colorize", 0, 2, 0, 0, ["None", "2-Color", "3-Color"]), PropDef("nvQOff", "Color Offset", 0, 2, 1, 2),
            PropDef("nvQSrc", "Source Opacity", 0, 1, 1, 2), PropDef("nvQRay", "Ray Opacity", 0, 1, 1, 2),
            PropDef("nvQBase", "Base On", 0, 2, 0, 0, ["Luma", "Hue", "Saturation"])],
        colors: [ColorParam("nvQC1", "Color1", col(0xFFFFFFFF)), ColorParam("nvQC2", "Color2", col(0xFFFFFF00)), ColorParam("nvQC3", "Color3", col(0xFFFF0D00))],
        previewAnim: "fade", glsl: """
    vec2 ce = vec2(nvQX * 0.01, 1.0 - nvQY * 0.01);
    float n = floor(nvQSam);
    vec2 stp = (ce - uv) / n * nvQAmt;
    vec2 p = uv;
    vec4 d1 = nvQC2 - nvQC1;
    vec4 d2 = nvQC3 - nvQC2;
    float il = 1.0 / max(nvQLen, 0.01);
    vec4 acc = vec4(0.0);
    for (int i = 0; i < 256; i++) {
        if (float(i) < n) {
            vec4 s = src(p);
            float t = float(i) / n;
            vec4 g1 = pow(t, nvQOff) * d1 + nvQC1;
            vec4 ga = pow(t * 2.0, nvQOff) * d1 + nvQC1;
            vec4 gb = pow(max(t * 2.0 - 1.0, 0.0), nvQOff) * d2 + nvQC2;
            vec4 g3 = t < 0.5 ? ga : gb;
            vec4 gc = nvQCol > 1.5 ? g3 : (nvQCol > 0.5 ? g1 : nvQC1);
            gc.rgb = gc.rgb * (gc.rgb * (gc.rgb * 0.305306 + 0.682171) + 0.0125229);
            vec3 hs = rgb2hsv(s.rgb);
            float lum = dot(s.rgb, vec3(0.3, 0.59, 0.11));
            float bv = nvQBase > 1.5 ? hs.y : (nvQBase > 0.5 ? abs(hs.x) : lum);
            float z = float(i) / max(n - 1.0, 1.0) * 3.0 - 1.5;
            vec3 w = clamp(vec3(-z, 1.0 - abs(z), z), 0.0, 1.0);
            s.rgb = nvQDis * (s.rgb * w * 3.0 - s.rgb) + s.rgb;
            s = s * gc * nvQBri;
            s = s * pow(1.0 - t, il) + acc;
            if (nvQThr < bv) { acc = s; }
            p += stp;
        }
    }
    vec4 r = acc / n;
    vec4 o0 = src(uv);
    vec4 sc = vec4(o0.rgb, o0.a * nvQSrc);
    r.a = r.a * nvQRay;
    return clamp(vec4(1.0) - (vec4(1.0) - sc) * (vec4(1.0) - r), 0.0, 1.0);
"""))

    // ---- Prism ----
    out.append(EffectDef(id: "nv.prism", name: "Prism (NV)", desc: "NodeVideo 'prism': radial RGB-split blur away from a centre point, stronger toward the edges.",
        category: cat, props: centre("nvP") + [
            PropDef("nvPSam", "Samples", 1, 128, 50, 0), PropDef("nvPBlu", "Blur", 0, 1, 0.25, 2), PropDef("nvPFal", "Falloff", 0, 10, 3, 2),
            PropDef("nvPSx", "RGB Shift R", -10, 10, 1, 2), PropDef("nvPSy", "RGB Shift G", -10, 10, 2, 2), PropDef("nvPSz", "RGB Shift B", -10, 10, 3, 2)],
        previewAnim: "fade", glsl: """
    vec2 ce = vec2(nvPX * 0.01, 1.0 - nvPY * 0.01);
    vec2 dv = uv - ce;
    vec2 dir = dv / max(length(dv), 0.00001) * nvPBlu;
    float fo = pow(max(length(uv - 0.5), 0.00001), nvPFal);
    vec2 v = dir * fo;
    float n = floor(nvPSam);
    float inv = 1.0 / n;
    vec2 vr = v * nvPSx;
    vec2 vg = v * nvPSy;
    vec2 vb = v * nvPSz;
    vec2 pr = vec2(0.0);
    vec2 pg = vec2(0.0);
    vec2 pb = vec2(0.0);
    vec4 acc = vec4(0.0);
    for (int i = 0; i < 128; i++) {
        if (float(i) < n) {
            vec4 sr = src(uv + pr);
            vec4 sg = src(uv + pg);
            vec4 sb = src(uv + pb);
            acc += vec4(sr.r, sg.g, sb.b, (sr.a + sg.a + sb.a) * 0.3333333);
            pr -= vr * inv;
            pg -= vg * inv;
            pb -= vb * inv;
        }
    }
    return acc / n;
"""))

    // ---- Prism 1 and Glitch Prism (the same shader, two entries as in the store) ----
    func wobble(_ id: String, _ name: String, _ desc: String, _ k: String) -> EffectDef {
        EffectDef(id: id, name: name, desc: desc, category: cat, props: [
            PropDef(k + "Amp", "Amplitude", 0, 1, 0.5, 2), PropDef(k + "Spd", "Speed", 1, 10, 3, 2), PropDef(k + "Dir", "Direction", -45, 360, -45, 0, nil, true, 180)],
            previewAnim: "swipe", glsl: """
    float ang = (\(k)Dir + 90.0) * 0.0174532942;
    vec2 dv = vec2(sin(-ang), cos(ang));
    vec2 nz = sin(uv * 20.0 + uTime * \(k)Spd);
    nz = nz * nz * nz;
    vec4 acc = vec4(0.0);
    for (int i = 0; i < 100; i++) {
        float t = float(i) * 0.01;
        float wy = pow(max(t * (1.0 - t), 0.00001), 1.5) * 6.8;
        vec3 c = vec3(t, wy, 1.0 - t);
        vec2 off = nz * (t * dv * \(k)Amp) * 0.1 + uv;
        acc += vec4(c * c, 1.0) * src(off);
    }
    return acc * vec4(0.029555222, 0.0302767847, 0.0295551848, 0.00990098994);
""")
    }
    out.append(wobble("nv.prism1", "Prism1 (NV)", "NodeVideo 'prism1': animated, directional RGB prism wobble.", "nvA"))
    out.append(wobble("nv.glitchprism", "Glitch Prism (NV)", "NodeVideo 'glitch_prism': animated, directional RGB prism glitch.", "nvG"))

    // ---- Manga ----
    out.append(EffectDef(id: "nv.manga", name: "Manga (NV)", desc: "NodeVideo 'manga': black and white screen-tone dots with ink edge lines.",
        category: cat, props: [PropDef("nvMInt", "Intensity", 0.05, 10, 2, 2)], previewAnim: "fade", glsl: """
    vec4 c0 = src(uv);
    float t1 = clamp((c0.x - (nvMInt * 0.125 - 0.2)) * 3.33333349, 0.0, 1.0);
    float sm = t1 * t1 * (3.0 - 2.0 * t1);
    float fq = 2136.28125 / nvMInt * 1.66666663;
    vec2 q = uv * 0.707106411;
    float cx = cos(fq * (q.x + q.y)) * 0.25 + 0.5;
    float pat = cos(fq * (uv.x * 0.707106411 - q.y)) * 0.25 + cx;
    float v = sm > 0.3 ? sm + pat : sm;
    float e = 0.00390625;
    vec4 wl = vec4(0.3, 0.59, 0.11, 0.25);
    float a = dot(src(uv + vec2(-e, -e)), wl);
    float b = dot(src(uv + vec2(e, -e)), wl);
    float c = dot(src(uv + vec2(-e, 0.0)), wl);
    float d = dot(src(uv + vec2(-e, e)), wl);
    float f = dot(src(uv + vec2(0.0, e)), wl);
    float g = dot(src(uv + vec2(e, e)), wl);
    float x2 = b + g + c * 2.0 - a - c * 2.0 - d;
    float y2 = f * 2.0 + d + g - a - a * 2.0 - b;
    float edge = (x2 * x2 + y2 * y2) > 0.04 ? -1.0 : 0.0;
    v = edge * pat + v;
    return vec4(v, v, v, c0.a);
"""))

    // ---- Effect Lut: 32x32x32 strip LUT (1024x32 image) taken from a layer picked as "LUT Layer" ----
    out.append(EffectDef(id: "nv.lut", name: "Effect Lut (NV)", desc: "NodeVideo 'Effect_Lut': colour-grades the layer with a 32-slice strip LUT (1024x32 image). Add the LUT image as a layer and pick it as the LUT Layer. With no LUT picked the layer is unchanged.",
        category: cat, props: [PropDef("nvLBle", "Blend", 0, 1, 1, 2)], inputs: ["LUT Layer"], previewAnim: "fade", glsl: """
    vec4 s0 = src(uv);
    vec3 c = s0.rgb / max(s0.a, 0.0001);
    float fz = fract(c.z * 31.0);
    vec3 t = c * vec3(0.0302734375, 0.96875, 31.0) + vec3(0.00048828125, 0.015625, 0.0);
    float sl = t.z - fz;
    vec2 p0 = t.xy + vec2(sl * 0.03125, 0.0);
    vec2 p1 = p0 + vec2(0.03125, 0.0);
    vec3 l0 = in0(p0).rgb;
    vec3 l1 = in0(p1).rgb;
    vec3 g = fz * (l1 - l0) + l0;
    if (uHas0 < 0.5) { g = c; }
    c = mix(c, g, nvLBle);
    return vec4(c * s0.a, s0.a);
"""))
    return out
}
