// BuiltinsShine.swift — "Shine": volumetric light rays from a source point (sun through clouds, headlights in fog,
// underwater beams). Pre-process threshold, Ray Length + Falloff, Shimmer, Boost Light, Colorize (1/3/5-colour gradient),
// Fractal Noise (smoky rays with parallax), Source/Shine opacity, Blend Mode, and two kinds of mask:
//   • Shape Mask  — an ellipse / rectangle with Feather, Opacity, Expansion, Invert (follows the layer's transform);
//   • Mask Layer  — any layer picked as the "Mask Layer" input (alpha or luma) with its own Feather / Expansion / Invert.
//
// Source Point Type: "2D" pins the source to a frame position. "3D (Camera-aware)" places it at a position in the scene
// and projects it through the scene camera every frame (ShineCam.resolve, called by the Metal renderer), so camera
// moves, orbits, rolls and zooms carry the rays with them and the ray length follows the perspective scale. The camera
// is found even when it sits below an adjustment layer in the stack. "Follow Layer Transform" makes the source (and the
// shape mask) ride on the layer carrying the effect — its position, rotation, scale, 3D tilt and parents.

import Foundation

private let shOnOff = ["Off", "On"]

/// Preset: name, parameter values, gradient colours (Highlights, Mid High, Midtones, Mid Low, Shadows as 0xRRGGBB).
let shinePresets: [(name: String, v: [String: Float], cols: [UInt32])] = [
    ("Default", [:], [0xFFFFFF, 0xFFE066, 0x00C8F0, 0xFFA060, 0x0A5CFF]),
    ("Sunbeam", ["shRay": 6, "shBoost": 5, "shShAmt": 25, "shFnAmt": 30, "shCol": 3, "shThr": 60], [0xFFFFFF, 0xFFF1B0, 0xFFC857, 0xFF9A3C, 0xC2410C]),
    ("Fire", ["shRay": 5, "shBoost": 8, "shShAmt": 40, "shFnAmt": 45, "shCol": 3, "shThr": 58], [0xFFFFE0, 0xFFD23C, 0xFF7A00, 0xD01C00, 0x420000]),
    ("Ice", ["shRay": 4, "shBoost": 0, "shShAmt": 15, "shFnAmt": 20, "shCol": 2], [0xFFFFFF, 0xD6F4FF, 0x7FD4FF, 0x3A8CFF, 0x0A2A8A]),
    ("Electric", ["shRay": 7, "shBoost": 10, "shThr": 62, "shShAmt": 55, "shShDet": 40, "shFnAmt": 10, "shCol": 2], [0xFFFFFF, 0xE0D0FF, 0xA070FF, 0x6030FF, 0x1A0A6A]),
    ("Underwater", ["shRay": 8, "shBoost": 0, "shShAmt": 25, "shFnAmt": 45, "shFnScale": 18, "shCol": 2, "shThr": 62], [0xE8FFFF, 0xA0F0E0, 0x40C8D0, 0x1890B0, 0x063A60]),
    ("Headlights in Fog", ["shRay": 9, "shBoost": 5, "shFnAmt": 55, "shFnScale": 25, "shCol": 1, "shThr": 65], [0xFFF8E8, 0xFFF8E8, 0xFFF8E8, 0xFFF8E8, 0xFFF8E8]),
]

enum ShineCam {
    // MARK: camera
    /// The camera an effect looks through: the layer's own scene camera, or — for an adjustment layer that sits above the
    /// camera in the stack (the usual place for it) — the nearest visible camera of the same scope below it.
    static func camera(for l: Layer) -> Layer? {
        if Xf.flatDraw { return nil }
        if let c = Xf.camera(for: l) { return c }
        guard l.type == .ADJUST, let idx = Editor.scene.layers.firstIndex(where: { $0 === l }) else { return nil }
        let scope = Xf.cameraScope(l)
        var best: Layer? = nil
        var bi = -1
        for (j, c) in Editor.scene.layers.enumerated() where c.type == .CAMERA && c.visible && j < idx && Xf.cameraScope(c) == scope {
            if j > bi { best = c; bi = j }
        }
        return best
    }

    /// View-projection for a layer that is seen through the camera (adjustment layers, 3D layers, models); nil otherwise.
    static func viewProj(_ l: Layer, time: Float, width: Int, height: Int) -> [Float]? {
        guard l.type == .ADJUST || l.is3d || l.type == .MODEL else { return nil }
        let ar = Float(width) / Float(max(height, 1))
        if let e = SceneRenderer.editCam {
            return MetalCam.lookAt(e[0], ar, e[1], e[2], e[3], e[4] * Float.pi / 180, e[5] * Float.pi / 180, 0)
        }
        guard let cam = camera(for: l) else { return nil }
        return MetalCam.vp(camera: cam, time: time, width: width, height: height)
    }

    /// World point -> screen. nx/ny are NDC (-1...1, y up); scale = on-screen size of one world unit relative to the neutral view.
    static func project(_ l: Layer, time: Float, width: Int, height: Int, _ x: Float, _ y: Float, _ z: Float) -> (nx: Float, ny: Float, scale: Float, visible: Bool) {
        let ar = Float(width) / Float(max(height, 1))
        if let vp = viewProj(l, time: time, width: width, height: height) {
            let cw = vp[3] * x + vp[7] * y + vp[11] * z + vp[15]
            if cw < 0.02 { return (0, 0, 1, false) }
            return ((vp[0] * x + vp[4] * y + vp[8] * z + vp[12]) / cw, (vp[1] * x + vp[5] * y + vp[9] * z + vp[13]) / cw, abs(vp[5]) / cw, true)
        }
        if l.type == .ADJUST || l.is3d || l.type == .MODEL {         // no camera: the default z = 3 view the 3D layers use
            let w = 1 - z / 3
            if w < 0.02 { return (0, 0, 1, false) }
            return (x / ar / w, y / w, 1 / w, true)
        }
        return (x / ar, y, 1, true)                                   // a flat 2D layer is not seen through the camera
    }

    // MARK: layer transform
    /// The layer's 2D affine [a b c d tx ty] (position, rotation Z, scale, anchor, parents) — identity when it is degenerate.
    static func affine(_ l: Layer, _ t: Float) -> [Float] {
        var m = Xf.matrix(l, t)
        let det = m[0] * m[3] - m[1] * m[2]
        if !det.isFinite || abs(det) < 1e-6 { m = [1, 0, 0, 1, m[4].isFinite ? m[4] : 0, m[5].isFinite ? m[5] : 0] }
        return m
    }

    /// Uniform on-screen scale of the layer's own 2D transform (1 when degenerate).
    static func layerScale(_ l: Layer, _ t: Float) -> Float {
        let m = affine(l, t)
        let s = sqrt(abs(m[0] * m[3] - m[1] * m[2]))
        return (s.isFinite && s > 1e-4) ? s : 1
    }

    /// A point given in the layer's own space (world units from its centre) -> world: position, rotation, scale, parents
    /// and the 3D tilt (rotX / rotY, same order as the model matrix).
    static func world(_ l: Layer, _ t: Float, _ lx: Float, _ ly: Float, _ lz: Float) -> (Float, Float, Float) {
        let m = affine(l, t)
        let lt = l.editTime("x", t)
        let ux = m[0] * lx + m[2] * ly, uy = m[1] * lx + m[3] * ly
        var sc = l.p("scale", lt)
        if !sc.isFinite || sc < 1e-4 { sc = 1 }
        let is3 = (l.is3d && l.type != .ADJUST && l.type != .GROUP) || l.type == .MODEL
        if !is3 { return (m[4] + ux, m[5] + uy, 0) }
        let uz = lz * sc
        // same order and signs as the layer quad shader (clipPos): rotY (negated) first, then rotX
        let rx = l.p("rotX", lt) * Float.pi / 180, ry = -l.p("rotY", lt) * Float.pi / 180
        let cy = cos(ry), sy = sin(ry), cx = cos(rx), sx = sin(rx)
        let x1 = ux * cy + uz * sy, z1 = -ux * sy + uz * cy
        let y2 = uy * cx - z1 * sx, z2 = uy * sx + z1 * cx
        return (m[4] + x1, m[5] + y2, Xf.worldZ(l, t) + z2)
    }

    // MARK: resolve
    /// Turns the stored source / mask inputs into the on-screen values the shader reads (shX, shY, shSc, shVis, shMX...).
    /// Used by the Metal renderer for every "shine" step and by the dashboard gizmo, so both always agree.
    static func resolve(_ def: EffectDef, _ props: inout [Float], layer l: Layer, time: Float, width: Int, height: Int) {
        var idx: [String: Int] = [:]
        for (i, p) in def.props.enumerated() { idx[p.key] = i }
        func get(_ k: String, _ d: Float) -> Float { if let i = idx[k], i < props.count { return props[i] }; return d }
        func put(_ k: String, _ v: Float) { if let i = idx[k], i < props.count { props[i] = v } }
        let ar = Float(width) / Float(max(height, 1))
        let three = get("shType", 0) > 0.5, follow = get("shFollow", 1) > 0.5
        let lscale = layerScale(l, time)
        var sc: Float = 1, vis: Float = 1
        if three {
            let lx = get("shWX", 0), ly = get("shWY", 0.3), lz = get("shWZ", 0)
            let w = follow ? world(l, time, lx, ly, lz) : (lx, ly, lz)
            let p = project(l, time: time, width: width, height: height, w.0, w.1, w.2)
            put("shX", (p.nx * 0.5 + 0.5) * 100); put("shY", (0.5 - p.ny * 0.5) * 100)
            sc = min(max(p.scale, 0.05), 6); vis = p.visible ? 1 : 0
        } else if follow {
            let w = world(l, time, (get("shX", 50) * 0.02 - 1) * ar, 1 - get("shY", 35) * 0.02, 0)
            put("shX", (w.0 / ar * 0.5 + 0.5) * 100); put("shY", (0.5 - w.1 * 0.5) * 100)
            sc = lscale
        }
        if follow && get("shMask", 0) > 0.5 {
            let w = world(l, time, (get("shMX", 50) * 0.02 - 1) * ar, 1 - get("shMY", 50) * 0.02, 0)
            put("shMX", (w.0 / ar * 0.5 + 0.5) * 100); put("shMY", (0.5 - w.1 * 0.5) * 100)
            put("shMW", get("shMW", 40) * lscale); put("shMH", get("shMH", 45) * lscale)
        }
        put("shSc", sc); put("shVis", vis)
    }

    /// Moves the input pair (kx, ky) until the resolved on-screen point (outX, outY, % of the frame) sits under the finger.
    static func solve(_ def: EffectDef, base: [Float], layer l: Layer, time: Float, width: Int, height: Int,
                      kx: String, ky: String, outX: String, outY: String, target: (Float, Float), step: Float, needVis: Bool = true) -> (Float, Float)? {
        func ix(_ k: String) -> Int? { def.props.firstIndex { $0.key == k } }
        guard let i1 = ix(kx), let i2 = ix(ky), let o1 = ix(outX), let o2 = ix(outY), let iv = ix("shVis") else { return nil }
        func eval(_ x: Float, _ y: Float) -> (Float, Float)? {
            var p = base; p[i1] = x; p[i2] = y
            resolve(def, &p, layer: l, time: time, width: width, height: height)
            return (needVis && p[iv] < 0.5) ? nil : (p[o1], p[o2])
        }
        var x = base[i1], y = base[i2]
        for _ in 0..<6 {
            guard let p0 = eval(x, y) else { return nil }
            let ex = target.0 - p0.0, ey = target.1 - p0.1
            if abs(ex) + abs(ey) < 0.01 { break }
            guard let px = eval(x + step, y), let py = eval(x, y + step) else { return nil }
            let j00 = (px.0 - p0.0) / step, j10 = (px.1 - p0.1) / step, j01 = (py.0 - p0.0) / step, j11 = (py.1 - p0.1) / step
            let det = j00 * j11 - j01 * j10
            if abs(det) < 1e-9 { return nil }
            x += (j11 * ex - j01 * ey) / det
            y += (-j10 * ex + j00 * ey) / det
        }
        return (x, y)
    }
}

func shineFx() -> [EffectDef] {
    func col(_ h: UInt32) -> Int32 { Int32(bitPattern: 0xFF000000 | h) }
    let props: [PropDef] = [
        PropDef("shType", "Source Point Type", 0, 1, 0, 0, ["2D", "3D (Camera-aware)"]),
        PropDef("shFollow", "Follow Layer Transform", 0, 1, 1, 0, shOnOff),
        PropDef("shX", "Source X (%)", -50, 150, 50, 1), PropDef("shY", "Source Y (%)", -50, 150, 35, 1),
        PropDef("shWX", "3D Source X", -4, 4, 0, 2), PropDef("shWY", "3D Source Y", -4, 4, 0.3, 2), PropDef("shWZ", "3D Source Z", -6, 6, 0, 2),
        PropDef("shSc", "(perspective scale)", 0.05, 6, 1, 2), PropDef("shVis", "(source visible)", 0, 1, 1, 0),
        PropDef("shThr", "Pre-process Threshold", 0, 100, 65, 1),
        PropDef("shRay", "Ray Length", 0, 20, 4, 1), PropDef("shFall", "Ray Falloff", 0, 100, 50, 1),
        PropDef("shQ", "Quality", 0, 2, 1, 0, ["Low", "Medium", "High"]),
        PropDef("shBoost", "Boost Light", 0, 100, 0, 1),
        PropDef("shShAmt", "Shimmer Amount", 0, 100, 0, 1), PropDef("shShDet", "Shimmer Detail", 0, 100, 10, 1),
        PropDef("shShInf", "Source Point Influence", 0, 100, 0, 1), PropDef("shShRad", "Shimmer Radius", 0, 100, 10, 1),
        PropDef("shShPh", "Shimmer Phase", -360, 360, 0, 1, nil, true, 180), PropDef("shShRed", "Reduce Flickering", 0, 1, 0, 0, shOnOff),
        PropDef("shCol", "Colorize", 0, 3, 2, 0, ["None", "1-Color", "3-Color Gradient", "5-Color Gradient"]),
        PropDef("shBase", "Base On", 0, 5, 0, 0, ["Lightness", "Luminance", "Alpha", "Red", "Green", "Blue"]),
        PropDef("shFnAmt", "Fractal Noise Amount", 0, 100, 0, 1), PropDef("shFnScale", "Fractal Noise Scale", 1, 60, 10, 1),
        PropDef("shFnDet", "Fractal Noise Detail", 1, 6, 3, 0), PropDef("shFnEvo", "Fractal Noise Evolution", 0, 10, 1, 2),
        PropDef("shFnPar", "Fractal Noise Parallax", 0, 100, 0, 1),
        PropDef("shSrcOp", "Source Opacity", 0, 100, 100, 1), PropDef("shOp", "Shine Opacity", 0, 100, 100, 1),
        PropDef("shBlend", "Blend Mode", 0, 5, 3, 0, ["None (Shine only)", "Normal", "Add", "Screen", "Overlay", "Multiply"]),
        PropDef("shMApply", "Masks Affect", 0, 2, 0, 0, ["Rays (Output)", "Source (Emitters)", "Both"]),
        PropDef("shMask", "Shape Mask", 0, 1, 0, 0, shOnOff), PropDef("shMShape", "Mask Shape", 0, 1, 0, 0, ["Ellipse", "Rectangle"]),
        PropDef("shMX", "Mask X (%)", 0, 100, 50, 1), PropDef("shMY", "Mask Y (%)", 0, 100, 50, 1),
        PropDef("shMW", "Mask Width (%)", 1, 200, 40, 1), PropDef("shMH", "Mask Height (%)", 1, 200, 45, 1),
        PropDef("shMFe", "Mask Feather (px)", 0, 500, 100, 0), PropDef("shMOp", "Mask Opacity", 0, 100, 100, 1),
        PropDef("shMEx", "Mask Expansion (px)", -300, 300, 0, 0), PropDef("shMInv", "Mask Inverted", 0, 1, 0, 0, shOnOff),
        PropDef("shLMSrc", "Mask Layer Uses", 0, 1, 0, 0, ["Alpha", "Luma"]), PropDef("shLMFe", "Mask Layer Feather (px)", 0, 300, 20, 0),
        PropDef("shLMEx", "Mask Layer Expansion (px)", -150, 150, 0, 0), PropDef("shLMInv", "Mask Layer Inverted", 0, 1, 0, 0, shOnOff),
        PropDef("shLMOp", "Mask Layer Opacity", 0, 100, 100, 1),
    ]
    let colors: [ColorParam] = [
        ColorParam("shCHi", "Highlights", col(0xFFFFFF)), ColorParam("shCMH", "Mid High", col(0xFFE066)),
        ColorParam("shCMid", "Midtones", col(0x00C8F0)), ColorParam("shCML", "Mid Low", col(0xFFA060)),
        ColorParam("shCSh", "Shadows", col(0x0A5CFF)),
    ]
    return [EffectDef(
        id: "shine", name: "Shine",
        desc: "Light rays from a source point. 2D pins it to the frame; 3D (Camera-aware) places it in the scene and follows the camera (use on an adjustment layer). Mask it with the shape mask or by picking a Mask Layer. Tap Open Dashboard for presets, the on-screen gizmo and every control.",
        category: "Light and glow", props: props, colors: colors, inputs: ["Mask Layer"], previewAnim: "fade", glsl: """
    vec2 px = 1.0 / uRes;
    float asp = uRes.x / max(uRes.y, 1.0);
    float pxs = uRes.y / 1080.0;
    vec4 s0 = src(uv);
    float a0 = s0.a;
    vec2 S = vec2(shX * 0.01, 1.0 - shY * 0.01);
    float sc = max(shSc, 0.05);
    vec2 d = S - uv;
    vec2 da = vec2(d.x * asp, d.y);
    float dist = length(da);
    float L = clamp(shRay * 0.1 * sc, 0.0, 1.0);
    float nF = shQ < 0.5 ? 24.0 : (shQ < 1.5 ? 40.0 : 64.0);
    float thr = min(shThr * 0.01, 0.98);
    float jit = fract(52.9829189 * fract(dot(uv * uRes, vec2(0.06711056, 0.00583715))));
    float pw = 0.6 + shFall * 0.03;
    float mShape = shMask > 0.5 ? 1.0 : 0.0;
    float useOut = (shMApply < 0.5 || shMApply > 1.5) ? 1.0 : 0.0;
    float useSrc = shMApply > 0.5 ? 1.0 : 0.0;
    vec2 mc = vec2(shMX * 0.01, 1.0 - shMY * 0.01);
    vec2 hp = max(vec2(shMW * 0.005 * uRes.x, shMH * 0.005 * uRes.y) + shMEx * pxs, vec2(1.0));
    float mfe = max(shMFe * pxs, 0.5);
    vec3 acc = vec3(0.0);
    float wsum = 0.0;
    for (int i = 0; i < 64; i++) {
        if (float(i) < nF) {
            float t = (float(i) + jit) / nF;
            vec2 sp = uv + d * (t * L);
            vec3 sm = src(sp).rgb;
            float sl = dot(sm, vec3(0.299, 0.587, 0.114));
            float wt = pow(1.0 - t, pw);
            float em = 1.0;
            if (useSrc > 0.5) {
                if (mShape > 0.5) {
                    vec2 pe = max(abs((sp - mc) * uRes), vec2(0.001));
                    float dq = 0.0;
                    if (shMShape < 0.5) { float k0 = length(pe / hp); float k1 = length(pe / (hp * hp)); dq = k0 * (k0 - 1.0) / max(k1, 0.000001); }
                    else { vec2 qd = pe - hp; dq = length(max(qd, vec2(0.0))) + min(max(qd.x, qd.y), 0.0); }
                    float me = clamp(0.5 - dq / mfe, 0.0, 1.0);
                    me = me * me * (3.0 - 2.0 * me);
                    if (shMInv > 0.5) { me = 1.0 - me; }
                    em *= mix(1.0, me, shMOp * 0.01);
                }
                if (uHas0 > 0.5) {
                    vec4 mq = in0(sp);
                    float ml = shLMSrc > 0.5 ? dot(mq.rgb, vec3(0.299, 0.587, 0.114)) : mq.a;
                    if (shLMInv > 0.5) { ml = 1.0 - ml; }
                    em *= mix(1.0, clamp(ml, 0.0, 1.0), shLMOp * 0.01);
                }
            }
            acc += sm * smoothstep(thr, 1.0, sl) * wt * em;
            wsum += wt;
        }
    }
    vec3 rays = acc / max(wsum, 0.0001) * ((0.5 + 1.2 * L) * 1.8) * (1.0 + shBoost * 0.05);
    if (shShAmt > 0.01) {
        float ang = atan(-d.y, -d.x * asp);
        float fq = 2.0 + shShDet * 0.35;
        float infl = shShInf * 0.01 * dist * (shShRad * 0.2 + 0.5);
        vec2 np = vec2(cos(ang), sin(ang)) * fq + vec2(shShPh / 57.29578 + infl * 3.0, infl);
        float n1 = vnoise(np);
        float n2 = vnoise(np * 2.1 + 7.3);
        float nn = shShRed > 0.5 ? n1 : (n1 * 0.65 + n2 * 0.35);
        rays *= max(1.0 + (nn - 0.5) * 2.4 * shShAmt * 0.01, 0.0);
    }
    if (shFnAmt > 0.01) {
        vec2 q = (uv - S) * vec2(asp, 1.0) * (1.0 + shFnPar * 0.03 * dist) * (60.0 / max(shFnScale, 1.0) * 0.4);
        q += vec2(uTime * 0.3, uTime * 0.17) * shFnEvo;
        float fa = 0.0;
        float fw = 0.5;
        float fs = 0.0;
        for (int o = 0; o < 6; o++) {
            if (float(o) < shFnDet) { fa += fw * vnoise(q); fs += fw; q = q * 2.03 + 3.1; fw *= 0.5; }
        }
        float fnv = fa / max(fs, 0.0001);
        rays *= mix(1.0, clamp(fnv * 2.2, 0.0, 2.0), shFnAmt * 0.01);
    }
    float rl = dot(rays, vec3(0.299, 0.587, 0.114));
    if (shBase < 0.5) { rl = (max(rays.r, max(rays.g, rays.b)) + min(rays.r, min(rays.g, rays.b))) * 0.5; }
    else if (shBase > 1.5 && shBase < 2.5) { rl = max(rays.r, max(rays.g, rays.b)); }
    else if (shBase > 2.5 && shBase < 3.5) { rl = rays.r; }
    else if (shBase > 3.5 && shBase < 4.5) { rl = rays.g; }
    else if (shBase > 4.5) { rl = rays.b; }
    float tg = pow(clamp(rl * 2.2, 0.0, 1.0), 0.8);
    if (shCol > 2.5) {
        vec3 g5 = tg < 0.25 ? mix(shCSh.rgb, shCML.rgb, tg * 4.0) : (tg < 0.5 ? mix(shCML.rgb, shCMid.rgb, (tg - 0.25) * 4.0) : (tg < 0.75 ? mix(shCMid.rgb, shCMH.rgb, (tg - 0.5) * 4.0) : mix(shCMH.rgb, shCHi.rgb, (tg - 0.75) * 4.0)));
        rays = g5 * rl;
    } else if (shCol > 1.5) {
        vec3 g3 = tg < 0.5 ? mix(shCSh.rgb, shCMid.rgb, tg * 2.0) : mix(shCMid.rgb, shCHi.rgb, (tg - 0.5) * 2.0);
        rays = g3 * rl;
    } else if (shCol > 0.5) {
        rays = shCHi.rgb * rl;
    }
    float mk = 1.0;
    if (mShape > 0.5 && useOut > 0.5) {
        vec2 pe = max(abs((uv - mc) * uRes), vec2(0.001));
        float dq = 0.0;
        if (shMShape < 0.5) { float k0 = length(pe / hp); float k1 = length(pe / (hp * hp)); dq = k0 * (k0 - 1.0) / max(k1, 0.000001); }
        else { vec2 qd = pe - hp; dq = length(max(qd, vec2(0.0))) + min(max(qd.x, qd.y), 0.0); }
        float m = clamp(0.5 - dq / mfe, 0.0, 1.0);
        m = m * m * (3.0 - 2.0 * m);
        if (shMInv > 0.5) { m = 1.0 - m; }
        mk = mix(1.0, m, shMOp * 0.01);
    }
    if (uHas0 > 0.5 && useOut > 0.5) {
        float ex = shLMEx * pxs;
        float fe = shLMFe * pxs;
        vec4 m0 = in0(uv);
        float lm = shLMSrc > 0.5 ? dot(m0.rgb, vec3(0.299, 0.587, 0.114)) : m0.a;
        if (fe + abs(ex) > 0.5) {
            float rr = max(fe + abs(ex), 1.0);
            float macc = lm;
            float mw = 1.0;
            for (int ki = 0; ki < 32; ki++) {
                float fk = float(ki) + 0.5;
                float rad = sqrt(fk / 32.0);
                float an = fk * 2.3999632 + jit * 6.2831853;
                vec4 m1 = in0(uv + vec2(cos(an), sin(an)) * rad * rr * px);
                macc += shLMSrc > 0.5 ? dot(m1.rgb, vec3(0.299, 0.587, 0.114)) : m1.a;
                mw += 1.0;
            }
            float bl = macc / mw;
            float dsd = (bl - 0.5) * 2.0 * rr;
            lm = clamp(0.5 + (dsd + ex) / max(fe, 1.0), 0.0, 1.0);
            lm = lm * lm * (3.0 - 2.0 * lm);
        }
        if (shLMInv > 0.5) { lm = 1.0 - lm; }
        mk *= mix(1.0, lm, shLMOp * 0.01);
    }
    rays *= shOp * 0.01 * mk * shVis;
    vec3 base = s0.rgb * (shSrcOp * 0.01);
    float aS = a0 * (shSrcOp * 0.01);
    vec3 rc = clamp(rays, vec3(0.0), vec3(1.0));
    float k = clamp(dot(rc, vec3(0.299, 0.587, 0.114)) * 1.6, 0.0, 1.0);
    vec3 o = base;
    if (shBlend < 0.5) { o = rays; }
    else if (shBlend < 1.5) { o = base * (1.0 - k) + rays; }
    else if (shBlend < 2.5) { o = base + rays; }
    else if (shBlend < 3.5) { o = base + rc - base * rc; }
    else if (shBlend < 4.5) {
        vec3 bs = base / max(aS, 0.0001);
        vec3 ov = vec3(bs.r < 0.5 ? 2.0 * bs.r * rc.r : 1.0 - 2.0 * (1.0 - bs.r) * (1.0 - rc.r),
                       bs.g < 0.5 ? 2.0 * bs.g * rc.g : 1.0 - 2.0 * (1.0 - bs.g) * (1.0 - rc.g),
                       bs.b < 0.5 ? 2.0 * bs.b * rc.b : 1.0 - 2.0 * (1.0 - bs.b) * (1.0 - rc.b));
        o = mix(base, ov * aS, k) + rays * 0.35;
    } else { o = base * (1.0 + rays * 2.0); }
    float oa = clamp(aS + (1.0 - aS) * dot(rc, vec3(0.299, 0.587, 0.114)) * 1.6, 0.0, 1.0);
    return vec4(max(o, vec3(0.0)), oa);
""")]
}
