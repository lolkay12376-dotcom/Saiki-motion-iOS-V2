// Folders.swift — project folders for My Playground (stored beside the projects, never inside them).

import Foundation

struct ProjectFolder { var id: String; var name: String }

enum Folders {
    private static var fileURL: URL { Paths.root.appendingPathComponent("folders.json") }
    private static var cache: (folders: [ProjectFolder], assign: [String: String])? = nil

    private static func load() -> (folders: [ProjectFolder], assign: [String: String]) {
        if let c = cache { return c }
        var out: (folders: [ProjectFolder], assign: [String: String]) = ([], [:])
        if let d = try? Data(contentsOf: fileURL),
           let o = try? JSONSerialization.jsonObject(with: d) as? [String: Any] {
            for f in (o["folders"] as? [[String: String]]) ?? [] {
                if let id = f["id"], let nm = f["name"] { out.folders.append(ProjectFolder(id: id, name: nm)) }
            }
            out.assign = (o["assign"] as? [String: String]) ?? [:]
        }
        cache = out
        return out
    }

    private static func save(_ v: (folders: [ProjectFolder], assign: [String: String])) {
        cache = v
        let o: [String: Any] = ["folders": v.folders.map { ["id": $0.id, "name": $0.name] }, "assign": v.assign]
        if let d = try? JSONSerialization.data(withJSONObject: o) { try? d.write(to: fileURL, options: .atomic) }
    }

    static var all: [ProjectFolder] { load().folders }
    static func folder(of projectId: String) -> String? { load().assign[projectId] }
    static func name(_ id: String) -> String { load().folders.first { $0.id == id }?.name ?? "Folder" }
    static func count(_ id: String) -> Int { load().assign.values.filter { $0 == id }.count }

    @discardableResult
    static func create(_ name: String) -> ProjectFolder {
        var v = load()
        let f = ProjectFolder(id: UUID().uuidString, name: name)
        v.folders.append(f)
        save(v)
        return f
    }

    static func rename(_ id: String, _ name: String) {
        var v = load()
        if let i = v.folders.firstIndex(where: { $0.id == id }) { v.folders[i].name = name }
        save(v)
    }

    /// Deleting a folder never deletes projects — they go back to the main list.
    static func delete(_ id: String) {
        var v = load()
        v.folders.removeAll { $0.id == id }
        v.assign = v.assign.filter { $0.value != id }
        save(v)
    }

    static func move(_ projectId: String, to folderId: String?) {
        var v = load()
        if let f = folderId { v.assign[projectId] = f } else { v.assign.removeValue(forKey: projectId) }
        save(v)
    }
}
