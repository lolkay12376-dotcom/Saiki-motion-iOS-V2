// Skeleton3D.swift — bones for a 3D model layer (glTF / VRM joints, PMX / FBX bones).
// Pose = per-bone rotation + offset on top of the rest pose; skin matrix = pose world · inverse(bind world).
// Physics (VRM spring bones, PMX rigid bodies) lives in Physics3D.swift and runs on top of the pose.

import Foundation
import simd

final class Bone3D {
    var name: String
    var parent: Int
    var bindWorld: simd_float4x4
    var restLocal: simd_float4x4
    var rot = simd_quatf(ix: 0, iy: 0, iz: 0, r: 1)
    var off = SIMD3<Float>(0, 0, 0)
    var physics = false          // driven by VRM spring bone / PMX rigid body
    init(name: String, parent: Int, bindWorld: simd_float4x4, restLocal: simd_float4x4) {
        self.name = name; self.parent = parent; self.bindWorld = bindWorld; self.restLocal = restLocal
    }
}

final class Skeleton3D {
    var bones: [Bone3D] = []
    var phys: Physics3D? = nil
    var physicsOn = true
    /// Bumped every time the simulated pose changed (the viewport redraws the bone overlay on it).
    private(set) var simTick = 0
    private var simW: [simd_float4x4]? = nil
    private var topoCache: [Int] = []
    private var bindInv: [simd_float4x4] = []
    private var sig = ""
    var poseSig: String { sig }

    /// Parents before children.
    func order() -> [Int] {
        if topoCache.count == bones.count { return topoCache }
        var seen = [Bool](repeating: false, count: bones.count)
        var out: [Int] = []; out.reserveCapacity(bones.count)
        for i in 0..<bones.count {
            var chain: [Int] = []
            var c = i, g = 0
            while c >= 0, c < bones.count, !seen[c], g < 4096 { chain.append(c); seen[c] = true; c = bones[c].parent; g += 1 }
            out.append(contentsOf: chain.reversed())
        }
        topoCache = out
        return out
    }

    /// Local matrix of a bone with its pose applied.
    static func local(_ b: Bone3D) -> simd_float4x4 {
        var d = simd_float4x4(b.rot)
        d.columns.3 = SIMD4<Float>(b.off.x, b.off.y, b.off.z, 1)
        return b.restLocal * d
    }

    /// World matrices of the posed skeleton without physics (model space).
    func poseWorld() -> [simd_float4x4] {
        var w = [simd_float4x4](repeating: matrix_identity_float4x4, count: bones.count)
        for i in order() {
            let b = bones[i], l = Skeleton3D.local(b)
            w[i] = (b.parent >= 0 && b.parent < bones.count && b.parent != i) ? w[b.parent] * l : l
        }
        return w
    }

    /// World matrices as drawn: pose + physics when the simulation is on.
    func world() -> [simd_float4x4] {
        if physicsOn, let s = simW, s.count == bones.count { return s }
        return poseWorld()
    }

    func skinMatrices() -> [simd_float4x4] {
        if bindInv.count != bones.count { bindInv = bones.map { $0.bindWorld.inverse } }
        let w = world()
        return (0..<bones.count).map { w[$0] * bindInv[$0] }
    }

    func resetPose() { for b in bones { b.rot = simd_quatf(ix: 0, iy: 0, iz: 0, r: 1); b.off = .zero } }

    /// Euler degrees (XYZ) → quaternion.
    static func quat(_ rx: Float, _ ry: Float, _ rz: Float) -> simd_quatf {
        let d = Float.pi / 180
        return simd_quatf(angle: rz * d, axis: SIMD3<Float>(0, 0, 1)) * simd_quatf(angle: ry * d, axis: SIMD3<Float>(0, 1, 0)) * simd_quatf(angle: rx * d, axis: SIMD3<Float>(1, 0, 0))
    }

    // MARK: layer tracks ("bn<i>rx/ry/rz/px/py/pz")

    /// (bone, channel 0...5) of a bone track key, nil for any other key.
    static func boneKey(_ k: String) -> (Int, Int)? {
        guard k.count > 4, k.hasPrefix("bn") else { return nil }
        let ax: Int
        switch String(k.suffix(2)) {
        case "rx": ax = 0
        case "ry": ax = 1
        case "rz": ax = 2
        case "px": ax = 3
        case "py": ax = 4
        case "pz": ax = 5
        default: return nil
        }
        guard let i = Int(k.dropFirst(2).dropLast(2)), i >= 0 else { return nil }
        return (i, ax)
    }

    /// Reads the layer's bone tracks at `t` into the pose. True when the pose changed.
    @discardableResult
    func loadPose(_ l: Layer, _ t: Float) -> Bool {
        var vals: [Int: [Float]] = [:]
        for key in l.props.keys {
            guard let k = Skeleton3D.boneKey(key), k.0 < bones.count else { continue }
            var v = vals[k.0] ?? [Float](repeating: 0, count: 6)
            let x = l.p(key, t)
            v[k.1] = x.isFinite ? x : 0
            vals[k.0] = v
        }
        var parts: [String] = []
        for i in vals.keys.sorted() { parts.append("\(i):" + (vals[i] ?? []).map { String(format: "%.5f", $0) }.joined(separator: ",")) }
        let s = parts.joined(separator: ";")
        if s == sig { return false }
        sig = s
        resetPose()
        for (i, v) in vals { bones[i].rot = Skeleton3D.quat(v[0], v[1], v[2]); bones[i].off = SIMD3<Float>(v[3], v[4], v[5]) }
        return true
    }

    /// Removes every bone track of the layer (Reset pose) and clears the pose.
    func clearTracks(_ l: Layer) {
        for k in Array(l.props.keys) where Skeleton3D.boneKey(k) != nil { l.props.removeValue(forKey: k) }
        resetPose(); sig = "\u{0}"          // differs from any pose signature, so the next loadPose re-skins
    }

    // MARK: physics

    /// Advances the simulation to timeline time `t` (`wall` = real seconds since the last call, used while the timeline is paused).
    /// True when any bone moved.
    @discardableResult
    func stepPhysics(t: Float, wall: Float) -> Bool {
        guard physicsOn, let ph = phys, ph.active else {
            if simW != nil { simW = nil; simTick &+= 1; return true }
            return false
        }
        let new = ph.solve(self, t: t, wall: wall)
        var moved = true
        if let old = simW, old.count == new.count {
            moved = false
            for i in 0..<new.count where Skeleton3D.differs(old[i], new[i]) { moved = true; break }
        }
        simW = new
        if moved { simTick &+= 1 }
        return moved
    }

    /// Drops the simulation state (the next step starts from the pose).
    func resetPhysics() { simW = nil; phys?.lastT = nil }

    private static func differs(_ a: simd_float4x4, _ b: simd_float4x4) -> Bool {
        for c in 0..<4 {
            let d = a[c] - b[c], r = b[c]
            if abs(d.x) > 1e-5 * (1 + abs(r.x)) || abs(d.y) > 1e-5 * (1 + abs(r.y)) || abs(d.z) > 1e-5 * (1 + abs(r.z)) { return true }
        }
        return false
    }

    // MARK: skinning

    /// Skins interleaved vertices (12 floats each: pos, normal, uv, ...) with the given skin matrices.
    static func skinVerts(base: [Float], jnt: [UInt16], wgt: [Float], mats: [simd_float4x4]) -> [Float] {
        var v = base
        let n = v.count / 12
        guard jnt.count >= n * 4, wgt.count >= n * 4 else { return v }
        for i in 0..<n {
            let o = SIMD4<Float>(v[i * 12], v[i * 12 + 1], v[i * 12 + 2], 1)
            let on = SIMD4<Float>(v[i * 12 + 3], v[i * 12 + 4], v[i * 12 + 5], 0)
            var p = SIMD4<Float>(0, 0, 0, 0), nn = SIMD4<Float>(0, 0, 0, 0), ws: Float = 0
            for k in 0..<4 {
                let w = wgt[i * 4 + k]; if w <= 0 { continue }
                let bi = Int(jnt[i * 4 + k]); if bi >= mats.count { continue }
                p += (mats[bi] * o) * w; nn += (mats[bi] * on) * w; ws += w
            }
            if ws < 0.999 { p += o * (1 - ws); nn += on * (1 - ws) }
            v[i * 12] = p.x; v[i * 12 + 1] = p.y; v[i * 12 + 2] = p.z
            let l = max(simd_length(SIMD3<Float>(nn.x, nn.y, nn.z)), 1e-6)
            v[i * 12 + 3] = nn.x / l; v[i * 12 + 4] = nn.y / l; v[i * 12 + 5] = nn.z / l
        }
        return v
    }

    // MARK: sidecar ("<model>.glb.skel") written by the PMX / FBX importers
    // v1 "SKL1": bones + skin weights.  v2 "SKL2": v1 + PMX rigid bodies and joints (physics). Both are read.
    static let magic1: UInt32 = 0x314C4B53, magic2: UInt32 = 0x324C4B53

    /// 1 / 2 for a readable sidecar, 0 when missing.
    static func sidecarVersion(_ path: String) -> Int {
        guard let h = FileHandle(forReadingAtPath: path) else { return 0 }
        defer { try? h.close() }
        let d = h.readData(ofLength: 4)
        guard d.count == 4 else { return 0 }
        let m = UInt32(d[d.startIndex]) | UInt32(d[d.startIndex + 1]) << 8 | UInt32(d[d.startIndex + 2]) << 16 | UInt32(d[d.startIndex + 3]) << 24
        return m == magic2 ? 2 : (m == magic1 ? 1 : 0)
    }

    static func write(_ sk: Skeleton3D, joints: [[UInt16]], weights: [[Float]], to path: String) {
        var d = Data()
        func u32(_ v: UInt32) { var x = v.littleEndian; withUnsafeBytes(of: &x) { d.append(contentsOf: $0) } }
        func i32(_ v: Int) { u32(UInt32(bitPattern: Int32(truncatingIfNeeded: v))) }
        func f32(_ v: Float) { u32(v.bitPattern) }
        func v3(_ v: SIMD3<Float>) { f32(v.x); f32(v.y); f32(v.z) }
        u32(magic2); u32(UInt32(sk.bones.count))
        for b in sk.bones {
            let nm = Array(b.name.utf8.prefix(200)); u32(UInt32(nm.count)); d.append(contentsOf: nm)
            u32(UInt32(bitPattern: Int32(b.parent)))
            for c in 0..<4 { let col = b.bindWorld[c]; for r in 0..<4 { f32(col[r]) } }
            for c in 0..<4 { let col = b.restLocal[c]; for r in 0..<4 { f32(col[r]) } }
            u32(b.physics ? 1 : 0)
        }
        u32(UInt32(joints.count))
        for (j, w) in zip(joints, weights) {
            u32(UInt32(j.count / 4))
            for x in j { var v = x.littleEndian; withUnsafeBytes(of: &v) { d.append(contentsOf: $0) } }
            for x in w { f32(x) }
        }
        // physics trailer
        let bodies = sk.phys?.bodies ?? [], pj = sk.phys?.joints ?? []
        u32(UInt32(bodies.count))
        for b in bodies {
            i32(b.bone); u32(UInt32(max(b.group, 0))); u32(UInt32(max(b.mask, 0))); u32(UInt32(max(b.shape, 0)))
            v3(b.size); v3(b.pos); f32(b.rot.imag.x); f32(b.rot.imag.y); f32(b.rot.imag.z); f32(b.rot.real)
            f32(b.mass); f32(b.linDamp); f32(b.angDamp); f32(b.repulsion); f32(b.friction); u32(UInt32(max(b.mode, 0)))
        }
        u32(UInt32(pj.count))
        for j in pj {
            i32(j.a); i32(j.b); v3(j.pos); v3(j.moveLo); v3(j.moveHi); v3(j.rotLo); v3(j.rotHi); v3(j.springMove); v3(j.springRot)
        }
        try? d.write(to: URL(fileURLWithPath: path))
    }

    static func read(_ path: String) -> (Skeleton3D, [[UInt16]], [[Float]])? {
        guard let data = FileManager.default.contents(atPath: path), data.count > 8 else { return nil }
        let b = [UInt8](data); var o = 0
        func u32() -> UInt32 { guard o + 4 <= b.count else { o = b.count + 1; return 0 }; let v = UInt32(b[o]) | UInt32(b[o + 1]) << 8 | UInt32(b[o + 2]) << 16 | UInt32(b[o + 3]) << 24; o += 4; return v }
        func i32() -> Int { Int(Int32(bitPattern: u32())) }
        func f32() -> Float { Float(bitPattern: u32()) }
        func v3() -> SIMD3<Float> { let x = f32(), y = f32(), z = f32(); return SIMD3<Float>(x, y, z) }
        func mat() -> simd_float4x4 {
            var m = matrix_identity_float4x4
            for c in 0..<4 { m[c] = SIMD4<Float>(f32(), f32(), f32(), f32()) }
            return m
        }
        let mg = u32()
        guard mg == magic1 || mg == magic2 else { return nil }
        let nb = Int(u32()); guard nb > 0, nb < 100_000 else { return nil }
        let sk = Skeleton3D()
        for _ in 0..<nb {
            let nl = Int(u32()); guard nl < 400, o + nl <= b.count else { return nil }
            let name = String(decoding: b[o..<(o + nl)], as: UTF8.self); o += nl
            let parent = Int(Int32(bitPattern: u32()))
            let bind = mat(), rest = mat()
            let bn = Bone3D(name: name, parent: parent, bindWorld: bind, restLocal: rest)
            bn.physics = u32() != 0
            sk.bones.append(bn)
        }
        let np = Int(u32()); guard np < 10_000 else { return nil }
        var J = [[UInt16]](), W = [[Float]]()
        for _ in 0..<np {
            let n = Int(u32()); guard n >= 0, o + n * 24 <= b.count else { return nil }
            var j = [UInt16](repeating: 0, count: n * 4), w = [Float](repeating: 0, count: n * 4)
            for i in 0..<(n * 4) { j[i] = UInt16(b[o]) | UInt16(b[o + 1]) << 8; o += 2 }
            for i in 0..<(n * 4) { w[i] = f32() }
            J.append(j); W.append(w)
        }
        if mg == magic2, o + 8 <= b.count {
            let ph = Physics3D()
            let nbod = Int(u32())
            if nbod >= 0, nbod < 100_000, o + nbod * 80 <= b.count {
                for _ in 0..<nbod {
                    let bone = i32(), grp = Int(u32()), mask = Int(u32()), shape = Int(u32())
                    let size = v3(), pos = v3()
                    let qx = f32(), qy = f32(), qz = f32(), qw = f32()
                    let mass = f32(), ld = f32(), ad = f32(), rep = f32(), fr = f32()
                    let mode = Int(u32())
                    ph.bodies.append(PmxBody(bone: bone, group: grp, mask: mask, shape: shape, size: size, pos: pos,
                                             rot: simd_quatf(ix: qx, iy: qy, iz: qz, r: qw), mass: mass, linDamp: ld, angDamp: ad,
                                             repulsion: rep, friction: fr, mode: mode))
                }
                let nj = Int(u32())
                if nj >= 0, nj < 200_000, o + nj * 92 <= b.count {
                    for _ in 0..<nj {
                        let a = i32(), c = i32()
                        let pos = v3(), ml = v3(), mh = v3(), rl = v3(), rh = v3(), sm = v3(), sr = v3()
                        ph.joints.append(PmxJoint(a: a, b: c, pos: pos, moveLo: ml, moveHi: mh, rotLo: rl, rotHi: rh, springMove: sm, springRot: sr))
                    }
                }
                if ph.active {
                    for bd in ph.bodies where bd.mode != 0 && bd.bone >= 0 && bd.bone < sk.bones.count { sk.bones[bd.bone].physics = true }
                    sk.phys = ph
                }
            }
        }
        return (sk, J, W)
    }
}
