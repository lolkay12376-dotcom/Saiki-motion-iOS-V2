//
//  FbxImport.swift — binary .fbx -> .glb converter. The GLB then goes through the normal GlbModel / Metal PBR path.
//  Reads: meshes (any polygon -> triangulated), normals, UVs, per-polygon materials, node hierarchy (T/R/S, pre-rotation,
//  up-axis baked), PBR + classic materials (base colour, metal, rough, emissive, AO, opacity), embedded or neighbouring
//  textures (separate rough / metal maps are packed into one glTF metal-rough image).
//
import UIKit
import simd

enum FbxImport {
    static var lastError = ""

    enum PV { case i(Int64), d(Double), s(String), raw([UInt8]), ad([Double]), ai([Int64]) }
    final class N {
        var name = ""; var p: [PV] = []; var c: [N] = []
        func child(_ n: String) -> N? { c.first { $0.name == n } }
        func kids(_ n: String) -> [N] { c.filter { $0.name == n } }
        var id: Int64 { if case .i(let v)? = p.first { return v }; return 0 }
        var str: String { for q in p { if case .s(let s) = q { return s } }; return "" }
        var doubles: [Double] {
            for q in p { if case .ad(let a) = q { return a }; if case .ai(let a) = q { return a.map(Double.init) } }
            return []
        }
        var ints: [Int64] {
            for q in p { if case .ai(let a) = q { return a }; if case .ad(let a) = q { return a.map { Int64($0) } } }
            return []
        }
        func num(_ i: Int) -> Double {
            guard i < p.count else { return 0 }
            switch p[i] { case .i(let v): return Double(v); case .d(let v): return v; default: return 0 }
        }
    }

    // MARK: parse
    static func parse(_ b: [UInt8]) -> [N]? {
        guard b.count > 27, String(decoding: b[0..<20], as: UTF8.self) == "Kaydara FBX Binary" else { return nil }
        let ver = Int(b[23]) | Int(b[24]) << 8 | Int(b[25]) << 16 | Int(b[26]) << 24
        let wide = ver >= 7500
        var pos = 27
        func u32(_ o: Int) -> Int { o + 4 <= b.count ? Int(b[o]) | Int(b[o + 1]) << 8 | Int(b[o + 2]) << 16 | Int(b[o + 3]) << 24 : 0 }
        func u64(_ o: Int) -> Int { u32(o) | (u32(o + 4) << 32) }
        func f64(_ o: Int) -> Double { b.withUnsafeBytes { $0.loadUnaligned(fromByteOffset: o, as: Double.self) } }
        func f32(_ o: Int) -> Float { b.withUnsafeBytes { $0.loadUnaligned(fromByteOffset: o, as: Float.self) } }
        func i64(_ o: Int) -> Int64 { b.withUnsafeBytes { $0.loadUnaligned(fromByteOffset: o, as: Int64.self) } }

        func readNode() -> N? {
            let hdr = wide ? 25 : 13
            guard pos + hdr <= b.count else { return nil }
            let end = wide ? u64(pos) : u32(pos)
            let np = wide ? u64(pos + 8) : u32(pos + 4)
            let nameLen = Int(b[pos + (wide ? 24 : 12)])
            if end == 0 { pos += hdr; return nil }
            pos += hdr
            guard pos + nameLen <= b.count, end <= b.count else { return nil }
            let n = N()
            n.name = String(decoding: b[pos..<(pos + nameLen)], as: UTF8.self)
            pos += nameLen
            for _ in 0..<np {
                guard pos < b.count else { break }
                let t = b[pos]; pos += 1
                switch t {
                case 0x59: n.p.append(.i(Int64(Int16(bitPattern: UInt16(b[pos]) | UInt16(b[pos + 1]) << 8))));  pos += 2
                case 0x43: n.p.append(.i(Int64(b[pos]))); pos += 1
                case 0x49: n.p.append(.i(Int64(Int32(truncatingIfNeeded: u32(pos))))); pos += 4
                case 0x46: n.p.append(.d(Double(f32(pos)))); pos += 4
                case 0x44: n.p.append(.d(f64(pos))); pos += 8
                case 0x4C: n.p.append(.i(i64(pos))); pos += 8
                case 0x53, 0x52:
                    let l = u32(pos); pos += 4
                    let seg = Array(b[pos..<min(b.count, pos + l)]); pos += l
                    if t == 0x53 {
                        var s = String(decoding: seg, as: UTF8.self)
                        if let r = s.range(of: "\u{0}\u{1}") { s = String(s[..<r.lowerBound]) }
                        n.p.append(.s(s))
                    } else { n.p.append(.raw(seg)) }
                case 0x66, 0x64, 0x6C, 0x69, 0x62:
                    let cnt = u32(pos), enc = u32(pos + 4), clen = u32(pos + 8); pos += 12
                    let es = (t == 0x66 || t == 0x69) ? 4 : (t == 0x62 ? 1 : 8)
                    var raw = Array(b[pos..<min(b.count, pos + clen)]); pos += clen
                    if enc == 1 { raw = VdbVolume.inflateZlib(raw) }
                    guard raw.count >= cnt * es else { n.p.append(.ad([])); break }
                    raw.withUnsafeBytes { r in
                        switch t {
                        case 0x66: n.p.append(.ad((0..<cnt).map { Double(r.loadUnaligned(fromByteOffset: $0 * 4, as: Float.self)) }))
                        case 0x64: n.p.append(.ad((0..<cnt).map { r.loadUnaligned(fromByteOffset: $0 * 8, as: Double.self) }))
                        case 0x6C: n.p.append(.ai((0..<cnt).map { r.loadUnaligned(fromByteOffset: $0 * 8, as: Int64.self) }))
                        case 0x69: n.p.append(.ai((0..<cnt).map { Int64(r.loadUnaligned(fromByteOffset: $0 * 4, as: Int32.self)) }))
                        default: n.p.append(.ai((0..<cnt).map { Int64(r[$0]) }))
                        }
                    }
                default: return n
                }
            }
            while pos < end {
                guard let c = readNode() else { if pos < end && pos + hdr <= b.count && (wide ? u64(pos) : u32(pos)) == 0 { pos += hdr }; break }
                n.c.append(c)
            }
            pos = end
            return n
        }
        var out: [N] = []
        while pos + 13 < b.count, let n = readNode() { out.append(n) }
        return out
    }

    // MARK: ASCII FBX
    static func parseAscii(_ b: [UInt8]) -> [N] {
        var i = 0
        let n = b.count
        func ws(_ lines: Bool = true) {
            while i < n {
                let c = b[i]
                if c == 32 || c == 9 || c == 13 || (lines && c == 10) { i += 1 }
                else if c == 59 && lines { while i < n && b[i] != 10 { i += 1 } }      // ; comment
                else { break }
            }
        }
        func number(_ tok: String) -> PV? {
            if let v = Int64(tok) { return .i(v) }
            if let d = Double(tok) { return .d(d) }
            return nil
        }
        func nodes() -> [N] {
            var out: [N] = []
            while true {
                ws()
                if i >= n { return out }
                if b[i] == 125 { i += 1; return out }          // }
                var s0 = i
                while i < n && b[i] != 58 && b[i] != 10 && b[i] != 123 { i += 1 }       // name up to ':'
                guard i < n, b[i] == 58 else { i += 1; continue }
                let node = N(); node.name = String(decoding: b[s0..<i], as: UTF8.self).trimmingCharacters(in: .whitespaces)
                i += 1
                var hasBlock = false
                while true {
                    ws(false)
                    if i >= n { break }
                    let c = b[i]
                    if c == 10 { break }
                    if c == 44 { i += 1; continue }
                    if c == 123 {
                        i += 1; hasBlock = true; break
                    }
                    if c == 42 {                                  // *N { a: ... }
                        i += 1; while i < n && b[i] >= 48 && b[i] <= 57 { i += 1 }
                        ws()
                        guard i < n, b[i] == 123 else { continue }
                        i += 1; ws()
                        if i + 1 < n, b[i] == 97, b[i + 1] == 58 { i += 2 }          // a:
                        var vals: [Double] = []
                        while i < n && b[i] != 125 {
                            ws()
                            s0 = i
                            while i < n && b[i] != 44 && b[i] != 125 && b[i] != 32 && b[i] != 10 && b[i] != 13 && b[i] != 9 { i += 1 }
                            if i > s0, let d = Double(String(decoding: b[s0..<i], as: UTF8.self)) { vals.append(d) }
                            ws(); if i < n && b[i] == 44 { i += 1 }
                        }
                        if i < n { i += 1 }
                        node.p.append(.ad(vals)); continue
                    }
                    if c == 34 {                                   // "string"
                        i += 1; s0 = i
                        while i < n && b[i] != 34 { i += 1 }
                        var str = String(decoding: b[s0..<min(i, n)], as: UTF8.self)
                        if i < n { i += 1 }
                        if node.name == "Content", let d = Data(base64Encoded: str, options: .ignoreUnknownCharacters) { node.p.append(.raw([UInt8](d))); continue }
                        if let r = str.range(of: "::"), node.p.count == 1 { str = String(str[r.upperBound...]) }       // "Model::Cube" -> "Cube"
                        node.p.append(.s(str)); continue
                    }
                    s0 = i
                    while i < n && b[i] != 44 && b[i] != 10 && b[i] != 13 && b[i] != 123 && b[i] != 32 { i += 1 }
                    let tok = String(decoding: b[s0..<i], as: UTF8.self)
                    if i == s0 { i += 1; continue }
                    node.p.append(number(tok) ?? .s(tok))
                }
                if hasBlock { node.c = nodes() }
                out.append(node)
            }
        }
        return nodes()
    }

    // MARK: helpers
    static func props(_ n: N?) -> [String: [PV]] {
        var d: [String: [PV]] = [:]
        for p in n?.child("Properties70")?.kids("P") ?? [] {
            if case .s(let k)? = p.p.first { d[k] = Array(p.p.dropFirst(4)) }
        }
        return d
    }
    static func vec(_ pr: [String: [PV]], _ k: String, _ def: [Double]) -> [Double] {
        guard let v = pr[k] else { return def }
        var o: [Double] = []
        for x in v { if case .d(let d) = x { o.append(d) } else if case .i(let i) = x { o.append(Double(i)) } }
        return o.count >= def.count ? o : def
    }
    static func rotM(_ d: [Double]) -> simd_float4x4 {
        func rx(_ a: Float) -> simd_float4x4 { let c = cos(a), s = sin(a); return simd_float4x4(columns: ([1, 0, 0, 0], [0, c, s, 0], [0, -s, c, 0], [0, 0, 0, 1])) }
        func ry(_ a: Float) -> simd_float4x4 { let c = cos(a), s = sin(a); return simd_float4x4(columns: ([c, 0, -s, 0], [0, 1, 0, 0], [s, 0, c, 0], [0, 0, 0, 1])) }
        func rz(_ a: Float) -> simd_float4x4 { let c = cos(a), s = sin(a); return simd_float4x4(columns: ([c, s, 0, 0], [-s, c, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1])) }
        let k = Float.pi / 180
        return rz(Float(d[2]) * k) * ry(Float(d[1]) * k) * rx(Float(d[0]) * k)
    }

    final class Mat {
        var base: [Float] = [0.8, 0.8, 0.8], alpha: Float = 1, metal: Float = 0, rough: Float = 0.8, emis: [Float] = [0, 0, 0]
        var tex: [String: Int64] = [:]     // slot -> texture object id
    }

    // MARK: convert
    /// Returns the .glb written beside the .fbx (cached by modification date), or nil with lastError set.
    static func convert(_ path: String) -> String? {
        lastError = ""
        let stem = ((path as NSString).deletingPathExtension)
        let out = stem + "_fbx.glb"
        let fm = FileManager.default
        if let a = (try? fm.attributesOfItem(atPath: path))?[.modificationDate] as? Date,
           let o = (try? fm.attributesOfItem(atPath: out))?[.modificationDate] as? Date, o > a,
           fm.fileExists(atPath: out + ".skel") || fm.fileExists(atPath: out + ".noskel") { return out }
        guard let data = fm.contents(atPath: path) else { lastError = "Cannot read the FBX file"; return nil }
        let bytes = [UInt8](data)
        let isBin = bytes.count > 20 && String(decoding: bytes[0..<18], as: UTF8.self) == "Kaydara FBX Binary"
        let rootsOpt: [N]? = isBin ? parse(bytes) : parseAscii(bytes)
        guard let roots = rootsOpt, roots.contains(where: { $0.name == "Objects" }) else { lastError = "Not a readable FBX file"; return nil }
        try? fm.removeItem(atPath: out + ".anim")
        guard let objects = roots.first(where: { $0.name == "Objects" }) else { lastError = "FBX has no objects"; return nil }
        let dir = (path as NSString).deletingLastPathComponent
        let stemName = (stem as NSString).lastPathComponent

        var geoms: [Int64: N] = [:], models: [Int64: N] = [:], mats: [Int64: N] = [:], texs: [Int64: N] = [:], vids: [Int64: N] = [:]
        var cnodes: [Int64: N] = [:], curvesRaw: [Int64: N] = [:], deformers: [Int64: N] = [:]
        for o in objects.c {
            switch o.name {
            case "Geometry": if o.p.count > 2, case .s(let s) = o.p[2], s == "Mesh" { geoms[o.id] = o }
            case "Model": models[o.id] = o
            case "Material": mats[o.id] = o
            case "Texture": texs[o.id] = o
            case "Video": vids[o.id] = o
            case "AnimationCurveNode": cnodes[o.id] = o
            case "AnimationCurve": curvesRaw[o.id] = o
            case "Deformer": deformers[o.id] = o
            default: break
            }
        }
        // connections
        var parentOf: [Int64: Int64] = [:]
        var modelGeom: [Int64: Int64] = [:], modelMats: [Int64: [Int64]] = [:]
        var matTex: [Int64: [(String, Int64)]] = [:], texVid: [Int64: Int64] = [:]
        var geomSkin: [Int64: Int64] = [:], skinClusters: [Int64: [Int64]] = [:], clusterBone: [Int64: Int64] = [:]
        var cnModel: [Int64: (Int64, String)] = [:], cnCurves: [Int64: [(String, Int64)]] = [:]
        for c in roots.first(where: { $0.name == "Connections" })?.c ?? [] where c.name == "C" {
            guard case .s(let kind)? = c.p.first, c.p.count >= 3 else { continue }
            let ch = Int64(c.num(1)), pa = Int64(c.num(2))
            var prop = ""
            if c.p.count > 3, case .s(let s) = c.p[3] { prop = s }
            if kind == "OO" {
                if models[ch] != nil && (models[pa] != nil || pa == 0) { parentOf[ch] = pa }
                else if geoms[ch] != nil && models[pa] != nil { modelGeom[pa] = ch }
                else if mats[ch] != nil && models[pa] != nil { modelMats[pa, default: []].append(ch) }
                else if vids[ch] != nil && texs[pa] != nil { texVid[pa] = ch }
                else if deformers[ch] != nil && geoms[pa] != nil { geomSkin[pa] = ch }
                else if deformers[ch] != nil && deformers[pa] != nil { skinClusters[pa, default: []].append(ch) }
                else if models[ch] != nil && deformers[pa] != nil { clusterBone[pa] = ch }
            } else if kind == "OP" {
                if texs[ch] != nil, mats[pa] != nil { matTex[pa, default: []].append((prop, ch)) }
                else if curvesRaw[ch] != nil, cnodes[pa] != nil { cnCurves[pa, default: []].append((prop, ch)) }
                else if cnodes[ch] != nil, models[pa] != nil { cnModel[ch] = (pa, prop) }
            }
        }
        // global settings: up axis
        let gs = props(roots.first(where: { $0.name == "GlobalSettings" }))
        let upAxis = Int(vec(gs, "UpAxis", [1])[0])
        let fix: simd_float4x4 = upAxis == 2
            ? simd_float4x4(columns: ([1, 0, 0, 0], [0, 0, -1, 0], [0, 1, 0, 0], [0, 0, 0, 1])) : matrix_identity_float4x4

        // animation curves (Lcl Translation / Rotation / Scaling), times in seconds
        struct Curve { var t: [Double] = []; var v: [Double] = [] }
        var anim: [Int64: [String: [Curve?]]] = [:]
        var tMin = Double.infinity, tMax = 0.0
        for (cn, mp) in cnModel {
            var arr: [Curve?] = [nil, nil, nil]
            for (prop, cid) in cnCurves[cn] ?? [] {
                guard let k = ["d|X": 0, "d|Y": 1, "d|Z": 2][prop], let c = curvesRaw[cid] else { continue }
                let times = (c.child("KeyTime")?.ints ?? []).map { Double($0) / 46186158000.0 }, vals = c.child("KeyValueFloat")?.doubles ?? []
                let cnt = min(times.count, vals.count); if cnt == 0 { continue }
                arr[k] = Curve(t: Array(times[0..<cnt]), v: Array(vals[0..<cnt]))
                tMin = min(tMin, times[0]); tMax = max(tMax, times[cnt - 1])
            }
            anim[mp.0, default: [:]][mp.1] = arr
        }
        let animated = !anim.isEmpty && tMax > tMin + 1e-6
        func sample(_ c: Curve, _ t: Double) -> Double {
            if t <= c.t[0] { return c.v[0] }
            if t >= c.t[c.t.count - 1] { return c.v[c.v.count - 1] }
            var lo = 0, hi = c.t.count - 1
            while hi - lo > 1 { let m = (lo + hi) / 2; if c.t[m] <= t { lo = m } else { hi = m } }
            let f = (t - c.t[lo]) / max(c.t[hi] - c.t[lo], 1e-12)
            return c.v[lo] + (c.v[hi] - c.v[lo]) * f
        }
        var modelProps: [Int64: [String: [PV]]] = [:]
        for (id, m) in models { modelProps[id] = props(m) }
        /// World matrices at time t (seconds; nil = static values). Roots get the up-axis fix.
        func makeWorld(_ t: Double?) -> (Int64) -> simd_float4x4 {
            var cache: [Int64: simd_float4x4] = [:]
            func trs(_ id: Int64, _ key: String, _ base: [Double]) -> [Double] {
                guard let t = t, let arr = anim[id]?[key] else { return base }
                var o = base
                for i in 0..<3 { if let c = arr[i] { o[i] = sample(c, t) } }
                return o
            }
            func w(_ id: Int64, _ depth: Int) -> simd_float4x4 {
                if let c = cache[id] { return c }
                guard let pr = modelProps[id], depth < 64 else { return matrix_identity_float4x4 }
                let tt = trs(id, "Lcl Translation", vec(pr, "Lcl Translation", [0, 0, 0]))
                let r = trs(id, "Lcl Rotation", vec(pr, "Lcl Rotation", [0, 0, 0]))
                let s = trs(id, "Lcl Scaling", vec(pr, "Lcl Scaling", [1, 1, 1]))
                let pre = vec(pr, "PreRotation", [0, 0, 0])
                var T = matrix_identity_float4x4; T.columns.3 = [Float(tt[0]), Float(tt[1]), Float(tt[2]), 1]
                let S = simd_float4x4(diagonal: [Float(s[0]), Float(s[1]), Float(s[2]), 1])
                let local = T * rotM(pre) * rotM(r) * S
                let par = parentOf[id] ?? 0
                let res = (par != 0 ? w(par, depth + 1) : fix) * local
                cache[id] = res
                return res
            }
            return { w($0, 0) }
        }
        func mat4(_ d: [Double]?) -> simd_float4x4 {
            guard let d = d, d.count >= 16 else { return matrix_identity_float4x4 }
            return simd_float4x4(columns: (simd_float4(Float(d[0]), Float(d[1]), Float(d[2]), Float(d[3])), simd_float4(Float(d[4]), Float(d[5]), Float(d[6]), Float(d[7])),
                                           simd_float4(Float(d[8]), Float(d[9]), Float(d[10]), Float(d[11])), simd_float4(Float(d[12]), Float(d[13]), Float(d[14]), Float(d[15]))))
        }
        // skins: per control point up to 4 (cluster, weight); bind = inverse(TransformLink) * Transform
        struct Skin { var infl: [[(Int, Float)]]; var bones: [Int64]; var bindM: [simd_float4x4] }
        var skins: [Int64: Skin] = [:]
        for (gid, sid) in geomSkin {
            var bones: [Int64] = [], bindM: [simd_float4x4] = []
            var infl = [[(Int, Float)]](repeating: [], count: (geoms[gid]?.child("Vertices")?.doubles.count ?? 0) / 3)
            for cid in skinClusters[sid] ?? [] {
                guard let cl = deformers[cid], let bone = clusterBone[cid] else { continue }
                let ci = bones.count; bones.append(bone)
                bindM.append(mat4(cl.child("TransformLink")?.doubles).inverse * mat4(cl.child("Transform")?.doubles))
                let idx = cl.child("Indexes")?.ints ?? [], wts = cl.child("Weights")?.doubles ?? []
                for (i, v) in idx.enumerated() where i < wts.count && v >= 0 && Int(v) < infl.count { infl[Int(v)].append((ci, Float(wts[i]))) }
            }
            for i in infl.indices where infl[i].count > 4 { infl[i] = Array(infl[i].sorted { $0.1 > $1.1 }.prefix(4)) }
            if !bones.isEmpty { skins[gid] = Skin(infl: infl, bones: bones, bindM: bindM) }
        }
        let tStart: Double? = animated ? tMin : nil
        let world0 = makeWorld(tStart)

        // materials
        func readMat(_ n: N) -> Mat {
            let m = Mat(); let pr = props(n)
            func f(_ k: String, _ d: Double) -> Double { vec(pr, k, [d])[0] }
            var df = 1.0
            for k in ["DiffuseColor", "BaseColor", "base_color", "Maya|baseColor", "Maya|base_color"] where pr[k] != nil {
                let v = vec(pr, k, [0.8, 0.8, 0.8]); m.base = [Float(v[0]), Float(v[1]), Float(v[2])]; break
            }
            for k in ["DiffuseFactor", "Maya|base", "BaseColorFactor"] where pr[k] != nil { df = f(k, 1); break }
            m.base = m.base.map { $0 * Float(df) }
            if pr["TransparencyFactor"] != nil { m.alpha = Float(1 - f("TransparencyFactor", 0)) }
            else if pr["Opacity"] != nil { m.alpha = Float(f("Opacity", 1)) }
            if pr["TransparentColor"] != nil, pr["TransparencyFactor"] == nil, m.alpha >= 1 {
                let v = vec(pr, "TransparentColor", [0, 0, 0]); m.alpha = Float(1 - (v[0] + v[1] + v[2]) / 3)
            }
            if m.alpha < 0.001 { m.alpha = 1 }       // exporters that write 100 % transparency by mistake
            let ec = vec(pr, "EmissiveColor", [0, 0, 0]), ef = pr["EmissiveFactor"] != nil ? f("EmissiveFactor", 1) : 1
            m.emis = [Float(ec[0] * ef), Float(ec[1] * ef), Float(ec[2] * ef)]
            for k in ["Metallic", "Maya|metalness", "metallic", "ReflectionFactor"] where pr[k] != nil { m.metal = Float(min(max(f(k, 0), 0), 1)); break }
            var gotR = false
            for k in ["Roughness", "Maya|roughness", "roughness"] where pr[k] != nil { m.rough = Float(min(max(f(k, 0.8), 0), 1)); gotR = true; break }
            if !gotR, let sh = pr["ShininessExponent"] ?? pr["Shininess"], case .d(let e)? = sh.last { m.rough = Float(min(max(sqrt(2.0 / (e + 2.0)), 0.05), 1)) }
            return m
        }
        func slot(_ p: String) -> String? {
            let l = p.lowercased()
            if l.contains("specular") { return nil }
            if l.contains("normal") || l.contains("bump") { return "normal" }
            if l.contains("emis") || l.contains("glow") { return "emis" }
            if l.contains("rough") || l.contains("shininess") || l.contains("glossi") { return "rough" }
            if l.contains("metal") || l.contains("reflectionfactor") { return "metal" }
            if l.contains("occlusion") || l.hasSuffix("ao") || l.contains("|ao") { return "ao" }
            if l.contains("opacity") || l.contains("transparen") { return "opacity" }
            if l.contains("diffuse") || l.contains("base") || l.contains("color") { return "base" }
            return nil
        }
        // textures -> image data
        var imgCache: [Int64: UIImage] = [:]
        func image(_ tid: Int64) -> UIImage? {
            if let i = imgCache[tid] { return i }
            guard let t = texs[tid] else { return nil }
            var img: UIImage?
            if let v = texVid[tid].flatMap({ vids[$0] }), let cn = v.child("Content"), case .raw(let r)? = cn.p.first, r.count > 16 { img = UIImage(data: Data(r)) }
            if img == nil {
                var names: [String] = []
                for k in ["RelativeFilename", "FileName"] { if let n = t.child(k)?.str, !n.isEmpty { names.append(n) } }
                if let v = texVid[tid].flatMap({ vids[$0] }) { for k in ["RelativeFilename", "FileName"] { if let n = v.child(k)?.str, !n.isEmpty { names.append(n) } } }
                let all = (try? fm.contentsOfDirectory(atPath: dir)) ?? []
                for n in names {
                    let leaf = (n.replacingOccurrences(of: "\\", with: "/") as NSString).lastPathComponent.lowercased()
                    if let f = all.first(where: { $0.lowercased() == leaf || $0.lowercased() == (stemName + "_tex_" + leaf).lowercased() }) {
                        img = UIImage(contentsOfFile: dir + "/" + f); if img != nil { break }
                    }
                }
            }
            if let i = img { imgCache[tid] = i }
            return img
        }
        func pixels(_ img: UIImage, _ w: Int, _ h: Int) -> [UInt8]? {
            guard let cg = img.cgImage else { return nil }
            var d = [UInt8](repeating: 255, count: w * h * 4)
            let ok = d.withUnsafeMutableBytes { raw -> Bool in
                guard let ctx = CGContext(data: raw.baseAddress, width: w, height: h, bitsPerComponent: 8, bytesPerRow: w * 4,
                                          space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
                ctx.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h)); return true
            }
            return ok ? d : nil
        }
        func png(_ d: [UInt8], _ w: Int, _ h: Int) -> Data? {
            var d = d
            let img: UIImage? = d.withUnsafeMutableBytes { raw in
                guard let ctx = CGContext(data: raw.baseAddress, width: w, height: h, bitsPerComponent: 8, bytesPerRow: w * 4,
                                          space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue),
                      let cg = ctx.makeImage() else { return nil }
                return UIImage(cgImage: cg)
            }
            return img?.pngData()
        }

        // GLB assembly
        var bin = [UInt8]()
        var views: [[String: Any]] = [], accs: [[String: Any]] = [], images: [[String: Any]] = [], textures: [[String: Any]] = []
        func addView(_ bytes: [UInt8], target: Int? = nil) -> Int {
            while bin.count % 4 != 0 { bin.append(0) }
            var v: [String: Any] = ["buffer": 0, "byteOffset": bin.count, "byteLength": bytes.count]
            if let t = target { v["target"] = t }
            bin.append(contentsOf: bytes); views.append(v); return views.count - 1
        }
        func fbytes(_ a: [Float]) -> [UInt8] { a.withUnsafeBytes { Array($0) } }
        func ubytes(_ a: [UInt32]) -> [UInt8] { a.withUnsafeBytes { Array($0) } }
        var texIndexForData: [Data: Int] = [:]
        func addTexture(_ data: Data) -> Int {
            if let t = texIndexForData[data] { return t }
            let v = addView([UInt8](data))
            images.append(["bufferView": v, "mimeType": "image/png"])
            textures.append(["source": images.count - 1]); texIndexForData[data] = textures.count - 1
            return textures.count - 1
        }
        // PBR maps that travelled beside the model (zip from Blender etc.): "<stem>_tex_<file>" or "<stem>*" image files
        func discover(_ matName: String, _ single: Bool) -> [String: UIImage] {
            guard let all = try? fm.contentsOfDirectory(atPath: dir) else { return [:] }
            let exts: Set<String> = ["png", "jpg", "jpeg", "tif", "tiff", "bmp"]
            let sl = stemName.lowercased(), mn = matName.lowercased()
            var out: [String: UIImage] = [:]
            for f in all.sorted() {
                let l = f.lowercased()
                guard exts.contains((l as NSString).pathExtension), l.hasPrefix(sl) else { continue }
                if !single && (mn.isEmpty || !l.contains(mn)) { continue }
                let nm = (l as NSString).deletingPathExtension
                var k: String?
                if nm.contains("metallicroughness") || nm.hasSuffix("_orm") || nm.hasSuffix("_mr") || nm.hasSuffix("_arm") { k = "orm" }
                else if nm.contains("normal") || nm.hasSuffix("_nrm") || nm.hasSuffix("_nor") || nm.hasSuffix("_n") { k = "normal" }
                else if nm.contains("rough") || nm.contains("glossi") { k = "rough" }
                else if nm.contains("metal") { k = "metal" }
                else if nm.contains("occlusion") || nm.hasSuffix("_ao") || nm.contains("ambient") { k = "ao" }
                else if nm.contains("emis") || nm.contains("glow") { k = "emis" }
                else if nm.contains("opacity") || nm.contains("alpha") || nm.contains("transp") { k = "opacity" }
                else if nm.contains("basecolor") || nm.contains("base_color") || nm.contains("albedo") || nm.contains("diffuse") || nm.hasSuffix("_color") || nm.hasSuffix("_col") || nm.hasSuffix("_base") { k = "base" }
                if let k = k, out[k] == nil, let im = UIImage(contentsOfFile: dir + "/" + f) { out[k] = im }
            }
            return out
        }
        var matJson: [[String: Any]] = [], matIndex: [Int64: Int] = [:]
        func glMat(_ id: Int64) -> Int {
            if let i = matIndex[id] { return i }
            let m = id == 0 ? Mat() : readMat(mats[id]!)
            var pbr: [String: Any] = ["baseColorFactor": [m.base[0], m.base[1], m.base[2], m.alpha], "metallicFactor": m.metal, "roughnessFactor": m.rough]
            var j: [String: Any] = ["doubleSided": true]
            var imgs: [String: UIImage] = [:]
            for (p, t) in matTex[id] ?? [] { if let k = slot(p), imgs[k] == nil, let im = image(t) { imgs[k] = im } }
            for (k, v) in discover(id == 0 ? "" : mats[id]!.str, mats.count <= 1) where imgs[k] == nil { imgs[k] = v }
            if let img = imgs["base"] {
                var imgOut = img
                if let oi = imgs["opacity"] {         // separate opacity map -> base alpha
                    let w = min(2048, Int(img.size.width * img.scale)), h = min(2048, Int(img.size.height * img.scale))
                    if var a = pixels(img, w, h), let b = pixels(oi, w, h) {
                        for i in 0..<(w * h) { a[i * 4 + 3] = b[i * 4] }
                        if let d = png(a, w, h), let u = UIImage(data: d) { imgOut = u }
                    }
                    j["alphaMode"] = "BLEND"
                }
                if let d = imgOut.pngData() { pbr["baseColorTexture"] = ["index": addTexture(d)]; pbr["baseColorFactor"] = [1, 1, 1, m.alpha] }
            }
            if let orm = imgs["orm"], imgs["rough"] == nil, imgs["metal"] == nil, let d = orm.pngData() {
                pbr["metallicRoughnessTexture"] = ["index": addTexture(d)]; pbr["roughnessFactor"] = 1; pbr["metallicFactor"] = 1
                if imgs["ao"] == nil { imgs["ao"] = orm }
            } else if imgs["rough"] != nil || imgs["metal"] != nil {
                let rI = imgs["rough"], mI = imgs["metal"]
                let ref = rI ?? mI!
                let w = min(2048, Int(ref.size.width * ref.scale)), h = min(2048, Int(ref.size.height * ref.scale))
                var d = [UInt8](repeating: 255, count: w * h * 4)
                let rp = rI.flatMap { pixels($0, w, h) }, mp = mI.flatMap { pixels($0, w, h) }
                for i in 0..<(w * h) {
                    d[i * 4] = 255
                    d[i * 4 + 1] = rp?[i * 4] ?? UInt8(min(max(m.rough, 0), 1) * 255)
                    d[i * 4 + 2] = mp?[i * 4] ?? UInt8(min(max(m.metal, 0), 1) * 255)
                }
                if let data = png(d, w, h) { pbr["metallicRoughnessTexture"] = ["index": addTexture(data)]; pbr["roughnessFactor"] = 1; pbr["metallicFactor"] = 1 }
            }
            if let img = imgs["normal"], let d = img.pngData() { j["normalTexture"] = ["index": addTexture(d)] }
            if let img = imgs["emis"], let d = img.pngData() { j["emissiveTexture"] = ["index": addTexture(d)]; j["emissiveFactor"] = [1, 1, 1] }
            else if m.emis != [0, 0, 0] { j["emissiveFactor"] = m.emis }
            if let img = imgs["ao"], let d = img.pngData() { j["occlusionTexture"] = ["index": addTexture(d)] }
            if m.alpha < 0.999 { j["alphaMode"] = "BLEND" }
            j["pbrMetallicRoughness"] = pbr
            matJson.append(j); matIndex[id] = matJson.count - 1
            return matJson.count - 1
        }

        struct Bk { var cp: [Int32] = []; var lp: [Float] = []; var ln: [Float] = []; var uv: [Float] = [] }
        func m3(_ m: simd_float4x4) -> simd_float3x3 {
            simd_float3x3(simd_float3(m.columns.0.x, m.columns.0.y, m.columns.0.z), simd_float3(m.columns.1.x, m.columns.1.y, m.columns.1.z), simd_float3(m.columns.2.x, m.columns.2.y, m.columns.2.z))
        }
        /// World-space positions + normals of one primitive at a given pose (rigid or skinned).
        func posed(_ b: Bk, _ mid: Int64, _ skin: Skin?, _ W: (Int64) -> simd_float4x4) -> ([Float], [Float]) {
            let n = b.cp.count
            var P = [Float](repeating: 0, count: n * 3), Nn = P
            let Wm = W(mid), NM = m3(Wm).inverse.transpose
            var bm: [simd_float4x4] = []
            if let s = skin { for (i, bone) in s.bones.enumerated() { bm.append(W(bone) * s.bindM[i]) } }
            var cpB = [simd_float4x4?](repeating: nil, count: skin?.infl.count ?? 0)
            for k in 0..<n {
                let p = simd_float4(b.lp[k * 3], b.lp[k * 3 + 1], b.lp[k * 3 + 2], 1), nl = simd_float3(b.ln[k * 3], b.ln[k * 3 + 1], b.ln[k * 3 + 2])
                var M: simd_float4x4? = nil
                if let s = skin {
                    let ci = Int(b.cp[k])
                    if ci < cpB.count {
                        if let c = cpB[ci] { M = c }
                        else {
                            let inf = s.infl[ci]
                            var tw: Float = 0; var acc = simd_float4x4()
                            for (c, w) in inf { acc += w * bm[c]; tw += w }
                            if tw > 1e-6 { acc = (1 / tw) * acc; cpB[ci] = acc; M = acc }
                        }
                    }
                }
                let wp: simd_float4, nw: simd_float3
                if let M = M { wp = M * p; nw = m3(M) * nl } else { wp = Wm * p; nw = NM * nl }
                let nn = simd_length(nw) > 1e-9 ? simd_normalize(nw) : simd_float3(0, 1, 0)
                P[k * 3] = wp.x; P[k * 3 + 1] = wp.y; P[k * 3 + 2] = wp.z
                Nn[k * 3] = nn.x; Nn[k * 3 + 1] = nn.y; Nn[k * 3 + 2] = nn.z
            }
            return (P, Nn)
        }
        struct PInfo { var mid: Int64; var bk: Bk; var skin: Skin? }
        var infos: [PInfo] = []
        var prims: [[String: Any]] = []
        for (mid, _) in models.sorted(by: { $0.key < $1.key }) {
            guard let gid = modelGeom[mid], let g = geoms[gid] else { continue }
            let verts = g.child("Vertices")?.doubles ?? [], pvi = g.child("PolygonVertexIndex")?.ints ?? []
            if verts.count < 9 || pvi.count < 3 { continue }
            struct Layer { var vals: [Double] = []; var idx: [Int64] = []; var byPoly = false; var direct = true; var all = false }
            func layer(_ nm: String, _ vk: String, _ ik: String) -> Layer? {
                guard let e = g.child(nm) else { return nil }
                var L = Layer(); L.vals = e.child(vk)?.doubles ?? []; L.idx = e.child(ik)?.ints ?? []
                let mp = e.child("MappingInformationType")?.str ?? "", rf = e.child("ReferenceInformationType")?.str ?? "Direct"
                L.byPoly = mp == "ByPolygonVertex"; L.all = mp == "AllSame"; L.direct = rf == "Direct"
                return L
            }
            let nL = layer("LayerElementNormal", "Normals", "NormalsIndex"), uL = layer("LayerElementUV", "UV", "UVIndex")
            var mL = layer("LayerElementMaterial", "Materials", "Materials")
            if let e = g.child("LayerElementMaterial") { mL?.idx = e.child("Materials")?.ints ?? []; mL?.all = (e.child("MappingInformationType")?.str ?? "") == "AllSame" }
            let mlist = modelMats[mid] ?? []
            var bySlot: [Int: Bk] = [:]
            var polyNo = 0
            func lookup(_ L: Layer?, _ comps: Int, _ vi: Int, _ pv: Int) -> [Float]? {
                guard let L = L else { return nil }
                var k = L.byPoly ? pv : (L.all ? 0 : vi)
                if !L.direct { guard k < L.idx.count else { return nil }; k = Int(L.idx[k]) }
                guard k >= 0, (k + 1) * comps <= L.vals.count else { return nil }
                return (0..<comps).map { Float(L.vals[k * comps + $0]) }
            }
            func emit(_ corner: [(vi: Int, pv: Int)], _ pn: Int) {
                var sl = 0
                if let ml = mL { sl = ml.all ? Int(ml.idx.first ?? 0) : (pn < ml.idx.count ? Int(ml.idx[pn]) : 0) }
                var b = bySlot[sl] ?? Bk()
                for t in 1..<(corner.count - 1) {
                    let cs = [corner[0], corner[t], corner[t + 1]]
                    var lps: [simd_float3] = []
                    for c in cs {
                        guard c.vi >= 0, c.vi * 3 + 2 < verts.count else { return }
                        lps.append(simd_float3(Float(verts[c.vi * 3]), Float(verts[c.vi * 3 + 1]), Float(verts[c.vi * 3 + 2])))
                    }
                    let fn = simd_cross(lps[1] - lps[0], lps[2] - lps[0])
                    let fnn = simd_length(fn) > 1e-12 ? simd_normalize(fn) : simd_float3(0, 1, 0)
                    for (k, c) in cs.enumerated() {
                        b.cp.append(Int32(c.vi)); b.lp += [lps[k].x, lps[k].y, lps[k].z]
                        if let nv = lookup(nL, 3, c.vi, c.pv) { b.ln += [nv[0], nv[1], nv[2]] } else { b.ln += [fnn.x, fnn.y, fnn.z] }
                        if let u = lookup(uL, 2, c.vi, c.pv) { b.uv += [u[0], 1 - u[1]] } else { b.uv += [0, 0] }
                    }
                }
                bySlot[sl] = b
            }
            var corners: [(Int, Int)] = []
            for (k, raw) in pvi.enumerated() {
                let end = raw < 0, vi = Int(end ? ~raw : raw)
                corners.append((vi, k))
                if end { emit(corners.map { (vi: $0.0, pv: $0.1) }, polyNo); corners.removeAll(keepingCapacity: true); polyNo += 1 }
            }
            for (sl, b) in bySlot.sorted(by: { $0.key < $1.key }) where !b.cp.isEmpty {
                let (pos, nor) = posed(b, mid, skins[gid], world0)
                var mn = [Float.infinity, .infinity, .infinity], mx = [-Float.infinity, -Float.infinity, -Float.infinity]
                var k = 0; while k + 2 < pos.count { for c in 0..<3 { mn[c] = min(mn[c], pos[k + c]); mx[c] = max(mx[c], pos[k + c]) }; k += 3 }
                let vP = addView(fbytes(pos), target: 34962), vN = addView(fbytes(nor), target: 34962), vU = addView(fbytes(b.uv), target: 34962)
                let vI = addView(ubytes((0..<UInt32(b.cp.count)).map { $0 }), target: 34963)
                accs.append(["bufferView": vP, "componentType": 5126, "count": pos.count / 3, "type": "VEC3", "min": mn, "max": mx]); let aP = accs.count - 1
                accs.append(["bufferView": vN, "componentType": 5126, "count": nor.count / 3, "type": "VEC3"]); let aN = accs.count - 1
                accs.append(["bufferView": vU, "componentType": 5126, "count": b.uv.count / 2, "type": "VEC2"]); let aU = accs.count - 1
                accs.append(["bufferView": vI, "componentType": 5125, "count": b.cp.count, "type": "SCALAR"]); let aI = accs.count - 1
                prims.append(["attributes": ["POSITION": aP, "NORMAL": aN, "TEXCOORD_0": aU], "indices": aI, "mode": 4,
                              "material": glMat(sl < mlist.count ? mlist[sl] : 0)])
                infos.append(PInfo(mid: mid, bk: b, skin: skins[gid]))
            }
        }
        guard !prims.isEmpty else { lastError = "FBX has no mesh geometry"; return nil }
        var root: [String: Any] = [
            "asset": ["version": "2.0", "generator": "SaikiMotion FBX Import"],
            "scene": 0, "scenes": [["nodes": [0]]], "nodes": [["mesh": 0]],
            "meshes": [["primitives": prims]], "materials": matJson,
            "buffers": [["byteLength": bin.count]], "bufferViews": views, "accessors": accs
        ]
        if !images.isEmpty { root["images"] = images; root["textures"] = textures }
        guard var js = try? JSONSerialization.data(withJSONObject: root) else { lastError = "FBX conversion failed"; return nil }
        while js.count % 4 != 0 { js.append(0x20) }
        while bin.count % 4 != 0 { bin.append(0) }
        var glb = Data()
        func le(_ v: UInt32) { var x = v.littleEndian; withUnsafeBytes(of: &x) { glb.append(contentsOf: $0) } }
        le(0x46546C67); le(2); le(UInt32(12 + 8 + js.count + 8 + bin.count))
        le(UInt32(js.count)); le(0x4E4F534A); glb.append(js)
        le(UInt32(bin.count)); le(0x004E4942); glb.append(contentsOf: bin)
        guard (try? glb.write(to: URL(fileURLWithPath: out))) != nil else { lastError = "Cannot write converted FBX"; return nil }
        // skeleton + skin weights sidecar for Pose mode (static models; animated ones are baked frame by frame instead)
        try? fm.removeItem(atPath: out + ".skel"); try? fm.removeItem(atPath: out + ".noskel")
        var wroteSkel = false
        if !animated, !skins.isEmpty {
            var boneIds: [Int64] = [], seenB = Set<Int64>()
            func addBone(_ id: Int64) { if models[id] != nil, !seenB.contains(id) { seenB.insert(id); boneIds.append(id) } }
            for (_, sn) in skins.sorted(by: { $0.key < $1.key }) { for b in sn.bones { addBone(b) } }
            for (id, mo) in models.sorted(by: { $0.key < $1.key }) where mo.p.count > 2 {
                if case .s(let ty) = mo.p[2], ty == "LimbNode" { addBone(id) }
            }
            var idxOf: [Int64: Int] = [:]
            for (i, id) in boneIds.enumerated() { idxOf[id] = i }
            func boneParent(_ id: Int64) -> Int {
                var a = parentOf[id] ?? 0, g = 0
                while a != 0, g < 64 { if let i = idxOf[a] { return i }; a = parentOf[a] ?? 0; g += 1 }
                return -1
            }
            let skel = Skeleton3D()
            var binds: [simd_float4x4] = []
            for id in boneIds { binds.append(world0(id)) }
            for (i, id) in boneIds.enumerated() {
                let pi = boneParent(id)
                var nm = models[id]?.str ?? "bone\(i)"
                if let z = nm.firstIndex(of: "\u{0}") { nm = String(nm[..<z]) }
                if nm.hasPrefix("Model::") { nm.removeFirst(7) }
                if nm.isEmpty { nm = "bone\(i)" }
                let rest = pi >= 0 ? binds[pi].inverse * binds[i] : binds[i]
                skel.bones.append(Bone3D(name: nm, parent: pi, bindWorld: binds[i], restLocal: rest))
            }
            var J = [[UInt16]](), W = [[Float]]()
            for inf in infos {
                let n = inf.bk.cp.count
                var j = [UInt16](repeating: 0, count: n * 4), w = [Float](repeating: 0, count: n * 4)
                if let sn = inf.skin {
                    for k in 0..<n {
                        let ci = Int(inf.bk.cp[k])
                        guard ci >= 0, ci < sn.infl.count else { continue }
                        var sum: Float = 0
                        let list = sn.infl[ci]
                        for slot in 0..<min(4, list.count) {
                            let c = list[slot].0
                            if c >= 0, c < sn.bones.count, let bi = idxOf[sn.bones[c]] { j[k * 4 + slot] = UInt16(min(bi, 65535)); w[k * 4 + slot] = list[slot].1; sum += list[slot].1 }
                        }
                        if sum > 1e-6 { for q in 0..<4 { w[k * 4 + q] /= sum } }
                    }
                }
                J.append(j); W.append(w)
            }
            if !skel.bones.isEmpty { Skeleton3D.write(skel, joints: J, weights: W, to: out + ".skel"); wroteSkel = true }
        }
        if !wroteSkel { fm.createFile(atPath: out + ".noskel", contents: Data()) }
        if animated {
            // bake every frame (skinning + node animation) into the "<model>.glb.anim" sidecar GlbModel already plays back
            let tm = vec(gs, "TimeMode", [6])[0]
            var fps: Double = [11: 24, 6: 30, 10: 25, 3: 60, 1: 120, 5: 48, 4: 50, 13: 23.976][Int(tm)] ?? (Int(tm) == 14 ? max(vec(gs, "CustomFrameRate", [30])[0], 1) : 30)
            let dur = tMax - tMin
            let corners = infos.reduce(0) { $0 + $1.bk.cp.count }
            var nf = max(2, Int((dur * fps).rounded(.up)) + 1)
            let maxF = max(2, 150_000_000 / max(corners * 24, 1))
            if nf > maxF { nf = maxF; fps = Double(nf - 1) / dur }
            var side = Data()
            func le(_ v: UInt32) { var x = v.littleEndian; withUnsafeBytes(of: &x) { side.append(contentsOf: $0) } }
            le(0x41424153); le(UInt32(nf)); var fp = Float(fps); withUnsafeBytes(of: &fp) { side.append(contentsOf: $0) }; le(UInt32(infos.count))
            for i in infos { le(UInt32(i.bk.cp.count)) }
            for f in 0..<nf {
                let Wf = makeWorld(tMin + dur * Double(f) / Double(nf - 1))
                for i in infos {
                    let (P, Nn) = posed(i.bk, i.mid, i.skin, Wf)
                    P.withUnsafeBytes { side.append(contentsOf: $0) }; Nn.withUnsafeBytes { side.append(contentsOf: $0) }
                }
            }
            try? side.write(to: URL(fileURLWithPath: out + ".anim"))
        }
        return out
    }
}
