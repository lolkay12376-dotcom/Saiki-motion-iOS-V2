// ChromaTownDashboard.swift — full-screen ChromaTown dashboard (opened by "Open Dashboard…" in the effect panel).
// Live preview on top, Chroma Style switch, the 32 presets as a tappable grid, and every parameter as a slider.
// Close = revert to how the effect looked on opening, Apply = keep.

import UIKit

final class ChromaTownDashboardViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {
    private let lay: Layer
    private let entry: String
    private let onDone: () -> Void
    private let def: EffectDef?
    private var snap: [String: Float] = [:]
    private var savedVideoCb: (() -> Void)?
    private lazy var pv: PreviewView = {
        savedVideoCb = MetalSceneRenderer.onVideoFrame
        let v = PreviewView(); v.quality = 2
        return v
    }()
    private let accent = argbToUIColor(C.GREEN)
    private let sliders = UIStackView()
    private var styleSeg = UISegmentedControl(items: chromaTownStyles.map { $0.replacingOccurrences(of: "Start/End ", with: "") })
    private var grid: UICollectionView!
    private var sliderRefs: [String: (UISlider, UILabel)] = [:]

    init(_ l: Layer, _ entry: String, onDone: @escaping () -> Void) {
        self.lay = l; self.entry = entry; self.onDone = onDone; self.def = Registry.get(entry)
        super.init(nibName: nil, bundle: nil)
        modalPresentationStyle = .overFullScreen
        for (k, t) in l.props where k.hasPrefix(entry + "__") { snap[k] = t.base }
    }
    required init?(coder: NSCoder) { fatalError() }

    private func key(_ k: String) -> String { entry + "__" + k }
    private func val(_ k: String) -> Float {
        if let t = lay.props[key(k)] { return t.eval(lay.editTime(key(k), Editor.time)) }
        return def?.props.first { $0.key == k }?.def ?? 0
    }
    private func set(_ k: String, _ v: Float) { lay.track(key(k)).base = v }
    private func setColor(_ k: String, _ argb: UInt32) {
        let comps: [(String, UInt32)] = [("_a", 24), ("_r", 16), ("_g", 8), ("_b", 0)]
        for (suf, sh) in comps { lay.track(key(k) + suf).base = Float((argb >> sh) & 0xFF) / 255 }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(white: 0.06, alpha: 1)
        let safe = view.safeAreaLayoutGuide

        let close = UIButton(type: .system)
        close.setImage(Icons.sf( "xmark"), for: .normal); close.setTitle("  Close", for: .normal); close.tintColor = .white
        close.addAction(UIAction { [weak self] _ in self?.finish(apply: false) }, for: .touchUpInside)
        let apply = UIButton(type: .system)
        apply.setTitle("Apply", for: .normal); apply.titleLabel?.font = .systemFont(ofSize: 16, weight: .bold)
        apply.setTitleColor(.black, for: .normal); apply.backgroundColor = accent; apply.layer.cornerRadius = 17
        apply.contentEdgeInsets = UIEdgeInsets(top: 0, left: 18, bottom: 0, right: 18)
        apply.addAction(UIAction { [weak self] _ in self?.finish(apply: true) }, for: .touchUpInside)
        let title = UILabel(); title.text = "uni.ChromaTown Dashboard"
        title.font = .systemFont(ofSize: 16, weight: .semibold); title.textColor = .white
        let bar = UIView()
        for v in [close, apply, title] as [UIView] { v.translatesAutoresizingMaskIntoConstraints = false; bar.addSubview(v) }

        let box = UIView(); box.backgroundColor = .black; box.clipsToBounds = true
        let aspect = CGFloat(max(Editor.project.w, 1)) / CGFloat(max(Editor.project.h, 1))
        pv.translatesAutoresizingMaskIntoConstraints = false
        box.addSubview(pv)

        styleSeg.selectedSegmentIndex = Int(val("ctStyle"))
        styleSeg.addAction(UIAction { [weak self] _ in
            guard let self = self else { return }
            self.set("ctStyle", Float(self.styleSeg.selectedSegmentIndex)); self.pv.requestDraw()
        }, for: .valueChanged)

        let lay2 = UICollectionViewFlowLayout()
        lay2.scrollDirection = .horizontal; lay2.itemSize = CGSize(width: 96, height: 84); lay2.minimumLineSpacing = 8
        lay2.sectionInset = UIEdgeInsets(top: 0, left: 12, bottom: 0, right: 12)
        grid = UICollectionView(frame: .zero, collectionViewLayout: lay2)
        grid.backgroundColor = .clear; grid.dataSource = self; grid.delegate = self
        grid.register(PresetCell.self, forCellWithReuseIdentifier: "c")
        grid.showsHorizontalScrollIndicator = false

        let scroll = UIScrollView(); sliders.axis = .vertical; sliders.spacing = 6
        sliders.translatesAutoresizingMaskIntoConstraints = false; scroll.addSubview(sliders)
        for pd in def?.props ?? [] where pd.options == nil { sliders.addArrangedSubview(sliderRow(pd)) }
        for pd in def?.props ?? [] where pd.options != nil && pd.key != "ctStyle" { sliders.addArrangedSubview(switchRow(pd)) }

        for v in [bar, box, styleSeg, grid, scroll] as [UIView] { v.translatesAutoresizingMaskIntoConstraints = false; view.addSubview(v) }
        let fillH = pv.heightAnchor.constraint(equalTo: box.heightAnchor); fillH.priority = UILayoutPriority(750)
        let fillW = pv.widthAnchor.constraint(equalTo: box.widthAnchor); fillW.priority = UILayoutPriority(749)
        NSLayoutConstraint.activate([
            bar.topAnchor.constraint(equalTo: safe.topAnchor), bar.leadingAnchor.constraint(equalTo: safe.leadingAnchor),
            bar.trailingAnchor.constraint(equalTo: safe.trailingAnchor), bar.heightAnchor.constraint(equalToConstant: 52),
            close.leadingAnchor.constraint(equalTo: bar.leadingAnchor, constant: 12), close.centerYAnchor.constraint(equalTo: bar.centerYAnchor),
            title.centerXAnchor.constraint(equalTo: bar.centerXAnchor), title.centerYAnchor.constraint(equalTo: bar.centerYAnchor),
            apply.trailingAnchor.constraint(equalTo: bar.trailingAnchor, constant: -12), apply.centerYAnchor.constraint(equalTo: bar.centerYAnchor),
            apply.heightAnchor.constraint(equalToConstant: 34),
            box.topAnchor.constraint(equalTo: bar.bottomAnchor), box.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            box.trailingAnchor.constraint(equalTo: view.trailingAnchor), box.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.36),
            pv.centerXAnchor.constraint(equalTo: box.centerXAnchor), pv.centerYAnchor.constraint(equalTo: box.centerYAnchor),
            pv.widthAnchor.constraint(lessThanOrEqualTo: box.widthAnchor), pv.heightAnchor.constraint(lessThanOrEqualTo: box.heightAnchor),
            pv.widthAnchor.constraint(equalTo: pv.heightAnchor, multiplier: aspect), fillH, fillW,
            styleSeg.topAnchor.constraint(equalTo: box.bottomAnchor, constant: 10),
            styleSeg.leadingAnchor.constraint(equalTo: safe.leadingAnchor, constant: 12), styleSeg.trailingAnchor.constraint(equalTo: safe.trailingAnchor, constant: -12),
            grid.topAnchor.constraint(equalTo: styleSeg.bottomAnchor, constant: 10), grid.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            grid.trailingAnchor.constraint(equalTo: view.trailingAnchor), grid.heightAnchor.constraint(equalToConstant: 84),
            scroll.topAnchor.constraint(equalTo: grid.bottomAnchor, constant: 10), scroll.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scroll.trailingAnchor.constraint(equalTo: view.trailingAnchor), scroll.bottomAnchor.constraint(equalTo: safe.bottomAnchor),
            sliders.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor), sliders.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor, constant: -16),
            sliders.leadingAnchor.constraint(equalTo: scroll.frameLayoutGuide.leadingAnchor, constant: 16),
            sliders.trailingAnchor.constraint(equalTo: scroll.frameLayoutGuide.trailingAnchor, constant: -16),
            sliders.widthAnchor.constraint(equalTo: scroll.frameLayoutGuide.widthAnchor, constant: -32),
        ])
    }
    override func viewDidAppear(_ a: Bool) { super.viewDidAppear(a); pv.requestDraw(); DispatchQueue.main.async { [weak self] in self?.pv.requestDraw() } }

    private func sliderRow(_ pd: PropDef) -> UIView {
        let name = UILabel(); name.text = pd.label; name.textColor = .white; name.font = .systemFont(ofSize: 13)
        let num = UILabel(); num.textColor = accent; num.font = .monospacedDigitSystemFont(ofSize: 13, weight: .medium); num.textAlignment = .right
        let s = UISlider(); s.minimumValue = pd.min; s.maximumValue = pd.max; s.tintColor = accent
        s.value = val(pd.key)
        func fmt(_ v: Float) -> String { String(format: "%.\(pd.dec)f", v) }
        num.text = fmt(s.value)
        s.addAction(UIAction { [weak self] _ in self?.set(pd.key, s.value); num.text = fmt(s.value); self?.pv.requestDraw() }, for: .valueChanged)
        sliderRefs[pd.key] = (s, num)
        let top = UIStackView(arrangedSubviews: [name, num]); top.distribution = .fill
        num.widthAnchor.constraint(equalToConstant: 64).isActive = true
        let col = UIStackView(arrangedSubviews: [top, s]); col.axis = .vertical; col.spacing = 2
        return col
    }
    private func switchRow(_ pd: PropDef) -> UIView {
        let name = UILabel(); name.text = pd.label; name.textColor = .white; name.font = .systemFont(ofSize: 13)
        let sw = UISwitch(); sw.isOn = val(pd.key) >= 0.5; sw.onTintColor = accent
        sw.addAction(UIAction { [weak self] _ in self?.set(pd.key, sw.isOn ? 1 : 0); self?.pv.requestDraw() }, for: .valueChanged)
        sliderRefs[pd.key] = nil
        switchRefs[pd.key] = sw
        return UIStackView(arrangedSubviews: [name, UIView(), sw])
    }
    private var switchRefs: [String: UISwitch] = [:]

    private func applyPreset(_ p: ChromaTownPreset) {
        // reset every param to default, then lay the preset over it
        for pd in def?.props ?? [] { set(pd.key, pd.def) }
        for (k, v) in p.vals { set(k, v) }
        setColor("ctSC", p.sc); setColor("ctEC", p.ec)
        for (k, r) in sliderRefs { let v = val(k); r.0.value = v; r.1.text = String(format: "%.\(def?.props.first { $0.key == k }?.dec ?? 2)f", v) }
        for (k, sw) in switchRefs { sw.isOn = val(k) >= 0.5 }
        styleSeg.selectedSegmentIndex = Int(val("ctStyle"))
        pv.requestDraw()
    }

    func collectionView(_ cv: UICollectionView, numberOfItemsInSection s: Int) -> Int { ChromaTownPresets.all.count }
    func collectionView(_ cv: UICollectionView, cellForItemAt ip: IndexPath) -> UICollectionViewCell {
        let c = cv.dequeueReusableCell(withReuseIdentifier: "c", for: ip) as! PresetCell
        c.configure(ChromaTownPresets.all[ip.item]); return c
    }
    func collectionView(_ cv: UICollectionView, didSelectItemAt ip: IndexPath) { applyPreset(ChromaTownPresets.all[ip.item]) }

    private func finish(apply: Bool) {
        if !apply {
            for k in Array(lay.props.keys) where k.hasPrefix(entry + "__") {
                if let b = snap[k] { lay.props[k]?.base = b } else { lay.props[k] = nil }
            }
        }
        MetalSceneRenderer.onVideoFrame = savedVideoCb
        let done = onDone
        dismiss(animated: true) { done() }
    }
}

private final class PresetCell: UICollectionViewCell {
    private let g = CAGradientLayer(); private let l = UILabel()
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.layer.cornerRadius = 10; contentView.clipsToBounds = true
        g.startPoint = CGPoint(x: 0, y: 0); g.endPoint = CGPoint(x: 1, y: 1); contentView.layer.addSublayer(g)
        l.font = .systemFont(ofSize: 11, weight: .semibold); l.textColor = .white; l.numberOfLines = 2
        l.shadowColor = .black; l.shadowOffset = CGSize(width: 0, height: 1)
        l.translatesAutoresizingMaskIntoConstraints = false; contentView.addSubview(l)
        NSLayoutConstraint.activate([l.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 8),
                                     l.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -8),
                                     l.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -6)])
    }
    required init?(coder: NSCoder) { fatalError() }
    override func layoutSubviews() { super.layoutSubviews(); g.frame = contentView.bounds }
    func configure(_ p: ChromaTownPreset) {
        g.colors = [UIColor(white: 0.05, alpha: 1).cgColor] + p.swatch.map { c in
            UIColor(red: CGFloat((c >> 16) & 255) / 255, green: CGFloat((c >> 8) & 255) / 255, blue: CGFloat(c & 255) / 255, alpha: 1).cgColor }
        l.text = p.name
    }
}
