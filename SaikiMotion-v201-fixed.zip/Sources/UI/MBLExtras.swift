// MBLExtras.swift — Magic Bullet Looks additions: Colourista 3-way wheels, HSL double-wheel UI, preset tab with
// thumbnails of the colour applied, and moving the effect left/right in the layer's effect stack.

import UIKit

// MARK: - Colourista wheel (puck on a hue ring; x/y in -1...1, y up)
final class MBLWheelView: UIView {
    var x: Float = 0, y: Float = 0
    var onChange: ((Float, Float) -> Void)?
    override init(frame: CGRect) {
        super.init(frame: frame); backgroundColor = .clear
        let t = UITapGestureRecognizer(target: self, action: #selector(reset)); t.numberOfTapsRequired = 2; addGestureRecognizer(t)
    }
    required init?(coder: NSCoder) { fatalError() }
    @objc private func reset() { x = 0; y = 0; setNeedsDisplay(); onChange?(0, 0) }
    override func draw(_ r: CGRect) {
        let c = CGPoint(x: bounds.midX, y: bounds.midY), R = min(bounds.width, bounds.height) / 2 - 4
        let ringW = R * 0.17
        for i in 0..<90 {
            let a0 = CGFloat(i) / 90 * .pi * 2, a1 = (CGFloat(i) + 1.6) / 90 * .pi * 2
            let p = UIBezierPath(arcCenter: c, radius: R - ringW / 2, startAngle: -a1, endAngle: -a0, clockwise: true)
            p.lineWidth = ringW; UIColor(hue: CGFloat(i) / 90, saturation: 0.85, brightness: 0.95, alpha: 1).setStroke(); p.stroke()
        }
        UIColor(white: 0.1, alpha: 1).setFill()
        UIBezierPath(arcCenter: c, radius: R - ringW - 2, startAngle: 0, endAngle: .pi * 2, clockwise: true).fill()
        UIColor(white: 0.3, alpha: 1).setStroke()
        let cross = UIBezierPath(); cross.lineWidth = 0.5
        cross.move(to: CGPoint(x: c.x - R * 0.7, y: c.y)); cross.addLine(to: CGPoint(x: c.x + R * 0.7, y: c.y))
        cross.move(to: CGPoint(x: c.x, y: c.y - R * 0.7)); cross.addLine(to: CGPoint(x: c.x, y: c.y + R * 0.7)); cross.stroke()
        let pr = R - ringW - 6
        let pt = CGPoint(x: c.x + CGFloat(x) * pr, y: c.y - CGFloat(y) * pr)
        UIColor.white.setStroke(); UIColor(white: 0.1, alpha: 1).setFill()
        let d = UIBezierPath(arcCenter: pt, radius: 6, startAngle: 0, endAngle: .pi * 2, clockwise: true); d.lineWidth = 2; d.fill(); d.stroke()
    }
    private func move(_ t: UITouch) {
        let c = CGPoint(x: bounds.midX, y: bounds.midY), R = min(bounds.width, bounds.height) / 2 - 4
        let pr = R - R * 0.17 - 6, l = t.location(in: self)
        var vx = (l.x - c.x) / pr, vy = -(l.y - c.y) / pr
        let n = hypot(vx, vy); if n > 1 { vx /= n; vy /= n }
        x = Float(vx); y = Float(vy); setNeedsDisplay(); onChange?(x, y)
    }
    override func touchesBegan(_ t: Set<UITouch>, with e: UIEvent?) { if let t = t.first { move(t) } }
    override func touchesMoved(_ t: Set<UITouch>, with e: UIEvent?) { if let t = t.first { move(t) } }
}

// MARK: - HSL wheel: 8 draggable dots. angle = hue shift, distance from centre = saturation / lightness (centre ring = 0)
final class MBLHSLWheel: UIView {
    enum Mode { case sat, light }
    let mode: Mode
    var hue = [Float](repeating: 0, count: 8), val = [Float](repeating: 0, count: 8), sel = 0
    var onChange: ((Int, Float, Float) -> Void)?, onSelect: ((Int) -> Void)?
    init(_ m: Mode) { mode = m; super.init(frame: .zero); backgroundColor = .clear }
    required init?(coder: NSCoder) { fatalError() }
    private var R: CGFloat { min(bounds.width, bounds.height) / 2 - 4 }
    private func pos(_ i: Int) -> CGPoint {
        let a = (CGFloat(mblHslHue[i] + hue[i] * 30) - 90) * .pi / 180, rho = 0.09 + 0.91 * (0.5 + 0.5 * CGFloat(val[i]))
        return CGPoint(x: bounds.midX + cos(a) * rho * R * 0.95, y: bounds.midY + sin(a) * rho * R * 0.95)
    }
    override func draw(_ r: CGRect) {
        let c = CGPoint(x: bounds.midX, y: bounds.midY), g = UIGraphicsGetCurrentContext()!
        for i in 0..<72 {
            let a0 = CGFloat(i) / 72 * .pi * 2 - .pi / 2, a1 = (CGFloat(i) + 1.3) / 72 * .pi * 2 - .pi / 2
            UIColor(hue: CGFloat(i) / 72, saturation: 0.85, brightness: mode == .light ? 0.75 : 0.9, alpha: 1).setFill()
            let p = UIBezierPath(); p.move(to: c); p.addArc(withCenter: c, radius: R, startAngle: a0, endAngle: a1, clockwise: true); p.fill()
        }
        let cols = (mode == .sat ? [UIColor(white: 0.45, alpha: 1), UIColor(white: 0.45, alpha: 0)] : [UIColor(white: 0, alpha: 0.9), UIColor(white: 0, alpha: 0)]).map { $0.cgColor } as CFArray
        let gr = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: cols, locations: nil)!
        g.saveGState(); UIBezierPath(arcCenter: c, radius: R, startAngle: 0, endAngle: .pi * 2, clockwise: true).addClip()
        g.drawRadialGradient(gr, startCenter: c, startRadius: 0, endCenter: c, endRadius: R, options: []); g.restoreGState()
        UIColor(white: 0.5, alpha: 0.6).setStroke()
        let mid = UIBezierPath(arcCenter: c, radius: R * 0.95 * 0.545, startAngle: 0, endAngle: .pi * 2, clockwise: true); mid.lineWidth = 0.5
        mid.setLineDash([3, 3], count: 2, phase: 0); mid.stroke()
        for i in 0..<8 {
            let p = pos(i), rad: CGFloat = i == sel ? 6 : 4.5
            UIColor(hue: CGFloat(mblHslHue[i]) / 360, saturation: 1, brightness: 1, alpha: 1).setFill()
            (i == sel ? UIColor.white : UIColor(white: 0, alpha: 0.7)).setStroke()
            let d = UIBezierPath(arcCenter: p, radius: rad, startAngle: 0, endAngle: .pi * 2, clockwise: true); d.lineWidth = 1.6; d.fill(); d.stroke()
        }
    }
    private var active = 0
    override func touchesBegan(_ t: Set<UITouch>, with e: UIEvent?) {
        guard let l = t.first?.location(in: self) else { return }
        active = (0..<8).min { hypot(pos($0).x - l.x, pos($0).y - l.y) < hypot(pos($1).x - l.x, pos($1).y - l.y) } ?? 0
        sel = active; onSelect?(active); move(l)
    }
    override func touchesMoved(_ t: Set<UITouch>, with e: UIEvent?) { if let l = t.first?.location(in: self) { move(l) } }
    private func move(_ l: CGPoint) {
        let dx = l.x - bounds.midX, dy = l.y - bounds.midY
        var deg = Float(atan2(dy, dx) * 180 / .pi) + 90
        var d = deg - mblHslHue[active]; while d > 180 { d -= 360 }; while d < -180 { d += 360 }
        deg = max(-30, min(30, d)) / 30
        let rho = Float(hypot(dx, dy) / (R * 0.95)), v = max(-1, min(1, (rho - 0.09) / 0.91 * 2 - 1))
        hue[active] = deg; val[active] = v; setNeedsDisplay(); onChange?(active, deg, v)
    }
}

// MARK: - Presets
struct MBLPreset { let name: String; let mods: [String]; let v: [String: Float] }
let mblPresets: [MBLPreset] = [
    MBLPreset(name: "Original", mods: [], v: [:]),
    MBLPreset(name: "Teal & Orange", mods: ["colorista", "mojo"], v: ["mbCoSx": -0.4, "mbCoHx": 0.35, "mbCoHy": 0.2, "mbMjAmt": 0.8, "mbMjTO": 0.6]),
    MBLPreset(name: "Warm Skin Glow", mods: ["mojo", "exposure"], v: ["mbMjAmt": 0.7, "mbMjWarm": 0.4, "mbMjTO": 0, "mbMjFade": 0.1, "mbMjSat": 1.05, "mbExpo": 0.1]),
    MBLPreset(name: "Cool Night", mods: ["colorista", "contrast"], v: ["mbCoSx": -0.2, "mbCoSy": -0.3, "mbCoMx": -0.1, "mbCoMy": -0.1, "mbCoExp": -0.2, "mbCoSat": 0.9, "mbCon": 0.2]),
    MBLPreset(name: "Faded Film", mods: ["mojo"], v: ["mbMjAmt": 1, "mbMjFade": 0.5, "mbMjCon": -0.1, "mbMjSat": 0.85, "mbMjWarm": 0.15, "mbMjTO": 0.2]),
    MBLPreset(name: "Vivid Pop", mods: ["huesat", "contrast"], v: ["mbSat": 1.4, "mbCon": 0.25]),
    MBLPreset(name: "Pastel Anime", mods: ["colorista", "mojo"], v: ["mbCoHx": 0.2, "mbCoHy": 0.1, "mbCoSat": 1.1, "mbCoExp": 0.2, "mbMjAmt": 0.8, "mbMjFade": 0.25, "mbMjCon": -0.15, "mbMjSat": 1, "mbMjTO": 0]),
    MBLPreset(name: "Moody Teal", mods: ["colorista"], v: ["mbCoSx": -0.45, "mbCoSy": -0.1, "mbCoMx": -0.2, "mbCoHx": 0.1, "mbCoHy": 0.05, "mbCoSat": 0.85, "mbCoSl": -0.1]),
    MBLPreset(name: "Golden Hour", mods: ["warmcool", "colorista", "contrast"], v: ["mbWarm": 0.5, "mbCoHx": 0.3, "mbCoHy": 0.15, "mbCoExp": 0.15, "mbCon": 0.15]),
]

/// Parameter values a preset results in (tool "added" defaults, then the preset's overrides).
func mblResolve(_ p: MBLPreset) -> [String: Float] {
    var d: [String: Float] = [:]
    for id in p.mods { if let t = mblTools.first(where: { $0.id == id }) { for (k, _, v) in t.vals { d[k] = v } } }
    for (k, v) in p.v { d[k] = v }
    return d
}

/// CPU port of the shader maths (Exposure, Warm/Cool, Contrast, Saturation, Colourista, Mojo II) for the thumbnails.
private func mblApply(_ v: [String: Float], _ c0: SIMD3<Float>) -> SIMD3<Float> {
    func g(_ k: String, _ d: Float = 0) -> Float { v[k] ?? d }
    func ss(_ a: Float, _ b: Float, _ x: Float) -> Float { let t = max(0, min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t) }
    func lum(_ c: SIMD3<Float>, _ w: SIMD3<Float>) -> Float { c.x * w.x + c.y * w.y + c.z * w.z }
    func off(_ x: Float, _ y: Float) -> SIMD3<Float> { SIMD3(x, -0.5 * x + 0.866 * y, -0.5 * x - 0.866 * y) }
    var c = c0
    c *= exp2(g("mbExpo"))
    let w = g("mbWarm"); c *= SIMD3(exp2(-w * 0.5) * exp2(-w * 0.25), exp2(w * 0.5), exp2(w * 0.25))
    let pv = g("mbConPiv", 0.18); c = (c - SIMD3(repeating: pv)) * (1 + g("mbCon")) + SIMD3(repeating: pv)
    let sat = g("mbSat", 1); let l0 = lum(c, SIMD3(0.299, 0.587, 0.114)); c = SIMD3(repeating: l0) + (c - SIMD3(repeating: l0)) * sat
    if g("mbCo") > 0.5 {
        let co0 = c, cl = lum(c, SIMD3(0.2126, 0.7152, 0.0722))
        let wS = 1 - ss(0, 0.5, cl), wH = ss(0.5, 1, cl), wM = max(0, min(1, 1 - wS - wH))
        c *= exp2(g("mbCoExp"))
        c += wS * (off(g("mbCoSx"), g("mbCoSy")) + SIMD3(repeating: g("mbCoSl"))) * 0.3
        c *= SIMD3(repeating: 1) + wM * (off(g("mbCoMx"), g("mbCoMy")) + SIMD3(repeating: g("mbCoMl"))) * 0.8
        c *= SIMD3(repeating: 1) + wH * (off(g("mbCoHx"), g("mbCoHy")) + SIMD3(repeating: g("mbCoHl"))) * 0.8
        let l2 = lum(c, SIMD3(0.2126, 0.7152, 0.0722)); c = SIMD3(repeating: l2) + (c - SIMD3(repeating: l2)) * g("mbCoSat", 1)
        let s = g("mbCoStr", 1); c = co0 + (c - co0) * s
    }
    if g("mbMj") > 0.5 {
        let m0 = c, ml = lum(c, SIMD3(0.299, 0.587, 0.114)), to = g("mbMjTO")
        c += to * (SIMD3(-0.05, 0.03, 0.06) * (1 - ss(0, 0.6, ml)) + SIMD3(0.07, 0.02, -0.06) * ss(0.4, 1, ml))
        let wm = g("mbMjWarm"); c *= SIMD3(exp2(wm * 0.2), 1, exp2(-wm * 0.2))
        c = (c - SIMD3(repeating: 0.18)) * (1 + g("mbMjCon") * 0.6) + SIMD3(repeating: 0.18)
        let l2 = lum(c, SIMD3(0.299, 0.587, 0.114)); c = SIMD3(repeating: l2) + (c - SIMD3(repeating: l2)) * g("mbMjSat", 1)
        let f = g("mbMjFade"); c = c * (1 - f * 0.3) + SIMD3(repeating: f * 0.08)
        c = m0 + (c - m0) * g("mbMjAmt")
    }
    return SIMD3(max(0, min(1, c.x)), max(0, min(1, c.y)), max(0, min(1, c.z)))
}

enum MBLThumbs {
    private static var base: (w: Int, h: Int, px: [UInt8])?
    private static var cache: [String: UIImage] = [:]
    private static func loadBase() -> (w: Int, h: Int, px: [UInt8])? {
        if let b = base { return b }
        let names = [("fx_girl", "jpg"), ("anime_portrait", "jpg"), ("fx_woman", "jpg")]
        guard let img = names.compactMap({ n in Bundle.main.path(forResource: n.0, ofType: n.1).flatMap { UIImage(contentsOfFile: $0) } }).first else { return nil }
        let w = 132, h = 88
        var px = [UInt8](repeating: 0, count: w * h * 4)
        guard let ctx = CGContext(data: &px, width: w, height: h, bitsPerComponent: 8, bytesPerRow: w * 4, space: CGColorSpaceCreateDeviceRGB(),
                                  bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue), let cg = img.cgImage else { return nil }
        let sc = max(CGFloat(w) / CGFloat(cg.width), CGFloat(h) / CGFloat(cg.height)), dw = CGFloat(cg.width) * sc, dh = CGFloat(cg.height) * sc
        ctx.draw(cg, in: CGRect(x: (CGFloat(w) - dw) / 2, y: (CGFloat(h) - dh) / 2, width: dw, height: dh))
        base = (w, h, px); return base
    }
    static func image(_ p: MBLPreset) -> UIImage {
        if let c = cache[p.name] { return c }
        guard let b = loadBase() else { return mblIcon(p.mods.first ?? "colorista", 96) }
        let v = mblResolve(p); var out = b.px
        for i in 0..<(b.w * b.h) {
            let c = mblApply(v, SIMD3(Float(b.px[i * 4]) / 255, Float(b.px[i * 4 + 1]) / 255, Float(b.px[i * 4 + 2]) / 255))
            out[i * 4] = UInt8(c.x * 255); out[i * 4 + 1] = UInt8(c.y * 255); out[i * 4 + 2] = UInt8(c.z * 255); out[i * 4 + 3] = 255
        }
        guard let ctx = CGContext(data: &out, width: b.w, height: b.h, bitsPerComponent: 8, bytesPerRow: b.w * 4, space: CGColorSpaceCreateDeviceRGB(),
                                  bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue), let cg = ctx.makeImage() else { return mblIcon("colorista", 96) }
        let u = UIImage(cgImage: cg); cache[p.name] = u; return u
    }
}

// MARK: - Editor panels
extension MBLEditorViewController {
    func coloristaPanel() {
        let pre = UIButton(type: .system); pre.setTitle("Preset: None  ▾", for: .normal); pre.tintColor = gold; pre.contentHorizontalAlignment = .leading
        let items: [(String, [String: Float])] = [
            ("None", [:]), ("Teal & Orange", ["mbCoSx": -0.4, "mbCoHx": 0.35, "mbCoHy": 0.2]), ("Warm Skin", ["mbCoMx": 0.15, "mbCoMy": 0.05, "mbCoHx": 0.2, "mbCoHy": 0.1]),
            ("Cool Night", ["mbCoSx": -0.2, "mbCoSy": -0.3, "mbCoMx": -0.1, "mbCoMy": -0.1, "mbCoExp": -0.2]), ("Faded", ["mbCoSl": 0.3, "mbCoSat": 0.8])]
        pre.menu = UIMenu(children: items.map { n, vv in UIAction(title: n) { [weak self] _ in
            guard let s = self else { return }
            for (k, d, _) in s.tool("colorista").vals where k != "mbCo" { s.set(k, d) }
            for (k, v) in vv { s.set(k, v) }
            s.showTab() } })
        pre.showsMenuAsPrimaryAction = true
        body.addArrangedSubview(pre)
        body.addArrangedSubview(sliderRow("Exposure", "mbCoExp"))
        func col(_ title: String, _ r: String) -> UIView {
            let t = UILabel(); t.text = title; t.font = .systemFont(ofSize: 12, weight: .semibold); t.textColor = UIColor(white: 0.8, alpha: 1); t.textAlignment = .center
            let w = MBLWheelView(); w.x = val("mbCo\(r)x"); w.y = val("mbCo\(r)y")
            w.onChange = { [weak self] x, y in self?.set("mbCo\(r)x", x); self?.set("mbCo\(r)y", y) }
            w.translatesAutoresizingMaskIntoConstraints = false; w.heightAnchor.constraint(equalToConstant: 140).isActive = true
            let c = UIStackView(arrangedSubviews: [t, w, sliderRow("Luma", "mbCo\(r)l")]); c.axis = .vertical; c.spacing = 4; return c
        }
        let mid = col("Midtones", "M"), midRow = UIStackView(arrangedSubviews: [UIView(), mid, UIView()]); midRow.distribution = .fillEqually
        body.addArrangedSubview(midRow)
        let sh = UIStackView(arrangedSubviews: [col("Shadows", "S"), col("Highlights", "H")]); sh.distribution = .fillEqually; sh.spacing = 16
        body.addArrangedSubview(sh)
        body.addArrangedSubview(sliderRow("Saturation", "mbCoSat"))
        body.addArrangedSubview(sliderRow("Strength", "mbCoStr"))
    }

    func hslWheelPanel() {
        let w1 = MBLHSLWheel(.sat), w2 = MBLHSLWheel(.light)
        let cap: (String) -> UILabel = { t in let l = UILabel(); l.text = t; l.font = .systemFont(ofSize: 11, weight: .semibold); l.textColor = UIColor(white: 0.7, alpha: 1); l.textAlignment = .center; return l }
        let table = UIStackView(); table.axis = .vertical; table.spacing = 2
        var cells: [[UILabel]] = [], rowViews: [UIView] = []
        func pct(_ v: Float) -> String { String(format: "%.0f%%", v * 100) }
        func refresh() {
            for w in [w1, w2] { w.hue = (0..<8).map { val("mbH\($0)") }; w.sel = hslIdx
                w.val = (0..<8).map { val((w.mode == .sat ? "mbS" : "mbL") + "\($0)") }; w.setNeedsDisplay() }
            for i in 0..<8 { cells[i][0].text = pct(val("mbH\(i)")); cells[i][1].text = pct(val("mbS\(i)")); cells[i][2].text = pct(val("mbL\(i)"))
                rowViews[i].backgroundColor = i == hslIdx ? UIColor(white: 0.2, alpha: 1) : .clear }
        }
        let hdr = UIStackView(arrangedSubviews: [UIView(), cap("Hue"), cap("Saturation"), cap("Lightness")]); hdr.distribution = .fillEqually
        table.addArrangedSubview(hdr)
        for i in 0..<8 {
            let dot = UIView(); dot.backgroundColor = UIColor(hue: CGFloat(mblHslHue[i]) / 360, saturation: 1, brightness: 1, alpha: 1); dot.layer.cornerRadius = 5
            dot.translatesAutoresizingMaskIntoConstraints = false; dot.widthAnchor.constraint(equalToConstant: 10).isActive = true; dot.heightAnchor.constraint(equalToConstant: 10).isActive = true
            let h = UIView(); h.addSubview(dot); dot.centerYAnchor.constraint(equalTo: h.centerYAnchor).isActive = true; dot.leadingAnchor.constraint(equalTo: h.leadingAnchor, constant: 8).isActive = true
            let ls = (0..<3).map { _ -> UILabel in let l = UILabel(); l.font = .monospacedDigitSystemFont(ofSize: 12, weight: .regular); l.textColor = .white; l.textAlignment = .center; return l }
            cells.append(ls)
            let r = UIStackView(arrangedSubviews: [h] + ls); r.distribution = .fillEqually; r.layer.cornerRadius = 4
            r.heightAnchor.constraint(equalToConstant: 26).isActive = true
            r.addGestureRecognizer(UITapGestureRecognizer(target: BlockTarget { [weak self] in self?.hslIdx = i; refresh() }.keep(r), action: #selector(BlockTarget.fire)))
            rowViews.append(r); table.addArrangedSubview(r)
        }
        for w in [w1, w2] {
            w.onSelect = { [weak self] i in self?.hslIdx = i; refresh() }
            w.onChange = { [weak self, weak w] i, dh, v in
                guard let s = self, let w = w else { return }
                s.set("mbH\(i)", dh); s.set((w.mode == .sat ? "mbS" : "mbL") + "\(i)", v); refresh()
            }
            w.translatesAutoresizingMaskIntoConstraints = false; w.heightAnchor.constraint(equalTo: w.widthAnchor).isActive = true
        }
        let c1 = UIStackView(arrangedSubviews: [cap("Hue / Saturation"), w1]); c1.axis = .vertical; c1.spacing = 4
        let c2 = UIStackView(arrangedSubviews: [cap("Hue / Lightness"), w2]); c2.axis = .vertical; c2.spacing = 4
        let wr = UIStackView(arrangedSubviews: [c1, c2]); wr.distribution = .fillEqually; wr.spacing = 14
        body.addArrangedSubview(wr); body.addArrangedSubview(table)
        refresh()
    }

    // MARK: presets
    func applyPreset(_ p: MBLPreset) {
        for id in mods { for (k, n, _) in tool(id).vals { set(k, n) } }
        let v = mblResolve(p)
        mods = p.mods
        for id in p.mods { for (k, _, d) in tool(id).vals { set(k, v[k] ?? d) } }
        curTool = p.mods.first; pv.requestDraw(); showTab()
    }

    func fillPresets(_ grid: UIStackView, _ vc: UIViewController) {
        for chunk in stride(from: 0, to: mblPresets.count, by: 3) {
            let row = UIStackView(); row.distribution = .fillEqually; row.spacing = 12; row.alignment = .top
            for p in mblPresets[chunk..<min(chunk + 3, mblPresets.count)] {
                let b = UIButton(type: .custom); b.setImage(MBLThumbs.image(p), for: .normal); b.imageView?.contentMode = .scaleAspectFill
                b.layer.cornerRadius = 8; b.clipsToBounds = true
                b.translatesAutoresizingMaskIntoConstraints = false; b.heightAnchor.constraint(equalTo: b.widthAnchor, multiplier: 0.68).isActive = true
                b.addAction(UIAction { [weak self, weak vc] _ in self?.applyPreset(p); vc?.dismiss(animated: true) }, for: .touchUpInside)
                let l = UILabel(); l.text = p.name; l.font = .systemFont(ofSize: 11); l.textColor = UIColor(white: 0.75, alpha: 1); l.textAlignment = .center; l.numberOfLines = 2
                let c = UIStackView(arrangedSubviews: [b, l]); c.axis = .vertical; c.spacing = 4; row.addArrangedSubview(c)
            }
            while row.arrangedSubviews.count < 3 { row.addArrangedSubview(UIView()) }
            grid.addArrangedSubview(row)
        }
    }

    // MARK: layer order (move this Looks effect left / right in the layer's effect stack)
    func moveInStack(_ d: Int) {
        guard let i = lay.fx.firstIndex(of: entry), lay.fx.indices.contains(i + d) else { return }
        lay.fx.swapAt(i, i + d); pv.requestDraw(); updateOrderButtons()
    }
    func updateOrderButtons() {
        let i = lay.fx.firstIndex(of: entry) ?? 0
        orderL?.alpha = i > 0 ? 1 : 0.3; orderR?.alpha = i < lay.fx.count - 1 ? 1 : 0.3
    }
}

private extension BlockTarget { func keep(_ v: UIView) -> BlockTarget { objc_setAssociatedObject(v, "bt", self, .OBJC_ASSOCIATION_RETAIN); return self } }

// MARK: - Edge Softness on-screen gizmo (yellow dashed inner circle = Radius, solid outer ellipse = Spread, centre dot = Centre X/Y)
final class MBLGizmoView: UIView {
    weak var owner: MBLEditorViewController?
    private let inner = CAShapeLayer(), outer = CAShapeLayer(), dots = CAShapeLayer()
    private let gold = UIColor(red: 0.98, green: 0.72, blue: 0.15, alpha: 1)
    private var hp: [CGPoint] = [.zero, .zero, .zero], drag = -1
    override init(frame: CGRect) {
        super.init(frame: frame); backgroundColor = .clear; isHidden = true
        for l in [outer, inner, dots] { l.fillColor = nil; l.strokeColor = gold.cgColor; l.lineWidth = 1.3; layer.addSublayer(l) }
        inner.lineDashPattern = [5, 4]; dots.fillColor = UIColor(white: 0, alpha: 0.35).cgColor
    }
    required init?(coder: NSCoder) { fatalError() }
    override func layoutSubviews() { super.layoutSubviews(); refresh() }
    private var m: (c: CGPoint, H: CGFloat, W: CGFloat, A: CGFloat, r0: CGFloat, r1: CGFloat, rad: CGFloat, spr: CGFloat)? {
        guard let o = owner else { return nil }
        let H = bounds.height, W = bounds.width, A = CGFloat(max(o.val("mbEsAsp"), 0.2)), rad = CGFloat(o.val("mbEsRad")), spr = CGFloat(o.val("mbEsSpr"))
        let r0 = 0.45 * rad * (1 - 0.6 * spr), r1 = r0 + 0.9 * rad * (0.3 + spr)
        return (CGPoint(x: W / 2 + CGFloat(o.val("mbEsX")) * 0.005 * W, y: H / 2 - CGFloat(o.val("mbEsY")) * 0.005 * H), H, W, A, r0, r1, rad, spr)
    }
    func refresh() {
        guard let o = owner, o.curTool == "edge", o.mods.contains("edge"), let g = m, g.H > 1 else { isHidden = true; return }
        isHidden = false
        func ell(_ r: CGFloat) -> CGRect { CGRect(x: g.c.x - r * g.A * g.H, y: g.c.y - r * g.H, width: 2 * r * g.A * g.H, height: 2 * r * g.H) }
        inner.path = UIBezierPath(ovalIn: ell(g.r0)).cgPath; outer.path = UIBezierPath(ovalIn: ell(g.r1)).cgPath
        let k: CGFloat = 0.7071
        hp = [g.c, CGPoint(x: g.c.x + g.r0 * g.A * g.H * k, y: g.c.y + g.r0 * g.H * k), CGPoint(x: g.c.x + g.r1 * g.A * g.H, y: g.c.y)]
        let d = UIBezierPath()
        for (i, p) in hp.enumerated() { d.append(UIBezierPath(arcCenter: p, radius: i == 0 ? 5 : 4, startAngle: 0, endAngle: .pi * 2, clockwise: true)) }
        dots.path = d.cgPath
    }
    private func nearest(_ l: CGPoint) -> Int? {
        guard !isHidden else { return nil }
        let d = hp.map { hypot($0.x - l.x, $0.y - l.y) }; let i = d.indices.min { d[$0] < d[$1] }!
        return d[i] < 30 ? i : nil
    }
    override func point(inside point: CGPoint, with event: UIEvent?) -> Bool { nearest(point) != nil }
    override func touchesBegan(_ t: Set<UITouch>, with e: UIEvent?) { if let l = t.first?.location(in: self) { drag = nearest(l) ?? -1 } }
    override func touchesMoved(_ t: Set<UITouch>, with e: UIEvent?) {
        guard let o = owner, let l = t.first?.location(in: self), let g = m, drag >= 0 else { return }
        func cl(_ v: CGFloat, _ a: CGFloat, _ b: CGFloat) -> Float { Float(max(a, min(b, v))) }
        switch drag {
        case 0: o.set("mbEsX", cl((l.x - g.W / 2) / (0.005 * g.W), -100, 100)); o.set("mbEsY", cl(-(l.y - g.H / 2) / (0.005 * g.H), -100, 100))
        case 1:
            let r0 = hypot((l.x - g.c.x) / (g.A * g.H), (l.y - g.c.y) / g.H)
            o.set("mbEsRad", cl(r0 / (0.45 * (1 - 0.6 * g.spr)), 0.1, 3))
        default:
            let r1 = abs(l.x - g.c.x) / (g.A * g.H)
            o.set("mbEsSpr", cl((r1 - g.r0) / (0.9 * g.rad) - 0.3, 0, 1))
        }
    }
    override func touchesEnded(_ t: Set<UITouch>, with e: UIEvent?) { if drag >= 0 { drag = -1; owner?.showTab() } }
    override func touchesCancelled(_ t: Set<UITouch>, with e: UIEvent?) { drag = -1 }
}

// MARK: - Haze/Flare panel (Magic Bullet Looks layout: Preset, value rows, Reflection toggle, Tint Color wheel + RGB)

/// Hue / saturation disc inside a thin ring with a draggable puck; `onChange` gives the tint as RGB 0...1 (value stays 1).
final class MBLTintWheel: UIView {
    var rgb: (Float, Float, Float) = (0.226, 0.181, 1.0) { didSet { setNeedsDisplay() } }
    var onChange: ((Float, Float, Float) -> Void)?
    private var disc: UIImage?
    override init(frame: CGRect) { super.init(frame: frame); backgroundColor = .clear }
    required init?(coder: NSCoder) { fatalError() }
    private func hsv() -> (h: CGFloat, s: CGFloat) {
        let mx = max(rgb.0, max(rgb.1, rgb.2)), mn = min(rgb.0, min(rgb.1, rgb.2)), d = mx - mn
        if d < 0.0001 { return (0, 0) }
        var h: Float
        if mx == rgb.0 { h = ((rgb.1 - rgb.2) / d).truncatingRemainder(dividingBy: 6) } else if mx == rgb.1 { h = (rgb.2 - rgb.0) / d + 2 } else { h = (rgb.0 - rgb.1) / d + 4 }
        if h < 0 { h += 6 }
        return (CGFloat(h / 6), CGFloat(d / max(mx, 0.0001)))
    }
    private func makeDisc(_ n: Int) -> UIImage {
        UIGraphicsImageRenderer(size: CGSize(width: n, height: n)).image { r in
            let c = CGFloat(n) / 2
            for y in 0..<n { for x in 0..<n {
                let dx = (CGFloat(x) - c) / c, dy = (CGFloat(y) - c) / c, d = hypot(dx, dy)
                if d > 1 { continue }
                var h = atan2(-dy, dx) / (.pi * 2); if h < 0 { h += 1 }
                UIColor(hue: h, saturation: d, brightness: 1, alpha: 1).setFill()
                r.cgContext.fill(CGRect(x: x, y: y, width: 1, height: 1))
            } }
        }
    }
    override func draw(_ rect: CGRect) {
        let R = min(bounds.width, bounds.height) / 2 - 3, c = CGPoint(x: bounds.midX, y: bounds.midY)
        UIColor(white: 0.55, alpha: 1).setStroke()
        let ring = UIBezierPath(arcCenter: c, radius: R + 1, startAngle: 0, endAngle: .pi * 2, clockwise: true); ring.lineWidth = 3; ring.stroke()
        let ir = R - 5
        if disc == nil || abs((disc?.size.width ?? 0) - ir * 2) > 1 { disc = makeDisc(Int(ir * 2)) }
        disc?.draw(in: CGRect(x: c.x - ir, y: c.y - ir, width: ir * 2, height: ir * 2))
        let (h, s) = hsv(), a = h * .pi * 2
        let p = CGPoint(x: c.x + cos(a) * s * ir, y: c.y - sin(a) * s * ir)
        UIColor.white.setStroke(); let d = UIBezierPath(arcCenter: p, radius: 4, startAngle: 0, endAngle: .pi * 2, clockwise: true); d.lineWidth = 1.5; d.stroke()
    }
    private func move(_ t: UITouch) {
        let l = t.location(in: self), c = CGPoint(x: bounds.midX, y: bounds.midY), ir = min(bounds.width, bounds.height) / 2 - 8
        let dx = (l.x - c.x) / ir, dy = -(l.y - c.y) / ir
        var h = atan2(dy, dx) / (.pi * 2); if h < 0 { h += 1 }
        let s = min(hypot(dx, dy), 1)
        let col = UIColor(hue: h, saturation: s, brightness: 1, alpha: 1)
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, al: CGFloat = 0; col.getRed(&r, green: &g, blue: &b, alpha: &al)
        rgb = (Float(r), Float(g), Float(b)); onChange?(rgb.0, rgb.1, rgb.2)
    }
    override func touchesBegan(_ t: Set<UITouch>, with e: UIEvent?) { if let t = t.first { move(t) } }
    override func touchesMoved(_ t: Set<UITouch>, with e: UIEvent?) { if let t = t.first { move(t) } }
}

extension MBLEditorViewController {
    func setTint(_ k: String, _ r: Float, _ g: Float, _ b: Float) {
        lay.track(key(k) + "_r").base = r; lay.track(key(k) + "_g").base = g; lay.track(key(k) + "_b").base = b; lay.track(key(k) + "_a").base = 1
        pv.requestDraw()
    }

    func hazeFlarePanel() {
        let dim = UIColor(white: 0.62, alpha: 1)
        // Preset popup
        let pre = UIButton(type: .system); pre.showsMenuAsPrimaryAction = true
        pre.backgroundColor = UIColor(white: 0.16, alpha: 1); pre.layer.cornerRadius = 5; pre.tintColor = .white
        pre.titleLabel?.font = .systemFont(ofSize: 13, weight: .medium); pre.contentHorizontalAlignment = .left
        pre.contentEdgeInsets = UIEdgeInsets(top: 6, left: 10, bottom: 6, right: 10)
        let curP = Int(val("mbHfPre"))
        pre.setTitle(mblHazePresets[min(max(curP, 0), mblHazePresets.count - 1)].name + "  ▾", for: .normal)
        pre.menu = UIMenu(children: mblHazePresets.enumerated().map { (i, p) in
            UIAction(title: p.name, state: i == curP ? .on : .off) { [weak self] _ in
                guard let self = self else { return }
                self.set("mbHfPre", Float(i))
                if i > 0 { for (k, v) in p.v { self.set(k, v) }; self.setTint("mbHfC", p.tint.0, p.tint.1, p.tint.2) }
                self.showTab()
            }
        })
        let pl = UILabel(); pl.text = "Preset:"; pl.font = .systemFont(ofSize: 13); pl.textColor = dim
        pl.setContentHuggingPriority(.required, for: .horizontal)
        let prow = UIStackView(arrangedSubviews: [pl, pre]); prow.spacing = 12; prow.alignment = .center
        body.addArrangedSubview(prow)

        func row(_ title: String, _ k: String, pct: Bool) {
            guard let pd = defs[k] else { return }
            let t = UILabel(); t.text = title + ":"; t.font = .systemFont(ofSize: 13); t.textColor = dim
            t.translatesAutoresizingMaskIntoConstraints = false; t.widthAnchor.constraint(equalToConstant: 128).isActive = true
            let v = UILabel(); v.font = .monospacedDigitSystemFont(ofSize: 13, weight: .medium); v.textColor = .white; v.textAlignment = .right
            v.translatesAutoresizingMaskIntoConstraints = false; v.widthAnchor.constraint(equalToConstant: 62).isActive = true
            let s = UISlider(); s.minimumValue = pd.min; s.maximumValue = pd.max; s.value = val(k); s.tintColor = gold
            let show: (Float) -> String = { pct ? String(format: "%.1f%%", $0) : String(format: "%.2f", $0) }
            v.text = show(s.value)
            s.addAction(UIAction { [weak self, weak s, weak v] _ in
                guard let s = s, let v = v else { return }
                self?.set(k, s.value); self?.set("mbHfPre", 0); v.text = show(s.value)
            }, for: .valueChanged)
            let r = UIStackView(arrangedSubviews: [t, s, v]); r.spacing = 8; r.alignment = .center
            body.addArrangedSubview(r)
        }
        row("Spillage", "mbHfSp", pct: true); row("Softness", "mbHfSo", pct: true); row("Reach", "mbHfRe", pct: true)
        row("Exposure", "mbHfEx", pct: false); row("Reflection Exposure", "mbHfRx", pct: false)

        // Reflection: On / Off check button
        let rl = UILabel(); rl.text = "Reflection:"; rl.font = .systemFont(ofSize: 13); rl.textColor = dim
        rl.translatesAutoresizingMaskIntoConstraints = false; rl.widthAnchor.constraint(equalToConstant: 128).isActive = true
        let tg = UIButton(type: .system); tg.backgroundColor = UIColor(white: 0.16, alpha: 1); tg.layer.cornerRadius = 4; tg.tintColor = .white
        tg.titleLabel?.font = .systemFont(ofSize: 13, weight: .medium)
        tg.contentEdgeInsets = UIEdgeInsets(top: 4, left: 12, bottom: 4, right: 12)
        func upd() { tg.setTitle(val("mbHfRf") > 0.5 ? "✓ On" : "Off", for: .normal) }
        upd()
        tg.addAction(UIAction { [weak self] _ in guard let self = self else { return }
            self.set("mbHfRf", self.val("mbHfRf") > 0.5 ? 0 : 1); self.set("mbHfPre", 0); upd() }, for: .touchUpInside)
        let trow = UIStackView(arrangedSubviews: [rl, tg, UIView()]); trow.spacing = 8; trow.alignment = .center
        body.addArrangedSubview(trow)

        row("Matte Box Size", "mbHfBx", pct: true); row("Matte Box Shade", "mbHfSh", pct: true)

        // Tint Color: wheel + RGB read-out
        let tl = UILabel(); tl.text = "Tint Color"; tl.font = .systemFont(ofSize: 13, weight: .semibold); tl.textColor = .white
        body.addArrangedSubview(tl)
        let wheel = MBLTintWheel()
        wheel.rgb = (comp("mbHfC", "r", 0.226), comp("mbHfC", "g", 0.181), comp("mbHfC", "b", 1.0))
        wheel.translatesAutoresizingMaskIntoConstraints = false
        wheel.widthAnchor.constraint(equalToConstant: 130).isActive = true; wheel.heightAnchor.constraint(equalToConstant: 130).isActive = true
        func readout(_ n: String) -> UILabel { let l = UILabel(); l.font = .monospacedDigitSystemFont(ofSize: 12, weight: .regular); l.textColor = .white; l.text = n; return l }
        let lr = readout(""), lg = readout(""), lb = readout("")
        func refresh(_ c: (Float, Float, Float)) {
            lr.text = String(format: "R   %.3f", c.0); lg.text = String(format: "G   %.3f", c.1); lb.text = String(format: "B   %.3f", c.2)
        }
        refresh(wheel.rgb)
        wheel.onChange = { [weak self] r, g, b in self?.setTint("mbHfC", r, g, b); self?.set("mbHfPre", 0); refresh((r, g, b)) }
        let rgbCol = UIStackView(arrangedSubviews: [lr, lg, lb]); rgbCol.axis = .vertical; rgbCol.spacing = 6
        let wr = UIStackView(arrangedSubviews: [UIView(), wheel, rgbCol, UIView()]); wr.spacing = 18; wr.alignment = .center
        body.addArrangedSubview(wr)
    }
}
