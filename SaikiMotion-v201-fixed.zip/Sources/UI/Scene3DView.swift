// Scene3DView.swift — the "Scene 3D" screen opened from the cube button beside the preview.
//
// A SceneKit viewport that mirrors every 3D thing in the main editor (model layers, 3D-cube
// layers, camera layers) at the editor's current time. Modes (left toolbar):
//   Still  — look around only (orbit / pan / zoom). Nothing can be selected or edited.
//   Move   — tap selects; drag the selected layer (gizmo arrows constrain to an axis).
//   Scale  — tap selects; drag up / down on it to scale.
// "+" menu: Import Model, 3D Scene (sync on/off), Grid, Timeline (panel), Gizmo.
// Bottom panel: Timeline (tracks + keyframes) or Properties (Layer / Global settings).
// Edits write the same x / y / z / scale tracks the main editor uses (auto-key aware, undoable).
// Camera: 1 finger orbits (on empty space in edit modes), 2 fingers pan, pinch dollies.

import UIKit
import SceneKit
import simd
import OpenGLES

final class Scene3DView: UIView, UIGestureRecognizerDelegate {

    enum Mode: Int { case still = 0, move, rotate, scale }

    // MARK: state
    private weak var host: EditorViewController?
    private let scn = SCNScene()
    private let sv = SCNView()
    private let cam = SCNNode()
    private let world = SCNNode()
    private let gridNode = SCNNode()
    private let gizmo = SCNNode()
    private var nodes: [Int: SCNNode] = [:]
    private var sig = ""
    private let vdbView = UIImageView()
    private var vdbOverlayOK = false
    private var vdbOvSig = ""
    private var link: CADisplayLink?
    private var mode = Mode.move
    private var selected = -1
    private var lastHostSel = -2
    private var showGrid = true, showGizmo = true, showTimeline = true, syncScene = true
    private var yaw: Float = 0.6, pitch: Float = 0.35, dist: Float = 6
    private var target = simd_float3(0, 0, 0)
    // smoothed camera (what is actually drawn); yaw / pitch / dist / target above are the goals the gestures move
    private var cYaw: Float = 0.6, cPitch: Float = 0.35, cDist: Float = 6, cTarget = simd_float3(0, 0, 0)
    private var camLink: CADisplayLink?
    private var tickN = 0
    private var camMoving = false, orbiting = false
    private var velYaw: Float = 0, velPitch: Float = 0
    private var lastOverlayT: CFTimeInterval = 0
    private var drag = false, dragAxis = -1
    fileprivate var dragPrev = CGPoint.zero, dragCur = CGPoint.zero
    fileprivate var snapOn = false, rotAcc: Float = 0
    private var gizmoMats: [Int: SCNMaterial] = [:]
    private var gizmoBase: [Int: UIColor] = [:]
    private var vdbSig = ""
    private var scLayer = -1
    private var lastTris: [Scatter.Tri] = []
    private var surfaceTris: [Int: [Scatter.Tri]] = [:]
    private var scInst: [Int: [SCNNode]] = [:]
    // pose mode
    fileprivate struct SkinPrim { let node: SCNNode; let base: [Float]; let jnt: [UInt16]; let wgt: [Float] }
    fileprivate var skels: [Int: Skeleton3D] = [:]
    fileprivate var skinPrims: [Int: [SkinPrim]] = [:]
    fileprivate var holders: [Int: SCNNode] = [:]
    fileprivate var modelScale: [Int: Float] = [:]
    fileprivate var poseSigStore: [Int: String] = [:]
    fileprivate var ovStore: [Int: String] = [:]
    fileprivate var poseMode = false, showBones = false
    fileprivate var selBone = -1
    fileprivate var lastPhysWall: CFTimeInterval = 0
    fileprivate var boneClip: [Float]? = nil
    fileprivate var boneFilter = ""
    fileprivate var boneFilterMode = 0
    fileprivate var boneStruct: [Int: String] = [:]
    fileprivate var boneNodes: [Int: [SCNNode]] = [:]

    // UI
    private var modeBtns: [UIButton] = []
    private let chip = UILabel()
    private let plus = UIButton(type: .custom)
    private let tl = UIView()                       // bottom panel (timeline or properties)
    private let timeLbl = UILabel()
    private let playBtn = UIButton(type: .custom)
    private let canvas = TLCanvas()
    private let tlBox = UIView()
    private let propScroll = UIScrollView()
    private let propStack = UIStackView()
    private let tabSeg = FlatSegment(["Timeline", "Properties", "Scatter"])
    private let scopeSeg = FlatSegment(["Layer", "Global", "Bones"])
    private var header = UIStackView()
    private var fullscreen = false
    private var known = Set<Int>(), built = false
    private var propKey = ""
    private var fsBtn: UIButton?
    private lazy var headerH: NSLayoutConstraint = header.heightAnchor.constraint(equalToConstant: 52)
    private var stackRef: UIStackView?
    private var vdbMats: [Int: SCNMaterial] = [:]
    private var panelH: NSLayoutConstraint!
    private var mainStack: UIStackView?, lastLand: Bool?, barView: UIView?
    private let sideCol = UIStackView()
    private lazy var sideW: NSLayoutConstraint = sideCol.widthAnchor.constraint(equalToConstant: 390)

    /// Landscape: the viewport takes the left, the tool bar + timeline / properties become a column on the right.
    override func layoutSubviews() {
        super.layoutSubviews()
        let land = bounds.width > bounds.height
        if let ms = mainStack {
            ms.isLayoutMarginsRelativeArrangement = true
            ms.layoutMargins = UIEdgeInsets(top: 0, left: land ? max(safeAreaInsets.left - 12, 0) : 0, bottom: 0, right: land ? max(safeAreaInsets.right - 12, 0) : 0)
        }
        if land != lastLand { lastLand = land; applyOrientation(land) }
    }

    private func applyOrientation(_ land: Bool) {
        guard let ms = mainStack, let bar = barView else { return }
        for v in [bar, tl] { sideCol.removeArrangedSubview(v); ms.removeArrangedSubview(v); v.removeFromSuperview() }
        ms.removeArrangedSubview(sideCol); sideCol.removeFromSuperview()
        if land {
            ms.axis = .horizontal; ms.spacing = 8; ms.alignment = .fill
            sideCol.axis = .vertical; sideCol.spacing = 8
            sideCol.addArrangedSubview(bar); sideCol.addArrangedSubview(tl)
            ms.addArrangedSubview(sideCol)
            panelH.isActive = false; sideW.isActive = true
        } else {
            sideW.isActive = false; panelH.isActive = true
            ms.axis = .vertical; ms.spacing = 8
            ms.addArrangedSubview(bar); ms.addArrangedSubview(tl)
        }
    }
    private let accent = UIColor(red: 1, green: 0.55, blue: 0.08, alpha: 1)

    // MARK: entry
    static func present(in host: EditorViewController) {
        if host.view.subviews.contains(where: { $0 is Scene3DView }) { return }
        let v = Scene3DView(host: host)
        v.translatesAutoresizingMaskIntoConstraints = false
        host.view.addSubview(v)
        NSLayoutConstraint.activate([
            v.leadingAnchor.constraint(equalTo: host.view.leadingAnchor),
            v.trailingAnchor.constraint(equalTo: host.view.trailingAnchor),
            v.topAnchor.constraint(equalTo: host.view.topAnchor),
            v.bottomAnchor.constraint(equalTo: host.view.bottomAnchor)])
    }

    init(host: EditorViewController) {
        self.host = host
        super.init(frame: .zero)
        backgroundColor = .black
        buildScene()
        buildUI()
        applyCam(snap: true)
        updateModeUI()
        rebuildMenu()
        link = CADisplayLink(target: self, selector: #selector(tick))
        link?.preferredFramesPerSecond = 30
        link?.add(to: .main, forMode: .common)
        camLink = CADisplayLink(target: self, selector: #selector(camStep(_:)))
        camLink?.add(to: .main, forMode: .common)
    }
    required init?(coder: NSCoder) { fatalError() }

    override func willMove(toSuperview newSuperview: UIView?) {
        if newSuperview == nil { link?.invalidate(); link = nil; camLink?.invalidate(); camLink = nil }
    }

    @objc private func close() { removeFromSuperview() }

    // MARK: scene
    private func buildScene() {
        scn.background.contents = UIColor.black
        let c = SCNCamera(); c.fieldOfView = 50; c.zNear = 0.05; c.zFar = 300
        cam.camera = c
        scn.rootNode.addChildNode(cam)
        scn.rootNode.addChildNode(world)
        scn.rootNode.addChildNode(gridNode)
        scn.rootNode.addChildNode(gizmo)
        let amb = SCNNode(); amb.light = SCNLight(); amb.light?.type = .ambient; amb.light?.intensity = 650
        let sun = SCNNode(); sun.light = SCNLight(); sun.light?.type = .directional; sun.light?.intensity = 900
        sun.eulerAngles = SCNVector3(-0.8, 0.6, 0)
        scn.rootNode.addChildNode(amb); scn.rootNode.addChildNode(sun)

        // floor grid + red X / blue Z axes (like the inspiration screenshot)
        var g: [SCNVector3] = []
        for i in -10...10 where i != 0 {
            let f = Float(i)
            g += [SCNVector3(f, 0, -10), SCNVector3(f, 0, 10), SCNVector3(-10, 0, f), SCNVector3(10, 0, f)]
        }
        gridNode.addChildNode(lines(g, UIColor(white: 0.28, alpha: 1)))
        gridNode.addChildNode(lines([SCNVector3(-10, 0, 0), SCNVector3(10, 0, 0)], UIColor(red: 0.85, green: 0.25, blue: 0.25, alpha: 1)))
        gridNode.addChildNode(lines([SCNVector3(0, 0, -10), SCNVector3(0, 0, 10)], UIColor(red: 0.25, green: 0.5, blue: 0.95, alpha: 1)))
        buildGizmo()
    }

    private func lines(_ pts: [SCNVector3], _ color: UIColor) -> SCNNode {
        let src = SCNGeometrySource(vertices: pts)
        let el = SCNGeometryElement(indices: (0..<Int32(pts.count)).map { $0 }, primitiveType: .line)
        let geo = SCNGeometry(sources: [src], elements: [el])
        let m = SCNMaterial(); m.diffuse.contents = color; m.lightingModel = .constant
        geo.materials = [m]
        return SCNNode(geometry: geo)
    }

    private func buildGizmo() {
        gizmo.childNodes.forEach { $0.removeFromParentNode() }
        gizmoMats = [:]; gizmoBase = [:]
        let cols = [UIColor(red: 1, green: 0.3, blue: 0.3, alpha: 1), UIColor(red: 0.3, green: 0.9, blue: 0.4, alpha: 1), UIColor(red: 0.3, green: 0.55, blue: 1, alpha: 1)]
        let rots = [SCNVector3(0, 0, -Float.pi / 2), SCNVector3(0, 0, 0), SCNVector3(Float.pi / 2, 0, 0)]
        func mat(_ key: Int, _ c: UIColor) -> SCNMaterial {
            let m = SCNMaterial(); m.diffuse.contents = c; m.lightingModel = .constant
            m.readsFromDepthBuffer = false; m.writesToDepthBuffer = false; m.isDoubleSided = true
            gizmoMats[key] = m; gizmoBase[key] = c; return m
        }
        /// Invisible, fatter copy of a handle: easy to hit with a finger.
        func proxy(_ g: SCNGeometry, _ code: Int) -> SCNNode {
            let m = SCNMaterial(); m.colorBufferWriteMask = []; m.isDoubleSided = true; m.readsFromDepthBuffer = false; m.writesToDepthBuffer = false
            g.materials = [m]
            let n = SCNNode(geometry: g); n.name = "ax\(code)"; n.renderingOrder = 1001; return n
        }
        for i in 0..<3 {
            let axis = SCNNode(); axis.eulerAngles = rots[i]
            let m = mat(i, cols[i])
            if mode == .rotate {     // one ring per axis
                let ring = SCNNode(geometry: SCNTorus(ringRadius: 1, pipeRadius: 0.03))
                ring.geometry?.materials = [m]; ring.name = "ax\(i)"; ring.renderingOrder = 1000
                axis.addChildNode(ring); axis.addChildNode(proxy(SCNTorus(ringRadius: 1, pipeRadius: 0.13), i))
                gizmo.addChildNode(axis); continue
            }
            let shaft = SCNNode(geometry: SCNCylinder(radius: 0.03, height: 1)); shaft.position.y = 0.5
            let tipGeo: SCNGeometry = mode == .scale ? SCNBox(width: 0.2, height: 0.2, length: 0.2, chamferRadius: 0) : SCNCone(topRadius: 0, bottomRadius: 0.11, height: 0.32)
            let tip = SCNNode(geometry: tipGeo); tip.position.y = 1.15
            for n in [shaft, tip] { n.geometry?.materials = [m]; n.name = "ax\(i)"; n.renderingOrder = 1000; axis.addChildNode(n) }
            let fat = proxy(SCNCylinder(radius: 0.15, height: 1.5), i); fat.position.y = 0.75
            axis.addChildNode(fat)
            gizmo.addChildNode(axis)
        }
        if mode == .move {           // plane handles: drag in the plane perpendicular to X / Y / Z
            let offs = [SIMD3<Float>(0, 0.32, 0.32), SIMD3<Float>(0.32, 0, 0.32), SIMD3<Float>(0.32, 0.32, 0)]
            let eul = [SCNVector3(0, Float.pi / 2, 0), SCNVector3(-Float.pi / 2, 0, 0), SCNVector3(0, 0, 0)]
            for k in 0..<3 {
                let code = 3 + k
                let sq = SCNNode(geometry: SCNPlane(width: 0.22, height: 0.22))
                sq.geometry?.materials = [mat(code, cols[k].withAlphaComponent(0.5))]
                sq.name = "ax\(code)"; sq.renderingOrder = 1000
                sq.eulerAngles = eul[k]; sq.simdPosition = offs[k]
                let fat = proxy(SCNPlane(width: 0.34, height: 0.34), code); fat.eulerAngles = eul[k]; fat.simdPosition = offs[k]
                gizmo.addChildNode(sq); gizmo.addChildNode(fat)
            }
        }
        if mode == .move || mode == .rotate {      // centre handle: free move / free rotate
            let c = SCNNode(geometry: SCNSphere(radius: mode == .move ? 0.1 : 0.14)); c.geometry?.materials = [mat(6, UIColor(white: 1, alpha: mode == .move ? 0.9 : 0.18))]
            c.name = "ax6"; c.renderingOrder = 1002
            gizmo.addChildNode(c)
        }
    }

    /// Dims the handles that are not being dragged (-1 = all normal).
    fileprivate func highlightGizmo(_ active: Int) {
        for (k, m) in gizmoMats {
            guard let base = gizmoBase[k] else { continue }
            if active < 0 || k == active { m.diffuse.contents = active == k ? UIColor.white : base }
            else { m.diffuse.contents = base.withAlphaComponent(0.25) }
        }
    }

    // MARK: sync with the main editor
    private func is3dContent(_ l: Layer) -> Bool { l.type == .MODEL || l.type == .CAMERA || l.is3d }
    private func layer(_ id: Int) -> Layer? { Editor.scene.layers.first { $0.id == id } }

    private func rebuild() {
        world.childNodes.forEach { $0.removeFromParentNode() }
        nodes = [:]; vdbMats = [:]; scInst = [:]; surfaceTris = [:]
        skels = [:]; skinPrims = [:]; holders = [:]; modelScale = [:]; poseSigStore = [:]; ovStore = [:]; boneStruct = [:]; boneNodes = [:]
        for l in Editor.scene.layers where is3dContent(l) {
            let root = SCNNode(); root.name = "L\(l.id)"
            switch l.type {
            case .CAMERA: root.addChildNode(camShape())
            case .MODEL: lastTris = []; root.addChildNode(isVdb(l) ? vdbNode(l) : modelNode(l))
            case .PARTICLES: lastTris = []; root.addChildNode(particleHolder())
            default: lastTris = []; root.addChildNode(l.isLight ? lightNode(l) : planeNode(l))
            }
            world.addChildNode(root)
            nodes[l.id] = root
            if l.type == .MODEL && !isVdb(l) || (l.type != .CAMERA && l.type != .MODEL) { surfaceTris[l.id] = lastTris }
        }
        if selected >= 0, nodes[selected] == nil { selected = -1 }
        let fresh = Set(nodes.keys).subtracting(known)
        known = Set(nodes.keys)
        if built, let id = fresh.first {              // just imported / added: show it
            if let l = layer(id) { nodes[id]?.simdTransform = xform(l, Editor.time) }
            if mode != .still { select(id, notifyHost: false) }
            frame(id)
        }
        built = true
        if mode != .still { tint(nodes[selected], true) }
    }

    // Particle layers: a live point cloud + small emitter marker (never a grey plane)
    private func particleHolder() -> SCNNode {
        let h = SCNNode(); h.name = "pts"
        let m = SCNSphere(radius: 0.04); let mt = SCNMaterial(); mt.diffuse.contents = UIColor.orange; mt.lightingModel = .constant; m.materials = [mt]
        h.addChildNode(SCNNode(geometry: m))
        return h
    }

    private func updateParticles(_ t: Float) {
        for l in Editor.scene.layers where l.type == .PARTICLES {
            guard let root = nodes[l.id], !root.isHidden, let h = root.childNode(withName: "pts", recursively: false) else { continue }
            h.childNodes.filter { $0.name == "cloud" }.forEach { $0.removeFromParentNode() }
            let ps = ParticularSim.field({ l.p($0, t) }, t: max(0, t - l.start))
            guard !ps.isEmpty else { continue }
            let pts = ps.map { SCNVector3($0.x, $0.y, $0.z) }
            var cols = [Float](); cols.reserveCapacity(ps.count * 4)
            for q in ps { let a = max(0, min(1, q.alpha * (1 - q.life))); cols += [q.cr, q.cg, q.cb, a] }
            let cs = SCNGeometrySource(data: cols.withUnsafeBufferPointer { Data(buffer: $0) }, semantic: .color, vectorCount: ps.count,
                                       usesFloatComponents: true, componentsPerVector: 4, bytesPerComponent: 4, dataOffset: 0, dataStride: 16)
            let el = SCNGeometryElement(indices: (0..<Int32(ps.count)).map { $0 }, primitiveType: .point)
            el.pointSize = 4; el.minimumPointScreenSpaceRadius = 1.5; el.maximumPointScreenSpaceRadius = 5
            let g = SCNGeometry(sources: [SCNGeometrySource(vertices: pts), cs], elements: [el])
            let mt = SCNMaterial(); mt.lightingModel = .constant; mt.blendMode = .add; mt.writesToDepthBuffer = false; g.materials = [mt]
            let n = SCNNode(geometry: g); n.name = "cloud"; h.addChildNode(n)
        }
    }

    private func lightNode(_ l: Layer) -> SCNNode {
        let sp = SCNSphere(radius: CGFloat(max(l.xf("lightRad", 0.5), 0.05)))      // invisible: only there so taps still pick the light
        let m = SCNMaterial(); m.colorBufferWriteMask = []; m.writesToDepthBuffer = false
        sp.materials = [m]
        let n = SCNNode(geometry: sp)
        let ring = SCNNode(); ring.name = "ring"
        var a: [SCNVector3] = [], b: [SCNVector3] = []
        let k = 48
        for i in 0..<k {
            let t0 = Float(i) / Float(k) * 2 * .pi, t1 = Float(i + 1) / Float(k) * 2 * .pi
            a += [SCNVector3(cos(t0), 0, sin(t0)), SCNVector3(cos(t1), 0, sin(t1))]     // horizontal circle
            b += [SCNVector3(cos(t0), sin(t0), 0), SCNVector3(cos(t1), sin(t1), 0)]     // vertical circle
        }
        ring.addChildNode(lines(a, .white)); ring.addChildNode(lines(b, .white))
        n.addChildNode(ring)
        styleLight(n, l)
        return n
    }

    private func styleLight(_ n: SCNNode, _ l: Layer) {
        guard let sp = n.geometry as? SCNSphere else { return }
        let r = CGFloat(max(l.xf("lightRad", 0.5), 0.05))
        if abs(sp.radius - r) > 0.0005 { sp.radius = r }
        let c = UInt32(bitPattern: l.vdbTint)
        let col = UIColor(red: CGFloat((c >> 16) & 255) / 255, green: CGFloat((c >> 8) & 255) / 255, blue: CGFloat(c & 255) / 255, alpha: 1)
        let type = Int(l.xf("lightType", 0))
        let sig = "\(type)|\(l.xf("lightPitch", -60))|\(l.xf("lightYaw", 30))|\(l.xf("lightCone", 45))"
        let old = n.childNodes.first(where: { $0.name?.hasPrefix("dir|") == true })
        if old?.name != "dir|" + sig {
            old?.removeFromParentNode()
            if type != 0 {
                let d = Lights.direction(l)
                func V(_ v: SIMD3<Float>) -> SCNVector3 { SCNVector3(v.x, v.y, v.z) }
                var pts: [SCNVector3] = [SCNVector3Zero, V(d * 1.6)]
                if type == 2 {      // cone edges
                    let up = abs(d.y) < 0.95 ? SIMD3<Float>(0, 1, 0) : SIMD3<Float>(1, 0, 0)
                    let a = simd_normalize(simd_cross(d, up)), b = simd_cross(d, a)
                    let ang = max(5, min(l.xf("lightCone", 45), 89)) * Float.pi / 180
                    for k in 0..<4 {
                        let t = Float(k) * Float.pi / 2
                        let e = simd_normalize(d * cos(ang) + (a * cos(t) + b * sin(t)) * sin(ang))
                        pts += [SCNVector3Zero, V(e * 1.6)]
                    }
                }
                let g = lines(pts, UIColor(red: 1, green: 0.85, blue: 0.3, alpha: 1))
                g.name = "dir|" + sig
                n.addChildNode(g)
            } else {
                let g = SCNNode(); g.name = "dir|" + sig; n.addChildNode(g)
            }
        }
        if let ring = n.childNode(withName: "ring", recursively: false) {
            ring.scale = SCNVector3(Float(r), Float(r), Float(r))
            ring.childNodes.forEach { $0.geometry?.materials.first?.diffuse.contents = col }
        }
    }

    private func camShape() -> SCNNode {
        let w: Float = 0.35, h: Float = 0.2, d: Float = -0.5
        let a = SCNVector3(-w, h, d), b = SCNVector3(w, h, d), c = SCNVector3(w, -h, d), e = SCNVector3(-w, -h, d), o = SCNVector3Zero
        return lines([o, a, o, b, o, c, o, e, a, b, b, c, c, e, e, a], UIColor.orange)
    }

    private func planeNode(_ l: Layer) -> SCNNode {
        let (qw, qh) = Xf.quadSize(l)
        let p = SCNPlane(width: CGFloat(max(qw, 0.05)), height: CGFloat(max(qh, 0.05)))
        let m = SCNMaterial(); m.isDoubleSided = true; m.lightingModel = .constant
        if let path = l.imagePath, let img = UIImage(contentsOfFile: path) { m.diffuse.contents = img }
        else { m.diffuse.contents = UIColor(white: 0.8, alpha: 0.35) }
        p.materials = [m]
        lastTris = Scatter.quad(Float(qw), Float(qh))
        return SCNNode(geometry: p)
    }

    private func modelNode(_ l: Layer) -> SCNNode {
        let holder = SCNNode()
        let old = GlbModel.cpuOnly
        GlbModel.cpuOnly = true
        let model = l.imagePath.flatMap { GlbModel.load(GlbModel.validate(path: $0)) }
        GlbModel.cpuOnly = old
        var built = false
        if let m = model {
            lastTris = Scatter.tris(m)
            if let sk = m.skeleton { skels[l.id] = sk; modelScale[l.id] = m.normalize[0] }
            for p in m.prims where !p.verts.isEmpty && p.mode != GLenum(GL_TRIANGLES) {   // point / line prims -> points
                let n = p.verts.count / 12
                let pts = (0..<n).map { SCNVector3(p.verts[$0 * 12], p.verts[$0 * 12 + 1], p.verts[$0 * 12 + 2]) }
                let g = SCNGeometry(sources: [SCNGeometrySource(vertices: pts)], elements: [SCNGeometryElement(indices: (0..<Int32(n)).map { $0 }, primitiveType: .point)])
                g.elements.first?.pointSize = 3; g.elements.first?.minimumPointScreenSpaceRadius = 1.5; g.elements.first?.maximumPointScreenSpaceRadius = 4
                let mt = SCNMaterial(); mt.diffuse.contents = UIColor.white; mt.lightingModel = .constant; g.materials = [mt]
                holder.addChildNode(SCNNode(geometry: g)); built = true
            }
            for p in m.prims where !p.verts.isEmpty && p.mode == GLenum(GL_TRIANGLES) {
                let vc = p.verts.count / 12
                let data = p.verts.withUnsafeBufferPointer { Data(buffer: $0) }
                func src(_ s: SCNGeometrySource.Semantic, _ comps: Int, _ off: Int) -> SCNGeometrySource {
                    SCNGeometrySource(data: data, semantic: s, vectorCount: vc, usesFloatComponents: true,
                                      componentsPerVector: comps, bytesPerComponent: 4, dataOffset: off * 4, dataStride: 48)
                }
                let idx: [UInt32] = p.cpuIdx.isEmpty ? (0..<UInt32(vc)).map { $0 } : p.cpuIdx
                let el = SCNGeometryElement(data: idx.withUnsafeBufferPointer { Data(buffer: $0) },
                                            primitiveType: .triangles, primitiveCount: idx.count / 3, bytesPerIndex: 4)
                let geo = SCNGeometry(sources: [src(.vertex, 3, 0), src(.normal, 3, 3), src(.texcoord, 2, 6)], elements: [el])
                let mat = SCNMaterial(); mat.isDoubleSided = true
                if p.texBase != 0, let img = GlbModel.cpuImages[p.texBase]?.img {
                    mat.diffuse.contents = img
                    mat.diffuse.contentsTransform = SCNMatrix4Translate(SCNMatrix4MakeScale(1, -1, 1), 0, 1, 0)
                    mat.diffuse.wrapS = .repeat; mat.diffuse.wrapT = .repeat
                } else {
                    mat.diffuse.contents = UIColor(red: CGFloat(p.color[0]), green: CGFloat(p.color[1]), blue: CGFloat(p.color[2]), alpha: 1)
                }
                geo.materials = [mat]
                let tn = SCNNode(geometry: geo)
                holder.addChildNode(tn)
                if m.skeleton != nil, !p.jnt.isEmpty, p.jnt.count == vc * 4 { skinPrims[l.id, default: []].append(SkinPrim(node: tn, base: p.verts, jnt: p.jnt, wgt: p.wgt)) }
                built = true
            }
            // renderer-space normalisation: S(n0) · T(offset)
            let n = m.normalize
            holder.simdTransform = S(n[0]) * T(n[1], n[2], n[3])
        }
        if !built {   // .vdb / animated / unreadable: a placeholder box so it can still be placed
            let b = SCNBox(width: 1, height: 1, length: 1, chamferRadius: 0)
            let m = SCNMaterial(); m.diffuse.contents = UIColor(white: 0.7, alpha: 0.3); m.fillMode = .lines; m.lightingModel = .constant
            b.materials = [m]
            holder.addChildNode(SCNNode(geometry: b))
        }
        holders[l.id] = holder
        return holder
    }

    private func isVdb(_ l: Layer) -> Bool { (l.imagePath ?? "").lowercased().hasSuffix(".vdb") }

    /// VDB preview: the density lattice as a point cloud (density threshold + point budget are global settings).
    private func vdbNode(_ l: Layer) -> SCNNode {
        let node = SCNNode()
        guard let path = l.imagePath, let vol = VdbVolume.load(path), let g = vol.grids.first, g.nx > 0, g.ny > 0, g.nz > 0 else {
            let b = SCNBox(width: 1, height: 1, length: 1, chamferRadius: 0)
            let m = SCNMaterial(); m.diffuse.contents = UIColor.orange; m.fillMode = .lines; m.lightingModel = .constant; b.materials = [m]
            node.addChildNode(SCNNode(geometry: b)); return node
        }
        let mx = max(g.data.max() ?? 1, 1e-6)
        let maxPts = Int(90000 * R3D.g("vpPts", 1))
        let step = max(1, Int(ceil(cbrt(Double(g.nx * g.ny * g.nz) / Double(max(maxPts, 1000))))))
        let th = R3D.g("vpThresh", 0.06)
        var pos: [SCNVector3] = [], col: [Float] = []
        let b = vol.bounds
        for z in stride(from: 0, to: g.nz, by: step) { for y in stride(from: 0, to: g.ny, by: step) { for x in stride(from: 0, to: g.nx, by: step) {
            let d = g.data[x + g.nx * (y + g.ny * z)] / mx
            if d > th {
                pos.append(SCNVector3((Float(x) + 0.5) / Float(g.nx) * 2 * max(b.0, 0.05) - max(b.0, 0.05),
                                      (Float(y) + 0.5) / Float(g.ny) * 2 * max(b.1, 0.05) - max(b.1, 0.05),
                                      (Float(z) + 0.5) / Float(g.nz) * 2 * max(b.2, 0.05) - max(b.2, 0.05)))
                let c = min(1, sqrt(d)); col += [c, c, c, c]
            }
        } } }
        if pos.isEmpty { return node }
        let colData = col.withUnsafeBufferPointer { Data(buffer: $0) }
        let colSrc = SCNGeometrySource(data: colData, semantic: .color, vectorCount: pos.count, usesFloatComponents: true,
                                       componentsPerVector: 4, bytesPerComponent: 4, dataOffset: 0, dataStride: 16)
        let el = SCNGeometryElement(indices: (0..<Int32(pos.count)).map { $0 }, primitiveType: .point)
        el.pointSize = 2; el.minimumPointScreenSpaceRadius = 1.5; el.maximumPointScreenSpaceRadius = 5
        let geo = SCNGeometry(sources: [SCNGeometrySource(vertices: pos), colSrc], elements: [el])
        let m = SCNMaterial(); m.lightingModel = .constant; m.blendMode = .add; m.writesToDepthBuffer = false; m.isDoubleSided = true
        geo.materials = [m]
        node.addChildNode(SCNNode(geometry: geo))
        vdbMats[l.id] = m
        styleVdb(m, l)
        return node
    }

    private func styleVdb(_ m: SCNMaterial, _ l: Layer) {
        let c = UInt32(bitPattern: l.vdbTint)
        let br = CGFloat(l.vdbBright * R3D.g("vdbBright", 1))
        m.diffuse.contents = UIColor(red: CGFloat((c >> 16) & 255) / 255 * br, green: CGFloat((c >> 8) & 255) / 255 * br, blue: CGFloat(c & 255) / 255 * br, alpha: 1)
        m.transparency = CGFloat(min(1, 0.25 * l.vdbDens * R3D.g("vdbDens", 1) * l.xf("vdbOpacity", 1)))
    }

    /// Centre the orbit camera on a layer.
    private func frame(_ id: Int) {
        guard let n = nodes[id] else { return }
        target = n.simdWorldPosition
        dist = 3.5
        applyCam(snap: !built)
    }

    /// Scatter preview: clones of each scattered model, placed exactly like the renderer places them.
    private func updateScatter(_ t: Float) {
        for l in Editor.scene.layers where l.type == .MODEL && !isVdb(l) {
            guard let root = nodes[l.id] else { continue }
            var mats: [simd_float4x4]? = nil
            let tid = Int(l.xf("scTarget", -1))
            if syncScene, l.xf("scOn", 0) > 0.5 {
                if tid == -2 || tid == -3 {      // ground / air: same field the renderer builds (no target layer)
                    mats = Scatter.instances(l, target: l, tris: Scatter.ground(l.xf("scGroundSize", 10), l.xf("scGroundY", 0)),
                                             targetM: matrix_identity_float4x4, time: t)
                } else if let tl = layer(tid), tl.id != l.id, let tn = nodes[tl.id], let tris = surfaceTris[tl.id] {
                    let norm = tl.type == .MODEL ? (tn.childNodes.first?.simdTransform ?? matrix_identity_float4x4) : matrix_identity_float4x4
                    mats = Scatter.instances(l, target: tl, tris: tris, targetM: xform(tl, t) * norm, time: t)
                }
            }
            var pool = scInst[l.id] ?? []
            guard let m = mats, let holder = root.childNodes.first else {
                pool.forEach { $0.removeFromParentNode() }; scInst[l.id] = nil; continue
            }
            let visible = syncScene && l.visible && t >= l.start && t <= l.end
            if l.xf("scKeep", 0) < 0.5 { root.isHidden = true }
            while pool.count > m.count { pool.removeLast().removeFromParentNode() }
            while pool.count < m.count {
                let n = SCNNode(); n.name = "L\(l.id)"; n.addChildNode(holder.clone()); world.addChildNode(n); pool.append(n)
                if mode != .still, l.id == selected { tint(n, true) }
            }
            for (i, n) in pool.enumerated() { n.simdTransform = m[i]; n.isHidden = !visible || vdbOverlayOK }
            scInst[l.id] = pool
        }
    }

    // matrix helpers
    private func T(_ x: Float, _ y: Float, _ z: Float) -> simd_float4x4 { var m = matrix_identity_float4x4; m.columns.3 = simd_float4(x, y, z, 1); return m }
    private func S(_ s: Float) -> simd_float4x4 { simd_float4x4(diagonal: simd_float4(s, s, s, 1)) }
    private func R(_ deg: Float, _ axis: simd_float3) -> simd_float4x4 { simd_float4x4(simd_quatf(angle: deg * .pi / 180, axis: axis)) }

    /// Same maths as MetalCam.modelMatrix: T(pos) · Rz · Rx · Ry · S(scale).
    private func xform(_ l: Layer, _ t: Float) -> simd_float4x4 {
        let lt = l.editTime("x", t)
        let x = l.p("x", lt), y = l.p("y", lt)
        var z = Xf.worldZ(l, t)
        let rot = R(l.p("rotZ", lt), simd_float3(0, 0, 1)) * R(l.p("rotX", lt), simd_float3(1, 0, 0)) * R(l.p("rotY", lt), simd_float3(0, 1, 0))
        if l.type == .CAMERA {
            var fov = l.p("fov", lt); if !fov.isFinite || fov < 10 { fov = 55 }
            z += 1 / tan(min(fov, 150) * Float.pi / 360)
            return T(x, y, z) * rot
        }
        if l.isLight { return T(x, y, z) }
        let sc = l.p("scale", lt)
        return T(x, y, z) * rot * simd_float4x4(diagonal: simd_float4(sc, sc, sc * (l.type == .MODEL ? l.p("scaleZ", lt) : 1), 1))
    }

    @objc private func tick() {
        guard let host = host else { return }
        let s = Editor.scene.layers.filter(is3dContent).map { "\($0.id)|\($0.type.rawValue)|\($0.imagePath ?? "")" }.joined(separator: ",") + "|\(R3D.g("vpPts", 1))|\(R3D.g("vpThresh", 0.06))"
        if s != sig { sig = s; rebuild() }
        if host.selId != lastHostSel {
            lastHostSel = host.selId
            if mode != .still { select(nodes[host.selId] != nil ? host.selId : -1, notifyHost: false) }
        }
        let t = Editor.time
        for l in Editor.scene.layers {
            guard let n = nodes[l.id] else { continue }
            n.isHidden = !syncScene || !l.visible || t < l.start || t > l.end || (vdbOverlayOK && isVdb(l))
            n.opacity = (vdbOverlayOK && !isVdb(l) && (l.type == .MODEL || is3dContent(l)) && l.type != .CAMERA && !l.isLight) ? 0.004 : 1
            n.simdTransform = xform(l, t)
        }
        tickN &+= 1
        if camMoving || tickN % 2 == 0 { updateVdbOverlay(t) }      // building the change-key is not free: 15 Hz when the camera is still
        updateScatter(t)
        updateParticles(t)
        updatePose(t)
        gridNode.isHidden = !showGrid || vdbOverlayOK
        updateGizmo()
        tl.isHidden = !showTimeline || fullscreen
        let dur = max(Editor.scene.duration, 0.1)
        timeLbl.text = String(format: "%.2f / %.1fs", t, dur)
        playBtn.setImage(Icons.sf( host.playing ? "pause.fill" : "play.fill"), for: .normal)
        cam.camera?.fieldOfView = CGFloat(R3D.g("vpFov", 50))
        if !tl.isHidden {
            if tabSeg.selectedSegmentIndex == 0 {
                canvas.rows = Editor.scene.layers.filter(is3dContent)
                canvas.selected = selected; canvas.time = t; canvas.dur = dur
                canvas.setNeedsDisplay()
            } else {
                let k = "\(tabSeg.selectedSegmentIndex)|\(scopeSeg.selectedSegmentIndex)|\(selected)|\(poseMode)|\(showBones)|\(selBone)|\(scLayer)|\(Editor.scene.layers.count)|\(Editor.scene.layers.map { "\($0.id)\($0.type.rawValue)" }.joined())"
                if k != propKey { propKey = k; rebuildProps() }
            }
        }
        for (id, m) in vdbMats { if let l = layer(id) { styleVdb(m, l) } }
        for l in Editor.scene.layers where l.isLight { if let n = nodes[l.id]?.childNodes.first { styleLight(n, l) } }
    }

    /// VDB through the main renderer (same ray-marcher / settings as the main viewport) with the orbit camera.
    private func updateVdbOverlay(_ t: Float) {
        let vl = Editor.scene.layers.filter { $0.type == .MODEL && $0.visible && t >= $0.start && t <= $0.end }
        guard syncScene, !vl.isEmpty, sv.bounds.width > 4 else { vdbView.image = nil; vdbOverlayOK = false; return }
        let ar = Float(sv.bounds.width / max(sv.bounds.height, 1))
        let e = cam.simdPosition
        let vp = MetalCam.lookAtEye(R3D.g("vpFov", 50), ar, e.x, e.y, e.z, -cPitch, cYaw, 0)
        let ovH = 540      // one fixed size: switching sizes re-allocates every render target (memory spikes, blank frames)
        // every other visible 3D layer goes along as an occluder (depth / silhouette only, never drawn twice)
        let occ = Editor.scene.layers.filter { is3dContent($0) && $0.type != .CAMERA && $0.type != .MODEL && $0.visible && t >= $0.start && t <= $0.end }
        var key: String = "H\(ovH)|" + vp.map { String(format: "%.4f", $0) }.joined(separator: ",") + "|\(t)|"
        for l in occ {
            var s: String = "\(l.id):\(l.p("x", t)),\(l.p("y", t)),\(l.p("z", t)),\(l.p("scale", t)),"
            s += "\(l.p("rotX", t)),\(l.p("rotY", t)),\(l.p("rotZ", t)),\(l.occlude),\(l.x3s),\(l.imagePath ?? "");"
            key += s
        }
        key += "|"
        for l in vl {
            var s: String = "\(l.id):\(l.vdbDens),\(l.vdbBright),\(l.vdbTint),\(l.vdbEnv),\(l.vdbSurround),"
            s += "\(l.xf("vdbOpacity", 1)),\(l.xf("vdbContrast", 1)),\(l.xf("vdbShadow", 1)),\(l.xf("vdbSteps", 56)),"
            s += "\(l.p("x", t)),\(l.p("y", t)),\(l.p("z", t)),\(l.p("scale", t)),\(l.p("scaleZ", t)),"
            s += "\(l.p("rotX", t)),\(l.p("rotY", t)),\(l.p("rotZ", t)),\(l.x3s),\(l.rtOn),\(l.rtInt),\(l.rtRad),\(l.imagePath ?? "");"
            key += s
        }
        key += "|\(R3D.g("rtAll", 0)),\(R3D.g("rtMul", 1)),\(R3D.g("exposure", 1)),\(R3D.g("light", 1)),\(R3D.g("env", 1)),\(GlobalEnv.path ?? ""),\(R3D.g("envRot", 0))|grid\(showGrid)|\(R3D.g("vdbDens", 1)),\(R3D.g("vdbBright", 1)),\(R3D.g("vdbQuality", 1))|"
        for l in Editor.scene.layers where l.isLight {
            var s: String = "\(l.id),\(l.visible),\(l.vdbTint),\(l.x3s),\(l.xf("lightInt", 1)),\(l.xf("lightInf", 1)),\(l.xf("lightType", 0)),\(l.xf("lightPitch", -60)),\(l.xf("lightYaw", 30)),"
            s += "\(l.p("x", t)),\(l.p("y", t)),\(l.p("z", t));"
            key += s
        }
        if key == vdbOvSig { return }
        if let img = MetalSceneRenderer.volumeOverlay(layers: occ + vl, vp: vp, time: t, quality: 2, size: (max(2, Int(Float(ovH) * ar)), ovH), full: true) {
            vdbOvSig = key
            vdbView.image = showGrid ? gridOverlay(img, vp) : img; vdbOverlayOK = true
        }
        else if vdbView.image == nil { vdbOverlayOK = false }      // Metal unavailable: point-cloud fallback stays
    }

    /// Draws the ground grid into the same frame (same view-projection) so it can never slide against the volume / models.
    private func gridOverlay(_ img: UIImage, _ vp: [Float]) -> UIImage {
        let W = img.size.width, H = img.size.height
        func clip(_ x: Float, _ z: Float) -> (Float, Float, Float, Float) {
            (vp[0] * x + vp[8] * z + vp[12], vp[1] * x + vp[9] * z + vp[13], vp[2] * x + vp[10] * z + vp[14], vp[3] * x + vp[11] * z + vp[15])
        }
        let r = UIGraphicsImageRenderer(size: img.size)
        return r.image { ctx in
            img.draw(at: .zero)
            let c = ctx.cgContext
            func line(_ a: (Float, Float), _ b: (Float, Float), _ col: UIColor, _ lw: CGFloat) {
                var p = clip(a.0, a.1), q = clip(b.0, b.1)
                let nearW: Float = 0.05
                if p.3 < nearW && q.3 < nearW { return }
                if p.3 < nearW { let t = (nearW - p.3) / (q.3 - p.3); p = (p.0 + (q.0 - p.0) * t, p.1 + (q.1 - p.1) * t, p.2, nearW) }
                if q.3 < nearW { let t = (nearW - q.3) / (p.3 - q.3); q = (q.0 + (p.0 - q.0) * t, q.1 + (p.1 - q.1) * t, q.2, nearW) }
                func pt(_ v: (Float, Float, Float, Float)) -> CGPoint { CGPoint(x: CGFloat(v.0 / v.3 * 0.5 + 0.5) * W, y: CGFloat(1 - (v.1 / v.3 * 0.5 + 0.5)) * H) }
                c.setStrokeColor(col.cgColor); c.setLineWidth(lw)
                c.move(to: pt(p)); c.addLine(to: pt(q)); c.strokePath()
            }
            let g = UIColor(white: 0.28, alpha: 1)
            for i in -10...10 where i != 0 {
                line((Float(i), -10), (Float(i), 10), g, 1); line((-10, Float(i)), (10, Float(i)), g, 1)
            }
            line((-10, 0), (10, 0), UIColor(red: 0.85, green: 0.25, blue: 0.25, alpha: 1), 1.5)
            line((0, -10), (0, 10), UIColor(red: 0.25, green: 0.5, blue: 0.95, alpha: 1), 1.5)
        }
    }

    private func updateGizmo() {
        let scattered = !(scInst[selected]?.isEmpty ?? true)      // original is hidden while its copies show
        guard mode != .still, showGizmo, let n = nodes[selected], !n.isHidden || scattered else { gizmo.isHidden = true; return }
        if poseMode, let sk = skels[selected], let h = holders[selected] {      // pose mode: the gizmo sits on the selected bone
            guard selBone >= 0, selBone < sk.bones.count else { gizmo.isHidden = true; return }
            let w = sk.world(), par = sk.bones[selBone].parent
            let frame = (par >= 0 && par < w.count ? w[par] : matrix_identity_float4x4) * sk.bones[selBone].restLocal
            let bp = w[selBone].columns.3
            let sp = h.convertPosition(SCNVector3(bp.x, bp.y, bp.z), to: nil)
            gizmo.isHidden = false; gizmo.simdPosition = simd_float3(sp.x, sp.y, sp.z)
            gizmo.simdWorldOrientation = Physics3D.rotQ(h.simdWorldTransform * frame)       // axes follow the bone
            gizmo.simdScale = simd_float3(repeating: max(simd_length(gizmo.simdPosition - cam.simdWorldPosition) * R3D.g("vpGizmo", 0.14), 0.05))
            return
        }
        gizmo.isHidden = false
        gizmo.simdOrientation = simd_quatf(ix: 0, iy: 0, iz: 0, r: 1)
        gizmo.simdPosition = n.simdWorldPosition
        let s = simd_length(gizmo.simdPosition - cam.simdWorldPosition) * R3D.g("vpGizmo", 0.14)
        gizmo.simdScale = simd_float3(repeating: max(s, 0.05))
    }

    // MARK: selection
    private func tint(_ n: SCNNode?, _ on: Bool) {
        n?.enumerateChildNodes { c, _ in
            c.geometry?.materials.forEach { $0.emission.contents = on ? UIColor(red: 0, green: 0.22, blue: 0.5, alpha: 1) : UIColor.black }
        }
    }

    private func select(_ id: Int, notifyHost: Bool = true) {
        tint(nodes[selected], false)
        selected = id
        if mode != .still { tint(nodes[id], true) }
        if notifyHost, id >= 0 { lastHostSel = id; host?.onSelect(id) }
    }

    private func pick(_ p: CGPoint) -> (Int, Int)? {
        let hits = sv.hitTest(p, options: [.searchMode: SCNHitTestSearchMode.all.rawValue])
        var axis = -1
        var lid: Int? = nil
        for h in hits {
            var n: SCNNode? = h.node
            while let c = n {
                if let nm = c.name {
                    if nm.hasPrefix("ax"), selected >= 0, axis < 0 { axis = Int(nm.dropFirst(2)) ?? -1 }
                    if nm.hasPrefix("L"), lid == nil, let i = Int(nm.dropFirst()) { lid = i }
                }
                n = c.parent
            }
        }
        if axis >= 0 && selected >= 0 { return (selected, axis) }
        if let l = lid { return (l, -1) }
        return nil
    }

    // MARK: camera + gestures
    /// Gestures only move the goal; camStep eases the drawn camera toward it every frame.
    private func applyCam(snap: Bool = false) {
        if snap { cYaw = yaw; cPitch = pitch; cDist = dist; cTarget = target; velYaw = 0; velPitch = 0; placeCam(); updateVdbOverlay(Editor.time) }
    }

    private func placeCam() {
        let cp = cosf(cPitch), sp = sinf(cPitch)
        cam.simdPosition = cTarget + cDist * simd_float3(cp * sinf(cYaw), sp, cp * cosf(cYaw))
        cam.simdLook(at: cTarget, up: simd_float3(0, 1, 0), localFront: simd_float3(0, 0, -1))
    }

    @objc private func camStep(_ l: CADisplayLink) {
        let dt = Float(min(max(l.duration, 1.0 / 120), 1.0 / 20))
        if !orbiting, abs(velYaw) + abs(velPitch) > 0.02 {        // inertia after a flick
            yaw += velYaw * dt; pitch = max(-1.5, min(1.5, pitch + velPitch * dt))
            let d = expf(-dt * 4.5); velYaw *= d; velPitch *= d
        }
        let k = 1 - expf(-dt * 22)
        let dy = yaw - cYaw, dp = pitch - cPitch, dd = dist - cDist, dt3 = target - cTarget
        let moving = abs(dy) > 5e-4 || abs(dp) > 5e-4 || abs(dd) > 2e-3 || simd_length(dt3) > 2e-3
        if moving {
            cYaw += dy * k; cPitch += dp * k; cDist += dd * k; cTarget += dt3 * k
            camMoving = true
            placeCam()
            let now = CACurrentMediaTime()
            if now - lastOverlayT >= 1.0 / 24 { lastOverlayT = now; updateVdbOverlay(Editor.time) }
        } else if camMoving {
            cYaw = yaw; cPitch = pitch; cDist = dist; cTarget = target
            camMoving = false
            placeCam(); updateVdbOverlay(Editor.time)      // settled: one full-quality picture
        }
    }

    private func installGestures() {
        let p1 = UIPanGestureRecognizer(target: self, action: #selector(pan1(_:))); p1.maximumNumberOfTouches = 1
        let p2 = UIPanGestureRecognizer(target: self, action: #selector(pan2(_:))); p2.minimumNumberOfTouches = 2; p2.maximumNumberOfTouches = 2
        let pc = UIPinchGestureRecognizer(target: self, action: #selector(pinch(_:)))
        let tp = UITapGestureRecognizer(target: self, action: #selector(tapped(_:)))
        let dt = UITapGestureRecognizer(target: self, action: #selector(doubleTapped(_:))); dt.numberOfTapsRequired = 2
        let p3 = UIPanGestureRecognizer(target: self, action: #selector(pan3(_:))); p3.minimumNumberOfTouches = 3; p3.maximumNumberOfTouches = 5
        tp.require(toFail: dt)
        for g in [p1, p2, p3, pc, tp, dt] { g.delegate = self; sv.addGestureRecognizer(g) }
    }

    func gestureRecognizer(_ a: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith b: UIGestureRecognizer) -> Bool { true }

    @objc private func pan1(_ g: UIPanGestureRecognizer) {
        switch g.state {
        case .began:
            drag = false; dragAxis = -1; velYaw = 0; velPitch = 0; orbiting = true
            if mode != .still {
                let p = g.location(in: sv), tr = g.translation(in: sv)
                if let h = pick(CGPoint(x: p.x - tr.x, y: p.y - tr.y)), h.1 >= 0 || (!poseMode && h.0 == selected) {
                    dragAxis = h.1; drag = true      // only gizmo handles / the selected object move; anything else orbits
                    dragPrev = CGPoint(x: p.x - tr.x, y: p.y - tr.y); dragCur = dragPrev; rotAcc = 0
                    highlightGizmo(dragAxis)
                    host?.pushUndo()
                }
            }
        case .changed:
            let d = g.translation(in: sv); g.setTranslation(.zero, in: sv)
            if drag { dragCur = g.location(in: sv); applyDrag(d); dragPrev = dragCur; showReadout() } else {
                let k = Float(0.0075 + 0.002 * min(dist, 20) / 20)
                yaw -= Float(d.x) * k
                pitch = max(-1.55, min(1.55, pitch + Float(d.y) * k))
            }
        default:
            orbiting = false
            if drag { drag = false; highlightGizmo(-1); updateModeUI(); host?.render(); host?.refreshPanel() }
            else if g.state == .ended { let v = g.velocity(in: sv); velYaw = -Float(v.x) * 0.008 * 0.6; velPitch = Float(v.y) * 0.008 * 0.6 }
        }
    }

    @objc private func pan2(_ g: UIPanGestureRecognizer) {
        guard g.state == .changed, g.numberOfTouches < 3 else { g.setTranslation(.zero, in: sv); return }
        let d = g.translation(in: sv); g.setTranslation(.zero, in: sv)
        let k = 2 * dist * tanf(Float(cam.camera?.fieldOfView ?? 50) * .pi / 360) / Float(max(sv.bounds.height, 1))
        target += (-cam.simdWorldRight * Float(d.x) + cam.simdWorldUp * Float(d.y)) * k
    }

    @objc private func pan3(_ g: UIPanGestureRecognizer) {      // 3 fingers: drag up / down to dolly fast
        if g.state == .began { g.setTranslation(.zero, in: sv); return }
        guard g.state == .changed else { return }
        let d = g.translation(in: sv); g.setTranslation(.zero, in: sv)
        dist = max(0.1, min(3000, dist * expf(Float(d.y) * 0.01)))
    }

    @objc private func pinch(_ g: UIPinchGestureRecognizer) {
        guard g.state == .changed, g.numberOfTouches < 3 else { g.scale = 1; return }
        dist = max(0.1, min(3000, dist / Float(max(g.scale, 0.01))))
        g.scale = 1
    }

    @objc private func tapped(_ g: UITapGestureRecognizer) {
        guard mode != .still else { return }
        if poseMode, skels[selected] != nil {
            if let b = pickBone(g.location(in: sv)) { selectBone(b); return }
        }
        if let h = pick(g.location(in: sv)) { select(h.0) } else { select(-1); host?.onSelect(-1) }
    }

    @objc private func doubleTapped(_ g: UITapGestureRecognizer) {      // double tap: fly to what you tapped (or back to the scene centre)
        if let h = pick(g.location(in: sv)) { select(h.0); frame(h.0) } else { target = .zero; dist = max(dist, 6) }
    }

    private func applyDrag(_ d: CGPoint) {
        guard let l = layer(selected), let n = nodes[selected] else { return }
        if poseMode, skels[selected] != nil { applyBoneDrag(d); return }
        let t = Editor.time, ak = host?.autoKeyOn ?? false
        if mode == .scale {
            let f = 1 - Float(d.y) * 0.006
            l.track("scale").set(t, max(0.01, l.p("scale", t) * f), ak)
            return
        }
        if mode == .rotate {
            // ring picked: rotate about that axis by the angle swept around the gizmo; centre / empty drag: free yaw + pitch
            func add(_ k: String, _ v: Float) { l.track(k).set(t, l.p(k, t) + v, ak) }
            let c = n.simdWorldPosition
            switch dragAxis {
            case 0: snapped(ringAngle(simd_float3(1, 0, 0), c)) { add("rotX", $0) }
            case 1: snapped(ringAngle(simd_float3(0, 1, 0), c)) { add("rotY", $0) }
            case 2: snapped(ringAngle(simd_float3(0, 0, 1), c)) { add("rotZ", $0) }
            default: add("rotY", Float(d.x) * 0.5); add("rotX", Float(d.y) * 0.5)
            }
            return
        }
        let pos = n.simdWorldPosition
        var dw = simd_float3(0, 0, 0)
        if (0...2).contains(dragAxis) {
            let dir = [simd_float3(1, 0, 0), simd_float3(0, 1, 0), simd_float3(0, 0, 1)][dragAxis]
            let a = sv.projectPoint(SCNVector3(pos)), b = sv.projectPoint(SCNVector3(pos + dir))
            let sx = CGFloat(b.x - a.x), sy = CGFloat(b.y - a.y)
            let den = Float(sx * sx + sy * sy)
            if den > 1e-4 { dw = dir * Float(d.x * sx + d.y * sy) / den }
        } else if (3...5).contains(dragAxis) {
            let nrm = [simd_float3(1, 0, 0), simd_float3(0, 1, 0), simd_float3(0, 0, 1)][dragAxis - 3]
            dw = planeDelta(pos, nrm) ?? .zero
        } else {
            let dd = simd_length(pos - cam.simdWorldPosition)
            let k = 2 * dd * tanf(Float(cam.camera?.fieldOfView ?? 50) * .pi / 360) / Float(max(sv.bounds.height, 1))
            dw = cam.simdWorldRight * Float(d.x) * k - cam.simdWorldUp * Float(d.y) * k
        }
        l.track("x").set(t, l.p("x", t) + dw.x, ak)
        l.track("y").set(t, l.p("y", t) + dw.y, ak)
        l.track("z").set(t, l.p("z", t) + dw.z, ak)
    }

    // MARK: UI
    private func sym(_ name: String, _ size: CGFloat = 20) -> UIImage? {
        Icons.sf( name, withConfiguration: UIImage.SymbolConfiguration(pointSize: size, weight: .regular))
    }

    private func btn(_ name: String, _ sel: Selector) -> UIButton {
        let b = UIButton(type: .custom)
        b.setImage(sym(name), for: .normal); b.tintColor = .white
        b.addTarget(self, action: sel, for: .touchUpInside)
        return b
    }

    private func buildUI() {
        // header
        let back = btn("chevron.left", #selector(close))
        let cube = UIImageView(image: sym("cube", 22)); cube.tintColor = .white
        let title = UILabel(); title.text = "Scene 3D"; title.textColor = .white; title.font = .systemFont(ofSize: 22, weight: .bold)
        let x = btn("xmark", #selector(close))
        header = UIStackView(arrangedSubviews: [back, cube, title, UIView(), x])
        header.spacing = 12; header.alignment = .center
        header.isLayoutMarginsRelativeArrangement = true
        header.layoutMargins = UIEdgeInsets(top: 0, left: 14, bottom: 0, right: 14)
        header.translatesAutoresizingMaskIntoConstraints = false
        addSubview(header)

        // viewport
        sv.scene = scn; sv.pointOfView = cam
        sv.backgroundColor = .black; sv.antialiasingMode = .multisampling4X
        sv.layer.cornerRadius = 22; sv.layer.masksToBounds = true
        sv.rendersContinuously = true
        vdbView.contentMode = .scaleToFill; vdbView.isUserInteractionEnabled = false
        vdbView.layer.compositingFilter = "screenBlendMode"     // volume frame is on black: screen = additive over the scene
        vdbView.translatesAutoresizingMaskIntoConstraints = false
        sv.addSubview(vdbView)
        NSLayoutConstraint.activate([vdbView.leadingAnchor.constraint(equalTo: sv.leadingAnchor), vdbView.trailingAnchor.constraint(equalTo: sv.trailingAnchor),
                                     vdbView.topAnchor.constraint(equalTo: sv.topAnchor), vdbView.bottomAnchor.constraint(equalTo: sv.bottomAnchor)])
        installGestures()

        // bottom bar: mode chip (left) + plus menu (right)
        chip.textColor = .white; chip.font = .systemFont(ofSize: 17)
        let bar = UIView(); barView = bar
        plus.setImage(sym("plus", 22), for: .normal); plus.tintColor = .white
        plus.backgroundColor = accent; plus.layer.cornerRadius = 14
        plus.showsMenuAsPrimaryAction = true
        plus.translatesAutoresizingMaskIntoConstraints = false; chip.translatesAutoresizingMaskIntoConstraints = false
        bar.addSubview(chip); bar.addSubview(plus)
        NSLayoutConstraint.activate([
            chip.leadingAnchor.constraint(equalTo: bar.leadingAnchor, constant: 8), chip.centerYAnchor.constraint(equalTo: bar.centerYAnchor),
            plus.trailingAnchor.constraint(equalTo: bar.trailingAnchor), plus.centerYAnchor.constraint(equalTo: bar.centerYAnchor),
            plus.widthAnchor.constraint(equalToConstant: 64), plus.heightAnchor.constraint(equalToConstant: 46),
            bar.heightAnchor.constraint(equalToConstant: 52)])

        // bottom panel: timeline or properties
        tabSeg.selectedSegmentIndex = 0
        tabSeg.addAction(UIAction { [weak self] _ in self?.tabChanged() }, for: .valueChanged)
        tabSeg.translatesAutoresizingMaskIntoConstraints = false
        bar.addSubview(tabSeg)
        NSLayoutConstraint.activate([tabSeg.centerXAnchor.constraint(equalTo: bar.centerXAnchor), tabSeg.centerYAnchor.constraint(equalTo: bar.centerYAnchor), tabSeg.widthAnchor.constraint(equalToConstant: 250)])
        chip.isHidden = true

        playBtn.tintColor = .white; playBtn.addTarget(self, action: #selector(playTap), for: .touchUpInside)
        let prev = btn("backward.end.fill", #selector(prevKey)), next = btn("forward.end.fill", #selector(nextKey))
        let key = btn("diamond", #selector(keyTap)); key.tintColor = accent
        let del = btn("diamond.fill", #selector(delKey)); del.tintColor = .systemRed
        timeLbl.textColor = .lightGray; timeLbl.font = .monospacedDigitSystemFont(ofSize: 13, weight: .medium)
        let row = UIStackView(arrangedSubviews: [playBtn, prev, next, UIView(), timeLbl, key, del])
        row.spacing = 18; row.alignment = .center
        canvas.onSeek = { [weak self] t in self?.host?.onSeek(t) }
        canvas.onSelect = { [weak self] id in self?.select(id) }
        canvas.backgroundColor = UIColor(white: 0.05, alpha: 1); canvas.layer.cornerRadius = 10; canvas.clipsToBounds = true
        let col = UIStackView(arrangedSubviews: [row, canvas]); col.axis = .vertical; col.spacing = 8
        col.translatesAutoresizingMaskIntoConstraints = false
        tlBox.addSubview(col); tlBox.translatesAutoresizingMaskIntoConstraints = false
        scopeSeg.selectedSegmentIndex = 0
        scopeSeg.addAction(UIAction { [weak self] _ in self?.propKey = "" }, for: .valueChanged)
        propStack.axis = .vertical; propStack.spacing = 10
        propStack.translatesAutoresizingMaskIntoConstraints = false; propScroll.translatesAutoresizingMaskIntoConstraints = false
        propScroll.addSubview(propStack); propScroll.isHidden = true
        scopeSeg.isHidden = true; scopeSeg.translatesAutoresizingMaskIntoConstraints = false
        tl.addSubview(tlBox); tl.addSubview(scopeSeg); tl.addSubview(propScroll)
        tl.backgroundColor = UIColor(white: 0.08, alpha: 1); tl.layer.cornerRadius = 16
        panelH = tl.heightAnchor.constraint(equalToConstant: 300)
        NSLayoutConstraint.activate([
            panelH,
            col.leadingAnchor.constraint(equalTo: tlBox.leadingAnchor), col.trailingAnchor.constraint(equalTo: tlBox.trailingAnchor),
            col.topAnchor.constraint(equalTo: tlBox.topAnchor), col.bottomAnchor.constraint(equalTo: tlBox.bottomAnchor),
            tlBox.leadingAnchor.constraint(equalTo: tl.leadingAnchor, constant: 12), tlBox.trailingAnchor.constraint(equalTo: tl.trailingAnchor, constant: -12),
            tlBox.topAnchor.constraint(equalTo: tl.topAnchor, constant: 10), tlBox.bottomAnchor.constraint(equalTo: tl.bottomAnchor, constant: -10),
            scopeSeg.topAnchor.constraint(equalTo: tl.topAnchor, constant: 10), scopeSeg.centerXAnchor.constraint(equalTo: tl.centerXAnchor), scopeSeg.widthAnchor.constraint(equalToConstant: 270),
            propScroll.topAnchor.constraint(equalTo: scopeSeg.bottomAnchor, constant: 8), propScroll.bottomAnchor.constraint(equalTo: tl.bottomAnchor),
            propScroll.leadingAnchor.constraint(equalTo: tl.leadingAnchor), propScroll.trailingAnchor.constraint(equalTo: tl.trailingAnchor),
            propStack.topAnchor.constraint(equalTo: propScroll.contentLayoutGuide.topAnchor), propStack.bottomAnchor.constraint(equalTo: propScroll.contentLayoutGuide.bottomAnchor, constant: -16),
            propStack.leadingAnchor.constraint(equalTo: propScroll.frameLayoutGuide.leadingAnchor, constant: 14), propStack.trailingAnchor.constraint(equalTo: propScroll.frameLayoutGuide.trailingAnchor, constant: -14),
            propStack.widthAnchor.constraint(equalTo: propScroll.frameLayoutGuide.widthAnchor, constant: -28)])

        // viewport corner buttons: fullscreen + frame selected
        let fs = btn("arrow.up.left.and.arrow.down.right", #selector(toggleFull)); fs.tag = 77
        let fr = btn("scope", #selector(frameSel))
        let corner = UIStackView(arrangedSubviews: [fs, fr]); corner.axis = .vertical; corner.spacing = 4
        corner.backgroundColor = UIColor(white: 0.1, alpha: 0.9); corner.layer.cornerRadius = 14
        for b in [fs, fr] { b.widthAnchor.constraint(equalToConstant: 44).isActive = true; b.heightAnchor.constraint(equalToConstant: 44).isActive = true }
        corner.translatesAutoresizingMaskIntoConstraints = false
        sv.addSubview(corner)
        NSLayoutConstraint.activate([corner.trailingAnchor.constraint(equalTo: sv.trailingAnchor, constant: -8), corner.topAnchor.constraint(equalTo: sv.topAnchor, constant: 12)])
        fsBtn = fs

        let stack = UIStackView(arrangedSubviews: [sv, bar, tl]); stack.axis = .vertical; stack.spacing = 8; mainStack = stack
        stackRef = stack
        stack.translatesAutoresizingMaskIntoConstraints = false
        addSubview(stack)

        // left mode toolbar over the viewport
        let icons = ["hand.raised", "arrow.up.and.down.and.arrow.left.and.right", "rotate.3d", "arrow.up.left.and.arrow.down.right", "figure.stand"]
        let tools = UIStackView(); tools.axis = .vertical; tools.spacing = 6
        tools.backgroundColor = UIColor(white: 0.1, alpha: 0.9); tools.layer.cornerRadius = 16
        tools.isLayoutMarginsRelativeArrangement = true; tools.layoutMargins = UIEdgeInsets(top: 6, left: 6, bottom: 6, right: 6)
        for (i, ic) in icons.enumerated() {
            let b = UIButton(type: .custom); b.setImage(sym(ic), for: .normal); b.tintColor = .white
            b.layer.cornerRadius = 12; b.tag = i
            b.addTarget(self, action: #selector(modeTap(_:)), for: .touchUpInside)
            b.widthAnchor.constraint(equalToConstant: 48).isActive = true
            b.heightAnchor.constraint(equalToConstant: 48).isActive = true
            tools.addArrangedSubview(b); modeBtns.append(b)
        }
        tools.translatesAutoresizingMaskIntoConstraints = false
        addSubview(tools)

        NSLayoutConstraint.activate([
            header.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor), headerH,
            header.leadingAnchor.constraint(equalTo: leadingAnchor), header.trailingAnchor.constraint(equalTo: trailingAnchor),
            stack.topAnchor.constraint(equalTo: header.bottomAnchor, constant: 4),
            stack.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 12), stack.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -12),
            stack.bottomAnchor.constraint(equalTo: safeAreaLayoutGuide.bottomAnchor, constant: -6),
            tools.leadingAnchor.constraint(equalTo: sv.leadingAnchor, constant: 8),
            tools.topAnchor.constraint(equalTo: sv.topAnchor, constant: 12)])
    }

    private func updateModeUI() {
        for (i, b) in modeBtns.enumerated() { b.backgroundColor = (i < 4 ? (i == mode.rawValue) : poseMode) ? accent : .clear }
        chip.text = mode == .still ? "Still  ·  view only" : (mode == .move ? "Edit Viewport  ·  Move" : (mode == .rotate ? "Edit Viewport  ·  Rotate" : "Edit Viewport  ·  Scale"))
        if poseMode { chip.text = poseChipText() }
        if mode == .still { tint(nodes[selected], false); gizmo.isHidden = true }
        else { tint(nodes[selected], true) }
        buildGizmo()
    }

    @objc private func modeTap(_ b: UIButton) {
        if b.tag == 4 { setPose(!poseMode); return }
        mode = Mode(rawValue: b.tag) ?? .move; updateModeUI()
    }

    fileprivate func setPose(_ on: Bool) {
        poseMode = on
        if on, mode == .still || mode == .scale { mode = .move }
        markBones(); propKey = ""; updateModeUI(); rebuildMenu()
    }

    private func rebuildMenu() {
        func item(_ title: String, _ img: String, _ on: Bool?, _ h: @escaping () -> Void) -> UIAction {
            UIAction(title: title, image: Icons.sf( img), state: on == true ? .on : .off) { _ in h() }
        }
        plus.menu = UIMenu(children: [
            item("Import Model", "square.and.arrow.down", nil) { [weak self] in self?.host?.pickFile(R_GLB, glbTypes()) },
            item("Import MikuMikuDance", "person.fill", nil) { [weak self] in self?.host?.pickFile(R_GLB, mmdTypes()) },
            item("Import VRM", "person.fill", nil) { [weak self] in self?.host?.pickFile(R_GLB, vrmTypes()) },
            item("Simulations", "cloud.sun", nil) { [weak self] in
                guard let self = self, let h = self.host else { return }
                SimulationsPanel.present(in: h, over: self)
            },
            item("Extras", "square.stack.3d.up", nil) { [weak self] in
                guard let self = self, let h = self.host else { return }
                ExtrasPanel.present(in: h, over: self)
            },
            item("Terrain", "mountain.2", nil) { [weak self] in
                guard let self = self, let h = self.host else { return }
                TerrainPanel.present(in: h, over: self)
            },
            item("Environment", "sun.max", nil) { [weak self] in
                guard let self = self, let h = self.host else { return }
                EnvPanel.present(in: h, over: self)
            },
            item("Lighting", "lightbulb", nil) { [weak self] in
                guard let self = self, let h = self.host else { return }
                LightPanel.present(in: h, over: self)
            },
            item("3D Scene", "cube.transparent", syncScene) { [weak self] in self?.syncScene.toggle(); self?.rebuildMenu() },
            item("Grid", "grid", showGrid) { [weak self] in self?.showGrid.toggle(); self?.rebuildMenu() },
            item("Timeline", "timeline.selection", showTimeline) { [weak self] in self?.showTimeline.toggle(); self?.rebuildMenu() },
            item("Show Bones", "bone", showBones) { [weak self] in self?.showBones.toggle(); self?.markBones(); self?.propKey = ""; self?.rebuildMenu() },
            item("Pose Mode", "figure.stand", poseMode) { [weak self] in self?.setPose(!(self?.poseMode ?? false)) },
            item("Snap rotation (5 deg)", "grid", snapOn) { [weak self] in self?.snapOn.toggle(); self?.rotAcc = 0; self?.rebuildMenu() },
            item("Gizmo", "move.3d", showGizmo) { [weak self] in self?.showGizmo.toggle(); self?.rebuildMenu() }
        ])
    }

    // MARK: timeline actions (drive the main editor's playhead)
    @objc private func playTap() { host?.togglePlay() }

    private func keyTimes(_ l: Layer) -> [Float] {
        var ts = Set<Float>()
        for k in ["x", "y", "z", "scale", "rotX", "rotY", "rotZ", "fov"] { for key in l.track(k).keys { ts.insert((key.t * 1000).rounded() / 1000) } }
        return ts.sorted()
    }
    @objc private func prevKey() {
        let t = Editor.time
        if let l = layer(selected), let k = keyTimes(l).last(where: { $0 < t - 0.01 }) { host?.onSeek(k) } else { host?.onSeek(max(0, t - 1 / 30)) }
    }
    @objc private func nextKey() {
        let t = Editor.time
        if let l = layer(selected), let k = keyTimes(l).first(where: { $0 > t + 0.01 }) { host?.onSeek(k) } else { host?.onSeek(min(Editor.scene.duration, t + 1 / 30)) }
    }

    /// Diamond: key the selected layer's position + scale + rotation at the playhead.
    @objc private func keyTap() {
        guard mode != .still, let l = layer(selected) else { return }
        host?.pushUndo()
        let t = Editor.time
        let ks = l.type == .CAMERA ? ["x", "y", "z", "rotX", "rotY", "rotZ", "fov"] 
            : ["x", "y", "z", "scale", "rotX", "rotY", "rotZ"] + (l.type == .MODEL ? ["scaleZ"] : [])
        for k in ks { l.track(k).set(t, l.p(k, t), true) }
        host?.render(); host?.refreshPanel()
    }
    @objc private func delKey() {
        guard let l = layer(selected) else { return }
        host?.pushUndo()
        let t = Editor.time
        for k in ["x", "y", "z", "scale", "rotX", "rotY", "rotZ", "fov"] { l.track(k).keys.removeAll { abs($0.t - t) < 0.03 } }
        host?.render(); host?.refreshPanel()
    }

    // MARK: fullscreen / panel
    @objc private func toggleFull() {
        fullscreen.toggle()
        header.isHidden = fullscreen; headerH.constant = fullscreen ? 0 : 52
        sv.layer.cornerRadius = fullscreen ? 0 : 22
        fsBtn?.setImage(sym(fullscreen ? "arrow.down.right.and.arrow.up.left" : "arrow.up.left.and.arrow.down.right"), for: .normal)
        UIView.animate(withDuration: 0.2) { self.layoutIfNeeded() }
    }
    @objc private func frameSel() { frame(selected >= 0 ? selected : (nodes.keys.first ?? -1)) }

    private func tabChanged() {
        let i = tabSeg.selectedSegmentIndex, p = i != 0
        tlBox.isHidden = p; propScroll.isHidden = !p; scopeSeg.isHidden = i != 1
        propKey = ""
    }
}

// MARK: - Properties panel (Layer / Global)

extension Scene3DView {

    fileprivate func rebuildProps() {
        propStack.arrangedSubviews.forEach { propStack.removeArrangedSubview($0); $0.removeFromSuperview() }
        if tabSeg.selectedSegmentIndex == 2 { scatterProps(); return }
        if scopeSeg.selectedSegmentIndex == 1 { globalProps(); return }
        if scopeSeg.selectedSegmentIndex == 2 { bonesProps(); return }
        guard let l = layer(selected) else { add(note("Select a 3D layer (tap it in Move / Scale mode, or in the timeline).")); return }
        let t = Editor.time
        let vdb = isVdbLayer(l)
        add(head("\(l.name)  ·  \(vdb ? "VDB volume" : l.type.rawValue.capitalized)"))
        add(sw("Visible", l.visible) { [weak self] v in self?.host?.pushUndo(); l.visible = v; self?.host?.render() })
        if l.type == .MODEL {
            add(sbtn("Scatter in air (one tap)") { [weak self] in
                self?.host?.pushUndo(); l.xset("scList", 1); l.xset("scTarget", -3); l.xset("scOn", 1)
                if l.xf("scCount", 0) == 0 { l.xset("scCount", 30) }
                self?.host?.render(); self?.propKey = ""; self?.rebuildProps()
            })
            let listed = l.xf("scList", 0) > 0.5
            add(sbtn(listed ? "Remove from scatter list" : "Add to scatter list") { [weak self] in
                self?.host?.pushUndo(); l.xset("scList", listed ? 0 : 1)
                if !listed { self?.scLayer = -1 }
                self?.propKey = ""; self?.rebuildProps()
            })
        }

        if l.isLight { lightProps(l) }
        if !l.tgraph.isEmpty, let g = TGraph.from(json: l.tgraph) {
            add(head("Terrain"))
            add(btnRow("Edit node") { [weak self] in
                guard let self = self, let h = self.host else { return }
                TerrainNodeEditor.present(in: h, over: self, graph: g, layer: l, parent: nil)
            })
        }
        add(head("Transform"))
        let ak = { [weak self] in self?.host?.autoKeyOn ?? false }
        func tr(_ n: String, _ k: String, _ lo: Float, _ hi: Float) {
            add(sl(n, lo, hi, l.p(k, t)) { l.track(k).set(Editor.time, $0, ak()) })
        }
        func zRow() {
            // signed log slider: Z is effectively unbounded (±100000)
            let z = l.p("z", t)
            let v = (z < 0 ? -1 : 1) * log10(1 + abs(z) * 10)
            add(sl("Position Z (unbounded)", -6, 6, v) { l.track("z").set(Editor.time, ($0 < 0 ? -1 : 1) * (powf(10, abs($0)) - 1) / 10, ak()) })
        }
        tr("Position X", "x", -4, 4); tr("Position Y", "y", -4, 4); zRow()
        if l.type != .CAMERA && !l.isLight {
            // log slider: 0.01 ... 100000 (the on-screen drag and the main editor are unbounded too)
            func logRow(_ n: String, _ k: String) {
                let cur = max(abs(l.p(k, t)), 0.01)
                add(sl(n, 0, 7, log10(cur / 0.01), "%.2f") { l.track(k).set(Editor.time, 0.01 * powf(10, $0), ak()) })
            }
            logRow("Scale (log, 0.01 – 100000)", "scale")
            if l.type == .MODEL { logRow("Scale Z / depth (log)", "scaleZ") }
        }
        tr("Rotate X", "rotX", -180, 180); tr("Rotate Y", "rotY", -180, 180); tr("Rotate Z", "rotZ", -180, 180)
        if l.type == .CAMERA { tr("Field of view", "fov", 10, 150) }

        add(head("Timing"))
        let dur = max(Editor.scene.duration, 1)
        add(sl("Start (s)", 0, dur, l.start) { l.start = min($0, l.end - 0.05) })
        add(sl("End (s)", 0, dur, l.end) { l.end = max($0, l.start + 0.05) })

        if l.type == .MODEL && !vdb {
            add(head("Material & light"))
            add(seg("View", ["Final", "Base", "Rough", "Metal", "Occl", "Emis"], l.m3View) { [weak self] i in self?.host?.pushUndo(); l.m3View = i; self?.host?.render() })
            add(sw("Environment light", l.m3Env) { [weak self] v in self?.host?.pushUndo(); l.m3Env = v; self?.host?.render() })
            add(sw("Metallic reflectivity", l.m3Metal) { [weak self] v in self?.host?.pushUndo(); l.m3Metal = v; self?.host?.render() })
            add(sw("Ambient occlusion texture", l.m3Ao) { [weak self] v in self?.host?.pushUndo(); l.m3Ao = v; self?.host?.render() })
            add(sw("Occluded by other models", l.occlude) { [weak self] v in self?.host?.pushUndo(); l.occlude = v; self?.host?.render() })
            add(sl("Light intensity", 0, 3, l.xf("light", 1)) { l.xset("light", $0) })
            add(sl("Environment intensity", 0, 3, l.xf("env", 1)) { l.xset("env", $0) })
            add(sl("Exposure", 0.2, 3, l.xf("exposure", 1)) { l.xset("exposure", $0) })
        }
        if vdb {
            add(head("VDB volume"))
            add(sl("Density", 0, 5, l.vdbDens) { l.vdbDens = $0 })
            add(sl("Brightness", 0, 5, l.vdbBright) { l.vdbBright = $0 })
            add(sl("Opacity", 0, 1, l.xf("vdbOpacity", 1)) { l.xset("vdbOpacity", $0) })
            add(sl("Contrast", 0.2, 3, l.xf("vdbContrast", 1)) { l.xset("vdbContrast", $0) })
            add(sl("Self-shadow", 0, 2, l.xf("vdbShadow", 1)) { l.xset("vdbShadow", $0) })
            add(sl("Quality (ray steps)", 16, 160, l.xf("vdbSteps", 56), "%.0f") { l.xset("vdbSteps", $0) })
            add(colorRow("Tint", l.vdbTint) { l.vdbTint = $0 })
            add(sw("Environment lighting", l.vdbEnv) { [weak self] v in self?.host?.pushUndo(); l.vdbEnv = v; self?.host?.render() })
            add(sw("Light from surrounding scene", l.vdbSurround) { [weak self] v in self?.host?.pushUndo(); l.vdbSurround = v; self?.host?.render() })
            if let p = l.vdbEnvPath, !p.isEmpty {
                add(btnRow("Remove environment image (\((p as NSString).lastPathComponent))") { [weak self] in l.vdbEnvPath = nil; self?.host?.render(); self?.propKey = "" })
            }
        }
        if (l.type == .MODEL || l.type == .CAMERA || l.is3d) && !l.isLight {
            add(head("Ray tracing"))
            add(sw("Ray tracing", l.rtOn) { [weak self] v in self?.host?.pushUndo(); l.rtOn = v; self?.host?.render(); self?.propKey = "" })
            if l.rtOn { rtRows(l) }
        }
    }

    private func lightProps(_ l: Layer) {
        let type = Int(l.xf("lightType", 0))
        add(head("Light"))
        add(seg("Type", Lights.types, type) { [weak self] i in
            self?.host?.pushUndo(); l.xset("lightType", Float(i)); self?.host?.render(); self?.propKey = ""; self?.rebuildProps()
        })
        add(note(type == 1 ? "Sun: parallel light from one direction, position does not matter." : type == 2 ? "Spot: a cone of light from the ball, aimed with Pitch / Yaw." : "Point: light in every direction from the ball."))
        add(colorRow("Light color", l.vdbTint) { l.vdbTint = $0 })
        add(sl("Temperature (K): warm to cool", 1500, 12000, l.xf("lightTemp", 6500), "%.0f") { l.xset("lightTemp", $0) })
        add(sw("Infinite reach", Lights.infinite(l)) { [weak self] v in self?.host?.pushUndo(); l.xset("lightInf", v ? 1 : 0); self?.host?.render(); self?.propKey = ""; self?.rebuildProps() })
        add(sl("Intensity (up to 10000)", 0, 10000, l.xf("lightInt", 1), "%.0f") { l.xset("lightInt", $0) })
        if type != 1 && !Lights.infinite(l) {
            add(sl("Range (0 = unlimited)", 0, 30, l.xf("lightRange", 0), "%.1f") { l.xset("lightRange", $0) })
            add(sl("Ball size", 0.05, 4, l.xf("lightRad", 0.5)) { l.xset("lightRad", $0) })
        }
        if type != 0 {
            add(sl("Pitch (down to up)", -90, 90, l.xf("lightPitch", -60), "%.0f") { l.xset("lightPitch", $0) })
            add(sl("Yaw (turn)", -180, 180, l.xf("lightYaw", 30), "%.0f") { l.xset("lightYaw", $0) })
        }
        if type == 2 {
            add(sl("Cone angle", 5, 89, l.xf("lightCone", 45), "%.0f") { l.xset("lightCone", $0) })
            add(sl("Edge softness", 0, 1, l.xf("lightSoft", 0.3)) { l.xset("lightSoft", $0) })
        }
        add(head("Surface response"))
        add(sl("Diffuse strength", 0, 2, l.xf("lightDiff", 1)) { l.xset("lightDiff", $0) })
        add(sl("Specular strength (highlights)", 0, 4, l.xf("lightSpec", 1)) { l.xset("lightSpec", $0) })
        add(head("Volumes (VDB / clouds)"))
        let ac = UInt32(l.xf("atmCol", Float(0x6688FF)))
        add(colorRow("Atmosphere color", Int32(bitPattern: 0xFF000000 | ac)) { l.xset("atmCol", Float(UInt32(bitPattern: $0) & 0xFFFFFF)) })
        add(sl("Atmosphere amount", 0, 2, l.xf("atmAmt", 0.3)) { l.xset("atmAmt", $0) })
        add(note("Up to 8 lights light models and PBR materials. Volumes use point lights only."))
    }

    private func rtRows(_ l: Layer) {
        add(sl("Intensity (master)", 0, 1, l.rtInt) { l.rtInt = $0 })
        add(sl("Shadow strength", 0, 1, l.xf("rtShadow", 1)) { l.xset("rtShadow", $0) })
        add(sl("Ambient occlusion strength", 0, 1, l.xf("rtAo", 1)) { l.xset("rtAo", $0) })
        add(sl("Occlusion radius", 0.05, 2, l.rtRad) { l.rtRad = $0 })
        rtStatusRow()
    }

    private func rtStatusRow() {
        let st = MetalModelRenderer.rtStatus
        add(note(st.isEmpty ? "Ray tracing ready (traced shadows + ambient occlusion on models, via Metal)." : st, st.isEmpty ? .gray : .systemRed))
    }

    private func globalProps() {
        add(head("Viewport"))
        add(sw("Grid", showGrid) { [weak self] v in self?.showGrid = v; self?.rebuildMenu() })
        add(sw("Gizmo", showGizmo) { [weak self] v in self?.showGizmo = v; self?.rebuildMenu() })
        add(sw("Show 3D scene", syncScene) { [weak self] v in self?.syncScene = v; self?.rebuildMenu() })
        add(sl("Viewport field of view", 20, 90, R3D.g("vpFov", 50), "%.0f") { R3D.set("vpFov", $0) })
        add(sl("Gizmo size", 0.05, 0.3, R3D.g("vpGizmo", 0.14)) { R3D.set("vpGizmo", $0) })
        add(sl("Background", 0, 0.4, R3D.g("vpBg", 0)) { [weak self] v in R3D.set("vpBg", v); self?.scn.background.contents = UIColor(white: CGFloat(v), alpha: 1) })
        add(sl("VDB preview density cut", 0.01, 0.5, R3D.g("vpThresh", 0.06)) { R3D.set("vpThresh", $0) })
        add(sl("VDB preview point budget", 0.2, 3, R3D.g("vpPts", 1)) { R3D.set("vpPts", $0) })

        add(head("Rendering (all layers)"))
        add(sl("Exposure", 0.2, 3, R3D.g("exposure", 1)) { R3D.set("exposure", $0) })
        add(sl("Light intensity", 0, 3, R3D.g("light", 1)) { R3D.set("light", $0) })
        add(sl("Environment intensity", 0, 3, R3D.g("env", 1)) { R3D.set("env", $0) })
        add(sw("Ray trace every model", R3D.g("rtAll", 0) > 0.5) { [weak self] v in R3D.set("rtAll", v ? 1 : 0); self?.host?.render() })
        add(sl("Ray tracing intensity (global)", 0, 1, R3D.g("rtMul", 1)) { R3D.set("rtMul", $0) })
        rtStatusRow()

        add(head("VDB (all volumes)"))
        add(sl("Density ×", 0, 3, R3D.g("vdbDens", 1)) { R3D.set("vdbDens", $0) })
        add(sl("Brightness ×", 0, 3, R3D.g("vdbBright", 1)) { R3D.set("vdbBright", $0) })
        add(sl("Quality ×", 0.4, 2.5, R3D.g("vdbQuality", 1)) { R3D.set("vdbQuality", $0) })
        add(btnRow("Reset global settings") { [weak self] in
            for k in ["vpFov", "vpGizmo", "vpBg", "vpThresh", "vpPts", "exposure", "light", "env", "rtAll", "rtMul", "vdbDens", "vdbBright", "vdbQuality"] { UserDefaults.standard.removeObject(forKey: "r3d." + k) }
            self?.propKey = ""; self?.host?.render()
        })
    }

    fileprivate func isVdbLayer(_ l: Layer) -> Bool { (l.imagePath ?? "").lowercased().hasSuffix(".vdb") }

    // ---- row builders
    private func add(_ v: UIView) { propStack.addArrangedSubview(v) }

    private func head(_ t: String) -> UIView {
        let l = UILabel(); l.text = t.uppercased(); l.font = .systemFont(ofSize: 12, weight: .bold)
        l.textColor = UIColor(red: 1, green: 0.55, blue: 0.08, alpha: 1); return l
    }
    private func note(_ t: String, _ c: UIColor = .gray) -> UIView {
        let l = UILabel(); l.text = t; l.font = .systemFont(ofSize: 12); l.textColor = c; l.numberOfLines = 0; return l
    }
    private func sw(_ t: String, _ on: Bool, _ f: @escaping (Bool) -> Void) -> UIView {
        let l = UILabel(); l.text = t; l.textColor = .white; l.font = .systemFont(ofSize: 15)
        let s = FlatSwitch(on)
        s.addAction(UIAction { _ in f(s.isOn) }, for: .valueChanged)
        let r = UIStackView(arrangedSubviews: [l, s]); r.alignment = .center; return r
    }
    private func sl(_ t: String, _ lo: Float, _ hi: Float, _ v: Float, _ fmt: String = "%.2f", _ f: @escaping (Float) -> Void) -> UIView {
        FlatSlider(t, lo, hi, v, step: (hi - lo) / 100, fmt: fmt, def: min(max(0, lo), hi),
                   onBegin: { [weak self] in self?.host?.pushUndo() }, onChange: f,
                   onEnd: { [weak self] in self?.host?.render(); self?.host?.refreshPanel() })
    }
    private func seg(_ t: String, _ items: [String], _ sel: Int, _ f: @escaping (Int) -> Void) -> UIView {
        let s = FlatSegment(items, sel)
        s.addAction(UIAction { _ in f(s.selectedSegmentIndex) }, for: .valueChanged); return s
    }
    private func colorRow(_ t: String, _ argb: Int32, _ f: @escaping (Int32) -> Void) -> UIView {
        let l = UILabel(); l.text = t; l.textColor = .white; l.font = .systemFont(ofSize: 15)
        let c = UInt32(bitPattern: argb)
        let w = UIColorWell(); w.supportsAlpha = false
        w.selectedColor = UIColor(red: CGFloat((c >> 16) & 255) / 255, green: CGFloat((c >> 8) & 255) / 255, blue: CGFloat(c & 255) / 255, alpha: 1)
        w.addAction(UIAction { [weak self, weak w] _ in
            guard let col = w?.selectedColor else { return }
            var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0; col.getRed(&r, green: &g, blue: &b, alpha: &a)
            self?.host?.pushUndo()
            f(Int32(bitPattern: 0xFF000000 | UInt32(r * 255) << 16 | UInt32(g * 255) << 8 | UInt32(b * 255))); self?.host?.render()
        }, for: .valueChanged)
        let r = UIStackView(arrangedSubviews: [l, w]); r.alignment = .center; return r
    }
    private func btnRow(_ t: String, _ f: @escaping () -> Void) -> UIView {
        let b = FlatButton(t); b.onTap = f; return b
    }
}

// MARK: - Timeline canvas (ruler, one row per 3D layer, keyframe diamonds, playhead)

final class TLCanvas: UIView {
    var rows: [Layer] = []
    var selected = -1
    var time: Float = 0
    var dur: Float = 5
    var onSeek: ((Float) -> Void)?
    var onSelect: ((Int) -> Void)?
    private var pps: CGFloat = 70           // pixels per second
    private var offX: CGFloat = 0, offY: CGFloat = 0
    private var scrub = false
    private let rowH: CGFloat = 32, top: CGFloat = 26
    private let orange = UIColor(red: 1, green: 0.55, blue: 0.08, alpha: 1)

    override init(frame: CGRect) {
        super.init(frame: frame)
        addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(pan(_:))))
        addGestureRecognizer(UIPinchGestureRecognizer(target: self, action: #selector(pinch(_:))))
        addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(tap(_:))))
        contentMode = .redraw
    }
    required init?(coder: NSCoder) { fatalError() }

    private func tx(_ t: Float) -> CGFloat { CGFloat(t) * pps - offX + 8 }
    private func tt(_ x: CGFloat) -> Float { Float(max(0, min(CGFloat(dur), (x + offX - 8) / pps))) }

    @objc private func pan(_ g: UIPanGestureRecognizer) {
        if g.state == .began { scrub = (g.location(in: self).y - g.translation(in: self).y) < top }
        let d = g.translation(in: self); g.setTranslation(.zero, in: self)
        if scrub { onSeek?(tt(g.location(in: self).x)) }
        else {
            offX = max(0, min(offX - d.x, max(0, CGFloat(dur) * pps - bounds.width + 40)))
            offY = max(0, min(offY - d.y, max(0, CGFloat(rows.count) * rowH - (bounds.height - top))))
            setNeedsDisplay()
        }
    }
    @objc private func pinch(_ g: UIPinchGestureRecognizer) {
        guard g.state == .changed else { return }
        pps = max(20, min(400, pps * g.scale)); g.scale = 1; setNeedsDisplay()
    }
    @objc private func tap(_ g: UITapGestureRecognizer) {
        let p = g.location(in: self)
        if p.y < top { onSeek?(tt(p.x)); return }
        let i = Int((p.y - top + offY) / rowH)
        if i >= 0 && i < rows.count { onSelect?(rows[i].id) } else { onSelect?(-1) }
    }

    override func draw(_ r: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let attr: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 11, weight: .medium), .foregroundColor: UIColor.white]
        let dim: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 10), .foregroundColor: UIColor.gray]
        // rows
        c.saveGState(); c.clip(to: CGRect(x: 0, y: top, width: bounds.width, height: bounds.height - top))
        if rows.isEmpty { ("No 3D layers yet. Use + > Import Model" as NSString).draw(at: CGPoint(x: 12, y: top + 12), withAttributes: dim) }
        for (i, l) in rows.enumerated() {
            let y = top + CGFloat(i) * rowH - offY
            if y + rowH < top || y > bounds.height { continue }
            if i % 2 == 0 { UIColor(white: 1, alpha: 0.03).setFill(); c.fill(CGRect(x: 0, y: y, width: bounds.width, height: rowH)) }
            let x0 = tx(l.start), x1 = tx(l.end)
            let bar = CGRect(x: x0, y: y + 4, width: max(6, x1 - x0), height: rowH - 8)
            (l.id == selected ? orange : orange.withAlphaComponent(0.35)).setFill()
            UIBezierPath(roundedRect: bar, cornerRadius: 6).fill()
            (l.name as NSString).draw(at: CGPoint(x: max(bar.minX, 0) + 6, y: y + 9), withAttributes: attr)
            var ts = Set<Float>()
            for k in ["x", "y", "z", "scale", "rotX", "rotY", "rotZ", "fov"] { for key in l.track(k).keys { ts.insert((key.t * 1000).rounded() / 1000) } }
            UIColor.white.setFill()
            for t in ts {
                let x = tx(t), my = y + rowH / 2
                let d = UIBezierPath(); d.move(to: CGPoint(x: x, y: my - 6)); d.addLine(to: CGPoint(x: x + 5, y: my))
                d.addLine(to: CGPoint(x: x, y: my + 6)); d.addLine(to: CGPoint(x: x - 5, y: my)); d.close(); d.fill()
            }
        }
        c.restoreGState()
        // ruler
        UIColor(white: 0.11, alpha: 1).setFill(); c.fill(CGRect(x: 0, y: 0, width: bounds.width, height: top))
        let stepT: Float = pps > 140 ? 0.5 : (pps > 40 ? 1 : 5)
        var t: Float = 0
        while t <= dur + 0.001 {
            let x = tx(t)
            if x > -30 && x < bounds.width + 30 {
                UIColor.gray.setFill(); c.fill(CGRect(x: x, y: top - 8, width: 1, height: 8))
                (String(format: stepT < 1 ? "%.1f" : "%.0f", t) as NSString).draw(at: CGPoint(x: x + 3, y: 5), withAttributes: dim)
            }
            t += stepT
        }
        // end-of-timeline marker
        UIColor(white: 0, alpha: 0.5).setFill(); c.fill(CGRect(x: tx(dur), y: top, width: max(0, bounds.width - tx(dur)), height: bounds.height))
        // playhead
        let px = tx(time)
        orange.setFill(); c.fill(CGRect(x: px - 1, y: 0, width: 2, height: bounds.height))
        let head = UIBezierPath(roundedRect: CGRect(x: px - 9, y: 2, width: 18, height: 16), cornerRadius: 5); orange.setFill(); head.fill()
    }
}

// MARK: - Scatter tab

extension Scene3DView {

    fileprivate func scatterProps() {
        let objs = Editor.scene.layers.filter { $0.type == .MODEL && $0.xf("scList", 0) > 0.5 }
        guard let l = layer(scLayer), objs.contains(where: { $0 === l }) else {
            scLayer = -1
            sadd(shead("Scatter list"))
            if objs.isEmpty {
                sadd(sbtn("Open full-screen Scatter editor") { [weak self] in if let h = self?.host { ScatterEditor.present(in: h, over: h.view, select: -1) } })
                sadd(snote("No scatter objects yet. Select a 3D model, open Properties and tap \"Add to scatter list\"."))
            } else {
                sadd(sbtn("Open full-screen Scatter editor") { [weak self] in if let h = self?.host { ScatterEditor.present(in: h, over: h.view, select: objs[0].id) } })
                sadd(snote("Tap an object to open its scatter panel."))
                for o in objs {
                    sadd(sbtn(o.name + (o.xf("scOn", 0) > 0.5 ? "  ·  on" : "")) { [weak self] in self?.scLayer = o.id; self?.propKey = ""; self?.rebuildProps() })
                }
            }
            return
        }
        sadd(sbtn("Open full-screen Scatter editor") { [weak self] in if let h = self?.host { ScatterEditor.present(in: h, over: h.view, select: l.id) } })
        sadd(sbtn("‹ Scatter list") { [weak self] in self?.scLayer = -1; self?.propKey = ""; self?.rebuildProps() })
        sadd(shead("Scatter · \(l.name)"))
        sadd(snote("Copies this model over the surface of a target (a model, or a media layer with the 3D cube on). Pick the target, then tune it. It renders in the final video too."))
        sadd(sbtn("Remove from scatter list") { [weak self] in
            self?.host?.pushUndo(); l.xset("scList", 0); l.xset("scOn", 0); self?.host?.render()
            self?.scLayer = -1; self?.propKey = ""; self?.rebuildProps()
        })
        let tgts = Editor.scene.layers.filter { is3dContent($0) && $0.id != l.id && !isVdbLayer($0) }
        let cur = layer(Int(l.xf("scTarget", -1)))
        let tv = Int(l.xf("scTarget", -1))
        let curName = tv == -2 ? "Ground plane" : tv == -3 ? "Air (random volume)" : (cur?.name ?? "None")
        sadd(picker("Target surface", curName, [("Ground plane", -2), ("Air (random volume)", -3)] + tgts.map { ($0.name, $0.id) }) { [weak self] id in
            self?.host?.pushUndo(); l.xset("scTarget", Float(id)); l.xset("scOn", 1); self?.host?.render(); self?.propKey = ""
        })
        if let s = layer(selected), s.id != l.id {
            sadd(sbtn("Use selected layer (\(s.name)) as target") { [weak self] in
                self?.host?.pushUndo(); l.xset("scTarget", Float(s.id)); l.xset("scOn", 1); self?.host?.render(); self?.propKey = ""
            })
        }
        if tv == -2 || tv == -3 {
            if tv == -3 { sadd(ssl("Air height", 0.5, 30, l.xf("scAirH", 4), "%.1f") { l.xset("scAirH", $0) }) }
            sadd(ssl("Ground size", 1, 60, l.xf("scGroundSize", 10), "%.0f") { l.xset("scGroundSize", $0) })
            sadd(ssl(tv == -3 ? "Air centre height" : "Ground height", -5, 5, l.xf("scGroundY", 0), "%.2f") { l.xset("scGroundY", $0) })
        }
        sadd(ssw("Scatter on", l.xf("scOn", 0) > 0.5) { [weak self] v in self?.host?.pushUndo(); l.xset("scOn", v ? 1 : 0); self?.host?.render() })
        sadd(ssw("Keep the original model too", l.xf("scKeep", 0) > 0.5) { [weak self] v in l.xset("scKeep", v ? 1 : 0); self?.host?.render() })
        func f(_ n: String, _ k: String, _ lo: Float, _ hi: Float, _ d: Float, _ fmt: String = "%.2f") {
            sadd(ssl(n, lo, hi, l.xf(k, d), fmt) { l.xset(k, $0) })
        }
        sadd(shead("Amount"))
        f("Count", "scCount", 1, 1500, 60, "%.0f"); f("Seed", "scSeed", 1, 999, 1, "%.0f"); f("Jitter", "scJitter", 0, 1, 0)
        sadd(sbtn("Re-roll seed") { [weak self] in self?.host?.pushUndo(); l.xset("scSeed", Float(Int.random(in: 1...999))); self?.host?.render(); self?.propKey = "" })
        sadd(shead("Distribution"))
        sadd(sseg(["Random", "Even spacing"], Int(l.xf("scMode", 0))) { i in l.xset("scMode", Float(i)) })
        f("Minimum distance (even)", "scMinDist", 0.01, 2, 0.2)
        sadd(shead("Scale"))
        f("Scale", "scScale", 0.05, 3, 1); f("Random scale", "scScaleRnd", 0, 1, 0.3); f("Squash / stretch", "scSquash", 0, 1, 0)
        sadd(shead("Rotation"))
        f("Align to surface", "scAlign", 0, 1, 1); f("Sit on surface", "scSit", 0, 1, 1); f("Random yaw", "scYaw", 0, 360, 360, "%.0f"); f("Random tilt", "scTilt", 0, 90, 0, "%.0f")
        f("Offset X", "scRotX", -180, 180, 0, "%.0f"); f("Offset Y", "scRotY", -180, 180, 0, "%.0f"); f("Offset Z", "scRotZ", -180, 180, 0, "%.0f")
        sadd(shead("Placement"))
        f("Lift along normal", "scLift", -1, 1, 0); f("Random lift", "scLiftRnd", 0, 1, 0)
        sadd(ssw("Flip surface normals", l.xf("scFlip", 0) > 0.5) { v in l.xset("scFlip", v ? 1 : 0) })
        sadd(shead("Filters"))
        f("Min slope (0 = flat up)", "scSlopeMin", 0, 180, 0, "%.0f"); f("Max slope", "scSlopeMax", 0, 180, 180, "%.0f")
        f("Min height", "scHMin", -10, 10, -10); f("Max height", "scHMax", -10, 10, 10)
        sadd(shead("Noise mask (clumps)"))
        f("Noise scale", "scNoiseScale", 0.2, 20, 3); f("Noise threshold", "scNoiseThr", 0, 1, 0)
        sadd(shead("Animation"))
        f("Grow-in duration (s)", "scGrow", 0, 5, 0); f("Grow stagger", "scStagger", 0, 1, 0.5)
        f("Sway angle", "scSway", 0, 30, 0, "%.1f"); f("Sway speed", "scSwaySpeed", 0, 4, 1)
        sadd(sbtn("Reset scatter settings") { [weak self] in
            self?.host?.pushUndo()
            l.x3s = l.x3s.split(separator: ";").filter { !$0.hasPrefix("sc") || $0.hasPrefix("scList") }.joined(separator: ";")
            self?.host?.render(); self?.propKey = ""
        })
    }

    private func sadd(_ v: UIView) { propStack.addArrangedSubview(v) }
    private func shead(_ t: String) -> UIView { let l = UILabel(); l.text = t.uppercased(); l.font = .systemFont(ofSize: 12, weight: .bold); l.textColor = accent; return l }
    private func snote(_ t: String, _ c: UIColor = .gray) -> UIView { let l = UILabel(); l.text = t; l.font = .systemFont(ofSize: 12); l.textColor = c; l.numberOfLines = 0; return l }
    private func sbtn(_ t: String, _ f: @escaping () -> Void) -> UIView {
        let b = FlatButton(t); b.onTap = f; return b
    }
    private func picker(_ title: String, _ cur: String, _ opts: [(String, Int)], _ f: @escaping (Int) -> Void) -> UIView {
        let b = FlatButton("\(title):  \(cur)  v", fill: accent.withAlphaComponent(0.35), height: 42)
        b.setMenu(UIMenu(children: opts.map { o in UIAction(title: o.0) { _ in f(o.1) } }))
        return b
    }
    private func ssw(_ t: String, _ on: Bool, _ f: @escaping (Bool) -> Void) -> UIView {
        let l = UILabel(); l.text = t; l.textColor = .white; l.font = .systemFont(ofSize: 15)
        let s = FlatSwitch(on)
        s.addAction(UIAction { _ in f(s.isOn) }, for: .valueChanged)
        let r = UIStackView(arrangedSubviews: [l, s]); r.alignment = .center; return r
    }
    private func sseg(_ items: [String], _ sel: Int, _ f: @escaping (Int) -> Void) -> UIView {
        let s = FlatSegment(items, sel)
        s.addAction(UIAction { _ in f(s.selectedSegmentIndex) }, for: .valueChanged); return s
    }
    private func ssl(_ t: String, _ lo: Float, _ hi: Float, _ v: Float, _ fmt: String, _ f: @escaping (Float) -> Void) -> UIView {
        FlatSlider(t, lo, hi, v, step: (hi - lo) / 100, fmt: fmt, def: min(max(0, lo), hi),
                   onBegin: { [weak self] in self?.host?.pushUndo() }, onChange: f, onEnd: { [weak self] in self?.host?.render() })
    }
}


// MARK: - Pose mode (bones, skinning, bone drag, Bones tab)

extension Scene3DView {

    fileprivate func markBones() { ovSigReset() }
    private func ovSigReset() { for k in Array(skels.keys) { setOv(k, "") } }

    /// Reads bone tracks ("bn<i>rx/ry/rz/px/py/pz"), poses the skeleton, runs physics, re-skins the mesh and redraws the bone overlay when anything changed.
    fileprivate func updatePose(_ t: Float) {
        let now = CACurrentMediaTime()
        let wall = lastPhysWall > 0 ? Float(min(now - lastPhysWall, 0.1)) : 0
        lastPhysWall = now
        for (id, sk) in skels {
            guard let l = layer(id), let holder = holders[id] else { continue }
            sk.physicsOn = (sk.phys?.active ?? false) && l.p("bnphoff", t) < 0.5
            let changed = sk.loadPose(l, t)
            let moved = sk.stepPhysics(t: t, wall: wall)
            if changed || moved { reskin(id, sk.skinMatrices()) }
            let vis = showBones || poseMode
            let ov = "\(sk.poseSig)|\(vis ? sk.simTick : 0)|\(showBones)|\(poseMode)|\(selBone)"
            if ov != getOv(id) { setOv(id, ov); refreshBones(id, sk, holder) }
        }
    }

    fileprivate func getPoseSig(_ id: Int) -> String { poseSigStore[id] ?? "" }
    fileprivate func setPoseSig(_ id: Int, _ v: String) { poseSigStore[id] = v }
    fileprivate func getOv(_ id: Int) -> String { ovStore[id] ?? "" }
    fileprivate func setOv(_ id: Int, _ v: String) { ovStore[id] = v }

    fileprivate func poseChipText() -> String {
        guard let sk = skels[selected] else { return "Pose  ·  select a model with bones" }
        var t = "Pose  ·  " + (mode == .rotate ? "Rotate bone" : (mode == .move ? "Move bone" : "pick Move or Rotate"))
        if selBone >= 0, selBone < sk.bones.count { t += "  ·  " + sk.bones[selBone].name }
        return t
    }

    fileprivate func selectBone(_ i: Int) {
        selBone = i; markBones(); propKey = ""
        if poseMode { chip.text = poseChipText() }
    }

    private func reskin(_ id: Int, _ mats: [simd_float4x4]) {
        for sp in skinPrims[id] ?? [] {
            guard let old = sp.node.geometry else { continue }
            let v = Skeleton3D.skinVerts(base: sp.base, jnt: sp.jnt, wgt: sp.wgt, mats: mats)
            let n = v.count / 12
            let data = v.withUnsafeBufferPointer { Data(buffer: $0) }
            func src(_ s: SCNGeometrySource.Semantic, _ comps: Int, _ off: Int) -> SCNGeometrySource {
                SCNGeometrySource(data: data, semantic: s, vectorCount: n, usesFloatComponents: true, componentsPerVector: comps, bytesPerComponent: 4, dataOffset: off * 4, dataStride: 48)
            }
            let g = SCNGeometry(sources: [src(.vertex, 3, 0), src(.normal, 3, 3), src(.texcoord, 2, 6)], elements: old.elements)
            g.materials = old.materials
            sp.node.geometry = g
        }
    }

    private func boneMat(_ c: UIColor) -> SCNMaterial {
        let m = SCNMaterial(); m.lightingModel = .constant; m.diffuse.contents = c
        m.readsFromDepthBuffer = false; m.writesToDepthBuffer = false      // bones are always drawn on top of the mesh
        return m
    }

    private func linePoints(_ sk: Skeleton3D, _ w: [simd_float4x4]) -> SCNGeometry? {
        var pts = [SCNVector3](), ind = [Int32]()
        for (i, b) in sk.bones.enumerated() where b.parent >= 0 && b.parent < w.count && b.parent != i {
            let p = w[i].columns.3, q = w[b.parent].columns.3
            ind += [Int32(pts.count), Int32(pts.count + 1)]
            pts += [SCNVector3(q.x, q.y, q.z), SCNVector3(p.x, p.y, p.z)]
        }
        guard !pts.isEmpty else { return nil }
        return SCNGeometry(sources: [SCNGeometrySource(vertices: pts)], elements: [SCNGeometryElement(indices: ind, primitiveType: .line)])
    }

    private func updateBonePositions(_ root: SCNNode, _ sk: Skeleton3D, _ id: Int) {
        let w = sk.world()
        let nodes = boneNodes[id] ?? []
        for i in 0..<min(nodes.count, w.count) { let p = w[i].columns.3; nodes[i].position = SCNVector3(p.x, p.y, p.z) }
        if let ln = root.childNode(withName: "lines", recursively: false), let g = linePoints(sk, w) {
            g.materials = ln.geometry?.materials ?? [boneMat(UIColor(white: 1, alpha: 0.75))]
            ln.geometry = g
        }
        if let lb = root.childNode(withName: "lbl", recursively: false), selBone >= 0, selBone < w.count {
            let p = w[selBone].columns.3, r = Float(0.016 / max(modelScale[id] ?? 1, 1e-4))
            lb.position = SCNVector3(p.x, p.y + r * 2.6, p.z)
        }
    }

    private func refreshBones(_ id: Int, _ sk: Skeleton3D, _ holder: SCNNode) {
        let existing = holder.childNode(withName: "bones", recursively: false)
        guard showBones || poseMode else { existing?.removeFromParentNode(); boneStruct[id] = ""; return }
        let key = "\(selBone)|\(sk.bones.count)"
        if let root = existing, boneStruct[id] == key { updateBonePositions(root, sk, id); return }
        existing?.removeFromParentNode()
        boneStruct[id] = key
        let root = SCNNode(); root.name = "bones"
        let w = sk.world()
        let rr = 0.016 / max(modelScale[id] ?? 1, 1e-4)
        func ball(_ c: UIColor, _ k: Float = 1) -> SCNGeometry {
            let g = SCNSphere(radius: CGFloat(rr * k)); g.segmentCount = 8
            g.materials = [boneMat(c)]; return g
        }
        let cyan = ball(UIColor(red: 0.2, green: 0.85, blue: 1, alpha: 1)), sel = ball(UIColor(red: 1, green: 0.55, blue: 0.1, alpha: 1), 1.6), phys = ball(UIColor(red: 1, green: 0.3, blue: 0.9, alpha: 1))
        var nodes: [SCNNode] = []
        for (i, b) in sk.bones.enumerated() {
            let p = w[i].columns.3
            let node = SCNNode(geometry: i == selBone ? sel : (b.physics ? phys : cyan))
            node.name = "bone\(i)"; node.position = SCNVector3(p.x, p.y, p.z); node.renderingOrder = 901
            root.addChildNode(node); nodes.append(node)
        }
        boneNodes[id] = nodes
        let ln = SCNNode(geometry: linePoints(sk, w)); ln.name = "lines"; ln.renderingOrder = 900
        ln.geometry?.materials = [boneMat(UIColor(white: 1, alpha: 0.75))]
        root.addChildNode(ln)
        if selBone >= 0, selBone < sk.bones.count {          // name of the selected bone, facing the camera
            let g = SCNText(string: sk.bones[selBone].name, extrusionDepth: 0)
            g.font = UIFont.boldSystemFont(ofSize: 1); g.flatness = 0.05
            g.materials = [boneMat(UIColor(red: 1, green: 0.9, blue: 0.35, alpha: 1))]
            let lb = SCNNode(geometry: g); lb.name = "lbl"
            let bb = g.boundingBox
            lb.pivot = SCNMatrix4MakeTranslation((bb.min.x + bb.max.x) / 2, bb.min.y, 0)
            let sc = Float(0.06 / max(modelScale[id] ?? 1, 1e-4))
            lb.scale = SCNVector3(sc, sc, sc); lb.renderingOrder = 902
            lb.constraints = [SCNBillboardConstraint()]
            let p = w[selBone].columns.3
            lb.position = SCNVector3(p.x, p.y + Float(rr) * 2.6, p.z)
            root.addChildNode(lb)
        }
        holder.addChildNode(root)
    }

    fileprivate func pickBone(_ p: CGPoint) -> Int? {
        for h in sv.hitTest(p, options: [.searchMode: SCNHitTestSearchMode.all.rawValue]) {
            if let nm = h.node.name, nm.hasPrefix("bone"), let i = Int(nm.dropFirst(4)) { return i }
        }
        return nil
    }

    fileprivate func applyBoneDrag(_ d: CGPoint) {
        guard let l = layer(selected), let sk = skels[selected], selBone >= 0, selBone < sk.bones.count, let holder = holders[selected] else { return }
        let t = Editor.time, ak = host?.autoKeyOn ?? false, i = selBone
        func add(_ k: String, _ v: Float) { l.track(k).set(t, l.p(k, t) + v, ak) }
        let w = sk.world()
        let bp = w[i].columns.3
        let sp = holder.convertPosition(SCNVector3(bp.x, bp.y, bp.z), to: nil)
        let pos = simd_float3(sp.x, sp.y, sp.z)
        let fr = (sk.bones[i].parent >= 0 && sk.bones[i].parent < w.count ? w[sk.bones[i].parent] : matrix_identity_float4x4) * sk.bones[i].restLocal
        /// The bone's own axis k in world space (what the gizmo shows).
        func axisW(_ k: Int) -> simd_float3? {
            let c = [fr.columns.0, fr.columns.1, fr.columns.2][k]
            let v = holder.convertVector(SCNVector3(c.x, c.y, c.z), to: nil)
            let l = sqrtf(v.x * v.x + v.y * v.y + v.z * v.z)
            return l > 1e-9 ? simd_float3(v.x / l, v.y / l, v.z / l) : nil
        }
        if mode == .rotate {
            let keys = ["bn\(i)rx", "bn\(i)ry", "bn\(i)rz"]
            if (0...2).contains(dragAxis), let ax = axisW(dragAxis) { snapped(ringAngle(ax, pos)) { add(keys[dragAxis], $0) } }
            else { add("bn\(i)ry", Float(d.x) * 0.5); add("bn\(i)rx", Float(d.y) * 0.5) }
            return
        }
        guard mode == .move else { return }
        var dw = simd_float3(0, 0, 0)
        if (0...2).contains(dragAxis), let dir = axisW(dragAxis) {
            let a = sv.projectPoint(SCNVector3(pos)), b = sv.projectPoint(SCNVector3(pos + dir))
            let sx = CGFloat(b.x - a.x), sy = CGFloat(b.y - a.y)
            let den = Float(sx * sx + sy * sy)
            guard den > 1e-4 else { return }
            dw = dir * Float(d.x * sx + d.y * sy) / den
        } else if (3...5).contains(dragAxis), let nrm = axisW(dragAxis - 3) {
            dw = planeDelta(pos, nrm) ?? .zero
        } else {
            dw = planeDelta(pos, simd_normalize(cam.simdWorldPosition - pos)) ?? .zero
        }
        let mv = holder.convertVector(SCNVector3(dw.x, dw.y, dw.z), from: nil)
        let o = fr.inverse * SIMD4<Float>(mv.x, mv.y, mv.z, 0)
        add("bn\(i)px", o.x); add("bn\(i)py", o.y); add("bn\(i)pz", o.z)
    }

    /// Degrees swept around `center` (on screen) since the last touch, signed for a right-handed rotation about `axis`.
    fileprivate func ringAngle(_ axis: simd_float3, _ center: simd_float3) -> Float {
        let c = sv.projectPoint(SCNVector3(center))
        let a0 = atan2(Float(dragPrev.y) - c.y, Float(dragPrev.x) - c.x), a1 = atan2(Float(dragCur.y) - c.y, Float(dragCur.x) - c.x)
        var da = a1 - a0
        if da > .pi { da -= 2 * .pi }
        if da < -.pi { da += 2 * .pi }
        let toCam = simd_normalize(cam.simdWorldPosition - center)
        let facing: Float = simd_dot(axis, toCam) >= 0 ? 1 : -1      // screen y points down: counter-clockwise = decreasing angle
        return -da * facing * 180 / .pi
    }

    /// Snaps rotation to 5 degree steps when Snap is on.
    fileprivate func snapped(_ v: Float, _ f: (Float) -> Void) {
        guard snapOn else { f(v); return }
        rotAcc += v
        let n = (rotAcc / 5).rounded(.towardZero)
        if n != 0 { f(n * 5); rotAcc -= n * 5 }
    }

    /// World movement of the touch point on the plane through `origin` with normal `n` since the last touch.
    fileprivate func planeDelta(_ origin: simd_float3, _ n: simd_float3) -> simd_float3? {
        func hit(_ p: CGPoint) -> simd_float3? {
            let a = sv.unprojectPoint(SCNVector3(Float(p.x), Float(p.y), 0)), b = sv.unprojectPoint(SCNVector3(Float(p.x), Float(p.y), 1))
            let o = simd_float3(a.x, a.y, a.z)
            let r = simd_normalize(simd_float3(b.x, b.y, b.z) - o)
            let dn = simd_dot(r, n)
            guard abs(dn) > 0.05 else { return nil }
            return o + r * (simd_dot(origin - o, n) / dn)
        }
        guard let p0 = hit(dragPrev), let p1 = hit(dragCur) else { return nil }
        return p1 - p0
    }

    /// Shows the values being edited in the top chip while a handle is dragged.
    fileprivate func showReadout() {
        guard let l = layer(selected) else { return }
        let t = Editor.time
        func v3(_ k: [String], _ f: String) -> String { zip(["X", "Y", "Z"], k).map { "\($0) " + String(format: f, l.p($1, t)) }.joined(separator: "   ") }
        if poseMode, skels[selected] != nil, selBone >= 0 {
            let i = selBone
            if mode == .rotate { chip.text = "Rotate  " + v3(["bn\(i)rx", "bn\(i)ry", "bn\(i)rz"], "%.1f") + (snapOn ? "  (snap)" : "") }
            else if mode == .move { chip.text = "Move  " + v3(["bn\(i)px", "bn\(i)py", "bn\(i)pz"], "%.3f") }
        } else if mode == .rotate { chip.text = "Rotate  " + v3(["rotX", "rotY", "rotZ"], "%.1f") + (snapOn ? "  (snap)" : "") }
        else if mode == .move { chip.text = "Move  " + v3(["x", "y", "z"], "%.2f") }
        else if mode == .scale { chip.text = "Scale  " + String(format: "%.2f", l.p("scale", t)) }
    }

    /// Bones in hierarchy order with their depth.
    private func boneTree(_ sk: Skeleton3D) -> [(Int, Int)] {
        let n = sk.bones.count
        var kids = [[Int]](repeating: [], count: n), roots: [Int] = []
        for (i, b) in sk.bones.enumerated() {
            if b.parent >= 0, b.parent < n, b.parent != i { kids[b.parent].append(i) } else { roots.append(i) }
        }
        var out: [(Int, Int)] = [], seen = Set<Int>()
        var stack: [(Int, Int)] = roots.reversed().map { ($0, 0) }
        while let (i, d) = stack.popLast() {
            if seen.contains(i) { continue }
            seen.insert(i); out.append((i, d))
            for c in kids[i].reversed() { stack.append((c, d + 1)) }
        }
        return out
    }

    /// Name of the opposite-side bone (Left/Right, _L/_R, .L/.R, L_/R_), nil when it has none.
    private func mirrorName(_ n: String) -> String? {
        for (a, b) in [("Left", "Right"), ("left", "right"), ("LEFT", "RIGHT")] {
            if n.contains(a) { return n.replacingOccurrences(of: a, with: b) }
            if n.contains(b) { return n.replacingOccurrences(of: b, with: a) }
        }
        for (a, b) in [("_L", "_R"), (".L", ".R"), ("_l", "_r"), (".l", ".r"), ("Left", "Right")] {
            if n.hasSuffix(a) { return String(n.dropLast(a.count)) + b }
            if n.hasSuffix(b) { return String(n.dropLast(b.count)) + a }
        }
        for (a, b) in [("L_", "R_"), ("l_", "r_")] {
            if n.hasPrefix(a) { return b + String(n.dropFirst(a.count)) }
            if n.hasPrefix(b) { return a + String(n.dropFirst(b.count)) }
        }
        if n.contains("\u{5DE6}") { return n.replacingOccurrences(of: "\u{5DE6}", with: "\u{53F3}") }
        if n.contains("\u{53F3}") { return n.replacingOccurrences(of: "\u{53F3}", with: "\u{5DE6}") }
        return nil
    }

    fileprivate func bonesProps() {
        guard let l = layer(selected) else { add(note("Select a rigged model first.")); return }
        add(head("Bones  ·  \(l.name)"))
        add(sw("Show bones", showBones) { [weak self] v in self?.showBones = v; self?.markBones(); self?.propKey = ""; self?.rebuildMenu() })
        guard let sk = skels[l.id] else { add(note("This model has no bones. Rigged GLB / glTF, VRM, PMX and static FBX models are supported.")); return }
        add(sw("Pose mode", poseMode) { [weak self] v in self?.setPose(v) })
        if let ph = sk.phys, ph.active {
            let nPhys = sk.bones.filter { $0.physics }.count
            add(sw("Physics  (\(nPhys) bones)", l.p("bnphoff", Editor.time) < 0.5) { [weak self] v in
                self?.host?.pushUndo(); l.track("bnphoff").set(Editor.time, v ? 0 : 1, false); sk.resetPhysics(); self?.markBones()
            })
        } else {
            add(note("No spring bones or rigid bodies in this model, so there is no physics."))
        }
        let t = Editor.time
        let chn = ["rx", "ry", "rz", "px", "py", "pz"]
        func vals(_ i: Int) -> [Float] { chn.map { l.p("bn\(i)" + $0, t) } }
        func setVals(_ i: Int, _ v: [Float], _ key: Bool) { for c in 0..<6 { l.track("bn\(i)" + chn[c]).set(t, v[c], key) } }
        func changed() { propKey = ""; host?.render() }
        func mk(_ title: String, _ fill: UIColor = Flat.card, _ f: @escaping () -> Void) -> FlatButton {
            let b = FlatButton(title, fill: fill); b.onTap = f; return b
        }
        let posed = Set<Int>(l.props.keys.compactMap { Skeleton3D.boneKey($0)?.0 })

        let r1 = UIStackView(arrangedSubviews: [
            mk("Reset pose", Flat.danger.withAlphaComponent(0.55)) { [weak self] in
                self?.host?.pushUndo(); sk.clearTracks(l); sk.resetPhysics(); self?.markBones(); self?.propKey = ""; self?.host?.render()
            },
            mk("Key pose") { [weak self] in
                self?.host?.pushUndo()
                for i in posed where i < sk.bones.count { setVals(i, vals(i), true) }
                changed()
            }])
        r1.spacing = 8; r1.distribution = .fillEqually; add(r1)

        guard poseMode else { add(note("Turn on Pose mode (figure button in the side bar) to pick and move bones.")); return }

        add(seg("", ["Rotate", "Move"], mode == .move ? 1 : 0) { [weak self] i in
            self?.mode = i == 1 ? .move : .rotate; self?.updateModeUI(); self?.propKey = ""
        })

        let tree = boneTree(sk)
        if selBone >= 0, selBone < sk.bones.count {
            let i = selBone
            add(head("Bone: \(sk.bones[i].name)"))
            // navigation
            let pos = tree.firstIndex { $0.0 == i } ?? 0
            func go(_ t: String, _ target: Int?) -> UIView {
                let b = FlatButton(t, height: 34)
                if let tg = target { b.onTap = { [weak self] in self?.selectBone(tg) } } else { b.alpha = 0.35 }
                return b
            }
            let par = sk.bones[i].parent >= 0 && sk.bones[i].parent < sk.bones.count ? sk.bones[i].parent : nil
            let child = tree.indices.contains(pos + 1) && tree[pos + 1].1 > tree[pos].1 ? tree[pos + 1].0 : nil
            let prev = pos > 0 ? tree[pos - 1].0 : nil
            let next = pos + 1 < tree.count ? tree[pos + 1].0 : nil
            let nav = UIStackView(arrangedSubviews: [go("Parent", par), go("Child", child), go("Prev", prev), go("Next", next)])
            nav.spacing = 6; nav.distribution = .fillEqually; add(nav)

            let rng = 0.5 / max(modelScale[l.id] ?? 1, 1e-4)
            func row(_ n: String, _ k: String, _ lo: Float, _ hi: Float, _ step: Float, _ fmt: String) {
                add(FlatSlider(n, lo, hi, l.p(k, t), step: step, fmt: fmt, def: 0,
                               onBegin: { [weak self] in self?.host?.pushUndo() },
                               onChange: { [weak self] v in l.track(k).set(Editor.time, v, self?.host?.autoKeyOn ?? false) },
                               onEnd: { [weak self] in self?.host?.render() }))
            }
            row("Rotate X", "bn\(i)rx", -180, 180, 1, "%.1f"); row("Rotate Y", "bn\(i)ry", -180, 180, 1, "%.1f"); row("Rotate Z", "bn\(i)rz", -180, 180, 1, "%.1f")
            row("Move X", "bn\(i)px", -rng, rng, rng / 100, "%.3f"); row("Move Y", "bn\(i)py", -rng, rng, rng / 100, "%.3f"); row("Move Z", "bn\(i)pz", -rng, rng, rng / 100, "%.3f")

            let a1 = UIStackView(arrangedSubviews: [
                mk("Reset bone") { [weak self] in self?.host?.pushUndo(); setVals(i, [0, 0, 0, 0, 0, 0], self?.host?.autoKeyOn ?? false); changed() },
                mk("Key bone", Flat.accent.withAlphaComponent(0.45)) { [weak self] in self?.host?.pushUndo(); setVals(i, vals(i), true); changed() }])
            a1.spacing = 8; a1.distribution = .fillEqually; add(a1)
            let paste = mk("Paste") { [weak self] in
                guard let c = self?.boneClip else { return }
                self?.host?.pushUndo(); setVals(i, c, self?.host?.autoKeyOn ?? false); changed()
            }
            paste.alpha = boneClip == nil ? 0.35 : 1
            let a2 = UIStackView(arrangedSubviews: [mk("Copy") { [weak self] in self?.boneClip = vals(i); self?.propKey = "" }, paste])
            a2.spacing = 8; a2.distribution = .fillEqually; add(a2)
            if let mn = mirrorName(sk.bones[i].name), let mi = sk.bones.firstIndex(where: { $0.name == mn }), mi != i {
                add(btnRow("Mirror to  " + mn) { [weak self] in
                    let v = vals(i)
                    self?.host?.pushUndo(); setVals(mi, [v[0], -v[1], -v[2], -v[3], v[4], v[5]], self?.host?.autoKeyOn ?? false); changed()
                })
            }
        } else {
            add(note("Tap a bone in the 3D view or in the list to select it."))
        }

        // searchable bone tree
        add(head("All bones (\(sk.bones.count))"))
        let field = FlatField(); field.placeholder = "Search bones"; field.text = boneFilter
        field.attributedPlaceholder = NSAttributedString(string: "Search bones", attributes: [.foregroundColor: Flat.dim])
        add(field)
        add(seg("", ["All", "Posed", "Physics"], boneFilterMode) { [weak self] i in self?.boneFilterMode = i; self?.propKey = "" })
        let box = UIStackView(); box.axis = .vertical; box.spacing = 4
        add(box)
        func fill() {
            box.arrangedSubviews.forEach { $0.removeFromSuperview() }
            let q = boneFilter.lowercased()
            var shown = 0, total = 0
            for (i, d) in tree {
                let b = sk.bones[i]
                if !q.isEmpty, !b.name.lowercased().contains(q) { continue }
                if boneFilterMode == 1, !posed.contains(i) { continue }
                if boneFilterMode == 2, !b.physics { continue }
                total += 1
                if shown >= 300 { continue }
                shown += 1
                let r = BoneRow(b.name, depth: (q.isEmpty && boneFilterMode == 0) ? d : 0, selected: i == selBone, physics: b.physics, posed: posed.contains(i))
                r.onTap = { [weak self] in self?.selectBone(i) }
                box.addArrangedSubview(r)
            }
            if total > shown { box.addArrangedSubview(note("\(total - shown) more. Use the search to narrow the list.")) }
            if total == 0 { box.addArrangedSubview(note("No bones match.")) }
        }
        fill()
        field.addAction(UIAction { [weak self, weak field] _ in self?.boneFilter = field?.text ?? ""; fill() }, for: .editingChanged)
        field.addAction(UIAction { [weak field] _ in field?.resignFirstResponder() }, for: .editingDidEndOnExit)
    }
}
