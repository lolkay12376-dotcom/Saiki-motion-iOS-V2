// PoseUI.swift — the app's own flat controls for the 3D editor panels (no UISwitch / UISlider / UISegmentedControl /
// system buttons) plus the bone tree used by the Bones tab.

import UIKit

enum Flat {
    static let accent = UIColor(red: 1, green: 0.55, blue: 0.08, alpha: 1)
    static let card = UIColor(white: 0.17, alpha: 1)
    static let card2 = UIColor(white: 0.24, alpha: 1)
    static let dim = UIColor(white: 0.62, alpha: 1)
    static let danger = UIColor(red: 0.85, green: 0.28, blue: 0.25, alpha: 1)

    static func text(_ s: String, _ size: CGFloat, _ color: UIColor, bold: Bool = false, in r: CGRect, align: NSTextAlignment = .center) {
        let p = NSMutableParagraphStyle(); p.alignment = align; p.lineBreakMode = .byTruncatingTail
        let f = UIFont.systemFont(ofSize: size, weight: bold ? .bold : .regular)
        let h = f.lineHeight
        (s as NSString).draw(in: CGRect(x: r.minX, y: r.midY - h / 2, width: r.width, height: h),
                             withAttributes: [.font: f, .foregroundColor: color, .paragraphStyle: p])
    }
}

/// On / off switch.
final class FlatSwitch: UIControl {
    var isOn = false { didSet { setNeedsDisplay() } }
    init(_ on: Bool) {
        super.init(frame: CGRect(x: 0, y: 0, width: 46, height: 26)); isOn = on
        backgroundColor = .clear; isOpaque = false
        addTarget(self, action: #selector(tapped), for: .touchUpInside)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
    override var intrinsicContentSize: CGSize { CGSize(width: 46, height: 26) }
    @objc private func tapped() { isOn.toggle(); sendActions(for: .valueChanged) }
    override func draw(_ rect: CGRect) {
        let r = CGRect(x: 0, y: (bounds.height - 26) / 2, width: 46, height: 26)
        (isOn ? Flat.accent : Flat.card2).setFill()
        UIBezierPath(roundedRect: r, cornerRadius: 13).fill()
        UIColor.white.setFill()
        UIBezierPath(ovalIn: CGRect(x: isOn ? r.maxX - 23 : r.minX + 3, y: r.minY + 3, width: 20, height: 20)).fill()
    }
}

/// Flat rounded button.
final class FlatButton: UIControl {
    var onTap: (() -> Void)?
    private let label = UILabel()
    private let fill: UIColor
    init(_ title: String, fill: UIColor = Flat.card, height: CGFloat = 40, textColor: UIColor = .white) {
        self.fill = fill
        super.init(frame: .zero)
        backgroundColor = fill; layer.cornerRadius = 10
        label.text = title; label.textColor = textColor; label.font = .systemFont(ofSize: 14, weight: .semibold)
        label.textAlignment = .center; label.isUserInteractionEnabled = false; label.adjustsFontSizeToFitWidth = true; label.minimumScaleFactor = 0.7
        label.translatesAutoresizingMaskIntoConstraints = false
        addSubview(label)
        NSLayoutConstraint.activate([label.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 8), label.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -8),
                                     label.centerYAnchor.constraint(equalTo: centerYAnchor), heightAnchor.constraint(equalToConstant: height)])
        addTarget(self, action: #selector(fire), for: .touchUpInside)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
    @objc private func fire() { onTap?() }
    func setTitle(_ t: String) { label.text = t }
    override var isHighlighted: Bool { didSet { alpha = isHighlighted ? 0.6 : 1 } }
}

/// Segmented selector (same API as the parts of UISegmentedControl the panels use).
final class FlatSegment: UIControl {
    var items: [String]
    var selectedSegmentIndex: Int { didSet { setNeedsDisplay() } }
    init(_ items: [String], _ sel: Int = 0) {
        self.items = items; selectedSegmentIndex = sel
        super.init(frame: .zero); backgroundColor = .clear; isOpaque = false
        heightAnchor.constraint(equalToConstant: 32).isActive = true
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
    override func draw(_ rect: CGRect) {
        Flat.card.setFill(); UIBezierPath(roundedRect: bounds, cornerRadius: 9).fill()
        guard !items.isEmpty else { return }
        let w = bounds.width / CGFloat(items.count)
        for (i, t) in items.enumerated() {
            let r = CGRect(x: w * CGFloat(i), y: 0, width: w, height: bounds.height)
            if i == selectedSegmentIndex { Flat.accent.setFill(); UIBezierPath(roundedRect: r.insetBy(dx: 2, dy: 2), cornerRadius: 7).fill() }
            Flat.text(t, items.count > 4 ? 10 : 13, i == selectedSegmentIndex ? .black : .white, bold: true, in: r)
        }
    }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first, !items.isEmpty else { return }
        let i = min(max(Int(t.location(in: self).x / (bounds.width / CGFloat(items.count))), 0), items.count - 1)
        if i != selectedSegmentIndex { selectedSegmentIndex = i; sendActions(for: .valueChanged) }
    }
}

/// Drag track. Fills from the left, or from the centre for ranges around zero. Double tap resets to `def`.
final class FlatTrack: UIControl {
    var lo: Float, hi: Float, def: Float
    var value: Float { didSet { setNeedsDisplay() } }
    var bipolar = false
    var onBegin: (() -> Void)?
    var onChange: ((Float) -> Void)?
    var onEnd: (() -> Void)?
    private var startX: CGFloat = 0, startV: Float = 0
    init(_ lo: Float, _ hi: Float, _ v: Float, def: Float = 0) {
        self.lo = lo; self.hi = hi; self.def = def; value = v
        super.init(frame: .zero); backgroundColor = .clear; isOpaque = false
        bipolar = lo < 0 && hi > 0
        heightAnchor.constraint(equalToConstant: 34).isActive = true
        let dt = UITapGestureRecognizer(target: self, action: #selector(doubleTap)); dt.numberOfTapsRequired = 2
        addGestureRecognizer(dt)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
    @objc private func doubleTap() { onBegin?(); set(def); onEnd?() }
    func set(_ v: Float) { value = min(max(v, lo), hi); onChange?(value) }
    override func draw(_ rect: CGRect) {
        let r = CGRect(x: 0, y: bounds.midY - 8, width: bounds.width, height: 16)
        Flat.card.setFill(); UIBezierPath(roundedRect: r, cornerRadius: 8).fill()
        let f = CGFloat((value - lo) / max(hi - lo, 1e-9))
        let zero = bipolar ? CGFloat((0 - lo) / (hi - lo)) : 0
        let a = min(f, zero) * r.width, b = max(f, zero) * r.width
        Flat.accent.setFill(); UIBezierPath(roundedRect: CGRect(x: a, y: r.minY, width: max(b - a, 2), height: r.height), cornerRadius: 8).fill()
        UIColor.white.setFill()
        UIBezierPath(ovalIn: CGRect(x: min(max(f * r.width - 9, 0), r.width - 18), y: bounds.midY - 9, width: 18, height: 18)).fill()
        if bipolar { Flat.dim.setFill(); UIBezierPath(rect: CGRect(x: zero * r.width - 0.5, y: r.minY - 2, width: 1, height: r.height + 4)).fill() }
    }
    private func at(_ x: CGFloat) { set(lo + Float(min(max(x / max(bounds.width, 1), 0), 1)) * (hi - lo)) }
    override func beginTracking(_ touch: UITouch, with event: UIEvent?) -> Bool { onBegin?(); at(touch.location(in: self).x); return true }
    override func continueTracking(_ touch: UITouch, with event: UIEvent?) -> Bool { at(touch.location(in: self).x); return true }
    override func endTracking(_ touch: UITouch?, with event: UIEvent?) { onEnd?() }
    override func cancelTracking(with event: UIEvent?) { onEnd?() }
}

/// Labelled slider row: name, value, [-] track [+] (nudge by `step`).
final class FlatSlider: UIStackView {
    init(_ name: String, _ lo: Float, _ hi: Float, _ v: Float, step: Float, fmt: String, def: Float = 0,
         onBegin: @escaping () -> Void, onChange: @escaping (Float) -> Void, onEnd: @escaping () -> Void) {
        super.init(frame: .zero)
        axis = .vertical; spacing = 2
        let n = UILabel(); n.text = name; n.textColor = .white; n.font = .systemFont(ofSize: 14)
        let val = UILabel(); val.textColor = Flat.dim; val.font = .monospacedDigitSystemFont(ofSize: 13, weight: .regular); val.textAlignment = .right
        val.text = String(format: fmt, v)
        let top = UIStackView(arrangedSubviews: [n, val])
        let tr = FlatTrack(lo, hi, v, def: def)
        tr.onBegin = onBegin; tr.onEnd = onEnd
        tr.onChange = { x in val.text = String(format: fmt, x); onChange(x) }
        func nudge(_ t: String, _ d: Float) -> FlatButton {
            let b = FlatButton(t, height: 30)
            b.widthAnchor.constraint(equalToConstant: 34).isActive = true
            b.onTap = { [weak tr] in guard let tr = tr else { return }; onBegin(); tr.set(tr.value + d); onEnd() }
            return b
        }
        let row = UIStackView(arrangedSubviews: [nudge("-", -step), tr, nudge("+", step)]); row.spacing = 6; row.alignment = .center
        addArrangedSubview(top); addArrangedSubview(row)
    }
    required init(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

/// Small text field for the bone search (flat, no system chrome).
final class FlatField: UITextField {
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = Flat.card; layer.cornerRadius = 10; textColor = .white; font = .systemFont(ofSize: 14)
        autocorrectionType = .no; autocapitalizationType = .none; returnKeyType = .done; borderStyle = .none
        heightAnchor.constraint(equalToConstant: 38).isActive = true
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
    override func textRect(forBounds bounds: CGRect) -> CGRect { bounds.insetBy(dx: 12, dy: 0) }
    override func editingRect(forBounds bounds: CGRect) -> CGRect { bounds.insetBy(dx: 12, dy: 0) }
    override func placeholderRect(forBounds bounds: CGRect) -> CGRect { bounds.insetBy(dx: 12, dy: 0) }
}

/// One row of the bone tree.
final class BoneRow: UIControl {
    var onTap: (() -> Void)?
    init(_ name: String, depth: Int, selected: Bool, physics: Bool, posed: Bool) {
        super.init(frame: .zero)
        backgroundColor = selected ? Flat.accent.withAlphaComponent(0.35) : Flat.card; layer.cornerRadius = 8
        heightAnchor.constraint(equalToConstant: 34).isActive = true
        let dot = UIView(); dot.layer.cornerRadius = 4; dot.isUserInteractionEnabled = false
        dot.backgroundColor = physics ? UIColor(red: 1, green: 0.3, blue: 0.9, alpha: 1) : (posed ? Flat.accent : UIColor(red: 0.2, green: 0.85, blue: 1, alpha: 1))
        dot.translatesAutoresizingMaskIntoConstraints = false
        let l = UILabel(); l.text = name; l.textColor = .white; l.font = .systemFont(ofSize: 13, weight: selected ? .bold : .regular)
        l.isUserInteractionEnabled = false; l.translatesAutoresizingMaskIntoConstraints = false
        addSubview(dot); addSubview(l)
        let ind = CGFloat(min(depth, 12)) * 10 + 10
        NSLayoutConstraint.activate([dot.leadingAnchor.constraint(equalTo: leadingAnchor, constant: ind), dot.centerYAnchor.constraint(equalTo: centerYAnchor),
                                     dot.widthAnchor.constraint(equalToConstant: 8), dot.heightAnchor.constraint(equalToConstant: 8),
                                     l.leadingAnchor.constraint(equalTo: dot.trailingAnchor, constant: 8), l.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -8),
                                     l.centerYAnchor.constraint(equalTo: centerYAnchor)])
        addTarget(self, action: #selector(fire), for: .touchUpInside)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
    @objc private func fire() { onTap?() }
}

// MARK: - drop-in replacements for UISlider / UISwitch / UISegmentedControl in the older panels

/// Same API as the parts of UISlider the panels use (min / max / value, tintColor, valueChanged / touchDown / touchUp events).
final class FlatUISlider: UIControl {
    var minimumValue: Float = 0 { didSet { setNeedsDisplay() } }
    var maximumValue: Float = 1 { didSet { setNeedsDisplay() } }
    var value: Float = 0 { didSet { setNeedsDisplay() } }
    override init(frame: CGRect) {
        super.init(frame: frame); backgroundColor = .clear; isOpaque = false
        heightAnchor.constraint(equalToConstant: 34).isActive = true
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
    override func draw(_ rect: CGRect) {
        let r = CGRect(x: 0, y: bounds.midY - 8, width: bounds.width, height: 16)
        Flat.card.setFill(); UIBezierPath(roundedRect: r, cornerRadius: 8).fill()
        let f = CGFloat((value - minimumValue) / max(maximumValue - minimumValue, 1e-9))
        (tintColor ?? Flat.accent).setFill()
        UIBezierPath(roundedRect: CGRect(x: 0, y: r.minY, width: max(f * r.width, 4), height: r.height), cornerRadius: 8).fill()
        UIColor.white.setFill()
        UIBezierPath(ovalIn: CGRect(x: min(max(f * r.width - 9, 0), r.width - 18), y: bounds.midY - 9, width: 18, height: 18)).fill()
    }
    private func at(_ x: CGFloat) {
        let v = minimumValue + Float(min(max(x / max(bounds.width, 1), 0), 1)) * (maximumValue - minimumValue)
        if v != value { value = v; sendActions(for: .valueChanged) }
    }
    override func beginTracking(_ touch: UITouch, with event: UIEvent?) -> Bool { at(touch.location(in: self).x); return true }
    override func continueTracking(_ touch: UITouch, with event: UIEvent?) -> Bool { at(touch.location(in: self).x); return true }
}

extension FlatSwitch {
    /// Kept so old call sites compile; the on colour is the app accent.
    var onTintColor: UIColor? { get { Flat.accent } set { } }
}

extension FlatSegment {
    convenience init(items: [String]) { self.init(items, 0) }
    var selectedSegmentTintColor: UIColor? { get { Flat.accent } set { } }
    func setTitleTextAttributes(_ a: [NSAttributedString.Key: Any]?, for state: UIControl.State) { }
}
