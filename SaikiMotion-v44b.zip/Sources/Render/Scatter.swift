// Scatter.swift — places copies of a 3D model on the surface of a target layer.
// Used by the Metal model renderer (instanced draws) and by the Scene 3D editor preview, so both agree.
// All settings live on the scattered layer as x3s keys (see Layer.xf): scOn, scTarget, scCount, ...

import Foundation
import simd
import OpenGLES

enum Scatter {
    struct Tri { var a: simd_float3; var b: simd_float3; var c: simd_float3 }
    struct P { var pos: simd_float3; var n: simd_float3; var r: simd_float4; var r2: simd_float2; var u: Float }

    // MARK: surfaces
    private static var triCache: [ObjectIdentifier: [Tri]] = [:]
    static func tris(_ g: GlbModel) -> [Tri] {
        let id = ObjectIdentifier(g)
        if let t = triCache[id] { return t }
        var out: [Tri] = []
        for p in g.prims where !p.verts.isEmpty && p.mode == GLenum(GL_TRIANGLES) {
            let idx: [UInt32] = p.cpuIdx.isEmpty ? (0..<UInt32(p.verts.count / 12)).map { $0 } : p.cpuIdx
            func v(_ i: UInt32) -> simd_float3 { let b = Int(i) * 12; return simd_float3(p.verts[b], p.verts[b + 1], p.verts[b + 2]) }
            var i = 0
            while i + 2 < idx.count { out.append(Tri(a: v(idx[i]), b: v(idx[i + 1]), c: v(idx[i + 2]))); i += 3 }
        }
        if triCache.count > 8 { triCache.removeAll() }
        triCache[id] = out
        return out
    }
    /// A flat image / video plane (local space, facing +Z).
    static func quad(_ w: Float, _ h: Float) -> [Tri] {
        let x = max(w, 0.01) / 2, y = max(h, 0.01) / 2
        let a = simd_float3(-x, -y, 0), b = simd_float3(x, -y, 0), c = simd_float3(x, y, 0), d = simd_float3(-x, y, 0)
        return [Tri(a: a, b: b, c: c), Tri(a: a, b: c, c: d)]
    }

    // MARK: random + noise
    private struct Rng {
        var s: UInt64
        mutating func f() -> Float {
            s ^= s << 13; s ^= s >> 7; s ^= s << 17
            return Float(s >> 40) / Float(1 << 24)
        }
    }
    private static func hash(_ x: Int32, _ y: Int32, _ z: Int32) -> Float {
        var h = UInt32(bitPattern: x &* 374761393 &+ y &* 668265263 &+ z &* 1274126177)
        h = (h ^ (h >> 13)) &* 1274126177
        return Float((h ^ (h >> 16)) & 0xFFFF) / 65535
    }
    private static func noise(_ p: simd_float3) -> Float {
        let f = simd_float3(floor(p.x), floor(p.y), floor(p.z)), t = p - f
        let s = t * t * (simd_float3(repeating: 3) - 2 * t)
        let i = (Int32(f.x), Int32(f.y), Int32(f.z))
        func h(_ a: Int32, _ b: Int32, _ c: Int32) -> Float { hash(i.0 &+ a, i.1 &+ b, i.2 &+ c) }
        let x00 = h(0, 0, 0) + (h(1, 0, 0) - h(0, 0, 0)) * s.x, x10 = h(0, 1, 0) + (h(1, 1, 0) - h(0, 1, 0)) * s.x
        let x01 = h(0, 0, 1) + (h(1, 0, 1) - h(0, 0, 1)) * s.x, x11 = h(0, 1, 1) + (h(1, 1, 1) - h(0, 1, 1)) * s.x
        let y0 = x00 + (x10 - x00) * s.y, y1 = x01 + (x11 - x01) * s.y
        return y0 + (y1 - y0) * s.z
    }

    // MARK: placement (cached until the settings / target change)
    private static var keys: [Int: String] = [:], caches: [Int: [P]] = [:]

    static func placements(_ l: Layer, tris: [Tri], targetM: simd_float4x4) -> [P] {
        var key = "\(l.id)|\(l.x3s)|\(tris.count)"
        for c in 0..<4 { let v = targetM[c]; key += "|\(Int(v.x * 500)),\(Int(v.y * 500)),\(Int(v.z * 500))" }
        if keys[l.id] == key, let c = caches[l.id] { return c }
        let g = generate(l, tris: tris, M: targetM)
        keys[l.id] = key; caches[l.id] = g
        return g
    }

    private static func generate(_ l: Layer, tris: [Tri], M: simd_float4x4) -> [P] {
        guard !tris.isEmpty else { return [] }
        let count = min(Int(l.xf("scCount", 60)), 3000)
        var rng = Rng(s: UInt64(max(1, Int(l.xf("scSeed", 1)))) &* 0x9E3779B97F4A7C15 | 1)
        let even = l.xf("scMode", 0) >= 0.5
        let minD = l.xf("scMinDist", 0.2)
        let sMin = l.xf("scSlopeMin", 0) , sMax = l.xf("scSlopeMax", 180)
        let hMin = l.xf("scHMin", -100), hMax = l.xf("scHMax", 100)
        let nScale = l.xf("scNoiseScale", 3), nThr = l.xf("scNoiseThr", 0)
        let flip: Float = l.xf("scFlip", 0) >= 0.5 ? -1 : 1
        let jitter = l.xf("scJitter", 0)
        // world-space triangles + cumulative area
        var cum: [Float] = [], tot: Float = 0
        var wt: [Tri] = []
        wt.reserveCapacity(tris.count)
        for t in tris {
            func w(_ v: simd_float3) -> simd_float3 { let r = M * simd_float4(v, 1); return simd_float3(r.x, r.y, r.z) }
            let a = w(t.a), b = w(t.b), c = w(t.c)
            wt.append(Tri(a: a, b: b, c: c))
            tot += 0.5 * simd_length(simd_cross(b - a, c - a)); cum.append(tot)
        }
        guard tot > 1e-9 else { return [] }
        var out: [P] = []
        var tries = 0
        while out.count < count && tries < count * 14 {
            tries += 1
            let r = rng.f() * tot
            var lo = 0, hi = cum.count - 1
            while lo < hi { let m = (lo + hi) / 2; if cum[m] < r { lo = m + 1 } else { hi = m } }
            let t = wt[lo]
            var u = rng.f(), v = rng.f()
            if u + v > 1 { u = 1 - u; v = 1 - v }
            var p = t.a + (t.b - t.a) * u + (t.c - t.a) * v
            var n = simd_cross(t.b - t.a, t.c - t.a)
            if simd_length(n) < 1e-12 { continue }
            n = simd_normalize(n) * flip
            let slope = acos(max(-1, min(1, n.y))) * 180 / .pi
            if slope < sMin || slope > sMax { continue }
            if p.y < hMin || p.y > hMax { continue }
            if nThr > 0, noise(p * max(nScale, 0.01)) < nThr { continue }
            if even && out.contains(where: { simd_distance($0.pos, p) < minD }) { continue }
            if jitter > 0 { p += simd_float3(rng.f() - 0.5, rng.f() - 0.5, rng.f() - 0.5) * jitter * 0.2 }
            out.append(P(pos: p, n: n, r: simd_float4(rng.f(), rng.f(), rng.f(), rng.f()), r2: simd_float2(rng.f(), rng.f()), u: Float(out.count) / Float(max(count, 1))))
        }
        return out
    }

    // MARK: per-frame matrices
    private static func rot(_ deg: Float, _ axis: simd_float3) -> simd_float4x4 { simd_float4x4(simd_quatf(angle: deg * .pi / 180, axis: axis)) }

    /// World matrix of every instance (before the model's own centring / normalising).
    static func matrices(_ l: Layer, _ ps: [P], time: Float) -> [simd_float4x4] {
        let base = l.p("scale", time) * l.xf("scScale", 1)
        let rnd = l.xf("scScaleRnd", 0.3), squash = l.xf("scSquash", 0)
        let align = l.xf("scAlign", 1), yaw = l.xf("scYaw", 360), tilt = l.xf("scTilt", 0)
        let lift = l.xf("scLift", 0), liftR = l.xf("scLiftRnd", 0)
        let sway = l.xf("scSway", 0), swaySp = l.xf("scSwaySpeed", 1)
        let grow = l.xf("scGrow", 0), stag = l.xf("scStagger", 0.5)
        let fix = rot(l.xf("scRotZ", 0), simd_float3(0, 0, 1)) * rot(l.xf("scRotX", 0), simd_float3(1, 0, 0)) * rot(l.xf("scRotY", 0), simd_float3(0, 1, 0))
        let up = simd_float3(0, 1, 0)
        var out: [simd_float4x4] = []
        out.reserveCapacity(ps.count)
        for p in ps {
            var g: Float = 1
            if grow > 0 { let x = max(0, min(1, (time - l.start - stag * p.u * grow) / grow)); g = x * x * (3 - 2 * x) }
            if g <= 0.0005 { continue }
            let s = max(0.001, base * (1 + (p.r.z - 0.5) * 2 * rnd)) * g
            let sy = s * (1 + (p.r.w - 0.5) * 2 * squash)
            let dir = simd_normalize(up * (1 - align) + p.n * align + simd_float3(0, 1e-5, 0))
            var R = simd_float4x4(simd_quatf(from: up, to: dir))
            R = R * rot(p.r.x * yaw, up) * rot((p.r.y - 0.5) * 2 * tilt, simd_float3(1, 0, 0))
            if sway != 0 {
                let a = sin((time * swaySp + p.r2.x * 6.283) * 6.283) * sway
                R = R * rot(a, simd_float3(1, 0, 0)) * rot(a * 0.6, simd_float3(0, 0, 1))
            }
            R = R * fix
            R.columns.0 *= s; R.columns.1 *= sy; R.columns.2 *= s
            let pos = p.pos + p.n * (lift + (p.r2.y - 0.5) * 2 * liftR)
            R.columns.3 = simd_float4(pos, 1)
            out.append(R)
        }
        return out
    }

    /// Everything the renderers need in one call. `nil` when scattering is off or has no valid target.
    static func instances(_ l: Layer, target: Layer?, tris: [Tri], targetM: simd_float4x4, time: Float) -> [simd_float4x4]? {
        guard l.xf("scOn", 0) > 0.5, target != nil, !tris.isEmpty else { return nil }
        return matrices(l, placements(l, tris: tris, targetM: targetM), time: time)
    }
}
