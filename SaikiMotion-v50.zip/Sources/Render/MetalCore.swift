//  MetalCore.swift
//  Metal foundation (migration stage 2). Nothing here is used by the GL
//  renderer yet; it sits beside it behind RenderBackend.useMetal.

import Foundation
import Metal
import UIKit

/// Backend switch. Default is GL, so the app behaves exactly as before.
/// Flip with: UserDefaults.standard.set(true, forKey: "useMetalRenderer")
enum RenderBackend {
    static let key = "useMetalRenderer"
    /// Scatter (and anything else only the Metal renderer does) forces Metal even when the flag is off.
    static func needsMetal(_ scene: Scene) -> Bool {
        MetalCore.shared != nil && scene.layers.contains { $0.type == .MODEL && $0.xf("scOn", 0) > 0.5 }
    }
    static var useMetal: Bool {
        get { UserDefaults.standard.bool(forKey: key) && MetalCore.shared != nil }
        set { UserDefaults.standard.set(newValue, forKey: key) }
    }
}

/// Device + command queue shared by every Metal pass.
final class MetalCore {
    /// nil when the device has no Metal (e.g. some simulators); callers must fall back to GL.
    static let shared: MetalCore? = MetalCore()

    let device: MTLDevice
    let queue: MTLCommandQueue
    /// True on A14+/M1+ GPUs. Stage 7 uses this to pick ray tracing vs the screen-space fallback.
    let supportsRaytracing: Bool
    /// Compiled lazily from .metal files in later stages.
    lazy var library: MTLLibrary? = device.makeDefaultLibrary()

    private init?() {
        guard let d = MTLCreateSystemDefaultDevice(), let q = d.makeCommandQueue() else { return nil }
        device = d
        queue = q
        supportsRaytracing = d.supportsRaytracing
        q.label = "SaikiMotion.queue"
    }

    /// One line describing the GPU, for debug/status text.
    var status: String {
        "Metal: \(device.name), raytracing=\(supportsRaytracing)"
    }

    /// Clears a small target and reads it back; true if Metal round-trips correctly.
    static func selfTest() -> Bool {
        guard let core = shared else { return false }
        let t = MetalTarget(core, 4, 4)
        guard let cb = core.queue.makeCommandBuffer() else { return false }
        let pd = t.passDescriptor(clear: MTLClearColor(red: 1, green: 0, blue: 0, alpha: 1))
        cb.makeRenderCommandEncoder(descriptor: pd)?.endEncoding()
        cb.commit()
        cb.waitUntilCompleted()
        var px = [UInt8](repeating: 0, count: 4)
        t.tex.getBytes(&px, bytesPerRow: 16, from: MTLRegionMake2D(0, 0, 1, 1), mipmapLevel: 0)
        return px[0] == 255 && px[1] == 0 && px[2] == 0 && px[3] == 255
    }
}

/// Metal counterpart of Gl.Target: an offscreen colour target backed by an MTLTexture.
/// Same width/height/half semantics. Note Metal's origin is top-left (GL is bottom-left),
/// so readImage() needs no row flip; passes ported later must account for the UV flip.
final class MetalTarget {
    let core: MetalCore
    let width: Int
    let height: Int
    let half: Bool
    /// var so a composite can swap two targets instead of copying (mirrors Gl.Target).
    var tex: MTLTexture

    init(_ core: MetalCore, _ w: Int, _ h: Int, half: Bool = false) {
        self.core = core
        width = max(1, w)
        height = max(1, h)
        self.half = half
        let d = MTLTextureDescriptor.texture2DDescriptor(
            pixelFormat: half ? .rgba16Float : .rgba8Unorm,
            width: width, height: height, mipmapped: false)
        d.usage = [.renderTarget, .shaderRead, .shaderWrite]
        d.storageMode = .private
        // Metal always supports fp16 render targets on iOS, so no GL-style fallback is needed.
        // .private is fastest on GPU; readImage() blits to a shared buffer when needed.
        tex = core.device.makeTexture(descriptor: d)!
    }

    /// Render pass writing into this target (replaces Gl.Target.bind()).
    func passDescriptor(clear: MTLClearColor? = nil) -> MTLRenderPassDescriptor {
        let pd = MTLRenderPassDescriptor()
        pd.colorAttachments[0].texture = tex
        if let c = clear {
            pd.colorAttachments[0].loadAction = .clear
            pd.colorAttachments[0].clearColor = c
        } else {
            pd.colorAttachments[0].loadAction = .load
        }
        pd.colorAttachments[0].storeAction = .store
        return pd
    }

    /// Reads the pixels back as a UIImage (RGBA8 targets only; fp16 is converted by a blit pass later).
    func readImage() -> UIImage? {
        guard !half else { return nil }
        let row = width * 4
        guard let buf = core.device.makeBuffer(length: row * height, options: .storageModeShared),
              let cb = core.queue.makeCommandBuffer(),
              let blit = cb.makeBlitCommandEncoder() else { return nil }
        blit.copy(from: tex, sourceSlice: 0, sourceLevel: 0,
                  sourceOrigin: MTLOrigin(x: 0, y: 0, z: 0),
                  sourceSize: MTLSize(width: width, height: height, depth: 1),
                  to: buf, destinationOffset: 0,
                  destinationBytesPerRow: row, destinationBytesPerImage: row * height)
        blit.endEncoding()
        cb.commit()
        cb.waitUntilCompleted()
        let data = Data(bytes: buf.contents(), count: row * height)
        guard let provider = CGDataProvider(data: data as CFData),
              let img = CGImage(width: width, height: height, bitsPerComponent: 8, bitsPerPixel: 32,
                                bytesPerRow: row, space: CGColorSpaceCreateDeviceRGB(),
                                bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.premultipliedLast.rawValue),
                                provider: provider, decode: nil, shouldInterpolate: false,
                                intent: .defaultIntent) else { return nil }
        return UIImage(cgImage: img)
    }
}
