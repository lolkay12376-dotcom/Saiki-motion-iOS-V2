import Foundation
import Metal
import simd
import UIKit
import OpenGLES

//  Stage 6b: GLB / glTF / OBJ / animated-ABC models in Metal (port of GlbModel.draw + the GL PBR shader).
//  GlbModel is loaded with cpuOnly = true (no GL calls); this file uploads its CPU data to Metal.
//  VDB volumes stay in GL.

enum MetalModelSL {
    /// Port of GlbModel.vertexSource / fragmentSource. Clip z is remapped from the GL range [-w, w]
    /// to Metal's [0, w]. Vertices are read from a plain float buffer (12 floats per vertex).
    static let source = MetalSL.header + """
struct ModelU {
    float4 vp0; float4 vp1; float4 vp2; float4 vp3;     // uVP columns
    float4 m0; float4 m1; float4 m2; float4 m3;         // uModel columns
    float4 color;     // uColor
    float4 emis;      // uEmis.xyz
    float4 eye;       // uEye.xyz
    float4 prm;       // metal, rough, cutoff, unlit
    float4 has;       // base, metal-rough, emissive, occlusion texture present
    float4 opt;       // env, metallic reflectivity, view mode, ao strength
    float4 xtra;      // exposure, rt ao, rt shadow, -
};
struct MOut { float4 pos [[position]]; float psize [[point_size]]; float3 n; float3 w; float2 uv; float4 col; };

vertex MOut modelVertex(uint vid [[vertex_id]], constant ModelU& u [[buffer(0)]],
                        const device float* vb [[buffer(1)]]) {
    uint b = vid * 12u;
    float3 aPos = float3(vb[b], vb[b + 1u], vb[b + 2u]);
    float3 aNormal = float3(vb[b + 3u], vb[b + 4u], vb[b + 5u]);
    float2 aUv = float2(vb[b + 6u], vb[b + 7u]);
    float4 aCol = float4(vb[b + 8u], vb[b + 9u], vb[b + 10u], vb[b + 11u]);
    float4 wp = u.m0 * aPos.x + u.m1 * aPos.y + u.m2 * aPos.z + u.m3;
    float4 c = u.vp0 * wp.x + u.vp1 * wp.y + u.vp2 * wp.z + u.vp3 * wp.w;
    c.z = (c.z + c.w) * 0.5;
    MOut o;
    o.pos = c;
    o.psize = 3.0;
    o.w = wp.xyz;
    float3 n = u.m0.xyz * aNormal.x + u.m1.xyz * aNormal.y + u.m2.xyz * aNormal.z;
    o.n = dot(n, n) > 1e-8 ? normalize(n) : float3(0.0, 1.0, 0.0);
    o.uv = aUv;
    o.col = aCol;
    return o;
}

constant float mPI = 3.14159265;
constant float3 mL1 = float3(0.4170, 0.6672, 0.6672);
constant float3 mL2 = float3(-0.8704, 0.2176, 0.4352);

inline float3 mEnv(float3 d, float r) {
    float h = d.y * 0.5 + 0.5;
    float3 c = mix(float3(0.14, 0.13, 0.15), float3(0.78, 0.80, 0.84), smoothstep(0.0, 0.5, h));
    c = mix(c, float3(0.55, 0.68, 0.95), smoothstep(0.5, 1.0, h));
    float sun = pow(max(dot(d, mL1), 0.0), mix(150.0, 5.0, r)) * mix(8.0, 0.6, r);
    return c + float3(1.0, 0.93, 0.82) * sun;
}

inline float3 mBrdf(float3 N, float3 V, float3 L, float3 diffC, float3 F0, float r) {
    float3 H = normalize(V + L);
    float NdL = max(dot(N, L), 0.0);
    float NdV = max(dot(N, V), 0.001);
    float NdH = max(dot(N, H), 0.0);
    float VdH = max(dot(V, H), 0.0);
    float a = r * r;
    float a2 = a * a;
    float dd = NdH * NdH * (a2 - 1.0) + 1.0;
    float D = a2 / (mPI * dd * dd + 0.0001);
    float k = (r + 1.0) * (r + 1.0) / 8.0;
    float G = (NdL / (NdL * (1.0 - k) + k)) * (NdV / (NdV * (1.0 - k) + k));
    float3 F = F0 + (1.0 - F0) * pow(1.0 - VdH, 5.0);
    float3 spec = D * G * F / max(4.0 * NdV * NdL, 0.001);
    return ((1.0 - F) * diffC / mPI + spec) * NdL;
}

fragment float4 modelFragment(MOut in [[stage_in]], constant ModelU& u [[buffer(0)]],
                              texture2d<float> tBase [[texture(0)]], texture2d<float> tMR [[texture(1)]],
                              texture2d<float> tEm [[texture(2)]], texture2d<float> tOcc [[texture(3)]],
                              sampler sBase [[sampler(0)]], sampler sMR [[sampler(1)]],
                              sampler sEm [[sampler(2)]], sampler sOcc [[sampler(3)]]) {
    float a = u.color.a * in.col.a;
    float3 tint = u.color.rgb * pow(max(in.col.rgb, float3(0.0)), float3(2.2));
    float3 alb = tint;
    if (u.has.x > 0.5) {
        float4 t = tBase.sample(sBase, in.uv);
        a *= t.a;
        alb *= pow(clamp(t.rgb / max(t.a, 0.001), 0.0, 1.0), float3(2.2));
    }
    if (u.prm.z >= 0.0) {
        if (a < u.prm.z) { discard_fragment(); }
        a = 1.0;
    }
    float metal = u.prm.x * u.opt.y;
    float rough = u.prm.y;
    float ao = 1.0;
    if (u.has.w > 0.5) { ao = mix(1.0, tOcc.sample(sOcc, in.uv).r, u.opt.w); }
    if (u.has.y > 0.5) {
        float4 m = tMR.sample(sMR, in.uv);
        rough *= m.g;
        metal *= m.b * u.opt.y;
    }
    rough = clamp(rough, 0.04, 1.0);
    metal = clamp(metal, 0.0, 1.0);

    float3 N = normalize(in.n);
    float3 V = normalize(u.eye.xyz - in.w);
    if (dot(N, V) < 0.0) { N = -N; }
    if (u.xtra.w > 0.0 && u.has.w > 0.5) {      // Extras PBR: normal XY packed in the occlusion texture's G / B
        float2 nxy = (tOcc.sample(sOcc, in.uv).gb * 2.0 - 1.0) * u.xtra.w;
        float3 dp1 = dfdx(in.w), dp2 = dfdy(in.w);
        float2 du1 = dfdx(in.uv), du2 = dfdy(in.uv);
        float3 p2 = cross(dp2, N), p1 = cross(N, dp1);
        float3 T = p2 * du1.x + p1 * du2.x, B = p2 * du1.y + p1 * du2.y;
        float inv = rsqrt(max(max(dot(T, T), dot(B, B)), 1e-12));
        N = normalize(T * inv * nxy.x + B * inv * nxy.y + N * sqrt(max(1.0 - dot(nxy, nxy), 0.05)));
    }
    float NdV = max(dot(N, V), 0.001);

    float3 F0 = mix(float3(0.04), alb, metal);
    float3 diffC = alb * (1.0 - metal);
    float3 col = mBrdf(N, V, mL1, diffC, F0, rough) * float3(3.2, 3.0, 2.8) * u.eye.w
               + mBrdf(N, V, mL2, diffC, F0, rough) * float3(0.9, 1.0, 1.3);
    float3 R = reflect(-V, N);
    float3 Fr = F0 + (max(float3(1.0 - rough), F0) - F0) * pow(1.0 - NdV, 5.0);
    if (u.opt.x > 0.5) {
        col += diffC * mEnv(N, 1.0) * 0.8 * ao * u.emis.w;
        col += mEnv(R, rough) * Fr * (1.0 - 0.5 * rough) * ao * u.emis.w;
    } else {
        col += diffC * 0.3 * ao;
    }
    float3 em = u.emis.xyz;
    if (u.has.z > 0.5) { em *= pow(tEm.sample(sEm, in.uv).rgb, float3(2.2)); }
    col += em;
    col = mix(col, alb + em, u.prm.w);
    if (u.opt.z > 0.5) {
        float3 v = alb;
        if (u.opt.z > 1.5) { v = float3(rough); }
        if (u.opt.z > 2.5) { v = float3(metal); }
        if (u.opt.z > 3.5) { v = float3(ao); }
        if (u.opt.z > 4.5) { v = em; }
        return float4(pow(max(v, float3(0.0)), float3(1.0 / 2.2)) * a, a);
    }
    col *= u.xtra.x;
    col = col * (1.0 + col / 6.0) / (1.0 + col);
    col = pow(max(col, float3(0.0)), float3(1.0 / 2.2));
    return float4(col * a, a);
}
"""
}

extension MetalModelSL {
    /// Same shader plus hardware ray-traced shadows / ambient occlusion against the model's own triangles.
    static var rtSource: String {
        var s = source
        s = s.replacingOccurrences(of: "struct ModelU {", with: "#include <metal_raytracing>\nusing namespace metal::raytracing;\nstruct ModelU {")
        s = s.replacingOccurrences(of: "fragment float4 modelFragment(", with: "fragment float4 modelFragmentRT(")
        s = s.replacingOccurrences(of: "sampler sEm [[sampler(2)]], sampler sOcc [[sampler(3)]]) {",
            with: "sampler sEm [[sampler(2)]], sampler sOcc [[sampler(3)]],\n primitive_acceleration_structure acc [[buffer(2)]], constant float4& rtp [[buffer(3)]], constant float4x4& rinv [[buffer(4)]]) {")
        let code = """
    float rtVis = 1.0; float rtAo = 1.0;
    if (rtp.x > 0.0) {
        float sc = max(length(rinv[0].xyz), 1e-6);
        float3 Pw = in.w + N * 0.004;
        intersector<triangle_data> it;
        it.assume_geometry_type(geometry_type::triangle);
        ray r;
        r.origin = (rinv * float4(Pw, 1.0)).xyz;
        r.min_distance = 0.0005 * sc;
        float sh = 0.0;
        r.max_distance = 1.0e4;
        r.direction = normalize((rinv * float4(mL1, 0.0)).xyz);
        if (it.intersect(r, acc).type == intersection_type::triangle) { sh = 1.0; }
        rtVis = 1.0 - sh * u.xtra.z;
        float3 T = normalize(abs(N.y) < 0.9 ? cross(N, float3(0.0, 1.0, 0.0)) : cross(N, float3(1.0, 0.0, 0.0)));
        float3 Bt = cross(N, T);
        float occl = 0.0;
        for (int k = 0; k < 8; k++) {
            float a2 = float(k) * 0.7853982;
            float el = (k & 1) == 0 ? 0.45 : 0.85;
            float3 dw = normalize(N * el + (T * cos(a2) + Bt * sin(a2)) * (1.0 - el));
            r.direction = normalize((rinv * float4(dw, 0.0)).xyz);
            r.max_distance = max(rtp.y, 0.01) * sc;
            if (it.intersect(r, acc).type == intersection_type::triangle) { occl += 1.0; }
        }
        rtAo = 1.0 - (occl / 8.0) * u.xtra.y;
    }
    col *= rtVis; ao *= rtAo;
    float3 R = reflect(-V, N);
"""
        s = s.replacingOccurrences(of: "    float3 R = reflect(-V, N);\n", with: code)
        return s
    }
}

/// Must match ModelU in MSL (14 x float4 = 224 bytes).
struct ModelU {
    var vp0 = SIMD4<Float>(0, 0, 0, 0), vp1 = SIMD4<Float>(0, 0, 0, 0)
    var vp2 = SIMD4<Float>(0, 0, 0, 0), vp3 = SIMD4<Float>(0, 0, 0, 0)
    var m0 = SIMD4<Float>(0, 0, 0, 0), m1 = SIMD4<Float>(0, 0, 0, 0)
    var m2 = SIMD4<Float>(0, 0, 0, 0), m3 = SIMD4<Float>(0, 0, 0, 0)
    var color = SIMD4<Float>(1, 1, 1, 1)
    var emis = SIMD4<Float>(0, 0, 0, 0)
    var eye = SIMD4<Float>(0, 0, 3, 0)
    var prm = SIMD4<Float>(0, 0.8, -1, 0)
    var has = SIMD4<Float>(0, 0, 0, 0)
    var opt = SIMD4<Float>(1, 1, 0, 1)
    var xtra = SIMD4<Float>(1, 1, 1, 0)
}

/// GPU copy of one GlbModel (loaded with GlbModel.cpuOnly).
final class MetalModel {
    struct P {
        var vbuf: MTLBuffer?
        var ibuf: MTLBuffer
        var count: Int
        var idx32: Bool
        var points: Bool
        var srcIndex: Int            // index into src.prims
        var tex: [MTLTexture?]       // base, metal-rough, emissive, occlusion
        var clamp: [Bool]
    }
    let src: GlbModel
    private(set) var prims: [P] = []
    var accel: MTLAccelerationStructure?

    init?(_ src: GlbModel, core: MetalCore) {
        self.src = src
        var texById: [UInt32: MTLTexture] = [:]
        var used: [UInt32] = []
        func tex(_ id: UInt32) -> (MTLTexture?, Bool) {
            guard id != 0, let e = GlbModel.cpuImages[id] else { return (nil, false) }
            used.append(id)
            if let t = texById[id] { return (t, e.clamp) }
            guard let t = MetalModel.makeTexture(core, e.img) else { return (nil, e.clamp) }
            texById[id] = t
            return (t, e.clamp)
        }
        for (si, sp) in src.prims.enumerated() {
            guard !sp.verts.isEmpty, !sp.cpuIdx.isEmpty else { continue }
            let idx32 = sp.indexType != GLenum(GL_UNSIGNED_SHORT)
            let ib: MTLBuffer?
            if idx32 {
                ib = sp.cpuIdx.withUnsafeBytes { core.device.makeBuffer(bytes: $0.baseAddress!, length: $0.count, options: .storageModeShared) }
            } else {
                let small = sp.cpuIdx.map { UInt16(truncatingIfNeeded: $0) }
                ib = small.withUnsafeBytes { core.device.makeBuffer(bytes: $0.baseAddress!, length: $0.count, options: .storageModeShared) }
            }
            guard let ibuf = ib else { continue }
            let t0 = tex(UInt32(sp.texBase)), t1 = tex(UInt32(sp.texMR)), t2 = tex(UInt32(sp.texEm)), t3 = tex(UInt32(sp.texOcc))
            prims.append(P(vbuf: nil, ibuf: ibuf, count: sp.cpuIdx.count, idx32: idx32,
                           points: sp.mode == GLenum(GL_POINTS), srcIndex: si,
                           tex: [t0.0, t1.0, t2.0, t3.0], clamp: [t0.1, t1.1, t2.1, t3.1]))
        }
        for id in used { GlbModel.cpuImages[id] = nil }       // CPU copies are no longer needed
        if prims.isEmpty { return nil }
    }

    /// RGBA8 premultiplied texture with a mip chain (GL generated mipmaps on ES3).
    static func makeTexture(_ core: MetalCore, _ image: UIImage) -> MTLTexture? {
        guard let cg = image.cgImage, cg.width > 0, cg.height > 0 else { return nil }
        let sc = min(1.0, 2048.0 / Double(max(cg.width, cg.height)))
        let w = max(1, Int(Double(cg.width) * sc)), h = max(1, Int(Double(cg.height) * sc))
        var data = [UInt8](repeating: 0, count: w * h * 4)
        let drew: Bool = data.withUnsafeMutableBytes { raw -> Bool in
            guard let ctx = CGContext(data: raw.baseAddress, width: w, height: h, bitsPerComponent: 8,
                                      bytesPerRow: w * 4, space: CGColorSpaceCreateDeviceRGB(),
                                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            ctx.setBlendMode(.copy)
            ctx.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h))
            return true
        }
        guard drew else { return nil }
        let d = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .rgba8Unorm, width: w, height: h, mipmapped: true)
        d.usage = .shaderRead
        d.storageMode = .shared
        guard let t = core.device.makeTexture(descriptor: d) else { return nil }
        data.withUnsafeBytes {
            t.replace(region: MTLRegionMake2D(0, 0, w, h), mipmapLevel: 0, withBytes: $0.baseAddress!, bytesPerRow: w * 4)
        }
        if t.mipmapLevelCount > 1, let cbuf = core.queue.makeCommandBuffer(), let blit = cbuf.makeBlitCommandEncoder() {
            blit.generateMipmaps(for: t)
            blit.endEncoding()
            cbuf.commit()
        }
        return t
    }
}

/// Draws model layers into a layer target with a shared depth buffer (GL drawModelLayer).
final class MetalModelRenderer {
    private let core: MetalCore
    private var lib: MTLLibrary?
    private var rtLib: MTLLibrary?
    /// "" when ray tracing is ready, else why it is not (shown in the 3D editor's Properties).
    static var rtStatus = ""
    private var psos: [String: MTLRenderPipelineState] = [:]
    private var dsWrite: MTLDepthStencilState?
    private var dsNoWrite: MTLDepthStencilState?
    private var smpRepeat: MTLSamplerState?
    private var smpClamp: MTLSamplerState?
    private var dummy: MTLTexture?
    private var depthTex: MTLTexture?
    private var cache: [String: MetalModel] = [:]
    private var failed = Set<String>()
    /// Paths whose texture files changed: dropped from the cache on the next load.
    static var evict = Set<String>()
    /// Cleared at frame start and per motion-blur sample: the next model draw clears the depth buffer.
    var depthDirty = true

    init(_ core: MetalCore) {
        self.core = core
        lib = try? core.device.makeLibrary(source: MetalModelSL.source, options: nil)
        if !core.device.supportsRaytracing { MetalModelRenderer.rtStatus = "This device's GPU has no hardware ray tracing (needs A13 or newer)." }
        else {
            let o = MTLCompileOptions()
            if #available(iOS 15.0, *) { o.languageVersion = .version2_4 } else { o.languageVersion = .version2_3 }
            do { rtLib = try core.device.makeLibrary(source: MetalModelSL.rtSource, options: o); MetalModelRenderer.rtStatus = "" }
            catch { MetalModelRenderer.rtStatus = "Ray tracing shader failed: \(error.localizedDescription)" }
        }
        let dw = MTLDepthStencilDescriptor()
        dw.depthCompareFunction = .lessEqual; dw.isDepthWriteEnabled = true
        dsWrite = core.device.makeDepthStencilState(descriptor: dw)
        let dn = MTLDepthStencilDescriptor()
        dn.depthCompareFunction = .lessEqual; dn.isDepthWriteEnabled = false
        dsNoWrite = core.device.makeDepthStencilState(descriptor: dn)
        func sampler(_ clamp: Bool) -> MTLSamplerState? {
            let d = MTLSamplerDescriptor()
            d.minFilter = .linear; d.magFilter = .linear; d.mipFilter = .linear
            d.sAddressMode = clamp ? .clampToEdge : .repeat
            d.tAddressMode = clamp ? .clampToEdge : .repeat
            d.maxAnisotropy = 4
            return core.device.makeSamplerState(descriptor: d)
        }
        smpRepeat = sampler(false); smpClamp = sampler(true)
        let td = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .rgba8Unorm, width: 1, height: 1, mipmapped: false)
        td.usage = .shaderRead
        dummy = core.device.makeTexture(descriptor: td)
        var px: [UInt8] = [255, 255, 255, 255]
        dummy?.replace(region: MTLRegionMake2D(0, 0, 1, 1), mipmapLevel: 0, withBytes: &px, bytesPerRow: 4)
    }

    var ready: Bool { lib != nil && dsWrite != nil && dsNoWrite != nil && smpRepeat != nil && smpClamp != nil && dummy != nil }

    func trimMemory() { cache.removeAll(); depthTex = nil }

    /// The shared depth buffer when a model has drawn since the last clear (volume occlusion), else nil.
    func occlusionDepth() -> MTLTexture? { depthDirty ? nil : depthTex }

    private func loadModel(for path: String) -> MetalModel? {
        if MetalModelRenderer.evict.remove(path) != nil { cache[path] = nil; failed.remove(path) }
        if let m = cache[path] { return m }
        if failed.contains(path) { return nil }
        let p = GlbModel.validate(path: path)
        GlbModel.cpuOnly = true
        defer { GlbModel.cpuOnly = false }
        guard let g = GlbModel.load(p), let m = MetalModel(g, core: core) else {
            failed.insert(path)
            return nil
        }
        cache[path] = m
        cache[p] = m
        return m
    }

    private func pso(blend: Bool, format: MTLPixelFormat, rt: Bool = false) -> MTLRenderPipelineState? {
        let key = "\(blend)/\(format.rawValue)/\(rt)"
        if let p = psos[key] { return p }
        guard let lib = rt ? rtLib : lib, let vf = lib.makeFunction(name: "modelVertex"),
              let ff = lib.makeFunction(name: rt ? "modelFragmentRT" : "modelFragment") else { return nil }
        let d = MTLRenderPipelineDescriptor()
        d.vertexFunction = vf
        d.fragmentFunction = ff
        d.colorAttachments[0].pixelFormat = format
        d.depthAttachmentPixelFormat = .depth32Float
        if blend {
            let c = d.colorAttachments[0]!
            c.isBlendingEnabled = true
            c.sourceRGBBlendFactor = .one; c.destinationRGBBlendFactor = .oneMinusSourceAlpha
            c.sourceAlphaBlendFactor = .one; c.destinationAlphaBlendFactor = .oneMinusSourceAlpha
        }
        guard let p = try? core.device.makeRenderPipelineState(descriptor: d) else { return nil }
        psos[key] = p
        return p
    }

    private func depth(_ w: Int, _ h: Int) -> MTLTexture? {
        if let t = depthTex, t.width == w, t.height == h { return t }
        let d = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .depth32Float, width: w, height: h, mipmapped: false)
        d.usage = [.renderTarget, .shaderRead]
        d.storageMode = .private
        depthTex = core.device.makeTexture(descriptor: d)
        depthDirty = true
        return depthTex
    }

    private func buildAccel(_ model: MetalModel, vbufs: [MTLBuffer?], cb: MTLCommandBuffer) -> MTLAccelerationStructure? {
        var geos: [MTLAccelerationStructureTriangleGeometryDescriptor] = []
        for (i, p) in model.prims.enumerated() where !p.points && i < vbufs.count {
            guard let vb = vbufs[i], p.count >= 3 else { continue }
            let g = MTLAccelerationStructureTriangleGeometryDescriptor()
            g.vertexBuffer = vb; g.vertexStride = 48
            g.indexBuffer = p.ibuf; g.indexType = p.idx32 ? .uint32 : .uint16
            g.triangleCount = p.count / 3
            g.opaque = true
            geos.append(g)
        }
        if geos.isEmpty { return nil }
        let d = MTLPrimitiveAccelerationStructureDescriptor()
        d.geometryDescriptors = geos
        let sz = core.device.accelerationStructureSizes(descriptor: d)
        guard let acc = core.device.makeAccelerationStructure(size: sz.accelerationStructureSize),
              let scratch = core.device.makeBuffer(length: max(sz.buildScratchBufferSize, 16), options: .storageModePrivate),
              let e = cb.makeAccelerationStructureCommandEncoder() else { return nil }
        e.build(accelerationStructure: acc, descriptor: d, scratchBuffer: scratch, scratchBufferOffset: 0)
        e.endEncoding()
        return acc
    }

    /// Draws model layer `l` (glb / gltf / obj / abc) into `target` (which the caller has cleared).
    func draw(_ l: Layer, time: Float, fov: Float, into target: MetalTarget, cb: MTLCommandBuffer) {
        guard ready, let path = l.imagePath, let model = loadModel(for: path),
              let dtex = depth(target.width, target.height) else { return }
        model.src.setAnimTime(max(0, time - l.start))
        let vp = MetalCam.vpForModel(l, fov: fov, time: time, width: target.width, height: target.height)
        let mm = MetalCam.modelMatrix(l, time: time, normalize: model.src.normalize)
        let eye = GlbModel.eye(fromVP: vp)
        guard vp.count == 16, mm.count == 16 else { return }

        var base = ModelU()
        base.vp0 = SIMD4(vp[0], vp[1], vp[2], vp[3]); base.vp1 = SIMD4(vp[4], vp[5], vp[6], vp[7])
        base.vp2 = SIMD4(vp[8], vp[9], vp[10], vp[11]); base.vp3 = SIMD4(vp[12], vp[13], vp[14], vp[15])
        base.m0 = SIMD4(mm[0], mm[1], mm[2], mm[3]); base.m1 = SIMD4(mm[4], mm[5], mm[6], mm[7])
        base.m2 = SIMD4(mm[8], mm[9], mm[10], mm[11]); base.m3 = SIMD4(mm[12], mm[13], mm[14], mm[15])
        base.eye = SIMD4(eye[0], eye[1], eye[2], l.xf("light", 1) * R3D.g("light", 1))
        base.opt = SIMD4(l.m3Env ? 1 : 0, l.m3Metal ? 1 : 0, Float(l.m3View), l.m3Ao ? 1 : 0)

        let animated = model.src.isAnimated
        var vbufs: [MTLBuffer?] = []
        for (i, p) in model.prims.enumerated() {
            guard p.srcIndex < model.src.prims.count else { vbufs.append(nil); continue }
            let sp = model.src.prims[p.srcIndex]
            var vbuf = p.vbuf
            if vbuf == nil || (animated && sp.slot >= 0) {
                vbuf = sp.verts.withUnsafeBytes { core.device.makeBuffer(bytes: $0.baseAddress!, length: $0.count, options: .storageModeShared) }
            }
            if let vb = vbuf, p.vbuf == nil && !(animated && sp.slot >= 0) { model.setVBuf(i, vb) }
            vbufs.append(vbuf)
        }
        // ray tracing: this layer's own switch, or the active camera's
        var rtI: Float = l.rtOn ? l.rtInt : 0
        var rtR: Float = l.rtRad
        if let cam = Xf.camera(for: l), cam.rtOn { rtI = max(rtI, cam.rtInt); rtR = cam.rtRad }
        if R3D.g("rtAll", 0) > 0.5 { rtI = max(rtI, R3D.g("rtMul", 1)) }
        base.xtra = SIMD4(l.xf("exposure", 1) * R3D.g("exposure", 1), min(rtI * l.xf("rtAo", 1), 1), min(rtI * l.xf("rtShadow", 1), 1), l.xf("pbrNorm", 0))
        var accel: MTLAccelerationStructure? = nil
        if rtI > 0.001, rtLib != nil {
            if animated || model.accel == nil { model.accel = buildAccel(model, vbufs: vbufs, cb: cb) }
            accel = model.accel
        }
        let m4 = simd_float4x4(SIMD4(mm[0], mm[1], mm[2], mm[3]), SIMD4(mm[4], mm[5], mm[6], mm[7]),
                               SIMD4(mm[8], mm[9], mm[10], mm[11]), SIMD4(mm[12], mm[13], mm[14], mm[15]))
        var invM = m4.inverse
        var rtp = SIMD4<Float>(min(rtI, 1), rtR, 0, 0)

        let pd = MTLRenderPassDescriptor()
        pd.colorAttachments[0].texture = target.tex
        pd.colorAttachments[0].loadAction = .load
        pd.colorAttachments[0].storeAction = .store
        pd.depthAttachment.texture = dtex
        pd.depthAttachment.loadAction = depthDirty ? .clear : .load
        pd.depthAttachment.clearDepth = 1
        pd.depthAttachment.storeAction = .store
        depthDirty = false
        guard let enc = cb.makeRenderCommandEncoder(descriptor: pd) else { return }
        enc.setCullMode(.none)

        if let a = accel { enc.useResource(a, usage: .read) }
        var instMs: [simd_float4x4] = [m4]
        if let sc = scatterMatrices(l, model: model, time: time) { instMs = sc }
        for im in instMs {
        base.m0 = im.columns.0; base.m1 = im.columns.1; base.m2 = im.columns.2; base.m3 = im.columns.3
        invM = im.inverse
        for (i, p) in model.prims.enumerated() where p.srcIndex < model.src.prims.count {
            let sp = model.src.prims[p.srcIndex]
            let rtPS = accel != nil ? pso(blend: sp.blend, format: target.tex.pixelFormat, rt: true) : nil
            guard let ps = rtPS ?? pso(blend: sp.blend, format: target.tex.pixelFormat) else { continue }
            guard i < vbufs.count, let vb = vbufs[i] else { continue }

            var u = base
            u.color = SIMD4(sp.color[0], sp.color[1], sp.color[2], sp.color[3])
            u.emis = SIMD4(sp.emissive[0], sp.emissive[1], sp.emissive[2], l.xf("env", 1) * R3D.g("env", 1))
            u.prm = SIMD4(sp.metal, sp.rough, sp.cutoff, sp.unlit)
            u.has = SIMD4(p.tex[0] != nil ? 1 : 0, p.tex[1] != nil ? 1 : 0, p.tex[2] != nil ? 1 : 0, p.tex[3] != nil ? 1 : 0)
            enc.setRenderPipelineState(ps)
            enc.setDepthStencilState(sp.blend ? dsNoWrite : dsWrite)
            enc.setVertexBytes(&u, length: MemoryLayout<ModelU>.stride, index: 0)
            enc.setFragmentBytes(&u, length: MemoryLayout<ModelU>.stride, index: 0)
            enc.setVertexBuffer(vb, offset: 0, index: 1)
            if rtPS != nil, let a = accel {
                enc.setFragmentAccelerationStructure(a, bufferIndex: 2)
                enc.setFragmentBytes(&rtp, length: 16, index: 3)
                enc.setFragmentBytes(&invM, length: 64, index: 4)
            }
            for k in 0..<4 {
                enc.setFragmentTexture(p.tex[k] ?? dummy, index: k)
                enc.setFragmentSamplerState(p.clamp[k] ? smpClamp : smpRepeat, index: k)
            }
            enc.drawIndexedPrimitives(type: p.points ? .point : .triangle, indexCount: p.count,
                                      indexType: p.idx32 ? .uint32 : .uint16, indexBuffer: p.ibuf, indexBufferOffset: 0)
        }
        }
        enc.endEncoding()
    }

    /// Scatter: raw world instance matrices for layer `l` (no model normalisation), or nil = not scattering.
    func scatterWorld(_ l: Layer, time: Float) -> [simd_float4x4]? {
        guard l.xf("scOn", 0) > 0.5 else { return nil }
        let tid = Int(l.xf("scTarget", -1))
        func f4(_ m: [Float]) -> simd_float4x4 { simd_float4x4(SIMD4(m[0], m[1], m[2], m[3]), SIMD4(m[4], m[5], m[6], m[7]), SIMD4(m[8], m[9], m[10], m[11]), SIMD4(m[12], m[13], m[14], m[15])) }
        var tris: [Scatter.Tri], tm: simd_float4x4, tl: Layer = l
        if tid == -2 || tid == -3 {
            tris = Scatter.ground(l.xf("scGroundSize", 10), l.xf("scGroundY", 0)); tm = matrix_identity_float4x4
        } else {
            guard tid != l.id, let t = Editor.scene.layers.first(where: { $0.id == tid }) else { return nil }
            tl = t
            if tl.type == .MODEL {
                guard let tp = tl.imagePath, !tp.lowercased().hasSuffix(".vdb"), let t0 = loadModel(for: tp) else { return nil }
                let mm = MetalCam.modelMatrix(tl, time: time, normalize: t0.src.normalize)
                guard mm.count == 16 else { return nil }
                tris = Scatter.tris(t0.src); tm = f4(mm)
            } else {
                let (w, h) = Xf.quadSize(tl)
                let mm = MetalCam.modelMatrix(tl, time: time, normalize: [1, 0, 0, 0])
                guard mm.count == 16 else { return nil }
                tris = Scatter.quad(w, h); tm = f4(mm)
            }
        }
        return Scatter.instances(l, target: tl, tris: tris, targetM: tm, time: time)
    }

    /// Scatter: instance matrices (already including this model's normalisation), or nil = draw normally.
    private func scatterMatrices(_ l: Layer, model: MetalModel, time: Float) -> [simd_float4x4]? {
        guard var inst = scatterWorld(l, time: time) else { return nil }
        func f4(_ m: [Float]) -> simd_float4x4 { simd_float4x4(SIMD4(m[0], m[1], m[2], m[3]), SIMD4(m[4], m[5], m[6], m[7]), SIMD4(m[8], m[9], m[10], m[11]), SIMD4(m[12], m[13], m[14], m[15])) }
        let n = model.src.normalize
        var N = simd_float4x4(diagonal: SIMD4(n[0], n[0], n[0], 1))
        N.columns.3 = SIMD4(n[0] * n[1], n[0] * n[2], n[0] * n[3], 1)       // S(n0) · T(offset)
        inst = inst.map { $0 * N }
        if l.xf("scKeep", 0) > 0.5 { inst.append(f4(MetalCam.modelMatrix(l, time: time, normalize: model.src.normalize))) }
        return inst
    }
}

extension MetalModel {
    /// Caches the static vertex buffer of prim `i`.
    func setVBuf(_ i: Int, _ b: MTLBuffer) {
        guard i < prims.count else { return }
        prims[i].vbuf = b
    }
}
