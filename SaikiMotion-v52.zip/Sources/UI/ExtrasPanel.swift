// ExtrasPanel.swift — Scene 3D "+" > Extras: a flat plane or a cube textured with a Poly Haven PBR material.
//
// Downloads every map Poly Haven has for the material (colour, normal, roughness, metal, AO, displacement),
// packs them into the three texture slots the model renderer already has (so nothing extra is bound per
// draw), writes a tiny .glb and imports it as an ordinary model layer. The count slider turns it into an
// instanced scatter field (one draw call per primitive for any count, capped at 500), so it stays fast.
//
//   colour           -> glTF base colour
//   rough / metal    -> metal-rough texture (G = rough, B = metal)
//   AO * cavity(disp)-> occlusion texture R;  normal XY -> its G / B  (the shader rebuilds Z, see MetalModel)

import UIKit

// MARK: - Poly Haven

enum PolyHaven {
    static let ua = "SaikiMotion/1.0 (iOS video editor)"
    static let maxCount = 500
    static var listCache: [(id: String, name: String)] = []
    static let thumbs = NSCache<NSString, UIImage>()

    private static func req(_ url: String) -> URLRequest {
        var r = URLRequest(url: URL(string: url)!, timeoutInterval: 30)
        r.setValue(ua, forHTTPHeaderField: "User-Agent")
        return r
    }
    static func get(_ url: String, _ done: @escaping (Data?) -> Void) {
        URLSession.shared.dataTask(with: req(url)) { d, r, _ in
            let ok = (r as? HTTPURLResponse).map { (200..<300).contains($0.statusCode) } ?? false
            done(ok ? d : nil)
        }.resume()
    }

    static func list(_ done: @escaping ([(id: String, name: String)]) -> Void) {
        if !listCache.isEmpty { done(listCache); return }
        get("https://api.polyhaven.com/assets?t=textures") { d in
            guard let d = d, let o = (try? JSONSerialization.jsonObject(with: d)) as? [String: [String: Any]] else { done([]); return }
            let out = o.map { (id: $0.key, name: ($0.value["name"] as? String) ?? $0.key) }.sorted { $0.name.lowercased() < $1.name.lowercased() }
            listCache = out
            done(out)
        }
    }

    static func thumb(_ id: String, _ done: @escaping (UIImage?) -> Void) {
        if let i = thumbs.object(forKey: id as NSString) { done(i); return }
        get("https://cdn.polyhaven.com/asset_img/thumbs/\(id).png?width=128&height=128") { d in
            let i = d.flatMap { UIImage(data: $0) }
            if let i = i { thumbs.setObject(i, forKey: id as NSString) }
            DispatchQueue.main.async { done(i) }
        }
    }

    struct Maps { var diff: UIImage?, nor: UIImage?, rough: UIImage?, metal: UIImage?, ao: UIImage?, disp: UIImage? }

    /// Downloads all maps at `res` ("1k" / "2k"), falling back to the nearest resolution each map has.
    static func maps(_ id: String, res: String, _ done: @escaping (Maps?) -> Void) {
        get("https://api.polyhaven.com/files/\(id)") { d in
            guard let d = d, let files = (try? JSONSerialization.jsonObject(with: d)) as? [String: Any] else { done(nil); return }
            func url(_ keys: [String]) -> String? {
                for k in keys {
                    guard let m = files[k] as? [String: Any] else { continue }
                    for r in [res, "1k", "2k", "4k"] {
                        for f in ["jpg", "png"] {
                            if let u = ((m[r] as? [String: Any])?[f] as? [String: Any])?["url"] as? String { return u }
                        }
                    }
                }
                return nil
            }
            let want: [(String, [String])] = [("diff", ["Diffuse", "diff"]), ("nor", ["nor_gl", "Normal"]), ("rough", ["Rough"]),
                                              ("metal", ["Metal"]), ("ao", ["AO"]), ("disp", ["Displacement", "Bump"])]
            var got: [String: UIImage] = [:]
            let lock = NSLock(), grp = DispatchGroup()
            for (k, keys) in want {
                guard let u = url(keys) else { continue }
                grp.enter()
                get(u) { data in
                    if let data = data, let img = UIImage(data: data) { lock.lock(); got[k] = img; lock.unlock() }
                    grp.leave()
                }
            }
            grp.notify(queue: .global(qos: .userInitiated)) {
                guard got["diff"] != nil || got["nor"] != nil else { done(nil); return }
                done(Maps(diff: got["diff"], nor: got["nor"], rough: got["rough"], metal: got["metal"], ao: got["ao"], disp: got["disp"]))
            }
        }
    }
}

// MARK: - texture packing + glb

enum ExtrasGLB {
    /// RGBA8 pixels of `img` resampled to size x size (nil image -> nil).
    private static func px(_ img: UIImage?, _ size: Int) -> [UInt8]? {
        guard let cg = img?.cgImage else { return nil }
        var d = [UInt8](repeating: 255, count: size * size * 4)
        let ok = d.withUnsafeMutableBytes { raw -> Bool in
            guard let c = CGContext(data: raw.baseAddress, width: size, height: size, bitsPerComponent: 8, bytesPerRow: size * 4,
                                    space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            c.interpolationQuality = .high
            c.draw(cg, in: CGRect(x: 0, y: 0, width: size, height: size))
            return true
        }
        return ok ? d : nil
    }
    private static func png(_ d: [UInt8], _ size: Int) -> Data? {
        var d = d
        return d.withUnsafeMutableBytes { raw -> Data? in
            guard let c = CGContext(data: raw.baseAddress, width: size, height: size, bitsPerComponent: 8, bytesPerRow: size * 4,
                                    space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue),
                  let cg = c.makeImage() else { return nil }
            return UIImage(cgImage: cg).pngData()
        }
    }

    struct Packed { var base: Data?, mr: Data?, occ: Data?; var hasNormal: Bool }

    static func pack(_ m: PolyHaven.Maps, size: Int) -> Packed {
        let n = size * size
        let base = m.diff.flatMap { $0.jpegData(compressionQuality: 0.9) }   // colour keeps its own size; GPU loader caps at 2048
        let nor = px(m.nor, size), rough = px(m.rough, size), metal = px(m.metal, size), ao = px(m.ao, size), disp = px(m.disp, size)
        var mr: Data? = nil
        if rough != nil || metal != nil {
            var o = [UInt8](repeating: 255, count: n * 4)
            for i in 0..<n { o[i * 4 + 1] = rough?[i * 4] ?? 200; o[i * 4 + 2] = metal?[i * 4] ?? 0 }
            mr = png(o, size)
        }
        var occ: Data? = nil
        if nor != nil || ao != nil || disp != nil {
            var o = [UInt8](repeating: 255, count: n * 4)
            for i in 0..<n {
                var a = Float(ao?[i * 4] ?? 255) / 255
                if let d = disp { a *= 0.7 + 0.3 * Float(d[i * 4]) / 255 }      // displacement -> cavity shading (bump look)
                o[i * 4] = UInt8(max(0, min(255, a * 255)))
                o[i * 4 + 1] = nor?[i * 4] ?? 128; o[i * 4 + 2] = nor?[i * 4 + 1] ?? 128
            }
            occ = png(o, size)
        }
        return Packed(base: base, mr: mr, occ: occ, hasNormal: nor != nil)
    }

    static func build(cube: Bool, _ p: Packed?) -> Data {
        var pos: [Float] = [], nor: [Float] = [], uv: [Float] = [], idx: [UInt16] = []
        func face(_ n: (Float, Float, Float), _ u: (Float, Float, Float), _ v: (Float, Float, Float), _ d: Float) {
            let b = UInt16(pos.count / 3)
            let c: [(Float, Float, Float, Float)] = [(-1, -1, 0, 1), (1, -1, 1, 1), (1, 1, 1, 0), (-1, 1, 0, 0)]
            for (su, sv, tu, tv) in c {
                pos += [n.0 * d + (u.0 * su + v.0 * sv) * 0.5, n.1 * d + (u.1 * su + v.1 * sv) * 0.5, n.2 * d + (u.2 * su + v.2 * sv) * 0.5]
                nor += [n.0, n.1, n.2]; uv += [tu, tv]
            }
            idx += [b, b + 1, b + 2, b, b + 2, b + 3]
        }
        if cube {
            face((0, 0, 1), (1, 0, 0), (0, 1, 0), 0.5); face((0, 0, -1), (-1, 0, 0), (0, 1, 0), 0.5)
            face((1, 0, 0), (0, 0, -1), (0, 1, 0), 0.5); face((-1, 0, 0), (0, 0, 1), (0, 1, 0), 0.5)
            face((0, 1, 0), (1, 0, 0), (0, 0, -1), 0.5); face((0, -1, 0), (1, 0, 0), (0, 0, 1), 0.5)
        } else { face((0, 0, 1), (1, 0, 0), (0, 1, 0), 0) }

        var bin = Data()
        var views: [[String: Any]] = []
        func add(_ d: Data, target: Int?) -> Int {
            while bin.count % 4 != 0 { bin.append(0) }
            var v: [String: Any] = ["buffer": 0, "byteOffset": bin.count, "byteLength": d.count]
            if let t = target { v["target"] = t }
            bin.append(d); views.append(v); return views.count - 1
        }
        func bytes<T>(_ a: [T]) -> Data { a.withUnsafeBytes { Data($0) } }
        let vp = add(bytes(pos), target: 34962), vn = add(bytes(nor), target: 34962), vu = add(bytes(uv), target: 34962), vi = add(bytes(idx), target: 34963)
        let nv = pos.count / 3
        let mn = [Float](repeating: -0.5, count: 3), mx = [Float](repeating: 0.5, count: 3)
        let acc: [[String: Any]] = [
            ["bufferView": vp, "componentType": 5126, "count": nv, "type": "VEC3", "min": mn, "max": mx],
            ["bufferView": vn, "componentType": 5126, "count": nv, "type": "VEC3"],
            ["bufferView": vu, "componentType": 5126, "count": nv, "type": "VEC2"],
            ["bufferView": vi, "componentType": 5123, "count": idx.count, "type": "SCALAR"]]

        var images: [[String: Any]] = [], textures: [[String: Any]] = []
        func tex(_ d: Data?, _ mime: String) -> Int? {
            guard let d = d else { return nil }
            images.append(["bufferView": add(d, target: nil), "mimeType": mime])
            textures.append(["source": images.count - 1, "sampler": 0])
            return textures.count - 1
        }
        var pbr: [String: Any] = ["metallicFactor": 1.0, "roughnessFactor": 1.0]
        var mat: [String: Any] = ["doubleSided": true]
        if let b = tex(p?.base, "image/jpeg") { pbr["baseColorTexture"] = ["index": b] } else { pbr["baseColorFactor"] = [0.8, 0.8, 0.8, 1.0] }
        if let m = tex(p?.mr, "image/png") { pbr["metallicRoughnessTexture"] = ["index": m] } else { pbr["metallicFactor"] = 0.0; pbr["roughnessFactor"] = 0.6 }
        if let o = tex(p?.occ, "image/png") { mat["occlusionTexture"] = ["index": o] }
        mat["pbrMetallicRoughness"] = pbr
        let json: [String: Any] = [
            "asset": ["version": "2.0", "generator": "SaikiMotion Extras"], "scene": 0, "scenes": [["nodes": [0]]], "nodes": [["mesh": 0]],
            "meshes": [["primitives": [["attributes": ["POSITION": 0, "NORMAL": 1, "TEXCOORD_0": 2], "indices": 3, "material": 0]]]],
            "materials": [mat], "accessors": acc, "bufferViews": views, "buffers": [["byteLength": bin.count]],
            "samplers": [["magFilter": 9729, "minFilter": 9987, "wrapS": 10497, "wrapT": 10497]],
            "images": images, "textures": textures]
        var js = (try? JSONSerialization.data(withJSONObject: json)) ?? Data()
        while js.count % 4 != 0 { js.append(0x20) }
        while bin.count % 4 != 0 { bin.append(0) }
        var out = Data()
        func u32(_ v: UInt32) { var x = v.littleEndian; withUnsafeBytes(of: &x) { out.append(contentsOf: $0) } }
        u32(0x46546C67); u32(2); u32(UInt32(12 + 8 + js.count + 8 + bin.count))
        u32(UInt32(js.count)); u32(0x4E4F534A); out.append(js)
        u32(UInt32(bin.count)); u32(0x004E4942); out.append(bin)
        return out
    }
}

// MARK: - panel

final class ExtrasPanel: UIView, UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate {
    private weak var host: EditorViewController?
    private let accent = UIColor(red: 1, green: 0.55, blue: 0.08, alpha: 1)
    private let shapeSeg = UISegmentedControl(items: ["Flat plane", "Cube"])
    private let spreadSeg = UISegmentedControl(items: ["Air", "Ground"])
    private let resSeg = UISegmentedControl(items: ["1k (fast)", "2k"])
    private let search = UISearchBar()
    private let table = UITableView()
    private let countLbl = UILabel(), status = UILabel()
    private let slider = UISlider()
    private let addBtn = UIButton(type: .system)
    private var all: [(id: String, name: String)] = [], shown: [(id: String, name: String)] = []
    private var pick = -1                     // index in `shown`; -1 = plain (no texture)
    private var busy = false

    static func present(in host: EditorViewController, over view: UIView) {
        if view.subviews.contains(where: { $0 is ExtrasPanel }) { return }
        let v = ExtrasPanel(host: host)
        v.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(v)
        NSLayoutConstraint.activate([v.leadingAnchor.constraint(equalTo: view.leadingAnchor), v.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                                     v.topAnchor.constraint(equalTo: view.topAnchor), v.bottomAnchor.constraint(equalTo: view.bottomAnchor)])
    }

    init(host: EditorViewController) {
        self.host = host
        super.init(frame: .zero)
        backgroundColor = UIColor(white: 0, alpha: 0.55)
        build()
        PolyHaven.list { [weak self] l in
            DispatchQueue.main.async {
                self?.all = l; self?.filter("")
                if l.isEmpty { self?.status.text = "Could not reach Poly Haven. Check your connection." }
            }
        }
    }
    required init?(coder: NSCoder) { fatalError() }

    private func build() {
        let card = UIView(); card.backgroundColor = UIColor(white: 0.09, alpha: 1); card.layer.cornerRadius = 22
        card.translatesAutoresizingMaskIntoConstraints = false; addSubview(card)
        let title = UILabel(); title.text = "Extras"; title.textColor = .white; title.font = .systemFont(ofSize: 22, weight: .bold)
        let x = UIButton(type: .system); x.setImage(UIImage(systemName: "xmark"), for: .normal); x.tintColor = .white
        x.addTarget(self, action: #selector(close), for: .touchUpInside)
        let head = UIStackView(arrangedSubviews: [title, UIView(), x]); head.alignment = .center

        for s in [shapeSeg, spreadSeg, resSeg] { s.selectedSegmentIndex = 0; s.selectedSegmentTintColor = accent
            s.setTitleTextAttributes([.foregroundColor: UIColor.white], for: .normal); s.setTitleTextAttributes([.foregroundColor: UIColor.black], for: .selected) }
        search.placeholder = "Search Poly Haven textures (brick, wood, rock…)"; search.searchBarStyle = .minimal; search.delegate = self
        search.searchTextField.textColor = .white; search.autocapitalizationType = .none
        table.dataSource = self; table.delegate = self; table.backgroundColor = .clear; table.rowHeight = 56
        table.separatorColor = UIColor(white: 1, alpha: 0.08)
        slider.minimumValue = 1; slider.maximumValue = Float(PolyHaven.maxCount); slider.value = 1; slider.tintColor = accent
        slider.addTarget(self, action: #selector(slid), for: .valueChanged)
        countLbl.textColor = .white; countLbl.font = .systemFont(ofSize: 15, weight: .semibold)
        status.textColor = UIColor(white: 0.7, alpha: 1); status.font = .systemFont(ofSize: 12); status.numberOfLines = 2
        addBtn.setTitle("Add to scene", for: .normal); addBtn.setTitleColor(.black, for: .normal)
        addBtn.titleLabel?.font = .systemFont(ofSize: 17, weight: .bold); addBtn.backgroundColor = accent; addBtn.layer.cornerRadius = 14
        addBtn.addTarget(self, action: #selector(addTap), for: .touchUpInside)
        addBtn.heightAnchor.constraint(equalToConstant: 48).isActive = true
        slid()

        func row(_ t: String, _ v: UIView) -> UIStackView {
            let l = UILabel(); l.text = t; l.textColor = UIColor(white: 0.7, alpha: 1); l.font = .systemFont(ofSize: 13)
            l.setContentHuggingPriority(.required, for: .horizontal)
            let s = UIStackView(arrangedSubviews: [l, v]); s.spacing = 10; s.alignment = .center; return s
        }
        let stack = UIStackView(arrangedSubviews: [head, shapeSeg, search, table, row("Count", slider), countLbl, row("Spread", spreadSeg), row("Quality", resSeg), status, addBtn])
        stack.axis = .vertical; stack.spacing = 10
        stack.translatesAutoresizingMaskIntoConstraints = false; card.addSubview(stack)
        NSLayoutConstraint.activate([
            card.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 12), card.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -12),
            card.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor, constant: 40), card.bottomAnchor.constraint(equalTo: safeAreaLayoutGuide.bottomAnchor, constant: -12),
            stack.leadingAnchor.constraint(equalTo: card.leadingAnchor, constant: 16), stack.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -16),
            stack.topAnchor.constraint(equalTo: card.topAnchor, constant: 16), stack.bottomAnchor.constraint(equalTo: card.bottomAnchor, constant: -16)])
        table.setContentHuggingPriority(.defaultLow, for: .vertical)
    }

    @objc private func close() { removeFromSuperview() }
    @objc private func slid() {
        let n = Int(slider.value.rounded())
        countLbl.text = n <= 1 ? "Single object" : "\(n) copies (procedural, instanced)"
    }

    // list
    private func filter(_ q: String) {
        let k = q.trimmingCharacters(in: .whitespaces).lowercased()
        shown = k.isEmpty ? all : all.filter { $0.name.lowercased().contains(k) || $0.id.contains(k) }
        pick = -1; table.reloadData()
    }
    func searchBar(_ s: UISearchBar, textDidChange t: String) { filter(t) }
    func searchBarSearchButtonClicked(_ s: UISearchBar) { s.resignFirstResponder() }
    func tableView(_ t: UITableView, numberOfRowsInSection s: Int) -> Int { shown.count + 1 }
    func tableView(_ t: UITableView, cellForRowAt ip: IndexPath) -> UITableViewCell {
        let c = t.dequeueReusableCell(withIdentifier: "c") ?? UITableViewCell(style: .default, reuseIdentifier: "c")
        c.backgroundColor = .clear; c.textLabel?.textColor = .white; c.tintColor = accent
        let i = ip.row - 1
        c.textLabel?.text = i < 0 ? "Plain (no texture)" : shown[i].name
        c.accessoryType = i == pick ? .checkmark : .none
        c.imageView?.image = nil
        if i >= 0 {
            let id = shown[i].id
            c.imageView?.image = UIImage(systemName: "photo")
            PolyHaven.thumb(id) { [weak c, weak t] img in
                guard let img = img, let c = c, c.textLabel?.text == self.shown.first(where: { $0.id == id })?.name else { return }
                c.imageView?.image = img; c.setNeedsLayout(); _ = t
            }
        }
        return c
    }
    func tableView(_ t: UITableView, didSelectRowAt ip: IndexPath) {
        pick = ip.row - 1; t.reloadData(); search.resignFirstResponder()
    }

    // build + import
    @objc private func addTap() {
        guard !busy, let host = host else { return }
        busy = true; addBtn.alpha = 0.5
        let cube = shapeSeg.selectedSegmentIndex == 1, count = Int(slider.value.rounded()), ground = spreadSeg.selectedSegmentIndex == 1
        let res = resSeg.selectedSegmentIndex == 0 ? "1k" : "2k"
        let tex = pick >= 0 ? shown[pick] : nil
        status.text = tex == nil ? "Building…" : "Downloading \(tex!.name) maps…"
        let finish: (Data?, String, Bool) -> Void = { [weak self] glb, name, normal in
            DispatchQueue.main.async {
                guard let self = self else { return }
                self.busy = false; self.addBtn.alpha = 1
                guard let glb = glb, let path = ProjectIO.writeDataIntoSandbox(glb, name: "extras_\(name)_\(nowMs()).glb") else {
                    self.status.text = "Could not build the object."; return }
                host.addMedia(path, .MODEL)
                if let l = Editor.scene.layers.last(where: { $0.imagePath == path }) {
                    l.name = "\(cube ? "Cube" : "Plane") · \(name)"
                    l.xset("pbrNorm", normal ? 1 : 0)
                    if count > 1 {
                        l.xset("scList", 1); l.xset("scOn", 1); l.xset("scTarget", ground ? -2 : -3)
                        l.xset("scCount", Float(count)); l.xset("scGroundSize", 10); l.xset("scAirH", 4); l.xset("scScale", 0.5); l.xset("scScaleRnd", 0.3)
                        l.xset("scAlign", ground ? 1 : 0); l.xset("scTilt", ground ? 0 : 180); l.xset("scYaw", 360)
                        if ground && !cube { l.xset("scRotX", -90) }       // flat planes lie on the floor
                    }
                    host.render(); host.refreshPanel()
                }
                self.close()
            }
        }
        DispatchQueue.global(qos: .userInitiated).async {
            guard let t = tex else { finish(ExtrasGLB.build(cube: cube, nil), "plain", false); return }
            PolyHaven.maps(t.id, res: res) { m in
                guard let m = m else { DispatchQueue.main.async { self.busy = false; self.addBtn.alpha = 1; self.status.text = "Download failed. Try again." }; return }
                let p = ExtrasGLB.pack(m, size: res == "1k" ? 1024 : 2048)
                finish(ExtrasGLB.build(cube: cube, p), t.id, p.hasNormal)
            }
        }
    }
}
