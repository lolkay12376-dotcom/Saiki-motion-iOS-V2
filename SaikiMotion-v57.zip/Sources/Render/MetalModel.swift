import Foundation
import Metal
import simd
import UIKit
import OpenGLES

//  Stage 6b: GLB / glTF / OBJ / animated-ABC models in Metal (port of GlbModel.draw + the GL PBR shader).
//  GlbModel is loaded with cpuOnly = true (no GL calls); this file uploads its CPU data to Metal.
//  VDB volumes stay in GL.

enum MetalModelSL {
    /// Port of GlbModel.vertexSource / fragmentSource. Clip z is remapped from the GL range [-w, w]
    /// to Metal's [0, w]. Vertices are read from a plain float buffer (12 floats per vertex).
    static let source = MetalSL.header + """
struct ModelU {
    float4 vp0; float4 vp1; float4 vp2; float4 vp3;     // uVP columns
    float4 m0; float4 m1; float4 m2; float4 m3;         // uModel columns
    float4 color;     // uColor
    float4 emis;      // uEmis.xyz
    float4 eye;       // uEye.xyz
    float4 prm;       // metal, rough, cutoff, unlit
    float4 has;       // base, metal-rough, emissive, occlusion texture present
    float4 opt;       // env, metallic reflectivity, view mode, ao strength
    float4 xtra;      // exposure, rt ao, rt shadow, pbr bump strength
    float4 lp0; float4 lp1; float4 lp2;     // scene point lights: world pos
    float4 lc0; float4 lc1; float4 lc2;     // rgb * intensity (w = 1 when active)
    float4 pg;        // procedural pbr: on, parallax depth, uv scale x, uv scale y
    float4 wa;        // water: on, time, wave height, wave frequency
    float4 wb;        // water: speed, foam, depth, choppiness
    float4 wc;        // water: clarity, turbidity, refraction, subsurface
    float4 wd;        // water: glint, detail, flow dir (rad), procedural seabed
    float4 we;        // water: wave variation, swell, swell length, whitecaps
    float4 wf;        // water: base y, 0, scene depth available, 0
};
struct MOut { float4 pos [[position]]; float psize [[point_size]]; float3 n; float3 w; float2 uv; float4 col; };

inline float mHash(float2 p) { return fract(sin(dot(p, float2(127.1, 311.7))) * 43758.5453); }
inline float mVn(float2 p) {
    float2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
    return mix(mix(mHash(i), mHash(i + float2(1.0, 0.0)), f.x), mix(mHash(i + float2(0.0, 1.0)), mHash(i + float2(1.0, 1.0)), f.x), f.y);
}
// Sharpened sine waves (Gerstner-like crests). Directions, frequencies and phases are jittered and domain-warped,
// amplitude is modulated at a large scale, so the pattern never visibly tiles. Returns height, gradient in g.
inline float wvH(float2 p, float t, float amp, float freq, float spd, float chop, float dirA, float vari, float2 sw, int nw, thread float2& g) {
    float k = mix(0.7, 2.6, chop);
    float zone = mix(0.6, 1.4, mVn(p * 0.03 + 19.0));      // calm / rough areas: far water differs from near water
    float am = mix(1.0, 0.45 + 1.1 * mVn(p * 0.09 + 7.0), vari);
    float wph = (mVn(p * 0.17 + 3.0) - 0.5) * 3.0 * vari;
    float h = 0.0, a = amp * am, f = freq, w = 1.0;
    g = float2(0.0);
    for (int i = 0; i < nw; i++) {
        float fi = float(i);
        float ang = dirA + fi * 0.83 + sin(fi * 5.1 + 1.0) * 0.7 * (0.4 + vari);
        float2 d = float2(cos(ang), sin(ang));
        float fr = f * (1.0 + 0.21 * sin(fi * 7.3));
        float ph = dot(d, p) * fr + t * spd * w * 1.6 + fi * 1.7 + wph * (0.4 + 0.3 * fi);
        float e = exp((sin(ph) - 1.0) * k);
        h += a * e;
        g += a * e * k * cos(ph) * fr * d;
        a *= 0.58; f *= 1.8; w *= 1.2;
    }
    for (int j = 0; j < 3; j++) {      // long rounded swells on their own headings
        float fj = float(j);
        float ang = dirA + 2.1 + fj * 1.9;
        float2 d = float2(cos(ang), sin(ang));
        float fr = freq * sw.y * (1.0 + 0.45 * fj);
        float ph = dot(d, p) * fr + t * spd * (0.8 + 0.25 * fj) + fj * 2.3 + wph * 0.5;
        float e = exp((sin(ph) - 1.0) * 0.9);
        float sa = amp * sw.x * zone * (1.0 - 0.25 * fj) * 2.2;
        h += sa * e;
        g += sa * e * 0.9 * cos(ph) * fr * d;
    }
    return h;
}

vertex MOut modelVertex(uint vid [[vertex_id]], constant ModelU& u [[buffer(0)]],
                        const device float* vb [[buffer(1)]]) {
    uint b = vid * 12u;
    float3 aPos = float3(vb[b], vb[b + 1u], vb[b + 2u]);
    float3 aNormal = float3(vb[b + 3u], vb[b + 4u], vb[b + 5u]);
    float2 aUv = float2(vb[b + 6u], vb[b + 7u]);
    float4 aCol = float4(vb[b + 8u], vb[b + 9u], vb[b + 10u], vb[b + 11u]);
    float4 wp = u.m0 * aPos.x + u.m1 * aPos.y + u.m2 * aPos.z + u.m3;
    float3 wn = float3(0.0, 1.0, 0.0);
    if (u.wa.x > 0.5) {
        float2 g; float hh = wvH(wp.xz, u.wa.y, u.wa.z, u.wa.w, u.wb.x, u.wb.w, u.wd.z, u.we.x, u.we.yz, 4, g);
        wp.y += hh; wn = normalize(float3(-g.x, 1.0, -g.y));
    }
    float4 c = u.vp0 * wp.x + u.vp1 * wp.y + u.vp2 * wp.z + u.vp3 * wp.w;
    c.z = (c.z + c.w) * 0.5;
    MOut o;
    o.pos = c;
    o.psize = 3.0;
    o.w = wp.xyz;
    float3 n = u.m0.xyz * aNormal.x + u.m1.xyz * aNormal.y + u.m2.xyz * aNormal.z;
    o.n = dot(n, n) > 1e-8 ? normalize(n) : float3(0.0, 1.0, 0.0);
    if (u.wa.x > 0.5) { o.n = wn; }
    o.uv = aUv;
    o.col = aCol;
    return o;
}

constant float mPI = 3.14159265;
constant float3 mL1 = float3(0.4170, 0.6672, 0.6672);
constant float3 mL2 = float3(-0.8704, 0.2176, 0.4352);

inline float3 mEnv(float3 d, float r) {
    float h = d.y * 0.5 + 0.5;
    float3 c = mix(float3(0.14, 0.13, 0.15), float3(0.78, 0.80, 0.84), smoothstep(0.0, 0.5, h));
    c = mix(c, float3(0.55, 0.68, 0.95), smoothstep(0.5, 1.0, h));
    float sun = pow(max(dot(d, mL1), 0.0), mix(150.0, 5.0, r)) * mix(8.0, 0.6, r);
    return c + float3(1.0, 0.93, 0.82) * sun;
}

inline float3 mBrdf(float3 N, float3 V, float3 L, float3 diffC, float3 F0, float r) {
    float3 H = normalize(V + L);
    float NdL = max(dot(N, L), 0.0);
    float NdV = max(dot(N, V), 0.001);
    float NdH = max(dot(N, H), 0.0);
    float VdH = max(dot(V, H), 0.0);
    float a = r * r;
    float a2 = a * a;
    float dd = NdH * NdH * (a2 - 1.0) + 1.0;
    float D = a2 / (mPI * dd * dd + 0.0001);
    float k = (r + 1.0) * (r + 1.0) / 8.0;
    float G = (NdL / (NdL * (1.0 - k) + k)) * (NdV / (NdV * (1.0 - k) + k));
    float3 F = F0 + (1.0 - F0) * pow(1.0 - VdH, 5.0);
    float3 spec = D * G * F / max(4.0 * NdV * NdL, 0.001);
    return ((1.0 - F) * diffC / mPI + spec) * NdL;
}

inline float mLin(float d) { return 10.0 / (100.05 - (2.0 * d - 1.0) * 99.95); }      // depth buffer -> view distance (near 0.05, far 100)
inline float3 wAbsorb(constant ModelU& u) { return float3(0.45, 0.09, 0.05) * mix(3.0, 0.4, u.wc.x) + u.wc.y * 0.5; }      // per metre
inline float wCaus(float2 sq, float tt) {
    float c1 = mVn(sq * 1.6 + float2(tt * 0.5, tt * 0.3)), c2 = mVn(sq * 2.1 - float2(tt * 0.4, -tt * 0.55) + 5.0);
    return pow(clamp(1.0 - abs(c1 - c2) * 3.4, 0.0, 1.0), 7.0);
}
inline float3 wFog(constant ModelU& u, float depthCam) {      // display-space colour of the water column; darker the deeper the camera
    float k = 1.0 - exp(-depthCam * 0.15);
    return mix(float3(0.10, 0.45, 0.48), float3(0.01, 0.06, 0.11), k) * mix(float3(1.0), u.color.rgb, 0.7);
}
struct WUOut { float4 pos [[position]]; float2 uv; };
vertex WUOut waterUnderV(uint vid [[vertex_id]]) {
    float2 p = float2(float((vid << 1) & 2u), float(vid & 2u));
    WUOut o; o.pos = float4(p * 2.0 - 1.0, 0.5, 1.0); o.uv = float2(p.x, 1.0 - p.y); return o;
}
// Camera below the surface: everything already drawn is absorbed / scattered by the water column, with light shafts.
fragment float4 waterUnderF(WUOut in [[stage_in]], constant ModelU& u [[buffer(0)]], constant float4x4& inv [[buffer(1)]],
                            depth2d<float> tSD [[texture(4)]], texture2d<float> tScene [[texture(5)]]) {
    constexpr sampler ls(filter::linear, address::clamp_to_edge);
    constexpr sampler ns(filter::nearest, address::clamp_to_edge);
    float2 nd = float2(in.uv.x * 2.0 - 1.0, 1.0 - in.uv.y * 2.0);
    float d = u.wf.z > 0.5 ? tSD.sample(ns, in.uv) : 1.0;
    float4 pw = inv * float4(nd, d * 2.0 - 1.0, 1.0);
    float3 wp = pw.xyz / pw.w;
    bool hit = d < 0.9999;
    float dist = hit ? length(wp - u.eye.xyz) : 80.0;
    float3 dir = normalize(wp - u.eye.xyz);
    float depthCam = max(u.wf.x - u.eye.y, 0.0);
    float3 Tp = pow(exp(-wAbsorb(u) * dist), float3(0.4545));
    float3 sc = tScene.sample(ls, in.uv).rgb;
    float3 col = sc * Tp + wFog(u, depthCam) * (1.0 - Tp);
    float t = u.wa.y * u.wb.x;
    float s = (u.wf.x - u.eye.y) / max(dir.y, 0.05);
    float2 hp = u.eye.xz + dir.xz * s;
    float sh = pow(clamp(mVn(hp * 0.8 + t * 0.2) * 1.6 - 0.35, 0.0, 1.0), 2.0) * mVn(hp * 0.25 - t * 0.1 + 4.0);
    col += float3(0.55, 0.85, 0.8) * sh * smoothstep(-0.1, 0.5, dir.y) * (1.0 - exp(-dist * 0.12)) * exp(-depthCam * 0.12) * u.eye.w * u.wc.w * 0.5;
    return float4(col, 1.0);
}

fragment float4 modelFragment(MOut in [[stage_in]], constant ModelU& u [[buffer(0)]],
                              texture2d<float> tBase [[texture(0)]], texture2d<float> tMR [[texture(1)]],
                              texture2d<float> tEm [[texture(2)]], texture2d<float> tOcc [[texture(3)]],
                              depth2d<float> tSD [[texture(4)]], texture2d<float> tScene [[texture(5)]],
                              sampler sBase [[sampler(0)]], sampler sMR [[sampler(1)]],
                              sampler sEm [[sampler(2)]], sampler sOcc [[sampler(3)]]) {
    float2 uv = in.uv;
    if (u.pg.x > 0.5) {      // procedural pbr: tile density follows the layer scale, slow domain warp hides repetition
        uv *= u.pg.zw;
        float2 q = uv * 0.37;
        uv += (float2(mVn(q + 11.0), mVn(q + 37.0)) - 0.5) * 0.5;
    }
    float2 gx = dfdx(uv), gy = dfdy(uv);
    float3 N = normalize(in.n);
    float3 V = normalize(u.eye.xyz - in.w);
    if (dot(N, V) < 0.0) { N = -N; }
    float nlt = u.lc0.w + u.lc1.w + u.lc2.w;
    float sunK = nlt > 0.5 ? 0.2 : 1.0;      // scene lights replace the default studio sun / env instead of drowning in it
    float envK = nlt > 0.5 ? 0.45 : 1.0;
    if (u.wa.x > 0.5) {      // water
        constexpr sampler ls(filter::linear, address::clamp_to_edge);
        constexpr sampler ns(filter::nearest, address::clamp_to_edge);
        float flow = u.wd.z;
        float2 g; float h = wvH(in.w.xz, u.wa.y, u.wa.z, u.wa.w, u.wb.x, u.wb.w, flow, u.we.x, u.we.yz, 6, g);
        float tt = u.wa.y * u.wb.x;
        float dist = length(u.eye.xyz - in.w);
        float baseY = in.w.y - h;
        bool under = u.eye.y < baseY;
        float pf = length(fwidth(in.w));
        float fadeD = 1.0 / (1.0 + pf * u.wa.w * 14.0);      // fine detail fades with pixel footprint: no shimmer in the distance
        float zone = mVn(in.w.xz * 0.045 + 11.0);
        float2 q = in.w.xz * u.wa.w * 3.0;
        float2 cf = float2(cos(flow), sin(flow));
        float2 qa = q + cf * tt * 0.9 + (float2(mVn(q * 0.23 + 3.0), mVn(q * 0.23 + 9.0)) - 0.5) * 2.5;
        float2 qb = q * 1.73 + float2(-cf.y, cf.x) * tt * 0.7 + 17.0;
        float2 rp = float2(mVn(qa) - mVn(qa + float2(0.7, 1.9)), mVn(qa.yx * 1.1 + 5.0) - mVn(qa.yx * 1.1 + float2(2.1, 0.4)));
        rp += 0.6 * float2(mVn(qb) - mVn(qb + float2(1.3, 0.2)), mVn(qb.yx) - mVn(qb.yx + float2(0.5, 1.1)));
        g += rp * u.wa.z * u.wa.w * 0.5 * u.wd.y * fadeD * mix(0.5, 1.4, zone);
        float3 Nw = normalize(float3(-g.x, 1.0, -g.y));
        Nw = normalize(mix(float3(0.0, 1.0, 0.0), Nw, mix(0.4, 1.0, fadeD)));
        if (dot(Nw, V) < 0.0) { Nw = -Nw; }
        float nlt2 = u.lc0.w + u.lc1.w + u.lc2.w;
        if (under) {      // looking up at the surface from inside the water: Snell's window + total internal reflection
            float depthCam = max(baseY - u.eye.y, 0.0);
            float3 fogL = pow(wFog(u, depthCam), float3(2.2));
            float3 Ru = refract(-V, Nw, 1.333);
            float tir = dot(Ru, Ru) < 1e-4 ? 1.0 : 0.0;
            float3 sky = mEnv(normalize(Ru + float3(0.0, 1e-4, 0.0)), 0.15) * u.emis.w * envK * exp(-depthCam * 0.05);
            float3 c = mix(sky, fogL * 0.8, tir);
            c = mix(c, fogL, 1.0 - exp(-dist * 0.1));
            c *= u.xtra.x;
            c = c * (1.0 + c / 6.0) / (1.0 + c);
            c = pow(max(c, float3(0.0)), float3(1.0 / 2.2));
            return float4(c * u.color.a, u.color.a);
        }
        float NdVw = clamp(dot(Nw, V), 0.0, 1.0);
        float F = 0.02 + 0.98 * pow(1.0 - NdVw, 5.0);
        float3 Rw = reflect(-V, Nw); Rw.y = abs(Rw.y);
        float3 refl = mEnv(Rw, 0.03) * u.emis.w * envK;
        float crest = clamp(h / (u.wa.z * 1.3 + 1e-5), 0.0, 1.0);
        float clar = u.wc.x, turb = u.wc.y;
        float D = mix(0.3, 8.0, u.wb.z);
        float3 Rr = refract(-V, Nw, 0.75);
        Rr = normalize(mix(-V, Rr, clamp(u.wc.z * 2.0, 0.0, 1.0)));
        float cr = max(-Rr.y, 0.12);
        float3 absorb = wAbsorb(u);
        // what is below: real depth buffer + the picture drawn so far, looked up through the wavy surface (refraction warp)
        float2 suv = in.pos.xy / float2(float(tScene.get_width()), float(tScene.get_height()));
        float surfLin = 1.0 / in.pos.w;
        float ray = dist / max(surfLin, 1e-3);
        bool hasD = u.wf.z > 0.5;
        float sd0 = hasD ? tSD.read(uint2(in.pos.xy)) : 1.0;
        float th0 = sd0 < 0.9999 ? max(mLin(sd0) - surfLin, 0.0) * ray : D / cr;
        float2 dxz = -Nw.xz * u.wc.z * 0.35 * min(th0, 3.0);
        float2 duv = float2(u.vp0.x * dxz.x + u.vp2.x * dxz.y, -(u.vp0.y * dxz.x + u.vp2.y * dxz.y)) * in.pos.w * 0.5;
        float2 uvR = suv + duv;
        float sdR = hasD ? tSD.sample(ns, uvR) : 1.0;
        if (hasD && mLin(sdR) < surfLin - 0.002) { uvR = suv; sdR = sd0; }      // something in front of the water: no warping across its edge
        bool hit = sdR < 0.9999;
        float thR = hit ? max(mLin(sdR) - surfLin, 0.0) * ray : D / cr;
        float3 Tr = exp(-absorb * thR);
        float3 seabed = float3(0.0), sceneT = float3(0.0);
        float3 hp = in.w + Rr * thR;
        float sand = 0.0;
        if (hit) {      // real object / floor: lit fully when shallow, darker and bluer the deeper it is, with caustics on it
            float cs = wCaus(hp.xz * 1.7, tt);
            sceneT = tScene.sample(ls, uvR).rgb * pow(Tr, float3(0.4545)) * (1.0 + cs * 1.2 * u.eye.w * sunK * Tr.g);
        } else {        // nothing below: procedural seabed
            float2 sq = hp.xz * 1.7;
            float sn = mVn(sq) * 0.6 + mVn(sq * 2.9 + 4.0) * 0.4;
            float rip = 0.5 + 0.5 * sin(hp.x * 5.0 + sn * 6.0 + hp.z * 2.0);
            float3 snd = mix(float3(0.50, 0.42, 0.30), float3(0.30, 0.25, 0.18), sn) * (0.85 + 0.3 * rip);
            seabed = (snd * (0.5 + 0.5 * u.eye.w * sunK) + wCaus(sq, tt) * float3(1.0, 0.95, 0.8) * 1.2 * u.eye.w) * Tr * u.wd.w;
            sand = 1.0;
        }
        float skyAmb = 0.35 + 0.65 * clamp(Nw.y, 0.0, 1.0);
        float3 deep = float3(0.015, 0.17, 0.20) * u.color.rgb, shallow = float3(0.07, 0.42, 0.40) * u.color.rgb;
        float3 body = mix(deep, shallow, Tr.g) * skyAmb * (1.0 + turb * 1.5);
        body *= hit ? (1.0 - 0.9 * Tr.g) : (1.0 - 0.6 * Tr.g * u.wd.w);
        float3 Hs = normalize(mL1 + Nw * 0.3);
        body += float3(0.10, 0.55, 0.42) * u.color.rgb * pow(clamp(dot(-V, Hs), 0.0, 1.0), 3.0) * crest * u.wc.w * u.eye.w * 0.9;
        float rg = mix(0.03, 0.14, 1.0 - fadeD);      // glints widen with distance instead of aliasing
        float3 spec = (mBrdf(Nw, V, mL1, float3(0.0), float3(0.02), rg) * float3(3.2, 3.0, 2.8)
                     + mBrdf(Nw, V, mL1, float3(0.0), float3(0.02), 0.18) * float3(0.5, 0.48, 0.45)) * u.eye.w * u.wd.x * sunK
                    + mBrdf(Nw, V, mL2, float3(0.0), float3(0.02), 0.08) * float3(0.9, 1.0, 1.3) * sunK;
        float3 lit = float3(0.0);
        float4 lps[3] = { u.lp0, u.lp1, u.lp2 }; float4 lcs[3] = { u.lc0, u.lc1, u.lc2 };
        for (int i = 0; i < 3; i++) {
            if (lcs[i].w < 0.5) { continue; }
            float3 Lv = lps[i].xyz - in.w; float d2 = dot(Lv, Lv); float3 Ld = Lv * rsqrt(max(d2, 1e-6));
            float att = 2.5 / (d2 + 0.3);
            spec += (mBrdf(Nw, V, Ld, float3(0.0), float3(0.02), max(rg, 0.04)) + mBrdf(Nw, V, Ld, float3(0.0), float3(0.02), 0.2) * 0.25) * lcs[i].rgb * att * u.wd.x;
            lit += lcs[i].rgb * clamp(dot(Nw, Ld), 0.0, 1.0) * att;
        }
        body += float3(0.05, 0.28, 0.30) * u.color.rgb * lit * 0.3 * (0.4 + Tr.g);
        seabed += float3(0.35, 0.3, 0.22) * lit * 0.25 * Tr * u.wd.w * sand;
        float steep = clamp(length(g) * 0.9 - 0.15, 0.0, 1.0);
        float fn = mVn(q * 4.0 - tt * 0.3) * 0.6 + mVn(q * 9.0 + tt * 0.2 + 3.0) * 0.4;
        float fm = smoothstep(1.0 - u.wb.y * 0.6, 1.0, crest * 0.7 + steep * 0.5 + (fn - 0.5) * 0.7) * smoothstep(0.05, 0.4, u.wb.y);
        float caps = smoothstep(0.55, 0.85, mVn(in.w.xz * 0.07 + tt * 0.03 + 5.0)) * u.we.w * smoothstep(0.1, 0.5, u.wb.y);
        float shore = hit ? smoothstep(0.35, 0.0, thR) : 0.0;      // foam where the water touches something
        fm = clamp(fm + caps * smoothstep(0.5, 0.8, fn) * 0.8 + shore * smoothstep(0.3, 0.7, fn + 0.2) * u.wb.y, 0.0, 1.0);
        float3 foamC = float3(0.92, 0.96, 0.98) * (0.3 + 0.7 * clamp(dot(Nw, mL1), 0.0, 1.0) * u.eye.w * sunK + lit * 0.5 + 0.2 * envK);
        float3 base = mix(mix(body + seabed, refl, F), foamC, fm);
        float3 outc = base + spec * (1.0 - fm);
        outc *= u.xtra.x;
        outc = outc * (1.0 + outc / 6.0) / (1.0 + outc);
        outc = pow(max(outc, float3(0.0)), float3(1.0 / 2.2));
        outc += sceneT * (1.0 - F) * (1.0 - fm);
        float aw = u.color.a;
        return float4(outc * aw, aw);
    }
    float pSh = 1.0;
    bool pbr = u.xtra.w > 0.0 && u.has.w > 0.5;
    float3 Tn = float3(0.0), Bn = float3(0.0);
    if (pbr) {      // Extras PBR: tangent frame from derivatives, height (MR.r) -> parallax, normal XY (occ.gb) -> bump
        float3 dp1 = dfdx(in.w), dp2 = dfdy(in.w);
        float2 du1 = dfdx(in.uv), du2 = dfdy(in.uv);
        float3 p2 = cross(dp2, N), p1 = cross(N, dp1);
        float3 T = p2 * du1.x + p1 * du2.x, B = p2 * du1.y + p1 * du2.y;
        float inv = rsqrt(max(max(dot(T, T), dot(B, B)), 1e-12));
        Tn = T * inv; Bn = B * inv;
        if (u.pg.y > 0.0 && u.has.y > 0.5) {      // parallax occlusion mapping (height in metal-rough R) + contact self-shadow
            float3 Vt = float3(dot(V, Tn), dot(V, Bn), max(dot(V, N), 0.3));
            float2 P = Vt.xy / Vt.z * u.pg.y * smoothstep(0.05, 0.4, dot(V, N));
            float plod = max(0.0, log2(max(length(gx), length(gy)) * float(tMR.get_width()))) + 0.5;
            const int NS = 20;
            float ld = 1.0 / float(NS), cl = 0.0;
            float2 cuv = uv;
            float dv = 1.0 - tMR.sample(sMR, cuv, level(plod)).r;
            for (int i = 0; i < NS; i++) {
                if (cl >= dv) { break; }
                cuv -= P * ld; dv = 1.0 - tMR.sample(sMR, cuv, level(plod)).r; cl += ld;
            }
            float2 prv = cuv + P * ld;
            float aft = dv - cl, bef = (1.0 - tMR.sample(sMR, prv, level(plod)).r) - cl + ld;
            uv = mix(cuv, prv, clamp(aft / (aft - bef - 1e-5), 0.0, 1.0));
            float3 Lt = float3(dot(mL1, Tn), dot(mL1, Bn), dot(mL1, N));
            if (Lt.z > 0.02) {
                float h0 = tMR.sample(sMR, uv, level(plod)).r;
                float2 Ls = Lt.xy / max(Lt.z, 0.1) * u.pg.y;
                for (int i = 1; i <= 6; i++) {
                    float f = float(i) / 6.0;
                    float hh = tMR.sample(sMR, uv + Ls * f, level(plod)).r;
                    pSh = min(pSh, clamp(1.0 - (hh - (h0 + f * 0.5)) * 6.0, 0.0, 1.0));
                }
            }
        }
        float2 nxy = (tOcc.sample(sOcc, uv, gradient2d(gx, gy)).gb * 2.0 - 1.0) * u.xtra.w;
        N = normalize(Tn * nxy.x + Bn * nxy.y + N * sqrt(max(1.0 - dot(nxy, nxy), 0.05)));
    }
    float a = u.color.a * in.col.a;
    float3 tint = u.color.rgb * pow(max(in.col.rgb, float3(0.0)), float3(2.2));
    float3 alb = tint;
    if (u.has.x > 0.5) {
        float4 t = tBase.sample(sBase, uv, gradient2d(gx, gy));
        a *= t.a;
        alb *= pow(clamp(t.rgb / max(t.a, 0.001), 0.0, 1.0), float3(2.2));
    }
    if (u.prm.z >= 0.0) {
        if (a < u.prm.z) { discard_fragment(); }
        a = 1.0;
    }
    float metal = u.prm.x * u.opt.y;
    float rough = u.prm.y;
    float ao = 1.0;
    if (u.has.w > 0.5) { ao = mix(1.0, tOcc.sample(sOcc, uv, gradient2d(gx, gy)).r, u.opt.w); }
    if (u.has.y > 0.5) {
        float4 m = tMR.sample(sMR, uv, gradient2d(gx, gy));
        rough *= m.g;
        metal *= m.b * u.opt.y;
    }
    rough = clamp(rough, 0.04, 1.0);
    metal = clamp(metal, 0.0, 1.0);

    float NdV = max(dot(N, V), 0.001);

    float3 F0 = mix(float3(0.04), alb, metal);
    float3 diffC = alb * (1.0 - metal);
    float3 col = mBrdf(N, V, mL1, diffC, F0, rough) * float3(3.2, 3.0, 2.8) * u.eye.w * pSh * sunK
               + mBrdf(N, V, mL2, diffC, F0, rough) * float3(0.9, 1.0, 1.3) * sunK;
    {   // scene lights (Lighting layers) lit with the same BRDF; falloff is soft inverse-square
        float4 lps[3] = { u.lp0, u.lp1, u.lp2 }; float4 lcs[3] = { u.lc0, u.lc1, u.lc2 };
        for (int i = 0; i < 3; i++) {
            if (lcs[i].w < 0.5) { continue; }
            float3 Lv = lps[i].xyz - in.w; float d2 = dot(Lv, Lv);
            col += mBrdf(N, V, Lv * rsqrt(max(d2, 1e-6)), diffC, F0, rough) * lcs[i].rgb * (2.5 / (d2 + 0.3));
        }
    }
    if (pbr) { col *= mix(1.0, ao, 0.8); }
    float3 R = reflect(-V, N);
    float3 Fr = F0 + (max(float3(1.0 - rough), F0) - F0) * pow(1.0 - NdV, 5.0);
    if (u.opt.x > 0.5) {
        col += diffC * mEnv(N, 1.0) * 0.8 * ao * u.emis.w * envK;
        col += mEnv(R, rough) * Fr * (1.0 - 0.5 * rough) * ao * u.emis.w * envK;
    } else {
        col += diffC * 0.3 * ao;
    }
    float3 em = u.emis.xyz;
    if (u.has.z > 0.5) { em *= pow(tEm.sample(sEm, uv, gradient2d(gx, gy)).rgb, float3(2.2)); }
    col += em;
    col = mix(col, alb + em, u.prm.w);
    if (u.opt.z > 0.5) {
        float3 v = alb;
        if (u.opt.z > 1.5) { v = float3(rough); }
        if (u.opt.z > 2.5) { v = float3(metal); }
        if (u.opt.z > 3.5) { v = float3(ao); }
        if (u.opt.z > 4.5) { v = em; }
        return float4(pow(max(v, float3(0.0)), float3(1.0 / 2.2)) * a, a);
    }
    col *= u.xtra.x;
    col = col * (1.0 + col / 6.0) / (1.0 + col);
    col = pow(max(col, float3(0.0)), float3(1.0 / 2.2));
    return float4(col * a, a);
}
"""
}

extension MetalModelSL {
    /// Same shader plus hardware ray-traced shadows / ambient occlusion against the model's own triangles.
    static var rtSource: String {
        var s = source
        s = s.replacingOccurrences(of: "struct ModelU {", with: "#include <metal_raytracing>\nusing namespace metal::raytracing;\nstruct ModelU {")
        s = s.replacingOccurrences(of: "fragment float4 modelFragment(", with: "fragment float4 modelFragmentRT(")
        s = s.replacingOccurrences(of: "sampler sEm [[sampler(2)]], sampler sOcc [[sampler(3)]]) {",
            with: "sampler sEm [[sampler(2)]], sampler sOcc [[sampler(3)]],\n primitive_acceleration_structure acc [[buffer(2)]], constant float4& rtp [[buffer(3)]], constant float4x4& rinv [[buffer(4)]]) {")
        let code = """
    float rtVis = 1.0; float rtAo = 1.0;
    if (rtp.x > 0.0) {
        float sc = max(length(rinv[0].xyz), 1e-6);
        float3 Pw = in.w + N * 0.004;
        intersector<triangle_data> it;
        it.assume_geometry_type(geometry_type::triangle);
        ray r;
        r.origin = (rinv * float4(Pw, 1.0)).xyz;
        r.min_distance = 0.0005 * sc;
        float sh = 0.0;
        r.max_distance = 1.0e4;
        r.direction = normalize((rinv * float4(mL1, 0.0)).xyz);
        if (it.intersect(r, acc).type == intersection_type::triangle) { sh = 1.0; }
        rtVis = 1.0 - sh * u.xtra.z;
        float3 T = normalize(abs(N.y) < 0.9 ? cross(N, float3(0.0, 1.0, 0.0)) : cross(N, float3(1.0, 0.0, 0.0)));
        float3 Bt = cross(N, T);
        float occl = 0.0;
        for (int k = 0; k < 8; k++) {
            float a2 = float(k) * 0.7853982;
            float el = (k & 1) == 0 ? 0.45 : 0.85;
            float3 dw = normalize(N * el + (T * cos(a2) + Bt * sin(a2)) * (1.0 - el));
            r.direction = normalize((rinv * float4(dw, 0.0)).xyz);
            r.max_distance = max(rtp.y, 0.01) * sc;
            if (it.intersect(r, acc).type == intersection_type::triangle) { occl += 1.0; }
        }
        rtAo = 1.0 - (occl / 8.0) * u.xtra.y;
    }
    col *= rtVis; ao *= rtAo;
    float3 R = reflect(-V, N);
"""
        s = s.replacingOccurrences(of: "    float3 R = reflect(-V, N);\n", with: code)
        return s
    }
}

/// Must match ModelU in MSL (14 x float4 = 224 bytes).
struct ModelU {
    var vp0 = SIMD4<Float>(0, 0, 0, 0), vp1 = SIMD4<Float>(0, 0, 0, 0)
    var vp2 = SIMD4<Float>(0, 0, 0, 0), vp3 = SIMD4<Float>(0, 0, 0, 0)
    var m0 = SIMD4<Float>(0, 0, 0, 0), m1 = SIMD4<Float>(0, 0, 0, 0)
    var m2 = SIMD4<Float>(0, 0, 0, 0), m3 = SIMD4<Float>(0, 0, 0, 0)
    var color = SIMD4<Float>(1, 1, 1, 1)
    var emis = SIMD4<Float>(0, 0, 0, 0)
    var eye = SIMD4<Float>(0, 0, 3, 0)
    var prm = SIMD4<Float>(0, 0.8, -1, 0)
    var has = SIMD4<Float>(0, 0, 0, 0)
    var opt = SIMD4<Float>(1, 1, 0, 1)
    var xtra = SIMD4<Float>(1, 1, 1, 0)
    var lp0 = SIMD4<Float>(0, 0, 0, 0), lp1 = SIMD4<Float>(0, 0, 0, 0), lp2 = SIMD4<Float>(0, 0, 0, 0)
    var lc0 = SIMD4<Float>(0, 0, 0, 0), lc1 = SIMD4<Float>(0, 0, 0, 0), lc2 = SIMD4<Float>(0, 0, 0, 0)
    var pg = SIMD4<Float>(0, 0, 1, 1), wa = SIMD4<Float>(0, 0, 0, 0), wb = SIMD4<Float>(0, 0, 0, 0)
    var wc = SIMD4<Float>(0.6, 0.15, 0.5, 0.5), wd = SIMD4<Float>(1, 0.6, 0.5, 0.7), we = SIMD4<Float>(0.7, 0.8, 0.15, 0.5), wf = SIMD4<Float>(0, 0, 0, 0)
}

/// GPU copy of one GlbModel (loaded with GlbModel.cpuOnly).
final class MetalModel {
    struct P {
        var vbuf: MTLBuffer?
        var ibuf: MTLBuffer
        var count: Int
        var idx32: Bool
        var points: Bool
        var srcIndex: Int            // index into src.prims
        var tex: [MTLTexture?]       // base, metal-rough, emissive, occlusion
        var clamp: [Bool]
    }
    let src: GlbModel
    private(set) var prims: [P] = []
    var accel: MTLAccelerationStructure?

    init?(_ src: GlbModel, core: MetalCore) {
        self.src = src
        var texById: [UInt32: MTLTexture] = [:]
        var used: [UInt32] = []
        func tex(_ id: UInt32) -> (MTLTexture?, Bool) {
            guard id != 0, let e = GlbModel.cpuImages[id] else { return (nil, false) }
            used.append(id)
            if let t = texById[id] { return (t, e.clamp) }
            guard let t = MetalModel.makeTexture(core, e.img) else { return (nil, e.clamp) }
            texById[id] = t
            return (t, e.clamp)
        }
        for (si, sp) in src.prims.enumerated() {
            guard !sp.verts.isEmpty, !sp.cpuIdx.isEmpty else { continue }
            let idx32 = sp.indexType != GLenum(GL_UNSIGNED_SHORT)
            let ib: MTLBuffer?
            if idx32 {
                ib = sp.cpuIdx.withUnsafeBytes { core.device.makeBuffer(bytes: $0.baseAddress!, length: $0.count, options: .storageModeShared) }
            } else {
                let small = sp.cpuIdx.map { UInt16(truncatingIfNeeded: $0) }
                ib = small.withUnsafeBytes { core.device.makeBuffer(bytes: $0.baseAddress!, length: $0.count, options: .storageModeShared) }
            }
            guard let ibuf = ib else { continue }
            let t0 = tex(UInt32(sp.texBase)), t1 = tex(UInt32(sp.texMR)), t2 = tex(UInt32(sp.texEm)), t3 = tex(UInt32(sp.texOcc))
            prims.append(P(vbuf: nil, ibuf: ibuf, count: sp.cpuIdx.count, idx32: idx32,
                           points: sp.mode == GLenum(GL_POINTS), srcIndex: si,
                           tex: [t0.0, t1.0, t2.0, t3.0], clamp: [t0.1, t1.1, t2.1, t3.1]))
        }
        for id in used { GlbModel.cpuImages[id] = nil }       // CPU copies are no longer needed
        if prims.isEmpty { return nil }
    }

    /// RGBA8 premultiplied texture with a mip chain (GL generated mipmaps on ES3).
    static func makeTexture(_ core: MetalCore, _ image: UIImage) -> MTLTexture? {
        guard let cg = image.cgImage, cg.width > 0, cg.height > 0 else { return nil }
        let sc = min(1.0, 2048.0 / Double(max(cg.width, cg.height)))
        let w = max(1, Int(Double(cg.width) * sc)), h = max(1, Int(Double(cg.height) * sc))
        var data = [UInt8](repeating: 0, count: w * h * 4)
        let drew: Bool = data.withUnsafeMutableBytes { raw -> Bool in
            guard let ctx = CGContext(data: raw.baseAddress, width: w, height: h, bitsPerComponent: 8,
                                      bytesPerRow: w * 4, space: CGColorSpaceCreateDeviceRGB(),
                                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            ctx.setBlendMode(.copy)
            ctx.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h))
            return true
        }
        guard drew else { return nil }
        let d = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .rgba8Unorm, width: w, height: h, mipmapped: true)
        d.usage = .shaderRead
        d.storageMode = .shared
        guard let t = core.device.makeTexture(descriptor: d) else { return nil }
        data.withUnsafeBytes {
            t.replace(region: MTLRegionMake2D(0, 0, w, h), mipmapLevel: 0, withBytes: $0.baseAddress!, bytesPerRow: w * 4)
        }
        if t.mipmapLevelCount > 1, let cbuf = core.queue.makeCommandBuffer(), let blit = cbuf.makeBlitCommandEncoder() {
            blit.generateMipmaps(for: t)
            blit.endEncoding()
            cbuf.commit()
        }
        return t
    }
}

/// Draws model layers into a layer target with a shared depth buffer (GL drawModelLayer).
final class MetalModelRenderer {
    private let core: MetalCore
    private var lib: MTLLibrary?
    private var rtLib: MTLLibrary?
    /// "" when ray tracing is ready, else why it is not (shown in the 3D editor's Properties).
    static var rtStatus = ""
    private var psos: [String: MTLRenderPipelineState] = [:]
    private var dsWrite: MTLDepthStencilState?
    private var dsNoWrite: MTLDepthStencilState?
    private var smpRepeat: MTLSamplerState?
    private var smpClamp: MTLSamplerState?
    private var dummy: MTLTexture?
    private var depthTex: MTLTexture?
    private var cache: [String: MetalModel] = [:]
    private var failed = Set<String>()
    /// Paths whose texture files changed: dropped from the cache on the next load.
    static var evict = Set<String>()
    /// Cleared at frame start and per motion-blur sample: the next model draw clears the depth buffer.
    var depthDirty = true
    private var depthCopy: MTLTexture?
    private var dummyDepthT: MTLTexture?
    private var dsAlways: MTLDepthStencilState?

    init(_ core: MetalCore) {
        self.core = core
        lib = try? core.device.makeLibrary(source: MetalModelSL.source, options: nil)
        if !core.device.supportsRaytracing { MetalModelRenderer.rtStatus = "This device's GPU has no hardware ray tracing (needs A13 or newer)." }
        else {
            let o = MTLCompileOptions()
            if #available(iOS 15.0, *) { o.languageVersion = .version2_4 } else { o.languageVersion = .version2_3 }
            do { rtLib = try core.device.makeLibrary(source: MetalModelSL.rtSource, options: o); MetalModelRenderer.rtStatus = "" }
            catch { MetalModelRenderer.rtStatus = "Ray tracing shader failed: \(error.localizedDescription)" }
        }
        let dw = MTLDepthStencilDescriptor()
        dw.depthCompareFunction = .lessEqual; dw.isDepthWriteEnabled = true
        dsWrite = core.device.makeDepthStencilState(descriptor: dw)
        let dn = MTLDepthStencilDescriptor()
        dn.depthCompareFunction = .lessEqual; dn.isDepthWriteEnabled = false
        dsNoWrite = core.device.makeDepthStencilState(descriptor: dn)
        func sampler(_ clamp: Bool) -> MTLSamplerState? {
            let d = MTLSamplerDescriptor()
            d.minFilter = .linear; d.magFilter = .linear; d.mipFilter = .linear
            d.sAddressMode = clamp ? .clampToEdge : .repeat
            d.tAddressMode = clamp ? .clampToEdge : .repeat
            d.maxAnisotropy = 4
            return core.device.makeSamplerState(descriptor: d)
        }
        smpRepeat = sampler(false); smpClamp = sampler(true)
        let td = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .rgba8Unorm, width: 1, height: 1, mipmapped: false)
        td.usage = .shaderRead
        dummy = core.device.makeTexture(descriptor: td)
        var px: [UInt8] = [255, 255, 255, 255]
        dummy?.replace(region: MTLRegionMake2D(0, 0, 1, 1), mipmapLevel: 0, withBytes: &px, bytesPerRow: 4)
    }

    var ready: Bool { lib != nil && dsWrite != nil && dsNoWrite != nil && smpRepeat != nil && smpClamp != nil && dummy != nil }

    func trimMemory() { cache.removeAll(); depthTex = nil }

    /// The shared depth buffer when a model has drawn since the last clear (volume occlusion), else nil.
    func occlusionDepth() -> MTLTexture? { depthDirty ? nil : depthTex }

    private func loadModel(for path: String) -> MetalModel? {
        if MetalModelRenderer.evict.remove(path) != nil { cache[path] = nil; failed.remove(path) }
        if let m = cache[path] { return m }
        if failed.contains(path) { return nil }
        let p = GlbModel.validate(path: path)
        GlbModel.cpuOnly = true
        defer { GlbModel.cpuOnly = false }
        guard let g = GlbModel.load(p), let m = MetalModel(g, core: core) else {
            failed.insert(path)
            return nil
        }
        cache[path] = m
        cache[p] = m
        return m
    }

    private func pso(blend: Bool, format: MTLPixelFormat, rt: Bool = false) -> MTLRenderPipelineState? {
        let key = "\(blend)/\(format.rawValue)/\(rt)"
        if let p = psos[key] { return p }
        guard let lib = rt ? rtLib : lib, let vf = lib.makeFunction(name: "modelVertex"),
              let ff = lib.makeFunction(name: rt ? "modelFragmentRT" : "modelFragment") else { return nil }
        let d = MTLRenderPipelineDescriptor()
        d.vertexFunction = vf
        d.fragmentFunction = ff
        d.colorAttachments[0].pixelFormat = format
        d.depthAttachmentPixelFormat = .depth32Float
        if blend {
            let c = d.colorAttachments[0]!
            c.isBlendingEnabled = true
            c.sourceRGBBlendFactor = .one; c.destinationRGBBlendFactor = .oneMinusSourceAlpha
            c.sourceAlphaBlendFactor = .one; c.destinationAlphaBlendFactor = .oneMinusSourceAlpha
        }
        guard let p = try? core.device.makeRenderPipelineState(descriptor: d) else { return nil }
        psos[key] = p
        return p
    }

    private func depth(_ w: Int, _ h: Int) -> MTLTexture? {
        if let t = depthTex, t.width == w, t.height == h { return t }
        let d = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .depth32Float, width: w, height: h, mipmapped: false)
        d.usage = [.renderTarget, .shaderRead]
        d.storageMode = .private
        depthTex = core.device.makeTexture(descriptor: d)
        depthDirty = true
        return depthTex
    }

    private func buildAccel(_ model: MetalModel, vbufs: [MTLBuffer?], cb: MTLCommandBuffer) -> MTLAccelerationStructure? {
        var geos: [MTLAccelerationStructureTriangleGeometryDescriptor] = []
        for (i, p) in model.prims.enumerated() where !p.points && i < vbufs.count {
            guard let vb = vbufs[i], p.count >= 3 else { continue }
            let g = MTLAccelerationStructureTriangleGeometryDescriptor()
            g.vertexBuffer = vb; g.vertexStride = 48
            g.indexBuffer = p.ibuf; g.indexType = p.idx32 ? .uint32 : .uint16
            g.triangleCount = p.count / 3
            g.opaque = true
            geos.append(g)
        }
        if geos.isEmpty { return nil }
        let d = MTLPrimitiveAccelerationStructureDescriptor()
        d.geometryDescriptors = geos
        let sz = core.device.accelerationStructureSizes(descriptor: d)
        guard let acc = core.device.makeAccelerationStructure(size: sz.accelerationStructureSize),
              let scratch = core.device.makeBuffer(length: max(sz.buildScratchBufferSize, 16), options: .storageModePrivate),
              let e = cb.makeAccelerationStructureCommandEncoder() else { return nil }
        e.build(accelerationStructure: acc, descriptor: d, scratchBuffer: scratch, scratchBufferOffset: 0)
        e.endEncoding()
        return acc
    }

    /// Draws model layer `l` (glb / gltf / obj / abc) into `target` (which the caller has cleared).
    func draw(_ l: Layer, time: Float, fov: Float, into target: MetalTarget, cb: MTLCommandBuffer, sceneTex: MTLTexture? = nil) {
        guard ready, let path = l.imagePath, let model = loadModel(for: path),
              let dtex = depth(target.width, target.height) else { return }
        model.src.setAnimTime(max(0, time - l.start))
        let vp = MetalCam.vpForModel(l, fov: fov, time: time, width: target.width, height: target.height)
        let mm = MetalCam.modelMatrix(l, time: time, normalize: model.src.normalize)
        let eye = GlbModel.eye(fromVP: vp)
        guard vp.count == 16, mm.count == 16 else { return }
        let isWater = l.xf("water", 0) > 0.5
        guard let dummyD = dummyDepth() else { return }
        var depthSrc: MTLTexture = dummyD
        var hasDepth: Float = 0
        if isWater, sceneTex != nil, !depthDirty, let dc = depthCopyTex(target.width, target.height), let bl = cb.makeBlitCommandEncoder() {
            // snapshot of the depth every earlier layer wrote: the water reads it to know how deep each thing below it is
            bl.copy(from: dtex, sourceSlice: 0, sourceLevel: 0, sourceOrigin: MTLOrigin(x: 0, y: 0, z: 0),
                    sourceSize: MTLSize(width: dtex.width, height: dtex.height, depth: 1),
                    to: dc, destinationSlice: 0, destinationLevel: 0, destinationOrigin: MTLOrigin(x: 0, y: 0, z: 0))
            bl.endEncoding()
            depthSrc = dc; hasDepth = 1
        }

        var base = ModelU()
        base.vp0 = SIMD4(vp[0], vp[1], vp[2], vp[3]); base.vp1 = SIMD4(vp[4], vp[5], vp[6], vp[7])
        base.vp2 = SIMD4(vp[8], vp[9], vp[10], vp[11]); base.vp3 = SIMD4(vp[12], vp[13], vp[14], vp[15])
        base.m0 = SIMD4(mm[0], mm[1], mm[2], mm[3]); base.m1 = SIMD4(mm[4], mm[5], mm[6], mm[7])
        base.m2 = SIMD4(mm[8], mm[9], mm[10], mm[11]); base.m3 = SIMD4(mm[12], mm[13], mm[14], mm[15])
        base.eye = SIMD4(eye[0], eye[1], eye[2], l.xf("light", 1) * R3D.g("light", 1))
        var lpos: [SIMD4<Float>] = [], lcol: [SIMD4<Float>] = []
        for L in Editor.scene.layers where L.isLight && L.visible && time >= L.start && time <= L.end && lpos.count < 3 {
            let lt = L.editTime("x", time), c = UInt32(bitPattern: L.vdbTint), k = L.xf("lightInt", 1)
            lpos.append(SIMD4(L.p("x", lt), L.p("y", lt), Xf.worldZ(L, time), 0))
            lcol.append(SIMD4(Float((c >> 16) & 255) / 255 * k, Float((c >> 8) & 255) / 255 * k, Float(c & 255) / 255 * k, 1))
        }
        while lpos.count < 3 { lpos.append(.zero); lcol.append(.zero) }
        base.lp0 = lpos[0]; base.lp1 = lpos[1]; base.lp2 = lpos[2]; base.lc0 = lcol[0]; base.lc1 = lcol[1]; base.lc2 = lcol[2]
        base.opt = SIMD4(l.m3Env ? 1 : 0, l.m3Metal ? 1 : 0, Float(l.m3View), l.m3Ao ? 1 : 0)

        let animated = model.src.isAnimated
        var vbufs: [MTLBuffer?] = []
        for (i, p) in model.prims.enumerated() {
            guard p.srcIndex < model.src.prims.count else { vbufs.append(nil); continue }
            let sp = model.src.prims[p.srcIndex]
            var vbuf = p.vbuf
            if vbuf == nil || (animated && sp.slot >= 0) {
                vbuf = sp.verts.withUnsafeBytes { core.device.makeBuffer(bytes: $0.baseAddress!, length: $0.count, options: .storageModeShared) }
            }
            if let vb = vbuf, p.vbuf == nil && !(animated && sp.slot >= 0) { model.setVBuf(i, vb) }
            vbufs.append(vbuf)
        }
        // ray tracing: this layer's own switch, or the active camera's
        var rtI: Float = l.rtOn ? l.rtInt : 0
        var rtR: Float = l.rtRad
        if let cam = Xf.camera(for: l), cam.rtOn { rtI = max(rtI, cam.rtInt); rtR = cam.rtRad }
        if R3D.g("rtAll", 0) > 0.5 { rtI = max(rtI, R3D.g("rtMul", 1)) }
        base.xtra = SIMD4(l.xf("exposure", 1) * R3D.g("exposure", 1), min(rtI * l.xf("rtAo", 1), 1), min(rtI * l.xf("rtShadow", 1), 1), l.xf("pbrNorm", 0))
        let pgOn = l.xf("pgOn", 0) > 0.5, sRatio = pgOn ? max(l.p("scale", time) / max(l.xf("pgRef", 1), 1e-4), 1e-3) : 1
        base.pg = SIMD4(pgOn ? 1 : 0, min(l.xf("pbrPom", 0), 0.06), sRatio, sRatio)
        base.wa = SIMD4(l.xf("water", 0), time, l.xf("wAmp", 0.03), l.xf("wFreq", 6))
        base.wb = SIMD4(l.xf("wSpeed", 1), l.xf("wFoam", 0.5), l.xf("wDepth", 0.5), l.xf("wChop", 0.5))
        base.wc = SIMD4(l.xf("wClar", 0.6), l.xf("wTurb", 0.15), l.xf("wRefr", 0.5), l.xf("wSss", 0.5))
        base.wd = SIMD4(l.xf("wGlint", 1), l.xf("wDetail", 0.6), l.xf("wDir", 30) * Float.pi / 180, l.xf("wSeabed", 0.7))
        base.we = SIMD4(l.xf("wVar", 0.7), l.xf("wSwell", 0.8), l.xf("wSwellLen", 0.15), l.xf("wCaps", 0.5))
        base.wf = SIMD4(mm[13], 0, hasDepth, 0)
        var accel: MTLAccelerationStructure? = nil
        if rtI > 0.001, rtLib != nil {
            if animated || model.accel == nil { model.accel = buildAccel(model, vbufs: vbufs, cb: cb) }
            accel = model.accel
        }
        let m4 = simd_float4x4(SIMD4(mm[0], mm[1], mm[2], mm[3]), SIMD4(mm[4], mm[5], mm[6], mm[7]),
                               SIMD4(mm[8], mm[9], mm[10], mm[11]), SIMD4(mm[12], mm[13], mm[14], mm[15]))
        var invM = m4.inverse
        var rtp = SIMD4<Float>(min(rtI, 1), rtR, 0, 0)

        let pd = MTLRenderPassDescriptor()
        pd.colorAttachments[0].texture = target.tex
        pd.colorAttachments[0].loadAction = .load
        pd.colorAttachments[0].storeAction = .store
        pd.depthAttachment.texture = dtex
        pd.depthAttachment.loadAction = depthDirty ? .clear : .load
        pd.depthAttachment.clearDepth = 1
        pd.depthAttachment.storeAction = .store
        depthDirty = false
        guard let enc = cb.makeRenderCommandEncoder(descriptor: pd) else { return }
        enc.setCullMode(.none)

        if let a = accel { enc.useResource(a, usage: .read) }
        enc.setFragmentTexture(depthSrc, index: 4)
        enc.setFragmentTexture(sceneTex ?? dummy, index: 5)
        if isWater, eye[1] < mm[13], let up = psoUnder(format: target.tex.pixelFormat), let ds = dsAlwaysState() {
            // camera below the surface (any camera, also the editing one): the whole picture is seen through the water
            var uu = base
            if let sp0 = model.src.prims.first { uu.color = SIMD4(sp0.color[0], sp0.color[1], sp0.color[2], sp0.color[3]) }
            var inv = simd_float4x4(SIMD4(vp[0], vp[1], vp[2], vp[3]), SIMD4(vp[4], vp[5], vp[6], vp[7]),
                                    SIMD4(vp[8], vp[9], vp[10], vp[11]), SIMD4(vp[12], vp[13], vp[14], vp[15])).inverse
            enc.setRenderPipelineState(up)
            enc.setDepthStencilState(ds)
            enc.setFragmentBytes(&uu, length: MemoryLayout<ModelU>.stride, index: 0)
            enc.setFragmentBytes(&inv, length: 64, index: 1)
            enc.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 3)
        }
        var instMs: [simd_float4x4] = [m4]
        if let sc = scatterMatrices(l, model: model, time: time) { instMs = sc }
        for im in instMs {
        base.m0 = im.columns.0; base.m1 = im.columns.1; base.m2 = im.columns.2; base.m3 = im.columns.3
        invM = im.inverse
        for (i, p) in model.prims.enumerated() where p.srcIndex < model.src.prims.count {
            let sp = model.src.prims[p.srcIndex]
            let rtPS = accel != nil ? pso(blend: sp.blend, format: target.tex.pixelFormat, rt: true) : nil
            guard let ps = rtPS ?? pso(blend: sp.blend, format: target.tex.pixelFormat) else { continue }
            guard i < vbufs.count, let vb = vbufs[i] else { continue }

            var u = base
            u.color = SIMD4(sp.color[0], sp.color[1], sp.color[2], sp.color[3])
            u.emis = SIMD4(sp.emissive[0], sp.emissive[1], sp.emissive[2], l.xf("env", 1) * R3D.g("env", 1))
            u.prm = SIMD4(sp.metal, sp.rough, sp.cutoff, sp.unlit)
            u.has = SIMD4(p.tex[0] != nil ? 1 : 0, p.tex[1] != nil ? 1 : 0, p.tex[2] != nil ? 1 : 0, p.tex[3] != nil ? 1 : 0)
            enc.setRenderPipelineState(ps)
            enc.setDepthStencilState((sp.blend && !isWater) ? dsNoWrite : dsWrite)
            enc.setVertexBytes(&u, length: MemoryLayout<ModelU>.stride, index: 0)
            enc.setFragmentBytes(&u, length: MemoryLayout<ModelU>.stride, index: 0)
            enc.setVertexBuffer(vb, offset: 0, index: 1)
            if rtPS != nil, let a = accel {
                enc.setFragmentAccelerationStructure(a, bufferIndex: 2)
                enc.setFragmentBytes(&rtp, length: 16, index: 3)
                enc.setFragmentBytes(&invM, length: 64, index: 4)
            }
            for k in 0..<4 {
                enc.setFragmentTexture(p.tex[k] ?? dummy, index: k)
                enc.setFragmentSamplerState(p.clamp[k] ? smpClamp : smpRepeat, index: k)
            }
            enc.drawIndexedPrimitives(type: p.points ? .point : .triangle, indexCount: p.count,
                                      indexType: p.idx32 ? .uint32 : .uint16, indexBuffer: p.ibuf, indexBufferOffset: 0)
        }
        }
        enc.endEncoding()
    }

    /// Scatter: raw world instance matrices for layer `l` (no model normalisation), or nil = not scattering.
    func scatterWorld(_ l: Layer, time: Float) -> [simd_float4x4]? {
        guard l.xf("scOn", 0) > 0.5 else { return nil }
        let tid = Int(l.xf("scTarget", -1))
        func f4(_ m: [Float]) -> simd_float4x4 { simd_float4x4(SIMD4(m[0], m[1], m[2], m[3]), SIMD4(m[4], m[5], m[6], m[7]), SIMD4(m[8], m[9], m[10], m[11]), SIMD4(m[12], m[13], m[14], m[15])) }
        var tris: [Scatter.Tri], tm: simd_float4x4, tl: Layer = l
        if tid == -2 || tid == -3 {
            tris = Scatter.ground(l.xf("scGroundSize", 10), l.xf("scGroundY", 0)); tm = matrix_identity_float4x4
        } else {
            guard tid != l.id, let t = Editor.scene.layers.first(where: { $0.id == tid }) else { return nil }
            tl = t
            if tl.type == .MODEL {
                guard let tp = tl.imagePath, !tp.lowercased().hasSuffix(".vdb"), let t0 = loadModel(for: tp) else { return nil }
                let mm = MetalCam.modelMatrix(tl, time: time, normalize: t0.src.normalize)
                guard mm.count == 16 else { return nil }
                tris = Scatter.tris(t0.src); tm = f4(mm)
            } else {
                let (w, h) = Xf.quadSize(tl)
                let mm = MetalCam.modelMatrix(tl, time: time, normalize: [1, 0, 0, 0])
                guard mm.count == 16 else { return nil }
                tris = Scatter.quad(w, h); tm = f4(mm)
            }
        }
        return Scatter.instances(l, target: tl, tris: tris, targetM: tm, time: time)
    }

    /// Scatter: instance matrices (already including this model's normalisation), or nil = draw normally.
    private func scatterMatrices(_ l: Layer, model: MetalModel, time: Float) -> [simd_float4x4]? {
        guard var inst = scatterWorld(l, time: time) else { return nil }
        func f4(_ m: [Float]) -> simd_float4x4 { simd_float4x4(SIMD4(m[0], m[1], m[2], m[3]), SIMD4(m[4], m[5], m[6], m[7]), SIMD4(m[8], m[9], m[10], m[11]), SIMD4(m[12], m[13], m[14], m[15])) }
        let n = model.src.normalize
        var N = simd_float4x4(diagonal: SIMD4(n[0], n[0], n[0], 1))
        N.columns.3 = SIMD4(n[0] * n[1], n[0] * n[2], n[0] * n[3], 1)       // S(n0) · T(offset)
        inst = inst.map { $0 * N }
        if l.xf("scKeep", 0) > 0.5 { inst.append(f4(MetalCam.modelMatrix(l, time: time, normalize: model.src.normalize))) }
        return inst
    }
}

extension MetalModel {
    /// Caches the static vertex buffer of prim `i`.
    func setVBuf(_ i: Int, _ b: MTLBuffer) {
        guard i < prims.count else { return }
        prims[i].vbuf = b
    }
}

extension MetalModelRenderer {
    fileprivate func depthCopyTex(_ w: Int, _ h: Int) -> MTLTexture? {
        if let t = depthCopy, t.width == w, t.height == h { return t }
        let d = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .depth32Float, width: w, height: h, mipmapped: false)
        d.usage = .shaderRead; d.storageMode = .private
        depthCopy = core.device.makeTexture(descriptor: d)
        return depthCopy
    }
    fileprivate func dummyDepth() -> MTLTexture? {
        if let t = dummyDepthT { return t }
        let d = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .depth32Float, width: 1, height: 1, mipmapped: false)
        d.usage = .shaderRead; d.storageMode = .private
        dummyDepthT = core.device.makeTexture(descriptor: d)
        return dummyDepthT
    }
    fileprivate func dsAlwaysState() -> MTLDepthStencilState? {
        if let s = dsAlways { return s }
        let d = MTLDepthStencilDescriptor()
        d.depthCompareFunction = .always; d.isDepthWriteEnabled = false
        dsAlways = core.device.makeDepthStencilState(descriptor: d)
        return dsAlways
    }
    fileprivate func psoUnder(format: MTLPixelFormat) -> MTLRenderPipelineState? {
        let key = "under/\(format.rawValue)"
        if let p = psos[key] { return p }
        guard let lib = lib, let vf = lib.makeFunction(name: "waterUnderV"), let ff = lib.makeFunction(name: "waterUnderF") else { return nil }
        let d = MTLRenderPipelineDescriptor()
        d.vertexFunction = vf; d.fragmentFunction = ff
        d.colorAttachments[0].pixelFormat = format
        d.depthAttachmentPixelFormat = .depth32Float
        guard let p = try? core.device.makeRenderPipelineState(descriptor: d) else { return nil }
        psos[key] = p
        return p
    }
}
