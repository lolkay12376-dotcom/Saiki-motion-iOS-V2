//  MetalSceneRenderer.swift
//  Metal migration stage 4 (part 2): 2D scene renderer (image / video / text / shape layers,
//  flat + precomp groups, group mattes, adjustment layers, blend modes, effect chains).
//
//  Used only when RenderBackend.useMetal is true AND the whole frame is "2D-eligible"
//  (see ineligibleReason). Otherwise the caller renders that frame with SceneRenderer (GL).
//
//  Frame life cycle (one command buffer per frame):
//    renderFrame(...)  -> encodes everything, returns false if the frame must go to GL
//    presentFrame(to:) -> blits the scene to a CAMetalLayer drawable, commits   (preview)
//    snapshotFrame()   -> commits, waits, returns a UIImage                      (thumbnails)
//    discardFrame()    -> drops an encoded frame that nobody will present

import simd
import Foundation
import Metal
import QuartzCore
import UIKit

final class MetalSceneRenderer {
    static let shared: MetalSceneRenderer? = MetalSceneRenderer()
    /// Set by the preview: called on the main thread when a video layer got a fresh frame.
    static var onVideoFrame: (() -> Void)?

    /// Effects that need GL-only machinery. Empty since stage 5b (Deep Glow now runs in MetalGlow).
    static let glOnlyEffects: Set<String> = []

    let core: MetalCore
    let passes: MetalPasses
    let fx: MetalEffects
    var quality = 1
    /// Export renders use the full motion-blur sample budget (mirrors SceneRenderer.isExport).
    var isExport = false
    private(set) var width = 576
    private(set) var height = 1024
    /// Why the last renderFrame() returned false ("" when it rendered).
    private(set) var lastFallbackReason = ""
    private(set) var buildError: String?

    private var lib: MTLLibrary?
    private var psos: [String: MTLRenderPipelineState] = [:]
    private var sceneT: MetalTarget?
    private var scratchT: MetalTarget?
    private var layerA: MetalTarget?
    private var layerB: MetalTarget?
    private var accumT: MetalTarget?
    private var groupT: MetalTarget?        // blurred-group sub-frame buffer
    private var groupAccT: MetalTarget?     // blurred-group accumulation (separate from accumT)
    private var fxSnapT: MetalTarget?       // layerA snapshot while effect layer inputs render
    private var inT0: MetalTarget?          // effect layer input 0 / 1 pictures
    private var inT1: MetalTarget?
    private var warpT: MetalTarget?         // group puppet output
    private var liveGrp: [Int: (key: String, t: MetalTarget)] = [:]   // flat picture of un-baked pre-rendered groups
    private let glow: MetalGlow?
    private let models: MetalModelRenderer
    private let volumes: MetalVolumeRenderer
    private let particles: MetalParticleRenderer
    private let flares: MetalFlareRenderer
    /// >1 while effects run on an already motion-blurred image (keeps Deep Glow's strength).
    private var glowBlurComp: Float = 1
    private var groupPool: [MetalTarget] = []
    private var groupDepth = 0
    private let images: MetalImageCache
    private var samplers: [Int: MetalVideoSampler] = [:]
    private var cb: MTLCommandBuffer?
    private var keep: [MTLTexture] = []      // per-frame textures (text) that must outlive encoding

    private init?() {
        guard let c = MetalCore.shared, let p = MetalPasses.shared, let f = MetalEffects.shared else { return nil }
        core = c; passes = p; fx = f
        images = MetalImageCache(c)
        glow = MetalGlow(p)
        models = MetalModelRenderer(c)
        volumes = MetalVolumeRenderer(c, p)
        particles = MetalParticleRenderer(c)
        flares = MetalFlareRenderer(c, p)
        do {
            lib = try c.device.makeLibrary(source: MetalSceneSL.source, options: nil)
        } catch {
            buildError = String(String(describing: error).prefix(400))
        }
    }

    var ready: Bool { lib != nil && passes.buildError == nil && glow?.ready == true }

    func trimMemory() { images.flush(); glow?.trimMemory(); models.trimMemory(); volumes.trimMemory(); flares.trimMemory() }
    func releaseVideos() { samplers.removeAll() }

    // MARK: - eligibility

    /// Flares are light: with the default blend they add onto the scene instead of covering it.
    private func flareMode(_ l: Layer) -> Int {
        l.type == .FLARE ? (l.blend == 2 ? 2 : 1) : l.blend
    }

    private func isVdb(_ l: Layer) -> Bool { l.type == .MODEL && (l.imagePath ?? "").lowercased().hasSuffix(".vdb") }

    /// Volumes draw after every other layer (stable), like GL vdbLast.
    private func vdbLast(_ ls: [Layer]) -> [Layer] {
        func isW(_ l: Layer) -> Bool { l.type == .MODEL && l.xf("water", 0) > 0.5 }      // water last: it reads the depth + picture below it
        if !ls.contains(where: { isVdb($0) || isW($0) }) { return ls }
        return ls.filter { !isVdb($0) && !isW($0) } + ls.filter { isVdb($0) } + ls.filter { isW($0) }
    }

    /// nil when the whole frame can render in Metal; otherwise the reason it must go to GL.
    func ineligibleReason(_ scene: Scene, _ time: Float) -> String? {
        for l in scene.layers where l.visible && time >= l.start - 0.001 && time <= l.end + 0.001 {
            switch l.type {
            case .FLARE:
                if !flares.ready { return "flare shader not ready" }
            case .PARTICLES:
                if !particles.ready { return "particle shader not ready" }
            case .MODEL:
                if isVdb(l) {
                    if !volumes.ready { return "volume shader not ready" }
                } else if !models.ready { return "model shader not ready" }
            default: break
            }
            if l.type == .SHAPE, Xf.isParticles(l), !particles.ready { return "particle shader not ready" }
            for entry in l.fx where !l.fxOff.contains(entry) {
                guard let d = Registry.get(entry) else { continue }
                if MetalSceneRenderer.glOnlyEffects.contains(d.id) { return "GL-only effect \(d.id)" }
                if !fx.canRun(d) { return "effect \(d.id) has no Metal shader" }
            }
        }
        return nil
    }

    // MARK: - frame entry

    /// Encodes the whole frame. false = render this frame in GL (see lastFallbackReason).
    func renderFrame(project: Project, scene: Scene, time: Float) -> Bool {
        discardFrame()
        guard ready else { lastFallbackReason = "Metal scene shaders not ready"; return false }
        Rig.apply(scene.layers, time)
        models.depthDirty = true
        if let r = ineligibleReason(scene, time) { lastFallbackReason = r; return false }
        ensureTargets(project)
        guard let st = sceneT, let buf = core.queue.makeCommandBuffer() else {
            lastFallbackReason = "no command buffer"; return false
        }
        buf.label = "SaikiMotion.frame"
        cb = buf
        keep.removeAll(keepingCapacity: true)
        groupDepth = 0

        let bg = UInt32(bitPattern: scene.bg)
        clear(st, MTLClearColor(red: Double((bg >> 16) & 0xFF) / 255, green: Double((bg >> 8) & 0xFF) / 255,
                                blue: Double(bg & 0xFF) / 255, alpha: 1))
        var visited = Set<ObjectIdentifier>()
        for l in vdbLast(scene.layers) {
            if l.parentId >= 0, let par = scene.layers.first(where: { $0.id == l.parentId }), par.type == .GROUP { continue }
            drawLayer(l, project: project, scene: scene, time: time, target: st, visited: &visited)
        }
        lastFallbackReason = ""
        return true
    }

    /// Blits the encoded frame into the layer's next drawable and commits. false = nothing shown.
    func presentFrame(to layer: CAMetalLayer) -> Bool {
        guard let buf = cb, let st = sceneT else { return false }
        guard let drawable = layer.nextDrawable(),
              let pso = passes.pipeline(fragment: "blitFragment", format: drawable.texture.pixelFormat) else {
            discardFrame(); return false
        }
        let pd = MTLRenderPassDescriptor()
        pd.colorAttachments[0].texture = drawable.texture
        pd.colorAttachments[0].loadAction = .clear
        pd.colorAttachments[0].clearColor = MTLClearColor(red: 0, green: 0, blue: 0, alpha: 1)
        pd.colorAttachments[0].storeAction = .store
        guard let enc = buf.makeRenderCommandEncoder(descriptor: pd) else { discardFrame(); return false }
        enc.setRenderPipelineState(pso)
        enc.setFragmentTexture(st.tex, index: 0)
        enc.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 3)
        enc.endEncoding()
        buf.present(drawable)
        finish(buf)
        return true
    }

    /// Commits the encoded frame, waits for the GPU and returns it as an image (offscreen path).
    func snapshotFrame() -> UIImage? {
        guard let buf = cb, let st = sceneT else { return nil }
        finish(buf)
        buf.waitUntilCompleted()
        return st.readImage()
    }

    func discardFrame() {
        // an encoded-but-never-committed buffer is simply dropped (Metal allows this)
        cb = nil
        keep.removeAll(keepingCapacity: true)
    }

    /// One-shot offscreen render for thumbnails / the frame cache. nil = use GL.
    static func thumbnail(project: Project, scene: Scene, time: Float, quality: Int) -> UIImage? {
        guard let r = shared else { return nil }
        r.quality = quality
        guard r.renderFrame(project: project, scene: scene, time: time) else { return nil }
        return r.snapshotFrame()
    }

    /// 3D editor: renders only `layers` (VDB volumes) with the exact main-viewport volume renderer, seen through `vp`.
    /// nil = Metal can't do it (caller keeps its fallback preview).
    /// Editor overlay: non-volume layers only feed occlusion (model depth / silhouettes), they never composite.
    static var occlusionOnly = false

    static func volumeOverlay(layers: [Layer], vp: [Float], time: Float, quality: Int, size: (Int, Int)? = nil, full: Bool = false) -> UIImage? {
        guard let r = shared else { return nil }
        let sc = Scene("vdb-overlay")
        sc.layers = layers; sc.fov = Editor.scene.fov; sc.bg = Int32(bitPattern: 0xFF000000)
        let oldQ = r.quality
        r.quality = quality
        MetalCam.vpOverride = vp
        occlusionOnly = !full
        SceneRenderer.sizeOverride = size
        defer { MetalCam.vpOverride = nil; occlusionOnly = false; SceneRenderer.sizeOverride = nil; r.quality = oldQ }
        guard r.renderFrame(project: Editor.project, scene: sc, time: time) else { return nil }
        return r.snapshotFrame()
    }

    private func finish(_ buf: MTLCommandBuffer) {
        let k = keep
        buf.addCompletedHandler { _ in _ = k.count }     // retain per-frame textures until the GPU is done
        buf.commit()
        cb = nil
    }

    // MARK: - targets

    private func ensureTargets(_ project: Project) {
        (width, height) = SceneRenderer.size(project, quality: quality)
        if sceneT == nil || sceneT!.width != width || sceneT!.height != height {
            sceneT = MetalTarget(core, width, height)
            scratchT = MetalTarget(core, width, height)
            layerA = MetalTarget(core, width, height)
            layerB = MetalTarget(core, width, height)
            accumT = MetalTarget(core, width, height)
            groupT = MetalTarget(core, width, height)
            groupAccT = MetalTarget(core, width, height)
            warpT = nil
            fxSnapT = nil; inT0 = nil; inT1 = nil
            liveGrp.removeAll()
            groupPool.removeAll()
        }
    }

    private func poolTarget(_ d: Int) -> MetalTarget {
        while groupPool.count <= d { groupPool.append(MetalTarget(core, width, height)) }
        return groupPool[d]
    }

    private func clear(_ t: MetalTarget, _ c: MTLClearColor = MTLClearColor(red: 0, green: 0, blue: 0, alpha: 0)) {
        guard let buf = cb, let enc = buf.makeRenderCommandEncoder(descriptor: t.passDescriptor(clear: c)) else { return }
        enc.endEncoding()
    }

    // MARK: - per layer (port of SceneRenderer.drawLayer, 2D subset)

    private func drawLayer(_ l: Layer, project: Project, scene: Scene, time: Float, target: MetalTarget,
                           visited: inout Set<ObjectIdentifier>) {
        guard l.visible, time >= l.start - 0.001, time <= l.end + 0.001 else { return }
        if Self.occlusionOnly, !isVdb(l) {
            // fills the shared model depth so volumes behind this model are hidden; colour is thrown away
            if l.type == .MODEL, let a = layerA, let buf = cb { clear(a); models.draw(l, time: time, fov: Editor.scene.fov, into: a, cb: buf) }
            return
        }
        let id = ObjectIdentifier(l)
        if visited.contains(id) { return }
        visited.insert(id)
        defer { visited.remove(id) }

        switch l.type {
        case .AUDIO, .CAMERA, .NULL:
            return
        case .GROUP:
            if l.prerender, PreRender.enabled {
                drawPreRenderedGroup(l, project: project, scene: scene, time: time, target: target, visited: &visited)
            } else if l.mask == 0, l.mblur || (Xf.camera(for: l)?.mblur ?? false) {
                if let img = blurredGroupImage(l, project: project, scene: scene, time: time, visited: &visited) {
                    composite(target, src: img.tex, alpha: l.p("opacity", time), mode: l.blend)
                }
            } else {
                drawGroup(l, project: project, scene: scene, time: time, target: target, visited: &visited)
            }
            return
        default:
            break
        }

        let tw = twitchRetime(l, project: project, time)
        let opacity = l.p("opacity", l.editTime("opacity", tw))
        let moveFx = movingFx(l, tw)
        let mb = motionBlurPlan(l, time: tw, moveFx: moveFx)
        if l.is3d, l.type != .ADJUST,
           l.fx.contains(where: { !l.fxOff.contains($0) && Registry.get($0)?.id == "motiontile" }) {
            // Motion Tile on a 3D layer: tile the layer flat, then place the tiled plane in 3D
            let savedCam = SceneRenderer.editCam
            SceneRenderer.editCam = nil
            Xf.flatDraw = true; Xf.bakingPlane = true; Xf.bakeRoot = l.id
            renderLayerContent(l, time: tw, target: target)
            applyEffects(l, time: tw)
            Xf.flatDraw = false; Xf.bakingPlane = false; Xf.bakeRoot = -1
            SceneRenderer.editCam = savedCam
            if let a = layerA { placePlane(l, src: a.tex, time: tw, target: target, opacity: opacity) }
            return
        }
        if mb.samples > 1, let acc = accumT {
            drawMotionBlurred(l, plan: mb, moveFx: moveFx, time: tw, opacity: opacity, acc: acc, target: target)
        } else if (l.type == .IMAGE || l.type == .VIDEO) && l.blend == 0 && l.mask == 0 && l.fx.isEmpty
                    && nearerOccluders(l, scene: scene, time: tw, visited: visited).isEmpty {
            // fast path: one blended quad straight into the target
            if opacity <= 0.0005 { return }
            _ = drawMedia(l, time: tw, opacity: opacity, into: target, clear: false, blend: true)
        } else {
            renderLayerContent(l, time: tw, target: target)
            applyEffects(l, time: tw)
            cutByNearer3D(l, scene: scene, time: tw, visited: visited)
            composite(target, src: layerA!.tex, alpha: opacity, mode: flareMode(l))
        }
    }

    /// Port of GL cutByNearer3D (occlusion): cuts the layer in layerA by the silhouette of every
    /// nearer occluding 3D layer. Occluders that are groups have no silhouette here (renderLayerContent
    /// draws only image / video / text / shape).
    /// Nearer occluding 3D layers (media planes, models, VDB volumes) that should cut layer `l`.
    /// Models already depth-test each other, so a model is only cut by non-model occluders.
    private func nearerOccluders(_ l: Layer, scene: Scene, time: Float, visited: Set<ObjectIdentifier>) -> [Layer] {
        guard l.occlude, l.is3d || l.type == .MODEL, !Xf.flatDraw else { return [] }
        let z = Xf.worldZ(l, time)
        let depthModel = l.type == .MODEL && !isVdb(l)
        return scene.layers.filter { o in
            o !== l && o.visible && o.occlude && (o.is3d || o.type == .MODEL) && o.type != .ADJUST
                && o.parentId == l.parentId && o.isRenderable() && o.type != .PARTICLES && o.type != .FLARE
                && time >= o.start - 0.001 && time <= o.end + 0.001 && !visited.contains(ObjectIdentifier(o))
                && Xf.worldZ(o, time) > z + 0.001 && o.p("opacity", time) > 0.5
                && !(depthModel && o.type == .MODEL && !isVdb(o))
        }
    }

    private func cutByNearer3D(_ l: Layer, scene: Scene, time: Float, visited: Set<ObjectIdentifier>) {
        let occ = nearerOccluders(l, scene: scene, time: time, visited: visited)
        guard !occ.isEmpty, let a = layerA, let b = layerB, let c = accumT, let cbuf = cb else { return }
        _ = passes.blit(cbuf, src: a.tex, to: c)                                  // snapshot of the layer
        for o in occ {
            renderLayerContent(o, time: time, target: a)                          // occluder -> layerA
            _ = passes.blit(cbuf, src: a.tex, to: b)                              // its silhouette
            clear(a)
            composite(a, src: c.tex, mask: b.tex, maskMode: 2, alpha: 1, mode: 0)
            _ = passes.blit(cbuf, src: a.tex, to: c)
        }
    }

    // MARK: - motion blur (port of the SceneRenderer.drawLayer sub-frame accumulation, 2D subset)

    private struct MBPlan { var samples = 1; var shutter: Float = 0; var amount: Float = 0 }

    /// Effects that move the picture themselves; blurred by evaluating the effects at every sample.
    private func movingFx(_ l: Layer, _ time: Float) -> Bool {
        for e in l.fx where !l.fxOff.contains(e) {
            switch Registry.get(e)?.id {
            case "oscillate", "randisp": return true
            case "motiontile":
                if l.p(e + "__mtScrollX", time) != 0 || l.p(e + "__mtScrollY", time) != 0 { return true }
            case "twitch":
                if l.p(e + "__twEnSlide", time) >= 0.5 || l.p(e + "__twEnScale", time) >= 0.5 { return true }
            default: break
            }
        }
        return false
    }

    private func mbJitter(_ s: Int, _ time: Float) -> Float {
        var h = UInt32(truncatingIfNeeded: s &* 73856093) ^ UInt32(truncatingIfNeeded: Int(time * 1000) &* 19349663)
        h = (h ^ (h >> 13)) &* 1274126177
        h ^= h >> 16
        return Float(h & 0xFFFF) / 65536
    }

    /// Max on-screen distance (pixels) a quad corner/centre travels over the shutter (3D layers are
    /// projected through the camera VP like the GL version; particles are not in Metal).
    private func screenTravel(_ l: Layer, time: Float, shutter: Float) -> Float {
        var (qw, qh) = Xf.quadSize(l)
        let isPart = l.type == .PARTICLES || l.fx.contains("particles")
        if isPart { qw *= 2.5; qh *= 2.5 }
        let useCam = l.is3d || (isPart && Xf.camera(for: l) != nil)
        let ar = Float(width) / Float(max(height, 1))
        let halfW = Float(width) * 0.5, halfH = Float(height) * 0.5
        func proj(_ t: Float, _ cx: Float, _ cy: Float) -> (Float, Float)? {
            let m = Xf.matrix(l, t)
            let x = cx * qw, y = cy * qh
            let wx = m[0] * x + m[2] * y + m[4], wy = m[1] * x + m[3] * y + m[5]
            if useCam {
                let z = Xf.worldZ(l, t)
                if let vp = MetalCam.vp(for: l, time: t, width: width, height: height) {
                    let cw = vp[3] * wx + vp[7] * wy + vp[11] * z + vp[15]
                    if cw < 0.02 { return nil }
                    return ((vp[0] * wx + vp[4] * wy + vp[8] * z + vp[12]) / cw,
                            (vp[1] * wx + vp[5] * wy + vp[9] * z + vp[13]) / cw)
                }
                let w = 1 - z / 3
                if w < 0.02 { return nil }
                return (wx / ar / w, wy / w)
            }
            return (wx / ar, wy)
        }
        var best: Float = 0
        let pts: [(Float, Float)] = [(-0.5, -0.5), (0.5, -0.5), (-0.5, 0.5), (0.5, 0.5), (0, 0)]
        for (cx, cy) in pts {
            guard let a = proj(time - shutter * 0.5, cx, cy), let b = proj(time + shutter * 0.5, cx, cy) else { continue }
            let dx = (a.0 - b.0) * halfW, dy = (a.1 - b.1) * halfH
            best = max(best, (dx * dx + dy * dy).squareRoot())
        }
        return best
    }

    private func motionBlurPlan(_ l: Layer, time: Float, moveFx: Bool) -> MBPlan {
        var plan = MBPlan()
        guard l.mblur || (Xf.camera(for: l)?.mblur ?? false) else { return plan }
        plan.amount = l.p("mbAmount", time)
        plan.shutter = 0.12 * plan.amount
        let cap = min(Int(max(2, l.p("mbSamples", time))), 64)
        let camMoves = (Xf.camera(for: l) != nil) && (l.is3d || l.type == .MODEL || l.type == .PARTICLES)
        let hasParticles = Xf.isParticles(l)
        let content = l.type == .VIDEO || l.type == .PARTICLES || l.type == .MODEL || l.type == .FLARE || !l.fx.isEmpty || camMoves
        let px = screenTravel(l, time: time, shutter: plan.shutter)
        var n = 1
        if px >= 0.5 {
            n = min(hasParticles ? (isExport ? 32 : 6) : (isExport ? 64 : 10), max(isExport ? 8 : 4, Int(px.rounded(.up)) / (isExport ? 1 : 2) + 1))
        } else if content && !hasParticles && l.type != .ADJUST && l.type != .IMAGE && l.type != .TEXT && l.type != .SHAPE && l.type != .FLARE && l.type != .MODEL {
            n = min(cap, isExport ? 6 : 3)      // only video (internal motion) needs averaging when nothing moves
        }
        if l.type == .ADJUST { n = 1 }          // averaging copies of the scene only dims glow/bloom
        else if moveFx { n = max(n, isExport ? 96 : 12) }
        plan.samples = n
        return plan
    }

    private func drawMotionBlurred(_ l: Layer, plan: MBPlan, moveFx: Bool, time: Float, opacity: Float,
                                   acc: MetalTarget, target: MetalTarget) {
        guard let cbuf = cb, let a = layerA else { return }
        let n = plan.samples
        if Xf.isParticles(l) { particles.simTime = time }
        defer { particles.simTime = nil }
        clear(acc)
        for s in 0..<n {
            models.depthDirty = true
            let u = (Float(s) + mbJitter(s, time)) / Float(n)
            var st = time - plan.shutter * (u - 0.5)
            if l.mbStutter { st = time - plan.shutter * 0.5 * (Float(s) / Float(max(n - 1, 1)) - 0.5).rounded() }
            let t = min(max(st, l.start), l.end)
            renderLayerContent(l, time: t, target: target)
            if moveFx { applyEffects(l, time: t) }
            composite(acc, src: a.tex, alpha: 1 / Float(s + 1), mode: 5,
                      rgbShift: l.mbRgb ? (u - 0.5) * 0.004 * plan.amount : 0)
        }
        if !l.fx.isEmpty && !moveFx {
            // effects run once on the blurred result; blurred content is dimmer, so keep Deep Glow's strength
            glowBlurComp = 2.4
            defer { glowBlurComp = 1 }
            _ = passes.blit(cbuf, src: acc.tex, to: a)
            applyEffects(l, time: time)
            composite(target, src: a.tex, alpha: opacity, mode: flareMode(l))
        } else {
            composite(target, src: acc.tex, alpha: opacity, mode: flareMode(l))
        }
    }

    /// Port of drawGroup: a precomp renders its children into a private buffer, then mask, group
    /// effects, opacity and blend are applied to that one image.
    private func drawGroup(_ g: Layer, project: Project, scene: Scene, time: Float, target: MetalTarget,
                           visited: inout Set<ObjectIdentifier>) {
        let children = scene.layers.filter { $0.parentId == g.id }
        guard !children.isEmpty else { return }
        let opacity = g.p("opacity", time)
        let hasFx = !g.fx.isEmpty
        let hasPuppet = (g.puppet?.on ?? false) && !(g.puppet?.pins.isEmpty ?? true)
        guard g.precomp || g.mask != 0 || hasFx || hasPuppet, groupDepth < 4 else {
            for c in vdbLast(children) {
                drawLayer(c, project: project, scene: scene, time: time, target: target, visited: &visited)
            }
            return
        }
        if let img = precompImage(g, children: children, project: project, scene: scene, time: time, visited: &visited) {
            var src = img.tex
            if hasPuppet, let warped = warpGroupImage(g, img, time: time) { src = warped }
            composite(target, src: src, alpha: opacity, mode: g.blend)
        }
    }

    /// Puppet on a group: draws the flattened group image through the pin-deformed mesh (GL warpGroupImage).
    private func warpGroupImage(_ g: Layer, _ img: MetalTarget, time: Float) -> MTLTexture? {
        guard let pm = PuppetMath.mesh(g, time) else { return nil }
        if warpT == nil || warpT!.width != width || warpT!.height != height { warpT = MetalTarget(core, width, height) }
        guard let out = warpT else { return nil }
        var u = QuadU()
        u.flipY = 1
        guard drawQuadPass("quadFragment", blend: false, into: out, clear: true, u: u, tex: img.tex,
                           mesh: pm, warp: true) else { return nil }
        return out.tex
    }

    // MARK: - pre-rendered groups (baked frames drawn as a flat plane)

    /// Loads the baked frame of `g` nearest to `time` (GL read-pixels order: bottom row first) into a
    /// top-row-first texture. nil when this frame is not baked (the group then renders live).
    private func preRenderTexture(_ g: Layer, project: Project, scene: Scene, time: Float) -> MTLTexture? {
        let sig = PreRender.signature(g, project: project, scene: scene)
        let idx = PreRender.frameIndex(time, project.fps)
        guard let raw = PreRender.load(project.id, g.id, sig, width, height, idx) else { return nil }
        let d = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .rgba8Unorm, width: width, height: height, mipmapped: false)
        d.usage = .shaderRead
        d.storageMode = .shared
        guard let t = core.device.makeTexture(descriptor: d) else { return nil }
        let row = width * 4, h = height
        var flipped = [UInt8](repeating: 0, count: row * h)
        raw.withUnsafeBytes { srcB in
            flipped.withUnsafeMutableBytes { dstB in
                guard let sp = srcB.baseAddress, let dp = dstB.baseAddress else { return }
                for y in 0..<h { memcpy(dp + (h - 1 - y) * row, sp + y * row, row) }
            }
        }
        t.replace(region: MTLRegionMake2D(0, 0, width, height), mipmapLevel: 0, withBytes: flipped, bytesPerRow: row)
        keep.append(t)
        return t
    }

    private func drawPreRenderedGroup(_ l: Layer, project: Project, scene: Scene, time: Float,
                                      target: MetalTarget, visited: inout Set<ObjectIdentifier>) {
        if let tex = preRenderTexture(l, project: project, scene: scene, time: time) {
            drawBakedPlane(l, tex: tex, time: time, target: target)
            return
        }
        let kids = scene.layers.filter { $0.parentId == l.id }
        guard !kids.isEmpty else { return }          // not baked yet: same look, rendered live
        let ckey = PreRender.signature(l, project: project, scene: scene)
            + "|\(PreRender.frameIndex(time, project.fps))|\(width)x\(height)"
        if let c = liveGrp[l.id], c.key == ckey {
            drawBakedPlane(l, tex: c.t.tex, time: time, target: target)
            return
        }
        let savedCam = SceneRenderer.editCam
        SceneRenderer.editCam = nil
        Xf.bakingPlane = true; Xf.bakeRoot = l.id
        let img = (l.mblur && l.mask == 0)
            ? blurredGroupImage(l, project: project, scene: scene, time: time, visited: &visited)
            : precompImage(l, children: kids, project: project, scene: scene, time: time, visited: &visited, ownFx: false)
        Xf.bakingPlane = false; Xf.bakeRoot = -1
        SceneRenderer.editCam = savedCam
        guard let im = img, let cbuf = cb else { return }
        let ct: MetalTarget
        if let old = liveGrp[l.id]?.t, old.width == width, old.height == height { ct = old } else { ct = MetalTarget(core, width, height) }
        _ = passes.blit(cbuf, src: im.tex, to: ct)
        liveGrp[l.id] = (ckey, ct)
        drawBakedPlane(l, tex: ct.tex, time: time, target: target)
    }

    /// Group effects run live on the baked picture (never part of the bake), then the flat picture is
    /// placed with the group's transform (and 3D / camera, see placePlane).
    private func drawBakedPlane(_ g: Layer, tex: MTLTexture, time: Float, target: MetalTarget) {
        guard let a = layerA, layerB != nil, let cbuf = cb else { return }
        let opacity = g.p("opacity", time)
        var src = tex
        if !g.fx.isEmpty {
            _ = passes.blit(cbuf, src: tex, to: a)
            applyEffects(g, time: time)
            src = a.tex
        }
        placePlane(g, src: src, time: time, target: target, opacity: opacity)
    }

    /// Port of GL drawPlane: the flat picture `src` placed with the group's transform, 3D rotation
    /// (3D groups) and the scene / edit camera, then composited with opacity and blend.
    private func placePlane(_ g: Layer, src: MTLTexture, time: Float, target: MetalTarget, opacity: Float) {
        guard let b = layerB else { return }
        var vp: [Float]? = nil
        if g.is3d || Xf.camera(for: g) != nil {
            vp = MetalCam.vp(for: g, time: time, width: width, height: height)
            if let v = vp, !v.allSatisfy({ $0.isFinite }) {      // broken camera: plain composite
                composite(target, src: src, alpha: opacity, mode: g.blend); return
            }
        }
        let ar = Float(width) / Float(max(height, 1))
        let m = Xf.matrix(g, time)
        var u = QuadU()
        u.abcd = SIMD4<Float>(m[0], m[1], m[2], m[3])
        u.t = SIMD2<Float>(m[4], m[5])
        u.quad = SIMD2<Float>(ar * 2, 2)
        u.aspect = ar
        u.flipY = 1
        if g.is3d || vp != nil { set3D(&u, g, time: time, rotate: g.is3d, vp: vp) }
        guard drawQuadPass("quadFragment", blend: false, into: b, clear: true, u: u, tex: src) else { return }
        composite(target, src: b.tex, alpha: opacity, mode: g.blend)
    }

    // MARK: - group motion blur (port of blurredGroupImage)

    /// The motion-blurred picture of a group (before opacity / blend); lives in groupAccT.
    private func blurredGroupImage(_ g: Layer, project: Project, scene: Scene, time: Float,
                                   visited: inout Set<ObjectIdentifier>) -> MetalTarget? {
        let children = scene.layers.filter { $0.parentId == g.id }
        guard !children.isEmpty, let acc = groupAccT, let grp = groupT else { return nil }
        let amount = g.p("mbAmount", time)
        let shutter = 0.12 * amount
        var travel: Float = 0
        for c in children { travel = max(travel, screenTravel(c, time: time, shutter: shutter)) }
        let n = travel >= 0.5
            ? min(isExport ? 48 : 8, max(isExport ? 8 : 4, Int(travel.rounded(.up)) / (isExport ? 1 : 3) + 1))
            : min(Int(max(2, g.p("mbSamples", time))), isExport ? 12 : 4)
        clear(acc)
        for s in 0..<n {
            models.depthDirty = true
            let st = min(max(time - shutter * ((Float(s) + mbJitter(s, time)) / Float(n) - 0.5), g.start), g.end)
            clear(grp)
            for c in vdbLast(children) {
                drawLayer(c, project: project, scene: scene, time: st, target: grp, visited: &visited)
            }
            composite(acc, src: grp.tex, alpha: 1 / Float(s + 1), mode: 5)
        }
        return acc
    }

    /// Port of precompImage. NOTE (matte): the matte is the first child's finished content (layerA
    /// after its effects). The GL code composites with layerB.tex, which only holds that content
    /// when the matte child's effect chain happens to end in layerB (e.g. exactly one effect).
    private func precompImage(_ g: Layer, children: [Layer], project: Project, scene: Scene, time: Float,
                              visited: inout Set<ObjectIdentifier>, ownFx: Bool = true) -> MetalTarget? {
        guard groupDepth < 4, let a = layerA, let cbuf = cb else { return nil }
        let grp = poolTarget(groupDepth)
        groupDepth += 1
        defer { groupDepth -= 1 }

        clear(grp)
        for c in vdbLast(children) {
            drawLayer(c, project: project, scene: scene, time: time, target: grp, visited: &visited)
        }

        if g.mask != 0, let first = children.first, first.isRenderable() {
            renderLayerContent(first, time: time, target: grp)
            applyEffects(first, time: time)
            composite(grp, src: grp.tex, mask: a.tex, maskMode: g.mask, alpha: 1, mode: 0)
        }

        _ = passes.blit(cbuf, src: grp.tex, to: a)
        if ownFx && !g.fx.isEmpty { applyEffects(g, time: time) }
        return a
    }

    /// Port of renderLayerContent: draws the layer's own content into layerA (cleared first).
    private func renderLayerContent(_ l: Layer, time: Float, target: MetalTarget) {
        guard let a = layerA, let cbuf = cb else { return }
        var drew = false
        switch l.type {
        case .IMAGE, .VIDEO:
            drew = drawMedia(l, time: time, opacity: 1, into: a, clear: true, blend: false)
        case .TEXT:
            drew = drawText(l, time: time, into: a)
        case .SHAPE:
            if Xf.isParticles(l) {
                // "Particles" added from the + menu is a Shape layer carrying the particles effect
                clear(a)
                if l.p("pShowSrc", l.editTime("pShowSrc", time)) >= 0.5 { _ = drawShape(l, time: time, into: a) }
                particles.draw(l, time: time, fov: Editor.scene.fov, into: a, cb: cbuf)
                drew = true
            } else {
                drew = drawShape(l, time: time, into: a)
            }
        case .FLARE:
            clear(a)
            flares.draw(l, time: time, fov: Editor.scene.fov, isExport: isExport, into: a, cb: cbuf)
            drew = true
        case .PARTICLES:
            clear(a)
            if l.p("pShowSrc", l.editTime("pShowSrc", time)) >= 0.5 { _ = drawShape(l, time: time, into: a) }
            particles.draw(l, time: time, fov: Editor.scene.fov, into: a, cb: cbuf)
            drew = true
        case .MODEL:
            clear(a)
            if isVdb(l), let path = l.imagePath {
                func flat(_ m: simd_float4x4) -> [Float] { [m.columns.0, m.columns.1, m.columns.2, m.columns.3].flatMap { [$0.x, $0.y, $0.z, $0.w] } }
                var overrides: [[Float]?] = [nil]
                if let inst = models.scatterWorld(l, time: time) {
                    let vpv = MetalCam.vpForModel(l, fov: Editor.scene.fov, time: time, width: a.width, height: a.height)
                    func depth(_ m: simd_float4x4) -> Float { vpv[3] * m.columns.3.x + vpv[7] * m.columns.3.y + vpv[11] * m.columns.3.z + vpv[15] }
                    overrides = inst.sorted { depth($0) > depth($1) }.prefix(24).map { flat($0) }   // far -> near; 24 copies max
                    if l.xf("scKeep", 0) > 0.5 { overrides.append(nil) }
                }
                for ov in overrides {
                    volumes.draw(l, path: path, time: time, fov: Editor.scene.fov, into: a, sceneTex: target.tex,
                                 depth: l.occlude ? models.occlusionDepth() : nil, cb: cbuf, mmOverride: ov, accumulate: overrides.count > 1)
                }
            } else {
                models.draw(l, time: time, fov: Editor.scene.fov, into: a, cb: cbuf, sceneTex: target.tex)
            }
            drew = true
        case .ADJUST:
            drew = passes.blit(cbuf, src: target.tex, to: a)     // content = the buffer below
        default:
            break
        }
        if !drew { clear(a) }
    }

    // MARK: - drawing primitives

    private func composite(_ target: MetalTarget, src: MTLTexture, mask: MTLTexture? = nil, maskMode: Int = 0,
                           alpha: Float, mode: Int, rgbShift: Float = 0) {
        guard let buf = cb, let scratch = scratchT else { return }
        _ = passes.composite(buf, target: target, scratch: scratch, src: src, mask: mask,
                             alpha: alpha, mode: mode, maskMode: maskMode, rgbShift: rgbShift)
    }

    private func pso(_ fragment: String, blend: Bool, format: MTLPixelFormat,
                     vertex: String = "quadVertex") -> MTLRenderPipelineState? {
        let key = "\(vertex)/\(fragment)/\(blend)/\(format.rawValue)"
        if let p = psos[key] { return p }
        guard let lib = lib, let vf = lib.makeFunction(name: vertex),
              let ff = lib.makeFunction(name: fragment) else { return nil }
        let d = MTLRenderPipelineDescriptor()
        d.vertexFunction = vf
        d.fragmentFunction = ff
        let ca = d.colorAttachments[0]!
        ca.pixelFormat = format
        if blend {                              // glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA)
            ca.isBlendingEnabled = true
            ca.sourceRGBBlendFactor = .one
            ca.destinationRGBBlendFactor = .oneMinusSourceAlpha
            ca.sourceAlphaBlendFactor = .one
            ca.destinationAlphaBlendFactor = .oneMinusSourceAlpha
        }
        guard let p = try? core.device.makeRenderPipelineState(descriptor: d) else { return nil }
        psos[key] = p
        return p
    }

    private func quadUniforms(_ l: Layer, time: Float) -> QuadU {
        let (qw, qh) = Xf.quadSize(l)
        let m = Xf.matrix(l, time)
        var u = QuadU()
        u.abcd = SIMD4<Float>(m[0], m[1], m[2], m[3])
        u.t = SIMD2<Float>(m[4], m[5])
        u.quad = SIMD2<Float>(qw, qh)
        u.aspect = Float(width) / Float(max(height, 1))
        if l.is3d && !Xf.flatDraw {
            var vp = MetalCam.vp(for: l, time: time, width: width, height: height)
            if let v = vp, !v.allSatisfy({ $0.isFinite }) { vp = nil }   // broken camera: draw flat, never vanish
            set3D(&u, l, time: time, rotate: true, vp: vp)
        }
        return u
    }

    /// Port of the GL uRot / uZ / uVP / uInvCam uniforms. rotate = apply the layer's rotX/rotY/z;
    /// vp = camera view-projection (nil = default z=3 perspective).
    private func set3D(_ u: inout QuadU, _ l: Layer, time: Float, rotate: Bool, vp: [Float]?) {
        var rx: Float = 0, ry: Float = 0, zz: Float = 0
        if rotate {
            let lt = l.editTime("x", time)
            let d = Float.pi / 180
            rx = l.p("rotX", lt) * d
            ry = -l.p("rotY", lt) * d
            zz = Xf.worldZ(l, time)
            if !zz.isFinite { zz = 0 }
        }
        u.rot3 = SIMD4<Float>(rx, ry, zz, 1.0 / 3.0)
        u.flags = SIMD4<Float>(vp != nil ? 1 : 0, 1, 0, 0)
        if let v = vp, v.count == 16 {
            u.vp0 = SIMD4<Float>(v[0], v[1], v[2], v[3])
            u.vp1 = SIMD4<Float>(v[4], v[5], v[6], v[7])
            u.vp2 = SIMD4<Float>(v[8], v[9], v[10], v[11])
            u.vp3 = SIMD4<Float>(v[12], v[13], v[14], v[15])
        }
    }

    @discardableResult
    private func drawQuadPass(_ frag: String, blend: Bool, into t: MetalTarget, clear doClear: Bool,
                              u: QuadU, tex: MTLTexture?,
                              mesh: (pos: [Float], uv: [Float], idx: [UInt16])? = nil, warp: Bool = false) -> Bool {
        guard let buf = cb else { return false }
        // puppet mesh: expand the indexed mesh into a plain triangle list held in two device buffers
        var pb: MTLBuffer?, ub: MTLBuffer?
        var count = 4
        if let m = mesh {
            var ep: [SIMD2<Float>] = [], eu: [SIMD2<Float>] = []
            ep.reserveCapacity(m.idx.count); eu.reserveCapacity(m.idx.count)
            for i in m.idx {
                let k = Int(i) * 2
                guard k + 1 < m.pos.count, k + 1 < m.uv.count else { continue }
                ep.append(SIMD2(m.pos[k], m.pos[k + 1])); eu.append(SIMD2(m.uv[k], m.uv[k + 1]))
            }
            count = ep.count - ep.count % 3
            guard count >= 3 else { return false }
            pb = core.device.makeBuffer(bytes: ep, length: count * MemoryLayout<SIMD2<Float>>.stride, options: .storageModeShared)
            ub = core.device.makeBuffer(bytes: eu, length: count * MemoryLayout<SIMD2<Float>>.stride, options: .storageModeShared)
            guard pb != nil, ub != nil else { return false }
        }
        let vname = mesh == nil ? "quadVertex" : (warp ? "warpVertex" : "meshVertex")
        guard let p = pso(frag, blend: blend, format: t.tex.pixelFormat, vertex: vname) else { return false }
        let pd = t.passDescriptor(clear: doClear ? MTLClearColor(red: 0, green: 0, blue: 0, alpha: 0) : nil)
        guard let enc = buf.makeRenderCommandEncoder(descriptor: pd) else { return false }
        var uu = u
        enc.setRenderPipelineState(p)
        enc.setVertexBytes(&uu, length: MemoryLayout<QuadU>.stride, index: 0)
        enc.setFragmentBytes(&uu, length: MemoryLayout<QuadU>.stride, index: 0)
        if let tx = tex { enc.setFragmentTexture(tx, index: 0) }
        if mesh != nil {
            enc.setVertexBuffer(pb, offset: 0, index: 1)
            enc.setVertexBuffer(ub, offset: 0, index: 2)
            enc.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: count)
        } else {
            enc.drawPrimitives(type: .triangleStrip, vertexStart: 0, vertexCount: 4)
        }
        enc.endEncoding()
        return true
    }

    private func drawMedia(_ l: Layer, time: Float, opacity: Float, into t: MetalTarget,
                           clear: Bool, blend: Bool) -> Bool {
        guard let path = l.imagePath else { return false }
        var tex: MTLTexture?
        if l.type == .VIDEO { tex = sampler(for: l, path: path).texture(at: sourceTime(l, time)) }
        if tex == nil { tex = images.texture(path: path, quality: quality) }
        guard let tx = tex else { return false }
        var u = quadUniforms(l, time: time)
        u.color = SIMD4<Float>(opacity, opacity, opacity, opacity)
        u.flipY = 1
        return drawQuadPass("quadFragment", blend: blend, into: t, clear: clear, u: u, tex: tx,
                            mesh: PuppetMath.mesh(l, time))
    }

    private func drawText(_ l: Layer, time: Float, into t: MetalTarget) -> Bool {
        let img = TextRaster.raster(l, time)
        guard img.size.width > 1, img.size.height > 1,
              let up = MetalImageUpload.texture(core, img, maxSide: 4096) else { return false }
        keep.append(up.tex)
        var u = quadUniforms(l, time: time)
        u.flipY = 1
        return drawQuadPass("quadFragment", blend: false, into: t, clear: true, u: u, tex: up.tex,
                            mesh: PuppetMath.mesh(l, time))
    }

    private func drawShape(_ l: Layer, time: Float, into t: MetalTarget) -> Bool {
        var u = quadUniforms(l, time: time)
        let c = UInt32(bitPattern: l.color)
        u.color = SIMD4<Float>(Float((c >> 16) & 0xFF) / 255, Float((c >> 8) & 0xFF) / 255,
                               Float(c & 0xFF) / 255, Float((c >> 24) & 0xFF) / 255)
        switch l.shape {
        case .RECT: u.kind = 0
        case .ROUND: u.kind = 1
        case .CIRCLE: u.kind = 2
        case .TRIANGLE: u.kind = 3
        case .STAR: u.kind = 4
        }
        u.corner = 0.12
        return drawQuadPass("shapeFragment", blend: false, into: t, clear: true, u: u, tex: nil,
                            mesh: PuppetMath.mesh(l, time))
    }

    private func sampler(for l: Layer, path: String) -> MetalVideoSampler {
        if let s = samplers[l.id] { return s }
        let s = MetalVideoSampler(path: path, device: core.device)
        s.onFrame = { MetalSceneRenderer.onVideoFrame?() }
        samplers[l.id] = s
        return s
    }

    /// Source-media time for a video layer at scene time `t` (remap aware) — copy of SceneRenderer.sourceTime.
    /// Twitch "Time" operator: random frame snaps of the layer's own footage (port of GL twitchRetime).
    private func twitchRetime(_ l: Layer, project: Project, _ time: Float) -> Float {
        guard !l.fx.isEmpty else { return time }
        var t = time
        for e in l.fx where !l.fxOff.contains(e) && Registry.get(e)?.id == "twitch" {
            guard l.p(e + "__twEnTime", time) >= 0.5 else { continue }
            let k = e + "__"
            let step = floor(time * 8 * l.p(k + "twSpeed", time) * l.p(k + "twTmSpeed", time))
            let seed = l.p(k + "twTmSeed", time)
            func h(_ a: Float) -> Float {
                var x = UInt32(truncatingIfNeeded: Int(a * 1000)) &* 2654435761
                x = (x ^ (x >> 15)) &* 2246822519; x ^= x >> 13
                return Float(x & 0xFFFF) / 65536
            }
            guard h(step * 3.1 + seed * 7.7) < l.p(k + "twTmTwitches", time) else { continue }
            let frames = (h(step * 5.3 + seed + 1) * 2 - 1) * l.p(k + "twTmAmount", time) * l.p(k + "twAmount", time)
            t += frames.rounded() / Float(max(1, project.fps))
        }
        return min(max(t, l.start), l.end)
    }

    private func sourceTime(_ l: Layer, _ t: Float) -> Float {
        if let tr = l.props["remapT"], !tr.keys.isEmpty {
            return max(0, tr.eval(t) + l.srcOffset)
        }
        let sp = l.props["remapSpeed"]?.eval(t) ?? 1
        return max(0, (t - l.start) * sp + l.srcOffset)
    }

    // MARK: - effects (port of SceneRenderer.applyEffects through MetalEffects)

    private func paramValue(_ l: Layer, key: String, def: Float, time: Float) -> Float {
        if let tr = l.props[key] {
            return tr.evalExpr(l.editTime(key, time), time, tr.exprActive() ? Editor.scene.markersByName() : [:])
        }
        return def
    }

    private func colorComp(_ l: Layer, key: String, def: Float, time: Float) -> Float {
        if let tr = l.props[key] { return tr.eval(l.editTime(key, time)) }
        return def
    }

    private func effectSteps(_ l: Layer, time: Float) -> [MetalEffects.Step] {
        var out: [MetalEffects.Step] = []
        for entry in l.fx where !l.fxOff.contains(entry) {
            guard let d = Registry.get(entry) else { continue }
            let single = d.kind == 1
            var props: [Float] = []
            for pd in d.props {
                let key = single ? pd.key : entry + "__" + pd.key
                props.append(paramValue(l, key: key, def: pd.def, time: time))
            }
            var cols: [SIMD4<Float>] = []
            for cp in d.colors {
                let base = single ? cp.key : entry + "__" + cp.key
                let c = UInt32(bitPattern: cp.def)
                let r = colorComp(l, key: base + "_r", def: Float((c >> 16) & 0xFF) / 255, time: time)
                let g = colorComp(l, key: base + "_g", def: Float((c >> 8) & 0xFF) / 255, time: time)
                let b = colorComp(l, key: base + "_b", def: Float(c & 0xFF) / 255, time: time)
                let a = colorComp(l, key: base + "_a", def: Float((c >> 24) & 0xFF) / 255, time: time)
                cols.append(SIMD4<Float>(r, g, b, a))
            }
            var step = MetalEffects.Step(def: d, props: props, colors: cols)
            for (slot, nm) in d.inputs.enumerated() where slot < 2 {
                let rid = l.inputs[entry + ":" + nm]
                if slot == 0 { step.inRef0 = rid } else { step.inRef1 = rid }
            }
            out.append(step)
        }
        return out
    }

    /// Layer inputs (in0 / in1) of effects: renders each referenced layer's own content into a dedicated
    /// target, then restores layerA (the layer being processed). Same picking rule as GL (slot < 2).
    private func bindEffectInputs(_ steps: inout [MetalEffects.Step], time: Float) {
        guard let cbuf = cb, let a = layerA, let st = sceneT else { return }
        if fxSnapT == nil { fxSnapT = MetalTarget(core, width, height) }
        if inT0 == nil { inT0 = MetalTarget(core, width, height) }
        if inT1 == nil { inT1 = MetalTarget(core, width, height) }
        guard let snap = fxSnapT else { return }
        var made: [Int: MTLTexture] = [:]
        var used = 0
        var snapped = false
        func inputTexture(_ rid: Int?) -> MTLTexture? {
            guard let rid = rid, let ref = Editor.scene.layers.first(where: { $0.id == rid }), ref.isRenderable() else { return nil }
            if let t = made[rid] { return t }
            guard used < 2, let dst = (used == 0 ? inT0 : inT1) else { return nil }
            if !snapped { _ = passes.blit(cbuf, src: a.tex, to: snap); snapped = true }
            renderLayerContent(ref, time: time, target: st)
            _ = passes.blit(cbuf, src: a.tex, to: dst)
            models.depthDirty = true
            used += 1
            made[rid] = dst.tex
            return dst.tex
        }
        for i in steps.indices {
            steps[i].in0 = inputTexture(steps[i].inRef0)
            steps[i].in1 = inputTexture(steps[i].inRef1)
        }
        if snapped { _ = passes.blit(cbuf, src: snap.tex, to: a) }
    }

    /// Runs the layer's effect chain on layerA; the result ends up in layerA.
    private func applyEffects(_ l: Layer, time: Float) {
        guard !l.fx.isEmpty, let buf = cb, let a = layerA, let b = layerB else { return }
        var steps = effectSteps(l, time: time)
        guard !steps.isEmpty else { return }
        if steps.contains(where: { $0.inRef0 != nil || $0.inRef1 != nil }) { bindEffectInputs(&steps, time: time) }
        var rect: (c: SIMD2<Float>, x: SIMD2<Float>, y: SIMD2<Float>)? = nil
        if l.type != .GROUP && l.type != .ADJUST {          // the layer's rectangle in world units
            let m = Xf.matrix(l, time)
            let (qw, qh) = Xf.quadSize(l)
            rect = (SIMD2<Float>(m[4], m[5]), SIMD2<Float>(m[0] * qw, m[1] * qw), SIMD2<Float>(m[2] * qh, m[3] * qh))
        }
        var read = a, write = b
        var sawBlurFx = false
        for st in steps {
            let id = st.def.id
            if id == "blur" || id == "radialblur" || id == "blurmo" { sawBlurFx = true }
            if id == "deepglow" {
                var gp = MetalGlow.Params()
                func val(_ key: String, _ def: Float) -> Float {
                    if let i = st.def.props.firstIndex(where: { $0.key == key }), i < st.props.count { return st.props[i] }
                    return def
                }
                gp.radius = val("radius", 0.12); gp.intensity = val("intensity", 1)
                gp.threshold = val("threshold", 0.3); gp.knee = val("knee", 0.5)
                gp.falloff = val("falloff", 0.5); gp.tintAmt = val("tintAmt", 0)
                gp.tintHue = val("tintHue", 0.08); gp.chroma = val("chroma", 0); gp.glowOnly = val("glowOnly", 0)
                gp.blurComp = sawBlurFx ? max(glowBlurComp, 2.4) : glowBlurComp
                if glow?.apply(buf, p: gp, src: read.tex, out: write) == true { swap(&read, &write) }
                continue
            }
            if fx.apply(buf, step: st, src: read.tex, out: write, time: time, rect: rect) { swap(&read, &write) }
        }
        if read !== a { swap(&a.tex, &b.tex) }
    }
}
