// TerrainPanel.swift — Scene 3D "+" > Terrain: a heightfield mesh (Basic hills or Procedural noise) with an optional
// Poly Haven PBR texture. Built as a .glb and imported as an ordinary model layer, like Extras.

import UIKit
import simd

// MARK: - heightfield + glb

enum TerrainGLB {
    struct Opt {
        var procedural = false, res = 128, height: Float = 0.25, seed = 1, feature: Float = 3, rough: Float = 0.5
        var ridged: Float = 0, edge: Float = 0.3, tiles = 4
    }
    private static func hash(_ x: Int, _ y: Int, _ s: Int) -> Float {
        var h = UInt32(truncatingIfNeeded: x &* 374761393 &+ y &* 668265263 &+ s &* 1274126177)
        h = (h ^ (h >> 13)) &* 1274126177
        return Float((h ^ (h >> 16)) & 0xFFFF) / 65535
    }
    private static func vn(_ x: Float, _ y: Float, _ s: Int) -> Float {
        let ix = Int(floor(x)), iy = Int(floor(y)), fx = x - floor(x), fy = y - floor(y)
        let sx = fx * fx * (3 - 2 * fx), sy = fy * fy * (3 - 2 * fy)
        let a = hash(ix, iy, s), b = hash(ix + 1, iy, s), c = hash(ix, iy + 1, s), d = hash(ix + 1, iy + 1, s)
        return (a + (b - a) * sx) + ((c + (d - c) * sx) - (a + (b - a) * sx)) * sy
    }
    private static func sstep(_ a: Float, _ b: Float, _ x: Float) -> Float { let t = max(0, min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t) }
    private static func lerp3(_ a: simd_float3, _ b: simd_float3, _ t: Float) -> simd_float3 { a + (b - a) * t }
    /// 0...1 height at (a, b) in 0...1.
    static func h(_ a: Float, _ b: Float, _ o: Opt) -> Float {
        var v: Float
        if !o.procedural {      // Basic: soft rolling hills
            v = 0.5 + 0.28 * sinf(a * 6.2 + 0.7) * cosf(b * 5.1) + 0.14 * sinf(a * 13 + b * 9) * cosf(b * 11 - a * 4)
        } else {
            var amp: Float = 1, f = o.feature, sum: Float = 0, norm: Float = 0
            for i in 0..<7 {
                var n = vn(a * f, b * f, o.seed &+ i * 31)
                let r = 1 - abs(2 * n - 1)      // ridge
                n = n * (1 - o.ridged) + r * r * o.ridged
                sum += n * amp; norm += amp
                amp *= 0.35 + 0.4 * o.rough; f *= 2.03
            }
            v = sum / norm
            v = max(0, min(1, (v - 0.5) * 1.8 + 0.5))
        }
        if o.edge > 0 {      // fade to the base level toward the borders
            let e = min(min(a, 1 - a), min(b, 1 - b)) * 2
            let t = max(0, min(1, e / max(o.edge, 0.01)))
            v *= t * t * (3 - 2 * t)
        }
        return v
    }

    static func build(_ o: Opt, _ p: ExtrasGLB.Packed?) -> Data {
        let res = o.res, R = res + 1
        let amp = o.height
        var hs = [Float](repeating: 0, count: R * R)
        for j in 0..<R { for i in 0..<R { hs[i + j * R] = h(Float(i) / Float(res), Float(j) / Float(res), o) * amp } }
        var pos: [Float] = [], nor: [Float] = [], uv: [Float] = [], col: [Float] = [], idx: [UInt32] = []
        let step = 1 / Float(res)
        for j in 0..<R { for i in 0..<R {
            let a = Float(i) * step, b = Float(j) * step, y = hs[i + j * R]
            pos += [a - 0.5, y, b - 0.5]
            let dx = hs[min(i + 1, res) + j * R] - hs[max(i - 1, 0) + j * R], dz = hs[i + min(j + 1, res) * R] - hs[i + max(j - 1, 0) * R]
            let sx = Float(min(i + 1, res) - max(i - 1, 0)) * step, sz = Float(min(j + 1, res) - max(j - 1, 0)) * step
            let n = simd_normalize(simd_float3(-dx / sx, 1, -dz / sz))
            nor += [n.x, n.y, n.z]
            uv += [a * Float(o.tiles), b * Float(o.tiles)]
            if p?.base != nil { col += [1, 1, 1, 1] } else {      // no texture: sand → grass → rock → snow by height and slope
                let t = amp > 0 ? y / amp : 0.5, slope = 1 - n.y
                var c = lerp3(simd_float3(0.76, 0.68, 0.46), simd_float3(0.28, 0.5, 0.2), sstep(0.18, 0.32, t))
                c = lerp3(c, simd_float3(0.45, 0.42, 0.4), max(sstep(0.55, 0.75, t), sstep(0.12, 0.35, slope)))
                c = lerp3(c, simd_float3(0.95), sstep(0.82, 0.95, t) * (1 - sstep(0.2, 0.5, slope)))
                col += [c.x, c.y, c.z, 1]
            }
        } }
        for j in 0..<res { for i in 0..<res {
            let a = UInt32(i + j * R)
            idx += [a, a + 1, a + UInt32(R), a + 1, a + UInt32(R) + 1, a + UInt32(R)]
        } }
        var bin = Data(); var views: [[String: Any]] = []
        func add(_ d: Data, _ t: Int?) -> Int {
            while bin.count % 4 != 0 { bin.append(0) }
            var v: [String: Any] = ["buffer": 0, "byteOffset": bin.count, "byteLength": d.count]
            if let t = t { v["target"] = t }
            bin.append(d); views.append(v); return views.count - 1
        }
        func bytes<T>(_ a: [T]) -> Data { a.withUnsafeBytes { Data($0) } }
        let vp = add(bytes(pos), 34962), vn_ = add(bytes(nor), 34962), vu = add(bytes(uv), 34962), vi = add(bytes(idx), 34963), vc = add(bytes(col), 34962)
        let nv = pos.count / 3
        var mn: [Float] = [1e9, 1e9, 1e9], mx: [Float] = [-1e9, -1e9, -1e9]
        for i in 0..<nv { for k in 0..<3 { mn[k] = min(mn[k], pos[i * 3 + k]); mx[k] = max(mx[k], pos[i * 3 + k]) } }
        let acc: [[String: Any]] = [
            ["bufferView": vp, "componentType": 5126, "count": nv, "type": "VEC3", "min": mn, "max": mx],
            ["bufferView": vn_, "componentType": 5126, "count": nv, "type": "VEC3"],
            ["bufferView": vu, "componentType": 5126, "count": nv, "type": "VEC2"],
            ["bufferView": vi, "componentType": 5125, "count": idx.count, "type": "SCALAR"],
            ["bufferView": vc, "componentType": 5126, "count": nv, "type": "VEC4"]]
        var images: [[String: Any]] = [], textures: [[String: Any]] = []
        func tex(_ d: Data?, _ mime: String) -> Int? {
            guard let d = d else { return nil }
            images.append(["bufferView": add(d, nil), "mimeType": mime]); textures.append(["source": images.count - 1, "sampler": 0])
            return textures.count - 1
        }
        var pbr: [String: Any] = ["metallicFactor": 1.0, "roughnessFactor": 1.0]
        var mat: [String: Any] = ["doubleSided": true]
        if let b = tex(p?.base, "image/jpeg") { pbr["baseColorTexture"] = ["index": b] } else { pbr["baseColorFactor"] = [1, 1, 1, 1] }
        if let m = tex(p?.mr, "image/png") { pbr["metallicRoughnessTexture"] = ["index": m] } else { pbr["metallicFactor"] = 0.0; pbr["roughnessFactor"] = 0.9 }
        if let oc = tex(p?.occ, "image/png") { mat["occlusionTexture"] = ["index": oc] }
        mat["pbrMetallicRoughness"] = pbr
        let json: [String: Any] = [
            "asset": ["version": "2.0", "generator": "SaikiMotion Terrain"], "scene": 0, "scenes": [["nodes": [0]]], "nodes": [["mesh": 0]],
            "meshes": [["primitives": [["attributes": ["POSITION": 0, "NORMAL": 1, "TEXCOORD_0": 2, "COLOR_0": 4], "indices": 3, "material": 0]]]],
            "materials": [mat], "accessors": acc, "bufferViews": views, "buffers": [["byteLength": bin.count]],
            "samplers": [["magFilter": 9729, "minFilter": 9987, "wrapS": 10497, "wrapT": 10497]], "images": images, "textures": textures]
        var js = (try? JSONSerialization.data(withJSONObject: json)) ?? Data()
        while js.count % 4 != 0 { js.append(0x20) }
        while bin.count % 4 != 0 { bin.append(0) }
        var out = Data()
        func u32(_ v: UInt32) { var x = v.littleEndian; withUnsafeBytes(of: &x) { out.append(contentsOf: $0) } }
        u32(0x46546C67); u32(2); u32(UInt32(12 + 8 + js.count + 8 + bin.count))
        u32(UInt32(js.count)); u32(0x4E4F534A); out.append(js)
        u32(UInt32(bin.count)); u32(0x004E4942); out.append(bin)
        return out
    }
}

// MARK: - panel

final class TerrainPanel: UIView, UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate {
    private weak var host: EditorViewController?
    private let accent = UIColor(red: 1, green: 0.55, blue: 0.08, alpha: 1)
    private let modeSeg = UISegmentedControl(items: ["Basic", "Procedural"])
    private let resSeg = UISegmentedControl(items: ["Low", "Medium", "High"])
    private let texRes = UISegmentedControl(items: ["1k (fast)", "2k"])
    private let search = UISearchBar(), table = UITableView(), status = UILabel(), addBtn = UIButton(type: .system)
    private var sHeight = UISlider(), sSeed = UISlider(), sFeature = UISlider(), sRough = UISlider(), sRidge = UISlider(), sEdge = UISlider(), sTiles = UISlider()
    private var procRows: [UIView] = []
    private var all: [(id: String, name: String)] = [], shown: [(id: String, name: String)] = []
    private var pick = -1, busy = false

    static func present(in host: EditorViewController, over view: UIView) {
        if view.subviews.contains(where: { $0 is TerrainPanel }) { return }
        let v = TerrainPanel(host: host)
        v.translatesAutoresizingMaskIntoConstraints = false; view.addSubview(v)
        NSLayoutConstraint.activate([v.leadingAnchor.constraint(equalTo: view.leadingAnchor), v.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                                     v.topAnchor.constraint(equalTo: view.topAnchor), v.bottomAnchor.constraint(equalTo: view.bottomAnchor)])
    }

    init(host: EditorViewController) {
        self.host = host
        super.init(frame: .zero)
        backgroundColor = UIColor(white: 0, alpha: 0.55)
        build()
        PolyHaven.list { [weak self] l in DispatchQueue.main.async {
            self?.all = l; self?.filter("")
            if l.isEmpty { self?.status.text = "Could not reach Poly Haven. Check your connection." } } }
    }
    required init?(coder: NSCoder) { fatalError() }

    private func build() {
        let card = UIView(); card.backgroundColor = UIColor(white: 0.09, alpha: 1); card.layer.cornerRadius = 22
        card.translatesAutoresizingMaskIntoConstraints = false; addSubview(card)
        let title = UILabel(); title.text = "Terrain"; title.textColor = .white; title.font = .systemFont(ofSize: 22, weight: .bold)
        let x = UIButton(type: .system); x.setImage(UIImage(systemName: "xmark"), for: .normal); x.tintColor = .white
        x.addTarget(self, action: #selector(close), for: .touchUpInside)
        let head = UIStackView(arrangedSubviews: [title, UIView(), x]); head.alignment = .center
        for s in [modeSeg, resSeg, texRes] { s.selectedSegmentTintColor = accent
            s.setTitleTextAttributes([.foregroundColor: UIColor.white], for: .normal); s.setTitleTextAttributes([.foregroundColor: UIColor.black], for: .selected) }
        modeSeg.selectedSegmentIndex = 0; resSeg.selectedSegmentIndex = 1; texRes.selectedSegmentIndex = 0
        modeSeg.addTarget(self, action: #selector(modeChanged), for: .valueChanged)
        func cfg(_ s: UISlider, _ lo: Float, _ hi: Float, _ v: Float) { s.minimumValue = lo; s.maximumValue = hi; s.value = v; s.tintColor = accent }
        cfg(sHeight, 0, 1, 0.35); cfg(sSeed, 1, 99, 7); cfg(sFeature, 1, 10, 3); cfg(sRough, 0, 1, 0.5); cfg(sRidge, 0, 1, 0); cfg(sEdge, 0, 1, 0.3); cfg(sTiles, 1, 16, 4)
        func row(_ t: String, _ v: UIView) -> UIStackView {
            let l = UILabel(); l.text = t; l.textColor = UIColor(white: 0.7, alpha: 1); l.font = .systemFont(ofSize: 13)
            l.widthAnchor.constraint(equalToConstant: 92).isActive = true
            let s = UIStackView(arrangedSubviews: [l, v]); s.spacing = 10; s.alignment = .center; return s
        }
        procRows = [row("Seed", sSeed), row("Feature size", sFeature), row("Roughness", sRough), row("Ridges", sRidge)]
        let texTitle = UILabel(); texTitle.text = "Texture"; texTitle.textColor = .white; texTitle.font = .systemFont(ofSize: 15, weight: .semibold)
        search.placeholder = "Search Poly Haven textures (rock, sand, grass…)"; search.searchBarStyle = .minimal; search.delegate = self
        search.searchTextField.textColor = .white; search.autocapitalizationType = .none
        table.dataSource = self; table.delegate = self; table.backgroundColor = .clear; table.rowHeight = 56
        table.separatorColor = UIColor(white: 1, alpha: 0.08)
        table.heightAnchor.constraint(equalToConstant: 220).isActive = true
        status.textColor = UIColor(white: 0.7, alpha: 1); status.font = .systemFont(ofSize: 12); status.numberOfLines = 2
        addBtn.setTitle("Add terrain", for: .normal); addBtn.setTitleColor(.black, for: .normal)
        addBtn.titleLabel?.font = .systemFont(ofSize: 17, weight: .bold); addBtn.backgroundColor = accent; addBtn.layer.cornerRadius = 14
        addBtn.addTarget(self, action: #selector(addTap), for: .touchUpInside)
        addBtn.heightAnchor.constraint(equalToConstant: 48).isActive = true
        let body = UIStackView(arrangedSubviews: [modeSeg, row("Height", sHeight)] + procRows + [row("Edge fade", sEdge), row("Detail", resSeg), texTitle, search, table, row("Tex tiles", sTiles), row("Tex quality", texRes), status])
        body.axis = .vertical; body.spacing = 10; body.translatesAutoresizingMaskIntoConstraints = false
        let scroll = UIScrollView(); scroll.translatesAutoresizingMaskIntoConstraints = false; scroll.keyboardDismissMode = .onDrag
        scroll.addSubview(body)
        let stack = UIStackView(arrangedSubviews: [head, scroll, addBtn]); stack.axis = .vertical; stack.spacing = 10
        stack.translatesAutoresizingMaskIntoConstraints = false; card.addSubview(stack)
        NSLayoutConstraint.activate([
            card.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 12), card.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -12),
            card.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor, constant: 40), card.bottomAnchor.constraint(equalTo: safeAreaLayoutGuide.bottomAnchor, constant: -12),
            stack.leadingAnchor.constraint(equalTo: card.leadingAnchor, constant: 16), stack.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -16),
            stack.topAnchor.constraint(equalTo: card.topAnchor, constant: 16), stack.bottomAnchor.constraint(equalTo: card.bottomAnchor, constant: -16),
            body.leadingAnchor.constraint(equalTo: scroll.contentLayoutGuide.leadingAnchor), body.trailingAnchor.constraint(equalTo: scroll.contentLayoutGuide.trailingAnchor),
            body.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor), body.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor),
            body.widthAnchor.constraint(equalTo: scroll.frameLayoutGuide.widthAnchor)])
        modeChanged()
    }

    @objc private func close() { removeFromSuperview() }
    @objc private func modeChanged() { procRows.forEach { $0.isHidden = modeSeg.selectedSegmentIndex == 0 } }

    private func filter(_ q: String) {
        let k = q.trimmingCharacters(in: .whitespaces).lowercased()
        shown = k.isEmpty ? all : all.filter { $0.name.lowercased().contains(k) || $0.id.contains(k) }
        pick = -1; table.reloadData()
    }
    func searchBar(_ s: UISearchBar, textDidChange t: String) { filter(t) }
    func searchBarSearchButtonClicked(_ s: UISearchBar) { s.resignFirstResponder() }
    func tableView(_ t: UITableView, numberOfRowsInSection s: Int) -> Int { shown.count + 1 }
    func tableView(_ t: UITableView, cellForRowAt ip: IndexPath) -> UITableViewCell {
        let c = t.dequeueReusableCell(withIdentifier: "c") ?? UITableViewCell(style: .default, reuseIdentifier: "c")
        c.backgroundColor = .clear; c.textLabel?.textColor = .white; c.tintColor = accent
        let i = ip.row - 1
        c.textLabel?.text = i < 0 ? "Procedural colours (sand / grass / rock / snow)" : shown[i].name
        c.accessoryType = i == pick ? .checkmark : .none; c.imageView?.image = nil
        if i >= 0 {
            let id = shown[i].id
            c.imageView?.image = UIImage(systemName: "photo")
            PolyHaven.thumb(id) { [weak c] img in
                guard let img = img, let c = c, c.textLabel?.text == self.shown.first(where: { $0.id == id })?.name else { return }
                c.imageView?.image = img; c.setNeedsLayout()
            }
        }
        return c
    }
    func tableView(_ t: UITableView, didSelectRowAt ip: IndexPath) { pick = ip.row - 1; t.reloadData(); search.resignFirstResponder() }

    @objc private func addTap() {
        guard !busy, let host = host else { return }
        busy = true; addBtn.alpha = 0.5
        var o = TerrainGLB.Opt()
        o.procedural = modeSeg.selectedSegmentIndex == 1
        o.res = [64, 128, 224][resSeg.selectedSegmentIndex]
        o.height = sHeight.value * 0.5; o.seed = Int(sSeed.value); o.feature = sFeature.value; o.rough = sRough.value
        o.ridged = sRidge.value; o.edge = sEdge.value; o.tiles = Int(sTiles.value.rounded())
        let tex = pick >= 0 ? shown[pick] : nil
        let res = texRes.selectedSegmentIndex == 0 ? "1k" : "2k"
        let name = o.procedural ? "Procedural terrain" : "Basic terrain"
        status.text = tex == nil ? "Building…" : "Downloading \(tex!.name) maps…"
        let finish: (ExtrasGLB.Packed?) -> Void = { [weak self] p in
            let glb = TerrainGLB.build(o, p)
            DispatchQueue.main.async {
                guard let self = self else { return }
                self.busy = false; self.addBtn.alpha = 1
                guard let path = ProjectIO.writeDataIntoSandbox(glb, name: "terrain_\(nowMs()).glb") else { self.status.text = "Could not build the terrain."; return }
                host.addMedia(path, .MODEL)
                if let l = Editor.scene.layers.last(where: { $0.imagePath == path }) {
                    l.name = tex.map { "\(name) · \($0.name)" } ?? name
                    if let p = p { let n = p.hasNormal || p.height != nil; l.xset("pbrNorm", n ? 1.3 : 0); l.xset("pbrExtra", 1); l.xset("pbrPom", 0) }
                    host.render(); host.refreshPanel()
                }
                self.close()
            }
        }
        DispatchQueue.global(qos: .userInitiated).async {
            guard let t = tex else { finish(nil); return }
            PolyHaven.maps(t.id, res: res) { m in
                guard let m = m else { DispatchQueue.main.async { self.busy = false; self.addBtn.alpha = 1; self.status.text = "Download failed. Try again." }; return }
                finish(ExtrasGLB.pack(m, size: res == "1k" ? 1024 : 2048))
            }
        }
    }
}
