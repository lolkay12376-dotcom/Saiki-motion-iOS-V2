// TerrainPanel.swift — Scene 3D "+" > Terrain. Tabs: Shape (output, presets) · Nodes (a stack of generator/modifier nodes that
// builds the heightfield) · Material (optional Poly Haven PBR). Built as a .glb and imported like Extras.

import UIKit
import simd

// MARK: - node graph (heightfield, 0...1)

enum TKind: Int, CaseIterable {
    case noise, ridged, hills, craters, warp, terrace, curve, level, smooth, erode, island
    var title: String { ["Noise", "Ridged noise", "Rolling hills", "Craters", "Domain warp", "Terrace", "Curve", "Level / plateau", "Smooth", "Erosion", "Island mask"][rawValue] }
    var icon: String { ["waveform", "mountain.2", "water.waves", "circle.dashed", "tornado", "chart.bar.fill", "point.topleft.down.curvedto.point.bottomright.up", "arrow.up.and.down.square", "drop", "wind", "circle.hexagongrid"][rawValue] }
    var isGen: Bool { rawValue <= 3 }
    /// name, lo, hi, default, choice options
    var params: [(String, Float, Float, Float, [String]?)] {
        let mix: (String, Float, Float, Float, [String]?) = ("Mix", 0, 3, 0, ["Add", "Mul", "Max", "Replace"])
        switch self {
        case .noise, .ridged: return [("Scale", 1, 16, 3, nil), ("Detail", 1, 8, 5, nil), ("Roughness", 0, 1, 0.5, nil), ("Strength", 0, 1, 1, nil), ("Seed", 1, 99, 1, nil), mix]
        case .hills: return [("Scale", 1, 10, 3, nil), ("Strength", 0, 1, 1, nil), mix]
        case .craters: return [("Count", 1, 40, 10, nil), ("Size", 0.03, 0.3, 0.1, nil), ("Depth", 0, 1, 0.5, nil), ("Seed", 1, 99, 1, nil)]
        case .warp: return [("Amount", 0, 0.3, 0.08, nil), ("Scale", 1, 10, 3, nil), ("Seed", 1, 99, 1, nil)]
        case .terrace: return [("Steps", 2, 20, 6, nil), ("Sharpness", 0, 1, 0.6, nil)]
        case .curve: return [("Power", 0.3, 4, 1.5, nil)]
        case .level: return [("Low", 0, 1, 0, nil), ("High", 0, 1, 1, nil)]
        case .smooth: return [("Iterations", 1, 12, 2, nil)]
        case .erode: return [("Iterations", 1, 40, 12, nil), ("Talus", 0.002, 0.06, 0.015, nil), ("Amount", 0, 1, 0.5, nil)]
        case .island: return [("Radius", 0.2, 1, 0.8, nil), ("Falloff", 0.05, 1, 0.4, nil)]
        }
    }
}

struct TNode {
    var kind: TKind, p: [Float], on = true
    init(_ k: TKind, _ over: [Int: Float] = [:]) {
        kind = k; p = k.params.map { $0.3 }
        for (i, v) in over where i < p.count { p[i] = v }
    }
}

enum TerrainGraph {
    private static func hash(_ x: Int, _ y: Int, _ s: Int) -> Float {
        var h = UInt32(truncatingIfNeeded: x &* 374761393 &+ y &* 668265263 &+ s &* 1274126177)
        h = (h ^ (h >> 13)) &* 1274126177
        return Float((h ^ (h >> 16)) & 0xFFFF) / 65535
    }
    private static func vn(_ x: Float, _ y: Float, _ s: Int) -> Float {
        let ix = Int(floor(x)), iy = Int(floor(y)), fx = x - floor(x), fy = y - floor(y)
        let sx = fx * fx * (3 - 2 * fx), sy = fy * fy * (3 - 2 * fy)
        let a = hash(ix, iy, s), b = hash(ix + 1, iy, s), c = hash(ix, iy + 1, s), d = hash(ix + 1, iy + 1, s)
        return (a + (b - a) * sx) + ((c + (d - c) * sx) - (a + (b - a) * sx)) * sy
    }
    private static func fbm(_ a: Float, _ b: Float, _ scale: Float, _ oct: Int, _ rough: Float, _ seed: Int, ridged: Bool) -> Float {
        var amp: Float = 1, f = scale, sum: Float = 0, norm: Float = 0
        for i in 0..<oct {
            var n = vn(a * f, b * f, seed &+ i * 31)
            if ridged { let r = 1 - abs(2 * n - 1); n = r * r }
            sum += n * amp; norm += amp
            amp *= 0.3 + 0.45 * rough; f *= 2.03
        }
        return sum / norm
    }
    private static func sstep(_ a: Float, _ b: Float, _ x: Float) -> Float { let t = max(0, min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t) }
    private static func lerp3(_ a: simd_float3, _ b: simd_float3, _ t: Float) -> simd_float3 { a + (b - a) * t }
    private static func norm(_ f: inout [Float]) {
        guard let lo = f.min(), let hi = f.max(), hi - lo > 1e-6 else { return }
        let k = 1 / (hi - lo); for i in 0..<f.count { f[i] = (f[i] - lo) * k }
    }
    private static func mix(_ f: Float, _ n: Float, _ s: Float, _ mode: Int) -> Float {
        switch mode {
        case 1: return f * (1 + (n - 1) * s)
        case 2: return max(f, n * s)
        case 3: return f + (n - f) * s
        default: return f + n * s
        }
    }

    /// Evaluates the node stack on a (res+1)² grid; result 0...1 with edge fade and sea floor applied.
    static func eval(_ nodes: [TNode], res: Int, edge: Float, sea: Float) -> [Float] {
        let R = res + 1, inv = 1 / Float(res)
        var f = [Float](repeating: 0, count: R * R)
        for nd in nodes where nd.on {
            let p = nd.p
            switch nd.kind {
            case .noise, .ridged:
                let mode = Int(p[5]), sd = Int(p[4]), ob = Int(p[1]), rg = nd.kind == .ridged
                for j in 0..<R { for i in 0..<R {
                    let n = fbm(Float(i) * inv, Float(j) * inv, p[0], ob, p[2], sd, ridged: rg)
                    f[i + j * R] = mix(f[i + j * R], n, p[3], mode)
                } }
            case .hills:
                for j in 0..<R { for i in 0..<R {
                    let a = Float(i) * inv, b = Float(j) * inv, k = p[0] / 3
                    let n = 0.5 + 0.28 * sinf(a * 6.2 * k + 0.7) * cosf(b * 5.1 * k) + 0.14 * sinf(a * 13 * k + b * 9 * k) * cosf(b * 11 * k - a * 4 * k)
                    f[i + j * R] = mix(f[i + j * R], n, p[1], Int(p[2]))
                } }
            case .craters:
                norm(&f)
                for c in 0..<Int(p[0]) {
                    let cx = hash(c, 1, Int(p[3])), cy = hash(c, 2, Int(p[3])), r = p[1] * (0.5 + hash(c, 3, Int(p[3])))
                    let j0 = max(0, Int((cy - r * 1.4) * Float(res))), j1 = min(res, Int((cy + r * 1.4) * Float(res)) + 1)
                    let i0 = max(0, Int((cx - r * 1.4) * Float(res))), i1 = min(res, Int((cx + r * 1.4) * Float(res)) + 1)
                    if j0 > j1 || i0 > i1 { continue }
                    for j in j0...j1 { for i in i0...i1 {
                        let dx = Float(i) * inv - cx, dy = Float(j) * inv - cy, d = sqrtf(dx * dx + dy * dy) / r
                        let bowl: Float = d < 1 ? -(1 - d * d) : 0
                        let rim = 0.35 * expf(-(d - 1) * (d - 1) * 18)
                        f[i + j * R] += (bowl + rim) * p[2] * 0.4
                    } }
                }
            case .warp:
                let src = f, sd = Int(p[2])
                for j in 0..<R { for i in 0..<R {
                    let a = Float(i) * inv, b = Float(j) * inv
                    let x = max(0, min(1, a + (vn(a * p[1], b * p[1], sd) - 0.5) * 2 * p[0])) * Float(res)
                    let y = max(0, min(1, b + (vn(a * p[1], b * p[1], sd &+ 17) - 0.5) * 2 * p[0])) * Float(res)
                    let x0 = min(Int(x), res - 1), y0 = min(Int(y), res - 1), fx = x - Float(x0), fy = y - Float(y0)
                    let v0 = src[x0 + y0 * R] * (1 - fx) + src[x0 + 1 + y0 * R] * fx, v1 = src[x0 + (y0 + 1) * R] * (1 - fx) + src[x0 + 1 + (y0 + 1) * R] * fx
                    f[i + j * R] = v0 * (1 - fy) + v1 * fy
                } }
            case .terrace:
                norm(&f)
                let n = p[0]
                for k in 0..<f.count {
                    let s = f[k] * n, fl = floor(s), fr = s - fl
                    let sharp = fr < 0.5 ? 0.5 * powf(fr * 2, 1 + p[1] * 5) : 1 - 0.5 * powf((1 - fr) * 2, 1 + p[1] * 5)
                    f[k] = (fl + sharp) / n
                }
            case .curve:
                norm(&f); for k in 0..<f.count { f[k] = powf(max(f[k], 0), p[0]) }
            case .level:
                norm(&f)
                let lo = min(p[0], p[1] - 0.01), hi = max(p[1], lo + 0.01)
                for k in 0..<f.count { f[k] = max(0, min(1, (f[k] - lo) / (hi - lo))) }
            case .smooth:
                for _ in 0..<Int(p[0]) {
                    let s = f
                    for j in 1..<res { for i in 1..<res {
                        var t: Float = 0
                        for dj in -1...1 { for di in -1...1 { t += s[(i + di) + (j + dj) * R] } }
                        f[i + j * R] = t / 9
                    } }
                }
            case .erode:
                norm(&f)
                let tal = p[1], amt = p[2] * 0.25
                for _ in 0..<Int(p[0]) {
                    var dl = [Float](repeating: 0, count: R * R)
                    for j in 0..<R { for i in 0..<R {
                        let k = i + j * R
                        for (di, dj) in [(1, 0), (0, 1), (-1, 0), (0, -1)] {
                            let ni = i + di, nj = j + dj
                            if ni < 0 || nj < 0 || ni > res || nj > res { continue }
                            let d = f[k] - f[ni + nj * R]
                            if d > tal { let m = amt * (d - tal); dl[k] -= m; dl[ni + nj * R] += m }
                        }
                    } }
                    for k in 0..<f.count { f[k] += dl[k] }
                }
            case .island:
                norm(&f)
                for j in 0..<R { for i in 0..<R {
                    let dx = Float(i) * inv - 0.5, dy = Float(j) * inv - 0.5, d = sqrtf(dx * dx + dy * dy) * 2
                    f[i + j * R] *= 1 - sstep(p[0] - p[1], p[0], d)
                } }
            }
        }
        norm(&f)
        for j in 0..<R { for i in 0..<R {
            var v = f[i + j * R]
            if edge > 0 {
                let e = min(min(Float(i) * inv, 1 - Float(i) * inv), min(Float(j) * inv, 1 - Float(j) * inv)) * 2
                v *= sstep(0, max(edge, 0.01), e)
            }
            f[i + j * R] = max(v, sea)
        } }
        return f
    }

    /// Procedural colour: shore sand → grass → rock → snow by height (0...1), slope and sea level.
    static func colour(_ t: Float, _ slope: Float, _ sea: Float) -> simd_float3 {
        let r = max(1 - sea, 0.05), h = (t - sea) / r      // height above the shore, 0...1
        var c = lerp3(simd_float3(0.76, 0.68, 0.46), simd_float3(0.28, 0.5, 0.2), sstep(0.04, 0.2, h))
        c = lerp3(c, simd_float3(0.45, 0.42, 0.4), max(sstep(0.5, 0.75, h), sstep(0.12, 0.35, slope)))
        return lerp3(c, simd_float3(0.95), sstep(0.8, 0.95, h) * (1 - sstep(0.2, 0.5, slope)))
    }

    /// Small shaded preview of the result.
    static func preview(_ nodes: [TNode], edge: Float, sea: Float, size: Int = 96) -> UIImage? {
        let f = eval(nodes, res: size, edge: edge, sea: sea), R = size + 1
        var px = [UInt8](repeating: 255, count: size * size * 4)
        let L = simd_normalize(simd_float3(-0.5, 0.7, -0.5))
        for j in 0..<size { for i in 0..<size {
            let hx = f[min(i + 1, size) + j * R] - f[max(i - 1, 0) + j * R], hz = f[i + min(j + 1, size) * R] - f[i + max(j - 1, 0) * R]
            let n = simd_normalize(simd_float3(-hx * 6, 1, -hz * 6))
            let sh = 0.35 + 0.75 * max(0, simd_dot(n, L)), t = f[i + j * R]
            let c = t <= sea + 0.001 ? simd_float3(0.16, 0.36, 0.55) : colour(t, 1 - n.y, sea)
            let o = (i + j * size) * 4
            px[o] = UInt8(max(0, min(255, c.x * sh * 255))); px[o + 1] = UInt8(max(0, min(255, c.y * sh * 255))); px[o + 2] = UInt8(max(0, min(255, c.z * sh * 255)))
        } }
        guard let ctx = CGContext(data: &px, width: size, height: size, bitsPerComponent: 8, bytesPerRow: size * 4, space: CGColorSpaceCreateDeviceRGB(),
                                  bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue), let img = ctx.makeImage() else { return nil }
        return UIImage(cgImage: img)
    }

    static let presets: [(String, [TNode], Float, Float)] = [      // name, nodes, edge fade, sea
        ("Rolling hills", [TNode(.hills, [2: 3]), TNode(.noise, [0: 6, 3: 0.15, 5: 0])], 0.3, 0),
        ("Mountains", [TNode(.ridged, [0: 3, 2: 0.55, 5: 3]), TNode(.noise, [0: 8, 3: 0.2, 5: 0]), TNode(.erode), TNode(.curve, [0: 1.4])], 0.25, 0),
        ("Islands", [TNode(.noise, [0: 3, 5: 3]), TNode(.warp), TNode(.island, [0: 0.85, 1: 0.5]), TNode(.smooth)], 0.15, 0.22),
        ("Mesa / canyon", [TNode(.noise, [0: 2.5, 5: 3]), TNode(.warp, [0: 0.1]), TNode(.level, [0: 0.15, 1: 0.7]), TNode(.terrace, [0: 5, 1: 0.5]), TNode(.erode, [0: 6])], 0.25, 0),
        ("Cratered moon", [TNode(.noise, [0: 4, 3: 0.4, 5: 3]), TNode(.craters, [0: 25, 1: 0.08, 2: 0.7])], 0.3, 0)]
}

enum TerrainGLB {
    struct Opt {
        var nodes: [TNode] = [], res = 128, height: Float = 0.25, edge: Float = 0.3, sea: Float = 0, tiles = 4
    }

    static func build(_ o: Opt, _ p: ExtrasGLB.Packed?) -> Data {
        let res = o.res, R = res + 1
        let amp = o.height
        var hs = [Float](repeating: 0, count: R * R)
        let field = TerrainGraph.eval(o.nodes, res: res, edge: o.edge, sea: o.sea)
        for k in 0..<(R * R) { hs[k] = field[k] * amp }
        var pos: [Float] = [], nor: [Float] = [], uv: [Float] = [], col: [Float] = [], idx: [UInt32] = []
        let step = 1 / Float(res)
        for j in 0..<R { for i in 0..<R {
            let a = Float(i) * step, b = Float(j) * step, y = hs[i + j * R]
            pos += [a - 0.5, y, b - 0.5]
            let dx = hs[min(i + 1, res) + j * R] - hs[max(i - 1, 0) + j * R], dz = hs[i + min(j + 1, res) * R] - hs[i + max(j - 1, 0) * R]
            let sx = Float(min(i + 1, res) - max(i - 1, 0)) * step, sz = Float(min(j + 1, res) - max(j - 1, 0)) * step
            let n = simd_normalize(simd_float3(-dx / sx, 1, -dz / sz))
            nor += [n.x, n.y, n.z]
            uv += [a * Float(o.tiles), b * Float(o.tiles)]
            if p?.base != nil { col += [1, 1, 1, 1] } else {      // no texture: shore → grass → rock → snow by height and slope
                let c = TerrainGraph.colour(amp > 0 ? y / amp : 0.5, 1 - n.y, o.sea)
                col += [c.x, c.y, c.z, 1]
            }
        } }
        for j in 0..<res { for i in 0..<res {
            let a = UInt32(i + j * R)
            idx += [a, a + 1, a + UInt32(R), a + 1, a + UInt32(R) + 1, a + UInt32(R)]
        } }
        var bin = Data(); var views: [[String: Any]] = []
        func add(_ d: Data, _ t: Int?) -> Int {
            while bin.count % 4 != 0 { bin.append(0) }
            var v: [String: Any] = ["buffer": 0, "byteOffset": bin.count, "byteLength": d.count]
            if let t = t { v["target"] = t }
            bin.append(d); views.append(v); return views.count - 1
        }
        func bytes<T>(_ a: [T]) -> Data { a.withUnsafeBytes { Data($0) } }
        let vp = add(bytes(pos), 34962), vn_ = add(bytes(nor), 34962), vu = add(bytes(uv), 34962), vi = add(bytes(idx), 34963), vc = add(bytes(col), 34962)
        let nv = pos.count / 3
        var mn: [Float] = [1e9, 1e9, 1e9], mx: [Float] = [-1e9, -1e9, -1e9]
        for i in 0..<nv { for k in 0..<3 { mn[k] = min(mn[k], pos[i * 3 + k]); mx[k] = max(mx[k], pos[i * 3 + k]) } }
        let acc: [[String: Any]] = [
            ["bufferView": vp, "componentType": 5126, "count": nv, "type": "VEC3", "min": mn, "max": mx],
            ["bufferView": vn_, "componentType": 5126, "count": nv, "type": "VEC3"],
            ["bufferView": vu, "componentType": 5126, "count": nv, "type": "VEC2"],
            ["bufferView": vi, "componentType": 5125, "count": idx.count, "type": "SCALAR"],
            ["bufferView": vc, "componentType": 5126, "count": nv, "type": "VEC4"]]
        var images: [[String: Any]] = [], textures: [[String: Any]] = []
        func tex(_ d: Data?, _ mime: String) -> Int? {
            guard let d = d else { return nil }
            images.append(["bufferView": add(d, nil), "mimeType": mime]); textures.append(["source": images.count - 1, "sampler": 0])
            return textures.count - 1
        }
        var pbr: [String: Any] = ["metallicFactor": 1.0, "roughnessFactor": 1.0]
        var mat: [String: Any] = ["doubleSided": true]
        if let b = tex(p?.base, "image/jpeg") { pbr["baseColorTexture"] = ["index": b] } else { pbr["baseColorFactor"] = [1, 1, 1, 1] }
        if let m = tex(p?.mr, "image/png") { pbr["metallicRoughnessTexture"] = ["index": m] } else { pbr["metallicFactor"] = 0.0; pbr["roughnessFactor"] = 0.9 }
        if let oc = tex(p?.occ, "image/png") { mat["occlusionTexture"] = ["index": oc] }
        mat["pbrMetallicRoughness"] = pbr
        let json: [String: Any] = [
            "asset": ["version": "2.0", "generator": "SaikiMotion Terrain"], "scene": 0, "scenes": [["nodes": [0]]], "nodes": [["mesh": 0]],
            "meshes": [["primitives": [["attributes": ["POSITION": 0, "NORMAL": 1, "TEXCOORD_0": 2, "COLOR_0": 4], "indices": 3, "material": 0]]]],
            "materials": [mat], "accessors": acc, "bufferViews": views, "buffers": [["byteLength": bin.count]],
            "samplers": [["magFilter": 9729, "minFilter": 9987, "wrapS": 10497, "wrapT": 10497]], "images": images, "textures": textures]
        var js = (try? JSONSerialization.data(withJSONObject: json)) ?? Data()
        while js.count % 4 != 0 { js.append(0x20) }
        while bin.count % 4 != 0 { bin.append(0) }
        var out = Data()
        func u32(_ v: UInt32) { var x = v.littleEndian; withUnsafeBytes(of: &x) { out.append(contentsOf: $0) } }
        u32(0x46546C67); u32(2); u32(UInt32(12 + 8 + js.count + 8 + bin.count))
        u32(UInt32(js.count)); u32(0x4E4F534A); out.append(js)
        u32(UInt32(bin.count)); u32(0x004E4942); out.append(bin)
        return out
    }
}

// MARK: - panel

final class TerrainPanel: UIView, UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate {
    private weak var host: EditorViewController?
    private let accent = UIColor(red: 1, green: 0.55, blue: 0.08, alpha: 1)
    private let tabs = UISegmentedControl(items: ["Shape", "Nodes", "Material"])
    private let resSeg = UISegmentedControl(items: ["Low", "Medium", "High"])
    private let texRes = UISegmentedControl(items: ["1k (fast)", "2k"])
    private let search = UISearchBar(), table = UITableView(), status = UILabel(), addBtn = UIButton(type: .system)
    private let previewView = UIImageView(), nodeStack = UIStackView()
    private var pages: [UIStackView] = []
    private var all: [(id: String, name: String)] = [], shown: [(id: String, name: String)] = []
    private var pick = -1, busy = false, previewWork: DispatchWorkItem?
    // remembered between openings
    private static var nodes: [TNode] = TerrainGraph.presets[1].1
    private static var height: Float = 0.35, edge: Float = 0.25, sea: Float = 0, tiles: Float = 4

    static func present(in host: EditorViewController, over view: UIView) {
        if view.subviews.contains(where: { $0 is TerrainPanel }) { return }
        let v = TerrainPanel(host: host)
        v.translatesAutoresizingMaskIntoConstraints = false; view.addSubview(v)
        NSLayoutConstraint.activate([v.leadingAnchor.constraint(equalTo: view.leadingAnchor), v.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                                     v.topAnchor.constraint(equalTo: view.topAnchor), v.bottomAnchor.constraint(equalTo: view.bottomAnchor)])
    }

    init(host: EditorViewController) {
        self.host = host
        super.init(frame: .zero)
        backgroundColor = UIColor(white: 0, alpha: 0.55)
        build(); rebuildNodes(); updatePreview()
        PolyHaven.list { [weak self] l in DispatchQueue.main.async {
            self?.all = l; self?.filter("")
            if l.isEmpty { self?.status.text = "Could not reach Poly Haven. Check your connection." } } }
    }
    required init?(coder: NSCoder) { fatalError() }

    // MARK: ui helpers
    private func label(_ t: String, _ size: CGFloat = 13, _ w: UIFont.Weight = .regular, _ c: UIColor = UIColor(white: 0.7, alpha: 1)) -> UILabel {
        let l = UILabel(); l.text = t; l.textColor = c; l.font = .systemFont(ofSize: size, weight: w); return l
    }
    private func style(_ s: UISegmentedControl) {
        s.selectedSegmentTintColor = accent
        s.setTitleTextAttributes([.foregroundColor: UIColor.white], for: .normal); s.setTitleTextAttributes([.foregroundColor: UIColor.black], for: .selected)
    }
    private func slider(_ title: String, _ lo: Float, _ hi: Float, _ v: Float, _ fmt: String = "%.2f", _ cb: @escaping (Float) -> Void) -> UIStackView {
        let l = label(title); l.widthAnchor.constraint(equalToConstant: 84).isActive = true
        let val = label(String(format: fmt, v), 12); val.textAlignment = .right; val.widthAnchor.constraint(equalToConstant: 42).isActive = true
        let s = UISlider(); s.minimumValue = lo; s.maximumValue = hi; s.value = v; s.tintColor = accent
        s.addAction(UIAction { [weak s, weak val] _ in guard let s = s else { return }; val?.text = String(format: fmt, s.value); cb(s.value) }, for: .valueChanged)
        let r = UIStackView(arrangedSubviews: [l, s, val]); r.spacing = 8; r.alignment = .center; return r
    }
    private func iconBtn(_ name: String, _ tint: UIColor = .white, _ h: @escaping () -> Void) -> UIButton {
        let b = UIButton(type: .system); b.setImage(UIImage(systemName: name), for: .normal); b.tintColor = tint
        b.widthAnchor.constraint(equalToConstant: 30).isActive = true; b.addAction(UIAction { _ in h() }, for: .touchUpInside); return b
    }

    private func build() {
        let card = UIView(); card.backgroundColor = UIColor(white: 0.09, alpha: 1); card.layer.cornerRadius = 22
        card.translatesAutoresizingMaskIntoConstraints = false; addSubview(card)
        let title = label("Terrain", 22, .bold, .white)
        let x = UIButton(type: .system); x.setImage(UIImage(systemName: "xmark"), for: .normal); x.tintColor = .white
        x.addTarget(self, action: #selector(close), for: .touchUpInside)
        let head = UIStackView(arrangedSubviews: [title, UIView(), x]); head.alignment = .center
        previewView.contentMode = .scaleAspectFill; previewView.clipsToBounds = true; previewView.layer.cornerRadius = 12
        previewView.layer.magnificationFilter = .linear; previewView.backgroundColor = UIColor(white: 0.14, alpha: 1)
        previewView.heightAnchor.constraint(equalToConstant: 150).isActive = true
        for s in [tabs, resSeg, texRes] { style(s) }
        tabs.selectedSegmentIndex = 0; resSeg.selectedSegmentIndex = 1; texRes.selectedSegmentIndex = 0
        tabs.addAction(UIAction { [weak self] _ in self?.showTab() }, for: .valueChanged)

        // Shape
        let presetBtn = UIButton(type: .system); presetBtn.setTitle("Start from a preset…", for: .normal); presetBtn.tintColor = accent
        presetBtn.contentHorizontalAlignment = .leading; presetBtn.showsMenuAsPrimaryAction = true
        presetBtn.menu = UIMenu(children: TerrainGraph.presets.map { pr in UIAction(title: pr.0) { [weak self] _ in
            guard let self = self else { return }
            TerrainPanel.nodes = pr.1; TerrainPanel.edge = pr.2; TerrainPanel.sea = pr.3
            self.rebuildShape(); self.rebuildNodes(); self.updatePreview() } })
        shapeBox.axis = .vertical; shapeBox.spacing = 10
        rebuildShape()

        // Nodes
        let addNode = UIButton(type: .system); addNode.setTitle("＋ Add node", for: .normal); addNode.tintColor = accent
        addNode.contentHorizontalAlignment = .leading; addNode.showsMenuAsPrimaryAction = true
        func grp(_ t: String, _ gen: Bool) -> UIMenu {
            UIMenu(title: t, options: .displayInline, children: TKind.allCases.filter { $0.isGen == gen }.map { k in
                UIAction(title: k.title, image: UIImage(systemName: k.icon)) { [weak self] _ in
                    TerrainPanel.nodes.append(TNode(k)); self?.rebuildNodes(); self?.updatePreview() } })
        }
        addNode.menu = UIMenu(children: [grp("Modifiers", false), grp("Generators", true)])
        nodeStack.axis = .vertical; nodeStack.spacing = 10
        let hint = label("Nodes run top to bottom. Generators build height, modifiers reshape what's above them.", 11)
        hint.numberOfLines = 0
        let nodesBox = UIStackView(arrangedSubviews: [addNode, hint, nodeStack]); nodesBox.axis = .vertical; nodesBox.spacing = 8

        // Material
        search.placeholder = "Search Poly Haven textures (rock, sand, grass…)"; search.searchBarStyle = .minimal; search.delegate = self
        search.searchTextField.textColor = .white; search.autocapitalizationType = .none
        table.dataSource = self; table.delegate = self; table.backgroundColor = .clear; table.rowHeight = 56
        table.separatorColor = UIColor(white: 1, alpha: 0.08)
        table.heightAnchor.constraint(equalToConstant: 220).isActive = true
        let matBox = UIStackView(arrangedSubviews: [label("Texture", 15, .semibold, .white), search, table,
            slider("Tex tiles", 1, 16, TerrainPanel.tiles, "%.0f") { TerrainPanel.tiles = $0 },
            { let r = UIStackView(arrangedSubviews: [self.label("Tex quality"), self.texRes]); r.spacing = 10; return r }()])
        matBox.axis = .vertical; matBox.spacing = 10

        pages = [shapeBox, nodesBox, matBox]
        status.textColor = UIColor(white: 0.7, alpha: 1); status.font = .systemFont(ofSize: 12); status.numberOfLines = 2
        addBtn.setTitle("Add terrain", for: .normal); addBtn.setTitleColor(.black, for: .normal)
        addBtn.titleLabel?.font = .systemFont(ofSize: 17, weight: .bold); addBtn.backgroundColor = accent; addBtn.layer.cornerRadius = 14
        addBtn.addTarget(self, action: #selector(addTap), for: .touchUpInside)
        addBtn.heightAnchor.constraint(equalToConstant: 48).isActive = true

        let body = UIStackView(arrangedSubviews: pages); body.axis = .vertical; body.translatesAutoresizingMaskIntoConstraints = false
        let scroll = UIScrollView(); scroll.translatesAutoresizingMaskIntoConstraints = false; scroll.keyboardDismissMode = .onDrag
        scroll.addSubview(body)
        let stack = UIStackView(arrangedSubviews: [head, previewView, tabs, scroll, status, addBtn]); stack.axis = .vertical; stack.spacing = 10
        stack.translatesAutoresizingMaskIntoConstraints = false; card.addSubview(stack)
        NSLayoutConstraint.activate([
            card.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 12), card.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -12),
            card.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor, constant: 40), card.bottomAnchor.constraint(equalTo: safeAreaLayoutGuide.bottomAnchor, constant: -12),
            stack.leadingAnchor.constraint(equalTo: card.leadingAnchor, constant: 16), stack.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -16),
            stack.topAnchor.constraint(equalTo: card.topAnchor, constant: 16), stack.bottomAnchor.constraint(equalTo: card.bottomAnchor, constant: -16),
            body.leadingAnchor.constraint(equalTo: scroll.contentLayoutGuide.leadingAnchor), body.trailingAnchor.constraint(equalTo: scroll.contentLayoutGuide.trailingAnchor),
            body.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor), body.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor),
            body.widthAnchor.constraint(equalTo: scroll.frameLayoutGuide.widthAnchor)])
        presetRef = presetBtn
        shapeBox.insertArrangedSubview(presetBtn, at: 0)
        showTab()
    }
    private let shapeBox = UIStackView()
    private var presetRef: UIButton?

    private func rebuildShape() {
        for v in shapeBox.arrangedSubviews where v !== presetRef { shapeBox.removeArrangedSubview(v); v.removeFromSuperview() }
        shapeBox.addArrangedSubview(slider("Height", 0, 1, TerrainPanel.height) { TerrainPanel.height = $0 })
        shapeBox.addArrangedSubview(slider("Edge fade", 0, 1, TerrainPanel.edge) { [weak self] in TerrainPanel.edge = $0; self?.updatePreview() })
        shapeBox.addArrangedSubview(slider("Sea level", 0, 0.6, TerrainPanel.sea) { [weak self] in TerrainPanel.sea = $0; self?.updatePreview() })
        let r = UIStackView(arrangedSubviews: [label("Mesh detail"), resSeg]); r.spacing = 10; r.alignment = .center
        shapeBox.addArrangedSubview(r)
    }

    private func rebuildNodes() {
        nodeStack.arrangedSubviews.forEach { nodeStack.removeArrangedSubview($0); $0.removeFromSuperview() }
        for (idx, nd) in TerrainPanel.nodes.enumerated() {
            let card = UIStackView(); card.axis = .vertical; card.spacing = 8; card.isLayoutMarginsRelativeArrangement = true
            card.layoutMargins = UIEdgeInsets(top: 10, left: 12, bottom: 10, right: 12)
            let bg = UIView(); bg.backgroundColor = UIColor(white: 0.15, alpha: 1); bg.layer.cornerRadius = 12; bg.translatesAutoresizingMaskIntoConstraints = false
            card.insertSubview(bg, at: 0)
            NSLayoutConstraint.activate([bg.leadingAnchor.constraint(equalTo: card.leadingAnchor), bg.trailingAnchor.constraint(equalTo: card.trailingAnchor),
                                         bg.topAnchor.constraint(equalTo: card.topAnchor), bg.bottomAnchor.constraint(equalTo: card.bottomAnchor)])
            let ic = UIImageView(image: UIImage(systemName: nd.kind.icon)); ic.tintColor = nd.kind.isGen ? accent : UIColor(red: 0.4, green: 0.7, blue: 1, alpha: 1)
            ic.contentMode = .scaleAspectFit; ic.widthAnchor.constraint(equalToConstant: 22).isActive = true
            let t = label("\(idx + 1). \(nd.kind.title)", 14, .semibold, nd.on ? .white : UIColor(white: 0.45, alpha: 1))
            let hd = UIStackView(arrangedSubviews: [ic, t, UIView(),
                iconBtn(nd.on ? "eye" : "eye.slash") { [weak self] in TerrainPanel.nodes[idx].on.toggle(); self?.rebuildNodes(); self?.updatePreview() },
                iconBtn("chevron.up") { [weak self] in if idx > 0 { TerrainPanel.nodes.swapAt(idx, idx - 1); self?.rebuildNodes(); self?.updatePreview() } },
                iconBtn("chevron.down") { [weak self] in if idx < TerrainPanel.nodes.count - 1 { TerrainPanel.nodes.swapAt(idx, idx + 1); self?.rebuildNodes(); self?.updatePreview() } },
                iconBtn("trash", UIColor(red: 1, green: 0.4, blue: 0.4, alpha: 1)) { [weak self] in TerrainPanel.nodes.remove(at: idx); self?.rebuildNodes(); self?.updatePreview() }])
            hd.alignment = .center; hd.spacing = 2; card.addArrangedSubview(hd)
            for (pi, sp) in nd.kind.params.enumerated() {
                if let opts = sp.4 {
                    let seg = UISegmentedControl(items: opts); style(seg); seg.selectedSegmentIndex = Int(nd.p[pi])
                    seg.addAction(UIAction { [weak self, weak seg] _ in
                        guard let seg = seg else { return }; TerrainPanel.nodes[idx].p[pi] = Float(seg.selectedSegmentIndex); self?.updatePreview() }, for: .valueChanged)
                    let r = UIStackView(arrangedSubviews: [label(sp.0), seg]); r.spacing = 8; r.alignment = .center; card.addArrangedSubview(r)
                } else {
                    let whole = sp.2 - sp.1 >= 8
                    card.addArrangedSubview(slider(sp.0, sp.1, sp.2, nd.p[pi], whole ? "%.0f" : "%.2f") { [weak self] v in
                        TerrainPanel.nodes[idx].p[pi] = whole ? v.rounded() : v; self?.updatePreview() })
                }
            }
            nodeStack.addArrangedSubview(card)
        }
        if TerrainPanel.nodes.isEmpty { nodeStack.addArrangedSubview(label("No nodes — the terrain is flat. Add a generator.", 12)) }
    }

    private func updatePreview() {
        previewWork?.cancel()
        let nodes = TerrainPanel.nodes, e = TerrainPanel.edge, s = TerrainPanel.sea
        let w = DispatchWorkItem { [weak self] in
            let img = TerrainGraph.preview(nodes, edge: e, sea: s)
            DispatchQueue.main.async { self?.previewView.image = img }
        }
        previewWork = w
        DispatchQueue.global(qos: .userInitiated).asyncAfter(deadline: .now() + 0.12, execute: w)
    }

    private func showTab() { for (i, p) in pages.enumerated() { p.isHidden = i != tabs.selectedSegmentIndex }; addBtn.isHidden = false }

    @objc private func close() { removeFromSuperview() }

    private func filter(_ q: String) {
        let k = q.trimmingCharacters(in: .whitespaces).lowercased()
        shown = k.isEmpty ? all : all.filter { $0.name.lowercased().contains(k) || $0.id.contains(k) }
        pick = -1; table.reloadData()
    }
    func searchBar(_ s: UISearchBar, textDidChange t: String) { filter(t) }
    func searchBarSearchButtonClicked(_ s: UISearchBar) { s.resignFirstResponder() }
    func tableView(_ t: UITableView, numberOfRowsInSection s: Int) -> Int { shown.count + 1 }
    func tableView(_ t: UITableView, cellForRowAt ip: IndexPath) -> UITableViewCell {
        let c = t.dequeueReusableCell(withIdentifier: "c") ?? UITableViewCell(style: .default, reuseIdentifier: "c")
        c.backgroundColor = .clear; c.textLabel?.textColor = .white; c.tintColor = accent
        let i = ip.row - 1
        c.textLabel?.text = i < 0 ? "Procedural colours (shore / grass / rock / snow)" : shown[i].name
        c.accessoryType = i == pick ? .checkmark : .none; c.imageView?.image = nil
        if i >= 0 {
            let id = shown[i].id
            c.imageView?.image = UIImage(systemName: "photo")
            PolyHaven.thumb(id) { [weak c] img in
                guard let img = img, let c = c, c.textLabel?.text == self.shown.first(where: { $0.id == id })?.name else { return }
                c.imageView?.image = img; c.setNeedsLayout()
            }
        }
        return c
    }
    func tableView(_ t: UITableView, didSelectRowAt ip: IndexPath) { pick = ip.row - 1; t.reloadData(); search.resignFirstResponder() }

    @objc private func addTap() {
        guard !busy, let host = host else { return }
        busy = true; addBtn.alpha = 0.5
        var o = TerrainGLB.Opt()
        o.nodes = TerrainPanel.nodes; o.res = [64, 128, 224][resSeg.selectedSegmentIndex]
        o.height = TerrainPanel.height * 0.5; o.edge = TerrainPanel.edge; o.sea = TerrainPanel.sea; o.tiles = Int(TerrainPanel.tiles.rounded())
        let tex = pick >= 0 ? shown[pick] : nil
        let res = texRes.selectedSegmentIndex == 0 ? "1k" : "2k"
        let name = "Terrain"
        status.text = tex == nil ? "Building…" : "Downloading \(tex!.name) maps…"
        let finish: (ExtrasGLB.Packed?) -> Void = { [weak self] p in
            let glb = TerrainGLB.build(o, p)
            DispatchQueue.main.async {
                guard let self = self else { return }
                self.busy = false; self.addBtn.alpha = 1
                guard let path = ProjectIO.writeDataIntoSandbox(glb, name: "terrain_\(nowMs()).glb") else { self.status.text = "Could not build the terrain."; return }
                host.addMedia(path, .MODEL)
                if let l = Editor.scene.layers.last(where: { $0.imagePath == path }) {
                    l.name = tex.map { "\(name) · \($0.name)" } ?? name
                    if let p = p { let n = p.hasNormal || p.height != nil; l.xset("pbrNorm", n ? 1.3 : 0); l.xset("pbrExtra", 1); l.xset("pbrPom", 0) }
                    host.render(); host.refreshPanel()
                }
                self.close()
            }
        }
        DispatchQueue.global(qos: .userInitiated).async {
            guard let t = tex else { finish(nil); return }
            PolyHaven.maps(t.id, res: res) { m in
                guard let m = m else { DispatchQueue.main.async { self.busy = false; self.addBtn.alpha = 1; self.status.text = "Download failed. Try again." }; return }
                finish(ExtrasGLB.pack(m, size: res == "1k" ? 1024 : 2048))
            }
        }
    }
}
