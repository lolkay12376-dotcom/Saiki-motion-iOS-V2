// GlobalEnv.swift — one HDRI (Poly Haven or imported) lighting + reflecting every 3D model, terrain and water.
import UIKit
import Metal
import ImageIO

enum GlobalEnv {
    static var path: String? {
        get { UserDefaults.standard.string(forKey: "r3d.envPath") }
        set { UserDefaults.standard.set(newValue, forKey: "r3d.envPath") }
    }
    private(set) static var cached: MTLTexture?
    private static var cachedPath: String?, failed: String?

    static var uniform: SIMD4<Float> {
        guard path != nil, let t = cached else { return SIMD4(0, 0, 0, 1) }
        return SIMD4(1, R3D.g("envRot", 0), Float(t.mipmapLevelCount - 1), R3D.g("envGain", 1))
    }

    /// Equirect picture (hdr / exr / jpg) as a mipmapped half-float texture so highlights keep their range.
    @discardableResult static func tex(_ core: MetalCore) -> MTLTexture? {
        guard let p = path else { cached = nil; cachedPath = nil; return nil }
        if cachedPath == p, let t = cached { return t }
        if failed == p { return nil }
        var made: MTLTexture?
        autoreleasepool {
            guard let src = CGImageSourceCreateWithURL(URL(fileURLWithPath: p) as CFURL, nil),
                  let cg = CGImageSourceCreateImageAtIndex(src, 0, nil),
                  let cs = CGColorSpace(name: CGColorSpace.extendedLinearSRGB) else { return }
            let w = max(64, min(cg.width, 2048)), h = max(32, w / 2)
            var data = [UInt8](repeating: 0, count: w * h * 8)
            let info = CGBitmapInfo.floatComponents.rawValue | CGBitmapInfo.byteOrder16Little.rawValue | CGImageAlphaInfo.premultipliedLast.rawValue
            let ok = data.withUnsafeMutableBytes { raw -> Bool in
                guard let ctx = CGContext(data: raw.baseAddress, width: w, height: h, bitsPerComponent: 16, bytesPerRow: w * 8, space: cs, bitmapInfo: info) else { return false }
                ctx.interpolationQuality = .high; ctx.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h)); return true
            }
            guard ok else { return }
            let d = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .rgba16Float, width: w, height: h, mipmapped: true)
            d.usage = .shaderRead; d.storageMode = .shared
            guard let t = core.device.makeTexture(descriptor: d) else { return }
            data.withUnsafeBytes { t.replace(region: MTLRegionMake2D(0, 0, w, h), mipmapLevel: 0, withBytes: $0.baseAddress!, bytesPerRow: w * 8) }
            if let cb = core.queue.makeCommandBuffer(), let blit = cb.makeBlitCommandEncoder() { blit.generateMipmaps(for: t); blit.endEncoding(); cb.commit(); cb.waitUntilCompleted() }
            made = t
        }
        if let m = made { cached = m; cachedPath = p } else { failed = p }
        return made
    }
}
