// EditorEffects.swift — Effects panel: applied list, browser, presets, custom + SDK IDE.

import UIKit
import UniformTypeIdentifiers

extension EditorViewController {
        // ---------------------------------------------------------------- effects

        func buildFx(_ l: Layer) {
            let p: UIStackView = panelList
            let hdr = hRow()
            let ht = UILabel()
            ht.text = "Effects  ·  " + l.name
            ht.textColor = argbToUIColor(C.TEXT)
            ht.font = boldFont(20)
            ht.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
            hdr.addArrangedSubview(ht)
            hdr.addArrangedSubview(wrap(pill("Close", "close") { [weak self] in self?.closePanel() }, 112, 42, 0, 0, 0, 0))
            put(p, hdr, 0, 6, 8)
            p.addArrangedSubview(chipRow(["Applied", "Browse", "Presets", "Custom"], fxTab) { [weak self] i in
                guard let self = self else { return }
                self.fxTab = i
                self.showBottom(); self.refreshPanel()
            })
            switch fxTab {
            case 0: buildApplied(l)
            case 1: buildBrowse(l)
            case 2: buildPresets(l)
            default: buildCustom(l)
            }
        }

        func snapFx(_ l: Layer, _ entry: String) -> FxSnap? {
            guard let d = Registry.get(entry) else { return nil }
            var m: [(String, JObj)] = []
            if d.kind == 1 {
                for pd in d.props {
                    if let tr = l.props[pd.key] { m.append(("=" + pd.key, tr.toJson())) }
                }
            } else {
                let pre = entry + "__"
                for (k, tr) in l.props where k.hasPrefix(pre) {
                    m.append((String(k.dropFirst(pre.count)), tr.toJson()))
                }
            }
            var ins: [String: Int] = [:]
            for (k, v) in l.inputs where k.hasPrefix(entry + ":") {
                ins[String(k.dropFirst(entry.count + 1))] = v
            }
            return FxSnap(d.id, m, ins, l.fxOff.contains(entry))
        }

        func pasteFx(_ l: Layer, _ snap: FxSnap) {
            guard let d = Registry.byId[snap.id] else { return }
            let entry: String
            if d.kind == 1 {
                entry = d.id
                if !l.fx.contains(entry) { l.fx.append(entry) }
            } else {
                entry = Registry.uniqueEntry(l, d.id)
                l.fx.append(entry)
            }
            if snap.off { l.fxOff.insert(entry) } else { _ = l.fxOff.remove(entry) }
            for (rk, js) in snap.tracks {
                let key = rk.hasPrefix("=") ? String(rk.dropFirst()) : entry + "__" + rk
                l.track(key).load(js)
            }
            for (nm, id) in snap.inputs { l.inputs[entry + ":" + nm] = id }
            expanded.insert("\(l.id):\(entry)")
        }

        func resetFx(_ l: Layer, _ entry: String) {
            guard let d = Registry.get(entry) else { return }
            for pd in d.props {
                let tr = l.track(l.pkey(entry, pd))
                tr.keys.removeAll()
                tr.base = pd.def
                _ = tr.setExpr("")
                tr.exprOn = false
            }
            for cp in d.colors {
                let ck = l.ckey(entry, cp)
                let vals: [(String, Int)] = [("_r", Int((UInt32(bitPattern: cp.def) >> 16) & 0xFF)),
                                             ("_g", Int((UInt32(bitPattern: cp.def) >> 8) & 0xFF)),
                                             ("_b", Int(UInt32(bitPattern: cp.def) & 0xFF)),
                                             ("_a", Int(UInt32(bitPattern: cp.def) >> 24))]
                for (sf, v) in vals {
                    let tr = l.track(ck + sf)
                    tr.keys.removeAll()
                    tr.base = Float(v) / 255
                }
            }
        }

        func moveFx(_ l: Layer, _ entry: String, _ dir: Int) {
            guard let idx = l.fx.firstIndex(of: entry) else { return }
            let to = idx + dir
            if to < 0 || to >= l.fx.count { return }
            l.fx.remove(at: idx)
            l.fx.insert(entry, at: to)
        }

        func removeFx(_ l: Layer, _ entry: String) {
            l.fx.removeAll { $0 == entry }
            _ = l.fxOff.remove(entry)
            let pre = entry + "__"
            if entry.contains("~") {
                for k in Array(l.props.keys) where k.hasPrefix(pre) { l.props.removeValue(forKey: k) }
            }
            for k in Array(l.inputs.keys) where k.hasPrefix(entry + ":") { l.inputs.removeValue(forKey: k) }
        }

        func fxMenu(_ l: Layer, _ entry: String) {
            guard let d = Registry.get(entry) else { return }
            let idx = l.fx.firstIndex(of: entry) ?? -1
            let labels = ["Copy effect", "Duplicate effect", "Move up", "Move down", "Reset to default", "Remove effect",
                          fxClip.isEmpty ? "Paste effect (nothing copied)" : "Paste effect (\(fxClip.count))"]
            let icons = ["dup", "dup", "chev_up", "chev_down", "adjust", "trash", "import"]
            Dlg(self).setTitle(d.name).setIconItems(labels, icons) { [weak self] _, w in
                guard let self = self else { return }
                switch w {
                case 0:
                    if let sn = self.snapFx(l, entry) { self.fxClip = [sn] }
                    self.toast("Effect copied")
                case 1:
                    if let sn = self.snapFx(l, entry) {
                        self.pushUndo()
                        self.pasteFx(l, sn)
                        self.refreshPanel(); self.render()
                    }
                case 2:
                    if idx > 0 {
                        self.pushUndo()
                        self.moveFx(l, entry, -1)
                        self.refreshPanel(); self.render()
                    }
                case 3:
                    if idx < l.fx.count - 1 {
                        self.pushUndo()
                        self.moveFx(l, entry, 1)
                        self.refreshPanel(); self.render()
                    }
                case 4:
                    self.pushUndo()
                    self.resetFx(l, entry)
                    self.refreshPanel(); self.render()
                case 5:
                    self.pushUndo()
                    self.removeFx(l, entry)
                    self.refreshPanel(); self.render()
                default:
                    if self.fxClip.isEmpty { self.toast("No effect copied"); return }
                    self.pushUndo()
                    for sn in self.fxClip { self.pasteFx(l, sn) }
                    self.refreshPanel(); self.render()
                }
            }.show()
        }

        func fxListMenu(_ l: Layer) {
            let labels = ["Copy all effects",
                          fxClip.isEmpty ? "Paste effects (nothing copied)" : "Paste effects (\(fxClip.count))",
                          "Reset all to default", "Remove all effects"]
            let icons = ["dup", "import", "adjust", "trash"]
            Dlg(self).setTitle("Effects").setIconItems(labels, icons) { [weak self] _, w in
                guard let self = self else { return }
                switch w {
                case 0:
                    self.fxClip = l.fx.compactMap { self.snapFx(l, $0) }
                    self.toast(self.fxClip.isEmpty ? "No effects to copy" : "Copied \(self.fxClip.count) effects")
                case 1:
                    if self.fxClip.isEmpty {
                        self.toast("No effects copied")
                    } else {
                        self.pushUndo()
                        for sn in self.fxClip { self.pasteFx(l, sn) }
                        self.refreshPanel(); self.render()
                    }
                case 2:
                    self.pushUndo()
                    for e in l.fx { self.resetFx(l, e) }
                    self.refreshPanel(); self.render()
                default:
                    self.pushUndo()
                    for e in l.fx { self.removeFx(l, e) }
                    self.refreshPanel(); self.render()
                }
            }.show()
        }

        func fxHeader(_ l: Layer, _ d: EffectDef, _ entry: String) -> UIView {
            let key = "\(l.id):\(entry)"
            let isOpen = expanded.contains(key)
            let bar = hRow()
            bar.backgroundColor = argbToUIColor(C.CARD)
            bar.isLayoutMarginsRelativeArrangement = true
            bar.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 14, bottom: 0, trailing: 2)
            bar.addArrangedSubview(wrap(IconView("handle", C.DIM, 20), 36, 48, 0, 0, 0, 0))
            let t = UILabel()
            t.text = entry.contains("~") ? d.name + " " + afterLast(entry, "~") : d.name
            t.textColor = argbToUIColor(C.TEXT)
            t.font = boldFont(16)
            t.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
            bar.addArrangedSubview(t)
            let off = l.fxOff.contains(entry)
            let eye = IconView(off ? "eye_off" : "eye", off ? C.DIM : C.GREEN, 20)
            eye.onClick = { [weak self] in
                guard let self = self else { return }
                self.pushUndo()
                if off { l.fxOff.remove(entry) } else { l.fxOff.insert(entry) }
                self.refreshPanel(); self.render()
            }
            bar.addArrangedSubview(wrap(eye, 40, 48, 0, 0, 0, 0))
            let chev = IconView(isOpen ? "chev_up" : "chev_down", C.DIM, 20)
            chev.onClick = { [weak self] in
                guard let self = self else { return }
                if self.expanded.contains(key) { self.expanded.remove(key) } else { self.expanded.insert(key) }
                self.refreshPanel()
            }
            bar.addArrangedSubview(wrap(chev, 40, 48, 0, 0, 0, 0))
            let more = IconView("more", C.TEXT, 20)
            more.onClick = { [weak self] in self?.fxMenu(l, entry) }
            bar.addArrangedSubview(wrap(more, 40, 48, 0, 0, 0, 0))
            return bar
        }

        func buildApplied(_ l: Layer) {
            let p: UIStackView = panelList
            let top = hRow()
            let cnt = UILabel()
            cnt.text = "\(l.fx.count)\(l.fx.count == 1 ? " effect" : " effects")"
            cnt.textColor = argbToUIColor(C.DIM)
            cnt.font = sysFont(13)
            cnt.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
            top.addArrangedSubview(cnt)
            let menu = IconView("more", C.TEXT, 22)
            menu.onClick = { [weak self] in self?.fxListMenu(l) }
            top.addArrangedSubview(wrap(menu, 44, 40, 0, 0, 0, 0))
            put(p, top, 40, 6, 2)
            if l.fx.isEmpty { text(p, "No effects yet. Tap Add Effect to browse.") }
            for entry in l.fx {
                guard let d = Registry.get(entry) else { continue }
                let id = d.id
                let c = vStack()
                c.addArrangedSubview(fxHeader(l, d, entry))
                if expanded.contains("\(l.id):\(entry)") {
                    text(c, d.desc, C.DIM, 12)
                    if let err = Registry.errors[id] { text(c, "Shader error: \(err)", C.RED, 12) }
                    for pd in d.props { addRow(c, l, Registry.instProp(l, entry, pd)) }
                    for cp in d.colors { addColorParam(c, l, Registry.instColor(l, entry, cp)) }
                    if id == "particles" {
                        let pmb = SwitchRow()
                        pmb.label = "Motion blur"; pmb.on = l.mblur
                        pmb.onToggle = { [weak self] v in self?.pushUndo(); l.mblur = v; self?.render() }
                        put(c, pmb, 52)
                        let occ = SwitchRow()
                        occ.label = "Occlude"; occ.on = l.p("pOcclude", Editor.time) >= 0.5
                        occ.onToggle = { [weak self] v in
                            self?.pushUndo(); l.track("pOcclude").base = v ? 1 : 0; self?.render()
                        }
                        put(c, occ, 52)
                        text(c, "Occlude hides particles that are behind 3D layers and models. Particles follow the scene camera.", C.DIM, 12)
                    }
                    for nm in d.inputs {
                        let rid = l.inputs[entry + ":" + nm]
                        let ref = Editor.scene.layers.first { $0.id == rid }
                        put(c, pill(nm + " layer: " + (ref?.name ?? "None"), "layers") { [weak self] in
                            self?.showInputDialog(l, entry, nm)
                        }, 42)
                    }
                    if id == "lightsweep" {
                        put(c, pill("Animate sweep") { [weak self] in self?.lightSweepAnim(l) }, 42)
                    }
                    if id == "tile" {
                        let b = hRow()
                        b.distribution = .fillEqually
                        b.spacing = 4
                        for axis in ["tileX", "tileY"] {
                            b.addArrangedSubview(wrap(pill("Scroll " + String(axis.last ?? "?")) { [weak self] in
                                self?.tileScroll(l, axis)
                            }, 0, 40, 0, 0, 0, 0))
                        }
                        c.addArrangedSubview(b)
                    }
                }
                put(p, c, 0, 3, 6)
            }
            put(p, pill("Add Effect", "plus", C.GREEN, C.ONDARK) { [weak self] in
                guard let self = self else { return }
                self.fxTab = 1
                self.showBottom(); self.refreshPanel()
            }, 48, 10, 10)
        }

        func lightSweepAnim(_ l: Layer) {
            pushUndo()
            let tr = l.track("lightsweep__centerX")
            tr.keys.removeAll()
            tr.keys.append(Key(l.start, -0.4, .EASE_IN_OUT))
            tr.keys.append(Key(l.end, 1.4, .EASE_IN_OUT))
            refreshPanel(); render()
        }

        func tileScroll(_ l: Layer, _ key: String) {
            pushUndo()
            let tr = l.track(key)
            let mirror = l.p("tileMirror", Editor.time) >= 0.5
            tr.keys.removeAll()
            tr.keys.append(Key(l.start, 0, .LINEAR))
            tr.keys.append(Key(l.end, mirror ? 2 : 1, .LINEAR))
            refreshPanel(); render()
        }

        func showInputDialog(_ l: Layer, _ entry: String, _ nm: String) {
            let cands = Editor.scene.layers.filter {
                $0.id != l.id && $0.isRenderable() && $0.type != .VIDEO && $0.type != .MODEL && $0.type != .PARTICLES
            }
            var names = ["None"]
            names += cands.map { $0.name }
            Dlg(self).setTitle(nm + " layer").setItems(names) { [weak self] _, w in
                guard let self = self else { return }
                self.pushUndo()
                if w == 0 {
                    l.inputs.removeValue(forKey: entry + ":" + nm)
                } else {
                    l.inputs[entry + ":" + nm] = cands[w - 1].id
                }
                self.refreshPanel(); self.render()
            }.show()
        }

        func fxCategory(_ d: EffectDef) -> String {
            switch d.id {
            case "deepglow", "raytrace", "lightsweep", "contour", "lightleak", "godrays", "starburst", "softfocus", "bokeh": return "Light and glow"
            case "tritone", "duotone", "hueshift", "grayscale", "invert", "rgbsplit", "vignette", "fill",
                 "nightvision", "thermal", "oldphoto", "gradientmap", "threshold", "colorcorrect", "levels", "splittone", "channelmix": return "Color"
            case "etching", "halftone", "zebrafy", "posterize", "filmgrain", "edgelines", "scanlines", "pixelate", "sharpen",
                 "ascii", "hexpixel", "sketch", "toon", "emboss", "clay", "matrixrain", "pixelscatter", "crt": return "Stylize"
            case "distortrgb", "kaleido", "bulge", "twirl", "barrel", "wavewarp", "ripple",
                 "glassblocks", "droste", "polarwarp", "turbulent", "mirror": return "Distort"
            case "blur", "radialblur", "blurmo": return "Blur"
            case "psykoblobs", "texturefolded", "texturemoire", "starfield", "plasma", "fire", "snow": return "Generate"
            case "sshake", "twitch", "glitchslices", "vhs", "oscillate", "autoshake", "randisp", "streaks", "timeslice": return "Glitch and motion"
            case "chromakey": return "Keying"
            default:
                if d.id.hasPrefix("shake_") { return "Glitch and motion" }
                if d.builtin { return "Transform and time" }
                return Registry.CATEGORIES.contains(d.category) ? d.category : "Custom"
            }
        }

        func buildBrowse(_ l: Layer) {
            let p: UIStackView = panelList
            let q = makeField(fxQuery)
            q.placeholder = "Search effects"
            let grid = vStack()
            var fill: (() -> Void)! = nil
            fill = { [weak self] in
                guard let self = self else { return }
                grid.arrangedSubviews.forEach { $0.removeFromSuperview() }
                let qs = fxQuery.trimmingCharacters(in: .whitespaces).lowercased()
                let list = Registry.order.filter {
                    qs.isEmpty || $0.name.lowercased().contains(qs) || $0.desc.lowercased().contains(qs)
                        || self.fxCategory($0).lowercased().contains(qs)
                }
                let groups = Dictionary(grouping: list, by: { self.fxCategory($0) })
                let catOrder = ["Light and glow", "Color", "Stylize", "Distort", "Blur", "Generate",
                                "Glitch and motion", "Keying", "Transform and time", "Custom"]
                let keys = groups.keys.sorted { a, b in
                    let ia = catOrder.firstIndex(of: a) ?? 99
                    let ib = catOrder.firstIndex(of: b) ?? 99
                    return ia < ib
                }
                if keys.isEmpty { text(grid, "No effects match your search.", C.DIM, 13) }
                let cols = max(2, Int((self.view.bounds.width - 60) / 200))
                for k in keys {
                    let items = (groups[k] ?? []).sorted { $0.name < $1.name }
                    text(grid, k + "  (" + String(items.count) + ")", C.GREEN, 14, true)
                    var i = 0
                    while i < items.count {
                        let r = UIStackView()
                        r.axis = .horizontal
                        r.alignment = .fill
                        r.distribution = .fillEqually
                        r.spacing = 8
                        for j in 0..<cols {
                            if i + j >= items.count {
                                r.addArrangedSubview(UIView())
                                continue
                            }
                            let d = items[i + j]
                            let card = EffectCard(d.name, self.fxCategory(d))
                            card.anim = d.previewAnim
                            card.thumbId = d.id
                            card.origId = EffectThumbs.origKey(d.id)
                            card.before = EffectThumbs.cache[EffectThumbs.origKey(d.id)]
                            card.after = EffectThumbs.cache[d.id]
                            card.badge = l.fx.contains(d.id)
                            card.onClick = { [weak self] in self?.showEffectInfo(d, l) }
                            r.addArrangedSubview(wrap(card, 0, 250, 4, 4, 4, 4))
                        }
                        grid.addArrangedSubview(r)
                        i += cols
                    }
                }
            }
            bind(q) { [weak self] s in
                self?.fxQuery = s
                fill()
            }
            put(p, q, 44)
            fill()
            p.addArrangedSubview(grid)
            if Registry.order.contains(where: { !EffectThumbs.ready($0.id) }) {
                EffectThumbs.generate(self, preview) { [weak self] in
                    if let self = self, self.panel == P_FX && self.fxTab == 1 { self.refreshPanel() }
                }
            }
            if !EffectThumbs.lastError.isEmpty { text(p, "Preview error: " + EffectThumbs.lastError, C.RED, 11) }
            if let glErr = Registry.errors["__gl"] { text(p, "GL error: " + glErr, C.RED, 11) }
        }

        func showEffectInfo(_ d: EffectDef, _ l: Layer) {
            let box = vStack()
            box.isLayoutMarginsRelativeArrangement = true
            box.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16)
            let card = EffectCard(d.name, d.category)
            card.anim = d.previewAnim
            card.thumbId = d.id
            card.origId = EffectThumbs.origKey(d.id)
            card.before = EffectThumbs.cache[EffectThumbs.origKey(d.id)]
            card.after = EffectThumbs.cache[d.id]
            box.addArrangedSubview(wrap(card, 0, 280, 0, 0, 0, 0))
            var sb = d.desc + "\n\nParameters: "
            sb += d.props.isEmpty ? "none" : d.props.map { $0.label }.joined(separator: ", ")
            if !d.inputs.isEmpty { sb += "\nLayer inputs: " + d.inputs.joined(separator: ", ") }
            if !d.builtin { sb += "\nCustom effect" }
            if let err = Registry.errors[d.id] { sb += "\n\nShader error:\n" + err }
            let info = UILabel()
            info.text = sb
            info.textColor = argbToUIColor(C.TEXT)
            info.font = sysFont(14)
            info.numberOfLines = 0
            box.addArrangedSubview(pad(info, 10, 0, 0, 0))
            var b = Dlg(self).setTitle(d.name).setView(box)
                .setPositiveButton("Add to layer") { [weak self] _, _ in
                    guard let self = self else { return }
                    self.pushUndo()
                    let entry = d.kind == 1 ? d.id : Registry.uniqueEntry(l, d.id)
                    if !l.fx.contains(entry) { l.fx.append(entry) }
                    l.fxOff.remove(entry)
                    self.expanded.insert("\(l.id):\(entry)")
                    self.fxTab = 0
                    self.showBottom(); self.refreshPanel(); self.render()
                }
                .setNegativeButton("Close", nil)
            if !d.builtin {
                b = b.setNeutralButton("Export") { [weak self] _, _ in
                    guard let self = self else { return }
                    self.exportText(d.id + ".saikieffect.json", self.prettyJson(Registry.toJson(d)))
                }
            }
            b.show()
        }

        func buildPresets(_ l: Layer) {
            let p: UIStackView = panelList
            put(p, pill("Save current effects as preset", "plus", C.GREEN, C.ONDARK) { [weak self] in
                guard let self = self else { return }
                if l.fx.isEmpty { self.toast("Add an effect first"); return }
                let et = self.makeField("My preset")
                Dlg(self).setTitle("Preset name").setView(et).setPositiveButton("Save") { [weak self] _, _ in
                    guard let self = self else { return }
                    var n = et.text ?? ""
                    if n.trimmingCharacters(in: .whitespaces).isEmpty { n = "My preset" }
                    Registry.savePreset(Registry.capturePreset(l, n, Editor.time))
                    self.refreshPanel()
                }.setNegativeButton("Cancel", nil).show()
            }, 44)
            put(p, pill("Import preset file", "import") { [weak self] in self?.pickFile(R_PRESET, [.json, .data]) }, 44)
            for pr in Registry.presets() {
                text(p, pr.name + (pr.builtin ? "  (built in)" : ""), C.TEXT, 15, true)
                let r = hRow()
                r.distribution = .fillEqually
                r.spacing = 4
                r.addArrangedSubview(wrap(pill("Apply") { [weak self] in
                    guard let self = self else { return }
                    self.pushUndo()
                    Registry.applyPreset(l, pr.json)
                    self.fxTab = 0
                    self.refreshPanel(); self.render()
                }, 0, 40, 0, 0, 0, 0))
                r.addArrangedSubview(wrap(pill("Export") { [weak self] in
                    guard let self = self else { return }
                    self.exportText(pr.name + ".saikipreset.json", self.prettyJson(pr.json))
                }, 0, 40, 0, 0, 0, 0))
                if !pr.builtin {
                    r.addArrangedSubview(wrap(pill("Delete", nil, C.CARD2, C.RED) { [weak self] in
                        guard let self = self else { return }
                        Registry.deletePreset(pr.name)
                        self.refreshPanel()
                    }, 0, 40, 0, 0, 0, 0))
                }
                put(p, r, 40)
            }
        }

        func buildCustom(_ l: Layer) {
            let p: UIStackView = panelList
            put(p, pill("Open Effect Editor", "edit", C.GREEN, C.ONDARK) { [weak self] in
                self?.openEffectEditor()
            }, 48)
            let r0 = hRow()
            r0.distribution = .fillEqually
            r0.spacing = 4
            r0.addArrangedSubview(wrap(pill("New effect", "plus") { [weak self] in self?.openEffectEditor(nil, true) }, 0, 42, 0, 0, 0, 0))
            r0.addArrangedSubview(wrap(pill("Import file", "import") { [weak self] in self?.pickFile(R_FX, [.json, .data]) }, 0, 42, 0, 0, 0, 0))
            put(p, r0, 42)
            text(p, "Each effect is a folder with effect.json and effect.glsl. Edit them in the full-screen editor, or put folders in the sdk/ folder of the app. See SDK.md.", C.DIM, 12)
            let custom = Registry.order.filter { !$0.builtin }
            if custom.isEmpty { text(p, "No custom effects yet.") }
            for d in custom {
                text(p, d.name + (d.bundled ? "  (bundled)" : ""), C.TEXT, 15, true)
                text(p, d.desc, C.DIM, 12)
                if Registry.errors[d.id] != nil { text(p, "Shader error. Open the editor and press Run to see the line.", C.RED, 12) }
                let r = hRow()
                r.distribution = .fillEqually
                r.spacing = 4
                r.addArrangedSubview(wrap(pill("Info") { [weak self] in self?.showEffectInfo(d, l) }, 0, 40, 0, 0, 0, 0))
                r.addArrangedSubview(wrap(pill(d.bundled ? "View" : "Edit") { [weak self] in self?.openEffectEditor(d.source) }, 0, 40, 0, 0, 0, 0))
                r.addArrangedSubview(wrap(pill("Export") { [weak self] in
                    guard let self = self else { return }
                    self.exportText(d.id + ".saikieffect.json", self.prettyJson(Registry.toJson(d)))
                }, 0, 40, 0, 0, 0, 0))
                if !d.bundled {
                    r.addArrangedSubview(wrap(pill("Delete", nil, C.CARD2, C.RED) { [weak self] in
                        guard let self = self else { return }
                        Registry.deleteCustom(d.id)
                        EffectThumbs.cache.removeValue(forKey: d.id)
                        self.refreshPanel()
                    }, 0, 40, 0, 0, 0, 0))
                }
                put(p, r, 40)
            }
        }

        /// Opens the full-screen SDK IDE (SdkIdeActivity on Android).
        func openEffectEditor(_ openPath: String? = nil, _ newEffect: Bool = false) {
            let ide = SdkIdeViewController()
            ide.openPath = openPath
            ide.newEffect = newEffect
            ide.onDone = { [weak self] in
                guard let self = self else { return }
                Registry.reloadSdk()
                for k in EffectThumbs.cache.keys where Registry.byId[k]?.builtin == false || k.hasPrefix("__orig:custom:") {
                    EffectThumbs.cache.removeValue(forKey: k)
                }
                EffectThumbs.generate(self, preview) { [weak self] in self?.refreshPanel() }
                self.refreshPanel(); self.render()
            }
            let nav = UINavigationController(rootViewController: ide)
            nav.isNavigationBarHidden = true
            nav.modalPresentationStyle = .fullScreen
            present(nav, animated: true)
        }

        func showCreateEffect() {
            let box = vStack()
            box.isLayoutMarginsRelativeArrangement = true
            box.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16)
            func field(_ hint: String, _ initText: String) -> UITextField {
                let e = makeField(initText)
                e.placeholder = hint
                e.font = sysFont(13)
                box.addArrangedSubview(wrap(e, 0, 40, 0, 4, 0, 4))
                return e
            }
            func area(_ hint: String, _ initText: String, _ lines: Int) -> UITextView {
                let e = UITextView()
                e.text = initText
                e.font = monoFont(13)
                e.textColor = argbToUIColor(C.TEXT)
                e.backgroundColor = argbToUIColor(C.CARD2)
                e.layer.cornerRadius = 8
                e.keyboardAppearance = .dark
                e.heightAnchor.constraint(equalToConstant: CGFloat(lines) * 22 + 16).isActive = true
                box.addArrangedSubview(wrap(e, 0, 0, 0, 4, 0, 4))
                return e
            }
            let name = field("Name", "My Effect")
            let desc = field("Description", "Mixes the image with grayscale.")
            let params = area("Parameters, one per line: name,label,min,max,default", "amount,Amount,0,1,1", 3)
            let code = area("GLSL code",
                            "vec4 effect(vec2 uv) {\n  vec4 c = src(uv);\n  return vec4(mix(c.rgb, vec3(luma(c.rgb)) * c.a, amount), c.a);\n}", 8)
            Dlg(self).setTitle("Create effect").setView(box).setPositiveButton("Create") { [weak self] _, _ in
                guard let self = self else { return }
                do {
                    let pa = JArr()
                    for line in (params.text ?? "").components(separatedBy: "\n") {
                        let f = line.split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) }
                        if f.count >= 5 {
                            guard let mn = Double(f[2]), let mx = Double(f[3]), let df = Double(f[4]) else {
                                throw NSError(domain: "saiki", code: 10,
                                              userInfo: [NSLocalizedDescriptionKey: "bad number"])
                            }
                            pa.put(JObj().put("name", f[0]).put("label", f[1]).put("min", mn).put("max", mx).put("def", df))
                        }
                    }
                    let o = JObj().put("name", name.text ?? "").put("description", desc.text ?? "")
                        .put("params", pa).put("code", code.text ?? "")
                    if let err = Registry.addCustom(o.toString()) {
                        self.toast(err)
                    } else {
                        self.toast("Effect created")
                        EffectThumbs.generate(self, self.preview) { [weak self] in self?.refreshPanel() }
                        self.refreshPanel()
                    }
                } catch { self.toast("Check the parameter lines") }
            }.setNegativeButton("Cancel", nil).show()
        }
}
