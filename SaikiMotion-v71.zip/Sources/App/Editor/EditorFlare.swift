// EditorFlare.swift — the full-screen Optical Flare editor.
//
// Layout (top → bottom): Cancel / title / Apply bar · LIVE preview (the real
// editor preview is moved up here while the editor is open, so you can drag
// the light and see exactly what renders) · tools row (animate the light,
// 3D chip) · tabs (Presets / Elements / Edit / Iris / Global) · scrolling panel.

import UIKit

extension EditorViewController {

    // ---------------------------------------------------------------- entry points

    /// The "Optical Flare" tool: adds a flare layer and opens the full-screen editor on Presets.
    func showFlareLibrary() {
        let l = addLayer(.FLARE)
        l.name = "Optical Flare \(l.id)"
        l.flare = Flare.builtin().first?.copy() ?? Flare.deflt()
        let asp = Float(Editor.project.w) / Float(Editor.project.h)
        l.track("x").base = -0.45 * asp
        l.track("y").base = 0.3
        flTab = 0
        openFlareEditor(l, isNew: true)
    }

    func addFlare(_ f: Flare, _ customize: Bool) {
        let l = addLayer(.FLARE)
        l.name = "Optical Flare \(l.id)"
        l.flare = f
        let asp = Float(Editor.project.w) / Float(Editor.project.h)
        l.track("x").base = -0.45 * asp
        l.track("y").base = 0.3
        if customize { openFlareEditor(l, isNew: true) } else { render(); refreshPanel() }
    }

    func openFlareEditor(_ l: Layer, isNew: Bool = false) {
        if flareOverlay != nil { return }
        if l.flare == nil { l.flare = Flare.deflt() }
        pushUndo()
        flareLayer = l
        flIsNew = isNew
        let b = JObj().put("flare", l.flare!.toJson())
        for d in Defs.flare { b.put(d.key, Double(l.track(d.key).base)) }
        b.put("opacity", Double(l.track("opacity").base))
        b.put("is3d", l.is3d)
        flareBackup = b
        if !isNew { flTab = 1 }
        flSel = 0
        Flare.loadUser()
        IrisDef.loadUser()
        buildFlareOverlay()
    }

    func closeFlareEditor(_ save: Bool) {
        stopFlareSweep()
        if let l = flareLayer, !save, let b = flareBackup {
            if flIsNew {
                Editor.scene.layers.removeAll { $0 === l }
                onSelect(-1)
            } else {
                if let fo = b.optJSONObject("flare") { l.flare = Flare.fromJson(fo) }
                for d in Defs.flare { l.track(d.key).base = b.optFloat(d.key, d.def) }
                l.track("opacity").base = b.optFloat("opacity", 1)
                l.is3d = b.optBool("is3d", l.is3d)
            }
        }
        // hand the live preview back to the editor
        if let parent = flareParent, let a = aspect {
            parent.addSubview(a)
            a.frame = parent.bounds
        }
        flareParent = nil
        flareOverlay?.removeFromSuperview()
        flareOverlay = nil; flareContent = nil; flareLayer = nil; flareTabs = nil
        render(); refreshAll()
    }

    // ---------------------------------------------------------------- light animation

    func toggleFlareSweep() {
        if flareDriver != nil { stopFlareSweep(); return }
        guard let l = flareLayer else { return }
        let asp = Float(Editor.project.w) / Float(Editor.project.h)
        flareSweepBase = (l.track("x").base, l.track("y").base)
        let d = FlareDriver()
        d.tick = { [weak self] t in
            guard let self = self, let l = self.flareLayer else { return }
            let tt = Float(t)
            l.track("x").base = asp * 0.85 * sin(tt * 0.8)
            l.track("y").base = 0.6 * sin(tt * 1.15 + 1.0)
            self.render()
        }
        flareDriver = d
        d.start()
        toast("Move the light with your finger or watch it drift")
    }

    func stopFlareSweep() {
        flareDriver?.stop()
        flareDriver = nil
        if let l = flareLayer, let b = flareSweepBase {
            l.track("x").base = b.0
            l.track("y").base = b.1
        }
        flareSweepBase = nil
        render()
    }

    // ---------------------------------------------------------------- overlay

    func buildFlareOverlay() {
        let ov = FlareEditorView(frame: screen.bounds)
        ov.backgroundColor = argbToUIColor(C.BG)
        ov.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        // give the bars a real size BEFORE adding autoresizing children: children added to a
        // zero-width parent were stretched later, which pushed Apply, the title and the hint
        // off the right edge of the screen
        ov.bar.frame = CGRect(x: 0, y: 0, width: ov.bounds.width, height: 54)
        ov.tools.frame = CGRect(x: 0, y: 0, width: ov.bounds.width, height: 50)
        ov.holder.frame = CGRect(x: 0, y: 0, width: ov.bounds.width, height: 200)

        // top bar
        ov.bar.backgroundColor = argbToUIColor(C.PANEL)
        let cancel = pill("Cancel") { [weak self] in self?.closeFlareEditor(false) }
        let apply = pill("Apply", "check", C.GREEN, C.ONDARK) { [weak self] in self?.closeFlareEditor(true) }
        cancel.frame = CGRect(x: 10, y: 7, width: 92, height: 40)
        cancel.autoresizingMask = [.flexibleRightMargin]
        apply.frame = CGRect(x: ov.bounds.width - 112, y: 7, width: 102, height: 40)
        apply.autoresizingMask = [.flexibleLeftMargin]
        let tt = UILabel(frame: CGRect(x: 110, y: 0, width: ov.bounds.width - 224, height: 54))
        tt.text = "Optical Flare"
        tt.textColor = argbToUIColor(C.TEXT)
        tt.font = boldFont(17)
        tt.textAlignment = .center
        tt.autoresizingMask = [.flexibleWidth]
        ov.bar.addSubview(cancel); ov.bar.addSubview(tt); ov.bar.addSubview(apply)

        // live preview: move the real preview up here
        ov.holder.backgroundColor = argbToUIColor(Int32(bitPattern: 0xFF161618))
        ov.holder.clipsToBounds = true
        flareParent = aspect.superview
        ov.holder.addSubview(aspect)
        aspect.frame = ov.holder.bounds
        aspect.autoresizingMask = [.flexibleWidth, .flexibleHeight]

        // tools row
        ov.tools.backgroundColor = argbToUIColor(C.PANEL)
        let anim = pill("Animate light", "play", C.CARD2, C.TEXT) { [weak self] in self?.toggleFlareSweep() }
        anim.frame = CGRect(x: 10, y: 5, width: 150, height: 40)
        let hint = UILabel(frame: CGRect(x: 170, y: 0, width: ov.bounds.width - 180, height: 50))
        hint.text = "Drag the light in the preview. Ghosts, spikes and glints react like a real lens."
        hint.textColor = argbToUIColor(C.DIM)
        hint.font = sysFont(11)
        hint.numberOfLines = 3
        hint.autoresizingMask = [.flexibleWidth]
        ov.tools.addSubview(anim); ov.tools.addSubview(hint)

        // tabs
        let tabs = TabBar(["Presets", "Elements", "Edit", "Iris", "Global"], flTab) { [weak self] i in
            guard let self = self else { return }
            self.flTab = i
            self.refreshFlare()
        }
        flareTabs = tabs
        ov.tabs = tabs

        // panel
        let sv = ov.scroll
        sv.keyboardDismissMode = .onDrag
        let content = vStack()
        content.isLayoutMarginsRelativeArrangement = true
        content.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 4, leading: 8, bottom: 40, trailing: 8)
        sv.addSubview(content)
        content.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            content.topAnchor.constraint(equalTo: sv.contentLayoutGuide.topAnchor),
            content.bottomAnchor.constraint(equalTo: sv.contentLayoutGuide.bottomAnchor),
            content.leadingAnchor.constraint(equalTo: sv.contentLayoutGuide.leadingAnchor),
            content.trailingAnchor.constraint(equalTo: sv.contentLayoutGuide.trailingAnchor),
            content.widthAnchor.constraint(equalTo: sv.frameLayoutGuide.widthAnchor)
        ])
        flareContent = content

        for v in [ov.holder, ov.scroll, ov.tools, tabs, ov.bar] as [UIView] { ov.addSubview(v) }
        flareOverlay = ov
        screen.addSubview(ov)
        ov.frame = screen.bounds
        ov.setNeedsLayout(); ov.layoutIfNeeded()
        refreshFlare()
        render()
    }

    func refreshFlare() {
        guard let l = flareLayer, let f = l.flare, let p = flareContent else { return }
        p.arrangedSubviews.forEach { $0.removeFromSuperview() }
        flareTabs?.sel = flTab
        flareTabs?.setNeedsDisplay()
        if flSel >= f.els.count { flSel = max(f.els.count - 1, 0) }
        switch flTab {
        case 0: flarePresets(p, l, f)
        case 1: flareElements(p, l, f)
        case 2: flareEditEl(p, l, f)
        case 3: flareIris(p, l, f)
        default: flareGlobal(p, l, f)
        }
    }

    // ---------------------------------------------------------------- presets

    func flarePresets(_ p: UIStackView, _ l: Layer, _ f: Flare) {
        let all = Flare.builtin() + Flare.user
        FlareThumbs.generate(preview, all) { }
        text(p, "Presets", C.GREEN, 14, true)
        var row: UIStackView? = nil
        for (i, pr) in all.enumerated() {
            if i % 3 == 0 {
                let r = hRow()
                r.distribution = .fillEqually
                p.addArrangedSubview(r)
                row = r
            }
            let th = FlareThumb(pr.sig(), pr.name)
            th.onClick = { [weak self] in
                guard let self = self else { return }
                l.flare = pr.copy()
                self.flSel = 0
                self.render(); self.refreshFlare()
            }
            put(row!, th, 92, 3, 3)
        }
        let rem = all.count % 3
        if rem != 0, let r = row { for _ in 0..<(3 - rem) { r.addArrangedSubview(UIView()) } }
        put(p, pill("Save as my preset", "plus") { [weak self] in
            guard let self = self else { return }
            let et = UITextField(frame: CGRect(x: 0, y: 0, width: 240, height: 40))
            et.placeholder = "Preset name"
            et.text = f.name
            et.textColor = argbToUIColor(C.TEXT)
            _ = Dlg(self).setTitle("Save preset").setView(et).setPositiveButton("Save") { [weak self] _, _ in
                guard let self = self else { return }
                let c = f.copy()
                let nm = et.text?.trimmingCharacters(in: .whitespaces) ?? ""
                c.name = nm.isEmpty ? "My flare \(Flare.user.count + 1)" : nm
                Flare.user.append(c)
                Flare.saveUser()
                self.refreshFlare()
            }.setNegativeButton("Cancel", nil).show()
        }, 46, 10, 4)
        text(p, "Tap a preset to load it, then fine-tune it in Elements, Edit and Iris.", C.DIM, 12)
    }

    // ---------------------------------------------------------------- elements

    func flareElements(_ p: UIStackView, _ l: Layer, _ f: Flare) {
        put(p, pill(flBrowse ? "Close element browser" : "Add element", flBrowse ? "check" : "plus", C.GREEN, C.ONDARK) { [weak self] in
            self?.flBrowse.toggle(); self?.refreshFlare()
        }, 46)
        if flBrowse { flareElementBrowser(p, f) }
        if f.els.isEmpty { text(p, "No elements. Add a Glow to start.", C.DIM, 13) }
        for (i, e) in f.els.enumerated() {
            let row = hRow()
            row.backgroundColor = argbToUIColor(i == flSel ? Int32(bitPattern: 0xFF2A2A30) : C.CARD)
            row.layer.cornerRadius = 10
            row.isLayoutMarginsRelativeArrangement = true
            row.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 4, bottom: 0, trailing: 2)
            let eye = IconView(e.enabled ? "eye" : "eye_off", e.enabled ? Int32(bitPattern: 0xFFFFFFFF) : C.DIM, 20)
            eye.onClick = { [weak self] in e.enabled = !e.enabled; self?.refreshFlare(); self?.render() }
            row.addArrangedSubview(wrap(eye, 40, 48, 0, 0, 0, 0))
            let sw = UIView()
            sw.backgroundColor = argbToUIColor(e.color | Int32(bitPattern: 0xFF000000))
            sw.layer.cornerRadius = 4
            row.addArrangedSubview(wrap(sw, 10, 26, 0, 0, 0, 0))
            let tv = UILabel()
            tv.text = "  " + e.label() + "  (" + String(format: "%.2f", e.pos) + ")"
            tv.textColor = argbToUIColor(C.TEXT)
            tv.font = sysFont(14)
            tv.numberOfLines = 1
            tv.setContentHuggingPriority(UILayoutPriority(1), for: .horizontal)
            let tap = TapView()
            tap.addSubview(tv)
            tv.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                tv.leadingAnchor.constraint(equalTo: tap.leadingAnchor),
                tv.trailingAnchor.constraint(equalTo: tap.trailingAnchor),
                tv.centerYAnchor.constraint(equalTo: tap.centerYAnchor)
            ])
            tap.onClick = { [weak self] in
                guard let self = self else { return }
                self.flSel = i; self.flTab = e.isIris ? 3 : 2
                self.refreshFlare()
            }
            row.addArrangedSubview(tap)
            func btn(_ icon: String, _ tint: Int32, _ click: @escaping () -> Void) {
                let b = IconView(icon, tint, 18)
                b.onClick = click
                row.addArrangedSubview(wrap(b, 34, 48, 0, 0, 0, 0))
            }
            btn("chev_up", Int32(bitPattern: 0xFFFFFFFF)) { [weak self] in
                guard let self = self else { return }
                if i > 0 { let e2 = f.els.remove(at: i); f.els.insert(e2, at: i - 1); self.flSel = i - 1; self.refreshFlare(); self.render() }
            }
            btn("chev_down", Int32(bitPattern: 0xFFFFFFFF)) { [weak self] in
                guard let self = self else { return }
                if i < f.els.count - 1 { let e2 = f.els.remove(at: i); f.els.insert(e2, at: i + 1); self.flSel = i + 1; self.refreshFlare(); self.render() }
            }
            btn("dup", Int32(bitPattern: 0xFFFFFFFF)) { [weak self] in
                guard let self = self, f.els.count < FlareEl.MAX else { return }
                f.els.insert(e.copy(), at: i + 1)
                self.flSel = i + 1
                self.refreshFlare(); self.render()
            }
            btn("trash", C.RED) { [weak self] in
                guard let self = self else { return }
                f.els.remove(at: i)
                self.refreshFlare(); self.render()
            }
            put(p, row, 0, 3, 3)
        }
        text(p, "Position 0 is the light itself, 1 is the screen center and 2 is the opposite side. Tap an element to edit it.", C.DIM, 12)
    }

    func flareElementBrowser(_ p: UIStackView, _ f: Flare) {
        let all = FlareThumbs.elementPreviews()
        FlareThumbs.generate(preview, all) { }
        text(p, "Tap an element to add it to the flare", C.DIM, 12)
        var row: UIStackView? = nil
        for (i, pr) in all.enumerated() {
            if i % 3 == 0 {
                let r = hRow(); r.distribution = .fillEqually
                p.addArrangedSubview(r); row = r
            }
            let th = FlareThumb(pr.sig(), pr.name)
            th.onClick = { [weak self] in
                guard let self = self, let ff = self.flareLayer?.flare else { return }
                if ff.els.count >= FlareEl.MAX { self.toast("A flare can hold \(FlareEl.MAX) elements"); return }
                let e = FlareEl.make(i)
                ff.els.append(e)
                self.flSel = ff.els.count - 1
                self.flBrowse = false
                self.flTab = e.isIris ? 3 : 2
                self.refreshFlare(); self.render()
            }
            put(row!, th, 92, 3, 3)
        }
        let rem = all.count % 3
        if rem != 0, let r = row { for _ in 0..<(3 - rem) { r.addArrangedSubview(UIView()) } }
    }

    // ---------------------------------------------------------------- edit element

    func flareEditEl(_ p: UIStackView, _ l: Layer, _ f: Flare) {
        if f.els.isEmpty { text(p, "Add an element in the Elements tab first.", C.DIM, 13); return }
        let e = f.els[flSel]
        text(p, "Editing: " + e.label() + "  (" + String(flSel + 1) + " of " + String(f.els.count) + ")", C.GREEN, 14, true)
        p.addArrangedSubview(chipRow(FlareEl.TYPES, e.type) { [weak self] i in
            guard let self = self else { return }
            let old = e.type
            e.type = i
            if i == 13 && old != 13 { e.sides = max(e.sides, 3) }
            self.refreshFlare(); self.render()
        })
        let t = e.type
        text(p, "Color of this element", C.GREEN, 13, true)
        addColorRow(p, e.color) { [weak self] c in e.color = c; self?.render() }
        addPlain(p, "Position on axis", -1, 3, e.pos, 2) { e.pos = $0; self.render() }
        addPlain(p, "Size", 0.01, 2.5, e.size, 3) { e.size = $0; self.render() }
        addPlain(p, "Brightness", 0, 4, e.bright, 2) { e.bright = $0; self.render() }
        if [0, 1, 5, 9, 13, 14, 2].contains(t) {
            addPlain(p, t == 9 || t == 2 ? "Length" : "Stretch (width / height)", 0.1, 20, e.stretch, 2) { e.stretch = $0; self.render() }
        }
        addPlain(p, "Rotation", -180, 180, e.rot, 0) { e.rot = $0; self.render() }
        if t != 6 { addPlain(p, "Softness", 0, 1, e.soft, 2) { e.soft = $0; self.render() } }
        if [1, 2, 4, 5, 8, 9, 11, 14, 15].contains(t) {
            let nm = t == 4 ? "Outline thickness (1 = filled)" : (t == 11 ? "Band width" : "Thickness")
            addPlain(p, nm, 0.01, 1, e.thick, 2) { e.thick = $0; self.render() }
        }
        if [3, 7, 10, 12].contains(t) { addPlain(p, "Rays", 2, 40, Float(e.rays), 0) { e.rays = Int($0); self.render() } }
        if [7, 10, 12].contains(t) { addPlain(p, t == 12 ? "Shimmer amount" : "Random ray length", 0, 1, e.noise, 2) { e.noise = $0; self.render() } }
        if [1, 4, 5, 8, 11, 13, 14, 15].contains(t) { addPlain(p, "Rainbow fringe", 0, 1, e.chroma, 2) { e.chroma = $0; self.render() } }
        if t == 15 { addPlain(p, "Arc length", 0.05, 1, e.spread, 2) { e.spread = $0; self.render() } }
        if t == 14 {
            addPlain(p, "Copies", 2, 8, Float(e.rays), 0) { e.rays = Int($0); self.render() }
            addPlain(p, "Spacing along the axis", 0.05, 1, e.spread, 2) { e.spread = $0; self.render() }
            addPlain(p, "Size variation", 0, 1, e.noise, 2) { e.noise = $0; self.render() }
        }
        if e.isIris {
            addPlain(p, "Blades", 3, 16, Float(e.sides), 0) { e.sides = Int($0); self.render() }
            put(p, pill("Open iris browser", "edit", C.CARD2, C.TEXT) { [weak self] in
                self?.flTab = 3; self?.refreshFlare()
            }, 44, 6, 4)
        }
        addPlain(p, "Spin when the light moves", -1, 1, e.spin, 2) { e.spin = $0; self.render() }
        let fo = SwitchRow()
        fo.label = "Turn with the flare axis"
        fo.on = e.follow
        fo.onToggle = { e.follow = $0; self.render() }
        put(p, fo, 52)
    }

    // ---------------------------------------------------------------- iris browser

    func flareIris(_ p: UIStackView, _ l: Layer, _ f: Flare) {
        text(p, "Procedural iris browser", C.GREEN, 14, true)
        guard !f.els.isEmpty, f.els.indices.contains(flSel), f.els[flSel].isIris else {
            text(p, "Pick an Iris, Multi iris, Polygon or Ring polygon element, or add a new iris.", C.DIM, 13)
            put(p, pill("Add iris element", "plus", C.GREEN, C.ONDARK) { [weak self] in
                guard let self = self, let ff = self.flareLayer?.flare, ff.els.count < FlareEl.MAX else { return }
                ff.els.append(FlareEl.make(13))
                self.flSel = ff.els.count - 1
                self.refreshFlare(); self.render()
            }, 46, 8, 4)
            return
        }
        let e = f.els[flSel]
        let cur = IrisDef(e)

        let pv = IrisPreview()
        pv.def = cur
        pv.tint = argbToUIColor(e.color | Int32(bitPattern: 0xFF000000))
        put(p, pv, 130, 4, 6)

        let nBuiltin = IrisDef.builtin().count
        let all = IrisDef.builtin() + IrisDef.user
        var cats: [String] = []
        for d in all where !cats.contains(d.cat) { cats.append(d.cat) }
        for cat in cats {
            text(p, cat, C.DIM, 12, true)
            var row: UIStackView? = nil
            var n = 0
            for (i, d) in all.enumerated() where d.cat == cat {
                if n % 4 == 0 {
                    let r = hRow(); r.distribution = .fillEqually
                    p.addArrangedSubview(r); row = r
                }
                n += 1
                let th = IrisThumb(d)
                th.picked = (d.sides == e.sides && abs(d.round - e.round) < 0.001 && abs(d.star - e.star) < 0.001 && abs(d.curve - e.curve) < 0.001 && abs(d.thick - e.thick) < 0.001)
                th.onClick = { [weak self] in
                    guard let self = self else { return }
                    d.apply(to: e)
                    if !e.isIris { e.type = 13 }
                    self.render(); self.refreshFlare()
                }
                if i >= nBuiltin {
                    th.onLongPress = { [weak self] in
                        guard let self = self else { return }
                        _ = Dlg(self).setTitle("Delete \"\(d.name)\"?").setPositiveButton("Delete") { [weak self] _, _ in
                            let k = i - nBuiltin
                            if IrisDef.user.indices.contains(k) { IrisDef.user.remove(at: k); IrisDef.saveUser() }
                            self?.refreshFlare()
                        }.setNegativeButton("Cancel", nil).show()
                    }
                }
                put(row!, th, 78, 3, 3)
            }
            if let r = row { for _ in 0..<((4 - n % 4) % 4) { r.addArrangedSubview(UIView()) } }
        }

        let btns = hRow(); btns.distribution = .fillEqually; btns.spacing = 8
        btns.addArrangedSubview(pill("Surprise me", "plus", C.CARD2, C.TEXT) { [weak self] in
            guard let self = self else { return }
            IrisDef.random().apply(to: e)
            if !e.isIris { e.type = 13 }
            self.render(); self.refreshFlare()
        })
        btns.addArrangedSubview(pill("Save iris", "plus", C.GREEN, C.ONDARK) { [weak self] in
            guard let self = self else { return }
            let et = UITextField(frame: CGRect(x: 0, y: 0, width: 240, height: 40))
            et.placeholder = "Iris name"
            et.textColor = argbToUIColor(C.TEXT)
            _ = Dlg(self).setTitle("Save iris").setView(et).setPositiveButton("Save") { [weak self] _, _ in
                var d = IrisDef(e)
                let nm = et.text?.trimmingCharacters(in: .whitespaces) ?? ""
                d.name = nm.isEmpty ? "My iris \(IrisDef.user.count + 1)" : nm
                IrisDef.user.append(d)
                IrisDef.saveUser()
                self?.refreshFlare()
            }.setNegativeButton("Cancel", nil).show()
        })
        put(p, btns, 46, 6, 6)

        addPlain(p, "Blades", 3, 16, Float(e.sides), 0) { [weak self] in e.sides = Int($0); pv.def = IrisDef(e); self?.render() }
        addPlain(p, "Roundness (1 = circle)", 0, 1, e.round, 2) { [weak self] in e.round = $0; pv.def = IrisDef(e); self?.render() }
        addPlain(p, "Star depth", 0, 1, e.star, 2) { [weak self] in e.star = $0; pv.def = IrisDef(e); self?.render() }
        addPlain(p, "Edge curve (− scallop / + bulge)", -1, 1, e.curve, 2) { [weak self] in e.curve = $0; pv.def = IrisDef(e); self?.render() }
        addPlain(p, "Thickness (1 = filled)", 0.05, 1, e.thick, 2) { [weak self] in e.thick = $0; pv.def = IrisDef(e); self?.render() }
        addPlain(p, "Edge softness", 0, 1, e.soft, 2) { [weak self] in e.soft = $0; pv.def = IrisDef(e); self?.render() }
        addPlain(p, "Edge brightness", 0, 1, e.grad, 2) { [weak self] in e.grad = $0; pv.def = IrisDef(e); self?.render() }
        addPlain(p, "Rainbow fringe", 0, 1, e.chroma, 2) { [weak self] in e.chroma = $0; pv.def = IrisDef(e); self?.render() }
        text(p, "Long-press one of your saved irises to delete it. Position, size, color and brightness are in the Edit tab.", C.DIM, 12)
    }

    // ---------------------------------------------------------------- global

    func flareGlobal(_ p: UIStackView, _ l: Layer, _ f: Flare) {
        text(p, "Whole flare", C.GREEN, 14, true)
        let opTr = l.track("opacity")
        addPlain(p, "Layer opacity", 0, 1, opTr.base, 2) { [weak self] in opTr.base = $0; self?.render() }
        text(p, "Tint (multiplies every element)", C.DIM, 12)
        addColorRow(p, f.tint) { [weak self] c in f.tint = c; self?.render() }
        text(p, "Set one color on every element", C.DIM, 12)
        addColorRow(p, f.els.first?.color ?? Int32(bitPattern: 0xFFFFFFFF)) { [weak self] c in
            for el in f.els { el.color = c }
            self?.render()
        }
        put(p, pill("Reset element colors to white") { [weak self] in
            for el in f.els { el.color = Int32(bitPattern: 0xFFFFFFFF) }
            self?.render(); self?.refreshFlare()
        }, 44, 4, 4)
        for d in Defs.flare {
            let tr = l.track(d.key)
            addPlain(p, d.label, d.min, d.max, tr.base, d.dec) { [weak self] v in
                tr.base = v
                self?.render()
            }
            if !tr.keys.isEmpty { text(p, d.label + " is keyframed. Edit it in the layer's Edit panel.", C.AMBER, 11) }
        }
        addPlain(p, "Rays / spikes strength (0 = no rays)", 0, 1.5, f.rayAmt, 2) { [weak self] in f.rayAmt = $0; self?.render() }
        text(p, "Life", C.GREEN, 14, true)
        addPlain(p, "Flicker", 0, 1, f.flicker, 2) { [weak self] in f.flicker = $0; self?.render() }
        addPlain(p, "Shimmer / flicker speed", 0, 4, f.speed, 2) { [weak self] in f.speed = $0; self?.render() }
        text(p, "3D and camera", C.GREEN, 14, true)
        addPlain(p, "Size change with distance", 0, 1, f.depthScale, 2) { [weak self] in f.depthScale = $0; self?.render() }
        addPlain(p, "Fade when the light leaves the screen", 0.01, 1.5, f.edgeFade, 2) { [weak self] in f.edgeFade = $0; self?.render() }
        let d3 = SwitchRow()
        d3.label = "3D layer (follows the camera)"
        d3.on = l.is3d
        d3.onToggle = { [weak self] _ in
            guard let self = self else { return }
            l.is3d = !l.is3d
            self.render()
            self.refreshFlare()
        }
        put(p, d3, 52)
        text(p, "With 3D on, the light is projected through the camera: it shrinks with distance, slides with camera moves and vanishes behind the camera. Opacity and blend work like any layer.", C.DIM, 12)
    }
}
