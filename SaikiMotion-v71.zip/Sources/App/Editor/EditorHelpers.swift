// EditorHelpers.swift — shared editor helpers: field binding, fonts,
// Kotlin-style string helpers and the pretty JSON writer.

import UIKit
import Foundation

// Key used to attach EditWatcher targets to their UITextFields (UIControl does NOT retain its
// targets; associating the watcher keeps it alive exactly as long as the field).
private var EditorFieldWatchKey: UInt8 = 0

/// TextWatcher replacement for UITextField editing-changed events.
private final class EditWatcher: NSObject {
    private let f: (String) -> Void
    init(_ f: @escaping (String) -> Void) { self.f = f }
    @objc func change(_ t: UITextField) { f(t.text ?? "") }
}


extension EditorViewController {
    // ================================================================ private string/number helpers

    /// Attaches a TextWatcher-equivalent target to a UITextField. UIControl does not retain its
    /// targets, so the watcher is associated to the field (lifetime == field lifetime).
    func bind(_ field: UIControl, _ handler: @escaping (String) -> Void) {
        let w = EditWatcher(handler)
        objc_setAssociatedObject(field, &EditorFieldWatchKey, w, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        field.addTarget(w, action: #selector(EditWatcher.change(_:)), for: .editingChanged)
    }

    func makeField(_ text: String) -> UITextField {
        let f = UITextField()
        f.text = text
        f.textColor = argbToUIColor(C.TEXT)
        f.font = sysFont(16)
        f.backgroundColor = argbToUIColor(C.CARD2)
        f.layer.cornerRadius = 10
        f.keyboardAppearance = .dark
        f.autocorrectionType = .no
        f.returnKeyType = .done
        f.addTarget(f, action: #selector(UIResponder.resignFirstResponder), for: .primaryActionTriggered)
        let bar = UIToolbar(frame: CGRect(x: 0, y: 0, width: 320, height: 44))
        bar.barStyle = .black
        bar.items = [UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil),
                     UIBarButtonItem(barButtonSystemItem: .done, target: f, action: #selector(UIResponder.resignFirstResponder))]
        f.inputAccessoryView = bar
        f.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: 1))
        f.leftViewMode = .always
        f.rightView = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: 1))
        f.rightViewMode = .always
        return f
    }

    func monoFont(_ size: CGFloat) -> UIFont {
        UIFont(name: "Menlo", size: size) ?? .monospacedSystemFont(ofSize: size, weight: .regular)
    }

    /// Monospaced digits for the timecode readout (top bar) so it never jiggles.
    func monoTimeFont(_ size: CGFloat) -> UIFont {
        let base = monoFont(size)
        guard let desc = base.fontDescriptor.withDesign(.monospaced) else { return base }
        return UIFont(descriptor: desc, size: size)
    }

    /// Kotlin Float.toInt(): truncate toward zero, NaN → 0, saturate at Int32 bounds.
    func ktInt(_ v: Float) -> Int {
        if v.isNaN { return 0 }
        if v >= 2147483520 { return Int(Int32.max) }
        if v <= -2147483520 { return Int(Int32.min) }
        return Int(v)
    }

    func cap(_ s: String) -> String {
        guard let f = s.first else { return s }
        return String(f).uppercased() + String(s.dropFirst())
    }

    /// Kotlin String.substringAfter — returns the whole string when the separator is missing.
    func afterFirst(_ s: String, _ sep: Character) -> String {
        if let i = s.firstIndex(of: sep) { return String(s[s.index(after: i)...]) }
        return s
    }

    func afterLast(_ s: String, _ sep: Character) -> String {
        if let i = s.lastIndex(of: sep) { return String(s[s.index(after: i)...]) }
        return s
    }

    func beforeLast(_ s: String, _ sep: Character) -> String {
        if let i = s.lastIndex(of: sep) { return String(s[..<i]) }
        return s
    }

    /// name.replace(Regex("[^A-Za-z0-9]"), "_")
    func alnum(_ s: String) -> String {
        String(s.map { c in
            (c.isASCII && c.isLetter) || (c.isASCII && c.isNumber) ? c : "_"
        })
    }

    /// org.json toString(indent) equivalent used for exported effect/preset files
    /// (Core/JSON.swift only ships the compact writer) — PORT NOTE.
    func prettyJson(_ v: Any, _ indent: Int = 0) -> String {
        let p = String(repeating: " ", count: indent)
        let p2 = String(repeating: " ", count: indent + 2)
        if let o = v as? JObj {
            if o.dict.isEmpty { return "{}" }
            var s = "{\n"
            let ks = o.keys
            for (i, k) in ks.enumerated() {
                s += p2 + "\"" + k + "\": " + prettyJson(o.dict[k]!, indent + 2)
                s += i < ks.count - 1 ? ",\n" : "\n"
            }
            return s + p + "}"
        }
        if let a = v as? JArr {
            if a.items.isEmpty { return "[]" }
            var s = "[\n"
            for (i, item) in a.items.enumerated() {
                s += p2 + prettyJson(item, indent + 2)
                s += i < a.items.count - 1 ? ",\n" : "\n"
            }
            return s + p + "]"
        }
        if let s = v as? String {
            var out = "\""
            for ch in s.unicodeScalars {
                switch ch {
                case "\"": out += "\\\""
                case "\\": out += "\\\\"
                case "\n": out += "\\n"
                case "\r": out += "\\r"
                case "\t": out += "\\t"
                default: out.unicodeScalars.append(ch)
                }
            }
            return out + "\""
        }
        if let b = v as? Bool { return b ? "true" : "false" }
        if let i = v as? Int64 { return String(i) }
        if let i = v as? Int32 { return String(i) }
        if let i = v as? Int { return String(i) }
        if let d = v as? Double { return JSONWriter.numberToString(d) }
        if let f = v as? Float { return JSONWriter.numberToString(Double(f)) }
        return "null"
    }
}
