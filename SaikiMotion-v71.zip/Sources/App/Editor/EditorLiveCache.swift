// EditorLiveCache.swift — idle "live render" cache for the editor (After Effects style).
//
// While nothing is being touched, the editor renders the frame at the playhead — then the
// next uncached frame after it, wrapping round — into the on-disk FrameCache
// (<Caches>/SaikiMotion/frames/…). The timeline shows cached ranges as a green bar and
// playback reads cached frames instead of re-running the GL pipeline, so scenes with many
// layers play smoothly. Any edit makes the cache stale; the cache can be cleared from
// Scene setup → Live render cache or Home → Extras.
//
// Frames are rendered one at a time on the main thread with the preview's own renderer
// (no second set of textures in memory), at most about 40% of the time, and it pauses
// at once when you touch anything, play, open a dialog, or the system warns about memory.

import UIKit

extension EditorViewController {

    func startLiveCache() {
        stopLiveCache()
        let t = Timer(timeInterval: 0.06, repeats: true) { [weak self] _ in self?.liveTick() }
        RunLoop.main.add(t, forMode: .common)
        liveTimer = t
        NotificationCenter.default.addObserver(self, selector: #selector(liveMemoryWarning),
                                               name: UIApplication.didReceiveMemoryWarningNotification,
                                               object: nil)
    }

    func stopLiveCache() {
        liveTimer?.invalidate()
        liveTimer = nil
        NotificationCenter.default.removeObserver(self, name: UIApplication.didReceiveMemoryWarningNotification,
                                                  object: nil)
    }

    @objc func liveMemoryWarning() {
        FrameCache.suspended = true       // stop rendering ahead until the editor is reopened
        preview.trimMemory()
    }

    /// Pre-render button on a selected group: on → bake its frames (a few per tick, never
    /// freezing the UI); off → drop them. Any later change to the group re-bakes it.
    func togglePreRender(_ g: Layer) {
        guard PreRender.enabled else {
            toast("Pre-render is off in Scene setup → Pre-render")
            return
        }
        pushUndo()
        g.prerender.toggle()
        if g.prerender {
            FrameCache.bump()
            refreshTitle()
            let vc = PreRenderProgressViewController(
                group: g, project: Editor.project, scene: Editor.scene, quality: preview.quality,
                bake: { [weak self] grp, idx in self?.preview.preRenderFrame(grp, idx: idx) ?? false },
                onDone: { [weak self] ok in
                    guard let self = self else { return }
                    if !ok {          // cancelled or failed: back to a normal live group
                        g.prerender = false
                        PreRender.clear(Editor.project.id, group: g.id)
                        FrameCache.bump()
                        self.toast("Pre-render cancelled")
                    } else {
                        self.toast("Pre-render ready")
                    }
                    self.refreshTitle()
                    self.render()
                })
            vc.modalPresentationStyle = .overFullScreen
            present(vc, animated: true)
            return
        } else {
            PreRender.clear(Editor.project.id, group: g.id)
            toast("Pre-render off")
        }
        FrameCache.bump()
        refreshTitle()
        render()
    }

    /// Chip on the preview: orange while frames bake, green when every pre-rendered group is baked.
    func updatePreBadge() {
        guard let b = preBadge else { return }
        // only while a pre-rendered group is selected; leaving the group hides the tag
        var gs: [Layer] = []
        if let sel = selected(), sel.type == .GROUP, sel.prerender, PreRender.enabled { gs = [sel] }
        guard !gs.isEmpty else { b.isHidden = true; return }
        let size = SceneRenderer.size(Editor.project, quality: preview.quality)
        var done = 0, total = 0
        for g in gs {
            let p = PreRender.progress(g, project: Editor.project, scene: Editor.scene, size: size)
            done += p.0; total += p.1
        }
        let ready = done >= total
        b.text = ready ? " PRE-RENDERED ✓ " : " PRE-RENDER \(done)/\(total) "
        b.backgroundColor = argbToUIColor(Int32(bitPattern: ready ? 0xFF3DDC84 : 0xFF4DA3FF))
        b.isHidden = false
    }

    /// Bakes one missing frame of a pre-rendered group. Returns true while work remains.
    func preBakeStep() -> Bool {
        guard PreRender.enabled, !FrameCache.suspended, !playing, view.window != nil,
              navigationController?.topViewController === self, presentedViewController == nil else { return false }
        let groups = PreRender.groups(in: Editor.scene)
        guard !groups.isEmpty else { preBurst = false; return false }
        let now = CFAbsoluteTimeGetCurrent()
        if now - lastActivity < (preBurst ? 0.15 : 0.6) { return true }
        if now < preNextAt { return true }
        let size = SceneRenderer.size(Editor.project, quality: preview.quality)
        guard size.0 > 1 else { return false }
        for g in groups {
            guard let idx = PreRender.nextMissing(g, project: Editor.project, scene: Editor.scene,
                                                  size: size, from: Editor.time) else { continue }
            PreRender.purgeStaleOnce(Editor.project.id, g.id,
                                     keep: PreRender.signature(g, project: Editor.project, scene: Editor.scene))
            let t0 = CACurrentMediaTime()
            let ok = preview.preRenderFrame(g, idx: idx)
            let dt = CACurrentMediaTime() - t0
            preNextAt = CFAbsoluteTimeGetCurrent() + (ok ? max(0.01, dt * (preBurst ? 0.3 : 1.2)) : 1.0)
            let (done, total) = PreRender.progress(g, project: Editor.project, scene: Editor.scene, size: size)
            subView.text = done < total ? "Pre-render \(done)/\(total)" : "Pre-render ready"
            updatePreBadge()
            if done >= total { preBurst = false; timeline.setNeedsDisplay() }
            return true
        }
        preBurst = false
        return false
    }

    func liveTick() {
        if preBakeStep() { return }
        guard FrameCache.enabled, !FrameCache.suspended, !FrameCache.liveFull, !playing,
              view.window != nil, navigationController?.topViewController === self,
              presentedViewController == nil else { return }
        let now = CFAbsoluteTimeGetCurrent()
        if now - lastActivity < 0.6 || now < liveNextAt { return }
        let k = preview.cacheKey
        guard k.0 > 1, k.1 > 1 else { return }
        guard let t = FrameCache.nextUncached(from: Editor.time, duration: Editor.scene.duration,
                                              Editor.project.id, k.0, k.1, k.2) else {
            if liveBusy { liveBusy = false; timeline.setNeedsDisplay() }
            return
        }
        liveBusy = true
        let t0 = CACurrentMediaTime()
        let ok = preview.cacheFrame(at: t)
        let dt = CACurrentMediaTime() - t0
        liveNextAt = CFAbsoluteTimeGetCurrent() + (ok ? max(0.02, dt * 1.5) : 1.0)
        if now - lastTimelineRefresh > 0.3 {
            lastTimelineRefresh = now
            timeline.setNeedsDisplay()
        }
    }
}
