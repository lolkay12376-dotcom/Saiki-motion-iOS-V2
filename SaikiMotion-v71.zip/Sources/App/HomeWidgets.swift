// HomeWidgets.swift — home-screen widgets: the five-tab bar button + its
// icons, the big action buttons and the segmented pills of the creation sheet.

import UIKit

// MARK: - home tab bar button ---------------------------------------------------------

/// One bottom-bar item: custom icon above an uppercase letter-spaced label.
/// Orange when selected, gray when not — the original's five-tab bar.
/// (TapView is the UI kit's closure-tappable view — the same mechanism the
/// original used everywhere.)
final class HomeTabButton: TapView {

    var icon: String = "" { didSet { iconView.name = icon; iconView.setNeedsDisplay() } }
    var on = false {
        didSet {
            iconView.color = on ? C.GREEN : C.DIM
            iconView.setNeedsDisplay()
            label.textColor = argbToUIColor(on ? C.GREEN : C.DIM)
        }
    }
    var tapped: (() -> Void)?

    private let iconView = TabIcon()
    private let label = UILabel()

    init() {
        super.init(frame: .zero)
        onClick = { [weak self] in self?.tapped?() }
        iconView.translatesAutoresizingMaskIntoConstraints = false
        addSubview(iconView)
        label.font = .systemFont(ofSize: 9, weight: .semibold)
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        addSubview(label)

        NSLayoutConstraint.activate([
            iconView.centerXAnchor.constraint(equalTo: centerXAnchor),
            iconView.topAnchor.constraint(equalTo: topAnchor, constant: 7),
            iconView.widthAnchor.constraint(equalToConstant: 24),
            iconView.heightAnchor.constraint(equalToConstant: 24),
            label.topAnchor.constraint(equalTo: iconView.bottomAnchor, constant: 3),
            label.centerXAnchor.constraint(equalTo: centerXAnchor),
            label.leadingAnchor.constraint(greaterThanOrEqualTo: leadingAnchor, constant: 2),
            label.trailingAnchor.constraint(lessThanOrEqualTo: trailingAnchor, constant: -2),
        ])
    }

    func setLabel(_ a: NSAttributedString) {
        label.attributedText = a
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.8
        setNeedsLayout()
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

/// The five tab icons, drawn with CGContext in the same stroke style as the
/// editor's icon kit (person / film frame / sparkles / two people / grid with +).
final class TabIcon: UIView {

    var color: Int32 = C.DIM
    var name: String = ""

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let s = min(rect.width, rect.height)
        c.saveGState()
        c.translateBy(x: rect.midX - s / 2, y: rect.midY - s / 2)
        c.scaleBy(x: s / 24, y: s / 24)
        c.setStrokeColor(argbToUIColor(color).cgColor)
        c.setFillColor(argbToUIColor(color).cgColor)
        c.setLineWidth(1.8)
        c.setLineCap(.round)
        c.setLineJoin(.round)

        func star(_ cx: CGFloat, _ cy: CGFloat, _ r: CGFloat) {
            let p = UIBezierPath()
            p.move(to: CGPoint(x: cx, y: cy - r))
            p.addQuadCurve(to: CGPoint(x: cx + r, y: cy), controlPoint: CGPoint(x: cx + r * 0.18, y: cy - r * 0.18))
            p.addQuadCurve(to: CGPoint(x: cx, y: cy + r), controlPoint: CGPoint(x: cx + r * 0.18, y: cy + r * 0.18))
            p.addQuadCurve(to: CGPoint(x: cx - r, y: cy), controlPoint: CGPoint(x: cx - r * 0.18, y: cy + r * 0.18))
            p.addQuadCurve(to: CGPoint(x: cx, y: cy - r), controlPoint: CGPoint(x: cx - r * 0.18, y: cy - r * 0.18))
            p.close()
            c.addPath(p.cgPath)
            c.fillPath()
        }

        switch name {
        case "account":
            c.strokeEllipse(in: CGRect(x: 8.4, y: 3.6, width: 7.2, height: 7.2))
            let body = UIBezierPath()
            body.addArc(withCenter: CGPoint(x: 12, y: 21), radius: 8.4,
                        startAngle: .pi, endAngle: 0, clockwise: true)
            c.addPath(body.cgPath)
            c.strokePath()
        case "film":
            let r = UIBezierPath(roundedRect: CGRect(x: 3.5, y: 4.5, width: 17, height: 15),
                                 cornerRadius: 2.5)
            c.addPath(r.cgPath)
            c.strokePath()
            let inner = UIBezierPath(roundedRect: CGRect(x: 8, y: 7.5, width: 8, height: 9),
                                     cornerRadius: 1.5)
            c.addPath(inner.cgPath)
            c.strokePath()
            for y in [CGFloat(7), CGFloat(13)] {
                c.fill(CGRect(x: 5.4, y: y, width: 1.6, height: 2.6))
                c.fill(CGRect(x: 17, y: y, width: 1.6, height: 2.6))
            }
        case "sparkle_tab":
            star(10, 10, 6.5)
            star(17, 16.5, 3.6)
            c.setLineWidth(1.6)
            let plus = UIBezierPath()
            plus.move(to: CGPoint(x: 17.5, y: 6.5))
            plus.addLine(to: CGPoint(x: 21.5, y: 6.5))
            plus.move(to: CGPoint(x: 19.5, y: 4.5))
            plus.addLine(to: CGPoint(x: 19.5, y: 8.5))
            c.addPath(plus.cgPath)
            c.strokePath()
        case "people":
            c.setLineWidth(1.6)
            c.strokeEllipse(in: CGRect(x: 4.2, y: 6.2, width: 6, height: 6))
            let b1 = UIBezierPath()
            b1.addArc(withCenter: CGPoint(x: 7.2, y: 19.5), radius: 6.4,
                      startAngle: .pi, endAngle: 0, clockwise: true)
            c.addPath(b1.cgPath)
            c.strokePath()
            c.strokeEllipse(in: CGRect(x: 13.8, y: 7.2, width: 5.4, height: 5.4))
            let b2 = UIBezierPath()
            b2.addArc(withCenter: CGPoint(x: 16.5, y: 19.5), radius: 5.8,
                      startAngle: .pi * 1.12, endAngle: -0.12 * .pi, clockwise: true)
            c.addPath(b2.cgPath)
            c.strokePath()
        case "tools":
            // toolbox: body, handle, lid line, latch
            let body = UIBezierPath(roundedRect: CGRect(x: 3.5, y: 8.5, width: 17, height: 11.5), cornerRadius: 2.4)
            c.addPath(body.cgPath)
            c.strokePath()
            let handle = UIBezierPath()
            handle.move(to: CGPoint(x: 8.5, y: 8.5))
            handle.addLine(to: CGPoint(x: 8.5, y: 6))
            handle.addQuadCurve(to: CGPoint(x: 9.5, y: 5), controlPoint: CGPoint(x: 8.5, y: 5))
            handle.addLine(to: CGPoint(x: 14.5, y: 5))
            handle.addQuadCurve(to: CGPoint(x: 15.5, y: 6), controlPoint: CGPoint(x: 15.5, y: 5))
            handle.addLine(to: CGPoint(x: 15.5, y: 8.5))
            handle.move(to: CGPoint(x: 3.5, y: 13.2))
            handle.addLine(to: CGPoint(x: 20.5, y: 13.2))
            c.addPath(handle.cgPath)
            c.strokePath()
            c.fill(CGRect(x: 10.6, y: 11.6, width: 2.8, height: 3.2))
        case "grid_plus":
            for (x, y) in [(CGFloat(4), CGFloat(4)), (13.5, 4), (4, 13.5)] {
                let r = UIBezierPath(roundedRect: CGRect(x: x, y: y, width: 6.5, height: 6.5),
                                     cornerRadius: 1.6)
                c.addPath(r.cgPath)
                c.strokePath()
            }
            let plus = UIBezierPath()
            plus.move(to: CGPoint(x: 16.75, y: 13.5))
            plus.addLine(to: CGPoint(x: 16.75, y: 20))
            plus.move(to: CGPoint(x: 13.5, y: 16.75))
            plus.addLine(to: CGPoint(x: 20, y: 16.75))
            c.addPath(plus.cgPath)
            c.strokePath()
        default:
            break
        }
        c.restoreGState()
    }
}

// MARK: - big action button --------------------------------------------------------

/// Full-width action button used by NEW PROJECT (orange) and
/// IMPORT PROJECT FILE (the original's dark brown + orange text).
final class HomeBigButton: TapView {

    var title: NSAttributedString? { didSet { label.attributedText = title; setNeedsDisplay() } }
    var bg: Int32 = C.GREEN { didSet { setNeedsDisplay() } }
    var fg: Int32 = C.ONDARK { didSet { setNeedsDisplay() } }
    var icon: String? { didSet { setNeedsDisplay() } }
    var tapped: (() -> Void)?

    private let label = UILabel()

    init() {
        super.init(frame: .zero)
        onClick = { [weak self] in self?.tapped?() }
        layer.cornerRadius = 23
        clipsToBounds = true
        label.textAlignment = .center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.8
        addSubview(label)
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        setNeedsDisplay()
        let size = label.sizeThatFits(CGSize(width: bounds.width - 100, height: bounds.height))
        let shift: CGFloat = icon != nil ? 12 : 0
        label.frame = CGRect(x: bounds.midX - size.width / 2 + shift,
                             y: bounds.midY - size.height / 2,
                             width: size.width, height: size.height)
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        c.setFillColor(argbToUIColor(bg).cgColor)
        c.fill(bounds)
        label.textColor = argbToUIColor(fg)
        if let ic = icon {
            Icons.draw(c, ic, label.frame.minX - 16, bounds.midY, 20, fg)
        }
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - segmented pill (the creation sheet's selectors) ---------------------

/// One option pill: orange with dark text when selected, card-gray otherwise.
final class SegPill: TapView {

    var title: String = "" { didSet { label.text = title; setNeedsDisplay() } }
    var on = false { didSet { setNeedsDisplay() } }
    var tapped: (() -> Void)?

    private let label = UILabel()

    init() {
        super.init(frame: .zero)
        onClick = { [weak self] in self?.tapped?() }
        layer.cornerRadius = 10
        clipsToBounds = true
        label.font = .systemFont(ofSize: 13, weight: .semibold)
        label.textAlignment = .center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.7
        addSubview(label)
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        label.frame = bounds.insetBy(dx: 4, dy: 0)
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        c.setFillColor(argbToUIColor(on ? C.GREEN : C.CARD2).cgColor)
        c.fill(bounds)
        label.textColor = argbToUIColor(on ? C.ONDARK : C.TEXT)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}
