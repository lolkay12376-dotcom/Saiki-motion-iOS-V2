// BuiltinsExtra.swift — PsykoBlobs, PsykoStripes, Ripple Dissolve, Card Dance.
//
// Ports of the supplied .aureaplugin shaders / Sapphire S_PsykoBlobs reference to the
// built-in `vec4 effect(vec2 uv)` format (GLSL ES 2.0, premultiplied src()). Cheap by design:
// one pass, one texture read per pixel (Card Dance: one read, capped grid loop).

import Foundation

func extraFx() -> [EffectDef] {
    var out: [EffectDef] = []

    out.append(EffectDef(
        id: "psykoblobs", name: "PsykoBlobs",
        desc: "Field of noise 'blobs' blended with the source and run through a cycling colour ramp (Phase Speed animates it). Recreation of Sapphire S_PsykoBlobs.",
        category: "Stylize", props: [
            PropDef("noiseFreq", "Noise Freq", 0.01, 32, 4, 2),
            PropDef("noiseFreqRelX", "Noise Freq Rel X", 0.01, 8, 1, 2),
            PropDef("noiseOctaves", "Noise Octaves", 1, 6, 1, 0),
            PropDef("noiseSeed", "Noise Seed", 0, 100, 0.23, 2),
            PropDef("shiftX", "Noise Shift X", -10, 10, 0, 2),
            PropDef("shiftY", "Noise Shift Y", -10, 10, 0, 2),
            PropDef("sourceScale", "Source Scale", 0, 4, 1, 2),
            PropDef("freqColors", "Freq Colors", 0, 16, 4, 2),
            PropDef("freqRed", "Freq Red", 0, 8, 1, 2),
            PropDef("freqGreen", "Freq Green", 0, 8, 1.1, 2),
            PropDef("freqBlue", "Freq Blue", 0, 8, 1.2, 2),
            PropDef("phaseStart", "Phase Start", -10, 10, 0.5, 2),
            PropDef("phaseSpeed", "Phase Speed", -10, 10, 1, 2),
            PropDef("brightness", "Brightness", 0, 4, 1, 2),
            PropDef("saturation", "Saturation", 0, 10, 1, 2),
            PropDef("scaleBySource", "Scale By Source", 0, 1, 0, 2),
            PropDef("mixWithSource", "Mix With Source", 0, 1, 0, 2),
        ], colors: [ColorParam("tint", "Color", Int32(bitPattern: 0xFFFFFFFF))],
        previewAnim: "fade", glsl: """
    vec4 s = src(uv);
    float a = s.a;
    vec3 sc = s.rgb / max(a, 0.0001);
    float lum = dot(sc, vec3(0.2126, 0.7152, 0.0722));
    vec2 p = (uv - 0.5) * vec2(uRes.x / max(uRes.y, 1.0) * noiseFreqRelX, 1.0) * noiseFreq
           + vec2(shiftX, shiftY) + vec2(noiseSeed * 17.0, noiseSeed * 31.0);
    float n = 0.0; float amp = 0.5; float norm = 0.0;
    for (int i = 0; i < 6; i++) {
        if (float(i) >= noiseOctaves - 0.5) break;
        n += amp * vnoise(p); norm += amp;
        p = p * 2.0 + 7.3; amp *= 0.5;
    }
    n /= max(norm, 0.0001);
    float val = n * 2.0 + lum * sourceScale;
    float ph = phaseStart + phaseSpeed * uTime;
    vec3 fk = vec3(freqRed, freqGreen, freqBlue);
    vec3 col = 0.5 + 0.5 * sin(6.2831853 * (freqColors * fk * val + ph));
    float g = (col.r + col.g + col.b) / 3.0;
    col = vec3(g) + (col - vec3(g)) * saturation;
    col = col * brightness * tint.rgb;
    col *= clamp(1.0 - scaleBySource * clamp(lum, 0.0, 1.0), 0.0, 1.0);
    col = mix(col, sc, mixWithSource);
    return vec4(clamp(col, 0.0, 1.0) * a, a);
"""))

    out.append(EffectDef(
        id: "psykostripes", name: "PsykoStripes",
        desc: "Wavy colourised stripes with an animated phase, driven by the source brightness.",
        category: "Stylize", props: [
            PropDef("angle", "Angle", -360, 360, 0, 1),
            PropDef("stripeFreq", "Stripe Freq", 0.1, 64, 6, 2),
            PropDef("stripeShift", "Stripe Shift", -100, 100, 0, 2),
            PropDef("warp", "Warp", 0, 4, 0.3, 2),
            PropDef("warpFreq", "Warp Freq", 0, 32, 3, 2),
            PropDef("warpPhase", "Warp Phase", -100, 100, 0.23, 2),
            PropDef("sourceScale", "Source Scale", 0, 4, 1, 2),
            PropDef("freqColors", "Freq Colors", 0, 32, 1, 2),
            PropDef("freqSpread", "Freq RGB Spread", 0, 1, 0.1, 2),
            PropDef("phaseStart", "Phase Start", -10, 10, 0.5, 2),
            PropDef("phaseSpeed", "Phase Speed", -10, 10, 1, 2),
            PropDef("brightness", "Brightness", 0, 4, 1, 2),
            PropDef("saturation", "Saturation", 0, 10, 1, 2),
            PropDef("scaleBySource", "Scale By Source", 0, 1, 0, 2),
            PropDef("mixWithSource", "Mix With Source", 0, 1, 0, 2),
        ], colors: [ColorParam("tint", "Color", Int32(bitPattern: 0xFFFFFFFF))],
        previewAnim: "fade", glsl: """
    vec4 s = src(uv);
    float a = s.a;
    vec3 sc = s.rgb / max(a, 0.0001);
    float lum = dot(sc, vec3(0.2126, 0.7152, 0.0722));
    vec2 q = (uv - 0.5) * uRes / max(max(uRes.x, uRes.y), 1.0);
    q += warp * 0.1 * vec2(sin(q.y * warpFreq * 6.2831853 + warpPhase),
                           sin(q.x * warpFreq * 6.2831853 * 1.3 + warpPhase * 1.7));
    float ang = radians(angle);
    float u = q.x * cos(ang) + q.y * sin(ang);
    float val = u * stripeFreq + stripeShift + lum * sourceScale;
    float ph = phaseStart + phaseSpeed * uTime;
    vec3 fk = vec3(1.0, 1.0 + freqSpread, 1.0 + 2.0 * freqSpread);
    vec3 col = 0.5 + 0.5 * sin(6.2831853 * (freqColors * fk * val + ph));
    float g = (col.r + col.g + col.b) / 3.0;
    col = vec3(g) + (col - vec3(g)) * saturation;
    col = col * brightness * tint.rgb;
    col *= clamp(1.0 - scaleBySource * clamp(lum, 0.0, 1.0), 0.0, 1.0);
    col = mix(col, sc, mixWithSource);
    return vec4(clamp(col, 0.0, 1.0) * a, a);
"""))

    out.append(EffectDef(
        id: "rippledissolve", name: "Ripple Dissolve",
        desc: "Transition: a rippling wave spreads from a centre point, distorting the layer while it fades out. Auto mode follows layer time; Percent Done mode is keyframable.",
        category: "Distort", props: [
            PropDef("animation", "Mode (0 Auto / 1 Percent)", 0, 1, 0, 0, ["Auto", "Percent Done"]),
            PropDef("percentDone", "Percent Done", 0, 100, 0, 1),
            PropDef("duration", "Duration (s)", 0.05, 60, 1.5, 2),
            PropDef("centerX", "Center X", 0, 1, 0.5, 2),
            PropDef("centerY", "Center Y", 0, 1, 0.5, 2),
            PropDef("radiusPeak", "Radius Peak %", 0, 300, 100, 0),
            PropDef("waveHeight", "Wave Height px", 0, 100, 20, 1),
            PropDef("perpHeight", "Perp Height px", 0, 100, 0, 1),
            PropDef("waveWidth", "Wave Width px", 5, 400, 60, 0),
            PropDef("widthGrow", "Width Increase %", 0, 300, 0, 0),
            PropDef("waveSpeed", "Wave Speed", 0, 20, 3, 2),
            PropDef("speedDecel", "Speed Decel %", 0, 100, 0, 0),
            PropDef("lightAngle", "Light Angle", -360, 360, 135, 0),
            PropDef("innerRadius", "Inner Radius %", 0, 200, 0, 0),
            PropDef("fallOff", "Fall Off %", 0, 100, 50, 0),
            PropDef("lightLevel", "Light Level %", 0, 100, 40, 0),
            PropDef("fadeOut", "Fade Out %", 0, 100, 0, 0),
        ], previewAnim: "fade", glsl: """
    float t = (animation < 0.5) ? clamp(uTime / max(duration, 0.001), 0.0, 1.0)
                                : clamp(percentDone * 0.01, 0.0, 1.0);
    float e = t * (0.5 + t * (1.5 - t));
    float bell = sin(3.14159265 * e);
    float d = smoothstep(0.0, 1.0, e) * clamp(fadeOut * 0.01, 0.0, 1.0);
    vec2 cen = vec2(centerX, centerY);
    vec2 dpx = (uv - cen) * uRes;
    float r = length(dpx);
    vec2 dir = (r > 0.0001) ? dpx / r : vec2(1.0, 0.0);
    vec2 perp = vec2(-dir.y, dir.x);
    vec2 cPx = cen * uRes;
    float halfDiag = length(max(cPx, uRes - cPx));
    float W = max(waveWidth * (1.0 + widthGrow * 0.01 * e), 1.0);
    float dec = clamp(speedDecel * 0.01, 0.0, 1.0);
    float accum = waveSpeed * (e - 0.5 * dec * e * e);
    float arg = 6.2831853 * (r / W - accum);
    float R = radiusPeak * 0.01 * halfDiag * e;
    float fl = max(fallOff * 0.01, 0.01) * 0.5 * max(R, 1.0);
    float outerEnv = 1.0 - smoothstep(R - fl, R + fl, r);
    float ri = innerRadius * 0.01 * halfDiag * e;
    float innerEnv = (ri > 0.0) ? smoothstep(ri - fl, ri + fl, r) : 1.0;
    float env = outerEnv * innerEnv * bell;
    float cs = cos(arg);
    vec2 dispPx = (dir * (waveHeight * sin(arg)) + perp * (perpHeight * cs)) * env;
    vec4 col = src(uv - dispPx / uRes) * (1.0 - d);
    float slope = waveHeight * cs * (6.2831853 / W) * env;
    vec3 N = normalize(vec3(-slope * dir, 1.0));
    float la = radians(lightAngle);
    vec3 L = normalize(vec3(cos(la), -sin(la), 1.0));
    float flatLit = pow(max(L.z, 0.0), 24.0);
    float lit = clamp((pow(max(dot(N, L), 0.0), 24.0) - flatLit) / max(1.0 - flatLit, 0.001), 0.0, 1.0);
    col.rgb += vec3(lit * lightLevel * 0.01 * col.a);
    return col;
"""))

    out.append(EffectDef(
        id: "carddance", name: "Card Dance",
        desc: "Splits the layer into a card grid; a seeded half of the cards moves toward the camera and the rest away, with 3D tilt and perspective.",
        category: "Distort", props: [
            PropDef("rows", "Rows", 1, 16, 1, 0),
            PropDef("columns", "Columns", 1, 16, 7, 0),
            PropDef("gap", "Gap px", 0, 80, 8, 0),
            PropDef("focal", "Perspective", 100, 4000, 900, 0),
            PropDef("xRotation", "X Rotation", -180, 180, 0, 0),
            PropDef("yRotation", "Y Rotation", -180, 180, 12, 0),
            PropDef("zPush", "Z Push", 0, 1200, 120, 0),
            PropDef("seed", "Seed", 0, 9999, 1, 0),
        ], previewAnim: "swipe", glsl: """
    vec2 L = max(uRes, vec2(1.0));
    vec2 pixel = uv * L;
    float cols = clamp(floor(columns + 0.5), 1.0, 16.0);
    float rws = clamp(floor(rows + 0.5), 1.0, 16.0);
    vec2 cardSize = L / vec2(cols, rws);
    vec3 ro = vec3(L * 0.5, -focal);
    vec3 rd = normalize(vec3(pixel - L * 0.5, focal));
    float ax = radians(xRotation); float ay = radians(yRotation);
    float cx = cos(ax), sx = sin(ax), cy = cos(ay), sy = sin(ay);
    mat3 RX = mat3(1.0, 0.0, 0.0, 0.0, cx, sx, 0.0, -sx, cx);
    mat3 RY = mat3(cy, 0.0, -sy, 0.0, 1.0, 0.0, sy, 0.0, cy);
    mat3 R = RY * RX;
    vec3 normal = R * vec3(0.0, 0.0, 1.0);
    float denom = dot(rd, normal);
    float bestT = 1e20;
    vec4 result = vec4(0.0, 0.0, 0.0, 1.0);
    if (abs(denom) < 0.00001) { return result; }
    vec2 half2 = cardSize * 0.5 - vec2(gap * 0.5);
    if (half2.x <= 0.0 || half2.y <= 0.0) { return result; }
    for (int iy = 0; iy < 16; iy++) {
        if (float(iy) >= rws) break;
        for (int ix = 0; ix < 16; ix++) {
            if (float(ix) >= cols) break;
            vec2 id = vec2(float(ix), float(iy));
            float rnd = hash21(id + vec2(seed * 17.17, seed * 41.73));
            float z = zPush * ((rnd >= 0.5) ? 1.0 : -1.0);
            vec2 c2 = (id + 0.5) * cardSize;
            vec3 cen = vec3(c2, z);
            float t = dot(cen - ro, normal) / denom;
            if (t <= 0.0 || t >= bestT) continue;
            vec3 d3 = ro + rd * t - cen;
            vec3 loc = vec3(dot(R[0], d3), dot(R[1], d3), dot(R[2], d3));
            if (denom > 0.0) {
                if (R[0].x < R[1].y) { loc.x = -loc.x; } else { loc.y = -loc.y; }
            }
            if (abs(loc.x) > half2.x || abs(loc.y) > half2.y) continue;
            result = src((c2 + loc.xy) / L);
            bestT = t;
        }
    }
    return result;
"""))
    return out
}
