// EffectDef.swift — one effect's definition (Effects).
//
// An effect = metadata (id/name/desc/category) + parameter list + colors +
// layer inputs + a GLSL body implementing `vec4 effect(vec2 uv)`. kind 1 =
// "single instance per layer" (remap, particles): parameters live on bare
// keys. Every other effect can be stacked; instance #2 gets the entry id
// "id~2" and parameters under "id~2__key".

import Foundation

final class EffectDef {
    let id: String
    var name: String
    var desc: String
    var category: String
    var kind: Int                     // 1 = single-instance (bare param keys)
    var props: [PropDef]
    var colors: [ColorParam]
    var inputs: [String]
    var previewAnim: String
    var builtin: Bool
    var bundled: Bool
    var source: String?               // folder path (sdk) or "bundle:" id
    var glsl: String                  // the effect.glsl body
    /// Optional native Metal source. When set the Metal renderer compiles it directly (see MetalEffects);
    /// when nil the GLSL above is translated at runtime. GL always keeps using `glsl`.
    var msl: String? = nil

    /// Colour / stylize / generate / keying effects only recolour the layer's own opaque pixels;
    /// blur, distort, transform and the glow-spill effects are allowed to move or grow alpha.
    var confinesToAlpha: Bool {
        if ["contour", "lightleak", "lightsweep"].contains(id) { return true }
        return ["Color", "Stylize", "Generate", "Keying"].contains(category)
    }

    init(id: String, name: String, desc: String, category: String = "Custom",
         kind: Int = 0, props: [PropDef] = [], colors: [ColorParam] = [],
         inputs: [String] = [], previewAnim: String = "swipe",
         builtin: Bool = false, bundled: Bool = false, source: String? = nil,
         glsl: String = "") {
        self.id = id
        self.name = name
        self.desc = desc
        self.category = category
        self.kind = kind
        self.props = props
        self.colors = colors
        self.inputs = inputs
        self.previewAnim = previewAnim
        self.builtin = builtin
        self.bundled = bundled
        self.source = source
        self.glsl = glsl
    }

    /// Parses an effect.json (as text) — the custom-effect import route and
    /// the SDK folders. `id` falls back to a slug of the name.
    static func fromJson(_ o: JObj, source: String?) -> EffectDef? {
        let name = o.optString("name").trimmingCharacters(in: .whitespaces)
        guard !name.isEmpty else { return nil }
        var id = o.optString("id").trimmingCharacters(in: .whitespaces)
        if id.isEmpty {
            id = String(name.lowercased().map { c in (c.isLetter || c.isNumber) ? c : Character("_") })
            id = id.trimmingCharacters(in: CharacterSet(charactersIn: "_"))
        }
        let d = EffectDef(id: id,
                          name: name,
                          desc: o.optString("description"),
                          category: o.optString("category", "Custom"),
                          kind: o.optInt("kind"),
                          inputs: [],
                          source: source,
                          glsl: o.optString("code"))
        let m = o.optString("msl")
        if !m.isEmpty { d.msl = m }
        // params
        if let pa = o.optJSONArray("params") {
            for i in 0..<pa.count {
                guard let po = pa.optJSONObject(i) else { continue }
                let key = po.optString("name").trimmingCharacters(in: .whitespaces)
                guard !key.isEmpty else { continue }
                var label = po.optString("label")
                if label.isEmpty { label = key }
                var opts: [String]? = nil
                if let oa = po.optJSONArray("options") {
                    opts = []
                    for j in 0..<oa.count { opts?.append(oa.optString(j)) }
                }
                let def = PropDef(key, label,
                                  po.optFloat("min"), po.optFloat("max", 1),
                                  po.optFloat("def"),
                                  po.optInt("dec", 2),
                                  opts,
                                  po.optBool("infinite"),
                                  po.optFloat("span", 180))
                d.props.append(def)
            }
        }
        // colors
        if let ca = o.optJSONArray("colors") {
            for i in 0..<ca.count {
                guard let co = ca.optJSONObject(i) else { continue }
                let key = co.optString("name").trimmingCharacters(in: .whitespaces)
                guard !key.isEmpty else { continue }
                var label = co.optString("label")
                if label.isEmpty { label = key }
                let hex = co.optString("def", "#FFFFFFFF")
                d.colors.append(ColorParam(key, label, parseColor(hex)))
            }
        }
        // inputs (layer references by name)
        if let ia = o.optJSONArray("inputs") {
            for i in 0..<ia.count {
                let nm = ia.optString(i).trimmingCharacters(in: .whitespaces)
                if !nm.isEmpty { d.inputs.append(nm) }
            }
        }
        let pv = o.optString("preview")
        if !pv.isEmpty { d.previewAnim = pv }
        return d
    }

    /// "#AARRGGBB" / "#RRGGBB" → ARGB Int32 (the SDK's color spelling).
    static func parseColor(_ s: String) -> Int32 {
        var t = s.trimmingCharacters(in: .whitespaces)
        if t.hasPrefix("#") { t.removeFirst() }
        guard let u = UInt64(t, radix: 16) else { return Int32(bitPattern: 0xFFFFFFFF) }
        if t.count == 6 { return Int32(bitPattern: UInt32(0xFF000000) | UInt32(u)) }
        if t.count == 8 { return Int32(bitPattern: UInt32(u)) }
        return Int32(bitPattern: 0xFFFFFFFF)
    }

    /// effect.json representation (export / preset files).
    func toJson() -> JObj {
        let o = JObj()
        o.put("id", id).put("name", name).put("description", desc)
        o.put("category", category).put("kind", Int64(kind)).put("preview", previewAnim)
        let pa = JArr()
        for p in props {
            let po = JObj().put("name", p.key).put("label", p.label)
                .put("min", Double(p.min)).put("max", Double(p.max)).put("def", Double(p.def))
                .put("dec", Int64(p.dec))
            if let opts = p.options {
                let oa = JArr()
                for s in opts { oa.put(s) }
                po.put("options", oa)
            }
            if p.inf { po.put("infinite", true).put("span", Double(p.span)) }
            pa.put(po)
        }
        o.put("params", pa)
        let ca = JArr()
        for c in colors {
            ca.put(JObj().put("name", c.key).put("label", c.label)
                .put("def", String(format: "#%08X", UInt32(bitPattern: c.def))))
        }
        o.put("colors", ca)
        let ia = JArr()
        for i in inputs { ia.put(i) }
        o.put("inputs", ia)
        o.put("code", glsl)
        if let m = msl, !m.isEmpty { o.put("msl", m) }
        return o
    }
}
