// ProjectArchive.swift — the `.saikiproject` bundle (Model).
//
// A single file holding a project AND the media it uses, so a project moves
// between devices intact. Plain container, streamed (videos never sit in RAM):
//
//   "SAIKIPRJ1\n"                       10-byte magic
//   u32  json length (little endian)
//   ...  project JSON (media paths rewritten to "@media/<key>")
//   u32  media count
//   per file:  u16 key length, key bytes (UTF-8), u64 data length, data
//
// Without media the app still exports the plain project .json as before.

import Foundation

enum ProjectArchive {

    static let fileExtension = "saikiproject"
    private static let magic = Array("SAIKIPRJ1\n".utf8)
    private static let prefix = "@media/"

    // MARK: sniffing

    static func isArchive(_ url: URL) -> Bool {
        guard let fh = try? FileHandle(forReadingFrom: url) else { return false }
        defer { try? fh.close() }
        guard let head = try? fh.read(upToCount: magic.count) else { return false }
        return Array(head.prefix(8)) == Array(magic.prefix(8))
    }

    // MARK: small binary helpers

    private static func le32(_ v: UInt32) -> Data {
        Data([UInt8(v & 0xFF), UInt8((v >> 8) & 0xFF), UInt8((v >> 16) & 0xFF), UInt8((v >> 24) & 0xFF)])
    }
    private static func le16(_ v: UInt16) -> Data {
        Data([UInt8(v & 0xFF), UInt8((v >> 8) & 0xFF)])
    }
    private static func le64(_ v: UInt64) -> Data {
        var out = Data()
        for i in 0..<8 { out.append(UInt8((v >> (8 * UInt64(i))) & 0xFF)) }
        return out
    }
    private static func readExact(_ fh: FileHandle, _ n: Int) -> Data? {
        if n == 0 { return Data() }
        guard let d = try? fh.read(upToCount: n), d.count == n else { return nil }
        return d
    }
    private static func u(_ d: Data) -> UInt64 {
        var v: UInt64 = 0
        for (i, b) in d.enumerated() { v |= UInt64(b) << (8 * UInt64(i)) }
        return v
    }

    // MARK: export

    /// Writes "<name>.saikiproject" into the temp folder. Returns nil on failure.
    static func export(_ id: String) -> URL? {
        guard let src = Projects.load(id),
              let o = JObj.parse(src.toJson().toString()) else { return nil }
        let p = Project.fromJson(o)                       // private copy we may rewrite

        // collect media, rewrite paths to relative keys
        var keyForPath: [String: String] = [:]
        var files: [(key: String, path: String)] = []
        func claim(_ path: String?) -> String? {
            guard let path = path, !path.isEmpty,
                  FileManager.default.fileExists(atPath: path) else { return path }
            if let k = keyForPath[path] { return prefix + k }
            var key = (path as NSString).lastPathComponent
            if files.contains(where: { $0.key == key }) { key = "\(files.count)_\(key)" }
            keyForPath[path] = key
            files.append((key, path))
            return prefix + key
        }
        for s in p.scenes {
            for l in s.layers {
                l.imagePath = claim(l.imagePath)
                l.fontPath = claim(l.fontPath)
            }
        }

        let json = Array(p.toJson().toString().utf8)
        let safe = src.name.components(separatedBy: CharacterSet(charactersIn: "/\\:*?\"<>|")).joined(separator: "_")
        let dest = FileManager.default.temporaryDirectory
            .appendingPathComponent((safe.isEmpty ? "project" : safe) + "." + fileExtension)
        try? FileManager.default.removeItem(at: dest)
        guard FileManager.default.createFile(atPath: dest.path, contents: nil),
              let out = try? FileHandle(forWritingTo: dest) else { return nil }
        do {
            try out.write(contentsOf: Data(magic))
            try out.write(contentsOf: le32(UInt32(json.count)))
            try out.write(contentsOf: Data(json))

            // only files that really exist go in
            let real = files.filter { FileManager.default.fileExists(atPath: $0.path) }
            try out.write(contentsOf: le32(UInt32(real.count)))
            for f in real {
                let keyBytes = Array(f.key.utf8)
                let attrs = try? FileManager.default.attributesOfItem(atPath: f.path)
                let size = (attrs?[.size] as? NSNumber)?.uint64Value ?? 0
                try out.write(contentsOf: le16(UInt16(min(keyBytes.count, 65535))))
                try out.write(contentsOf: Data(keyBytes.prefix(65535)))
                try out.write(contentsOf: le64(size))
                guard let inp = try? FileHandle(forReadingFrom: URL(fileURLWithPath: f.path)) else { throw CocoaError(.fileReadUnknown) }
                var left = size
                while left > 0 {
                    let chunk = try inp.read(upToCount: Int(min(left, 1 << 20))) ?? Data()
                    if chunk.isEmpty { break }
                    try out.write(contentsOf: chunk)
                    left -= UInt64(chunk.count)
                }
                try? inp.close()
            }
            try out.close()
            return dest
        } catch {
            try? out.close()
            try? FileManager.default.removeItem(at: dest)
            return nil
        }
    }

    // MARK: import

    /// Unpacks a .saikiproject into the store under a fresh id. Media go to the
    /// media folder with fresh names, and every path in the project is repointed.
    @discardableResult
    static func importArchive(_ url: URL) -> Project? {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        guard let fh = try? FileHandle(forReadingFrom: url) else { return nil }
        defer { try? fh.close() }
        guard let head = readExact(fh, magic.count), Array(head.prefix(8)) == Array(magic.prefix(8)),
              let lenData = readExact(fh, 4) else { return nil }
        let jsonLen = Int(u(lenData))
        guard jsonLen > 0, jsonLen < 400_000_000,
              let jsonData = readExact(fh, jsonLen),
              let text = String(data: jsonData, encoding: .utf8),
              let obj = JObj.parse(text) else { return nil }
        let p = Project.fromJson(obj)

        Projects.ensureDirs()
        var newPath: [String: String] = [:]
        if let cData = readExact(fh, 4) {
            let count = Int(u(cData))
            for _ in 0..<min(count, 100_000) {
                guard let kl = readExact(fh, 2), let kb = readExact(fh, Int(u(kl))),
                      let key = String(data: kb, encoding: .utf8),
                      let sl = readExact(fh, 8) else { break }
                var left = u(sl)
                let clean = key.replacingOccurrences(of: "/", with: "_")
                let destURL = Projects.mediaDir()
                    .appendingPathComponent(ProjectIO.sandboxName(forOriginal: clean))
                FileManager.default.createFile(atPath: destURL.path, contents: nil)
                guard let w = try? FileHandle(forWritingTo: destURL) else { break }
                while left > 0 {
                    guard let chunk = try? fh.read(upToCount: Int(min(left, 1 << 20))), !chunk.isEmpty else { break }
                    try? w.write(contentsOf: chunk)
                    left -= UInt64(chunk.count)
                }
                try? w.close()
                newPath[key] = destURL.path
            }
        }
        func fix(_ path: String?) -> String? {
            guard let path = path, path.hasPrefix(prefix) else { return path }
            return newPath[String(path.dropFirst(prefix.count))]
        }
        for s in p.scenes {
            for l in s.layers {
                l.imagePath = fix(l.imagePath)
                l.fontPath = fix(l.fontPath)
            }
        }
        p.id = UUID().uuidString
        if p.name.isEmpty { p.name = url.deletingPathExtension().lastPathComponent }
        var saved = p
        let nLayers = p.scenes.reduce(0) { $0 + $1.layers.count }
        Projects.lastImportNote = "\(p.scenes.count) scenes · \(nLayers) layers · \(newPath.count) media"
        Projects.save(&saved)
        return saved
    }
}
