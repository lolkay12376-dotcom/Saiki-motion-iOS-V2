// Puppet.swift — puppet pin warp (Model + math).
// Pins live in the layer's quad space (-1...1, y up, same space as the
// renderer's aPos). Each pin's motion is two ordinary tracks on the layer
// ("pp<id>x" / "pp<id>y" = offset from rest), so keyframes, auto-key,
// undo, save and export all work with no special cases. Auto-sway adds a
// procedural wave on top, scaled root→tip along a chain of pins.

import Foundation
import OpenGLES

final class PuppetPin {
    var id: Int
    var rx: Float
    var ry: Float
    init(_ id: Int, _ rx: Float, _ ry: Float) { self.id = id; self.rx = rx; self.ry = ry }
}

final class Puppet {
    var on = true
    var pins: [PuppetPin] = []
    var nextId = 1
    var density = 1                 // 0 low, 1 medium, 2 high
    var showMesh = true
    var stiffness: Float = 2        // falloff power (higher = more local)
    var swayOn = false
    var lockRoot = true
    var swayStrength = 1            // 0 gentle, 1 medium, 2 strong
    var swayChain: [Int] = []       // pin ids, root first
    var swaySpeed: Float = 0.8      // cycles per second
    var swayDeg: Float = 20         // swing angle at the tip (degrees)
    var swayWave: Float = 0.5       // phase lag per pin (radians)
    var swayTip: Float = 1.5        // root→tip weight exponent
    var swayRand: Float = 0         // 0...1
    var swaySeed = 1

    func pin(_ id: Int) -> PuppetPin? { pins.first { $0.id == id } }
    func number(_ id: Int) -> Int { (pins.firstIndex { $0.id == id } ?? 0) + 1 }

    func toJson() -> JObj {
        let o = JObj()
        o.put("on", on).put("nextId", Int64(nextId)).put("density", Int64(density))
        o.put("showMesh", showMesh).put("stiffness", Double(stiffness))
        o.put("swayOn", swayOn).put("lockRoot", lockRoot)
        o.put("swayStrength", Int64(swayStrength)).put("swaySpeed", Double(swaySpeed))
        o.put("swayDeg", Double(swayDeg)).put("swayWave", Double(swayWave)).put("swayTip", Double(swayTip))
        o.put("swayRand", Double(swayRand)).put("swaySeed", Int64(swaySeed))
        let pa = JArr()
        for p in pins {
            pa.put(JObj().put("id", Int64(p.id)).put("rx", Double(p.rx)).put("ry", Double(p.ry)))
        }
        o.put("pins", pa)
        let ca = JArr(); for c in swayChain { _ = ca.put(Int64(c)) }
        o.put("chain", ca)
        return o
    }

    static func fromJson(_ o: JObj) -> Puppet {
        let p = Puppet()
        p.on = o.optBool("on", true)
        p.nextId = max(1, o.optInt("nextId", 1))
        p.density = clamp(o.optInt("density", 1), 0, 3)
        p.showMesh = o.optBool("showMesh", true)
        p.stiffness = o.optFloat("stiffness", 2)
        p.swayOn = o.optBool("swayOn")
        p.lockRoot = o.optBool("lockRoot", true)
        p.swayStrength = clamp(o.optInt("swayStrength", 1), 0, 2)
        p.swaySpeed = o.optFloat("swaySpeed", 0.8)
        p.swayDeg = o.optFloat("swayDeg", 20); p.swayWave = o.optFloat("swayWave", 0.5)
        p.swayTip = o.optFloat("swayTip", 1.5); p.swayRand = o.optFloat("swayRand", 0)
        p.swaySeed = o.optInt("swaySeed", 1)
        if let pa = o.optJSONArray("pins") {
            for i in 0..<pa.count {
                if let po = pa.optJSONObject(i) {
                    p.pins.append(PuppetPin(po.optInt("id"), po.optFloat("rx"), po.optFloat("ry")))
                }
            }
        }
        if let ca = o.optJSONArray("chain") {
            for i in 0..<ca.count { p.swayChain.append(ca.optInt(i)) }
        }
        return p
    }
}

/// Shared state between the Puppet panel and the viewport overlay.
enum PuppetEdit {
    static var mode = 0              // 0 add, 1 select, 2 multi
    static var sel: [Int] = []       // selected pin ids (last = primary)
    static var fine = false
    static var onChange: (() -> Void)? = nil
}

enum PuppetMath {
    static let segs = [7, 12, 18, 28]
    private static let lock = NSLock()
    private static var gCaches: [Int: (key: [Float], out: [Float])] = [:]

    static func rnd(_ seed: Int, _ k: Int) -> Float {
        var x = UInt32(truncatingIfNeeded: seed &* 7919 &+ k &* 104729 &+ 12345)
        x = x &* 1664525 &+ 1013904223
        x ^= x >> 13
        x = x &* 1664525 &+ 1013904223
        return Float(x >> 8) / Float(1 << 24) * 2 - 1
    }

    /// Procedural sway: each chained pin swings around the root pin, more toward the tip.
    static func swayOffset(_ l: Layer, _ p: Puppet, _ pin: PuppetPin, _ t: Float,
                           _ qs: (Float, Float)) -> (Float, Float) {
        guard p.swayOn, let k = p.swayChain.firstIndex(of: pin.id),
              let root = p.pin(p.swayChain[0]) else { return (0, 0) }
        let n = p.swayChain.count
        let base: Float = p.lockRoot ? (n > 1 ? Float(k) / Float(n - 1) : 0) : Float(k + 1) / Float(n)
        let w = base <= 0 ? 0 : pow(base, max(p.swayTip, 0.1))
        let r = rnd(p.swaySeed, k)
        let ph = 2 * Float.pi * p.swaySpeed * t - Float(k) * p.swayWave + p.swayRand * r * Float.pi
        let amp = 1 + p.swayRand * r * 0.5
        if k == 0 {
            return p.lockRoot ? (0, 0) : (0.03 * p.swayDeg / 20 * w * sin(ph), 0)
        }
        let ang = p.swayDeg * Float.pi / 180 * w * sin(ph) * amp
        let vx = (pin.rx - root.rx) * qs.0, vy = (pin.ry - root.ry) * qs.1
        let c = cos(ang), s = sin(ang)
        let rx = vx * c - vy * s, ry = vx * s + vy * c
        return ((rx - vx) / max(qs.0, 0.0001), (ry - vy) / max(qs.1, 0.0001))
    }

    /// Offset from rest of one pin at time t (keyed tracks + sway).
    static func offset(_ l: Layer, _ p: Puppet, _ pin: PuppetPin, _ t: Float,
                       _ qs: (Float, Float)? = nil) -> (Float, Float) {
        let ox = (l.props["pp\(pin.id)x"]?.eval(t) ?? 0) + (l.rigOff["pp\(pin.id)x"] ?? 0)
        let oy = (l.props["pp\(pin.id)y"]?.eval(t) ?? 0) + (l.rigOff["pp\(pin.id)y"] ?? 0)
        if !p.swayOn { return (ox, oy) }
        let s = swayOffset(l, p, pin, t, qs ?? Xf.quadSize(l))
        return (ox + s.0, oy + s.1)
    }

    static func pinPos(_ l: Layer, _ p: Puppet, _ pin: PuppetPin, _ t: Float,
                       _ qs: (Float, Float)? = nil) -> (Float, Float) {
        let o = offset(l, p, pin, t, qs)
        return (pin.rx + o.0, pin.ry + o.1)
    }

    @inline(__always) static func wgt(_ d2: Float, _ pw: Float) -> Float {
        let e = d2 + 0.00001
        return pw == 2 ? 1 / e : pow(e, -pw * 0.5)
    }

    /// Displacement of a rest point (inverse-distance weighted, with a hold
    /// weight so far-away points stay put).
    static func disp(_ pins: [(Float, Float, Float, Float)], _ pw: Float, _ x: Float, _ y: Float) -> (Float, Float) {
        var sx: Float = 0, sy: Float = 0, sw = pow(1.4, -pw)
        for q in pins {
            let dx = x - q.0, dy = y - q.1
            let w = wgt(dx * dx + dy * dy, pw)
            sx += w * q.2; sy += w * q.3; sw += w
        }
        return (sx / sw, sy / sw)
    }

    static func activePins(_ l: Layer, _ p: Puppet, _ t: Float) -> [(Float, Float, Float, Float)] {
        let qs = p.swayOn ? Xf.quadSize(l) : (1, 1)
        return p.pins.map { let o = offset(l, p, $0, t, qs); return ($0.rx, $0.ry, o.0, o.1) }
    }

    /// Deformed grid vertex positions (aPos space), row-major, (n+1)² points. Cached so the
    /// renderer and the overlay share one computation per change.
    static func gridPositions(_ l: Layer, _ p: Puppet, _ t: Float) -> [Float] {
        let n = segs[p.density]
        let pins = activePins(l, p, t)
        var key: [Float] = [Float(l.id), Float(n), p.stiffness]
        for q in pins { key.append(q.0); key.append(q.1); key.append(q.2); key.append(q.3) }
        let ck = l.id &* 8 &+ p.density
        lock.lock()
        if let c = gCaches[ck], c.key == key { lock.unlock(); return c.out }
        lock.unlock()
        var out = [Float](); out.reserveCapacity((n + 1) * (n + 1) * 2)
        for j in 0...n {
            let y = -1 + 2 * Float(j) / Float(n)
            for i in 0...n {
                let x = -1 + 2 * Float(i) / Float(n)
                let d = disp(pins, p.stiffness, x, y)
                out.append(x + d.0); out.append(y + d.1)
            }
        }
        lock.lock()
        if gCaches.count > 400 { gCaches.removeAll() }
        gCaches[ck] = (key, out); lock.unlock()
        return out
    }

    private static var topoCache: [Int: ([Float], [UInt16])] = [:]
    static func topology(_ n: Int) -> ([Float], [UInt16]) {
        if let c = topoCache[n] { return c }
        var uv = [Float](), idx = [UInt16]()
        for j in 0...n { for i in 0...n { uv.append(Float(i) / Float(n)); uv.append(Float(j) / Float(n)) } }
        for j in 0..<n { for i in 0..<n {
            let a = UInt16(j * (n + 1) + i), b = a + 1, c = a + UInt16(n + 1), d = c + 1
            idx += [a, b, c, b, d, c]
        } }
        topoCache[n] = (uv, idx)
        return (uv, idx)
    }

    /// Mesh for the renderer, or nil when the layer has no active puppet.
    static func mesh(_ l: Layer, _ t: Float) -> (pos: [Float], uv: [Float], idx: [UInt16])? {
        guard let p = l.puppet, p.on, !p.pins.isEmpty else { return nil }
        let (uv, idx) = topology(segs[p.density])
        return (gridPositions(l, p, t), uv, idx)
    }
}

extension Gl {
    /// Draws an indexed triangle mesh: aPos = deformed quad-space position, aUv = rest uv.
    static func drawMesh(_ program: GLProgram, _ pos: [Float], _ uv: [Float], _ idx: [UInt16]) {
        program.use()
        glBindBuffer(GLenum(GL_ARRAY_BUFFER), 0)
        glBindBuffer(GLenum(GL_ELEMENT_ARRAY_BUFFER), 0)
        let aPos = glGetAttribLocation(program.handle, "aPos")
        let aUv = glGetAttribLocation(program.handle, "aUv")
        guard aPos >= 0, aUv >= 0 else { return }
        glEnableVertexAttribArray(GLuint(aPos))
        glEnableVertexAttribArray(GLuint(aUv))
        pos.withUnsafeBufferPointer { pp in
            uv.withUnsafeBufferPointer { up in
                idx.withUnsafeBufferPointer { ip in
                    glVertexAttribPointer(GLuint(aPos), 2, GLenum(GL_FLOAT), GLboolean(GL_FALSE), 8, pp.baseAddress)
                    glVertexAttribPointer(GLuint(aUv), 2, GLenum(GL_FLOAT), GLboolean(GL_FALSE), 8, up.baseAddress)
                    glDrawElements(GLenum(GL_TRIANGLES), GLsizei(idx.count), GLenum(GL_UNSIGNED_SHORT), ip.baseAddress)
                }
            }
        }
        glDisableVertexAttribArray(GLuint(aPos))
        glDisableVertexAttribArray(GLuint(aUv))
    }
}
