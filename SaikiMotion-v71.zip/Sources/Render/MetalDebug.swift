//  MetalDebug.swift — hidden debug panel (long-press the SAIKI MOTION wordmark on the home screen for 2 s).

import UIKit

enum MetalDebug {
    static func statusText() -> String {
        guard let core = MetalCore.shared, let passes = MetalPasses.shared else { return "Metal is not available on this device." }
        var l: [String] = [core.status]
        l.append("flag useMetalRenderer: " + (RenderBackend.useMetal ? "ON" : "OFF") + "  (live preview stays GL until Stage 4)")
        l.append("self-test: " + (MetalCore.selfTest() ? "PASS" : "FAIL"))
        l.append("pass shaders: " + (passes.buildError.map { "FAILED " + $0.prefix(120) } ?? "compiled OK"))
        l.append(MetalEffects.shared?.summary ?? "effects: n/a")
        l.append(MetalParity.lastSummary)
        return l.joined(separator: "\n")
    }

    static func present(from vc: UIViewController) {
        let a = UIAlertController(title: "Metal renderer (experimental)", message: statusText(), preferredStyle: .alert)
        a.addAction(UIAlertAction(title: RenderBackend.useMetal ? "Turn flag OFF" : "Turn flag ON", style: .default) { _ in
            RenderBackend.useMetal.toggle()
            present(from: vc)
        })
        a.addAction(UIAlertAction(title: "Run parity test (GL vs Metal)", style: .default) { _ in
            let wait = UIAlertController(title: "Running parity test…", message: "Compiling effects, a few seconds.", preferredStyle: .alert)
            vc.present(wait, animated: true)
            MetalParity.run { report in
                wait.dismiss(animated: true) {
                    let r = UIAlertController(title: "Parity report", message: String(report.prefix(1800)), preferredStyle: .alert)
                    r.addAction(UIAlertAction(title: "Copy full report", style: .default) { _ in
                        UIPasteboard.general.string = report
                    })
                    r.addAction(UIAlertAction(title: "Close", style: .cancel))
                    vc.present(r, animated: true)
                }
            }
        })
        a.addAction(UIAlertAction(title: "Close", style: .cancel))
        vc.present(a, animated: true)
    }
}
