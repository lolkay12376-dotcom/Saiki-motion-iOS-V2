//  MetalEffects.swift
//  Metal migration stage 3: effect passes. Effects keep GLSL as their source; EffectDef.msl (optional)
//  is native Metal. GLSL is translated at runtime by a light source translator that builds on
//  Gl.effectShaderSource, so the prelude (luma, hash, fbm, hsv…) and the confine-to-alpha rules
//  stay in ONE place.
//
//  Translation scheme: every GLSL function (prelude + effect body) becomes a member of `struct FxCtx`,
//  which also holds the uniforms and textures. That gives GLSL's "global uniforms" without MSL globals.
//  Native MSL contract (EffectDef.msl): define
//    fragment float4 effectFragment(VOut in [[stage_in]], constant FxCommon& C [[buffer(0)]],
//        constant float* P [[buffer(1)]], texture2d<float> t0 [[texture(0)]],
//        texture2d<float> t1 [[texture(1)]], texture2d<float> t2 [[texture(2)]])
//  t0 = layer, t1/t2 = in0/in1. P = props in order, then each colour as 4 floats (r,g,b,a).
//  The standard header (VOut, FxCommon, linearClamp, flipV) is prepended unless the source has its own #include.

import Foundation
import Metal

final class MetalEffects {
    static let shared: MetalEffects? = MetalPasses.shared.map { MetalEffects($0) }

    /// One step of a layer's effect chain.
    struct Step {
        var def: EffectDef
        var props: [Float]            // in def.props order
        var colors: [SIMD4<Float>]    // in def.colors order
        var in0: MTLTexture? = nil
        var in1: MTLTexture? = nil
        var inRef0: Int? = nil        // layer ids picked for the effect's layer inputs (resolved by the scene renderer)
        var inRef1: Int? = nil
    }

    private final class Entry {
        var lib: MTLLibrary?
        var error: String?
        var native = false
        var msl = ""
    }

    private let passes: MetalPasses
    private var cache: [String: Entry] = [:]       // per-effect translation cache
    private let lock = NSLock()
    private(set) var translatedCount = 0
    private(set) var nativeCount = 0
    private(set) var failures: [String: String] = [:]

    private init(_ p: MetalPasses) { passes = p }

    var summary: String {
        lock.lock(); defer { lock.unlock() }
        return "effects: \(translatedCount) translated, \(nativeCount) native MSL, \(failures.count) failed"
    }

    // MARK: - public

    /// False if the effect's shader does not compile in Metal (callers should render that frame/effect in GL).
    func canRun(_ d: EffectDef) -> Bool { entry(d).lib != nil }

    func mslSource(_ d: EffectDef) -> String { entry(d).msl }

    /// Runs one effect pass: src -> out. Returns false (and writes nothing) when the shader failed.
    @discardableResult
    func apply(_ cb: MTLCommandBuffer, step: Step, src: MTLTexture, out: MetalTarget,
               time: Float, rect: (c: SIMD2<Float>, x: SIMD2<Float>, y: SIMD2<Float>)? = nil) -> Bool {
        let e = entry(step.def)
        guard let lib = e.lib,
              let pso = passes.pipeline(fragment: "effectFragment", library: lib, libKey: key(step.def),
                                        format: out.tex.pixelFormat) else { return false }
        var c = FxCommon()
        c.res = SIMD2(Float(out.width), Float(out.height))
        c.time = time
        c.has0 = step.in0 == nil ? 0 : 1
        c.has1 = step.in1 == nil ? 0 : 1
        let ar = Float(out.width) / Float(max(out.height, 1))
        if let r = rect { c.lc = r.c; c.lx = r.x; c.ly = r.y } else { c.lx = SIMD2(ar * 2, 0); c.ly = SIMD2(0, 2) }
        var flat = step.props
        for col in step.colors { flat += [col.x, col.y, col.z, col.w] }
        if flat.isEmpty { flat = [0] }
        passes.encode(cb, into: out, pso: pso) { enc in
            enc.setFragmentBytes(&c, length: MemoryLayout<FxCommon>.stride, index: 0)
            flat.withUnsafeBytes { enc.setFragmentBytes($0.baseAddress!, length: $0.count, index: 1) }
            enc.setFragmentTexture(src, index: 0)
            enc.setFragmentTexture(step.in0 ?? self.passes.dummy, index: 1)
            enc.setFragmentTexture(step.in1 ?? self.passes.dummy, index: 2)
        }
        return true
    }

    /// Ping-pong chain like SceneRenderer.applyEffects. Input is in `a`; returns the target holding the
    /// result. An effect that cannot run in Metal is skipped (passthrough, never a blank frame).
    func applyChain(_ cb: MTLCommandBuffer, steps: [Step], a: MetalTarget, b: MetalTarget, time: Float,
                    rect: (c: SIMD2<Float>, x: SIMD2<Float>, y: SIMD2<Float>)? = nil) -> MetalTarget {
        var read = a, write = b
        for s in steps where apply(cb, step: s, src: read.tex, out: write, time: time, rect: rect) {
            swap(&read, &write)
        }
        return read
    }

    /// Default parameter values of an effect (used by tests/thumbnails).
    static func defaultStep(_ d: EffectDef) -> Step {
        let cols = d.colors.map { cp -> SIMD4<Float> in
            let v = UInt32(bitPattern: cp.def)
            return SIMD4(Float((v >> 16) & 0xFF) / 255, Float((v >> 8) & 0xFF) / 255,
                         Float(v & 0xFF) / 255, Float((v >> 24) & 0xFF) / 255)
        }
        return Step(def: d, props: d.props.map { $0.def }, colors: cols)
    }

    // MARK: - cache + compile

    private func key(_ d: EffectDef) -> String {
        var h = Hasher()
        h.combine(d.msl ?? d.glsl)
        h.combine(d.props.map { $0.key }.joined(separator: ","))
        h.combine(d.colors.map { $0.key }.joined(separator: ","))
        h.combine(d.confinesToAlpha)
        return d.id + "#" + String(UInt(bitPattern: h.finalize()), radix: 16)
    }

    private func entry(_ d: EffectDef) -> Entry {
        let k = key(d)
        lock.lock()
        if let e = cache[k] { lock.unlock(); return e }
        lock.unlock()

        let e = Entry()
        if let m = d.msl, !m.isEmpty {
            e.native = true
            e.msl = m.contains("#include") ? m : MetalSL.header + m
        } else {
            e.msl = MetalEffects.translate(d)
        }
        do {
            e.lib = try passes.core.device.makeLibrary(source: e.msl, options: nil)
        } catch {
            e.error = String(String(describing: error).prefix(400))
        }
        lock.lock()
        cache[k] = e
        if e.lib != nil { if e.native { nativeCount += 1 } else { translatedCount += 1 } }
        else { failures[d.id] = e.error ?? "unknown" }
        lock.unlock()
        if let err = e.error { Registry.noteError(d.id, "Metal: " + err) }
        return e
    }

    // MARK: - GLSL -> MSL translator

    /// Names that are fine in GLSL but not in MSL/C++ (renamed with an `m_` prefix everywhere).
    private static let mslReserved: Set<String> = [
        "half", "select", "saturate", "fma", "rsqrt", "constant", "device", "thread", "threadgroup", "kernel",
        "vertex", "fragment", "uint", "ushort", "uchar", "char", "short", "long", "double", "new", "delete",
        "class", "this", "template", "namespace", "operator", "default", "auto", "register", "public",
        "private", "protected", "friend", "typename", "using", "static", "struct", "union", "enum", "case",
        "do", "goto", "break", "continue", "true", "false", "sizeof", "volatile", "signed", "unsigned",
        "bool", "half2", "half3", "half4", "float2", "float3", "float4", "int2", "int3", "int4", "metal",
        "fetch", "uTex", "uIn0", "uIn1", "uRes", "uTime", "uHas0", "uHas1", "uLC", "uLX", "uLY"
    ]

    static func translate(_ d: EffectDef) -> String {
        let (glsl, _) = Gl.effectShaderSource(d)
        var tail = glsl
        if let r = tail.range(of: "float luma(") { tail = String(tail[r.lowerBound...]) }    // drop header uniforms
        if let r = tail.range(of: "void main()", options: .backwards) { tail = String(tail[..<r.lowerBound]) }

        // member names (GLSL-reserved handled by Gl.uniformName; MSL-reserved by m_ prefix)
        func member(_ key: String) -> String {
            let n = Gl.uniformName(key)
            return mslReserved.contains(n) ? "m_" + n : n
        }
        for n in (d.props.map { Gl.uniformName($0.key) } + d.colors.map { Gl.uniformName($0.key) }) where mslReserved.contains(n) {
            if let re = try? NSRegularExpression(pattern: "(?<![A-Za-z0-9_.])" + n + "(?![A-Za-z0-9_])") {
                tail = re.stringByReplacingMatches(in: tail, range: NSRange(tail.startIndex..., in: tail), withTemplate: "m_" + n)
            }
        }

        // simple token rewrites
        tail = tail.replacingOccurrences(of: "texture2D(", with: "fetch(")
        tail = tail.replacingOccurrences(of: "inversesqrt(", with: "rsqrt(")
        tail = rewriteCalls(tail, name: "atan", argCount: 2, newName: "atan2")
        tail = rewriteCalls(tail, name: "mat2", argCount: 4, newName: "mat2_s")
        tail = rewriteCalls(tail, name: "mat3", argCount: 9, newName: "mat3_s")
        tail = rewriteCalls(tail, name: "mat4", argCount: 16, newName: "mat4_s")

        // top-level `const` declarations can't live inside the struct: hoist them as MSL `constant` globals
        var hoisted = "", body = ""
        var depth = 0
        for line in tail.components(separatedBy: "\n") {
            let t = line.trimmingCharacters(in: .whitespaces)
            if depth == 0 && t.hasPrefix("const ") && t.hasSuffix(";") {
                hoisted += "constant " + String(t.dropFirst(6)) + "\n"
            } else {
                body += line + "\n"
            }
            depth += line.filter { $0 == "{" }.count - line.filter { $0 == "}" }.count
        }

        var members = "", assign = "", idx = 0
        for p in d.props { members += "    float \(member(p.key));\n"; assign += "    x.\(member(p.key)) = P[\(idx)];\n"; idx += 1 }
        for c in d.colors {
            members += "    float4 \(member(c.key));\n"
            assign += "    x.\(member(c.key)) = float4(P[\(idx)], P[\(idx + 1)], P[\(idx + 2)], P[\(idx + 3)]);\n"
            idx += 4
        }
        var confine = ""
        if d.confinesToAlpha {
            confine = """
    float sa = x.fetch(t0, vUv).a;
    o.a = min(o.a, sa);
    o.rgb = clamp(o.rgb, 0.0, 1.0);
    o.rgb = min(o.rgb, float3(o.a));

"""
        }

        return MetalSL.header + """
typedef float2 vec2; typedef float3 vec3; typedef float4 vec4;
typedef float2x2 mat2; typedef float3x3 mat3; typedef float4x4 mat4;
template<typename T> inline T mod(T x, T y) { return x - y * floor(x / y); }
inline float2 mod(float2 x, float y) { return x - y * floor(x / y); }
inline float3 mod(float3 x, float y) { return x - y * floor(x / y); }
inline float4 mod(float4 x, float y) { return x - y * floor(x / y); }
inline float2x2 mat2_s(float a, float b, float c, float d) { return float2x2(float2(a, b), float2(c, d)); }
inline float3x3 mat3_s(float a, float b, float c, float d, float e, float f, float g, float h, float i) {
    return float3x3(float3(a, b, c), float3(d, e, f), float3(g, h, i)); }
inline float4x4 mat4_s(float a, float b, float c, float d, float e, float f, float g, float h,
                       float i, float j, float k, float l, float m, float n, float o, float p) {
    return float4x4(float4(a, b, c, d), float4(e, f, g, h), float4(i, j, k, l), float4(m, n, o, p)); }

""" + hoisted + """
struct FxCtx {
    texture2d<float> uTex; texture2d<float> uIn0; texture2d<float> uIn1;
    float2 uRes; float2 uLC; float2 uLX; float2 uLY; float uTime; float uHas0; float uHas1;
\(members)
    FxCtx(texture2d<float> a, texture2d<float> b, texture2d<float> c) : uTex(a), uIn0(b), uIn1(c) {}
    float4 fetch(texture2d<float> t, float2 uv) { return t.sample(linearClamp, float2(uv.x, 1.0 - uv.y)); }

""" + body + """
};

fragment float4 effectFragment(VOut in [[stage_in]], constant FxCommon& C [[buffer(0)]],
                               constant float* P [[buffer(1)]],
                               texture2d<float> t0 [[texture(0)]], texture2d<float> t1 [[texture(1)]],
                               texture2d<float> t2 [[texture(2)]]) {
    FxCtx x(t0, t1, t2);
    x.uRes = C.res; x.uLC = C.lc; x.uLX = C.lx; x.uLY = C.ly;
    x.uTime = C.time; x.uHas0 = C.has0; x.uHas1 = C.has1;
\(assign)    float2 vUv = in.uv;
    float4 o = x.effect(vUv);
\(confine)    return o;
}

"""
    }

    /// Rewrites `name(a, b, …)` calls that have exactly `argCount` top-level arguments to `newName(…)`.
    static func rewriteCalls(_ s: String, name: String, argCount: Int, newName: String) -> String {
        func isId(_ c: Character) -> Bool { c.isLetter || c.isNumber || c == "_" }
        let cs = Array(s), nc = Array(name)
        var out = ""
        out.reserveCapacity(cs.count + 64)
        var i = 0
        while i < cs.count {
            var matched = false
            if cs[i] == nc[0], i + nc.count < cs.count, Array(cs[i..<(i + nc.count)]) == nc,
               i == 0 || !(isId(cs[i - 1]) || cs[i - 1] == ".") {
                var j = i + nc.count
                if !isId(cs[j]) {
                    while j < cs.count, cs[j] == " " { j += 1 }
                    if j < cs.count, cs[j] == "(" {
                        var depth = 0, args = 1, k = j
                        while k < cs.count {
                            let c = cs[k]
                            if c == "(" || c == "[" { depth += 1 }
                            else if c == ")" || c == "]" { depth -= 1; if depth == 0 { break } }
                            else if c == "," && depth == 1 { args += 1 }
                            k += 1
                        }
                        if args == argCount { out += newName; i = j; matched = true }
                    }
                }
            }
            if !matched { out.append(cs[i]); i += 1 }
        }
        return out
    }
}
