import Foundation
import Metal
import UIKit

//  Stage 7c: FLARE layers in Metal (port of SceneRenderer.drawFlareLayer + the GL procedural flare shader).
//  The fragment shader is the GL one converted mechanically (vec -> float, mod -> glmod, atan -> atan2,
//  uniform arrays -> one float4 buffer: A, B, C, D, E, Col blocks of 16). Preview shades at half resolution
//  and upsamples, like GL; export stays full resolution.

enum MetalFlareSL {
    static let source = MetalSL.header + """
struct FlareU { float4 h0; float4 h1; float4 h2; float4 h3; };
inline float glmod(float x, float y) { return x - y * floor(x / y); }

float hn(float x) { return fract(sin(x * 127.1) * 43758.5453); }
float vn(float x) { float i = floor(x); float f = fract(x); f = f * f * (3.0 - 2.0 * f); return mix(hn(i), hn(i + 1.0), f); }
float3 hsv2rgb(float3 c) {
    float3 p = abs(fract(c.xxx + float3(1.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0);
    return c.z * mix(float3(1.0), clamp(p - 1.0, float3(0.0), float3(1.0)), float3(c.y));
}

// procedural iris: radius (vertex = 1) of the polygon / star / flower at angle a
float irisR(float a, float n, float round, float star, float curve) {
    float seg = 6.28318 / n;
    float t = glmod(a, seg);
    float hs = seg * 0.5;
    float phi = abs(t - hs);
    float cosH = cos(hs);
    float sinH = sin(hs);
    float inner = mix(cosH, 0.12, star);
    float den = cos(phi) * sinH - sin(phi) * (cosH - inner);
    float r = min(inner * sinH / max(den, 0.05), 2.0);
    float u = phi / hs;
    r *= 1.0 + curve * 0.25 * (1.0 - u * u);
    float rc = (inner + 1.0) * 0.5;
    return mix(r, rc, round);
}

float irisMask(float2 d, float size, float n, float round, float star, float curve,
               float thick, float soft, float grad) {
    float a = atan2(d.y, d.x) + 1.5708;
    float R = irisR(a, n, round, star, curve) * size;
    float x = length(d) / max(R, 0.0001);
    float edge = 0.02 + soft * 0.6;
    float outer = 1.0 - smoothstep(1.0 - edge, 1.0, x);
    float hole = mix(smoothstep(1.0 - thick - edge, 1.0 - thick + 0.001, x), 1.0, step(0.99, thick));
    return outer * hole * mix(1.0, x * x, grad);
}

fragment float4 flareFragment(VOut in [[stage_in]], constant FlareU& u [[buffer(0)]], constant float4* arr [[buffer(1)]]) {
    float2 uLight = u.h0.xy; float uIntensity = u.h0.z; float uAxis = u.h0.w;
    float uSizeMul = u.h1.x; float uEdgeFade = u.h1.y; float uAspect = u.h1.z; float uCount = u.h1.w;
    float uTime = u.h2.x; float uFlicker = u.h2.y; float uSpeed = u.h2.z; float uRayAmt = u.h2.w;
    float3 uTintRgb = u.h3.xyz;
    float2 asp = float2(uAspect, 1.0);
    float2 p = in.uv * asp;
    float2 L = uLight * asp;
    float2 ax = (float2(0.5) * asp - L) * uAxis;
    float axLen = length(ax);
    float axAng = atan2(ax.y, ax.x);
    float3 acc = float3(0.0);

    for (int i = 0; i < 16; i++) {
        float t = arr[0 + i].x;
        if (t < -0.5 || float(i) + 0.5 > uCount) { continue; }
        float pos = arr[0 + i].y;
        float size = min(arr[0 + i].z * uSizeMul, 3.0);
        float bright = arr[16 + i].x;
        float soft = arr[16 + i].y;
        float thick = arr[16 + i].z;
        float stretch = arr[16 + i].w;
        float sides = arr[32 + i].x;
        float rays = arr[32 + i].y;
        float chroma = arr[32 + i].z;
        float follow = arr[32 + i].w;
        float noise = arr[64 + i].x;

        float ang = radians(arr[0 + i].w) + follow * axAng * smoothstep(0.03, 0.3, axLen) + arr[64 + i].y * 1.2 * axLen;
        float2 d = p - (L + ax * pos);
        float ca = cos(ang);
        float sa = sin(ang);
        d = float2(ca * d.x + sa * d.y, -sa * d.x + ca * d.y);
        float r = length(d);

        // PERFORMANCE: skip every pixel that is outside the element's reach. Without this each
        // pixel evaluated up to 16 elements (atan/pow/iris x3, multi-iris x8) -> heavy lag.
        bool multi = t > 13.5 && t < 14.5;
        if (!multi && r > size * max(stretch, 1.0) * 2.6 + 0.01) { continue; }
        if (bright * uIntensity < 0.002) { continue; }

        float3 m = float3(0.0);
        if (t < 0.5) {                                  // Glow
            float2 q = float2(d.x / stretch, d.y);
            float x = length(q) / max(size, 0.001);
            float g = exp(-pow(x, mix(2.0, 0.85, soft)) * 4.5) * (1.0 - smoothstep(0.85, 1.0, x));
            // real lens glare: hot core + long inverse-square wings (like the reference photos)
            float wing = (1.0 / (1.0 + x * x * 24.0)) * (1.0 - smoothstep(0.55, 1.0, x));
            g = mix(g, g * 0.6 + wing * 0.5, soft);
            m = float3(g);
        } else if (t < 1.5 || (t > 4.5 && t < 5.5) || (t > 12.5 && t < 13.5)) {   // Polygon / Ring polygon / Iris
            float st = 0.0; float rd = 0.0; float cv = 0.0; float gr = arr[48 + i].w; float th = thick; float sf = soft;
            if (t > 12.5) { rd = arr[48 + i].x; st = arr[48 + i].y; cv = arr[48 + i].z; }
            else { th = t < 1.5 ? max(thick, 0.3) : thick; gr = 0.3; sf = 0.12; }
            float2 q = float2(d.x / stretch, d.y);
            float k = chroma * 0.07;
            m = float3(irisMask(q, size * (1.0 + k), sides, rd, st, cv, th, sf, gr),
                     irisMask(q, size, sides, rd, st, cv, th, sf, gr),
                     irisMask(q, size * (1.0 - k), sides, rd, st, cv, th, sf, gr));
            if (chroma > 0.01) { m *= float3(1.0, 0.85, 1.0); }
        } else if (t < 2.5) {                            // Line
            float2 s = float2(size * stretch * 0.5, size * 0.5 * max(thick, 0.01));
            float2 qq = abs(d) - s;
            float e = 0.004 + soft * 0.03;
            m = float3(1.0 - smoothstep(-e, e, length(max(qq, float2(0.0))) + min(max(qq.x, qq.y), 0.0)));
        } else if (t < 3.5) {                            // Rays (soft beams)
            float n = max(rays, 2.0);
            float a = atan2(d.y, d.x);
            float beam = pow(abs(cos(a * n * 0.5)), 28.0);
            float rad = exp(-r / max(size * 0.35, 0.001)) * (1.0 - smoothstep(size * 0.6, size, r));
            m = float3(beam * rad * 0.7 * uRayAmt);
        } else if (t < 4.5) {                            // Ring
            float R = size * 0.5;
            float w = max(thick, 0.01) * R;
            float e = 0.004 + soft * 0.02;
            float k = chroma * 0.06;
            float3 rr = float3(r / (1.0 + k), r, r / (1.0 - k));
            if (thick >= 0.95) { m = 1.0 - smoothstep(float3(R * (1.0 - soft * 0.5) - e), float3(R + e), rr); }
            else { m = 1.0 - smoothstep(float3(w * 0.5 - e), float3(w * 0.5 + e), abs(rr - R)); }
        } else if (t < 6.5) {                            // Dot
            float R = size * 0.5;
            m = float3(1.0 - smoothstep(R * (1.0 - soft * 0.8), R, r));
        } else if (t < 7.5) {                            // Glint: smooth starburst
            float n = max(rays, 2.0);
            float a = atan2(d.y, d.x);
            float seg = 6.28318 / n;
            float idx = glmod(floor(a / seg + 0.5), n);
            float fr = (fract(a / seg + 0.5) - 0.5) * seg;
            float lenv = mix(1.0, 0.6 + 0.4 * hn(idx * 3.7 + arr[64 + i].z), noise * 0.6);
            float len = size * 0.5 * lenv;
            float w = mix(0.018, 0.075, soft);
            float beam = exp(-(fr * fr) / (w * w));
            float rad = exp(-r / max(len * 0.45, 0.001)) * (1.0 - smoothstep(len * 0.55, len, r));
            float core = exp(-r / max(size * 0.05, 0.001)) * 0.7;
            m = float3(beam * rad * 0.8 * uRayAmt + core);
        } else if (t < 8.5) {                            // Hoop
            float R = size * 0.5;
            float w = max(thick, 0.02) * R * 0.5;
            float k = chroma * 0.07;
            float3 rr = float3(r / (1.0 + k), r, r / (1.0 - k));
            float3 z = (rr - R) / w;
            m = exp(-z * z * (1.0 + (1.0 - soft) * 3.0));
        } else if (t < 9.5) {                            // Streak (anamorphic)
            float len = size * stretch * 0.5;
            float wy = size * 0.5 * max(thick, 0.01) * 0.35 + 0.002;
            float hx = exp(-abs(d.x) / max(len * (0.12 + 0.5 * soft), 0.001));
            float vy = exp(-(d.y / wy) * (d.y / wy));
            m = float3(hx * vy * (1.0 - smoothstep(len * 0.8, len * 1.2, abs(d.x))));
        } else if (t < 10.5) {                           // Spike ball: fine smooth spikes
            float n = max(rays, 3.0) * 2.0;
            float a = atan2(d.y, d.x);
            float seg = 6.28318 / n;
            float idx = glmod(floor(a / seg + 0.5), n);
            float fr = (fract(a / seg + 0.5) - 0.5) * seg;
            float lenv = mix(1.0, 0.45 + 0.55 * hn(idx * 5.3 + arr[64 + i].z), noise * 0.7);
            float len = size * 0.5 * lenv;
            float w = mix(0.012, 0.04, soft);
            float beam = exp(-(fr * fr) / (w * w));
            float rad = exp(-r / max(len * 0.4, 0.001)) * (1.0 - smoothstep(len * 0.6, len, r));
            float core = exp(-pow(r / max(size * 0.12, 0.001), 1.2) * 2.0);
            m = float3(beam * rad * 0.6 * uRayAmt + core * 0.9);
        } else if (t < 11.5) {                           // Rainbow
            float x = r / max(size * 0.5, 0.001);
            float inner = 1.0 - thick * 0.7;
            float band = smoothstep(inner, inner + 0.12, x) * (1.0 - smoothstep(0.92, 1.0, x));
            float3 spec = hsv2rgb(float3(clamp((1.0 - (x - inner) / max(1.0 - inner, 0.05)) * 0.75, 0.0, 0.8), 0.9, 1.0));
            m = band * mix(float3(1.0), spec, float3(0.25 + 0.75 * chroma));
        } else if (t > 14.5) {                           // Arc: partial lens ring with colour fringe
            float R = size * 0.5;
            float w = max(thick, 0.02) * R * 0.5;
            float k = chroma * 0.07;
            float3 rr = float3(r / (1.0 + k), r, r / (1.0 - k));
            float3 z = (rr - R) / w;
            float aa = atan2(d.y, d.x);
            float hs = clamp(arr[64 + i].w, 0.02, 1.0) * 3.14159;
            float am = 1.0 - smoothstep(hs * (1.0 - soft), hs, abs(aa));
            m = exp(-z * z * (1.0 + (1.0 - soft) * 3.0)) * am;
        } else if (t > 13.5) {                           // Multi iris: a chain of ghost irises
            float cnt = clamp(rays, 2.0, 8.0);
            float3 mm = float3(0.0);
            for (int k = 0; k < 8; k++) {
                float fk = float(k);
                if (fk + 0.5 > cnt) { break; }
                float h1 = hn(fk * 12.9 + arr[64 + i].z);
                float h2 = hn(fk * 7.7 + arr[64 + i].z + 3.0);
                float2 dk = p - (L + ax * (pos + fk * arr[64 + i].w));
                dk = float2(ca * dk.x + sa * dk.y, -sa * dk.x + ca * dk.y);
                float szk = size * (1.0 - noise * 0.6 * h1) * (1.0 - 0.06 * fk);
                float mk = irisMask(float2(dk.x / stretch, dk.y), szk, sides, arr[48 + i].x, arr[48 + i].y, arr[48 + i].z,
                                    max(thick, 0.05), soft, arr[48 + i].w);
                float3 spec = hsv2rgb(float3(fract(0.08 + fk * 0.17 + h2 * 0.1), 0.65, 1.0));
                float3 tk = mix(float3(1.0), spec, float3(chroma * 0.9));
                mm += mk * tk * (0.55 + 0.45 * h2) / (1.0 + 0.12 * fk);
            }
            m = mm;
        } else {                                         // Shimmer
            float x = r / max(size, 0.001);
            float a = atan2(d.y, d.x);
            float g = exp(-pow(x, 1.2) * 3.5) * (1.0 - smoothstep(0.9, 1.0, x));
            float nz = vn(a * rays * 0.35 + 20.0 + uTime * uSpeed * 1.2) * 0.7
                     + vn(a * rays * 0.9 + uTime * uSpeed * 2.3) * 0.5;
            m = float3(g * (0.45 + nz * 1.1 * (0.25 + noise)));
        }

        float fl = 1.0 + uFlicker * (vn(uTime * uSpeed * 9.0 + float(i) * 3.1) - 0.5) * 0.7;
        acc += arr[80 + i].rgb * uTintRgb * m * bright * fl;
    }

    // the whole flare fades as the light leaves the frame
    float2 lp = uLight;
    float outside = max(max(-lp.x, lp.x - 1.0), max(-lp.y, lp.y - 1.0));
    outside = max(outside - 0.12, 0.0);                 // never fades while the light is on or near the frame
    float vis = 1.0 - smoothstep(0.0, max(uEdgeFade, 0.05) + 0.25, outside);
    acc = clamp(acc, float3(0.0), float3(60.0)) * uIntensity * vis;

    // soft highlight roll-off keeps hot colours from clipping to flat white
    float3 o = float3(1.0) - exp(-acc * 1.1);
    float lum = max(o.r, max(o.g, o.b));
    o = mix(o, float3(lum), float3(smoothstep(0.55, 1.0, lum) * 0.45));   // hot cores bleed to white like film
    float dn = fract(52.9829189 * fract(dot(in.pos.xy, float2(0.06711056, 0.00583715)))) - 0.5;
    o = max(o + dn * (1.0 / 255.0) * step(float3(0.002), o), float3(0.0));
    return float4(o, max(o.r, max(o.g, o.b)));
}

"""
}

struct FlareU {
    var h0 = SIMD4<Float>(), h1 = SIMD4<Float>(), h2 = SIMD4<Float>(), h3 = SIMD4<Float>()
}

final class MetalFlareRenderer {
    private let core: MetalCore
    private let passes: MetalPasses
    private var lib: MTLLibrary?
    private var halfT: MetalTarget?

    init(_ core: MetalCore, _ passes: MetalPasses) {
        self.core = core
        self.passes = passes
        lib = try? core.device.makeLibrary(source: MetalFlareSL.source, options: nil)
    }

    var ready: Bool { lib != nil }

    func trimMemory() { halfT = nil }

    private func projectPoint(_ vp: [Float], _ x: Float, _ y: Float, _ z: Float) -> (Float, Float, Float) {
        let cx = vp[0] * x + vp[4] * y + vp[8] * z + vp[12]
        let cy = vp[1] * x + vp[5] * y + vp[9] * z + vp[13]
        let cw = vp[3] * x + vp[7] * y + vp[11] * z + vp[15]
        return (cx / max(abs(cw), 0.0001), cy / max(abs(cw), 0.0001), cw)
    }

    private func rgb(_ c: Int32) -> SIMD4<Float> {
        let v = UInt32(bitPattern: c)
        return SIMD4(Float((v >> 16) & 0xFF) / 255, Float((v >> 8) & 0xFF) / 255, Float(v & 0xFF) / 255, 1)
    }

    /// Draws flare layer `l` into `a` (the caller has cleared it).
    func draw(_ l: Layer, time: Float, fov: Float, isExport: Bool, into a: MetalTarget, cb: MTLCommandBuffer) {
        guard ready, let f = l.flare, let lb = lib else { return }
        let tw = a.width, th = a.height
        let ar = Float(tw) / Float(max(th, 1))
        let lt = l.editTime("x", time)
        var wx = l.p("x", lt), wy = l.p("y", lt)
        var visible: Float = 1
        var sizeMul: Float = 1

        if l.is3d {
            // real 3D light: projected through the camera; grows/shrinks with distance, hidden behind it
            let z = Xf.worldZ(l, time)
            let vp = MetalCam.vpForModel(l, fov: fov, time: time, width: tw, height: th)
            guard vp.count == 16 else { return }
            let (nx, ny, pw) = projectPoint(vp, wx, wy, z)
            let (_, _, pw0) = projectPoint(vp, 0, 0, 0)
            if pw <= 0.01 { visible = 0 }
            sizeMul = 1 + (min(max(pw0 / max(pw, 0.01), 0.15), 6) - 1) * f.depthScale
            wx = nx * ar; wy = ny
        } else if l.parentId >= 0 {
            let m = Xf.matrix(l, time)
            wx = m[4]; wy = m[5]
        }
        let lightX = wx / ar / 2 + 0.5       // 0..1 across the canvas
        let lightY = 0.5 - wy / 2
        let intensity = l.p("fIntensity", lt) * visible
        let axis = l.p("fAxis", lt)
        if intensity <= 0.0005 { return }          // invisible (behind the camera / zero): skip the heavy shader

        let n = min(f.els.count, min(FlareEl.MAX, 16))
        var u = FlareU()
        u.h0 = SIMD4(lightX, lightY, intensity, axis)
        u.h1 = SIMD4(sizeMul, f.edgeFade, ar, Float(n))
        u.h2 = SIMD4(time, f.flicker, f.speed, f.rayAmt)
        u.h3 = rgb(f.tint)
        var arr = [SIMD4<Float>](repeating: SIMD4<Float>(0, 0, 0, 0), count: 96)
        for i in 0..<16 {
            guard i < n else { arr[i] = SIMD4(-1, 0, 0, 0); continue }
            let e = f.els[i]
            arr[i] = SIMD4(Float(e.enabled ? e.type : -1), e.pos, e.size, e.rot)
            arr[16 + i] = SIMD4(e.bright, e.soft, e.thick, max(e.stretch, 0.05))
            arr[32 + i] = SIMD4(Float(e.sides), Float(e.rays), e.chroma, e.follow ? 1 : 0)
            arr[48 + i] = SIMD4(e.round, e.star, e.curve, e.grad)
            arr[64 + i] = SIMD4(e.noise, e.spin, Float(i) * 7.31 + 1.7, e.spread)
            arr[80 + i] = rgb(e.color)
        }

        func run(_ tgt: MetalTarget) {
            guard let pso = passes.pipeline(fragment: "flareFragment", library: lb, libKey: "flare",
                                            format: tgt.tex.pixelFormat) else { return }
            passes.encode(cb, into: tgt, pso: pso) { enc in
                enc.setFragmentBytes(&u, length: MemoryLayout<FlareU>.stride, index: 0)
                arr.withUnsafeBytes { enc.setFragmentBytes($0.baseAddress!, length: $0.count, index: 1) }
            }
        }

        if !isExport && tw >= 64 {
            // Preview: flares are smooth light, so shade them at half resolution and upsample.
            if halfT == nil || halfT!.width != tw / 2 || halfT!.height != th / 2 {
                halfT = MetalTarget(core, tw / 2, th / 2)
            }
            if let ft = halfT {
                run(ft)
                _ = passes.blit(cb, src: ft.tex, to: a)
                return
            }
        }
        run(a)
    }
}
