//  MetalGlow.swift
//  Metal migration stage 5b: Deep Glow (port of SceneRenderer.applyDeepGlow).
//
//  bright pass -> half-res level 0 -> downsample chain -> separable Gaussian per level ->
//  weighted accumulate from the deepest level up -> final composite (tint / chroma / dither).
//  All intermediate levels are rgba16Float. UVs are GL-style (bottom-left origin) and every
//  texture read goes through flipV, like the other Metal passes.

import Foundation
import Metal
import UIKit

enum MetalGlowSL {
    static let source = MetalSL.header + """
struct GlowExtractU { float2 px; float thr; float knee; };
struct GlowFinalU { float4 tint; float gain; float chroma; float only; float tintAmt; float2 res; float2 pad; };

inline float4 glowTap(texture2d<float> t, float2 uv, float thr, float knee0) {
    float4 c = min(t.sample(linearClamp, flipV(uv)), float4(16.0));
    float l = max(max(c.r, c.g), c.b);
    float knee = thr * knee0 + 0.0001;
    float sf = clamp(l - thr + knee, 0.0, 2.0 * knee);
    sf = sf * sf / (4.0 * knee);
    float k = max(sf, l - thr) / max(l, 0.0001);
    return c * clamp(k, 0.0, 1.0);
}

fragment float4 glowExtract(VOut in [[stage_in]], constant GlowExtractU& u [[buffer(0)]],
                            texture2d<float> t [[texture(0)]]) {
    float2 o = u.px * 0.5;
    float2 v = in.uv;
    float4 a = glowTap(t, v + float2(-o.x, -o.y), u.thr, u.knee) + glowTap(t, v + float2(o.x, -o.y), u.thr, u.knee)
             + glowTap(t, v + float2(-o.x, o.y), u.thr, u.knee) + glowTap(t, v + float2(o.x, o.y), u.thr, u.knee);
    return a * 0.25;
}

fragment float4 glowDown(VOut in [[stage_in]], constant float2& px [[buffer(0)]],
                         texture2d<float> t [[texture(0)]]) {
    float2 o = px * 0.5;
    float2 v = in.uv;
    return (t.sample(linearClamp, flipV(v + float2(-o.x, -o.y))) + t.sample(linearClamp, flipV(v + float2(o.x, -o.y)))
          + t.sample(linearClamp, flipV(v + float2(-o.x, o.y))) + t.sample(linearClamp, flipV(v + float2(o.x, o.y)))) * 0.25;
}

fragment float4 glowBlur(VOut in [[stage_in]], constant float2& st [[buffer(0)]],
                         texture2d<float> t [[texture(0)]]) {
    float2 v = in.uv;
    float4 c = t.sample(linearClamp, flipV(v)) * 0.2270270270;
    c += (t.sample(linearClamp, flipV(v + st * 1.3846153846)) + t.sample(linearClamp, flipV(v - st * 1.3846153846))) * 0.3162162162;
    c += (t.sample(linearClamp, flipV(v + st * 3.2307692308)) + t.sample(linearClamp, flipV(v - st * 3.2307692308))) * 0.0702702703;
    return c;
}

fragment float4 glowScale(VOut in [[stage_in]], constant float& w [[buffer(0)]],
                          texture2d<float> a [[texture(0)]]) {
    return a.sample(linearClamp, flipV(in.uv)) * w;
}

fragment float4 glowUp(VOut in [[stage_in]], constant float& w [[buffer(0)]],
                       texture2d<float> a [[texture(0)]], texture2d<float> b [[texture(1)]]) {
    float2 v = flipV(in.uv);
    return a.sample(linearClamp, v) * w + b.sample(linearClamp, v);
}

inline bool glowBad(float x) { return (as_type<uint>(x) & 0x7fffffffu) > 0x7f800000u; }

fragment float4 glowFinal(VOut in [[stage_in]], constant GlowFinalU& u [[buffer(0)]],
                          texture2d<float> tex [[texture(0)]], texture2d<float> tg [[texture(1)]]) {
    float2 vUv = in.uv;
    float4 c = tex.sample(linearClamp, flipV(vUv));
    float4 g = tg.sample(linearClamp, flipV(vUv));
    if (u.chroma > 0.001) {
        float2 dir = (vUv - 0.5) * u.chroma * 0.04;
        g.r = tg.sample(linearClamp, flipV(vUv + dir)).r;
        g.b = tg.sample(linearClamp, flipV(vUv - dir)).b;
    }
    g = clamp(g * u.gain, 0.0, 64.0);
    if (glowBad(g.r) || glowBad(g.g) || glowBad(g.b) || glowBad(g.a)) { g = float4(0.0); }
    float gl = max(g.r, max(g.g, g.b));
    g.rgb = mix(g.rgb, u.tint.rgb * gl, u.tintAmt);
    float3 add = g.rgb / (1.0 + g.rgb * 0.18);
    float2 fc = float2(in.pos.x, u.res.y - in.pos.y);          // GL-style fragment coordinate
    float n = fract(52.9829189 * fract(dot(fc, float2(0.06711056, 0.00583715)))) - 0.5;
    add += n * (1.0 / 255.0) * min(1.0, g.a * 4.0);
    add = max(add, 0.0);
    float base = u.only > 0.5 ? 0.0 : 1.0;
    float3 rgb = c.rgb * base + add;
    float ga = max(clamp(g.a, 0.0, 1.0), max(add.r, max(add.g, add.b)));
    float a = clamp(c.a * base + ga * (1.0 - c.a * base), 0.0, 1.0);
    return float4(rgb, a);
}
"""
}

private struct GlowExtractU { var px: SIMD2<Float>; var thr: Float; var knee: Float }
private struct GlowFinalU {
    var tint: SIMD4<Float>
    var gain: Float, chroma: Float, only: Float, tintAmt: Float
    var res: SIMD2<Float>
    var pad: SIMD2<Float> = .zero
}

final class MetalGlow {
    static let N = 7

    /// Raw Deep Glow parameters (same meaning as the GL effect's props).
    struct Params {
        var radius: Float = 0.12, intensity: Float = 1, threshold: Float = 0.3, knee: Float = 0.5
        var falloff: Float = 0.5, tintAmt: Float = 0, tintHue: Float = 0.08, chroma: Float = 0, glowOnly: Float = 0
        /// >1 when the glow input was blurred (motion blur / blur effects dim the bright pass).
        var blurComp: Float = 1
    }

    private let core: MetalCore
    private let passes: MetalPasses
    private var lib: MTLLibrary?
    private(set) var buildError: String?
    private var levels: [MetalTarget] = []
    private var tmp: [MetalTarget] = []
    private var blur: [MetalTarget] = []
    private var size = (0, 0)

    init?(_ p: MetalPasses) {
        core = p.core
        passes = p
        do {
            lib = try p.core.device.makeLibrary(source: MetalGlowSL.source, options: nil)
        } catch {
            buildError = String(String(describing: error).prefix(400))
        }
    }

    var ready: Bool { lib != nil }

    func trimMemory() { levels = []; tmp = []; blur = []; size = (0, 0) }

    private func ensure(_ w: Int, _ h: Int) {
        if size == (w, h), !levels.isEmpty { return }
        levels = []; tmp = []; blur = []
        for k in 0..<MetalGlow.N {
            let div = 2 << k
            let lw = max(2, w / div), lh = max(2, h / div)
            levels.append(MetalTarget(core, lw, lh, half: true))
            tmp.append(MetalTarget(core, lw, lh, half: true))
            blur.append(MetalTarget(core, lw, lh, half: true))
        }
        size = (w, h)
    }

    private func pass(_ cb: MTLCommandBuffer, _ frag: String, into t: MetalTarget,
                      _ setup: (MTLRenderCommandEncoder) -> Void) -> Bool {
        guard let l = lib, let pso = passes.pipeline(fragment: frag, library: l, libKey: "glow",
                                                     format: t.tex.pixelFormat) else { return false }
        passes.encode(cb, into: t, pso: pso, setup)
        return true
    }

    /// Runs Deep Glow: src -> out. Returns false (nothing useful written) when a shader is missing.
    func apply(_ cb: MTLCommandBuffer, p: Params, src: MTLTexture, out: MetalTarget) -> Bool {
        guard lib != nil else { return false }
        ensure(out.width, out.height)
        let N = MetalGlow.N
        let comp = p.blurComp
        let radius = max(0, p.radius)
        let intensity = max(0, p.intensity)
        let thr = min(max(p.threshold, 0), 0.999) / comp
        let knee = min(max(p.knee, 0), 1)
        let falloff = min(max(p.falloff, 0), 1)
        let tintAmt = min(max(p.tintAmt, 0), 1)
        let chromaAb = min(max(p.chroma, 0), 1)

        // 1) bright pass -> level 0 (half res)
        var ex = GlowExtractU(px: SIMD2(1 / Float(out.width), 1 / Float(out.height)), thr: thr, knee: knee)
        guard pass(cb, "glowExtract", into: levels[0], { enc in
            enc.setFragmentBytes(&ex, length: MemoryLayout<GlowExtractU>.stride, index: 0)
            enc.setFragmentTexture(src, index: 0)
        }) else { return false }

        // level weights follow the radius continuously (log-space gaussian) — same maths as GL
        let sigmaPx = max(radius, 0.0005) * Float(out.height) * 0.2
        let pos = min(max(log2(max(sigmaPx, 1) / 4), 0), Float(N - 1))
        var w = [Float](repeating: 0, count: N)
        for k in 0..<N {
            let dk = Float(k) - pos
            let sg = 0.55 + falloff * 1.6
            w[k] = exp(-dk * dk / (2 * sg * sg))
        }
        let wMax = max(w.max() ?? 1, 0.0001)
        for k in 0..<N { w[k] = w[k] / wMax * 0.9 }
        let minW: Float = 0.035
        var top = 0
        for k in 0..<N where w[k] > minW { top = k }

        // 2) downsample chain
        if top >= 1 {
            for k in 1...top {
                var px = SIMD2<Float>(1 / Float(levels[k - 1].width), 1 / Float(levels[k - 1].height))
                _ = pass(cb, "glowDown", into: levels[k], { enc in
                    enc.setFragmentBytes(&px, length: MemoryLayout<SIMD2<Float>>.stride, index: 0)
                    enc.setFragmentTexture(self.levels[k - 1].tex, index: 0)
                })
            }
        }

        // 3) separable Gaussian on every used level
        for k in 0...top where w[k] > minW || k == 0 {
            let lv = levels[k]
            var sx = SIMD2<Float>(1 / Float(lv.width), 0)
            _ = pass(cb, "glowBlur", into: tmp[k], { enc in
                enc.setFragmentBytes(&sx, length: MemoryLayout<SIMD2<Float>>.stride, index: 0)
                enc.setFragmentTexture(lv.tex, index: 0)
            })
            var sy = SIMD2<Float>(0, 1 / Float(lv.height))
            _ = pass(cb, "glowBlur", into: blur[k], { enc in
                enc.setFragmentBytes(&sy, length: MemoryLayout<SIMD2<Float>>.stride, index: 0)
                enc.setFragmentTexture(self.tmp[k].tex, index: 0)
            })
        }

        // 4) accumulate from the deepest used level up (results go into tmp[k], free after the blur)
        var acc = -1
        for k in stride(from: top, through: 0, by: -1) where w[k] > minW || k == 0 {
            var wk = w[k]
            if acc < 0 {
                _ = pass(cb, "glowScale", into: tmp[k], { enc in
                    enc.setFragmentBytes(&wk, length: MemoryLayout<Float>.stride, index: 0)
                    enc.setFragmentTexture(self.blur[k].tex, index: 0)
                })
            } else {
                let prev = tmp[acc].tex
                _ = pass(cb, "glowUp", into: tmp[k], { enc in
                    enc.setFragmentBytes(&wk, length: MemoryLayout<Float>.stride, index: 0)
                    enc.setFragmentTexture(self.blur[k].tex, index: 0)
                    enc.setFragmentTexture(prev, index: 1)
                })
            }
            acc = k
        }

        // 5) final composite
        var tr: CGFloat = 1, tg: CGFloat = 1, tb: CGFloat = 1, ta: CGFloat = 1
        UIColor(hue: CGFloat(p.tintHue - floor(p.tintHue)), saturation: 1, brightness: 1, alpha: 1)
            .getRed(&tr, green: &tg, blue: &tb, alpha: &ta)
        var fu = GlowFinalU(tint: SIMD4(Float(tr), Float(tg), Float(tb), 1),
                            gain: intensity * 1.6 * (1 + (comp - 1) * 0.6), chroma: chromaAb,
                            only: p.glowOnly, tintAmt: tintAmt,
                            res: SIMD2(Float(out.width), Float(out.height)))
        let glowTex = tmp[max(acc, 0)].tex
        return pass(cb, "glowFinal", into: out, { enc in
            enc.setFragmentBytes(&fu, length: MemoryLayout<GlowFinalU>.stride, index: 0)
            enc.setFragmentTexture(src, index: 0)
            enc.setFragmentTexture(glowTex, index: 1)
        })
    }
}
