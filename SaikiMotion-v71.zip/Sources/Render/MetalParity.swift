//  MetalParity.swift
//  Stage 3 verification: renders the same synthetic inputs through the GL passes and the Metal passes
//  (blit, composite modes/masks, every registered effect at default params) and compares the pixels.

import Foundation
import Metal
import OpenGLES
import UIKit

enum MetalParity {
    static var lastSummary = "parity: not run yet"
    static var lastReport = ""
    private static let W = 96, H = 64
    private static let tol = 6          // max per-channel difference (of 255) still counted as a match

    // top-row-first premultiplied RGBA test pattern
    private static func pattern(_ seed: Int, flipRows: Bool) -> [UInt8] {
        var px = [UInt8](repeating: 0, count: W * H * 4)
        for y in 0..<H {
            for x in 0..<W {
                let fx = Float(x) / Float(W), fy = Float(y) / Float(H)
                let dx = fx - 0.5, dy = fy - 0.5
                let a = max(0, min(1, 1 - (dx * dx + dy * dy) * (seed == 0 ? 3.0 : 2.2)))
                let chk: Float = ((x / 8 + y / 8) % 2 == 0) ? 0.9 : 0.2
                let r = (seed == 0 ? fx : 1 - fx) * a, g = fy * a, b = chk * a
                let row = flipRows ? (H - 1 - y) : y
                let o = (row * W + x) * 4
                px[o] = UInt8(r * 255 + 0.5); px[o + 1] = UInt8(g * 255 + 0.5)
                px[o + 2] = UInt8(b * 255 + 0.5); px[o + 3] = UInt8(a * 255 + 0.5)
            }
        }
        return px
    }

    private static func bytes(_ img: UIImage?) -> [UInt8]? {
        guard let cg = img?.cgImage else { return nil }
        var px = [UInt8](repeating: 0, count: cg.width * cg.height * 4)
        let ok = px.withUnsafeMutableBytes { raw -> Bool in
            guard let ctx = CGContext(data: raw.baseAddress, width: cg.width, height: cg.height, bitsPerComponent: 8,
                                      bytesPerRow: cg.width * 4, space: CGColorSpaceCreateDeviceRGB(),
                                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            ctx.draw(cg, in: CGRect(x: 0, y: 0, width: cg.width, height: cg.height))
            return true
        }
        return ok ? px : nil
    }

    private static func diff(_ a: [UInt8]?, _ b: [UInt8]?) -> (max: Int, mean: Double)? {
        guard let a = a, let b = b, a.count == b.count, !a.isEmpty else { return nil }
        var mx = 0, sum = 0
        for i in 0..<a.count { let d = abs(Int(a[i]) - Int(b[i])); mx = max(mx, d); sum += d }
        return (mx, Double(sum) / Double(a.count))
    }

    private static func glTex(_ seed: Int) -> GLuint {
        var px = pattern(seed, flipRows: true)
        return px.withUnsafeMutableBytes { Gl.makeTexture(W, H, $0.baseAddress) }
    }

    /// Runs everything on a background queue (own GL context); calls `done` on the main queue.
    static func run(done: @escaping (String) -> Void) {
        DispatchQueue.global(qos: .userInitiated).async {
            let text = runSync()
            DispatchQueue.main.async { done(text) }
        }
    }

    static func runSync() -> String {
        guard let passes = MetalPasses.shared, let fx = MetalEffects.shared else { return "Metal not available" }
        if let e = passes.buildError { lastSummary = "parity: pass shaders failed"; return "Pass shaders failed to compile:\n" + e }
        guard let ctx = GLContext.make() else { return "No GL context" }
        let prev = EAGLContext.current()
        EAGLContext.setCurrent(ctx)
        var r = compare(passes, fx)      // GL targets are released inside, while the context is current
        let sceneLines = sceneParity()   // stage 4: GL vs Metal 2D scenes
        r += "\n" + sceneLines.joined(separator: "\n")
        lastReport = r
        lastSummary += " | " + sceneSummary(sceneLines)
        EAGLContext.setCurrent(prev)
        return r
    }

    private static func compare(_ passes: MetalPasses, _ fx: MetalEffects) -> String {
        var lines: [String] = []
        var bad = 0, good = 0
        func record(_ name: String, _ d: (max: Int, mean: Double)?) {
            guard let d = d else { lines.append("\(name): readback failed"); bad += 1; return }
            if d.max <= tol { good += 1 } else {
                bad += 1
                lines.append("\(name): max \(d.max) mean \(String(format: "%.2f", d.mean))")
            }
        }

        let gScene = glTex(1), gSrc = glTex(0), gMask = glTex(1)
        let mScene = passes.makeTexture(width: W, height: H, rgba: pattern(1, flipRows: false))!
        let mSrc = passes.makeTexture(width: W, height: H, rgba: pattern(0, flipRows: false))!
        let mMask = mScene
        let gOut = Gl.Target(W, H)
        let mOut = MetalTarget(passes.core, W, H)

        // blit
        if let bp = GLProgram(vertex: GLProgram.defaultVertex, fragment:
            "precision highp float; varying vec2 vUv; uniform sampler2D uTex; void main() { gl_FragColor = texture2D(uTex, vUv); }") {
            gOut.bind(); glDisable(GLenum(GL_BLEND)); bp.use(); bp.setTexture("uTex", gSrc, 0); Gl.drawFull(bp)
            let g = bytes(gOut.readImage())
            passes.runSync { _ = passes.blit($0, src: mSrc, to: mOut) }
            record("blit", diff(g, bytes(mOut.readImage())))
        }

        // composite: blend modes, masks, rgb shift
        if let cp = GLProgram(vertex: GLProgram.defaultVertex, fragment: SceneRenderer.compositeFragment) {
            var cases: [(String, Int, Int, Float)] = []
            let names = ["normal", "add", "screen", "multiply", "accumulate", "average"]
            for m in 0..<6 { cases.append(("composite \(names[m])", m, 0, 0)) }
            for mk in 1...4 { cases.append(("composite mask\(mk)", 0, mk, 0)) }
            cases.append(("composite rgbshift", 0, 0, 0.02))
            for (name, mode, maskMode, shift) in cases {
                gOut.bind(); glDisable(GLenum(GL_BLEND)); cp.use()
                cp.setTexture("uScene", gScene, 0); cp.setTexture("uSrc", gSrc, 1); cp.setTexture("uMask", gMask, 2)
                cp.setFloat("uAlpha", 0.7); cp.setFloat("uMode", Float(mode))
                cp.setFloat("uMaskMode", Float(maskMode)); cp.setFloat("uRgbShift", shift)
                Gl.drawFull(cp)
                let g = bytes(gOut.readImage())
                passes.runSync {
                    _ = passes.composite($0, scene: mScene, src: mSrc, mask: mMask, alpha: 0.7, mode: mode,
                                         maskMode: maskMode, rgbShift: shift, to: mOut)
                }
                record(name, diff(g, bytes(mOut.readImage())))
            }
        }

        // effects at default params
        var glFail = 0, mtlFail = 0, total = 0
        for d in Registry.order {
            total += 1
            guard let p = GLProgram(vertex: GLProgram.defaultVertex, fragment: Gl.effectShaderSource(d).0) else {
                glFail += 1; continue
            }
            gOut.bind(); glDisable(GLenum(GL_BLEND)); p.use()
            p.setTexture("uTex", gSrc, 0)
            p.setVec2("uRes", Float(W), Float(H)); p.setFloat("uTime", 0.5)
            p.setFloat("uHas0", 0); p.setFloat("uHas1", 0)
            let ar = Float(W) / Float(H)
            p.setVec2("uLC", 0, 0); p.setVec2("uLX", ar * 2, 0); p.setVec2("uLY", 0, 2)
            for pd in d.props { p.setFloat(Gl.uniformName(pd.key), pd.def) }
            let step = MetalEffects.defaultStep(d)
            for (i, cp) in d.colors.enumerated() {
                let c = step.colors[i]
                p.setVec4(Gl.uniformName(cp.key), c.x, c.y, c.z, c.w)
            }
            Gl.drawFull(p)
            let g = bytes(gOut.readImage())
            var ran = false
            passes.runSync { ran = fx.apply($0, step: step, src: mSrc, out: mOut, time: 0.5) }
            if !ran {
                mtlFail += 1
                lines.append("EFFECT \(d.id): Metal compile failed: " + String((fx.failures[d.id] ?? "?").replacingOccurrences(of: "\n", with: " ").prefix(160)))
                continue
            }
            record("effect \(d.id)", diff(g, bytes(mOut.readImage())))
        }

        Gl.delete(gScene); Gl.delete(gSrc); Gl.delete(gMask)
        lastSummary = "parity: \(good) match, \(bad) differ, \(mtlFail) Metal-compile fails, \(glFail) GL fails (of \(total) effects)"
        lastReport = ([lastSummary, fx.summary] + lines).joined(separator: "\n")
        return lastReport
    }
}
