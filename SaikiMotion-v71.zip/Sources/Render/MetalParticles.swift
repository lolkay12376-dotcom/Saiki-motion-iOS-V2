import Foundation
import Metal
import UIKit

//  Stage 7b: particle fields in Metal (port of SceneRenderer.drawParticleLayer + the GL point-sprite shader).
//  ParticlesSim is CPU-only, so the simulation, 3D projection, depth sort and occluder rectangles are the same
//  code as GL; only the point-sprite draw is Metal (point primitives, premultiplied one / one-minus-src-alpha).

enum MetalParticleSL {
    static let source = MetalSL.header + """
struct PtU {
    float4 vp0; float4 vp1; float4 vp2; float4 vp3;
    float4 a;       // aspect, ortho, size, px
    float4 b;       // opacity, fadeIn, fadeOut, 0
    float4 colA; float4 colB;
};
struct PtOut {
    float4 pos [[position]];
    float psz [[point_size]];
    float4 col;
    float life;
    float soft;
    float ps;
};
vertex PtOut particleVertex(uint vid [[vertex_id]], constant PtU& u [[buffer(0)]],
                            const device float* pts [[buffer(1)]]) {
    float3 aPos = float3(pts[vid * 6], pts[vid * 6 + 1], pts[vid * 6 + 2]);
    float3 aData = float3(pts[vid * 6 + 3], pts[vid * 6 + 4], pts[vid * 6 + 5]);
    PtOut o;
    float k = 1.0;
    if (u.a.y > 0.5) {
        o.pos = float4(aPos.x / u.a.x, aPos.y, 0.5, 1.0);
    } else {
        float4x4 vp = float4x4(u.vp0, u.vp1, u.vp2, u.vp3);
        float4 c = vp * float4(aPos, 1.0);
        o.pos = float4(c.x, c.y, (c.z + c.w) * 0.5, c.w);     // GL clip z [-w, w] -> Metal [0, w]
        k = 3.0 / max(c.w, 0.05);
    }
    o.soft = aData.z;
    float ps = max(4.0, u.a.z * u.a.w * aData.x * k * (1.0 + aData.z * 0.35));
    o.psz = ps;
    o.ps = ps;
    o.life = aData.y;
    o.col = mix(u.colA, u.colB, clamp(aData.y, 0.0, 1.0));
    return o;
}
fragment float4 particleFragment(PtOut in [[stage_in]], constant PtU& u [[buffer(0)]], float2 pc [[point_coord]]) {
    float2 c = pc - 0.5;
    float d = length(c);
    float aa = 1.5 / max(in.ps, 3.0);
    float a = 1.0 - smoothstep(mix(0.5 - aa, 0.0, in.soft), 0.5, d);
    float fade = smoothstep(0.0, u.b.y, in.life) * (1.0 - smoothstep(1.0 - u.b.z, 1.0, in.life));
    a *= fade * u.b.x * in.col.a;
    return float4(in.col.rgb * a, a);
}
"""
}

struct PtU {
    var vp0 = SIMD4<Float>(), vp1 = SIMD4<Float>(), vp2 = SIMD4<Float>(), vp3 = SIMD4<Float>()
    var a = SIMD4<Float>()
    var b = SIMD4<Float>()
    var colA = SIMD4<Float>(), colB = SIMD4<Float>()
}

final class MetalParticleRenderer {
    private let core: MetalCore
    private var lib: MTLLibrary?
    private var psos: [UInt: MTLRenderPipelineState] = [:]
    /// While set, particle simulation uses this time (camera / layer keep the blur sub-time), so particles
    /// stay crisp under motion blur instead of averaging to nothing. Same meaning as GL particleSimTime.
    var simTime: Float? = nil

    init(_ core: MetalCore) {
        self.core = core
        lib = try? core.device.makeLibrary(source: MetalParticleSL.source, options: nil)
    }

    var ready: Bool { lib != nil }

    private func pso(_ format: MTLPixelFormat) -> MTLRenderPipelineState? {
        if let p = psos[format.rawValue] { return p }
        guard let lb = lib, let vf = lb.makeFunction(name: "particleVertex"),
              let ff = lb.makeFunction(name: "particleFragment") else { return nil }
        let d = MTLRenderPipelineDescriptor()
        d.vertexFunction = vf
        d.fragmentFunction = ff
        let ca = d.colorAttachments[0]!
        ca.pixelFormat = format
        ca.isBlendingEnabled = true
        ca.sourceRGBBlendFactor = .one; ca.destinationRGBBlendFactor = .oneMinusSourceAlpha
        ca.sourceAlphaBlendFactor = .one; ca.destinationAlphaBlendFactor = .oneMinusSourceAlpha
        guard let p = try? core.device.makeRenderPipelineState(descriptor: d) else { return nil }
        psos[format.rawValue] = p
        return p
    }

    private func projectPoint(_ vp: [Float], _ x: Float, _ y: Float, _ z: Float) -> (Float, Float, Float) {
        let cx = vp[0] * x + vp[4] * y + vp[8] * z + vp[12]
        let cy = vp[1] * x + vp[5] * y + vp[9] * z + vp[13]
        let cw = vp[3] * x + vp[7] * y + vp[11] * z + vp[15]
        return (cx / max(abs(cw), 0.0001), cy / max(abs(cw), 0.0001), cw)
    }

    private func colorComp(_ l: Layer, key: String, def: Float, time: Float) -> Float {
        if let tr = l.props[key] { return tr.eval(l.editTime(key, time)) }
        return def
    }

    private func clamp01(_ v: Float) -> Float { min(max(v, 0), 1) }

    /// Draws the particle field of `l` over `target`'s current content (the caller has cleared / drawn the source).
    func draw(_ l: Layer, time: Float, fov: Float, into target: MetalTarget, cb: MTLCommandBuffer) {
        guard ready else { return }
        let ar = Float(target.width) / Float(max(target.height, 1))
        let lt = l.editTime("x", time)
        let field = ParticlesSim.field(count: Int(l.p("pCount", lt)), spread: l.p("pSpread", lt),
                                       speed: l.p("pSpeed", lt), gravity: l.p("pGravity", lt),
                                       life: l.p("pLife", lt), seed: l.p("pSeed", lt),
                                       dirX: l.p("pDirX", lt), dirY: l.p("pDirY", lt), t: simTime ?? time, ar: ar,
                                       posX: l.p("pPosX", lt), posY: l.p("pPosY", lt), posZ: l.p("pPosZ", lt),
                                       radX: l.p("pRadX", lt), radY: l.p("pRadY", lt), radZ: l.p("pRadZ", lt),
                                       dirZ: l.p("pDirZ", lt), resist: l.p("pResist", lt),
                                       wobble: l.p("pWobble", lt), sizeVar: l.p("pSizeVar", lt),
                                       sizeEnd: l.p("pSizeEnd", lt), dof: l.p("pDof", lt),
                                       focus: l.p("pFocus", lt),
                                       burst: l.p("pBurst", lt), burstForce: l.p("pBurstForce", lt),
                                       edge: l.p("pSoftEdge", lt))
        let m = Xf.matrix(l, time)
        let scene = Editor.scene
        let hasCam = MetalCam.vp(for: l, time: time, width: target.width, height: target.height) != nil
        let vp = MetalCam.vpForModel(l, fov: fov, time: time, width: target.width, height: target.height)
        guard vp.count == 16, m.count >= 6 else { return }
        let use3D = hasCam || l.is3d
        let occlude = l.p("pOcclude", lt) >= 0.5

        // Occlude: particles behind a 3D layer / model are hidden by it.
        var blockers: [(Float, Float, Float, Float, Float)] = []   // minX, minY, maxX, maxY, z
        if occlude {
            for o in scene.layers where o !== l && o.visible
                && time >= o.start - 0.001 && time <= o.end + 0.001
                && (o.is3d || o.type == .MODEL) && o.isRenderable() && o.type != .PARTICLES {
                let ot = o.editTime("x", time)
                let sc = o.p("scale", ot)
                let (qw, qh) = Xf.quadSize(o)
                let hw = qw * sc * 0.5, hh = qh * sc * 0.5
                let ox = o.p("x", ot), oy = o.p("y", ot), oz = Xf.worldZ(o, time)
                var minX = Float.greatestFiniteMagnitude, minY = minX
                var maxX = -Float.greatestFiniteMagnitude, maxY = maxX
                var ok = true
                for (sx, sy) in [(-hw, -hh), (hw, -hh), (hw, hh), (-hw, hh)] {
                    let (px, py, pw) = projectPoint(vp, ox + sx, oy + sy, oz)
                    if pw <= 0.01 { ok = false; break }
                    minX = min(minX, px); maxX = max(maxX, px)
                    minY = min(minY, py); maxY = max(maxY, py)
                }
                if ok { blockers.append((minX, minY, maxX, maxY, oz)) }
            }
        }

        struct Pt { var x: Float; var y: Float; var z: Float; var size: Float; var life: Float; var soft: Float; var w: Float }
        var list: [Pt] = []
        list.reserveCapacity(field.count)
        let layerZ = Xf.worldZ(l, time)
        let pd = Float.pi / 180
        let prx = l.p("rotX", lt) * pd, pry = -l.p("rotY", lt) * pd
        let pcx = cos(prx), psx = sin(prx), pcy = cos(pry), psy = sin(pry)
        let pRot = prx != 0 || pry != 0
        for q0 in field {
            var q = q0
            if pRot {
                let x1 = q.x * pcy + q.z * psy, z1 = -q.x * psy + q.z * pcy
                let y2 = q.y * pcx - z1 * psx, z2 = q.y * psx + z1 * pcx
                q.x = x1; q.y = y2; q.z = z2
            }
            q.z += layerZ
            var wx = m[0] * q.x + m[2] * q.y + m[4]
            var wy = m[1] * q.x + m[3] * q.y + m[5]
            var sz = q.size
            var w: Float = 1
            if use3D {
                let (sx, sy, pw) = projectPoint(vp, wx, wy, q.z)
                if pw <= 0.05 { continue }
                w = pw
                if occlude {
                    var hidden = false
                    for b in blockers where q.z < b.4 - 0.001 && sx >= b.0 && sx <= b.2 && sy >= b.1 && sy <= b.3 {
                        hidden = true; break
                    }
                    if hidden { continue }
                }
            } else {
                let pf = 1 / max(0.2, 1 - q.z / 3)
                wx *= pf; wy *= pf; sz *= pf
                w = 1 / pf
            }
            list.append(Pt(x: wx, y: wy, z: q.z, size: sz, life: q.life, soft: q.soft, w: w))
        }
        if list.isEmpty { return }
        if use3D { list.sort { $0.w > $1.w } }   // far -> near

        var u = PtU()
        u.vp0 = SIMD4(vp[0], vp[1], vp[2], vp[3]); u.vp1 = SIMD4(vp[4], vp[5], vp[6], vp[7])
        u.vp2 = SIMD4(vp[8], vp[9], vp[10], vp[11]); u.vp3 = SIMD4(vp[12], vp[13], vp[14], vp[15])
        u.a = SIMD4(ar, use3D ? 0 : 1, l.p("pSize", lt), Float(target.height) * 0.5)
        u.b = SIMD4(l.p("pOpacity", lt) * clamp01(l.p("opacity", lt)),
                    max(0.001, l.p("pFadeIn", lt)), max(0.001, l.p("pFadeOut", lt)), 0)
        func pc(_ k: String, _ def: UInt32) -> SIMD4<Float> {
            SIMD4(colorComp(l, key: k + "_r", def: Float((def >> 16) & 0xFF) / 255, time: time),
                  colorComp(l, key: k + "_g", def: Float((def >> 8) & 0xFF) / 255, time: time),
                  colorComp(l, key: k + "_b", def: Float(def & 0xFF) / 255, time: time),
                  colorComp(l, key: k + "_a", def: 1, time: time))
        }
        u.colA = pc("pColA", 0xFFFFFFFF)
        u.colB = pc("pColB", 0xFFFFFFFF)

        var pts = [Float]()
        pts.reserveCapacity(list.count * 6)
        for q in list {
            pts.append(q.x); pts.append(q.y); pts.append(q.z)
            pts.append(q.size); pts.append(q.life); pts.append(q.soft)
        }
        guard let ps = pso(target.tex.pixelFormat),
              let vb = pts.withUnsafeBytes({ core.device.makeBuffer(bytes: $0.baseAddress!, length: $0.count, options: .storageModeShared) }),
              let enc = cb.makeRenderCommandEncoder(descriptor: target.passDescriptor()) else { return }
        enc.setRenderPipelineState(ps)
        enc.setVertexBytes(&u, length: MemoryLayout<PtU>.stride, index: 0)
        enc.setVertexBuffer(vb, offset: 0, index: 1)
        enc.setFragmentBytes(&u, length: MemoryLayout<PtU>.stride, index: 0)
        enc.drawPrimitives(type: .point, vertexStart: 0, vertexCount: list.count)
        enc.endEncoding()
    }
}
