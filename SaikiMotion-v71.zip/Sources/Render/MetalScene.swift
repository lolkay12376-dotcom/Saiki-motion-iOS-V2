//  MetalScene.swift
//  Metal migration stage 4 (part 1): MSL for layer quads + shapes, image/text texture upload,
//  the byte-budgeted LRU image cache and the CVPixelBuffer -> CVMetalTextureCache video sampler.
//
//  UV CONVENTION (same as stage 3): shader uv.y is UP (0 = bottom of the quad). Every Metal
//  texture (images, text, video frames AND render targets) is stored top-row-first, so sampling
//  uses (uv.x, 1 - uv.y). QuadU.flipY = 1 means "texture is top-row-first" (always, in Metal);
//  0 would read the texture with uv.y unflipped (kept only for parity with the GL uniform).

import Foundation
import Metal
import UIKit
import AVFoundation
import CoreVideo

enum MetalSceneSL {
    /// Ports of SceneRenderer.layerQuadVertex (2D subset: uMat, uQuad, uAspect), the quad fragment
    /// (uTex, uFlipY, uColor) and the shape fragment (uKind, uCornerRadius, uColor).
    /// 3D (uRot/uZ/uVP/uInvCam) is ported in clipPos (stage 6a). Puppet meshes: meshVertex / warpVertex.
    static let source = MetalSL.header + """
struct QuadU {
    float4 color;     // uColor
    float4 abcd;      // uMat: a b c d  (Xf affine [a b c d tx ty])
    float2 t;         // uMat: tx ty
    float2 quad;      // uQuad (also the shape size)
    float aspect;     // uAspect
    float flipY;      // uFlipY
    float kind;       // uKind
    float corner;     // uCornerRadius
    float4 rot3;      // 3D: x = uRot.x, y = uRot.y, z = uZ, w = uInvCam
    float4 flags;     // 3D: x = uUseVP, y = 3D path on (else the exact 2D path)
    float4 vp0;       // uVP columns (GL column-major)
    float4 vp1;
    float4 vp2;
    float4 vp3;
};
struct QOut { float4 pos [[position]]; float2 uv; float2 lc; };

inline float glmod(float x, float y) { return x - y * floor(x / y); }

// Port of the GL layerQuadVertex tail: 3D rotation about the layer centre, then camera VP or the
// default z=3 perspective. flags.y = 0 keeps the untouched 2D position.
inline float4 clipPos(float2 w, constant QuadU& u) {
    if (u.flags.y < 0.5) { return float4(w.x / u.aspect, w.y, 0.0, 1.0); }
    float2 c = u.t;
    float3 o = float3(w - c, 0.0);
    float cy = cos(u.rot3.y), sy = sin(u.rot3.y);
    o = float3(o.x * cy + o.z * sy, o.y, -o.x * sy + o.z * cy);
    float cx = cos(u.rot3.x), sx = sin(u.rot3.x);
    o = float3(o.x, o.y * cx - o.z * sx, o.y * sx + o.z * cx);
    float3 pos = float3(c + o.xy, o.z + u.rot3.z);
    if (u.flags.x > 0.5) {
        float4 cl = u.vp0 * pos.x + u.vp1 * pos.y + u.vp2 * pos.z + u.vp3;
        if (cl.w < 0.02) { return float4(2.0, 2.0, 0.0, 1.0); }
        return float4(cl.x, cl.y, 0.0, cl.w);
    }
    return float4(pos.x / u.aspect, pos.y, 0.0, 1.0 - pos.z * u.rot3.w);
}

vertex QOut quadVertex(uint vid [[vertex_id]], constant QuadU& u [[buffer(0)]]) {
    // triangle strip: (0,0) (1,0) (0,1) (1,1); pu.y = 1 is the TOP of the quad
    float2 pu = float2(float(vid & 1u), float(vid >> 1u));
    float2 lc = (pu - 0.5) * u.quad;
    // GL: w = uMat * vec3(lc, 1) with uMat columns (a,b,0) (c,d,0) (tx,ty,1)
    float2 w = float2(u.abcd.x * lc.x + u.abcd.z * lc.y + u.t.x,
                      u.abcd.y * lc.x + u.abcd.w * lc.y + u.t.y);
    QOut o;
    o.pos = clipPos(w, u);
    o.uv = pu;
    o.lc = lc;
    return o;
}

// Puppet mesh: vertices come from two device buffers (expanded triangle list). pos is the deformed
// quad-space position in [-1,1] (same as GL aPos), uvs the rest uv (uv.y up, like the GL aUv).
vertex QOut meshVertex(uint vid [[vertex_id]], constant QuadU& u [[buffer(0)]],
                       const device float2* mpos [[buffer(1)]], const device float2* muv [[buffer(2)]]) {
    float2 pu = mpos[vid] * 0.5 + 0.5;
    float2 lc = (pu - 0.5) * u.quad;
    float2 w = float2(u.abcd.x * lc.x + u.abcd.z * lc.y + u.t.x,
                      u.abcd.y * lc.x + u.abcd.w * lc.y + u.t.y);
    QOut o;
    o.pos = clipPos(w, u);
    o.uv = muv[vid];
    o.lc = lc;
    return o;
}

// Group puppet warp: positions are already clip space (GL warpProg).
vertex QOut warpVertex(uint vid [[vertex_id]], constant QuadU& u [[buffer(0)]],
                       const device float2* mpos [[buffer(1)]], const device float2* muv [[buffer(2)]]) {
    QOut o;
    o.pos = float4(mpos[vid], 0.0, 1.0);
    o.uv = muv[vid];
    o.lc = float2(0.0);
    return o;
}

fragment float4 quadFragment(QOut in [[stage_in]], constant QuadU& u [[buffer(0)]],
                             texture2d<float> tex [[texture(0)]]) {
    float2 p = u.flipY > 0.5 ? float2(in.uv.x, 1.0 - in.uv.y) : in.uv;
    return tex.sample(linearClamp, p) * u.color;
}

fragment float4 shapeFragment(QOut in [[stage_in]], constant QuadU& u [[buffer(0)]]) {
    float2 q = in.lc;
    float2 qs = u.quad;
    float cr = u.corner;
    float a = 0.0;
    if (u.kind < 0.5) {
        a = 1.0;
    } else if (u.kind < 1.5) {
        float2 d = abs(q) - (qs * 0.5 - float2(cr));
        float outD = length(max(d, float2(0.0))) + min(max(d.x, d.y), 0.0) - cr;
        a = 1.0 - smoothstep(-0.004, 0.004, outD);
    } else if (u.kind < 2.5) {
        float m = min(qs.x, qs.y);
        a = 1.0 - smoothstep(0.48 * m, 0.5 * m, length(q));
    } else if (u.kind < 3.5) {
        float2 v1 = float2(-qs.x * 0.5, -qs.y * 0.5) - q;
        float2 v2 = float2(qs.x * 0.5, -qs.y * 0.5) - q;
        float2 v3 = q - float2(-qs.x * 0.5, -qs.y * 0.5);
        float s1 = v1.x * v2.y - v1.y * v2.x;
        float s2 = v2.x * v3.y - v2.y * v3.x;
        float s3 = v3.x * (-v1.y) - v3.y * (-v1.x);
        a = ((s1 >= 0.0 && s2 >= 0.0 && s3 >= 0.0) || (s1 <= 0.0 && s2 <= 0.0 && s3 <= 0.0)) ? 1.0 : 0.0;
    } else {
        float n = 5.0;
        float a0 = atan2(q.y, q.x) + 1.5708;
        float seg = 6.2831 / n;
        float m = min(qs.x, qs.y);
        float rIn = 0.22 * m;
        float rOut = 0.5 * m;
        float ang = glmod(a0, seg) - seg * 0.5;
        float rLim = mix(rOut, rIn, abs(ang) / (seg * 0.5));
        a = 1.0 - smoothstep(rLim - 0.01, rLim + 0.01, length(q));
    }
    // same as GL: rgb * a, alpha * a (the colour is not multiplied by its own alpha)
    return float4(u.color.rgb * a, u.color.a * a);
}
"""
}

/// Must match QuadU in MSL byte for byte (160 bytes, 16-aligned).
struct QuadU {
    var color = SIMD4<Float>(1, 1, 1, 1)
    var abcd = SIMD4<Float>(1, 0, 0, 1)
    var t = SIMD2<Float>(0, 0)
    var quad = SIMD2<Float>(2, 2)
    var aspect: Float = 1
    var flipY: Float = 1
    var kind: Float = 0
    var corner: Float = 0.12
    var rot3 = SIMD4<Float>(0, 0, 0, 0)
    var flags = SIMD4<Float>(0, 0, 0, 0)
    var vp0 = SIMD4<Float>(0, 0, 0, 0)
    var vp1 = SIMD4<Float>(0, 0, 0, 0)
    var vp2 = SIMD4<Float>(0, 0, 0, 0)
    var vp3 = SIMD4<Float>(0, 0, 0, 0)
}

// MARK: - image upload

enum MetalImageUpload {
    /// Decoded size in bytes when scaled so the longest side is <= maxSide (mirrors Gl.uploadBytes).
    static func byteCount(_ image: UIImage, maxSide: Int) -> Int {
        guard let cg = image.cgImage, cg.width > 0, cg.height > 0 else { return 0 }
        let sc = min(1.0, Double(maxSide) / Double(max(cg.width, cg.height)))
        return max(1, Int(Double(cg.width) * sc)) * max(1, Int(Double(cg.height) * sc)) * 4
    }

    /// UIImage -> premultiplied RGBA8 MTLTexture, rows top-first (CGContext memory order). Mirrors Gl.upload.
    static func texture(_ core: MetalCore, _ image: UIImage, maxSide: Int = 4096) -> (tex: MTLTexture, bytes: Int)? {
        guard let cg = image.cgImage, cg.width > 0, cg.height > 0 else { return nil }
        let sc = min(1.0, Double(maxSide) / Double(max(cg.width, cg.height, 1)))
        let w = max(1, Int(Double(cg.width) * sc)), h = max(1, Int(Double(cg.height) * sc))
        var data = [UInt8](repeating: 0, count: w * h * 4)
        let drew: Bool = data.withUnsafeMutableBytes { raw -> Bool in
            guard let ctx = CGContext(data: raw.baseAddress, width: w, height: h, bitsPerComponent: 8,
                                      bytesPerRow: w * 4, space: CGColorSpaceCreateDeviceRGB(),
                                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            ctx.setBlendMode(.copy)
            ctx.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h))
            return true
        }
        guard drew else { return nil }
        let d = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .rgba8Unorm, width: w, height: h, mipmapped: false)
        d.usage = .shaderRead
        d.storageMode = .shared
        guard let t = core.device.makeTexture(descriptor: d) else { return nil }
        data.withUnsafeBytes {
            t.replace(region: MTLRegionMake2D(0, 0, w, h), mipmapLevel: 0,
                      withBytes: $0.baseAddress!, bytesPerRow: w * 4)
        }
        return (t, w * h * 4)
    }
}

// MARK: - image cache (port of SceneRenderer.imageTexture, byte-budgeted LRU)

final class MetalImageCache {
    private let core: MetalCore
    private var tex: [String: MTLTexture] = [:]
    private var bytes: [String: Int] = [:]
    private var order: [String] = []        // least recently used first
    private var total = 0
    private var side = 0
    let budget = 360 * 1_048_576

    init(_ core: MetalCore) { self.core = core }

    var totalBytes: Int { total }

    func texture(path: String, quality: Int) -> MTLTexture? {
        let s = max(384, 1536 / max(1, quality))
        if s != side { flush(); side = s }
        if let t = tex[path] {
            if order.last != path {
                if let i = order.firstIndex(of: path) { order.remove(at: i) }
                order.append(path)
            }
            return t
        }
        var made: (tex: MTLTexture, bytes: Int)?
        autoreleasepool {
            guard let img = UIImage(contentsOfFile: path) else { return }
            made = MetalImageUpload.texture(core, img, maxSide: s)
        }
        guard let m = made else { return nil }
        tex[path] = m.tex
        bytes[path] = m.bytes
        total += m.bytes
        order.append(path)
        while total > budget, order.count > 1 {
            let old = order.removeFirst()
            tex.removeValue(forKey: old)            // ARC frees the MTLTexture once in-flight work is done
            total -= bytes.removeValue(forKey: old) ?? 0
        }
        return m.tex
    }

    func flush() {
        tex.removeAll(); bytes.removeAll(); order.removeAll(); total = 0
    }
}

// MARK: - video frames (CVPixelBuffer -> CVMetalTextureCache)

/// Per-layer async frame source, same 10-frames-per-second bucketing as VideoFrames.Sampler.
/// Frames are decoded with AVAssetReader (BGRA, preferred transform applied) and wrapped as
/// MTLTextures through a CVMetalTextureCache (no CPU copy).
final class MetalVideoSampler {
    private let asset: AVURLAsset
    private let queue: DispatchQueue
    private var cache: CVMetalTextureCache?
    private let lock = NSLock()
    private var current: MTLTexture?
    private var currentRef: CVMetalTexture?     // keeps the pixel buffer alive while `current` is in use
    private var bucket = -1
    private var pending = -1
    /// Fired on the main thread after a fresh frame arrives.
    var onFrame: (() -> Void)?

    init(path: String, device: MTLDevice) {
        asset = VideoFrames.asset(path)
        queue = DispatchQueue(label: "saiki.metalvideo.\(abs(path.hashValue))")
        CVMetalTextureCacheCreate(kCFAllocatorDefault, nil, device, nil, &cache)
    }

    /// The newest frame at/near `srcTime` (returns the previous frame while the next one decodes).
    func texture(at srcTime: Float) -> MTLTexture? {
        let b = Int(max(0, srcTime) * 10)
        lock.lock()
        let cur = current
        let have = (b == bucket) || (b == pending)
        if !have { pending = b }
        lock.unlock()
        if !have {
            queue.async { [weak self] in self?.generate(srcTime, bucket: b) }
        }
        return cur
    }

    private func generate(_ t: Float, bucket b: Int) {
        var made: MTLTexture?
        var ref: CVMetalTexture?
        autoreleasepool {
            guard let cache = cache,
                  let track = asset.tracks(withMediaType: .video).first,
                  let reader = try? AVAssetReader(asset: asset) else { return }
            let settings: [String: Any] = [
                kCVPixelBufferPixelFormatTypeKey as String: Int(kCVPixelFormatType_32BGRA),
                kCVPixelBufferMetalCompatibilityKey as String: true,
                kCVPixelBufferIOSurfacePropertiesKey as String: [String: Any](),
            ]
            let out = AVAssetReaderVideoCompositionOutput(videoTracks: [track], videoSettings: settings)
            out.videoComposition = AVMutableVideoComposition(propertiesOf: asset)   // applies the rotation
            reader.timeRange = CMTimeRange(start: CMTime(seconds: Double(max(0, t)), preferredTimescale: 600),
                                           duration: CMTime(seconds: 0.5, preferredTimescale: 600))
            guard reader.canAdd(out) else { return }
            reader.add(out)
            guard reader.startReading(),
                  let sb = out.copyNextSampleBuffer(),
                  let pb = CMSampleBufferGetImageBuffer(sb) else { return }
            let w = CVPixelBufferGetWidth(pb), h = CVPixelBufferGetHeight(pb)
            var cvt: CVMetalTexture?
            let st = CVMetalTextureCacheCreateTextureFromImage(kCFAllocatorDefault, cache, pb, nil,
                                                               .bgra8Unorm, w, h, 0, &cvt)
            if st == kCVReturnSuccess, let c = cvt, let tx = CVMetalTextureGetTexture(c) {
                made = tx
                ref = c
            }
            reader.cancelReading()
        }
        lock.lock()
        if let m = made { current = m; currentRef = ref }
        bucket = b
        pending = -1
        lock.unlock()
        if made != nil {
            DispatchQueue.main.async { [weak self] in self?.onFrame?() }
        }
    }
}
