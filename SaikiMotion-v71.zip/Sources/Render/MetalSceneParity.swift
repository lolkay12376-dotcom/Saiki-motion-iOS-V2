//  MetalSceneParity.swift
//  Metal migration stage 4: renders small test scenes with SceneRenderer (GL) and
//  MetalSceneRenderer and reports the pixel difference. Called from MetalParity.runSync with the
//  GL context current. Scene A = image + shape + text + add blend + one effect.
//  Scene B = precomp group with an alpha matte (first child) over an image.

import Foundation
import UIKit
import OpenGLES

extension MetalParity {
    private static let sceneTol = 6

    private static func rgba(_ img: UIImage?) -> [UInt8]? {
        guard let cg = img?.cgImage else { return nil }
        var px = [UInt8](repeating: 0, count: cg.width * cg.height * 4)
        let ok = px.withUnsafeMutableBytes { raw -> Bool in
            guard let ctx = CGContext(data: raw.baseAddress, width: cg.width, height: cg.height, bitsPerComponent: 8,
                                      bytesPerRow: cg.width * 4, space: CGColorSpaceCreateDeviceRGB(),
                                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            ctx.draw(cg, in: CGRect(x: 0, y: 0, width: cg.width, height: cg.height))
            return true
        }
        return ok ? px : nil
    }

    private static func sceneDiff(_ a: [UInt8]?, _ b: [UInt8]?) -> String {
        guard let a = a, let b = b else { return "readback failed" }
        guard a.count == b.count, !a.isEmpty else { return "size mismatch GL \(a.count / 4)px vs Metal \(b.count / 4)px" }
        var mx = 0, sum = 0, bad = 0
        var i = 0
        while i < a.count {
            var worst = 0
            for c in 0..<4 {
                let d = abs(Int(a[i + c]) - Int(b[i + c]))
                worst = max(worst, d); sum += d
            }
            mx = max(mx, worst)
            if worst > sceneTol { bad += 1 }
            i += 4
        }
        let pct = Double(bad) / Double(a.count / 4) * 100
        let verdict = bad == 0 ? "OK" : "DIFF"
        return "\(verdict) max \(mx) mean \(String(format: "%.2f", Double(sum) / Double(a.count))) differ \(String(format: "%.2f", pct))% px"
    }

    private static func testImagePath() -> String? {
        let size = CGSize(width: 128, height: 96)
        let r = UIGraphicsImageRenderer(size: size)
        let img = r.image { c in
            let g = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(),
                               colors: [UIColor.red.cgColor, UIColor.yellow.cgColor, UIColor.blue.cgColor] as CFArray,
                               locations: [0, 0.5, 1])!
            c.cgContext.drawLinearGradient(g, start: .zero, end: CGPoint(x: size.width, y: size.height), options: [])
            UIColor.white.withAlphaComponent(0.8).setFill()
            c.cgContext.fillEllipse(in: CGRect(x: 14, y: 10, width: 40, height: 40))   // upper-left: catches flipped V
            UIColor.black.setFill()
            c.cgContext.fill(CGRect(x: 80, y: 60, width: 36, height: 24))              // lower-right
        }
        guard let data = img.pngData() else { return nil }
        let path = NSTemporaryDirectory() + "saiki_parity_img.png"
        do { try data.write(to: URL(fileURLWithPath: path)) } catch { return nil }
        return path
    }

    private static func set(_ l: Layer, _ key: String, _ v: Float) { l.track(key).base = v }

    private static func shape(_ id: Int, _ name: String, color: UInt32, x: Float, y: Float, scale: Float,
                              rot: Float, opacity: Float = 1, blend: Int = 0, kind: ShapeKind = .RECT) -> Layer {
        let l = Layer(id, name, .SHAPE)
        l.shape = kind
        l.color = Int32(bitPattern: color)
        l.blend = blend
        set(l, "x", x); set(l, "y", y); set(l, "scale", scale); set(l, "rotZ", rot); set(l, "opacity", opacity)
        return l
    }

    private static func image(_ id: Int, _ path: String, x: Float, y: Float, scale: Float, opacity: Float = 1) -> Layer {
        let l = Layer(id, "img\(id)", .IMAGE)
        l.imagePath = path
        set(l, "x", x); set(l, "y", y); set(l, "scale", scale); set(l, "opacity", opacity)
        return l
    }

    /// "A ok, B diff" style tail for the one-line summary.
    static func sceneSummary(_ lines: [String]) -> String {
        var parts: [String] = []
        for l in lines {
            let tag = l.hasPrefix("scene A") ? "A" : (l.hasPrefix("scene B") ? "B" : "scene")
            parts.append(tag + (l.contains(": OK") ? " ok" : " diff"))
        }
        return parts.joined(separator: ", ")
    }

    /// GL context must be current. Returns report lines.
    static func sceneParity() -> [String] {
        guard let mr = MetalSceneRenderer.shared else { return ["scene parity: Metal scene renderer unavailable"] }
        if let e = mr.buildError { return ["scene parity: scene shaders failed: " + e.replacingOccurrences(of: "\n", with: " ")] }
        guard let path = testImagePath() else { return ["scene parity: could not write test image"] }
        guard let ctx = GLContext.make() else { return ["scene parity: no GL context"] }
        EAGLContext.setCurrent(ctx)

        let proj = Project(name: "parity", w: 540, h: 960)
        let fxDef = Registry.order.first {
            $0.kind == 1 && $0.inputs.isEmpty && !MetalSceneRenderer.glOnlyEffects.contains($0.id) && MetalEffects.shared?.canRun($0) == true
        }

        // scene A
        let a = Scene("A")
        a.bg = Int32(bitPattern: 0xFF202040)
        a.layers.append(image(1, path, x: 0, y: 0, scale: 1))
        a.layers.append(shape(2, "rect", color: 0xFF3388FF, x: 0.25, y: 0.1, scale: 0.6, rot: 20, opacity: 0.8))
        let t = Layer(3, "text", .TEXT)
        t.text = "Parity"
        t.color = Int32(bitPattern: 0xFFFFFFFF)
        set(t, "y", -0.5)
        a.layers.append(t)
        a.layers.append(shape(4, "add", color: 0xFFFF8800, x: -0.25, y: 0.3, scale: 0.5, rot: 0, blend: 1))
        let fxImg = image(5, path, x: 0.1, y: -0.8, scale: 0.5, opacity: 0.7)
        if let d = fxDef { fxImg.fx = [d.id] }
        a.layers.append(fxImg)

        // scene B: group with an alpha matte (first child = matte)
        let b = Scene("B")
        b.bg = Int32(bitPattern: 0xFF202040)
        let g = Layer(10, "grp", .GROUP)
        g.mask = 1
        let matte = shape(11, "matte", color: 0xFFFFFFFF, x: 0.1, y: 0, scale: 0.7, rot: 15)
        matte.parentId = 10
        let content = image(12, path, x: 0, y: 0, scale: 1.2)
        content.parentId = 10
        b.layers = [g, matte, content]

        let savedP = Editor.project, savedI = Editor.sceneIndex
        defer { Editor.project = savedP; Editor.sceneIndex = savedI }

        var lines: [String] = []
        let glr = SceneRenderer(context: ctx)
        glr.quality = 4
        mr.quality = 4
        let fxName: String = fxDef?.id ?? "none"
        let cases: [(String, Scene)] = [("scene A (image+shape+text+add+fx:" + fxName + ")", a),
                                        ("scene B (group + alpha matte)", b)]
        for (name, scene) in cases {
            proj.scenes = [scene]
            Editor.project = proj; Editor.sceneIndex = 0
            EAGLContext.setCurrent(ctx)
            _ = glr.draw(project: proj, scene: scene, time: 1.0, video: nil)
            let gl = rgba(glr.snapshot())
            guard mr.renderFrame(project: proj, scene: scene, time: 1.0) else {
                lines.append("\(name): Metal declined (\(mr.lastFallbackReason))"); continue
            }
            let mt = rgba(mr.snapshotFrame())
            lines.append("\(name): " + sceneDiff(gl, mt))
        }
        glr.trimMemory()
        return lines
    }
}
