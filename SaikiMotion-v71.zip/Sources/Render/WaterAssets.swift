// WaterAssets.swift — procedural water textures (Render).
//
// The finished app shipped a small water kit: a tileable normal map for the
// water/refraction effects and a caustics sheet for pools. Both are
// generated once with value noise, cached under Caches/SaikiMotion and
// handed to shaders as ordinary textures — no bundled binaries needed.

import Foundation
import CoreGraphics
import UIKit

enum WaterAssets {

    /// Tileable water normal map (RGB = normals, tileable).
    static func normalMap(size: Int = 256) -> UIImage {
        let key = "water_n\(size)"
        if let img = cache[key] { return img }
        let img = renderNormal(size)
        cache[key] = img
        return img
    }

    /// Tileable caustics intensity map (white on transparent).
    static func caustics(size: Int = 256) -> UIImage {
        let key = "water_c\(size)"
        if let img = cache[key] { return img }
        let img = renderCaustics(size)
        cache[key] = img
        return img
    }

    private static var cache: [String: UIImage] = [:]

    // MARK: - generators

    private static func renderNormal(_ n: Int) -> UIImage {
        var height = [Float](repeating: 0, count: n * n)
        // layered tileable value noise
        for y in 0..<n {
            for x in 0..<n {
                let fx = Float(x) / Float(n)
                let fy = Float(y) / Float(n)
                var h: Float = 0
                var amp: Float = 1
                var sc: Float = 4
                for _ in 0..<4 {
                    h += amp * tnoise(fx * sc, fy * sc, Float(n) / sc * 0.5)
                    amp *= 0.5
                    sc *= 2
                }
                height[y * n + x] = h / 1.875
            }
        }
        var data = [UInt8](repeating: 0, count: n * n * 4)
        for y in 0..<n {
            for x in 0..<n {
                let l = height[y * n + ((x - 1 + n) % n)]
                let r = height[y * n + ((x + 1) % n)]
                let u = height[((y - 1 + n) % n) * n + x]
                let d = height[((y + 1) % n) * n + x]
                let nx = (l - r) * 2
                let ny = (u - d) * 2
                let nz: Float = 0.6
                let len = sqrt(nx * nx + ny * ny + nz * nz)
                let i = (y * n + x) * 4
                data[i] = UInt8(clamp((nx / len * 0.5 + 0.5) * 255, 0, 255))
                data[i + 1] = UInt8(clamp((ny / len * 0.5 + 0.5) * 255, 0, 255))
                data[i + 2] = UInt8(clamp((nz / len * 0.5 + 0.5) * 255, 0, 255))
                data[i + 3] = 255
            }
        }
        return image(from: data, w: n, h: n)
    }

    private static func renderCaustics(_ n: Int) -> UIImage {
        var data = [UInt8](repeating: 0, count: n * n * 4)
        for y in 0..<n {
            for x in 0..<n {
                let fx = Float(x) / Float(n)
                let fy = Float(y) / Float(n)
                // voronoi-ish caustic webs: two noise fields sharpened
                let a = tnoise(fx * 6, fy * 6, Float(n) / 6 * 0.5)
                let b = tnoise(fx * 9 + 3.7, fy * 9 + 1.3, Float(n) / 9 * 0.5)
                let v = pow(abs(a - b), 0.6)
                let bright = clamp((1.0 - v * 3.2), 0, 1)
                let i = (y * n + x) * 4
                let c = UInt8(bright * 255)
                data[i] = c; data[i + 1] = c; data[i + 2] = UInt8(min(255, Float(c) + 18))
                data[i + 3] = UInt8(bright * 220)
            }
        }
        return image(from: data, w: n, h: n)
    }

    private static func image(from data: [UInt8], w: Int, h: Int) -> UIImage {
        let ctx = CGContext(data: nil, width: w, height: h, bitsPerComponent: 8, bytesPerRow: w * 4,
                            space: CGColorSpaceCreateDeviceRGB(),
                            bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)
        guard let ctx = ctx else { return UIImage() }
        data.withUnsafeBytes { raw in
            ctx.data?.copyMemory(from: raw.baseAddress!, byteCount: data.count)
        }
        guard let cg = ctx.makeImage() else { return UIImage() }
        return UIImage(cgImage: cg)
    }

    /// Tileable value noise with period `period`.
    private static func tnoise(_ x: Float, _ y: Float, _ period: Float) -> Float {
        let xi = floorf(x), yi = floorf(y)
        let xf = x - xi, yf = y - yi
        let u = xf * xf * (3 - 2 * xf)
        let v = yf * yf * (3 - 2 * yf)
        func h(_ px: Float, _ py: Float) -> Float {
            var s = UInt32(truncatingIfNeeded: Int64(px + py * period * 57.0))
            s = s &* 747796405 &+ 2891336453
            s = ((s >> ((s >> 28) + 4)) ^ s) &* 277803737
            s = (s >> 22) ^ s
            return Float(s % 10000) / 10000
        }
        let x0 = ((xi.truncatingRemainder(dividingBy: period)) + period).truncatingRemainder(dividingBy: period)
        let x1 = (x0 + 1).truncatingRemainder(dividingBy: period)
        let y0 = ((yi.truncatingRemainder(dividingBy: period)) + period).truncatingRemainder(dividingBy: period)
        let y1 = (y0 + 1).truncatingRemainder(dividingBy: period)
        let a = h(x0, y0), b = h(x1, y0)
        let c = h(x0, y1), d = h(x1, y1)
        return (a * (1 - u) + b * u) * (1 - v) + (c * (1 - u) + d * u) * v
    }
}


/// One-tap water looks. Every value stays editable afterwards in the layer's Water settings.
enum WaterPresets {
    static let names = ["Ocean", "Lake", "River", "Pool", "Storm", "Tropical"]
    static let keys = ["wAmp", "wFreq", "wSpeed", "wChop", "wFoam", "wDepth", "wClar", "wTurb", "wRefr", "wSss", "wGlint", "wDetail", "wVar", "wSwell", "wSwellLen", "wCaps"]
    static let vals: [[Float]] = [
        [0.06, 4, 1.0, 0.65, 0.6, 0.8, 0.55, 0.10, 0.5, 0.5, 1.0, 0.6, 0.9, 1.2, 0.15, 0.6],     // Ocean
        [0.015, 7, 0.6, 0.25, 0.1, 0.6, 0.5, 0.20, 0.5, 0.4, 1.0, 0.5, 0.6, 0.3, 0.15, 0.1],     // Lake
        [0.02, 9, 2.2, 0.45, 0.35, 0.35, 0.45, 0.35, 0.5, 0.3, 1.0, 0.9, 0.8, 0.15, 0.2, 0.2],    // River
        [0.004, 12, 0.5, 0.1, 0.0, 0.3, 1.0, 0.0, 0.8, 0.2, 1.2, 0.35, 0.3, 0.0, 0.15, 0.0],      // Pool
        [0.12, 3, 1.8, 1.0, 1.0, 0.9, 0.3, 0.35, 0.4, 0.4, 1.0, 1.0, 1.0, 1.6, 0.15, 1.0],        // Storm
        [0.03, 5, 0.9, 0.4, 0.3, 0.4, 1.0, 0.0, 0.6, 0.8, 1.0, 0.6, 0.7, 0.5, 0.15, 0.2]          // Tropical
    ]
    static func apply(_ i: Int, _ l: Layer) {
        guard i >= 0, i < vals.count else { return }
        for (k, x) in zip(keys, vals[i]) { l.xset(k, x) }
    }
}
