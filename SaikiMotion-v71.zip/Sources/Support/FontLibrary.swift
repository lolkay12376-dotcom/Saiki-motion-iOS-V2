// FontLibrary.swift — the user's font collection: import single fonts or whole .zip packs,
// organise them in folders, and apply them to text layers.
//
//   <Documents>/SaikiMotion/Fonts/<files>   the font files
//   <Documents>/SaikiMotion/Fonts/library.json   folders + font records
//
// Fonts are registered with CoreText on demand (TextRaster.registerFont), so a layer only stores
// the file path — and if the app container moves, the file is found again by its name here.

import UIKit
import Compression
import CoreText

// MARK: - tiny ZIP reader (stored + deflate, no zip64) --------------------------------------

enum MiniZip {
    struct Entry { let name: String; let data: Data }

    private static func u16(_ d: Data, _ o: Int) -> Int { Int(d[d.startIndex + o]) | Int(d[d.startIndex + o + 1]) << 8 }
    private static func u32(_ d: Data, _ o: Int) -> Int { u16(d, o) | u16(d, o + 2) << 16 }

    private static func inflate(_ src: Data, expected: Int) -> Data? {
        if expected == 0 { return Data() }
        var dst = [UInt8](repeating: 0, count: expected)
        let n = src.withUnsafeBytes { (sp: UnsafeRawBufferPointer) -> Int in
            dst.withUnsafeMutableBytes { (dp: UnsafeMutableRawBufferPointer) -> Int in
                compression_decode_buffer(dp.bindMemory(to: UInt8.self).baseAddress!, expected,
                                          sp.bindMemory(to: UInt8.self).baseAddress!, src.count,
                                          nil, COMPRESSION_ZLIB)
            }
        }
        return n == expected ? Data(dst) : nil
    }

    /// Every file whose lower-cased name passes `accept`.
    static func read(_ url: URL, accept: (String) -> Bool) -> [Entry] {
        guard let d = try? Data(contentsOf: url, options: .mappedIfSafe), d.count > 22 else { return [] }
        var eocd = -1
        var i = d.count - 22
        while i >= max(0, d.count - 65_557) {
            if u32(d, i) == 0x06054b50 { eocd = i; break }
            i -= 1
        }
        guard eocd >= 0 else { return [] }
        let count = u16(d, eocd + 10)
        var p = u32(d, eocd + 16)
        var out: [Entry] = []
        for _ in 0..<count {
            guard p + 46 <= d.count, u32(d, p) == 0x02014b50 else { break }
            let method = u16(d, p + 10)
            let csize = u32(d, p + 20), usize = u32(d, p + 24)
            let nlen = u16(d, p + 28), elen = u16(d, p + 30), clen = u16(d, p + 32)
            let lho = u32(d, p + 42)
            guard p + 46 + nlen <= d.count else { break }
            let nameData = d.subdata(in: (d.startIndex + p + 46)..<(d.startIndex + p + 46 + nlen))
            let name = String(data: nameData, encoding: .utf8) ?? String(decoding: nameData, as: UTF8.self)
            p += 46 + nlen + elen + clen
            guard accept(name.lowercased()), lho + 30 <= d.count, u32(d, lho) == 0x04034b50 else { continue }
            let start = lho + 30 + u16(d, lho + 26) + u16(d, lho + 28)
            guard start + csize <= d.count, usize < 80_000_000 else { continue }
            let raw = d.subdata(in: (d.startIndex + start)..<(d.startIndex + start + csize))
            if method == 0 { out.append(Entry(name: name, data: raw)) }
            else if method == 8, let x = inflate(raw, expected: usize) { out.append(Entry(name: name, data: x)) }
        }
        return out
    }
}

// MARK: - library ---------------------------------------------------------------------------

struct FontFolder: Codable { var id: String; var name: String }
struct FontRecord: Codable { var id: String; var name: String; var file: String; var folder: String? }
private struct FontIndex: Codable { var folders: [FontFolder] = []; var fonts: [FontRecord] = [] }

enum FontLibrary {
    private static var index: FontIndex = load()
    static var folders: [FontFolder] { index.folders }
    static var fonts: [FontRecord] { index.fonts }

    static var dir: URL {
        let u = Paths.root.appendingPathComponent("Fonts", isDirectory: true)
        try? FileManager.default.createDirectory(at: u, withIntermediateDirectories: true)
        return u
    }
    private static var indexURL: URL { dir.appendingPathComponent("library.json") }

    private static func load() -> FontIndex {
        guard let d = try? Data(contentsOf: indexURL),
              let i = try? JSONDecoder().decode(FontIndex.self, from: d) else { return FontIndex() }
        return i
    }
    private static func save() { try? JSONEncoder().encode(index).write(to: indexURL, options: .atomic) }

    static func path(_ f: FontRecord) -> String { dir.appendingPathComponent(f.file).path }
    static func fonts(in folder: String?) -> [FontRecord] {
        index.fonts.filter { $0.folder == folder }.sorted { $0.name.lowercased() < $1.name.lowercased() }
    }
    static func count(in folder: String) -> Int { index.fonts.filter { $0.folder == folder }.count }

    /// A stored path whose container moved still resolves by file name.
    static func resolve(_ path: String) -> String {
        if FileManager.default.fileExists(atPath: path) { return path }
        let alt = dir.appendingPathComponent((path as NSString).lastPathComponent).path
        return FileManager.default.fileExists(atPath: alt) ? alt : path
    }

    // folders
    @discardableResult static func addFolder(_ name: String) -> FontFolder {
        let f = FontFolder(id: UUID().uuidString, name: name)
        index.folders.append(f); save(); return f
    }
    static func renameFolder(_ id: String, _ name: String) {
        if let i = index.folders.firstIndex(where: { $0.id == id }) { index.folders[i].name = name; save() }
    }
    /// Deleting a folder keeps its fonts (they move back to the top level).
    static func deleteFolder(_ id: String) {
        index.folders.removeAll { $0.id == id }
        for i in index.fonts.indices where index.fonts[i].folder == id { index.fonts[i].folder = nil }
        save()
    }
    static func move(_ fontId: String, to folder: String?) {
        if let i = index.fonts.firstIndex(where: { $0.id == fontId }) { index.fonts[i].folder = folder; save() }
    }
    static func rename(_ fontId: String, _ name: String) {
        if let i = index.fonts.firstIndex(where: { $0.id == fontId }) { index.fonts[i].name = name; save() }
    }
    static func delete(_ fontId: String) {
        guard let i = index.fonts.firstIndex(where: { $0.id == fontId }) else { return }
        // keep the file if a text layer might still point at it? Layers fall back to the default font.
        try? FileManager.default.removeItem(at: dir.appendingPathComponent(index.fonts[i].file))
        index.fonts.remove(at: i); save()
    }

    // importing
    private static func isFont(_ n: String) -> Bool { n.hasSuffix(".ttf") || n.hasSuffix(".otf") }

    /// Adds font files and/or zip packs. A zip with several fonts gets its own folder (named after
    /// the zip) inside `folder`'s level. Returns how many fonts were added.
    @discardableResult
    static func importURLs(_ urls: [URL], into folder: String?) -> Int {
        var added = 0
        for url in urls {
            let scoped = url.startAccessingSecurityScopedResource()
            defer { if scoped { url.stopAccessingSecurityScopedResource() } }
            let ext = url.pathExtension.lowercased()
            if ext == "zip" {
                let entries = MiniZip.read(url) { n in
                    isFont(n) && !n.contains("__macosx") && !((n as NSString).lastPathComponent.hasPrefix("._"))
                }
                guard !entries.isEmpty else { continue }
                var target = folder
                if entries.count > 1 {
                    target = addFolder(url.deletingPathExtension().lastPathComponent).id
                }
                for e in entries { if add(e.data, filename: (e.name as NSString).lastPathComponent, folder: target) { added += 1 } }
            } else if ext == "ttf" || ext == "otf" {
                if let d = try? Data(contentsOf: url), add(d, filename: url.lastPathComponent, folder: folder) { added += 1 }
            }
        }
        save()
        return added
    }

    private static func add(_ data: Data, filename: String, folder: String?) -> Bool {
        guard let provider = CGDataProvider(data: data as CFData), let cg = CGFont(provider) else { return false }
        let ps = (cg.postScriptName as String?) ?? filename
        // same PostScript font twice → skip
        if index.fonts.contains(where: { $0.name == ps && $0.folder == folder }) { return false }
        let id = UUID().uuidString
        let file = id.prefix(8) + "_" + filename
        guard (try? data.write(to: dir.appendingPathComponent(String(file)), options: .atomic)) != nil else { return false }
        let display = (cg.fullName as String?) ?? ps
        index.fonts.append(FontRecord(id: id, name: display, file: String(file), folder: folder))
        return true
    }
}
