// AnimeDecomposeViewController.swift — the "Anime Decomposition" tool screen.
//
// Same dark + orange look as the rest of the app. Pick an image, choose how
// many layers, tap SEPARATE LAYERS (cancel any time), then toggle layers and
// export as PSD, as one image, or straight into a new project.

import UIKit
import PhotosUI

// MARK: - small views ------------------------------------------------------------------

/// Icon-only tap target drawn with the shared vector icons.
private final class ToolIconButton: TapView {
    var icon = "" { didSet { setNeedsDisplay() } }
    var tint: Int32 = C.TEXT { didSet { setNeedsDisplay() } }

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        Icons.draw(c, icon, bounds.midX, bounds.midY, 22, isHighlighted ? C.GREEN : tint)
    }
}

/// Shows an image, or a stack of layer bitmaps, aspect-fit over a transparency checkerboard.
private final class LayerPreviewCanvas: UIView {
    private var canvas = CGSize.zero
    private var entries: [(view: UIImageView, rect: CGRect)] = []
    private var checker = false

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        isOpaque = false
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    func show(_ items: [(UIImage, CGRect)], size: CGSize, checker: Bool) {
        for e in entries { e.view.removeFromSuperview() }
        entries = []
        for item in items {
            let v = UIImageView(image: item.0)
            v.contentMode = .scaleToFill
            addSubview(v)
            entries.append((v, item.1))
        }
        canvas = size
        self.checker = checker
        setNeedsLayout()
        setNeedsDisplay()
    }

    func setHidden(_ index: Int, _ hidden: Bool) {
        if entries.indices.contains(index) { entries[index].view.isHidden = hidden }
    }

    private func fitted() -> CGRect {
        guard canvas.width > 0, canvas.height > 0, bounds.width > 0, bounds.height > 0 else { return .zero }
        let s = min(bounds.width / canvas.width, bounds.height / canvas.height)
        let w = canvas.width * s, h = canvas.height * s
        return CGRect(x: (bounds.width - w) / 2, y: (bounds.height - h) / 2, width: w, height: h)
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        let f = fitted()
        guard f.width > 0 else { return }
        let s = f.width / canvas.width
        for e in entries {
            e.view.frame = CGRect(x: f.minX + e.rect.minX * s, y: f.minY + e.rect.minY * s,
                                  width: e.rect.width * s, height: e.rect.height * s)
        }
        setNeedsDisplay()
    }

    override func draw(_ rect: CGRect) {
        guard checker, let c = UIGraphicsGetCurrentContext() else { return }
        let f = fitted()
        guard f.width > 0 else { return }
        c.saveGState()
        c.clip(to: f)
        fillRect(c, f, C.CARD)
        let cell: CGFloat = 10
        var y = f.minY
        var row = 0
        while y < f.maxY {
            var x = f.minX + (row % 2 == 0 ? 0 : cell)
            while x < f.maxX {
                fillRect(c, CGRect(x: x, y: y, width: cell, height: cell), C.CARD2)
                x += cell * 2
            }
            y += cell
            row += 1
        }
        c.restoreGState()
    }
}

// MARK: - screen ----------------------------------------------------------------------------

final class AnimeDecomposeViewController: UIViewController, PHPickerViewControllerDelegate {

    private let pad: CGFloat = 16

    // state
    private var sourceImage: UIImage?
    private var result: DecomposeResult?
    private var opts = DecomposeOptions()

    private var aiSwitch: UISwitch?
    private var aiStatus: UILabel?
    private var aiDelete: UIButton?
    private var aiWorking = false

    private func aiStatusText() -> String {
        if !AnimeSegModel.runtimeLinked { return "Not available: this build has no ONNX Runtime (add the package to project.yml)" }
        if !AnimeSegModel.onnxInstalled { return "Turn on to download the model (176 MB, once). After that it works offline." }
        if opts.useAI && aiWorking { return String(format: "Working ✓ · tested OK (%.1fs) · runs offline", AnimeSegModel.testSecs) }
        return "Model downloaded · off"
    }

    private func aiRefresh() {
        aiStatus?.text = aiStatusText()
        aiDelete?.isHidden = !AnimeSegModel.onnxInstalled
    }

    private func aiRow() -> UIView {
        let t = UILabel()
        t.text = "AI cut-out (ISNet anime)"
        t.font = .systemFont(ofSize: 14, weight: .semibold)
        t.textColor = argbToUIColor(C.TEXT)
        let s = UILabel()
        s.font = .systemFont(ofSize: 12)
        s.textColor = argbToUIColor(C.DIM)
        s.numberOfLines = 0
        let del = UIButton(type: .system)
        del.setTitle("Delete model (frees 176 MB)", for: .normal)
        del.titleLabel?.font = .systemFont(ofSize: 12, weight: .semibold)
        del.setTitleColor(.systemRed, for: .normal)
        del.contentHorizontalAlignment = .leading
        del.addAction(UIAction { [weak self] _ in self?.aiConfirmDelete() }, for: .touchUpInside)
        aiDelete = del
        let labels = UIStackView(arrangedSubviews: [t, s, del])
        labels.axis = .vertical
        labels.spacing = 2
        let sw = UISwitch()
        sw.isOn = false
        sw.onTintColor = argbToUIColor(C.GREEN)
        sw.setContentHuggingPriority(.required, for: .horizontal)
        sw.addAction(UIAction { [weak self, weak sw] _ in
            if let sw = sw { self?.aiToggled(sw.isOn) }
        }, for: .valueChanged)
        aiSwitch = sw
        aiStatus = s
        opts.useAI = false
        aiRefresh()
        let row = UIStackView(arrangedSubviews: [labels, sw])
        row.axis = .horizontal
        row.alignment = .center
        row.spacing = 10
        if AnimeSegModel.runtimeLinked && AnimeSegModel.onnxInstalled { aiVerifyAndEnable() }
        return row
    }

    private func aiConfirmDelete() {
        let a = UIAlertController(title: "Delete AI model?", message: "You can download it again any time.", preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        a.addAction(UIAlertAction(title: "Delete", style: .destructive) { [weak self] _ in
            AnimeSegModel.removeModel()
            self?.aiWorking = false
            self?.opts.useAI = false
            self?.aiSwitch?.setOn(false, animated: true)
            self?.aiSwitch?.isEnabled = true
            self?.aiRefresh()
        })
        present(a, animated: true)
    }

    private func aiToggled(_ on: Bool) {
        guard let sw = aiSwitch else { return }
        if !on { opts.useAI = false; aiWorking = false; aiRefresh(); return }
        guard AnimeSegModel.runtimeLinked else { aiFail(aiStatusText()); return }
        if AnimeSegModel.onnxInstalled { aiVerifyAndEnable(); return }
        sw.isEnabled = false
        aiDelete?.isHidden = true
        aiStatus?.text = "Downloading… 0%"
        AnimeSegModel.download(progress: { [weak self] f in
            self?.aiStatus?.text = "Downloading… \(Int(f * 100))%"
        }) { [weak self] ok in
            if ok { self?.aiVerifyAndEnable() }
            else { self?.aiFail("Download failed. Check your connection, then turn it on again.") }
        }
    }

    private func aiVerifyAndEnable() {
        aiSwitch?.isEnabled = false
        aiStatus?.text = "Testing model on this phone…"
        DispatchQueue.global(qos: .userInitiated).async {
            let ok = AnimeSegModel.verify()
            DispatchQueue.main.async { [weak self] in
                if ok {
                    self?.aiWorking = true
                    self?.opts.useAI = true
                    self?.aiSwitch?.setOn(true, animated: true)
                    self?.aiSwitch?.isEnabled = true
                    self?.aiRefresh()
                } else {
                    let why = AnimeSegModel.lastError.map { ": " + $0 } ?? ""
                    self?.aiFail("Model test failed" + why)
                }
            }
        }
    }

    private func aiFail(_ msg: String) {
        opts.useAI = false
        aiWorking = false
        aiSwitch?.setOn(false, animated: true)
        aiSwitch?.isEnabled = true
        aiRefresh()
        aiStatus?.text = msg
    }
    private var token: CancelToken?
    private var running = false

    // views
    private let scroll = UIScrollView()
    private let stack = UIStackView()
    private let canvas = LayerPreviewCanvas()
    private let placeholder = UILabel()
    private let settingsCard = UIView()
    private let separateBtn = HomeBigButton()
    private let progressCard = UIView()
    private let progressBar = UIProgressView(progressViewStyle: .default)
    private let statusLabel = UILabel()
    private let resultsStack = UIStackView()
    private let layerList = UIStackView()
    private let layersTitle = UILabel()
    private var exportButtons: [HomeBigButton] = []

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    // MARK: lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = argbToUIColor(C.BG)
        CrashLog.note("anime_decompose")
        buildUi()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        // leaving mid-run: stop the work, nobody is waiting for it
        if isMovingFromParent { token?.cancel() }
    }

    // MARK: helpers

    private func kerned(_ s: String, _ size: CGFloat = 13, _ weight: UIFont.Weight = .bold,
                        kern: CGFloat = 1.6) -> NSAttributedString {
        NSAttributedString(string: s.uppercased(), attributes: [
            .kern: kern, .font: UIFont.systemFont(ofSize: size, weight: weight)])
    }

    private func bigButton(_ title: String, _ icon: String, orange: Bool, _ action: @escaping () -> Void) -> HomeBigButton {
        let b = HomeBigButton()
        b.title = kerned(title, orange ? 14 : 13)
        b.bg = orange ? C.GREEN : Int32(bitPattern: 0xFF14351F)
        b.fg = orange ? C.ONDARK : C.GREEN
        b.icon = icon
        b.tapped = action
        b.translatesAutoresizingMaskIntoConstraints = false
        b.heightAnchor.constraint(equalToConstant: 46).isActive = true
        return b
    }

    private func caption(_ s: String) -> UILabel {
        let l = UILabel()
        l.attributedText = kerned(s, 11, .semibold, kern: 1.2)
        l.textColor = argbToUIColor(C.DIM)
        return l
    }

    private func wrapCard(_ inner: UIView, inset: CGFloat = 14) -> UIView {
        let card = UIView()
        card.backgroundColor = argbToUIColor(C.CARD)
        card.layer.cornerRadius = 14
        inner.translatesAutoresizingMaskIntoConstraints = false
        card.addSubview(inner)
        NSLayoutConstraint.activate([
            inner.topAnchor.constraint(equalTo: card.topAnchor, constant: inset),
            inner.bottomAnchor.constraint(equalTo: card.bottomAnchor, constant: -inset),
            inner.leadingAnchor.constraint(equalTo: card.leadingAnchor, constant: inset),
            inner.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -inset),
        ])
        return card
    }

    // MARK: ui

    private func buildUi() {
        // header: back + wordmark + title (same rhythm as the Projects tab)
        let back = ToolIconButton()
        back.icon = "back"
        back.onClick = { [weak self] in self?.goBack() }
        back.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(back)

        let wordmark = UILabel()
        wordmark.attributedText = kerned("TOOLS", 12, .bold, kern: 2.2)
        wordmark.textColor = argbToUIColor(C.GREEN)
        wordmark.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(wordmark)

        let title = UILabel()
        title.text = "Anime Decomposition"
        title.font = .boldSystemFont(ofSize: 24)
        title.textColor = argbToUIColor(C.TEXT)
        title.adjustsFontSizeToFitWidth = true
        title.minimumScaleFactor = 0.7
        title.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(title)

        scroll.alwaysBounceVertical = true
        scroll.keyboardDismissMode = .onDrag
        scroll.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scroll)

        stack.axis = .vertical
        stack.spacing = 12
        stack.translatesAutoresizingMaskIntoConstraints = false
        scroll.addSubview(stack)

        NSLayoutConstraint.activate([
            back.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 6),
            back.centerYAnchor.constraint(equalTo: title.centerYAnchor, constant: -6),
            back.widthAnchor.constraint(equalToConstant: 44),
            back.heightAnchor.constraint(equalToConstant: 44),
            wordmark.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16),
            wordmark.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 50),
            title.topAnchor.constraint(equalTo: wordmark.bottomAnchor, constant: 2),
            title.leadingAnchor.constraint(equalTo: wordmark.leadingAnchor),
            title.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -pad),
            scroll.topAnchor.constraint(equalTo: title.bottomAnchor, constant: 10),
            scroll.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scroll.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scroll.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            stack.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor, constant: 4),
            stack.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor, constant: -40),
            stack.leadingAnchor.constraint(equalTo: scroll.contentLayoutGuide.leadingAnchor, constant: pad),
            stack.trailingAnchor.constraint(equalTo: scroll.contentLayoutGuide.trailingAnchor, constant: -pad),
            stack.widthAnchor.constraint(equalTo: scroll.frameLayoutGuide.widthAnchor, constant: -2 * pad),
        ])

        // 1. preview
        let preview = UIView()
        preview.backgroundColor = argbToUIColor(C.CARD)
        preview.layer.cornerRadius = 14
        preview.clipsToBounds = true
        preview.heightAnchor.constraint(equalToConstant: 340).isActive = true
        canvas.translatesAutoresizingMaskIntoConstraints = false
        preview.addSubview(canvas)
        placeholder.text = "Tap CHOOSE IMAGE to pick an anime character"
        placeholder.font = .systemFont(ofSize: 13)
        placeholder.textColor = argbToUIColor(C.DIM)
        placeholder.textAlignment = .center
        placeholder.numberOfLines = 0
        placeholder.translatesAutoresizingMaskIntoConstraints = false
        preview.addSubview(placeholder)
        NSLayoutConstraint.activate([
            canvas.topAnchor.constraint(equalTo: preview.topAnchor, constant: 8),
            canvas.bottomAnchor.constraint(equalTo: preview.bottomAnchor, constant: -8),
            canvas.leadingAnchor.constraint(equalTo: preview.leadingAnchor, constant: 8),
            canvas.trailingAnchor.constraint(equalTo: preview.trailingAnchor, constant: -8),
            placeholder.centerYAnchor.constraint(equalTo: preview.centerYAnchor),
            placeholder.leadingAnchor.constraint(equalTo: preview.leadingAnchor, constant: 30),
            placeholder.trailingAnchor.constraint(equalTo: preview.trailingAnchor, constant: -30),
        ])
        stack.addArrangedSubview(preview)

        // 2. choose image
        stack.addArrangedSubview(bigButton("Choose image", "import", orange: false) { [weak self] in
            self?.chooseImage()
        })

        // 3. settings
        let col = UIStackView()
        col.axis = .vertical
        col.spacing = 14
        col.addArrangedSubview(caption("Settings"))
        col.addArrangedSubview(segmentBlock("Quality", ["Fast", "Balanced", "High", "Ultra"], opts.quality) { [weak self] i in
            guard let self = self else { return }
            self.opts.quality = i
            self.opts.maxSide = DecomposeOptions.preset(i).maxSide
            if i == 3 { Toast.show("Ultra uses more memory and time (about 2–5 min)") }
        })
        col.addArrangedSubview(sliderRow("Detail", 1, 10, Float(opts.detail), { "\(Int($0.rounded()))" }) { [weak self] v in
            self?.opts.detail = Int(v.rounded())
        })
        col.addArrangedSubview(sliderRow("Edge smoothing", 0, 3, Float(opts.smoothing), { ["Off", "Low", "Medium", "High"][max(0, min(3, Int($0.rounded())))] }) { [weak self] v in
            self?.opts.smoothing = Int(v.rounded())
        })
        col.addArrangedSubview(caption("Background"))
        col.addArrangedSubview(switchRow("Remove background", "Cuts the character out (flat colours and busy scenes)", opts.removeBackground) { [weak self] on in
            self?.opts.removeBackground = on
        })
        col.addArrangedSubview(switchRow("Keep background layer", "Adds the removed background as its own layer", opts.keepBackground) { [weak self] on in
            self?.opts.keepBackground = on
        })
        col.addArrangedSubview(caption("Parts"))
        col.addArrangedSubview(switchRow("Separate eyes, eyelids & mouth", "Eyes, eyelids, eyebrows and mouth become their own layers", opts.splitFace) { [weak self] on in
            self?.opts.splitFace = on
        })
        col.addArrangedSubview(switchRow("Hair strands", "Splits hair into separate pieces (bangs, sides, back, highlights)", opts.hairStrands) { [weak self] on in
            self?.opts.hairStrands = on
        })
        col.addArrangedSubview(sliderRow("Max hair layers", 4, 60, Float(opts.strandLimit), { "\(Int($0.rounded()))" }) { [weak self] v in
            self?.opts.strandLimit = Int(v.rounded())
        })
        col.addArrangedSubview(switchRow("Separate body parts", "Neck, arms and legs", opts.splitBody) { [weak self] on in
            self?.opts.splitBody = on
        })
        col.addArrangedSubview(switchRow("Separate clothes", "Top, bottom, footwear by colour", opts.splitClothes) { [weak self] on in
            self?.opts.splitClothes = on
        })
        col.addArrangedSubview(caption("Line art"))
        col.addArrangedSubview(segmentBlock("Line art layers", ["Merge", "One layer", "Per part"], opts.lineMode) { [weak self] i in
            self?.opts.lineMode = i
        })
        col.addArrangedSubview(sliderRow("Line sensitivity", 1, 3, Float(opts.lineSensitivity), { ["", "Low", "Medium", "High"][max(1, min(3, Int($0.rounded())))] }) { [weak self] v in
            self?.opts.lineSensitivity = Int(v.rounded())
        })
        col.addArrangedSubview(caption("Output"))
        col.addArrangedSubview(switchRow("Auto group", "Groups layers into Head, Hair, Body, Clothes… in the project", opts.autoGroup) { [weak self] on in
            self?.opts.autoGroup = on
        })
        col.addArrangedSubview(aiRow())
        col.addArrangedSubview(switchRow("Fill hidden gaps", "Adds hidden skin and colour under eyes, hair and lines so parts can move freely", opts.fillGaps) { [weak self] on in
            self?.opts.fillGaps = on
        })
        settingsCard.backgroundColor = argbToUIColor(C.CARD)
        settingsCard.layer.cornerRadius = 14
        col.translatesAutoresizingMaskIntoConstraints = false
        settingsCard.addSubview(col)
        NSLayoutConstraint.activate([
            col.topAnchor.constraint(equalTo: settingsCard.topAnchor, constant: 14),
            col.bottomAnchor.constraint(equalTo: settingsCard.bottomAnchor, constant: -14),
            col.leadingAnchor.constraint(equalTo: settingsCard.leadingAnchor, constant: 14),
            col.trailingAnchor.constraint(equalTo: settingsCard.trailingAnchor, constant: -14),
        ])
        stack.addArrangedSubview(settingsCard)

        // 4. separate
        separateBtn.title = kerned("Separate layers", 14)
        separateBtn.bg = C.GREEN
        separateBtn.fg = C.ONDARK
        separateBtn.icon = "layers"
        separateBtn.tapped = { [weak self] in self?.startSeparate() }
        separateBtn.translatesAutoresizingMaskIntoConstraints = false
        separateBtn.heightAnchor.constraint(equalToConstant: 46).isActive = true
        separateBtn.alpha = 0.45
        stack.addArrangedSubview(separateBtn)

        // 5. progress (hidden until running)
        let pcol = UIStackView()
        pcol.axis = .vertical
        pcol.spacing = 10
        statusLabel.font = .systemFont(ofSize: 13, weight: .medium)
        statusLabel.textColor = argbToUIColor(C.TEXT)
        statusLabel.text = "Starting…"
        progressBar.progressTintColor = argbToUIColor(C.GREEN)
        progressBar.trackTintColor = argbToUIColor(C.CARD2)
        pcol.addArrangedSubview(statusLabel)
        pcol.addArrangedSubview(progressBar)
        let cancel = HomeBigButton()
        cancel.title = kerned("Cancel", 13)
        cancel.bg = Int32(bitPattern: 0xFF3A1A1A)
        cancel.fg = C.RED
        cancel.icon = "close"
        cancel.tapped = { [weak self] in self?.cancelRun() }
        cancel.translatesAutoresizingMaskIntoConstraints = false
        cancel.heightAnchor.constraint(equalToConstant: 46).isActive = true
        pcol.addArrangedSubview(cancel)
        let pc = wrapCard(pcol)
        progressCard.backgroundColor = .clear
        progressCard.addSubview(pc)
        pc.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            pc.topAnchor.constraint(equalTo: progressCard.topAnchor),
            pc.bottomAnchor.constraint(equalTo: progressCard.bottomAnchor),
            pc.leadingAnchor.constraint(equalTo: progressCard.leadingAnchor),
            pc.trailingAnchor.constraint(equalTo: progressCard.trailingAnchor),
        ])
        progressCard.isHidden = true
        stack.addArrangedSubview(progressCard)

        // 6. results (hidden until a run finishes)
        resultsStack.axis = .vertical
        resultsStack.spacing = 12
        layersTitle.textColor = argbToUIColor(C.GREEN)
        resultsStack.addArrangedSubview(layersTitle)
        layerList.axis = .vertical
        layerList.spacing = 8
        resultsStack.addArrangedSubview(layerList)
        resultsStack.addArrangedSubview(caption("Export"))
        let psd = bigButton("Export as PSD", "export", orange: false) { [weak self] in self?.exportPSD() }
        let img = bigButton("Export as image", "media", orange: false) { [weak self] in self?.exportImage() }
        let prj = bigButton("Export to project", "plus", orange: true) { [weak self] in self?.exportToProject() }
        let paint = bigButton("Send to Paint", "edit", orange: false) { [weak self] in self?.sendToPaint() }
        exportButtons = [psd, img, paint, prj]
        resultsStack.addArrangedSubview(psd)
        resultsStack.addArrangedSubview(img)
        resultsStack.addArrangedSubview(paint)
        resultsStack.addArrangedSubview(prj)
        resultsStack.isHidden = true
        stack.addArrangedSubview(resultsStack)
    }

    // MARK: setting rows

    private func sliderRow(_ title: String, _ lo: Float, _ hi: Float, _ value: Float,
                           _ fmt: @escaping (Float) -> String,
                           _ change: @escaping (Float) -> Void) -> UIView {
        let t = UILabel()
        t.text = title
        t.font = .systemFont(ofSize: 14, weight: .semibold)
        t.textColor = argbToUIColor(C.TEXT)
        let v = UILabel()
        v.text = fmt(value)
        v.font = .systemFont(ofSize: 14, weight: .bold)
        v.textColor = argbToUIColor(C.GREEN)
        v.textAlignment = .right
        v.setContentHuggingPriority(.required, for: .horizontal)
        let top = UIStackView(arrangedSubviews: [t, v])
        top.axis = .horizontal
        let s = UISlider()
        s.minimumValue = lo
        s.maximumValue = hi
        s.value = value
        s.minimumTrackTintColor = argbToUIColor(C.GREEN)
        s.maximumTrackTintColor = argbToUIColor(C.CARD2)
        s.thumbTintColor = argbToUIColor(C.GREEN)
        s.addAction(UIAction { [weak s] _ in
            guard let s = s else { return }
            v.text = fmt(s.value)
            change(s.value)
        }, for: .valueChanged)
        let col = UIStackView(arrangedSubviews: [top, s])
        col.axis = .vertical
        col.spacing = 6
        return col
    }

    private func switchRow(_ title: String, _ sub: String, _ on: Bool,
                           _ change: @escaping (Bool) -> Void) -> UIView {
        let t = UILabel()
        t.text = title
        t.font = .systemFont(ofSize: 14, weight: .semibold)
        t.textColor = argbToUIColor(C.TEXT)
        let s = UILabel()
        s.text = sub
        s.font = .systemFont(ofSize: 12)
        s.textColor = argbToUIColor(C.DIM)
        s.numberOfLines = 0
        let labels = UIStackView(arrangedSubviews: [t, s])
        labels.axis = .vertical
        labels.spacing = 2
        let sw = UISwitch()
        sw.isOn = on
        sw.onTintColor = argbToUIColor(C.GREEN)
        sw.setContentHuggingPriority(.required, for: .horizontal)
        sw.addAction(UIAction { [weak sw] _ in
            if let sw = sw { change(sw.isOn) }
        }, for: .valueChanged)
        let row = UIStackView(arrangedSubviews: [labels, sw])
        row.axis = .horizontal
        row.alignment = .center
        row.spacing = 10
        return row
    }

    private func segmentBlock(_ title: String, _ options: [String], _ selected: Int,
                              _ change: @escaping (Int) -> Void) -> UIView {
        let t = UILabel()
        t.text = title
        t.font = .systemFont(ofSize: 14, weight: .semibold)
        t.textColor = argbToUIColor(C.TEXT)
        let row = UIStackView()
        row.axis = .horizontal
        row.distribution = .fillEqually
        row.spacing = 8
        for (i, opt) in options.enumerated() {
            let p = SegPill()
            p.title = opt
            p.on = i == selected
            p.tapped = { [weak p, weak row] in
                guard let p = p, let row = row else { return }
                for case let q as SegPill in row.arrangedSubviews { q.on = (q === p) }
                change(i)
            }
            p.heightAnchor.constraint(equalToConstant: 34).isActive = true
            row.addArrangedSubview(p)
        }
        let col = UIStackView(arrangedSubviews: [t, row])
        col.axis = .vertical
        col.spacing = 8
        return col
    }

    // MARK: picking an image

    private func goBack() {
        token?.cancel()
        navigationController?.popViewController(animated: true)
    }

    private func chooseImage() {
        guard !running else { return }
        var cfg = PHPickerConfiguration()
        cfg.filter = .images
        cfg.selectionLimit = 1
        let picker = PHPickerViewController(configuration: cfg)
        picker.delegate = self
        present(picker, animated: true)
    }

    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        picker.dismiss(animated: true)
        guard let prov = results.first?.itemProvider, prov.canLoadObject(ofClass: UIImage.self) else { return }
        prov.loadObject(ofClass: UIImage.self) { [weak self] obj, _ in
            DispatchQueue.main.async {
                guard let self = self, let img = obj as? UIImage else {
                    Toast.show("Could not open that image")
                    return
                }
                self.setSource(img)
            }
        }
    }

    private func setSource(_ img: UIImage) {
        sourceImage = img
        result = nil
        placeholder.isHidden = true
        let size = CGSize(width: img.size.width * img.scale, height: img.size.height * img.scale)
        canvas.show([(img, CGRect(origin: .zero, size: size))], size: size, checker: false)
        resultsStack.isHidden = true
        layerList.arrangedSubviews.forEach { $0.removeFromSuperview() }
        separateBtn.alpha = 1
    }

    // MARK: run

    private func startSeparate() {
        guard !running else { return }
        guard let img = sourceImage else { Toast.show("Choose an image first"); return }
        running = true
        let tok = CancelToken()
        token = tok
        let options = opts
        settingsCard.isUserInteractionEnabled = false
        settingsCard.alpha = 0.5
        separateBtn.isHidden = true
        resultsStack.isHidden = true
        progressBar.progress = 0
        statusLabel.text = "Starting…"
        progressCard.isHidden = false

        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let px = AnimeDecomposer.loadPixels(img, maxSide: options.maxSide) else {
                DispatchQueue.main.async { self?.finished(nil, cancelled: false) }
                return
            }
            let res = AnimeDecomposer.run(rgba: px.rgba, width: px.w, height: px.h, options: options, token: tok) { f, s in
                DispatchQueue.main.async { self?.setProgress(f, s) }
            }
            DispatchQueue.main.async { self?.finished(res, cancelled: tok.isCancelled) }
        }
    }

    private func setProgress(_ f: Double, _ s: String) {
        guard running else { return }
        progressBar.setProgress(Float(f), animated: true)
        statusLabel.text = s + "…"
    }

    private func cancelRun() {
        guard running else { return }
        token?.cancel()
        statusLabel.text = "Cancelling…"
    }

    private func finished(_ res: DecomposeResult?, cancelled: Bool) {
        running = false
        progressCard.isHidden = true
        separateBtn.isHidden = false
        settingsCard.isUserInteractionEnabled = true
        settingsCard.alpha = 1
        if cancelled { Toast.show("Cancelled"); return }
        guard let r = res else { Toast.show("Could not separate this image"); return }
        showResult(r)
    }

    // MARK: results

    private func showResult(_ r: DecomposeResult) {
        result = r
        var items: [(UIImage, CGRect)] = []
        var thumbs: [UIImage] = []
        for l in r.layers {
            let im = AnimeDecomposer.image(from: l.rgba, width: l.w, height: l.h) ?? UIImage()
            thumbs.append(im)
            items.append((im, CGRect(x: l.x, y: l.y, width: l.w, height: l.h)))
        }
        canvas.show(items, size: CGSize(width: r.width, height: r.height), checker: true)

        layersTitle.attributedText = kerned("Layers · \(r.layers.count)", 12, .semibold, kern: 1.6)
        layerList.arrangedSubviews.forEach { $0.removeFromSuperview() }
        let total = max(1, r.layers.reduce(0) { $0 + $1.area })
        for (i, l) in r.layers.enumerated() {
            layerList.addArrangedSubview(layerRow(i, l, thumbs[i], Int((Double(l.area) / Double(total) * 100).rounded())))
        }
        resultsStack.isHidden = false
        let groupCount = Set(r.layers.map { $0.group }.filter { !$0.isEmpty }).count
        Toast.show(groupCount > 0 ? "\(r.layers.count) layers in \(groupCount) groups ready" : "\(r.layers.count) layers ready")

        view.layoutIfNeeded()
        let y = resultsStack.convert(CGPoint.zero, to: scroll).y - 12
        let maxY = max(0, scroll.contentSize.height - scroll.bounds.height)
        scroll.setContentOffset(CGPoint(x: 0, y: max(0, min(y, maxY))), animated: true)
    }

    private func layerRow(_ index: Int, _ l: DecomposedLayer, _ thumb: UIImage, _ pct: Int) -> UIView {
        let card = UIView()
        card.backgroundColor = argbToUIColor(C.CARD)
        card.layer.cornerRadius = 12

        let box = UIView()
        box.backgroundColor = argbToUIColor(C.CARD2)
        box.layer.cornerRadius = 8
        box.clipsToBounds = true
        let iv = UIImageView(image: thumb)
        iv.contentMode = .scaleAspectFit
        iv.translatesAutoresizingMaskIntoConstraints = false
        box.addSubview(iv)
        box.translatesAutoresizingMaskIntoConstraints = false

        let name = UILabel()
        name.text = l.name
        name.font = .systemFont(ofSize: 15, weight: .semibold)
        name.textColor = argbToUIColor(C.TEXT)
        let meta = UILabel()
        meta.text = (l.group.isEmpty ? "" : "\(l.group) · ") + "\(pct)% of figure · \(l.w)×\(l.h)"
        meta.font = .systemFont(ofSize: 12)
        meta.textColor = argbToUIColor(C.DIM)
        let labels = UIStackView(arrangedSubviews: [name, meta])
        labels.axis = .vertical
        labels.spacing = 2
        labels.translatesAutoresizingMaskIntoConstraints = false

        let eye = ToolIconButton()
        eye.icon = l.visible ? "eye" : "eye_off"
        eye.tint = l.visible ? C.GREEN : C.DIM
        eye.translatesAutoresizingMaskIntoConstraints = false
        eye.onClick = { [weak self, weak eye] in
            guard let self = self, let eye = eye, var r = self.result, r.layers.indices.contains(index) else { return }
            r.layers[index].visible.toggle()
            self.result = r
            let vis = r.layers[index].visible
            eye.icon = vis ? "eye" : "eye_off"
            eye.tint = vis ? C.GREEN : C.DIM
            self.canvas.setHidden(index, !vis)
        }

        card.addSubview(box)
        card.addSubview(labels)
        card.addSubview(eye)
        NSLayoutConstraint.activate([
            box.leadingAnchor.constraint(equalTo: card.leadingAnchor, constant: 10),
            box.topAnchor.constraint(equalTo: card.topAnchor, constant: 10),
            box.bottomAnchor.constraint(equalTo: card.bottomAnchor, constant: -10),
            box.widthAnchor.constraint(equalToConstant: 52),
            box.heightAnchor.constraint(equalToConstant: 52),
            iv.topAnchor.constraint(equalTo: box.topAnchor, constant: 3),
            iv.bottomAnchor.constraint(equalTo: box.bottomAnchor, constant: -3),
            iv.leadingAnchor.constraint(equalTo: box.leadingAnchor, constant: 3),
            iv.trailingAnchor.constraint(equalTo: box.trailingAnchor, constant: -3),
            labels.leadingAnchor.constraint(equalTo: box.trailingAnchor, constant: 12),
            labels.centerYAnchor.constraint(equalTo: card.centerYAnchor),
            labels.trailingAnchor.constraint(equalTo: eye.leadingAnchor, constant: -6),
            eye.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -6),
            eye.centerYAnchor.constraint(equalTo: card.centerYAnchor),
            eye.widthAnchor.constraint(equalToConstant: 44),
            eye.heightAnchor.constraint(equalToConstant: 44),
        ])
        return card
    }

    // MARK: export

    /// Runs `work` off the main thread, then calls `done` on main.
    private func busy(_ text: String, _ work: @escaping () -> URL?, _ done: @escaping (URL) -> Void) {
        Toast.show(text)
        DispatchQueue.global(qos: .userInitiated).async {
            let u = work()
            DispatchQueue.main.async {
                if let u = u { done(u) } else { Toast.show("Export failed") }
            }
        }
    }

    private func share(_ url: URL, from source: UIView) {
        let vc = UIActivityViewController(activityItems: [url], applicationActivities: nil)
        vc.popoverPresentationController?.sourceView = source
        vc.popoverPresentationController?.sourceRect = source.bounds
        present(vc, animated: true)
    }

    private func tempURL(_ name: String) -> URL {
        FileManager.default.temporaryDirectory.appendingPathComponent(name)
    }

    private func exportPSD() {
        guard let r = result else { return }
        let src = exportButtons[0]
        busy("Building PSD…", {
            let comp = AnimeDecomposer.composite(r.layers, width: r.width, height: r.height)
            let data = PSDWriter.write(width: r.width, height: r.height, layers: r.layers, composite: comp)
            let url = FileManager.default.temporaryDirectory.appendingPathComponent("anime_layers.psd")
            try? FileManager.default.removeItem(at: url)
            do { try data.write(to: url, options: .atomic); return url } catch { return nil }
        }, { [weak self] url in self?.share(url, from: src) })
    }

    private func exportImage() {
        guard let r = result else { return }
        let src = exportButtons[1]
        busy("Building image…", {
            let comp = AnimeDecomposer.composite(r.layers, width: r.width, height: r.height)
            guard let img = AnimeDecomposer.image(from: comp, width: r.width, height: r.height),
                  let png = img.pngData() else { return nil }
            let url = FileManager.default.temporaryDirectory.appendingPathComponent("anime_character.png")
            try? FileManager.default.removeItem(at: url)
            do { try png.write(to: url, options: .atomic); return url } catch { return nil }
        }, { [weak self] url in self?.share(url, from: src) })
    }

    /// Layers → a new artwork in the Drawing Editor's own "Anime Decomposition" gallery folder.
    private func sendToPaint() {
        guard let r = result else { return }
        Toast.show("Sending to Paint…")
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            let f = DateFormatter()
            f.dateFormat = "MMM d HH:mm"
            let art = DrawImport.fromDecomposed(r, name: "Anime " + f.string(from: Date()))
            DispatchQueue.main.async {
                guard let self = self, let nav = self.navigationController else { return }
                var stack = nav.viewControllers
                stack.append(DrawingGalleryViewController(folderId: nil))
                if let pf = art.parent { stack.append(DrawingGalleryViewController(folderId: pf)) }
                stack.append(DrawingEditorViewController(item: art))
                nav.setViewControllers(stack, animated: true)
                Toast.show("Saved to Gallery › Anime Decomposition")
            }
        }
    }

    /// One full-canvas PNG per layer → a new project with every layer in it.
    private func exportToProject() {
        guard let r = result else { return }
        Toast.show("Creating project…")
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            let project = Project(name: "Anime layers", w: r.width, h: r.height, fps: 30)
            let scene = project.scenes[0]
            var ok = true
            var groups: [String: Layer] = [:]
            var groupOrder: [(String, Int)] = []
            for (idx, layer) in r.layers.enumerated() {
                let full = AnimeDecomposer.fullCanvas(layer, width: r.width, height: r.height)
                guard let img = AnimeDecomposer.image(from: full, width: r.width, height: r.height),
                      let png = img.pngData(),
                      let path = ProjectIO.writeDataIntoSandbox(png, name: "\(idx + 1)_\(layer.name).png")
                else { ok = false; break }
                let l = Layer(project.nextId, layer.name, .IMAGE)
                project.nextId += 1
                l.imagePath = path
                l.end = scene.duration
                l.visible = layer.visible
                if !layer.group.isEmpty {
                    var g = groups[layer.group]
                    if g == nil {
                        let ng = Layer(project.nextId, layer.group, .GROUP)
                        project.nextId += 1
                        ng.end = scene.duration
                        groups[layer.group] = ng
                        groupOrder.append((layer.group, layer.order))
                        g = ng
                    }
                    l.parentId = g!.id
                }
                scene.layers.append(l)
            }
            // group layers go on top of the list (like Group Layers in the editor); the
            // part that sits lowest in the stack comes first
            for (name, _) in groupOrder.sorted(by: { $0.1 < $1.1 }) {
                if let g = groups[name] { scene.layers.append(g) }
            }
            let groupTotal = groups.count
            DispatchQueue.main.async {
                guard let self = self else { return }
                guard ok else { Toast.show("Export failed"); return }
                var saved = project
                Projects.save(&saved)
                Toast.show(groupTotal == 0 ? "Project created with \(r.layers.count) layers" : "Project created: \(r.layers.count) layers in \(groupTotal) groups")
                self.navigationController?.pushViewController(EditorViewController(projectId: saved.id), animated: true)
            }
        }
    }
}
