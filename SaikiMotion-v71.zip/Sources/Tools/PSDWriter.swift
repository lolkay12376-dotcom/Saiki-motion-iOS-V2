// PSDWriter.swift — minimal layered Photoshop (.psd) writer.
//
// 8-bit RGB + alpha, one cropped raster layer per DecomposedLayer, PackBits
// (RLE) compressed so transparent layers stay small. Opens in Photoshop,
// Krita, GIMP, Procreate, Clip Studio, Affinity…

import Foundation

enum PSDWriter {

    private static func be16(_ d: inout Data, _ v: Int) {
        d.append(UInt8((v >> 8) & 0xFF)); d.append(UInt8(v & 0xFF))
    }
    private static func be32(_ d: inout Data, _ v: Int) {
        d.append(UInt8((v >> 24) & 0xFF)); d.append(UInt8((v >> 16) & 0xFF))
        d.append(UInt8((v >> 8) & 0xFF)); d.append(UInt8(v & 0xFF))
    }

    /// PackBits one scanline.
    private static func packBits(_ row: [UInt8], into out: inout [UInt8]) {
        let n = row.count
        var i = 0
        while i < n {
            var run = 1
            while i + run < n && run < 128 && row[i + run] == row[i] { run += 1 }
            if run >= 2 {
                out.append(UInt8(truncatingIfNeeded: 1 - run))
                out.append(row[i])
                i += run
            } else {
                var j = i + 1
                while j < n && (j - i) < 128 {
                    if j + 1 < n && row[j] == row[j + 1] { break }
                    j += 1
                }
                out.append(UInt8(j - i - 1))
                for t in i..<j { out.append(row[t]) }
                i = j
            }
        }
    }

    /// RLE-compress one channel plane of an RGBA buffer: (row byte counts, packed bytes).
    private static func rle(_ rgba: [UInt8], _ w: Int, _ h: Int, channel: Int) -> (counts: [Int], bytes: [UInt8]) {
        var counts = [Int](); counts.reserveCapacity(h)
        var bytes = [UInt8]()
        var row = [UInt8](repeating: 0, count: w)
        var packed = [UInt8]()
        for y in 0..<h {
            for x in 0..<w { row[x] = rgba[(y * w + x) * 4 + channel] }
            packed.removeAll(keepingCapacity: true)
            packBits(row, into: &packed)
            counts.append(packed.count)
            bytes.append(contentsOf: packed)
        }
        return (counts, bytes)
    }

    private static func asciiName(_ s: String) -> [UInt8] {
        var out = [UInt8]()
        for u in s.unicodeScalars where u.value >= 32 && u.value < 127 { out.append(UInt8(u.value)) }
        if out.isEmpty { out = Array("Layer".utf8) }
        return Array(out.prefix(31))
    }

    /// `composite` is the full-canvas merged RGBA preview (un-premultiplied).
    static func write(width: Int, height: Int, layers: [DecomposedLayer], composite: [UInt8]) -> Data {
        var d = Data()

        // header
        d.append(contentsOf: Array("8BPS".utf8))
        be16(&d, 1)
        d.append(contentsOf: [UInt8](repeating: 0, count: 6))
        be16(&d, 4)                       // R G B + transparency
        be32(&d, height)
        be32(&d, width)
        be16(&d, 8)                       // bits / channel
        be16(&d, 3)                       // RGB
        be32(&d, 0)                       // colour mode data
        be32(&d, 0)                       // image resources

        // layer records + channel data (layers go bottom → top, same as our order)
        var records = Data()
        var channelData = Data()
        let channelIds = [0, 1, 2, -1]    // R, G, B, alpha
        var written = 0
        for layer in layers where layer.w > 0 && layer.h > 0 {
            written += 1
            be32(&records, layer.y)                    // top
            be32(&records, layer.x)                    // left
            be32(&records, layer.y + layer.h)          // bottom
            be32(&records, layer.x + layer.w)          // right
            be16(&records, 4)
            var planes: [Data] = []
            for (ci, cid) in channelIds.enumerated() {
                let chan = ci == 3 ? 3 : ci
                let r = rle(layer.rgba, layer.w, layer.h, channel: chan)
                var plane = Data()
                be16(&plane, 1)                        // RLE
                for c in r.counts { be16(&plane, c) }
                plane.append(contentsOf: r.bytes)
                planes.append(plane)
                be16(&records, cid)
                be32(&records, plane.count)
            }
            records.append(contentsOf: Array("8BIM".utf8))
            records.append(contentsOf: Array("norm".utf8))
            records.append(255)                        // opacity
            records.append(0)                          // clipping
            records.append(layer.visible ? 0 : 2)      // flags (bit 1 = hidden)
            records.append(0)                          // filler

            let name = asciiName(layer.name)
            var pascal = [UInt8(name.count)] + name
            while pascal.count % 4 != 0 { pascal.append(0) }
            be32(&records, 4 + 4 + pascal.count)       // extra data length
            be32(&records, 0)                          // layer mask
            be32(&records, 0)                          // blending ranges
            records.append(contentsOf: pascal)

            for p in planes { channelData.append(p) }
        }

        var info = Data()
        be16(&info, -written)                          // negative: merged image has transparency
        info.append(records)
        info.append(channelData)
        if info.count % 2 != 0 { info.append(0) }

        var section = Data()
        be32(&section, info.count)
        section.append(info)
        be32(&section, 0)                              // global layer mask info
        be32(&d, section.count)
        d.append(section)

        // merged image (RLE, planar R G B A)
        be16(&d, 1)
        var planesData = Data()
        var counts = Data()
        for ch in 0..<4 {
            let r = rle(composite, width, height, channel: ch)
            for c in r.counts { be16(&counts, c) }
            planesData.append(contentsOf: r.bytes)
        }
        d.append(counts)
        d.append(planesData)
        return d
    }
}
