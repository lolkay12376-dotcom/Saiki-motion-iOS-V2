// AspectPicker.swift — aspect-ratio presets + the picker used by New Project (UI).
//
// Presets: 16:9 9:16 1:1 4:3 3:4 4:5 3:2 2:3 21:9, plus "Custom" (any W : H, e.g. 2.39 : 1).
// `base` everywhere is the SHORT side in pixels (720 / 1080 / 1440), as before, so
// 16:9 @1080 = 1920x1080 and 9:16 @1080 = 1080x1920 are unchanged.

import UIKit

enum AspectPresets {
    static let names  = ["16:9", "9:16", "1:1", "4:3", "3:4", "4:5", "3:2", "2:3", "21:9"]
    static let ratios: [Double] = [16.0 / 9, 9.0 / 16, 1, 4.0 / 3, 3.0 / 4, 4.0 / 5, 3.0 / 2, 2.0 / 3, 21.0 / 9]
    /// Longest edge is capped (GPU texture limits): ratio stays inside 1:4 … 4:1.
    static func clampRatio(_ r: Double) -> Double { min(max(r.isFinite ? r : 1, 0.25), 4) }

    /// Even pixel size for a ratio (W/H) with `base` pixels on the short side.
    static func dims(base: Int, ratio: Double) -> (Int, Int) {
        let r = clampRatio(ratio)
        func even(_ v: Double) -> Int { max(2, Int((v / 2).rounded()) * 2) }
        return r >= 1 ? (even(Double(base) * r), even(Double(base))) : (even(Double(base)), even(Double(base) / r))
    }

    /// Preset index that matches a canvas (within 1%), nil → Custom.
    static func match(_ w: Int, _ h: Int) -> Int? {
        let r = Double(w) / Double(max(h, 1))
        return ratios.firstIndex { abs($0 - r) / $0 < 0.01 }
    }

    /// Parses "W" and "H" text fields (commas allowed) into a ratio.
    static func parse(_ w: String?, _ h: String?) -> Double {
        func num(_ s: String?) -> Double { Double((s ?? "").replacingOccurrences(of: ",", with: ".").trimmingCharacters(in: .whitespaces)) ?? 1 }
        return clampRatio(num(w) / max(num(h), 0.0001))
    }

    /// Short side in pixels of an existing canvas, as a resolution index 0/1/2.
    static func resIndex(_ w: Int, _ h: Int) -> Int {
        let s = min(w, h)
        return s >= 1300 ? 2 : (s >= 900 ? 1 : 0)
    }
}

/// Grid of aspect pills (+ Custom with two number fields).
final class AspectChips: UIView {

    private let stack = UIStackView()
    private var pills: [SegPill] = []
    private let customRow = UIStackView()
    let wField = UITextField()
    let hField = UITextField()
    private(set) var index = 0
    var onChange: (() -> Void)?

    var ratio: Double {
        index < AspectPresets.ratios.count ? AspectPresets.ratios[index] : AspectPresets.parse(wField.text, hField.text)
    }

    init(selected: Int) {
        super.init(frame: .zero)
        stack.axis = .vertical
        stack.spacing = 8
        stack.translatesAutoresizingMaskIntoConstraints = false
        addSubview(stack)
        NSLayoutConstraint.activate([
            stack.topAnchor.constraint(equalTo: topAnchor),
            stack.bottomAnchor.constraint(equalTo: bottomAnchor),
            stack.leadingAnchor.constraint(equalTo: leadingAnchor),
            stack.trailingAnchor.constraint(equalTo: trailingAnchor),
        ])
        index = selected
        let all = AspectPresets.names + ["Custom"]
        var row: UIStackView? = nil
        for (i, nm) in all.enumerated() {
            if i % 4 == 0 {
                let r = UIStackView()
                r.axis = .horizontal; r.distribution = .fillEqually; r.spacing = 8
                stack.addArrangedSubview(r); row = r
            }
            let p = SegPill()
            p.title = nm
            p.on = i == selected
            p.heightAnchor.constraint(equalToConstant: 34).isActive = true
            p.tapped = { [weak self] in self?.select(i) }
            pills.append(p)
            row?.addArrangedSubview(p)
        }
        while let r = row, r.arrangedSubviews.count < 4 { r.addArrangedSubview(UIView()) }   // keep pill widths equal

        customRow.axis = .horizontal
        customRow.alignment = .center
        customRow.spacing = 8
        for (f, v) in [(wField, "21"), (hField, "9")] {
            f.text = v
            f.keyboardType = .decimalPad
            f.textAlignment = .center
            f.font = .systemFont(ofSize: 15, weight: .semibold)
            f.textColor = argbToUIColor(C.TEXT)
            f.backgroundColor = argbToUIColor(C.CARD2)
            f.layer.cornerRadius = 10
            f.heightAnchor.constraint(equalToConstant: 38).isActive = true
            f.addAction(UIAction { [weak self] _ in self?.onChange?() }, for: .editingChanged)
        }
        let colon = UILabel()
        colon.text = ":"
        colon.textColor = argbToUIColor(C.DIM)
        colon.font = .systemFont(ofSize: 18, weight: .bold)
        customRow.addArrangedSubview(wField)
        customRow.addArrangedSubview(colon)
        customRow.addArrangedSubview(hField)
        wField.widthAnchor.constraint(equalTo: hField.widthAnchor).isActive = true
        customRow.isHidden = selected < AspectPresets.names.count
        stack.addArrangedSubview(customRow)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    /// Pre-fills the Custom fields (e.g. from the current canvas) and selects Custom.
    func setCustom(w: Int, h: Int) {
        let g = { (a: Int, b: Int) -> Int in var x = a, y = b; while y != 0 { (x, y) = (y, x % y) }; return max(x, 1) }(w, h)
        wField.text = "\(w / g)"; hField.text = "\(h / g)"
        select(AspectPresets.names.count)
    }

    func select(_ i: Int) {
        index = i
        for (k, p) in pills.enumerated() { p.on = k == i }
        customRow.isHidden = i < AspectPresets.names.count
        onChange?()
    }
}
