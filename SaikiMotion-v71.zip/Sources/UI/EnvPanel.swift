// EnvPanel.swift — Scene 3D "+" > Environment. Browse / import Poly Haven HDRIs; lights and reflects models, terrain PBR and water.
import UIKit

final class EnvPanel: UIView, UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate {
    private weak var host: EditorViewController?
    private let accent = UIColor(red: 1, green: 0.55, blue: 0.08, alpha: 1)
    private let search = UISearchBar(), table = UITableView(), status = UILabel(), quality = UISegmentedControl(items: ["1k (fast)", "2k"])
    private var all: [(id: String, name: String)] = [], shown: [(id: String, name: String)] = []
    private static var listCache: [(id: String, name: String)] = []
    private var busy = false

    static func present(in host: EditorViewController, over view: UIView) {
        if view.subviews.contains(where: { $0 is EnvPanel }) { return }
        let v = EnvPanel(host: host)
        v.translatesAutoresizingMaskIntoConstraints = false; view.addSubview(v)
        NSLayoutConstraint.activate([v.leadingAnchor.constraint(equalTo: view.leadingAnchor), v.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                                     v.topAnchor.constraint(equalTo: view.topAnchor), v.bottomAnchor.constraint(equalTo: view.bottomAnchor)])
    }

    init(host: EditorViewController) {
        self.host = host
        super.init(frame: .zero)
        backgroundColor = UIColor(white: 0, alpha: 0.55)
        build()
        if EnvPanel.listCache.isEmpty {
            PolyHaven.get("https://api.polyhaven.com/assets?t=hdris") { [weak self] d in DispatchQueue.main.async {
                guard let self = self else { return }
                if let d = d, let o = (try? JSONSerialization.jsonObject(with: d)) as? [String: [String: Any]] {
                    EnvPanel.listCache = o.map { (id: $0.key, name: ($0.value["name"] as? String) ?? $0.key) }.sorted { $0.name.lowercased() < $1.name.lowercased() }
                }
                self.all = EnvPanel.listCache; self.filter("")
                if self.all.isEmpty { self.status.text = "Could not reach Poly Haven. Check your connection." } } }
        } else { all = EnvPanel.listCache; filter("") }
    }
    required init?(coder: NSCoder) { fatalError() }

    private func label(_ t: String, _ size: CGFloat = 13, _ w: UIFont.Weight = .regular, _ c: UIColor = UIColor(white: 0.7, alpha: 1)) -> UILabel {
        let l = UILabel(); l.text = t; l.textColor = c; l.font = .systemFont(ofSize: size, weight: w); return l
    }
    private func slider(_ title: String, _ lo: Float, _ hi: Float, _ v: Float, _ cb: @escaping (Float) -> Void) -> UIStackView {
        let l = label(title); l.widthAnchor.constraint(equalToConstant: 84).isActive = true
        let val = label(String(format: "%.2f", v), 12); val.textAlignment = .right; val.widthAnchor.constraint(equalToConstant: 42).isActive = true
        let s = UISlider(); s.minimumValue = lo; s.maximumValue = hi; s.value = v; s.tintColor = accent
        s.addAction(UIAction { [weak s, weak val] _ in guard let s = s else { return }; val?.text = String(format: "%.2f", s.value); cb(s.value) }, for: .valueChanged)
        let r = UIStackView(arrangedSubviews: [l, s, val]); r.spacing = 8; r.alignment = .center; return r
    }

    private func build() {
        let card = UIView(); card.backgroundColor = UIColor(white: 0.09, alpha: 1); card.layer.cornerRadius = 22
        card.translatesAutoresizingMaskIntoConstraints = false; addSubview(card)
        let x = UIButton(type: .system); x.setImage(UIImage(systemName: "xmark"), for: .normal); x.tintColor = .white
        x.addAction(UIAction { [weak self] _ in self?.removeFromSuperview() }, for: .touchUpInside)
        let head = UIStackView(arrangedSubviews: [label("Environment", 22, .bold, .white), UIView(), x]); head.alignment = .center
        search.placeholder = "Search Poly Haven HDRIs (sky, forest, studio…)"; search.searchBarStyle = .minimal; search.delegate = self
        search.searchTextField.textColor = .white; search.autocapitalizationType = .none
        table.dataSource = self; table.delegate = self; table.backgroundColor = .clear; table.rowHeight = 60; table.separatorColor = UIColor(white: 1, alpha: 0.08)
        quality.selectedSegmentTintColor = accent; quality.selectedSegmentIndex = 0
        quality.setTitleTextAttributes([.foregroundColor: UIColor.white], for: .normal); quality.setTitleTextAttributes([.foregroundColor: UIColor.black], for: .selected)
        let rm = UIButton(type: .system); rm.setTitle("Remove environment", for: .normal); rm.tintColor = UIColor(red: 1, green: 0.4, blue: 0.4, alpha: 1)
        rm.addAction(UIAction { [weak self] _ in GlobalEnv.path = nil; self?.status.text = "Environment removed."; self?.host?.render() }, for: .touchUpInside)
        status.textColor = UIColor(white: 0.7, alpha: 1); status.font = .systemFont(ofSize: 12); status.numberOfLines = 2
        status.text = GlobalEnv.path == nil ? "Pick an HDRI. It lights and reflects PBR, terrain and water." : "An environment is active."
        let q = UIStackView(arrangedSubviews: [label("Quality"), quality]); q.spacing = 10; q.alignment = .center
        let stack = UIStackView(arrangedSubviews: [head, search, table,
            slider("Intensity", 0, 3, R3D.g("env", 1)) { [weak self] in R3D.set("env", $0); self?.host?.render() },
            slider("Rotation", 0, 1, R3D.g("envRot", 0)) { [weak self] in R3D.set("envRot", $0); self?.host?.render() },
            q, rm, status])
        stack.axis = .vertical; stack.spacing = 10; stack.translatesAutoresizingMaskIntoConstraints = false; card.addSubview(stack)
        NSLayoutConstraint.activate([
            card.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 12), card.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -12),
            card.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor, constant: 40), card.bottomAnchor.constraint(equalTo: safeAreaLayoutGuide.bottomAnchor, constant: -12),
            stack.leadingAnchor.constraint(equalTo: card.leadingAnchor, constant: 16), stack.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -16),
            stack.topAnchor.constraint(equalTo: card.topAnchor, constant: 16), stack.bottomAnchor.constraint(equalTo: card.bottomAnchor, constant: -16)])
    }

    /// Inside-out UV sphere (equirect mapped, unlit) textured with the HDRI's preview picture.
    static func skyGLB(_ jpg: Data) -> Data? {
        let W = 64, H = 32
        var pos: [Float] = [], nor: [Float] = [], uv: [Float] = [], idx: [UInt32] = []
        for j in 0...H { for i in 0...W {
            let v = Float(j) / Float(H), u = Float(i) / Float(W), th = v * .pi, ph = (u - 0.5) * 2 * .pi
            let x = sinf(th) * cosf(ph), y = cosf(th), z = sinf(th) * sinf(ph)
            pos += [x * 0.5, y * 0.5, z * 0.5]; nor += [-x, -y, -z]; uv += [u, v]
        } }
        for j in 0..<H { for i in 0..<W {
            let a = UInt32(i + j * (W + 1)), b = a + UInt32(W + 1)
            idx += [a, a + 1, b, a + 1, b + 1, b]
        } }
        var bin = Data(); var views: [[String: Any]] = []
        func add(_ d: Data, _ t: Int?) -> Int {
            while bin.count % 4 != 0 { bin.append(0) }
            var v: [String: Any] = ["buffer": 0, "byteOffset": bin.count, "byteLength": d.count]
            if let t = t { v["target"] = t }
            bin.append(d); views.append(v); return views.count - 1
        }
        func bytes<T>(_ a: [T]) -> Data { a.withUnsafeBytes { Data($0) } }
        let vp = add(bytes(pos), 34962), vn = add(bytes(nor), 34962), vu = add(bytes(uv), 34962), vi = add(bytes(idx), 34963), im = add(jpg, nil)
        let nv = pos.count / 3
        let acc: [[String: Any]] = [
            ["bufferView": vp, "componentType": 5126, "count": nv, "type": "VEC3", "min": [-0.5, -0.5, -0.5], "max": [0.5, 0.5, 0.5]],
            ["bufferView": vn, "componentType": 5126, "count": nv, "type": "VEC3"],
            ["bufferView": vu, "componentType": 5126, "count": nv, "type": "VEC2"],
            ["bufferView": vi, "componentType": 5125, "count": idx.count, "type": "SCALAR"]]
        let json: [String: Any] = [
            "asset": ["version": "2.0", "generator": "SaikiMotion Sky"], "extensionsUsed": ["KHR_materials_unlit"],
            "scene": 0, "scenes": [["nodes": [0]]], "nodes": [["mesh": 0]],
            "meshes": [["primitives": [["attributes": ["POSITION": 0, "NORMAL": 1, "TEXCOORD_0": 2], "indices": 3, "material": 0]]]],
            "materials": [["doubleSided": true, "extensions": ["KHR_materials_unlit": [String: Any]()],
                           "pbrMetallicRoughness": ["baseColorTexture": ["index": 0], "metallicFactor": 0.0, "roughnessFactor": 1.0]]],
            "textures": [["source": 0, "sampler": 0]], "images": [["bufferView": im, "mimeType": "image/jpeg"]],
            "samplers": [["magFilter": 9729, "minFilter": 9987, "wrapS": 10497, "wrapT": 33071]],
            "accessors": acc, "bufferViews": views, "buffers": [["byteLength": bin.count]]]
        guard var js = try? JSONSerialization.data(withJSONObject: json) else { return nil }
        while js.count % 4 != 0 { js.append(0x20) }
        while bin.count % 4 != 0 { bin.append(0) }
        var out = Data()
        func u32(_ v: UInt32) { var x = v.littleEndian; withUnsafeBytes(of: &x) { out.append(contentsOf: $0) } }
        u32(0x46546C67); u32(2); u32(UInt32(12 + 8 + js.count + 8 + bin.count))
        u32(UInt32(js.count)); u32(0x4E4F534A); out.append(js)
        u32(UInt32(bin.count)); u32(0x004E4942); out.append(bin)
        return out
    }

    private func filter(_ q: String) {
        let k = q.trimmingCharacters(in: .whitespaces).lowercased()
        shown = k.isEmpty ? all : all.filter { $0.name.lowercased().contains(k) || $0.id.contains(k) }
        table.reloadData()
    }
    func searchBar(_ s: UISearchBar, textDidChange t: String) { filter(t) }
    func searchBarSearchButtonClicked(_ s: UISearchBar) { s.resignFirstResponder() }
    func tableView(_ t: UITableView, numberOfRowsInSection s: Int) -> Int { shown.count }
    func tableView(_ t: UITableView, cellForRowAt ip: IndexPath) -> UITableViewCell {
        let c = t.dequeueReusableCell(withIdentifier: "c") ?? UITableViewCell(style: .default, reuseIdentifier: "c")
        c.backgroundColor = .clear; c.textLabel?.textColor = .white
        let it = shown[ip.row]
        c.textLabel?.text = it.name; c.imageView?.image = UIImage(systemName: "sun.max")
        PolyHaven.thumb(it.id) { [weak c] img in
            guard let img = img, let c = c, c.textLabel?.text == it.name else { return }
            c.imageView?.image = img; c.setNeedsLayout()
        }
        return c
    }
    func tableView(_ t: UITableView, didSelectRowAt ip: IndexPath) {
        t.deselectRow(at: ip, animated: true); search.resignFirstResponder()
        guard !busy else { return }
        busy = true; let it = shown[ip.row], res = quality.selectedSegmentIndex == 0 ? "1k" : "2k"
        status.text = "Downloading \(it.name)…"
        func fail(_ m: String) { DispatchQueue.main.async { self.busy = false; self.status.text = m } }
        PolyHaven.get("https://api.polyhaven.com/files/\(it.id)") { d in
            guard let d = d, let f = (try? JSONSerialization.jsonObject(with: d)) as? [String: Any], let h = f["hdri"] as? [String: Any] else { fail("Download failed."); return }
            var url: String?, ext = "hdr"
            for r in [res, "1k", "2k", "4k"] where url == nil {
                for e in ["hdr", "exr"] where url == nil {
                    if let u = ((h[r] as? [String: Any])?[e] as? [String: Any])?["url"] as? String { url = u; ext = e }
                }
            }
            guard let u = url else { fail("No HDRI file found."); return }
            let tmUrl = (f["tonemapped"] as? [String: Any])?["url"] as? String
            PolyHaven.get(u) { data in
                guard let data = data, let path = ProjectIO.writeDataIntoSandbox(data, name: "env_\(it.id)_\(res).\(ext)") else { fail("Download failed."); return }
                func finish(_ sky: Data?) {
                    let skyPath = sky.flatMap { EnvPanel.skyGLB($0) }.flatMap { ProjectIO.writeDataIntoSandbox($0, name: "sky_\(it.id)_\(nowMs()).glb") }
                    DispatchQueue.main.async {
                        self.busy = false; GlobalEnv.path = path
                        self.status.text = "\(it.name) applied."
                        if let sp = skyPath, let h = self.host {      // visible sky dome as its own layer
                            for old in Editor.scene.layers.filter({ $0.name.hasPrefix("Sky · ") }) { Editor.scene.layers.removeAll { $0 === old } }
                            h.addMedia(sp, .MODEL)
                            if let l = Editor.scene.layers.last(where: { $0.imagePath == sp }) {
                                l.name = "Sky · \(it.name)"; l.track("scale").base = 40; l.m3Env = false
                                h.refreshPanel()
                            }
                        }
                        self.host?.render()
                    }
                }
                if let t = tmUrl { PolyHaven.get(t) { finish($0) } } else { finish(nil) }
            }
        }
    }
}
