// FontBrowserViewController.swift — browse, import and organise fonts, pick one for a text layer.

import UIKit
import UniformTypeIdentifiers

final class FontBrowserViewController: UIViewController, UITableViewDataSource, UITableViewDelegate,
                                       UIDocumentPickerDelegate {
    var onPick: ((FontRecord) -> Void)?
    var currentPath: String?
    private let folderId: String?
    private let table = UITableView(frame: .zero, style: .plain)
    private let titleLabel = UILabel()
    private let empty = UILabel()
    private var folders: [FontFolder] = []
    private var fonts: [FontRecord] = []
    private var query = ""
    private let search = UISearchBar()

    init(folderId: String? = nil) {
        self.folderId = folderId
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = argbToUIColor(C.BG)
        let name = folderId.flatMap { id in FontLibrary.folders.first { $0.id == id }?.name } ?? "Fonts"
        titleLabel.text = name
        titleLabel.font = .boldSystemFont(ofSize: 18); titleLabel.textColor = argbToUIColor(C.TEXT)
        titleLabel.textAlignment = .center

        func btn(_ icon: String, _ sel: Selector) -> UIButton {
            let b = UIButton(type: .custom)
            b.setImage(Icons.image(icon, size: 24, color: C.TEXT), for: .normal)
            b.addTarget(self, action: sel, for: .touchUpInside)
            return b
        }
        let close = btn(folderId == nil ? "close" : "back", #selector(closeTap))
        let add = btn("plus", #selector(addTap))
        for v in [close, add, titleLabel] as [UIView] { view.addSubview(v) }
        close.tag = 1; add.tag = 2; titleLabel.tag = 3

        search.placeholder = "Search fonts"
        search.searchBarStyle = .minimal
        search.barStyle = .black
        search.delegate = self
        search.tag = 4
        view.addSubview(search)

        table.backgroundColor = .clear; table.separatorColor = argbToUIColor(C.LINE)
        table.dataSource = self; table.delegate = self
        table.rowHeight = 62
        view.addSubview(table)

        empty.text = "No fonts yet.\nTap + to import font files or a .zip of fonts."
        empty.numberOfLines = 0; empty.textAlignment = .center
        empty.textColor = argbToUIColor(C.DIM); empty.font = .systemFont(ofSize: 14)
        view.addSubview(empty)
        reload()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let w = view.bounds.width
        let top = max(view.safeAreaInsets.top, 8)
        view.viewWithTag(1)?.frame = CGRect(x: 6, y: top, width: 48, height: 44)
        view.viewWithTag(2)?.frame = CGRect(x: w - 54, y: top, width: 48, height: 44)
        titleLabel.frame = CGRect(x: 60, y: top, width: w - 120, height: 44)
        search.frame = CGRect(x: 8, y: top + 46, width: w - 16, height: 44)
        let ty = top + 92
        table.frame = CGRect(x: 0, y: ty, width: w, height: view.bounds.height - ty)
        empty.frame = CGRect(x: 30, y: ty + 40, width: w - 60, height: 80)
    }

    private func reload() {
        let q = query.lowercased()
        if q.isEmpty {
            folders = folderId == nil ? FontLibrary.folders : []
            fonts = FontLibrary.fonts(in: folderId)
        } else {
            folders = []
            fonts = FontLibrary.fonts.filter { $0.name.lowercased().contains(q) }
                .sorted { $0.name.lowercased() < $1.name.lowercased() }
        }
        empty.isHidden = !(folders.isEmpty && fonts.isEmpty && q.isEmpty)
        table.reloadData()
    }

    // MARK: actions

    @objc private func closeTap() {
        if let nav = navigationController, nav.viewControllers.count > 1 { nav.popViewController(animated: true) }
        else { dismiss(animated: true) }
    }

    @objc private func addTap() {
        let s = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        s.addAction(UIAlertAction(title: "Import fonts / ZIP…", style: .default) { [weak self] _ in self?.pickFiles() })
        if folderId == nil {
            s.addAction(UIAlertAction(title: "New folder", style: .default) { [weak self] _ in
                self?.prompt("New folder", "") { FontLibrary.addFolder($0); self?.reload() }
            })
        }
        s.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        s.popoverPresentationController?.sourceView = view.viewWithTag(2)
        present(s, animated: true)
    }

    private func pickFiles() {
        let p = UIDocumentPickerViewController(forOpeningContentTypes: [.data], asCopy: true)
        p.allowsMultipleSelection = true
        p.delegate = self
        present(p, animated: true)
    }

    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        Toast.show("Importing fonts…")
        let fid = folderId
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            let n = FontLibrary.importURLs(urls, into: fid)
            DispatchQueue.main.async {
                Toast.show(n > 0 ? "Added \(n) font\(n == 1 ? "" : "s")" : "No usable .ttf / .otf fonts found")
                self?.reload()
            }
        }
    }

    private func prompt(_ title: String, _ text: String, _ done: @escaping (String) -> Void) {
        let a = UIAlertController(title: title, message: nil, preferredStyle: .alert)
        a.addTextField { $0.text = text; $0.autocapitalizationType = .words }
        a.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in
            let t = a.textFields?.first?.text?.trimmingCharacters(in: .whitespaces) ?? ""
            if !t.isEmpty { done(t) }
        })
        present(a, animated: true)
    }

    private func moveSheet(_ f: FontRecord) {
        let s = UIAlertController(title: "Move “\(f.name)”", message: nil, preferredStyle: .actionSheet)
        if f.folder != nil { s.addAction(UIAlertAction(title: "Fonts (top level)", style: .default) { [weak self] _ in
            FontLibrary.move(f.id, to: nil); self?.reload() }) }
        for fo in FontLibrary.folders where fo.id != f.folder {
            s.addAction(UIAlertAction(title: fo.name, style: .default) { [weak self] _ in
                FontLibrary.move(f.id, to: fo.id); self?.reload() })
        }
        s.addAction(UIAlertAction(title: "New folder…", style: .default) { [weak self] _ in
            self?.prompt("New folder", "") { n in FontLibrary.move(f.id, to: FontLibrary.addFolder(n).id); self?.reload() }
        })
        s.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        s.popoverPresentationController?.sourceView = view
        s.popoverPresentationController?.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 1, height: 1)
        present(s, animated: true)
    }

    // MARK: table

    func numberOfSections(in tableView: UITableView) -> Int { 2 }
    func tableView(_ t: UITableView, numberOfRowsInSection s: Int) -> Int { s == 0 ? folders.count : fonts.count }

    func tableView(_ t: UITableView, cellForRowAt ip: IndexPath) -> UITableViewCell {
        let c = UITableViewCell(style: .subtitle, reuseIdentifier: nil)
        c.backgroundColor = .clear
        c.textLabel?.textColor = argbToUIColor(C.TEXT)
        c.detailTextLabel?.textColor = argbToUIColor(C.DIM)
        if ip.section == 0 {
            let f = folders[ip.row]
            c.imageView?.image = Icons.image("folder", size: 28, color: C.GREEN)
            c.textLabel?.font = .boldSystemFont(ofSize: 16)
            c.textLabel?.text = f.name
            let n = FontLibrary.count(in: f.id)
            c.detailTextLabel?.text = "\(n) font\(n == 1 ? "" : "s")"
            c.accessoryType = .disclosureIndicator
        } else {
            let f = fonts[ip.row]
            let path = FontLibrary.path(f)
            var font = UIFont.systemFont(ofSize: 20)
            if let d = FileManager.default.contents(atPath: path), let prov = CGDataProvider(data: d as CFData), let cg = CGFont(prov) {
                CTFontManagerRegisterGraphicsFont(cg, nil)      // already-registered errors are harmless
                if let ps = cg.postScriptName as String?, let u = UIFont(name: ps, size: 20) { font = u }
            }
            c.textLabel?.font = font
            c.textLabel?.text = f.name
            c.detailTextLabel?.text = "The quick brown fox 0123"
            c.detailTextLabel?.font = font.withSize(13)
            let cur = currentPath.map { FontLibrary.resolve($0) == path } ?? false
            c.accessoryView = cur ? UIImageView(image: Icons.image("check", size: 22, color: C.GREEN)) : nil
        }
        return c
    }

    func tableView(_ t: UITableView, didSelectRowAt ip: IndexPath) {
        t.deselectRow(at: ip, animated: true)
        if ip.section == 0 {
            let vc = FontBrowserViewController(folderId: folders[ip.row].id)
            vc.onPick = onPick; vc.currentPath = currentPath
            if let nav = navigationController { nav.pushViewController(vc, animated: true) }
            else { present(vc, animated: true) }
        } else {
            onPick?(fonts[ip.row])
            dismiss(animated: true)
        }
    }

    func tableView(_ t: UITableView, trailingSwipeActionsConfigurationForRowAt ip: IndexPath) -> UISwipeActionsConfiguration? {
        if ip.section == 0 {
            let f = folders[ip.row]
            let del = UIContextualAction(style: .destructive, title: "Delete") { [weak self] _, _, done in
                FontLibrary.deleteFolder(f.id); self?.reload(); done(true)
            }
            let ren = UIContextualAction(style: .normal, title: "Rename") { [weak self] _, _, done in
                self?.prompt("Rename folder", f.name) { FontLibrary.renameFolder(f.id, $0); self?.reload() }; done(true)
            }
            ren.backgroundColor = argbToUIColor(C.CARD2)
            return UISwipeActionsConfiguration(actions: [del, ren])
        }
        let f = fonts[ip.row]
        let del = UIContextualAction(style: .destructive, title: "Delete") { [weak self] _, _, done in
            FontLibrary.delete(f.id); self?.reload(); done(true)
        }
        let mv = UIContextualAction(style: .normal, title: "Move") { [weak self] _, _, done in
            self?.moveSheet(f); done(true)
        }
        mv.backgroundColor = argbToUIColor(C.GREEN_DARK)
        let ren = UIContextualAction(style: .normal, title: "Rename") { [weak self] _, _, done in
            self?.prompt("Rename font", f.name) { FontLibrary.rename(f.id, $0); self?.reload() }; done(true)
        }
        ren.backgroundColor = argbToUIColor(C.CARD2)
        return UISwipeActionsConfiguration(actions: [del, mv, ren])
    }
}

extension FontBrowserViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) { query = searchText; reload() }
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) { searchBar.resignFirstResponder() }
}
