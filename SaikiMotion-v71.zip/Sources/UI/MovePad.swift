// MovePad.swift — MovePadView (trackpad), GridPick (3x3 anchors), FlareThumb.

import UIKit
import Foundation

// MARK: - MovePadView

/// Drag anywhere inside to move X and Y together (relative movement, like a trackpad).
final class MovePadView: UIControl {
    var px: Float = 0
    var py: Float = 0
    var onBegin: (() -> Void)? = nil
    var onMove: ((Float, Float) -> Void)? = nil
    private var lx: CGFloat = 0
    private var ly: CGFloat = 0

    override init(frame: CGRect) { super.init(frame: frame) }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        fillRoundRect(c, CGRect(x: 0, y: 0, width: bounds.width, height: bounds.height), 12, C.CARD)
        let cx = bounds.width / 2
        let cy = bounds.height / 2
        strokeLine(c, cx, 0, cx, bounds.height, 1, Int32(bitPattern: 0xFF3A3A42))
        strokeLine(c, 0, cy, bounds.width, cy, 1, Int32(bitPattern: 0xFF3A3A42))
        let ox = CGFloat(clamp(px / 3 * 160, Float(-cx + 14), Float(cx - 14)))
        let oy = CGFloat(clamp(-py / 3 * 160, Float(-cy + 14), Float(cy - 14)))
        fillCircle(c, cx + ox, cy + oy, 9, C.GREEN)
        drawText("X " + String(format: "%.2f", px) + "   Y " + String(format: "%.2f", py),
                 12, 20, color: C.DIM, size: 12, align: .left)
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        lx = t.location(in: self).x
        ly = t.location(in: self).y
        disallowParentScrollInterception(self, true)
        onBegin?()
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        let p = t.location(in: self)
        let k: Float = 3 / 160
        onMove?((Float(p.x - lx)) * k, -(Float(p.y - ly)) * k)
        lx = p.x
        ly = p.y
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        disallowParentScrollInterception(self, false)
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        disallowParentScrollInterception(self, false)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - GridPick

/// 3x3 anchor preset picker. Index 0..8, row-major from top-left.
final class GridPick: TapView {
    var sel = -1
    var onPick: ((Int) -> Void)? = nil

    override init(frame: CGRect) { super.init(frame: frame) }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        fillRoundRect(c, CGRect(x: 0, y: 0, width: bounds.width, height: bounds.height), 12, C.CARD)
        let padX: CGFloat = 28
        let padY: CGFloat = 22
        for i in 0..<9 {
            let x = padX + (bounds.width - 2 * padX) * CGFloat(i % 3) / 2
            let y = padY + (bounds.height - 2 * padY) * CGFloat(i / 3) / 2
            fillCircle(c, x, y, i == sel ? 10 : 5, i == sel ? C.GREEN : C.DIM)
        }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        let p = t.location(in: self)
        let col = clamp(Int(p.x / (bounds.width / 3)), 0, 2)
        let row = clamp(Int(p.y / (bounds.height / 3)), 0, 2)
        onPick?(row * 3 + col)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - FlareThumb

/// A card showing a pre-rendered flare; picks the picture up from FlareThumbs once it exists.
final class FlareThumb: TapView {
    let key: String
    let label: String

    init(_ key: String, _ label: String) {
        self.key = key
        self.label = label
        super.init(frame: .zero)
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let w = bounds.width
        let h = bounds.height
        fillRoundRect(c, CGRect(x: 0, y: 0, width: w, height: h), 14, Int32(bitPattern: 0xFF0B0B10))
        let b = FlareThumbs.cache[key]
        let th = h - 26
        if let b = b {
            c.saveGState()
            let clip = UIBezierPath(roundedRect: CGRect(x: 0, y: 0, width: w, height: h), cornerRadius: 14).cgPath
            c.addPath(clip)
            c.clip()
            let s = max(w / b.size.width, (th + 8) / b.size.height)
            let dw = b.size.width * s
            let dh = b.size.height * s
            if let cgi = b.cgImage {
                c.draw(cgi, in: CGRect(x: (w - dw) / 2, y: (th + 8 - dh) / 2, width: dw, height: dh))
            }
            c.restoreGState()
        } else {
            drawText("Rendering...", w / 2, th / 2, color: C.DIM, size: 11, align: .center)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { [weak self] in
                self?.setNeedsDisplay()
            }
        }
        fillRect(c, CGRect(x: 0, y: h - 26, width: w, height: 26), Int32(bitPattern: 0xCC000000))
        drawText(label, w / 2, h - 9, color: Int32(bitPattern: 0xFFFFFFFF), size: 12, bold: true, align: .center)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

// MARK: - Iris browser views

/// A card showing one procedural iris shape (preset browser).
final class IrisThumb: TapView {
    var def: IrisDef
    var picked = false { didSet { setNeedsDisplay() } }
    var onLongPress: (() -> Void)? = nil

    init(_ def: IrisDef) {
        self.def = def
        super.init(frame: .zero)
        backgroundColor = .clear
        let lp = UILongPressGestureRecognizer(target: self, action: #selector(longed(_:)))
        addGestureRecognizer(lp)
    }

    @objc private func longed(_ g: UILongPressGestureRecognizer) {
        if g.state == .began { onLongPress?() }
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let w = bounds.width, h = bounds.height
        fillRoundRect(c, CGRect(x: 0, y: 0, width: w, height: h), 12,
                      picked ? Int32(bitPattern: 0xFF3A2812) : Int32(bitPattern: 0xFF0B0B10))
        if picked {
            c.setStrokeColor(argbToUIColor(C.GREEN).cgColor)
            c.setLineWidth(2)
            c.addPath(UIBezierPath(roundedRect: CGRect(x: 1, y: 1, width: w - 2, height: h - 2), cornerRadius: 12).cgPath)
            c.strokePath()
        }
        IrisPreview.drawIris(c, def, CGPoint(x: w / 2, y: (h - 16) / 2 + 2), (h - 24) / 2 * 0.9)
        drawText(def.name, w / 2, h - 5, color: C.DIM, size: 10, align: .center)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

/// Large live preview of the iris being edited (drawn with the same maths as the flare shader).
final class IrisPreview: UIView {
    var def = IrisDef() { didSet { setNeedsDisplay() } }
    var tint = UIColor(red: 1, green: 0.85, blue: 0.6, alpha: 1) { didSet { setNeedsDisplay() } }

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        isOpaque = false
    }

    static func drawIris(_ c: CGContext, _ d: IrisDef, _ centre: CGPoint, _ r: CGFloat,
                         _ col: UIColor = UIColor(red: 1, green: 0.88, blue: 0.65, alpha: 1)) {
        c.saveGState()
        c.translateBy(x: centre.x, y: centre.y)
        let path = FlareThumbs.irisPath(d, r)
        c.setBlendMode(.plusLighter)
        if d.thick >= 0.95 {
            // filled: soft edge glow stacked from big to small
            for i in 0..<6 {
                let k = 1 - CGFloat(i) * 0.06 * CGFloat(1 - d.grad * 0.6)
                c.saveGState()
                c.scaleBy(x: k, y: k)
                c.addPath(path)
                c.setFillColor(col.withAlphaComponent(0.1 + 0.05 * CGFloat(d.grad)).cgColor)
                c.fillPath()
                c.restoreGState()
            }
        }
        let lw = max(1.5, r * CGFloat(min(d.thick, 0.5)) * 0.35 + r * 0.03)
        if d.chroma > 0.02 {
            let cols = [UIColor.red, UIColor.green, UIColor.blue]
            for (i, cc) in cols.enumerated() {
                let k = 1 + (CGFloat(i) - 1) * -CGFloat(d.chroma) * 0.07
                c.saveGState(); c.scaleBy(x: k, y: k)
                c.addPath(path); c.setStrokeColor(cc.withAlphaComponent(0.8).cgColor)
                c.setLineWidth(lw); c.strokePath(); c.restoreGState()
            }
        } else {
            c.addPath(path); c.setStrokeColor(col.withAlphaComponent(0.9).cgColor)
            c.setLineWidth(lw); c.strokePath()
        }
        c.restoreGState()
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let w = bounds.width, h = bounds.height
        fillRoundRect(c, CGRect(x: 0, y: 0, width: w, height: h), 14, Int32(bitPattern: 0xFF08080C))
        IrisPreview.drawIris(c, def, CGPoint(x: w / 2, y: h / 2), min(w, h) * 0.38, tint)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

/// Drives the "Animate light" preview (a CADisplayLink needs an NSObject target).
final class FlareDriver: NSObject {
    private var link: CADisplayLink?
    private var t0 = CACurrentMediaTime()
    var tick: ((Double) -> Void)?

    func start() {
        t0 = CACurrentMediaTime()
        link = CADisplayLink(target: self, selector: #selector(step))
        link?.add(to: .main, forMode: .common)
    }

    func stop() { link?.invalidate(); link = nil }

    @objc private func step() { tick?(CACurrentMediaTime() - t0) }
}

/// Full-screen flare editor container: bar, live preview, tools, tabs and the scrolling panel.
final class FlareEditorView: UIView {
    let bar = UIView()
    let holder = UIView()
    let tools = UIView()
    var tabs: UIView?
    let scroll = CapScroll()

    override func layoutSubviews() {
        super.layoutSubviews()
        let w = bounds.width, h = bounds.height
        let ins = safeAreaInsets
        bar.frame = CGRect(x: 0, y: ins.top, width: w, height: 54)
        let ph = max(200, min(h * 0.36, w * 1.05))
        holder.frame = CGRect(x: 0, y: bar.frame.maxY, width: w, height: ph)
        tools.frame = CGRect(x: 0, y: holder.frame.maxY, width: w, height: 50)
        tabs?.frame = CGRect(x: 0, y: tools.frame.maxY, width: w, height: 44)
        let top = (tabs?.frame.maxY ?? tools.frame.maxY)
        scroll.frame = CGRect(x: 0, y: top, width: w, height: max(0, h - top - ins.bottom))
    }
}
