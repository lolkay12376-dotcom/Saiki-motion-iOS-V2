// PreRenderOverlay.swift — full-screen progress for baking a group (UI).
//
// Same look as the Render screen (ring, bar, frames + ETA, Cancel). Frames are baked one per
// run-loop turn on the main thread (the GL context lives there), so the ring keeps
// animating and Cancel always responds.

import UIKit

final class PreRenderProgressViewController: UIViewController {

    private let group: Layer
    private let project: Project
    private let scene: Scene
    private let size: (Int, Int)
    private let bake: (Layer, Int) -> Bool
    private let onDone: (Bool) -> Void

    private let ring = RenderRingView()
    private let bar = RenderBarView()
    private let titleL = UILabel()
    private let sub = UILabel()
    private let etaL = UILabel()
    private let girl = UIImageView()
    private let cancelB = PillButton("Cancel", "close", C.CARD2, C.TEXT)
    private var cancelled = false
    private var finished = false
    private var failures = 0
    private var startedAt = Date()
    private var startDone = 0

    init(group: Layer, project: Project, scene: Scene, quality: Int,
         bake: @escaping (Layer, Int) -> Bool, onDone: @escaping (Bool) -> Void) {
        self.group = group
        self.project = project
        self.scene = scene
        self.size = SceneRenderer.size(project, quality: quality)
        self.bake = bake
        self.onDone = onDone
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    override var prefersStatusBarHidden: Bool { true }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = argbToUIColor(Int32(bitPattern: 0xFF0B0B10))

        let frames = (0..<7).compactMap { i -> UIImage? in
            Bundle.main.url(forResource: "render_f\(i)", withExtension: "png")
                .flatMap { UIImage(contentsOfFile: $0.path) }
        }
        girl.contentMode = .scaleAspectFit
        girl.translatesAutoresizingMaskIntoConstraints = false
        if !frames.isEmpty {
            girl.animationImages = frames
            girl.animationDuration = 1.6
            girl.startAnimating()
        }
        view.addSubview(girl)

        titleL.text = "Pre-rendering"
        titleL.textColor = argbToUIColor(C.TEXT)
        titleL.font = boldFont(20)
        titleL.textAlignment = .center
        titleL.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(titleL)

        ring.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(ring)

        sub.text = group.name
        sub.textColor = argbToUIColor(C.DIM)
        sub.font = sysFont(13)
        sub.textAlignment = .center
        sub.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(sub)

        bar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(bar)

        etaL.text = " "
        etaL.textColor = argbToUIColor(C.DIM)
        etaL.font = sysFont(12)
        etaL.textAlignment = .center
        etaL.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(etaL)

        cancelB.onClick = { [weak self] in
            guard let self = self else { return }
            self.cancelled = true
            self.etaL.text = "Cancelling…"
            self.cancelB.isUserInteractionEnabled = false
        }
        cancelB.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(cancelB)

        NSLayoutConstraint.activate([
            titleL.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            titleL.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -150),
            girl.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            girl.bottomAnchor.constraint(equalTo: titleL.topAnchor, constant: -8),
            girl.widthAnchor.constraint(equalToConstant: 120),
            girl.heightAnchor.constraint(equalToConstant: 120),
            ring.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            ring.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            ring.widthAnchor.constraint(equalToConstant: 168),
            ring.heightAnchor.constraint(equalToConstant: 168),
            sub.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            sub.topAnchor.constraint(equalTo: ring.bottomAnchor, constant: 22),
            bar.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            bar.topAnchor.constraint(equalTo: sub.bottomAnchor, constant: 18),
            bar.widthAnchor.constraint(equalToConstant: 260),
            bar.heightAnchor.constraint(equalToConstant: 8),
            etaL.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            etaL.topAnchor.constraint(equalTo: bar.bottomAnchor, constant: 10),
            cancelB.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            cancelB.topAnchor.constraint(equalTo: etaL.bottomAnchor, constant: 22),
            cancelB.widthAnchor.constraint(equalToConstant: 132),
            cancelB.heightAnchor.constraint(equalToConstant: 42),
        ])

        ring.startAnimating()
        bar.startAnimating()
        let sig = PreRender.signature(group, project: project, scene: scene)
        PreRender.purgeStaleOnce(project.id, group.id, keep: sig)
        startDone = PreRender.progress(group, project: project, scene: scene, size: size).0
        startedAt = Date()
        // let the screen appear first, then start baking
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { [weak self] in self?.step() }
    }

    private func step() {
        guard !finished else { return }
        if cancelled { finish(false); return }
        guard let idx = PreRender.nextMissing(group, project: project, scene: scene, size: size, from: group.start) else {
            finish(true); return
        }
        if !bake(group, idx) {
            failures += 1
            if failures >= 3 { finish(false, error: "Could not render this group."); return }
        }
        let (done, total) = PreRender.progress(group, project: project, scene: scene, size: size)
        let p = CGFloat(done) / CGFloat(max(1, total))
        ring.progress = p
        bar.progress = p
        let n = done - startDone
        if n > 3 {
            let eta = Date().timeIntervalSince(startedAt) / Double(n) * Double(max(0, total - done))
            etaL.text = "\(done) / \(total) frames  ·  ~\(Int(eta)) s left"
        } else {
            etaL.text = "\(done) / \(total) frames"
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.002) { [weak self] in self?.step() }
    }

    private func finish(_ ok: Bool, error: String? = nil) {
        guard !finished else { return }
        finished = true
        ring.stopAnimating()
        bar.stopAnimating()
        dismiss(animated: true) { [onDone] in onDone(ok) }
        if let e = error { Snack.show(e) }
    }
}
