// Waveform.swift — real audio peaks for the timeline's audio layers (cached per file).

import Foundation
import AVFoundation

enum Waveform {
    private static let lock = NSLock()
    private static var cache: [String: [Float]] = [:]
    private static var loading = Set<String>()
    static let buckets = 1500

    /// Normalised peaks (0…1) for the whole file, or nil while still being decoded
    /// (`done` fires on the main thread when they are ready).
    static func peaks(_ path: String, done: @escaping () -> Void) -> [Float]? {
        lock.lock()
        if let p = cache[path] { lock.unlock(); return p }
        if loading.contains(path) { lock.unlock(); return nil }
        loading.insert(path)
        lock.unlock()
        DispatchQueue.global(qos: .utility).async {
            let p = compute(path)
            lock.lock(); cache[path] = p; loading.remove(path); lock.unlock()
            DispatchQueue.main.async(execute: done)
        }
        return nil
    }

    private static func compute(_ path: String) -> [Float] {
        guard let f = try? AVAudioFile(forReading: URL(fileURLWithPath: path)) else { return [] }
        let total = f.length
        guard total > 0, let buf = AVAudioPCMBuffer(pcmFormat: f.processingFormat, frameCapacity: 16384) else { return [] }
        let per = max(1, total / Int64(buckets))
        var out = [Float](repeating: 0, count: buckets)
        var pos: Int64 = 0
        while pos < total {
            do { try f.read(into: buf) } catch { break }
            let n = Int(buf.frameLength)
            if n == 0 { break }
            guard let ch = buf.floatChannelData else { break }
            let chs = Int(buf.format.channelCount)
            for i in 0..<n {
                var m: Float = 0
                for c in 0..<chs { m = max(m, abs(ch[c][i])) }
                let b = min(buckets - 1, Int((pos + Int64(i)) / per))
                if m > out[b] { out[b] = m }
            }
            pos += Int64(n)
        }
        let mx = max(out.max() ?? 0, 0.0001)
        return out.map { $0 / mx }
    }
}
