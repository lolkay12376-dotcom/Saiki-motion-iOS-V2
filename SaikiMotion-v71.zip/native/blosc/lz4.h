/* Minimal LZ4 block decoder shim so vendored c-blosc can read OpenVDB (lz4) chunks.
   Compression entry points are stubs: this app only ever decompresses. */
#ifndef LZ4_MIN_H
#define LZ4_MIN_H
int LZ4_decompress_safe(const char* src, char* dst, int compressedSize, int dstCapacity);
int LZ4_compress_fast(const char* src, char* dst, int srcSize, int dstCapacity, int acceleration);
int LZ4_compress_HC(const char* src, char* dst, int srcSize, int dstCapacity, int level);
#endif
