#include "lz4.h"
#include <string.h>

int LZ4_decompress_safe(const char* src, char* dst, int csize, int cap) {
    const unsigned char* ip = (const unsigned char*)src;
    const unsigned char* iend = ip + csize;
    unsigned char* op = (unsigned char*)dst;
    unsigned char* oend = op + cap;
    while (ip < iend) {
        unsigned token = *ip++;
        size_t lit = token >> 4;
        if (lit == 15) { unsigned char s; do { if (ip >= iend) return -1; s = *ip++; lit += s; } while (s == 255); }
        if ((size_t)(iend - ip) < lit || (size_t)(oend - op) < lit) return -1;
        memcpy(op, ip, lit); ip += lit; op += lit;
        if (ip >= iend) break;                       /* last sequence: literals only */
        if (iend - ip < 2) return -1;
        size_t off = ip[0] | (ip[1] << 8); ip += 2;
        if (off == 0 || off > (size_t)(op - (unsigned char*)dst)) return -1;
        size_t ml = token & 15;
        if (ml == 15) { unsigned char s; do { if (ip >= iend) return -1; s = *ip++; ml += s; } while (s == 255); }
        ml += 4;
        if ((size_t)(oend - op) < ml) return -1;
        const unsigned char* m = op - off;
        while (ml--) *op++ = *m++;                   /* byte copy handles overlap */
    }
    return (int)(op - (unsigned char*)dst);
}
int LZ4_compress_fast(const char* a, char* b, int c, int d, int e) { return 0; }
int LZ4_compress_HC(const char* a, char* b, int c, int d, int e) { return 0; }
