import Foundation

//  Stage 6a: camera view-projection for Metal 3D layers. Exact port of SceneRenderer.cameraVP /
//  perspectiveLookAt (column-major 4x4, the same layout GL uploads as uVP). GL code is untouched.

enum MetalCam {
    /// The scene / edit-camera view-projection for a 3D layer at `time`, or nil when the layer has no
    /// camera (the shader then uses the default z=3 perspective: w = 1 - z * uInvCam).
    static func vp(for l: Layer, time: Float, width: Int, height: Int) -> [Float]? {
        let ar = Float(width) / Float(max(height, 1))
        if let e = SceneRenderer.editCam {
            return lookAt(e[0], ar, e[1], e[2], e[3], e[4] * Float.pi / 180, e[5] * Float.pi / 180, 0)
        }
        guard let cam = Xf.camera(for: l) else { return nil }
        let ct = cam.editTime("x", time)
        var fov = cam.p("fov", ct)
        if !fov.isFinite || fov < 10 { fov = 55 }
        fov = min(fov, 150)
        let neutral = 1 / tan(fov * Float.pi / 360)
        let ex = cam.p("x", ct), ey = cam.p("y", ct), ez = cam.p("z", ct) + neutral
        let rx = cam.p("rotX", ct) * Float.pi / 180
        let ry = cam.p("rotY", ct) * Float.pi / 180
        let rz = cam.p("rotZ", ct) * Float.pi / 180
        if cam.parentId >= 0, let w = parentedWorld(cam, ct, ex, ey, ez, rx, ry, rz) {
            return viewProj(fov, ar, w)
        }
        return lookAt(fov, ar, ex, ey, ez, rx, ry, rz)
    }

    /// Camera linked to a (3D) null / layer: its world pose = parent chain (translate, rotate, scale) x its own pose.
    private static func parentedWorld(_ cam: Layer, _ t: Float, _ ex: Float, _ ey: Float, _ ez: Float,
                                      _ rx: Float, _ ry: Float, _ rz: Float) -> [Float]? {
        var chain: [Layer] = []
        var cur = cam
        while cur.parentId >= 0, chain.count < 16,
              let par = Editor.scene.layers.first(where: { $0.id == cur.parentId }) {
            chain.append(par); cur = par
        }
        if chain.isEmpty { return nil }
        // camera's own pose (rotation order matches lookAt: Ry * Rx * Rz)
        var w = mul(rotY(ry), mul(rotX(rx), rotZ(rz)))
        w[12] = ex; w[13] = ey; w[14] = ez
        for par in chain {                       // nearest parent first, then up the chain
            let pt = par.editTime("x", t)
            var s = par.p("scale", pt)
            if !s.isFinite || s < 1e-4 { s = 1 }
            var m = mul(rotZ(par.p("rotZ", pt) * Float.pi / 180),
                        mul(rotX(par.p("rotX", pt) * Float.pi / 180), rotY(par.p("rotY", pt) * Float.pi / 180)))
            for i in 0..<3 { m[i] *= s; m[4 + i] *= s; m[8 + i] *= s }
            m[12] = par.p("x", pt); m[13] = par.p("y", pt); m[14] = par.p("z", pt)
            w = mul(m, w)
        }
        return w
    }

    /// Projection * inverse(rigid world matrix `w`) (scale removed from the rotation).
    private static func viewProj(_ fovDeg: Float, _ ar: Float, _ w: [Float]) -> [Float] {
        var r = w
        for c in 0..<3 {
            let l = max(sqrt(w[c * 4] * w[c * 4] + w[c * 4 + 1] * w[c * 4 + 1] + w[c * 4 + 2] * w[c * 4 + 2]), 1e-6)
            r[c * 4] /= l; r[c * 4 + 1] /= l; r[c * 4 + 2] /= l
        }
        var v = ident()
        for rr in 0..<3 { for c in 0..<3 { v[c * 4 + rr] = r[rr * 4 + c] } }      // transpose
        for rr in 0..<3 { v[12 + rr] = -(v[rr] * w[12] + v[4 + rr] * w[13] + v[8 + rr] * w[14]) }
        let f = 1 / tan(fovDeg * Float.pi / 360)
        let near: Float = 0.05, far: Float = 100
        let nf = 1 / (near - far)
        var p = ident()
        p[0] = f / ar; p[5] = f; p[10] = (far + near) * nf; p[11] = -1; p[14] = 2 * far * near * nf; p[15] = 0
        return mul(p, v)
    }

    /// Model layers always use a VP: the camera one, or the default z=3 view (GL cameraVP without `has`).
    /// Set by the 3D editor while it renders volumes with its orbit camera (same renderer as the main view).
    static var vpOverride: [Float]? = nil

    static func vpForModel(_ l: Layer, fov: Float, time: Float, width: Int, height: Int) -> [Float] {
        if let o = vpOverride { return o }
        if let v = vp(for: l, time: time, width: width, height: height) { return v }
        let ar = Float(width) / Float(max(height, 1))
        return lookAt(fov, ar, 0, 0, 3, 0, 0, 0)
    }

    /// Port of SceneRenderer.modelMatrix (turns around the model's own centre).
    static func modelMatrix(_ l: Layer, time: Float, normalize norm: [Float]) -> [Float] {
        let lt = l.editTime("x", time)
        let s = l.p("scale", lt)
        let x = l.p("x", lt), y = l.p("y", lt)
        let z = Xf.worldZ(l, time)
        let rx = l.p("rotX", lt) * Float.pi / 180
        let ry = l.p("rotY", lt) * Float.pi / 180
        let rz = l.p("rotZ", lt) * Float.pi / 180
        let sc = s * norm[0]
        let sz = l.p("scaleZ", lt)
        var m = ident()
        m = mul(rotY(ry), m)
        m = mul(rotX(rx), m)
        m = mul(rotZ(rz), m)
        m = mul(m, [sc, 0, 0, 0, 0, sc, 0, 0, 0, 0, sc * sz, 0, 0, 0, 0, 1])   // R · S so the depth scale follows the model
        let ox = norm[1], oy = norm[2], oz = norm[3]
        m[12] = x + m[0] * ox + m[4] * oy + m[8] * oz
        m[13] = y + m[1] * ox + m[5] * oy + m[9] * oz
        m[14] = z + m[2] * ox + m[6] * oy + m[10] * oz
        return m
    }

    static func lookAt(_ fovDeg: Float, _ ar: Float, _ ex: Float, _ ey: Float, _ ez: Float,
                       _ rx: Float, _ ry: Float, _ rz: Float) -> [Float] {
        let f = 1 / tan(fovDeg * Float.pi / 360)
        let near: Float = 0.05, far: Float = 100
        let nf = 1 / (near - far)
        var p = ident()
        p[0] = f / ar
        p[5] = f
        p[10] = (far + near) * nf
        p[11] = -1
        p[14] = 2 * far * near * nf
        p[15] = 0
        var v = ident()
        v = mul(rotY(-ry), v)
        v = mul(rotX(-rx), v)
        v = mul(rotZ(-rz), v)
        v[12] = -ex; v[13] = -ey; v[14] = -ez
        return mul(p, v)
    }

    private static func ident() -> [Float] { [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1] }
    private static func rotX(_ a: Float) -> [Float] {
        let c = cos(a), s = sin(a)
        return [1, 0, 0, 0, 0, c, s, 0, 0, -s, c, 0, 0, 0, 0, 1]
    }
    private static func rotY(_ a: Float) -> [Float] {
        let c = cos(a), s = sin(a)
        return [c, 0, -s, 0, 0, 1, 0, 0, s, 0, c, 0, 0, 0, 0, 1]
    }
    private static func rotZ(_ a: Float) -> [Float] {
        let c = cos(a), s = sin(a)
        return [c, s, 0, 0, -s, c, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]
    }
    /// a * b (column-major).
    private static func mul(_ a: [Float], _ b: [Float]) -> [Float] {
        var o = [Float](repeating: 0, count: 16)
        for c in 0..<4 {
            for r in 0..<4 {
                var s: Float = 0
                for k in 0..<4 { s += a[k * 4 + r] * b[c * 4 + k] }
                o[c * 4 + r] = s
            }
        }
        return o
    }
}
