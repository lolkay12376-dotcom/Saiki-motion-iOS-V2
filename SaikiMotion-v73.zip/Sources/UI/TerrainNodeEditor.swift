// TerrainNodeEditor.swift — wire-based terrain node graph: drag nodes, drag wires from an output dot to an input dot,
// live orbitable 3D preview (SceneKit) and a "Render PBR" button that builds the terrain layer like the Terrain panel.
// The graph is stored on the layer (Layer.tgraph) so Properties > Terrain > Edit node reopens it.

import UIKit
import SceneKit
import simd

// MARK: - model

struct TGNode: Codable { var id: Int; var kind: Int; var p: [Float]; var x: Double; var y: Double; var on = true }   // kind -1 = Output
struct TGWire: Codable { var from: Int; var to: Int; var port: Int }

struct TGraph: Codable {
    var nodes: [TGNode] = [], wires: [TGWire] = [], next = 1
    var height: Float = 0.35, edge: Float = 0.25, sea: Float = 0, scale: Float = 1, seed: Float = 1

    static func make() -> TGraph {
        var g = TGraph()
        g.nodes = [TGNode(id: 0, kind: -1, p: [], x: 520, y: 70)]
        let a = g.add(.ridged, 30, 30), b = g.add(.erode, 190, 60), c = g.add(.curve, 350, 90)
        g.wires = [TGWire(from: a, to: b, port: 0), TGWire(from: b, to: c, port: 0), TGWire(from: c, to: 0, port: 0)]
        return g
    }

    /// The old linear stack as a chain: node1 → node2 → … → Output.
    static func fromStack(_ s: [TNode], edge: Float, sea: Float) -> TGraph {
        var g = TGraph(); g.edge = edge; g.sea = sea
        g.nodes = [TGNode(id: 0, kind: -1, p: [], x: 40 + Double(s.count) * 170, y: 70)]
        var prev = -1
        for (i, n) in s.enumerated() where n.kind != .baked {
            let id = g.add(n.kind, 30 + Double(i) * 170, 30 + Double(i % 2) * 60)
            if let k = g.nodes.firstIndex(where: { $0.id == id }) { g.nodes[k].p = n.p; g.nodes[k].on = n.on }
            if prev >= 0 { g.wires.append(TGWire(from: prev, to: id, port: 0)) }
            prev = id
        }
        if prev >= 0 { g.wires.append(TGWire(from: prev, to: 0, port: 0)) }
        return g
    }

    func json() -> String { (try? JSONEncoder().encode(self)).flatMap { String(data: $0, encoding: .utf8) } ?? "" }
    static func from(json: String) -> TGraph? { try? JSONDecoder().decode(TGraph.self, from: Data(json.utf8)) }

    @discardableResult mutating func add(_ k: TKind, _ x: Double, _ y: Double) -> Int {
        let id = next; next += 1
        nodes.append(TGNode(id: id, kind: k.rawValue, p: k.params.map { $0.3 }, x: x, y: y)); return id
    }
    func node(_ id: Int) -> TGNode? { nodes.first { $0.id == id } }
    func inputs(_ n: TGNode) -> Int { n.kind < 0 ? 1 : (TKind(rawValue: n.kind) == .blend ? 2 : 1) }
    func hasOutput(_ n: TGNode) -> Bool { n.kind >= 0 }
    func source(_ id: Int, _ port: Int) -> Int? { wires.first { $0.to == id && $0.port == port }?.from }
    /// true when `a` (transitively) feeds `b` — used to refuse wires that would make a loop
    func feeds(_ a: Int, _ b: Int, _ d: Int = 0) -> Bool {
        if a == b { return true }
        if d > 64 { return true }
        for w in wires where w.to == b { if feeds(a, w.from, d + 1) { return true } }
        return false
    }

    /// Heightfield before edge / sea / normalise.
    func raw(res: Int, scale: Float, seed: Int) -> [Float] {
        let R = res + 1, zero = [Float](repeating: 0, count: R * R)
        var memo: [Int: [Float]] = [:]
        func val(_ id: Int, _ d: Int) -> [Float]? {
            if let m = memo[id] { return m }
            guard d < 64, let n = node(id), let k = TKind(rawValue: n.kind) else { return nil }
            let a = source(id, 0).flatMap { val($0, d + 1) }
            var out: [Float]
            if !n.on { out = a ?? zero }
            else if k == .blend {
                let A = a ?? zero, B = source(id, 1).flatMap { val($0, d + 1) } ?? zero
                let mode = Int(n.p.first ?? 0), f = n.p.count > 1 ? n.p[1] : 0.5
                out = A
                for i in 0..<out.count {
                    switch mode {
                    case 1: out[i] = A[i] * (1 + (B[i] - 1) * f)
                    case 2: out[i] = max(A[i], B[i] * f)
                    case 3: out[i] = min(A[i], B[i])
                    case 4: out[i] = A[i] + (B[i] - A[i]) * f
                    default: out[i] = A[i] + B[i] * f
                    }
                }
            } else {
                var t = TNode(k); t.p = n.p
                out = TerrainGraph.eval([t], res: res, edge: 0, sea: 0, scale: scale, seed: seed, initial: a, raw: true)
            }
            memo[id] = out; return out
        }
        return source(0, 0).flatMap { val($0, 0) } ?? zero
    }
    func field(res: Int) -> [Float] {
        TerrainGraph.eval([], res: res, edge: edge, sea: sea, scale: scale, seed: Int(seed), initial: raw(res: res, scale: scale, seed: Int(seed)))
    }
}

// MARK: - canvas (nodes + wires drawn directly; touches handled here)

final class TGCanvas: UIView {
    var g = TGraph.make()
    var selected = -1
    var offset = CGPoint(x: 10, y: 10)
    var onChange: (() -> Void)?, onSelect: ((Int) -> Void)?
    private enum Mode { case none, pan(CGPoint), drag(Int, CGPoint), wire(Int, CGPoint) }
    private var mode = Mode.none
    private let accent = UIColor(red: 1, green: 0.55, blue: 0.08, alpha: 1)
    static let W: CGFloat = 138, head: CGFloat = 26, row: CGFloat = 24

    override init(frame: CGRect) { super.init(frame: frame); backgroundColor = UIColor(white: 0.09, alpha: 1); isMultipleTouchEnabled = false; clipsToBounds = true }
    required init?(coder: NSCoder) { fatalError() }

    private func size(_ n: TGNode) -> CGSize { CGSize(width: TGCanvas.W, height: TGCanvas.head + TGCanvas.row * CGFloat(max(g.inputs(n), 1)) + 6) }
    private func rect(_ n: TGNode) -> CGRect { CGRect(origin: CGPoint(x: n.x + offset.x, y: n.y + offset.y), size: size(n)) }
    private func inPort(_ n: TGNode, _ i: Int) -> CGPoint { let r = rect(n); return CGPoint(x: r.minX, y: r.minY + TGCanvas.head + TGCanvas.row * (CGFloat(i) + 0.5)) }
    private func outPort(_ n: TGNode) -> CGPoint { let r = rect(n); return CGPoint(x: r.maxX, y: r.minY + TGCanvas.head + TGCanvas.row * 0.5) }
    private func dist(_ a: CGPoint, _ b: CGPoint) -> CGFloat { hypot(a.x - b.x, a.y - b.y) }

    private func wirePath(_ a: CGPoint, _ b: CGPoint) -> UIBezierPath {
        let p = UIBezierPath(), k = max(40, abs(b.x - a.x) * 0.5)
        p.move(to: a); p.addCurve(to: b, controlPoint1: CGPoint(x: a.x + k, y: a.y), controlPoint2: CGPoint(x: b.x - k, y: b.y)); return p
    }

    override func draw(_ rect0: CGRect) {
        // grid
        UIColor(white: 1, alpha: 0.04).setStroke()
        let grid = UIBezierPath(); var gx = offset.x.truncatingRemainder(dividingBy: 40)
        while gx < bounds.width { grid.move(to: CGPoint(x: gx, y: 0)); grid.addLine(to: CGPoint(x: gx, y: bounds.height)); gx += 40 }
        var gy = offset.y.truncatingRemainder(dividingBy: 40)
        while gy < bounds.height { grid.move(to: CGPoint(x: 0, y: gy)); grid.addLine(to: CGPoint(x: bounds.width, y: gy)); gy += 40 }
        grid.lineWidth = 1; grid.stroke()
        // wires
        for w in g.wires {
            guard let a = g.node(w.from), let b = g.node(w.to) else { continue }
            let p = wirePath(outPort(a), inPort(b, w.port)); p.lineWidth = 3
            (a.on ? UIColor(red: 0.45, green: 0.8, blue: 1, alpha: 1) : UIColor(white: 0.45, alpha: 1)).setStroke(); p.stroke()
        }
        if case .wire(let id, let pt) = mode, let a = g.node(id) {
            let p = wirePath(outPort(a), pt); p.lineWidth = 3; accent.setStroke(); p.stroke()
        }
        // nodes
        let tf: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 12, weight: .semibold), .foregroundColor: UIColor.white]
        let sf: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 10), .foregroundColor: UIColor(white: 0.7, alpha: 1)]
        for n in g.nodes {
            let r = rect(n), k = TKind(rawValue: n.kind)
            let body = UIBezierPath(roundedRect: r, cornerRadius: 9)
            UIColor(white: n.on ? 0.17 : 0.11, alpha: 1).setFill(); body.fill()
            let hd = UIBezierPath(roundedRect: CGRect(x: r.minX, y: r.minY, width: r.width, height: TGCanvas.head), byRoundingCorners: [.topLeft, .topRight], cornerRadii: CGSize(width: 9, height: 9))
            (n.kind < 0 ? UIColor(red: 0.2, green: 0.55, blue: 0.3, alpha: 1) : (k?.isGen == true ? accent : UIColor(red: 0.3, green: 0.5, blue: 0.85, alpha: 1))).withAlphaComponent(n.on ? 1 : 0.4).setFill(); hd.fill()
            let nm: String = n.kind < 0 ? "Output" : (k?.title ?? "?")
            nm.draw(at: CGPoint(x: r.minX + 8, y: r.minY + 5), withAttributes: tf)
            if n.id == selected { accent.setStroke(); body.lineWidth = 2.5; body.stroke() }
            for i in 0..<g.inputs(n) {
                let c = inPort(n, i), label = n.kind < 0 ? "Height" : (g.inputs(n) == 2 ? (i == 0 ? "A" : "B") : "In")
                label.draw(at: CGPoint(x: c.x + 9, y: c.y - 6), withAttributes: sf)
                UIColor.white.setFill(); UIBezierPath(arcCenter: c, radius: 6, startAngle: 0, endAngle: .pi * 2, clockwise: true).fill()
                (g.source(n.id, i) != nil ? UIColor(red: 0.45, green: 0.8, blue: 1, alpha: 1) : UIColor(white: 0.3, alpha: 1)).setFill()
                UIBezierPath(arcCenter: c, radius: 3.5, startAngle: 0, endAngle: .pi * 2, clockwise: true).fill()
            }
            if g.hasOutput(n) {
                let c = outPort(n)
                UIColor.white.setFill(); UIBezierPath(arcCenter: c, radius: 6, startAngle: 0, endAngle: .pi * 2, clockwise: true).fill()
                accent.setFill(); UIBezierPath(arcCenter: c, radius: 3.5, startAngle: 0, endAngle: .pi * 2, clockwise: true).fill()
            }
        }
    }

    // touches: output dot → new wire · input dot (wired) → pick the wire up · node → move · empty → pan the graph
    override func touchesBegan(_ t: Set<UITouch>, with e: UIEvent?) {
        guard let pt = t.first?.location(in: self) else { return }
        for n in g.nodes.reversed() where g.hasOutput(n) && dist(outPort(n), pt) < 24 { mode = .wire(n.id, pt); setNeedsDisplay(); return }
        for n in g.nodes.reversed() {
            for i in 0..<g.inputs(n) where dist(inPort(n, i), pt) < 24 {
                if let wi = g.wires.firstIndex(where: { $0.to == n.id && $0.port == i }) {
                    let from = g.wires[wi].from; g.wires.remove(at: wi); mode = .wire(from, pt); onChange?(); setNeedsDisplay(); return
                }
            }
        }
        for n in g.nodes.reversed() where rect(n).contains(pt) {
            selected = n.id; onSelect?(n.id); mode = .drag(n.id, CGPoint(x: pt.x - rect(n).minX, y: pt.y - rect(n).minY)); setNeedsDisplay(); return
        }
        mode = .pan(CGPoint(x: pt.x - offset.x, y: pt.y - offset.y))
    }
    override func touchesMoved(_ t: Set<UITouch>, with e: UIEvent?) {
        guard let pt = t.first?.location(in: self) else { return }
        switch mode {
        case .pan(let o): offset = CGPoint(x: pt.x - o.x, y: pt.y - o.y)
        case .drag(let id, let o): if let i = g.nodes.firstIndex(where: { $0.id == id }) { g.nodes[i].x = Double(pt.x - o.x - offset.x); g.nodes[i].y = Double(pt.y - o.y - offset.y) }
        case .wire(let id, _): mode = .wire(id, pt)
        case .none: break
        }
        setNeedsDisplay()
    }
    override func touchesEnded(_ t: Set<UITouch>, with e: UIEvent?) {
        if let pt = t.first?.location(in: self) {
            switch mode {
            case .wire(let from, _):
                var best: (TGNode, Int, CGFloat)? = nil
                for n in g.nodes where n.id != from && !g.feeds(n.id, from) {      // never into itself or something that feeds it
                    for i in 0..<g.inputs(n) { let d = dist(inPort(n, i), pt); if d < 34, best == nil || d < best!.2 { best = (n, i, d) } }
                }
                if let b = best {
                    g.wires.removeAll { $0.to == b.0.id && $0.port == b.1 }
                    g.wires.append(TGWire(from: from, to: b.0.id, port: b.1))
                }
                onChange?()
            case .pan(let o) where dist(CGPoint(x: pt.x - offset.x, y: pt.y - offset.y), o) < 4: selected = -1; onSelect?(-1)
            case .drag: onChange?()
            default: break
            }
        }
        mode = .none; setNeedsDisplay()
    }
    override func touchesCancelled(_ t: Set<UITouch>, with e: UIEvent?) { mode = .none; setNeedsDisplay() }
}

// MARK: - editor

final class TerrainNodeEditor: UIView {
    private weak var host: EditorViewController?
    private weak var parentPanel: TerrainPanel?
    private var layer3: Layer?
    private let canvas = TGCanvas(), scn = SCNView(), params = UIStackView(), paramScroll = UIScrollView(), status = UILabel()
    private let scene = SCNScene(), terrainNode = SCNNode(), seaNode = SCNNode()
    private var work: DispatchWorkItem?, timer: Timer?, panel: TerrainPanel?, rendering = false
    private let accent = UIColor(red: 1, green: 0.55, blue: 0.08, alpha: 1)

    static func present(in host: EditorViewController, over view: UIView, graph: TGraph, layer: Layer?, parent: TerrainPanel?) {
        if view.subviews.contains(where: { $0 is TerrainNodeEditor }) { return }
        let v = TerrainNodeEditor(host: host, graph: graph, layer: layer, parent: parent)
        v.translatesAutoresizingMaskIntoConstraints = false; view.addSubview(v)
        NSLayoutConstraint.activate([v.leadingAnchor.constraint(equalTo: view.leadingAnchor), v.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                                     v.topAnchor.constraint(equalTo: view.topAnchor), v.bottomAnchor.constraint(equalTo: view.bottomAnchor)])
    }

    init(host: EditorViewController, graph: TGraph, layer: Layer?, parent: TerrainPanel?) {
        self.host = host; self.layer3 = layer; self.parentPanel = parent
        super.init(frame: .zero)
        backgroundColor = UIColor(white: 0.05, alpha: 1)
        canvas.g = graph
        canvas.onChange = { [weak self] in self?.changed() }
        canvas.onSelect = { [weak self] _ in self?.rebuildParams() }
        build(); setupScene(); rebuildParams(); updatePreview()
    }
    required init?(coder: NSCoder) { fatalError() }
    deinit { timer?.invalidate() }

    private func build() {
        let title = UILabel(); title.text = "Terrain nodes"; title.textColor = .white; title.font = .systemFont(ofSize: 16, weight: .bold)
        let close = UIButton(type: .system); close.setImage(UIImage(systemName: "xmark.circle.fill"), for: .normal); close.tintColor = UIColor(white: 0.6, alpha: 1)
        close.addAction(UIAction { [weak self] _ in self?.removeFromSuperview() }, for: .touchUpInside)
        let add = UIButton(type: .system); add.setTitle("＋ Node", for: .normal); add.tintColor = accent; add.showsMenuAsPrimaryAction = true
        func grp(_ t: String, _ gen: Bool) -> UIMenu {
            UIMenu(title: t, options: .displayInline, children: TKind.allCases.filter { $0.isGen == gen && $0 != .baked }.map { k in
                UIAction(title: k.title, image: UIImage(systemName: k.icon)) { [weak self] _ in self?.addNode(k) } })
        }
        add.menu = UIMenu(children: [grp("Modifiers", false), grp("Generators", true)])
        let render = UIButton(type: .system); render.setTitle("Render PBR", for: .normal); render.setTitleColor(.black, for: .normal)
        render.backgroundColor = accent; render.layer.cornerRadius = 8; render.contentEdgeInsets = UIEdgeInsets(top: 6, left: 12, bottom: 6, right: 12)
        render.titleLabel?.font = .systemFont(ofSize: 14, weight: .bold)
        render.addTarget(self, action: #selector(renderPBR), for: .touchUpInside)
        let bar = UIStackView(arrangedSubviews: [title, UIView(), add, render, close]); bar.spacing = 12; bar.alignment = .center
        bar.isLayoutMarginsRelativeArrangement = true; bar.layoutMargins = UIEdgeInsets(top: 4, left: 14, bottom: 4, right: 14)
        status.textColor = UIColor(white: 0.7, alpha: 1); status.font = .systemFont(ofSize: 11); status.text = "Drag a node's orange dot onto another node's input dot to wire. Drag empty space to move around."
        status.numberOfLines = 2

        params.axis = .vertical; params.spacing = 8; params.translatesAutoresizingMaskIntoConstraints = false
        paramScroll.addSubview(params); paramScroll.backgroundColor = UIColor(white: 0.1, alpha: 1)
        NSLayoutConstraint.activate([params.leadingAnchor.constraint(equalTo: paramScroll.leadingAnchor, constant: 14), params.trailingAnchor.constraint(equalTo: paramScroll.trailingAnchor, constant: -14),
                                     params.topAnchor.constraint(equalTo: paramScroll.topAnchor, constant: 10), params.bottomAnchor.constraint(equalTo: paramScroll.bottomAnchor, constant: -10),
                                     params.widthAnchor.constraint(equalTo: paramScroll.widthAnchor, constant: -28)])
        let col = UIStackView(arrangedSubviews: [bar, scn, status, canvas, paramScroll]); col.axis = .vertical; col.translatesAutoresizingMaskIntoConstraints = false
        addSubview(col)
        NSLayoutConstraint.activate([col.leadingAnchor.constraint(equalTo: leadingAnchor), col.trailingAnchor.constraint(equalTo: trailingAnchor),
                                     col.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor), col.bottomAnchor.constraint(equalTo: safeAreaLayoutGuide.bottomAnchor),
                                     scn.heightAnchor.constraint(equalTo: col.heightAnchor, multiplier: 0.30), paramScroll.heightAnchor.constraint(equalToConstant: 190)])
        canvas.setContentHuggingPriority(.defaultLow, for: .vertical)
    }

    private func setupScene() {
        scn.scene = scene; scn.allowsCameraControl = true; scn.antialiasingMode = .multisampling4X; scn.backgroundColor = UIColor(red: 0.1, green: 0.13, blue: 0.2, alpha: 1)
        let cam = SCNNode(); cam.camera = SCNCamera(); cam.camera?.zNear = 0.01; cam.position = SCNVector3(0, 0.75, 1.25)
        scene.rootNode.addChildNode(cam); cam.look(at: SCNVector3(0, 0.05, 0)); scn.pointOfView = cam
        let amb = SCNNode(); amb.light = SCNLight(); amb.light?.type = .ambient; amb.light?.intensity = 500; scene.rootNode.addChildNode(amb)
        let sun = SCNNode(); sun.light = SCNLight(); sun.light?.type = .directional; sun.light?.intensity = 900; sun.eulerAngles = SCNVector3(-0.9, 0.6, 0); scene.rootNode.addChildNode(sun)
        scene.rootNode.addChildNode(terrainNode)
        let plane = SCNPlane(width: 1, height: 1); plane.firstMaterial?.diffuse.contents = UIColor(red: 0.1, green: 0.35, blue: 0.6, alpha: 0.7); plane.firstMaterial?.isDoubleSided = true
        seaNode.geometry = plane; seaNode.eulerAngles.x = -.pi / 2; scene.rootNode.addChildNode(seaNode)
    }

    // MARK: graph edits

    private func addNode(_ k: TKind) {
        let x = Double(-canvas.offset.x + canvas.bounds.width / 2 - 70 + CGFloat(canvas.g.nodes.count % 4) * 14), y = Double(-canvas.offset.y + 40 + CGFloat(canvas.g.nodes.count % 5) * 14)
        let id = canvas.g.add(k, x, y); canvas.selected = id; canvas.setNeedsDisplay(); rebuildParams(); changed()
    }

    private func changed() { canvas.setNeedsDisplay(); updatePreview() }

    private func rebuildParams() {
        params.arrangedSubviews.forEach { params.removeArrangedSubview($0); $0.removeFromSuperview() }
        func lab(_ t: String, _ c: UIColor = .white, _ s: CGFloat = 13, _ w: UIFont.Weight = .regular) -> UILabel { let l = UILabel(); l.text = t; l.textColor = c; l.font = .systemFont(ofSize: s, weight: w); l.numberOfLines = 0; return l }
        func slider(_ name: String, _ lo: Float, _ hi: Float, _ v: Float, _ whole: Bool, _ set: @escaping (Float) -> Void) {
            let l = lab(String(format: whole ? "%@: %.0f" : "%@: %.2f", name, v), UIColor(white: 0.8, alpha: 1), 12)
            let s = UISlider(); s.minimumValue = lo; s.maximumValue = hi; s.value = v; s.tintColor = accent
            s.addAction(UIAction { [weak self, weak l, weak s] _ in
                guard let s = s else { return }; let x = whole ? s.value.rounded() : s.value
                l?.text = String(format: whole ? "%@: %.0f" : "%@: %.2f", name, x); set(x); self?.changed() }, for: .valueChanged)
            params.addArrangedSubview(l); params.addArrangedSubview(s)
        }
        let id = canvas.selected
        guard id >= 0, let n = canvas.g.node(id) else {
            params.addArrangedSubview(lab("Select a node to edit it. Tap Output for height, edges, sea level and scale.", UIColor(white: 0.6, alpha: 1), 12)); return
        }
        if n.kind < 0 {
            params.addArrangedSubview(lab("Output", accent, 13, .bold))
            slider("Height", 0.05, 1, canvas.g.height, false) { [weak self] in self?.canvas.g.height = $0 }
            slider("Edge fade", 0, 1, canvas.g.edge, false) { [weak self] in self?.canvas.g.edge = $0 }
            slider("Sea level", 0, 0.6, canvas.g.sea, false) { [weak self] in self?.canvas.g.sea = $0 }
            slider("Feature scale", 0.3, 3, canvas.g.scale, false) { [weak self] in self?.canvas.g.scale = $0 }
            slider("Seed", 1, 99, canvas.g.seed, true) { [weak self] in self?.canvas.g.seed = $0 }
            return
        }
        guard let k = TKind(rawValue: n.kind) else { return }
        params.addArrangedSubview(lab(k.title, accent, 13, .bold))
        for (pi, d) in k.params.enumerated() where pi < n.p.count {
            if let opts = d.4 {
                let seg = UISegmentedControl(items: opts); seg.selectedSegmentIndex = Int(n.p[pi])
                seg.addAction(UIAction { [weak self, weak seg] _ in
                    guard let self = self, let seg = seg, let i = self.canvas.g.nodes.firstIndex(where: { $0.id == id }) else { return }
                    self.canvas.g.nodes[i].p[pi] = Float(seg.selectedSegmentIndex); self.changed() }, for: .valueChanged)
                params.addArrangedSubview(lab(d.0, UIColor(white: 0.8, alpha: 1), 12)); params.addArrangedSubview(seg)
            } else {
                let whole = d.2 - d.1 >= 8
                slider(d.0, d.1, d.2, n.p[pi], whole) { [weak self] v in
                    if let i = self?.canvas.g.nodes.firstIndex(where: { $0.id == id }) { self?.canvas.g.nodes[i].p[pi] = v } }
            }
        }
        let on = UISwitch(); on.isOn = n.on; on.onTintColor = accent
        on.addAction(UIAction { [weak self, weak on] _ in
            if let i = self?.canvas.g.nodes.firstIndex(where: { $0.id == id }), let on = on { self?.canvas.g.nodes[i].on = on.isOn; self?.changed() } }, for: .valueChanged)
        let onRow = UIStackView(arrangedSubviews: [lab("Enabled (off = bypass)"), on]); onRow.alignment = .center
        func btn(_ t: String, _ c: UIColor, _ f: @escaping () -> Void) -> UIButton {
            let b = UIButton(type: .system); b.setTitle(t, for: .normal); b.tintColor = c; b.addAction(UIAction { _ in f() }, for: .touchUpInside); return b
        }
        let dup = btn("Duplicate", accent) { [weak self] in
            guard let self = self, let o = self.canvas.g.node(id), let kk = TKind(rawValue: o.kind) else { return }
            let nid = self.canvas.g.add(kk, o.x + 24, o.y + 34)
            if let i = self.canvas.g.nodes.firstIndex(where: { $0.id == nid }) { self.canvas.g.nodes[i].p = o.p }
            self.canvas.selected = nid; self.rebuildParams(); self.changed() }
        let del = btn("Delete", UIColor(red: 1, green: 0.4, blue: 0.4, alpha: 1)) { [weak self] in
            guard let self = self else { return }
            self.canvas.g.nodes.removeAll { $0.id == id }; self.canvas.g.wires.removeAll { $0.from == id || $0.to == id }
            self.canvas.selected = -1; self.rebuildParams(); self.changed() }
        let row = UIStackView(arrangedSubviews: [dup, del]); row.distribution = .fillEqually
        params.addArrangedSubview(onRow); params.addArrangedSubview(row)
    }

    // MARK: 3D preview

    private func updatePreview() {
        work?.cancel()
        let g = canvas.g
        let w = DispatchWorkItem { [weak self] in
            let res = 72, R = res + 1, f = g.field(res: res), amp = g.height * 0.5
            var pos = [Float](), nor = [Float](), col = [Float](), idx = [UInt32]()
            pos.reserveCapacity(R * R * 3); nor.reserveCapacity(R * R * 3); col.reserveCapacity(R * R * 4)
            let step = 1 / Float(res)
            for j in 0..<R { for i in 0..<R {
                let y = f[i + j * R] * amp
                pos += [Float(i) * step - 0.5, y, Float(j) * step - 0.5]
                let dx = f[min(i + 1, res) + j * R] - f[max(i - 1, 0) + j * R], dz = f[i + min(j + 1, res) * R] - f[i + max(j - 1, 0) * R]
                let n = simd_normalize(simd_float3(-dx * amp / (Float(min(i + 1, res) - max(i - 1, 0)) * step), 1, -dz * amp / (Float(min(j + 1, res) - max(j - 1, 0)) * step)))
                nor += [n.x, n.y, n.z]
                let c = TerrainGraph.colour(f[i + j * R], 1 - n.y, g.sea); col += [c.x, c.y, c.z, 1]
            } }
            for j in 0..<res { for i in 0..<res {
                let a = UInt32(i + j * R); idx += [a, a + UInt32(R), a + 1, a + 1, a + UInt32(R), a + UInt32(R) + 1]
            } }
            DispatchQueue.main.async {
                guard let self = self else { return }
                func src(_ a: [Float], _ s: SCNGeometrySource.Semantic, _ comps: Int) -> SCNGeometrySource {
                    SCNGeometrySource(data: a.withUnsafeBytes { Data($0) }, semantic: s, vectorCount: a.count / comps, usesFloatComponents: true,
                                      componentsPerVector: comps, bytesPerComponent: 4, dataOffset: 0, dataStride: comps * 4)
                }
                let geo = SCNGeometry(sources: [src(pos, .vertex, 3), src(nor, .normal, 3), src(col, .color, 4)],
                                      elements: [SCNGeometryElement(data: idx.withUnsafeBytes { Data($0) }, primitiveType: .triangles, primitiveCount: idx.count / 3, bytesPerIndex: 4)])
                let m = SCNMaterial(); m.diffuse.contents = UIColor.white; m.lightingModel = .lambert; m.isDoubleSided = true
                geo.materials = [m]; self.terrainNode.geometry = geo
                self.seaNode.isHidden = g.sea <= 0.001; self.seaNode.position = SCNVector3(0, g.sea * amp + 0.001, 0)
            }
        }
        work = w
        DispatchQueue.global(qos: .userInitiated).asyncAfter(deadline: .now() + 0.1, execute: w)
    }

    // MARK: render with PBR

    @objc private func renderPBR() {
        guard !rendering, let host = host else { return }
        rendering = true; status.text = "Preparing PBR layers…"
        let g = canvas.g
        TerrainGraph.bakedEval = { res, sc, sd in g.raw(res: res, scale: sc, seed: sd) }
        TerrainPanel.nodes = [TNode(.baked)]
        TerrainPanel.height = g.height; TerrainPanel.edge = g.edge; TerrainPanel.sea = g.sea; TerrainPanel.genScale = g.scale; TerrainPanel.genSeed = g.seed
        TerrainPanel.pendingGraph = g.json(); TerrainPanel.replacing = layer3
        let p = TerrainPanel(host: host); panel = p
        let go = { [weak self] in
            guard let self = self else { return }
            p.addTap()
            self.timer = Timer.scheduledTimer(withTimeInterval: 0.35, repeats: true) { [weak self] t in
                guard let self = self else { t.invalidate(); return }
                self.status.text = p.statusText
                if !p.isBusy { t.invalidate(); self.parentPanel?.removeFromSuperview(); self.removeFromSuperview() }
            }
        }
        if !TerrainPanel.layers.isEmpty { go(); return }
        // no PBR layers set up yet: pick sand / grass / rock / snow from Poly Haven by height and slope
        PolyHaven.list { list in DispatchQueue.main.async {
            func pick(_ keys: [String]) -> (id: String, name: String)? { for k in keys { if let m = list.first(where: { $0.name.lowercased().contains(k) }) { return m } }; return nil }
            // keys, height lo/hi, slope lo/hi
            let defs: [([String], Float, Float, Float, Float)] = [(["sand"], 0, 0.22, 0, 0.5), (["grass", "forest", "ground"], 0.12, 0.65, 0, 0.5),
                                                                  (["rock", "cliff"], 0.5, 1, 0, 1), (["rock", "cliff"], 0, 1, 0.4, 1), (["snow"], 0.82, 1, 0, 0.45)]
            for d in defs {
                guard let m = pick(d.0) else { continue }
                var l = PLayer(id: TerrainPanel.nextLayer); TerrainPanel.nextLayer += 1
                l.tex = m.id; l.texName = m.name; l.hLo = d.1; l.hHi = d.2; l.sLo = d.3; l.sHi = d.4
                TerrainPanel.layers.append(l)
            }
            go()
        } }
    }
}
