import Foundation
import Metal
import simd
import UIKit
import OpenGLES

//  Stage 6b: GLB / glTF / OBJ / animated-ABC models in Metal (port of GlbModel.draw + the GL PBR shader).
//  GlbModel is loaded with cpuOnly = true (no GL calls); this file uploads its CPU data to Metal.
//  VDB volumes stay in GL.

enum MetalModelSL {
    /// Port of GlbModel.vertexSource / fragmentSource. Clip z is remapped from the GL range [-w, w]
    /// to Metal's [0, w]. Vertices are read from a plain float buffer (12 floats per vertex).
    static let source = MetalSL.header + """
struct ModelU {
    float4 vp0; float4 vp1; float4 vp2; float4 vp3;     // uVP columns
    float4 m0; float4 m1; float4 m2; float4 m3;         // uModel columns
    float4 color;     // uColor
    float4 emis;      // uEmis.xyz
    float4 eye;       // uEye.xyz
    float4 prm;       // metal, rough, cutoff, unlit
    float4 has;       // base, metal-rough, emissive, occlusion texture present
    float4 opt;       // env, metallic reflectivity, view mode, ao strength
    float4 xtra;      // exposure, rt ao, rt shadow, pbr bump strength
    float4 lp0; float4 lp1; float4 lp2;     // scene point lights: world pos
    float4 lc0; float4 lc1; float4 lc2;     // rgb * intensity (w = 1 when active)
    float4 pg;        // procedural pbr: on, parallax depth, uv scale x, uv scale y
    float4 wa;        // water: on, time, wave height, wave frequency
    float4 wb;        // water: speed, foam, depth, choppiness
    float4 wc;        // water: clarity, turbidity, refraction, subsurface
    float4 wd;        // water: glint, detail, flow dir (rad), procedural seabed
    float4 we;        // water: wave variation, swell, swell length, whitecaps
    float4 wf;        // water: base y, reflect, scene depth available, rays
    float4 wg;        // water rays: strength, length, sharpness, speed
    float4 wh;        // water collision: rocks, shores, foam width, 0
    float4 envp;      // HDRI environment: on, rotation (turns), max mip, gain
    float4 sp0;       // terrain splat: on, layer count, 0, 0
    float4 sp1;       // splat tiling per layer
    float4 sp2;       // splat normal strength per layer
    float4 pm;        // imported PBR maps: normal, roughness, metallic, height present
    float4 pn;        // opacity map present, normal strength, normal Y sign, displacement amount (world units)
    float4 pt;        // texture tiling u, v, parallax depth, height mid-point
    float4 pq;        // roughness multiplier, metallic multiplier, emissive strength, maps on
    float4 pr;        // clear coat, clear coat roughness, AO strength
};
struct MOut { float4 pos [[position]]; float psize [[point_size]]; float3 n; float3 w; float2 uv; float4 col; };

inline float mHash(float2 p) { return fract(sin(dot(p, float2(127.1, 311.7))) * 43758.5453); }
inline float mVn(float2 p) {
    float2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
    return mix(mix(mHash(i), mHash(i + float2(1.0, 0.0)), f.x), mix(mHash(i + float2(0.0, 1.0)), mHash(i + float2(1.0, 1.0)), f.x), f.y);
}
// Sharpened sine waves (Gerstner-like crests). Directions, frequencies and phases are jittered and domain-warped,
// amplitude is modulated at a large scale, so the pattern never visibly tiles. Returns height, gradient in g.
inline float2 mH2(float2 p) { return float2(mHash(p), mHash(p + 17.3)); }
inline float wCell(float2 p) {      // cellular distance: bubble walls
    float2 i = floor(p), f = fract(p); float m = 8.0;
    for (int y = -1; y <= 1; y++) { for (int x = -1; x <= 1; x++) {
        float2 g = float2(float(x), float(y)); float2 r = g + mH2(i + g) * 0.9 - f; m = min(m, dot(r, r)); } }
    return sqrt(m);
}
inline float wFoamT(float2 p, float tt) {      // lacy foam: warped streaks + two scales of bubble walls
    float2 wv = float2(mVn(p * 1.3 + tt * 0.15), mVn(p * 1.3 + 9.0 - tt * 0.12)) - 0.5;
    p += wv * 1.3;
    float f = mVn(p * 2.0) * 0.45 + mVn(p * 5.0 + 3.0) * 0.3 + mVn(p * 12.0) * 0.25;
    float b1 = smoothstep(0.18, 0.62, wCell(p * 8.0 + tt * 0.06));
    float b2 = mVn(p * 31.0 - tt * 0.05 + 5.0);
    return smoothstep(0.22, 0.8, f * 0.5 + b1 * 0.35 + b2 * 0.2);
}
inline float wBeam(float2 sp, float t, float wid) {      // sunbeams that pass through the moving surface
    float pat = mVn(sp * 1.1 + t * 0.25) * 0.65 + mVn(sp * 2.7 - t * 0.35 + 8.0) * 0.35;
    return pow(clamp(pat * 1.7 - 0.45, 0.0, 1.0), mix(1.2, 4.0, clamp(wid * 0.5, 0.0, 1.0)));
}
inline float wMean(float k) { float k2 = k * k; return exp(-k) * (1.0 + k2 * (0.25 + k2 * (0.015625 + k2 * (0.000434 + k2 * 0.0000068)))); }      // mean of exp((sin-1)k)
inline float wvH(float2 p, float t, float amp, float freq, float spd, float chop, float dirA, float vari, float2 sw, int nw, thread float2& g) {
    float k = mix(0.7, 2.6, chop);
    float zone = mix(0.6, 1.4, mVn(p * 0.03 + 19.0));      // calm / rough areas: far water differs from near water
    float am = mix(1.0, 0.45 + 1.1 * mVn(p * 0.09 + 7.0), vari);
    float wph = (mVn(p * 0.17 + 3.0) - 0.5) * 3.0 * vari;
    float h = 0.0, a = amp * am, f = freq, w = 1.0;
    g = float2(0.0);
    for (int i = 0; i < nw; i++) {
        float fi = float(i);
        float ang = dirA + fi * 0.83 + sin(fi * 5.1 + 1.0) * 0.7 * (0.4 + vari);
        float2 d = float2(cos(ang), sin(ang));
        float fr = f * (1.0 + 0.21 * sin(fi * 7.3));
        float ph = dot(d, p) * fr + t * spd * w * 1.6 + fi * 1.7 + wph * (0.4 + 0.3 * fi);
        float e = exp((sin(ph) - 1.0) * k);
        h += a * (e - wMean(k));
        g += a * e * k * cos(ph) * fr * d;
        a *= 0.58; f *= 1.8; w *= 1.2;
    }
    for (int j = 0; j < 3; j++) {      // long rounded swells on their own headings
        float fj = float(j);
        float ang = dirA + 2.1 + fj * 1.9;
        float2 d = float2(cos(ang), sin(ang));
        float fr = freq * sw.y * (1.0 + 0.45 * fj);
        float ph = dot(d, p) * fr + t * spd * (0.8 + 0.25 * fj) + fj * 2.3 + wph * 0.5;
        float e = exp((sin(ph) - 1.0) * 0.9);
        float sa = amp * sw.x * zone * (1.0 - 0.25 * fj) * 2.2;
        h += sa * (e - 0.4934);
        g += sa * e * 0.9 * cos(ph) * fr * d;
    }
    return h;
}

vertex MOut modelVertex(uint vid [[vertex_id]], constant ModelU& u [[buffer(0)]],
                        const device float* vb [[buffer(1)]], texture2d<float> tPH [[texture(0)]]) {
    uint b = vid * 12u;
    float3 aPos = float3(vb[b], vb[b + 1u], vb[b + 2u]);
    float3 aNormal = float3(vb[b + 3u], vb[b + 4u], vb[b + 5u]);
    float2 aUv = float2(vb[b + 6u], vb[b + 7u]);
    float4 aCol = float4(vb[b + 8u], vb[b + 9u], vb[b + 10u], vb[b + 11u]);
    float4 wp = u.m0 * aPos.x + u.m1 * aPos.y + u.m2 * aPos.z + u.m3;
    float3 wn = float3(0.0, 1.0, 0.0);
    if (u.wa.x > 0.5) {
        float2 g; float hh = wvH(wp.xz, u.wa.y, u.wa.z, u.wa.w, u.wb.x, u.wb.w, u.wd.z, u.we.x, u.we.yz, 4, g);
        wp.y += hh; wn = normalize(float3(-g.x, 1.0, -g.y));
    }
    if (u.pq.w > 0.5 && u.pm.w > 0.5 && abs(u.pn.w) > 1e-5) {      // imported height map: real vertex displacement along the normal
        constexpr sampler sv(filter::linear, address::repeat);
        float hh = tPH.sample(sv, aUv * u.pt.xy, level(0.0)).r;
        float3 nW = u.m0.xyz * aNormal.x + u.m1.xyz * aNormal.y + u.m2.xyz * aNormal.z;
        nW = dot(nW, nW) > 1e-8 ? normalize(nW) : float3(0.0, 1.0, 0.0);
        wp.xyz += nW * ((hh - u.pt.w) * u.pn.w);
    }
    float4 c = u.vp0 * wp.x + u.vp1 * wp.y + u.vp2 * wp.z + u.vp3 * wp.w;
    c.z = (c.z + c.w) * 0.5;
    MOut o;
    o.pos = c;
    o.psize = 3.0;
    o.w = wp.xyz;
    float3 n = u.m0.xyz * aNormal.x + u.m1.xyz * aNormal.y + u.m2.xyz * aNormal.z;
    o.n = dot(n, n) > 1e-8 ? normalize(n) : float3(0.0, 1.0, 0.0);
    if (u.wa.x > 0.5) { o.n = wn; }
    o.uv = aUv;
    o.col = aCol;
    return o;
}

constant float mPI = 3.14159265;
constant float3 mL1 = float3(0.4170, 0.6672, 0.6672);
constant float3 mL2 = float3(-0.8704, 0.2176, 0.4352);

inline float3 mEnv(float3 d, float r) {
    float h = d.y * 0.5 + 0.5;
    float3 c = mix(float3(0.14, 0.13, 0.15), float3(0.78, 0.80, 0.84), smoothstep(0.0, 0.5, h));
    c = mix(c, float3(0.55, 0.68, 0.95), smoothstep(0.5, 1.0, h));
    float sun = pow(max(dot(d, mL1), 0.0), mix(150.0, 5.0, r)) * mix(8.0, 0.6, r);
    return c + float3(1.0, 0.93, 0.82) * sun;
}

inline float3 mEnvT(float3 d, float r, texture2d<float> t, float4 ep) {
    if (ep.x < 0.5) { return mEnv(d, r); }
    constexpr sampler s(filter::linear, mip_filter::linear, address::repeat);
    float u = atan2(d.z, d.x) * 0.15915494 + 0.5 + ep.y;
    float v = 0.5 - asin(clamp(d.y, -1.0, 1.0)) * 0.31830989;
    float3 c = t.sample(s, float2(u, v), level(sqrt(r) * ep.z)).rgb;
    return fmin(fmax(c, float3(0.0)), float3(40.0)) * ep.w;
}

inline float3 mBrdf(float3 N, float3 V, float3 L, float3 diffC, float3 F0, float r) {
    float3 H = normalize(V + L);
    float NdL = max(dot(N, L), 0.0);
    float NdV = max(dot(N, V), 0.001);
    float NdH = max(dot(N, H), 0.0);
    float VdH = max(dot(V, H), 0.0);
    float a = r * r;
    float a2 = a * a;
    float dd = NdH * NdH * (a2 - 1.0) + 1.0;
    float D = a2 / (mPI * dd * dd + 0.0001);
    float k = (r + 1.0) * (r + 1.0) / 8.0;
    float G = (NdL / (NdL * (1.0 - k) + k)) * (NdV / (NdV * (1.0 - k) + k));
    float3 F = F0 + (1.0 - F0) * pow(1.0 - VdH, 5.0);
    float3 spec = D * G * F / max(4.0 * NdV * NdL, 0.001);
    return ((1.0 - F) * diffC / mPI + spec) * NdL;
}

inline float mLin(float d) { return 10.0 / (100.05 - (2.0 * d - 1.0) * 99.95); }      // depth buffer -> view distance (near 0.05, far 100)
inline float3 wAbsorb(constant ModelU& u) { return float3(0.45, 0.09, 0.05) * mix(3.0, 0.4, u.wc.x) + u.wc.y * 0.5; }      // per metre
inline float wCaus(float2 sq, float tt) {
    float c1 = mVn(sq * 1.6 + float2(tt * 0.5, tt * 0.3)), c2 = mVn(sq * 2.1 - float2(tt * 0.4, -tt * 0.55) + 5.0);
    return pow(clamp(1.0 - abs(c1 - c2) * 3.4, 0.0, 1.0), 7.0);
}
inline float3 wFog(constant ModelU& u, float depthCam) {      // display-space colour of the water column; darker the deeper the camera
    float k = 1.0 - exp(-depthCam * 0.15);
    return mix(float3(0.10, 0.45, 0.48), float3(0.01, 0.06, 0.11), k) * mix(float3(1.0), u.color.rgb, 0.7);
}
struct WUOut { float4 pos [[position]]; float2 uv; };
vertex WUOut waterUnderV(uint vid [[vertex_id]]) {
    float2 p = float2(float((vid << 1) & 2u), float(vid & 2u));
    WUOut o; o.pos = float4(p * 2.0 - 1.0, 0.5, 1.0); o.uv = float2(p.x, 1.0 - p.y); return o;
}
// Camera below the surface: everything already drawn is absorbed / scattered by the water column, with light shafts.
fragment float4 waterUnderF(WUOut in [[stage_in]], constant ModelU& u [[buffer(0)]], constant float4x4& inv [[buffer(1)]],
                            depth2d<float> tSD [[texture(4)]], texture2d<float> tScene [[texture(5)]]) {
    constexpr sampler ls(filter::linear, address::clamp_to_edge);
    constexpr sampler ns(filter::nearest, address::clamp_to_edge);
    float2 nd = float2(in.uv.x * 2.0 - 1.0, 1.0 - in.uv.y * 2.0);
    float d = u.wf.z > 0.5 ? tSD.sample(ns, in.uv) : 1.0;
    float4 pw = inv * float4(nd, d * 2.0 - 1.0, 1.0);
    float3 wp = pw.xyz / pw.w;
    bool hit = d < 0.9999;
    float dist = hit ? length(wp - u.eye.xyz) : 80.0;
    float3 dir = normalize(wp - u.eye.xyz);
    float depthCam = max(u.wf.x - u.eye.y, 0.0);
    float3 Tp = pow(exp(-wAbsorb(u) * dist), float3(0.4545));
    float3 sc = clamp(tScene.sample(ls, in.uv).rgb, float3(0.0), float3(4.0));
    float3 col = sc * Tp + wFog(u, depthCam) * (1.0 - Tp);
    float t = u.wa.y * u.wb.x;
    float s = (u.wf.x - u.eye.y) / max(dir.y, 0.05);
    float2 hp = u.eye.xz + dir.xz * s;
    float sh = pow(clamp(mVn(hp * 0.8 + t * 0.2) * 1.6 - 0.35, 0.0, 1.0), 2.0) * mVn(hp * 0.25 - t * 0.1 + 4.0);
    col += float3(0.55, 0.85, 0.8) * sh * smoothstep(-0.1, 0.5, dir.y) * (1.0 - exp(-dist * 0.12)) * exp(-depthCam * 0.12) * u.eye.w * u.wc.w * 0.5 * (u.wf.w > 0.5 ? 0.3 : 1.0);
    if (u.wf.w > 0.5) {      // Rays: volumetric shafts in the water + the same beams landing on whatever is underwater
        float rt = t * u.wg.w, rstr = u.wg.x;
        float Ly = max(mL1.y, 0.15);
        float maxD = min(dist, 28.0 * u.wg.y);
        float acc = 0.0;
        const int NR = 10;
        float jit = fract(sin(dot(in.pos.xy, float2(12.9898, 78.233))) * 43758.5453);
        for (int i = 0; i < NR; i++) {
            float st = (float(i) + jit) / float(NR) * maxD;
            float3 q = u.eye.xyz + dir * st;
            float dpt = u.wf.x - q.y;
            if (dpt < 0.0) { continue; }
            acc += wBeam(q.xz + mL1.xz / Ly * dpt, rt, u.wg.z) * exp(-dpt * 0.11 / max(u.wg.y, 0.2));
        }
        acc *= maxD / float(NR) * 0.18;
        float fwd = 0.45 + 0.55 * pow(clamp(dot(dir, mL1), 0.0, 1.0), 2.0);
        float lightK = max(u.eye.w, 0.3);
        col += float3(0.50, 0.85, 0.78) * acc * fwd * lightK * rstr * (1.0 - 0.6 * (1.0 - exp(-depthCam * 0.08)));
        if (hit && wp.y < u.wf.x) {      // beams hit the ground, even in shallow water, and light it up with a soft glow beside them
            float dg = u.wf.x - wp.y;
            float2 sg = wp.xz + mL1.xz / Ly * dg;
            float bg = wBeam(sg, rt, u.wg.z) * exp(-dg * 0.11 / max(u.wg.y, 0.2));
            float glow = wBeam(sg * 0.4, rt * 0.7, 0.2) * exp(-dg * 0.09);
            col += (sc * Tp * 2.2 + float3(0.35, 0.6, 0.55) * 0.35) * bg * lightK * rstr + float3(0.25, 0.5, 0.46) * glow * 0.18 * lightK * rstr * Tp;
        }
    }
    return float4(col, 1.0);
}

struct PlOccU { float4x4 inv; float4x4 vp; float4 p0; float4 n; float4 flags; };
inline float plDepth(constant PlOccU& u, float2 uv, thread bool& ok) {
    float2 nd = float2(uv.x * 2.0 - 1.0, 1.0 - uv.y * 2.0);
    float4 a0 = u.inv * float4(nd, -1.0, 1.0), a1 = u.inv * float4(nd, 1.0, 1.0);
    float3 A = a0.xyz / a0.w, B = a1.xyz / a1.w;
    float den = dot(B - A, u.n.xyz);
    ok = abs(den) > 1e-9;
    float t = ok ? dot(u.p0.xyz - A, u.n.xyz) / den : 0.0;
    float4 cl = u.vp * float4(A + (B - A) * t, 1.0);
    return (cl.z + cl.w) * 0.5 / cl.w;
}
fragment float4 planeOccF(WUOut in [[stage_in]], constant PlOccU& u [[buffer(0)]], texture2d<float> tA [[texture(0)]], depth2d<float> tSD [[texture(4)]]) {
    constexpr sampler ls(filter::linear, address::clamp_to_edge);
    constexpr sampler ns(filter::nearest, address::clamp_to_edge);
    float4 c = tA.sample(ls, in.uv);
    if (c.a <= 0.0 || u.flags.x < 0.5) { return c; }
    bool ok; float pd = plDepth(u, in.uv, ok);
    float md = tSD.sample(ns, in.uv);
    return (ok && pd > md + 0.0004) ? float4(0.0) : c;      // a model is nearer at this pixel
}
struct PlDOut { float d [[depth(any)]]; };
fragment PlDOut planeDepthF(WUOut in [[stage_in]], constant PlOccU& u [[buffer(0)]], texture2d<float> tA [[texture(0)]]) {
    constexpr sampler ns(filter::nearest, address::clamp_to_edge);
    bool ok; float pd = plDepth(u, in.uv, ok);
    if (!ok || tA.sample(ns, in.uv).a < 0.5) { discard_fragment(); }
    PlDOut o; o.d = clamp(pd, 0.0, 1.0); return o;
}

fragment float4 modelFragment(MOut in [[stage_in]], constant ModelU& u [[buffer(0)]],
                              texture2d<float> tBase [[texture(0)]], texture2d<float> tMR [[texture(1)]],
                              texture2d<float> tEm [[texture(2)]], texture2d<float> tOcc [[texture(3)]],
                              depth2d<float> tSD [[texture(4)]], texture2d<float> tScene [[texture(5)]],
                              texture2d<float> tEnv [[texture(6)]],
                              array<texture2d<float>, 4> tD [[texture(7)]], array<texture2d<float>, 4> tN [[texture(11)]], array<texture2d<float>, 4> tR [[texture(15)]],
                              texture2d<float> tW0 [[texture(19)]], texture2d<float> tW1 [[texture(20)]],
                              texture2d<float> tPN [[texture(21)]], texture2d<float> tPR [[texture(22)]], texture2d<float> tPM [[texture(23)]],
                              texture2d<float> tPH2 [[texture(24)]], texture2d<float> tPO [[texture(25)]], constant float4* LB [[buffer(5)]],
                              sampler sBase [[sampler(0)]], sampler sMR [[sampler(1)]],
                              sampler sEm [[sampler(2)]], sampler sOcc [[sampler(3)]]) {
    float2 uv = in.uv;
    if (u.pg.x > 0.5) {      // procedural pbr: tile density follows the layer scale, slow domain warp hides repetition
        uv *= u.pg.zw;
        float2 q = uv * 0.37;
        uv += (float2(mVn(q + 11.0), mVn(q + 37.0)) - 0.5) * 0.5;
    }
    bool pmOn = u.pq.w > 0.5;
    constexpr sampler sP(filter::linear, mip_filter::linear, address::repeat, max_anisotropy(8));
    if (pmOn) { uv *= u.pt.xy; }
    float2 gx = dfdx(uv), gy = dfdy(uv);
    float3 N = normalize(in.n);
    float3 V = normalize(u.eye.xyz - in.w);
    if (dot(N, V) < 0.0) { N = -N; }
    float nlt = u.lc0.w + u.lc1.w + u.lc2.w + u.pr.w;
    float sunK = nlt > 0.5 ? 0.2 : 1.0;      // scene lights replace the default studio sun / env instead of drowning in it
    float envK = nlt > 0.5 ? 0.45 : 1.0;
    if (u.wa.x > 0.5) {      // water
        constexpr sampler ls(filter::linear, address::clamp_to_edge);
        constexpr sampler ns(filter::nearest, address::clamp_to_edge);
        float flow = u.wd.z;
        float2 g; float h = wvH(in.w.xz, u.wa.y, u.wa.z, u.wa.w, u.wb.x, u.wb.w, flow, u.we.x, u.we.yz, 6, g);
        float tt = u.wa.y * u.wb.x;
        float dist = length(u.eye.xyz - in.w);
        float2 g4; float h4 = wvH(in.w.xz, u.wa.y, u.wa.z, u.wa.w, u.wb.x, u.wb.w, flow, u.we.x, u.we.yz, 4, g4);      // the mesh itself is displaced with 4 octaves
        float baseY = in.w.y - h4;      // true rest level (was off by the 6-octave detail, which flipped the "camera below" test)
        bool under = u.eye.y < baseY - 0.002;
        float pf = length(fwidth(in.w));
        float fadeD = 1.0 / (1.0 + pf * u.wa.w * 14.0);      // fine detail fades with pixel footprint: no shimmer in the distance
        float zone = mVn(in.w.xz * 0.045 + 11.0);
        float2 q = in.w.xz * u.wa.w * 3.0;
        float2 cf = float2(cos(flow), sin(flow));
        float2 qa = q + cf * tt * 0.9 + (float2(mVn(q * 0.23 + 3.0), mVn(q * 0.23 + 9.0)) - 0.5) * 2.5;
        float2 qb = q * 1.73 + float2(-cf.y, cf.x) * tt * 0.7 + 17.0;
        float2 rp = float2(mVn(qa) - mVn(qa + float2(0.7, 1.9)), mVn(qa.yx * 1.1 + 5.0) - mVn(qa.yx * 1.1 + float2(2.1, 0.4)));
        rp += 0.6 * float2(mVn(qb) - mVn(qb + float2(1.3, 0.2)), mVn(qb.yx) - mVn(qb.yx + float2(0.5, 1.1)));
        g += rp * u.wa.z * u.wa.w * 0.5 * u.wd.y * fadeD * mix(0.5, 1.4, zone);
        float3 Nw = normalize(float3(-g.x, 1.0, -g.y));
        Nw = normalize(mix(float3(0.0, 1.0, 0.0), Nw, mix(0.4, 1.0, fadeD)));
        if (dot(Nw, V) < 0.0) { Nw = -Nw; }
        float nlt2 = u.lc0.w + u.lc1.w + u.lc2.w;
        if (under) {      // looking up at the surface from inside the water: Snell's window + total internal reflection
            float depthCam = max(baseY - u.eye.y, 0.0);
            float3 fogL = pow(wFog(u, depthCam), float3(2.2));
            float3 Ru = refract(-V, Nw, 1.333);
            float tir = dot(Ru, Ru) < 1e-4 ? 1.0 : 0.0;
            float3 sky = mEnvT(normalize(Ru + float3(0.0, 1e-4, 0.0)), 0.15, tEnv, u.envp) * u.emis.w * envK * exp(-depthCam * 0.05);
            float3 c = mix(sky, fogL * 0.8, tir);
            c = mix(c, fogL, 1.0 - exp(-dist * 0.1));
            c *= u.xtra.x;
            c = c * (1.0 + c / 6.0) / (1.0 + c);
            c = pow(max(c, float3(0.0)), float3(1.0 / 2.2));
            return float4(c * u.color.a, u.color.a);
        }
        float NdVw = clamp(dot(Nw, V), 0.1, 1.0);      // floor: at grazing angles Fresnel hit 1.0 and the whole plane turned into a flat white mirror
        float F = 0.02 + 0.98 * pow(1.0 - NdVw, 5.0);
        float3 Rw = reflect(-V, Nw); Rw.y = abs(Rw.y);
        float3 refl = mEnvT(Rw, 0.03, tEnv, u.envp) * u.emis.w * envK;
        if (u.envp.x < 0.5) {      // no HDRI: a blue sky gradient (the default grey horizon made water look like snow) ...
            refl = mix(float3(0.42, 0.58, 0.80), float3(0.10, 0.28, 0.70), clamp(Rw.y * 1.6, 0.0, 1.0)) * (0.6 + 0.4 * envK);
            if (u.wf.z > 0.5) {      // ... and, better, reflect the real picture behind it (the 2D sky layer) at the mirrored view direction
                float3 sp = u.eye.xyz + Rw * 60.0;
                float4 sc = u.vp0 * sp.x + u.vp1 * sp.y + u.vp2 * sp.z + u.vp3;
                if (sc.w > 0.05) {
                    float2 sUv = float2(sc.x / sc.w * 0.5 + 0.5, 0.5 - sc.y / sc.w * 0.5);
                    float sEdge = smoothstep(0.0, 0.06, min(min(sUv.x, 1.0 - sUv.x), min(sUv.y, 1.0 - sUv.y)));
                    if (sEdge > 0.0 && tSD.sample(ns, sUv) >= 0.9999) {
                        float3 sk = pow(clamp(tScene.sample(ls, sUv).rgb, float3(0.0), float3(4.0)), float3(2.2));
                        refl = mix(refl, sk, sEdge);
                    }
                }
            }
        }
        if (u.wf.y > 0.5 && u.wf.z > 0.5) {      // Reflect surface: screen-space reflection of everything already drawn around the water
            constexpr sampler rs(filter::linear, address::clamp_to_edge);
            constexpr sampler rn(filter::nearest, address::clamp_to_edge);
            float3 rp = in.w + Nw * 0.01;
            float stp = 0.05;
            for (int i = 0; i < 16; i++) {
                rp += Rw * stp; stp *= 1.32;
                float4 cc = u.vp0 * rp.x + u.vp1 * rp.y + u.vp2 * rp.z + u.vp3;
                if (cc.w <= 0.05) { break; }
                float2 ruv = float2(cc.x / cc.w * 0.5 + 0.5, 0.5 - cc.y / cc.w * 0.5);
                if (ruv.x < 0.0 || ruv.x > 1.0 || ruv.y < 0.0 || ruv.y > 1.0) { break; }
                float rd = tSD.sample(rn, ruv);
                if (rd < 0.9999) {
                    float dl = cc.w - mLin(rd);
                    if (dl > 0.0 && dl < 0.35 + stp * 2.0) {
                        float edge = smoothstep(0.0, 0.08, min(min(ruv.x, 1.0 - ruv.x), min(ruv.y, 1.0 - ruv.y)));
                        float3 hc = pow(clamp(tScene.sample(rs, ruv).rgb, float3(0.0), float3(4.0)), float3(2.2));
                        refl = mix(refl, hc, edge * (1.0 - float(i) / 30.0));
                        break;
                    }
                }
            }
        }
        float crest = clamp((h + u.wa.z * 0.4) / (u.wa.z * 1.3 + 1e-5), 0.0, 1.0);
        float clar = u.wc.x, turb = u.wc.y;
        float D = mix(0.3, 8.0, u.wb.z);
        float3 Rr = refract(-V, Nw, 0.75);
        Rr = normalize(mix(-V, Rr, clamp(u.wc.z * 2.0, 0.0, 1.0)));
        float cr = max(-Rr.y, 0.12);
        float3 absorb = wAbsorb(u);
        // what is below: real depth buffer + the picture drawn so far, looked up through the wavy surface (refraction warp)
        float2 suv = in.pos.xy / float2(float(tScene.get_width()), float(tScene.get_height()));
        float surfLin = 1.0 / in.pos.w;
        float ray = dist / max(surfLin, 1e-3);
        bool hasD = u.wf.z > 0.5;
        float sd0 = hasD ? tSD.read(uint2(in.pos.xy)) : 1.0;
        float th0 = sd0 < 0.9999 ? max(mLin(sd0) - surfLin, 0.0) * ray : D / cr;
        float2 dxz = -Nw.xz * u.wc.z * 0.35 * min(th0, 3.0);
        float2 duv = float2(u.vp0.x * dxz.x + u.vp2.x * dxz.y, -(u.vp0.y * dxz.x + u.vp2.y * dxz.y)) * in.pos.w * 0.5;
        float2 uvR = suv + duv;
        float sdR = hasD ? tSD.sample(ns, uvR) : 1.0;
        if (hasD && mLin(sdR) < surfLin - 0.002) { uvR = suv; sdR = sd0; }      // something in front of the water: no warping across its edge
        bool hit = sdR < 0.9999;
        float thR = hit ? max(mLin(sdR) - surfLin, 0.0) * ray : D / cr;
        float3 Tr = exp(-absorb * thR);
        float3 seabed = float3(0.0), sceneT = float3(0.0);
        float3 hp = in.w + Rr * thR;
        float sand = 0.0;
        if (hit) {      // real object / floor: lit fully when shallow, darker and bluer the deeper it is, with caustics on it
            float cs = wCaus(hp.xz * 1.7, tt) * (1.0 + 0.6 * u.wf.y);
            sceneT = clamp(tScene.sample(ls, uvR).rgb, float3(0.0), float3(4.0)) * pow(Tr, float3(0.4545)) * (1.0 + cs * (1.2 + 1.8 * u.wf.y) * u.eye.w * sunK * Tr.g);
        } else {        // nothing below: procedural seabed
            float2 sq = hp.xz * 1.7;
            float sn = mVn(sq) * 0.6 + mVn(sq * 2.9 + 4.0) * 0.4;
            float rip = 0.5 + 0.5 * sin(hp.x * 5.0 + sn * 6.0 + hp.z * 2.0);
            float3 snd = mix(float3(0.50, 0.42, 0.30), float3(0.30, 0.25, 0.18), sn) * (0.85 + 0.3 * rip);
            seabed = (snd * (0.5 + 0.5 * u.eye.w * sunK) + wCaus(sq, tt) * float3(1.0, 0.95, 0.8) * 1.2 * u.eye.w) * Tr * u.wd.w;
            sand = 1.0;
        }
        float skyAmb = 0.35 + 0.65 * clamp(Nw.y, 0.0, 1.0);
        float3 deep = float3(0.015, 0.17, 0.20) * u.color.rgb, shallow = float3(0.07, 0.42, 0.40) * u.color.rgb;
        float3 body = mix(deep, shallow, Tr.g) * skyAmb * (1.0 + turb * 1.5);
        body *= hit ? (1.0 - 0.9 * Tr.g) : (1.0 - 0.6 * Tr.g * u.wd.w);
        float3 Hs = normalize(mL1 + Nw * 0.3);
        body += float3(0.10, 0.55, 0.42) * u.color.rgb * pow(clamp(dot(-V, Hs), 0.0, 1.0), 3.0) * crest * u.wc.w * u.eye.w * 0.9;
        float rg = mix(0.03, 0.14, 1.0 - fadeD);      // glints widen with distance instead of aliasing
        float3 spec = (mBrdf(Nw, V, mL1, float3(0.0), float3(0.02), rg) * float3(3.2, 3.0, 2.8)
                     + mBrdf(Nw, V, mL1, float3(0.0), float3(0.02), 0.18) * float3(0.5, 0.48, 0.45)) * u.eye.w * u.wd.x * sunK
                    + mBrdf(Nw, V, mL2, float3(0.0), float3(0.02), 0.08) * float3(0.9, 1.0, 1.3) * sunK;
        float3 lit = float3(0.0);
        float4 lps[3] = { u.lp0, u.lp1, u.lp2 }; float4 lcs[3] = { u.lc0, u.lc1, u.lc2 };
        for (int i = 0; i < 3; i++) {
            if (lcs[i].w < 0.5) { continue; }
            float3 Lv = lps[i].xyz - in.w; float d2 = dot(Lv, Lv); float3 Ld = Lv * rsqrt(max(d2, 1e-6));
            float att = 2.5 / (d2 + 0.3);
            spec += (mBrdf(Nw, V, Ld, float3(0.0), float3(0.02), max(rg, 0.04)) + mBrdf(Nw, V, Ld, float3(0.0), float3(0.02), 0.2) * 0.25) * lcs[i].rgb * att * u.wd.x;
            lit += lcs[i].rgb * clamp(dot(Nw, Ld), 0.0, 1.0) * att;
        }
        body += float3(0.05, 0.28, 0.30) * u.color.rgb * lit * 0.3 * (0.4 + Tr.g);
        seabed += float3(0.35, 0.3, 0.22) * lit * 0.25 * Tr * u.wd.w * sand;
        float steep = clamp(length(g) * 0.9 - 0.15, 0.0, 1.0);
        float fn = mVn(q * 4.0 - tt * 0.3) * 0.6 + mVn(q * 9.0 + tt * 0.2 + 3.0) * 0.4;
        float fm0 = smoothstep(1.0 - u.wb.y * 0.6, 1.0, crest * 0.7 + steep * 0.5 + (fn - 0.5) * 0.7) * smoothstep(0.05, 0.4, u.wb.y);
        float caps = smoothstep(0.55, 0.85, mVn(in.w.xz * 0.07 + tt * 0.03 + 5.0)) * u.we.w * smoothstep(0.1, 0.5, u.wb.y);
        float dThR = fwidth(thR);
        bool coll = u.wh.x > 0.5 || u.wh.y > 0.5;
        float shoreOld = (hit && !coll) ? smoothstep(0.35, 0.0, thR) : 0.0;
        float contactF = 0.0;
        if (hit && coll) {      // water collision: foam where the surface meets rocks (steep) and shores (gentle), waves washing up and back
            float fw = mix(0.12, 1.4, u.wh.z);
            float steepD = smoothstep(0.02, 0.25, dThR * 8.0);
            float contact = smoothstep(fw, 0.0, thR);
            float wash = 0.55 + 0.45 * sin(tt * 1.4 - thR * 5.0 / (fw + 0.1) + fn * 3.0);
            float bands = smoothstep(0.55, 1.0, sin(thR * 9.0 / (fw + 0.1) - tt * 1.2 + fn * 2.0)) * smoothstep(fw * 2.6, fw * 0.8, thR) * 0.55;
            contactF = contact * steepD * u.wh.x + (contact * wash + bands) * (1.0 - steepD) * u.wh.y;
        }
        float cover = clamp(fm0 + caps * smoothstep(0.5, 0.8, fn) * 0.8 + shoreOld * smoothstep(0.3, 0.7, fn + 0.2) * u.wb.y + contactF * 1.3 * max(u.wb.y, 0.35), 0.0, 1.0);
        float ft = wFoamT(in.w.xz, tt);
        float3 fN = Nw;
        {   // bumpy foam normal from screen-space derivatives (no extra texture taps)
            float3 dpx = dfdx(in.w), dpy = dfdy(in.w);
            float dhx = dfdx(ft), dhy = dfdy(ft);
            float3 r1 = cross(dpy, Nw), r2 = cross(Nw, dpx);
            float det = dot(dpx, r1);
            float3 gr = sign(det) * (dhx * r1 + dhy * r2);
            fN = normalize(abs(det) * Nw - clamp(gr * 0.02, float3(-0.6 * abs(det)), float3(0.6 * abs(det))));
        }
        float fm = clamp((cover * 1.5 - (1.0 - ft) * 0.85) * 2.0, 0.0, 1.0);
        float back = pow(clamp(dot(-V, mL1), 0.0, 1.0), 4.0);
        float3 foamC = mix(float3(0.60, 0.80, 0.82), float3(0.97, 0.98, 0.99), clamp(fm * 1.2 + ft * 0.3, 0.0, 1.0))
                     * (0.3 + 0.7 * clamp(dot(fN, mL1), 0.0, 1.0) * u.eye.w * sunK + lit * 0.5 + 0.22 * envK + 0.12 * back * u.eye.w) * (0.78 + 0.22 * ft);
        float3 base = mix(mix(body + seabed, refl, F), foamC, fm);
        float3 outc = base + spec * (1.0 - fm);
        outc *= u.xtra.x;
        outc = outc * (1.0 + outc / 6.0) / (1.0 + outc);
        outc = pow(max(outc, float3(0.0)), float3(1.0 / 2.2));
        outc += sceneT * (1.0 - F) * (1.0 - fm);
        float aw = u.color.a;
        return float4(outc * aw, aw);
    }
    float pSh = 1.0;
    bool pbr = u.xtra.w > 0.0 && u.has.w > 0.5;
    float3 Tn = float3(0.0), Bn = float3(0.0);
    if (pbr) {      // Extras PBR: tangent frame from derivatives, height (MR.r) -> parallax, normal XY (occ.gb) -> bump
        float3 dp1 = dfdx(in.w), dp2 = dfdy(in.w);
        float2 du1 = dfdx(in.uv), du2 = dfdy(in.uv);
        float3 p2 = cross(dp2, N), p1 = cross(N, dp1);
        float3 T = p2 * du1.x + p1 * du2.x, B = p2 * du1.y + p1 * du2.y;
        float inv = rsqrt(max(max(dot(T, T), dot(B, B)), 1e-12));
        Tn = T * inv; Bn = B * inv;
        if (u.pg.y > 0.0 && u.has.y > 0.5 && u.sp0.x < 0.5) {      // parallax occlusion mapping (height in metal-rough R) + contact self-shadow
            float3 Vt = float3(dot(V, Tn), dot(V, Bn), max(dot(V, N), 0.3));
            float2 P = Vt.xy / Vt.z * u.pg.y * smoothstep(0.05, 0.4, dot(V, N));
            float plod = max(0.0, log2(max(length(gx), length(gy)) * float(tMR.get_width()))) + 0.5;
            const int NS = 20;
            float ld = 1.0 / float(NS), cl = 0.0;
            float2 cuv = uv;
            float dv = 1.0 - tMR.sample(sMR, cuv, level(plod)).r;
            for (int i = 0; i < NS; i++) {
                if (cl >= dv) { break; }
                cuv -= P * ld; dv = 1.0 - tMR.sample(sMR, cuv, level(plod)).r; cl += ld;
            }
            float2 prv = cuv + P * ld;
            float aft = dv - cl, bef = (1.0 - tMR.sample(sMR, prv, level(plod)).r) - cl + ld;
            uv = mix(cuv, prv, clamp(aft / (aft - bef - 1e-5), 0.0, 1.0));
            float3 Lt = float3(dot(mL1, Tn), dot(mL1, Bn), dot(mL1, N));
            if (Lt.z > 0.02) {
                float h0 = tMR.sample(sMR, uv, level(plod)).r;
                float2 Ls = Lt.xy / max(Lt.z, 0.1) * u.pg.y;
                for (int i = 1; i <= 6; i++) {
                    float f = float(i) / 6.0;
                    float hh = tMR.sample(sMR, uv + Ls * f, level(plod)).r;
                    pSh = min(pSh, clamp(1.0 - (hh - (h0 + f * 0.5)) * 6.0, 0.0, 1.0));
                }
            }
        }
        float2 nxy = u.sp0.x > 0.5 ? float2(0.0) : (tOcc.sample(sOcc, uv, gradient2d(gx, gy)).gb * 2.0 - 1.0) * u.xtra.w;
        N = normalize(Tn * nxy.x + Bn * nxy.y + N * sqrt(max(1.0 - dot(nxy, nxy), 0.05)));
    }
    if (pmOn) {      // imported PBR maps: tangent frame from derivatives, parallax + self-shadow from the height map, normal map
        float3 dp1 = dfdx(in.w), dp2 = dfdy(in.w);
        float2 du1 = dfdx(in.uv), du2 = dfdy(in.uv);
        float3 q2 = cross(dp2, N), q1 = cross(N, dp1);
        float3 Tq = q2 * du1.x + q1 * du2.x, Bq = q2 * du1.y + q1 * du2.y;
        float iv = rsqrt(max(max(dot(Tq, Tq), dot(Bq, Bq)), 1e-12));
        float3 Tm = Tq * iv, Bm = Bq * iv;
        bool hasH = u.pm.w > 0.5;
        if (hasH && u.pt.z > 0.0) {
            float3 Vt = float3(dot(V, Tm), dot(V, Bm), max(dot(V, N), 0.3));
            float2 P = Vt.xy / Vt.z * u.pt.z * smoothstep(0.05, 0.4, dot(V, N));
            float plod = max(0.0, log2(max(length(gx), length(gy)) * float(tPH2.get_width()))) + 0.5;
            const int NS = 24;
            float ld = 1.0 / float(NS), cl = 0.0;
            float2 cuv = uv;
            float dv = 1.0 - tPH2.sample(sP, cuv, level(plod)).r;
            for (int i = 0; i < NS; i++) {
                if (cl >= dv) { break; }
                cuv -= P * ld; dv = 1.0 - tPH2.sample(sP, cuv, level(plod)).r; cl += ld;
            }
            float2 prv = cuv + P * ld;
            float aft = dv - cl, bef = (1.0 - tPH2.sample(sP, prv, level(plod)).r) - cl + ld;
            uv = mix(cuv, prv, clamp(aft / (aft - bef - 1e-5), 0.0, 1.0));
            float3 Lt = float3(dot(mL1, Tm), dot(mL1, Bm), dot(mL1, N));
            if (Lt.z > 0.02) {
                float h0 = tPH2.sample(sP, uv, level(plod)).r;
                float2 Ls = Lt.xy / max(Lt.z, 0.1) * u.pt.z;
                for (int i = 1; i <= 6; i++) {
                    float f = float(i) / 6.0;
                    float hh = tPH2.sample(sP, uv + Ls * f, level(plod)).r;
                    pSh = min(pSh, clamp(1.0 - (hh - (h0 + f * 0.5)) * 6.0, 0.0, 1.0));
                }
            }
        }
        float3 nt = float3(0.0, 0.0, 1.0);
        if (u.pm.x > 0.5) {
            nt = tPN.sample(sP, uv, gradient2d(gx, gy)).rgb * 2.0 - 1.0;
            nt.y *= u.pn.z;
        } else if (hasH) {      // no normal map: the relief itself gives the normals
            float e = 1.0 / float(tPH2.get_width());
            float hl = tPH2.sample(sP, uv - float2(e, 0.0), level(0.0)).r, hr = tPH2.sample(sP, uv + float2(e, 0.0), level(0.0)).r;
            float hd = tPH2.sample(sP, uv - float2(0.0, e), level(0.0)).r, hu = tPH2.sample(sP, uv + float2(0.0, e), level(0.0)).r;
            nt = float3((hl - hr) * 6.0, (hd - hu) * 6.0, 1.0);
        }
        nt.xy *= u.pn.y;
        nt.z = sqrt(max(1.0 - dot(nt.xy, nt.xy), 0.05));
        N = normalize(Tm * nt.x + Bm * nt.y + N * nt.z);
    }
    float spCov = 0.0, spR = 0.9, spM = 0.0, spAo = 1.0; float3 spC = float3(0.0);
    if (u.sp0.x > 0.5 && pbr) {      // terrain splat: up to 4 tiled PBR layers, weights from rules, height-based blend, per-pixel normals
        constexpr sampler sT(filter::linear, mip_filter::linear, address::repeat, max_anisotropy(8));
        constexpr sampler sW(filter::linear, address::clamp_to_edge);
        float3 w0 = tW0.sample(sW, in.uv).rgb; float w1 = tW1.sample(sW, in.uv).r;
        float wt[4] = { w0.r, w0.g, w0.b, w1 };
        float tl[4] = { u.sp1.x, u.sp1.y, u.sp1.z, u.sp1.w };
        float st[4] = { u.sp2.x, u.sp2.y, u.sp2.z, u.sp2.w };
        float3 Vt = float3(dot(V, Tn), dot(V, Bn), max(dot(V, N), 0.3));
        float2 duvx = dfdx(in.uv), duvy = dfdy(in.uv);
        float depth = u.pg.y, expo = 2.0 + depth * 60.0, rcs = 0.7986, rsn = 0.6018;
        float kk = 0.5 + 0.3 * sin(in.uv.x * 9.1 + in.uv.y * 5.3) * cos(in.uv.y * 7.7 - in.uv.x * 3.9);
        float gk = 1.0 / sqrt(kk * kk + (1.0 - kk) * (1.0 - kk));
        float2 par = Vt.xy / Vt.z * depth * 8.0 * smoothstep(0.05, 0.4, dot(V, N));
        float wh[4]; float3 cA[4]; float rA[4], mA[4], aA[4]; float2 nA[4];
        float wsum = 0.0, cover = 0.0;
        for (int l = 0; l < 4; l++) {
            wh[l] = 0.0; cA[l] = float3(0.0); rA[l] = 0.9; mA[l] = 0.0; aA[l] = 1.0; nA[l] = float2(0.0);
            cover += wt[l];
            if (wt[l] < 0.004) { continue; }
            float2 gxp = duvx * tl[l], gyp = duvy * tl[l], p = in.uv * tl[l];
            p += par * (tR[l].sample(sT, p, gradient2d(gxp, gyp)).r - 0.5);
            float2 pb = float2(rcs * p.x - rsn * p.y, rsn * p.x + rcs * p.y) * 0.93 + float2(17.3, 5.1);
            float2 gxb = float2(rcs * gxp.x - rsn * gxp.y, rsn * gxp.x + rcs * gxp.y) * 0.93, gyb = float2(rcs * gyp.x - rsn * gyp.y, rsn * gyp.x + rcs * gyp.y) * 0.93;
            float4 d1 = tD[l].sample(sT, p, gradient2d(gxp, gyp)), d2 = tD[l].sample(sT, pb, gradient2d(gxb, gyb));
            float4 r1 = tR[l].sample(sT, p, gradient2d(gxp, gyp)), r2 = tR[l].sample(sT, pb, gradient2d(gxb, gyb));
            float4 n1 = tN[l].sample(sT, p, gradient2d(gxp, gyp)), n2 = tN[l].sample(sT, pb, gradient2d(gxb, gyb));
            float3 avg = tD[l].sample(sT, float2(0.5), level(12.0)).rgb;
            float3 ce = clamp(avg + (mix(d1.rgb, d2.rgb, kk) - avg) * gk, 0.0, 1.0);
            float h = clamp(0.5 + (mix(r1.r, r2.r, kk) - 0.5) * gk, 0.0, 1.0);
            float2 na = n1.rg * 2.0 - 1.0, nb0 = n2.rg * 2.0 - 1.0;
            float2 nb = float2(rcs * nb0.x + rsn * nb0.y, -rsn * nb0.x + rcs * nb0.y);
            cA[l] = pow(ce, float3(2.2)); rA[l] = mix(r1.g, r2.g, kk); mA[l] = mix(r1.b, r2.b, kk); aA[l] = mix(n1.b, n2.b, kk);
            nA[l] = mix(na, nb, kk) * gk * st[l];
            wh[l] = wt[l] * pow(0.15 + h, expo); wsum += wh[l];
        }
        float tot = max(wsum, 1e-5); float2 nsum = float2(0.0);
        for (int l = 0; l < 4; l++) {
            float w = wh[l] / tot;
            spC += cA[l] * w; spR += (rA[l] - 0.9) * w; spM += mA[l] * w; spAo += (aA[l] - 1.0) * w; nsum += nA[l] * w;
        }
        spCov = clamp(cover, 0.0, 1.0);
        float2 nx2 = nsum * u.xtra.w * spCov;
        N = normalize(Tn * nx2.x + Bn * nx2.y + N * sqrt(max(1.0 - dot(nx2, nx2), 0.05)));
    }
    float a = u.color.a * in.col.a;
    float3 tint = u.color.rgb * pow(max(in.col.rgb, float3(0.0)), float3(2.2));
    float3 alb = tint;
    if (u.has.x > 0.5) {
        float4 t = tBase.sample(sBase, uv, gradient2d(gx, gy));
        a *= t.a;
        alb *= pow(clamp(t.rgb / max(t.a, 0.001), 0.0, 1.0), float3(2.2));
    }
    if (spCov > 0.0) { alb = mix(alb, tint * spC, spCov); }
    if (pmOn && u.pn.x > 0.5) { if (tPO.sample(sP, uv, gradient2d(gx, gy)).r < 0.5) { discard_fragment(); } }
    if (u.prm.z >= 0.0) {
        if (a < u.prm.z) { discard_fragment(); }
        a = 1.0;
    }
    float metal = u.prm.x * u.opt.y;
    float rough = u.prm.y;
    float ao = 1.0;
    if (u.has.w > 0.5) { ao = mix(1.0, tOcc.sample(sOcc, uv, gradient2d(gx, gy)).r, u.opt.w); }
    if (u.has.y > 0.5) {
        float4 m = tMR.sample(sMR, uv, gradient2d(gx, gy));
        rough *= m.g;
        metal *= m.b * u.opt.y;
    }
    if (pmOn) {
        if (u.pm.y > 0.5) { rough = tPR.sample(sP, uv, gradient2d(gx, gy)).r; }
        rough *= u.pq.x;
        if (u.pm.z > 0.5) { metal = tPM.sample(sP, uv, gradient2d(gx, gy)).r * u.opt.y; }
        metal *= u.pq.y;
        if (u.has.w > 0.5) { ao = mix(1.0, tOcc.sample(sOcc, uv, gradient2d(gx, gy)).r, u.pr.z); }
        float3 dnr = fwidth(N);      // geometric specular anti-aliasing: bumpy normals widen the highlight instead of sparkling
        rough = sqrt(rough * rough + min(0.5 * dot(dnr, dnr), 0.18));
    }
    if (spCov > 0.0) { rough = mix(rough, spR, spCov); metal = mix(metal, spM * u.opt.y, spCov); ao = mix(ao, spAo, spCov); }
    rough = clamp(rough, 0.04, 1.0);
    metal = clamp(metal, 0.0, 1.0);

    float NdV = max(dot(N, V), 0.001);

    float3 F0 = mix(float3(0.04), alb, metal);
    float3 diffC = alb * (1.0 - metal);
    float3 col = mBrdf(N, V, mL1, diffC, F0, rough) * float3(3.2, 3.0, 2.8) * u.eye.w * pSh * sunK
               + mBrdf(N, V, mL2, diffC, F0, rough) * float3(0.9, 1.0, 1.3) * sunK;
    {   // scene lights (Lighting layers): point / sun / spot, range window, spot cone + penumbra, separate diffuse + specular strength
        for (int i = 0; i < 8; i++) {
            float4 LA = LB[i * 4], LC = LB[i * 4 + 1], LD = LB[i * 4 + 2], LE = LB[i * 4 + 3];
            if (LE.w < 0.5) { continue; }
            float3 Ld; float att = 2.0;
            if (LA.w > 0.5 && LA.w < 1.5) {
                Ld = -normalize(LD.xyz);
            } else {
                float3 Lv = LA.xyz - in.w; float d2 = dot(Lv, Lv);
                Ld = Lv * rsqrt(max(d2, 1e-6));
                att = 2.5 / (d2 + 0.3);
                if (LC.w > 0.001) { float rr = d2 / (LC.w * LC.w); float wnd = clamp(1.0 - rr * rr, 0.0, 1.0); att *= wnd * wnd; }
                if (LA.w > 1.5) { att *= smoothstep(LD.w, max(LE.x, LD.w + 0.001), dot(-Ld, normalize(LD.xyz))); }
            }
            float3 full = mBrdf(N, V, Ld, diffC, F0, rough);
            float3 sp = mBrdf(N, V, Ld, float3(0.0), F0, rough);
            col += ((full - sp) * LE.y + sp * LE.z) * LC.rgb * att;
        }
    }
    if (pbr || pmOn) { col *= mix(1.0, ao, 0.8); }
    float3 R = reflect(-V, N);
    float3 Fr = F0 + (max(float3(1.0 - rough), F0) - F0) * pow(1.0 - NdV, 5.0);
    if (u.opt.x > 0.5) {
        col += diffC * mEnvT(N, 1.0, tEnv, u.envp) * 0.8 * ao * u.emis.w * envK;
        col += mEnvT(R, rough, tEnv, u.envp) * Fr * (1.0 - 0.5 * rough) * ao * u.emis.w * envK;
    } else {
        col += diffC * 0.3 * ao;
    }
    if (pmOn && u.pr.x > 0.001) {      // clear coat: a second glossy dielectric layer over the base (lacquer, car paint, wet look)
        float3 Ng = normalize(in.n); if (dot(Ng, V) < 0.0) { Ng = -Ng; }
        float cr = clamp(u.pr.y, 0.03, 1.0);
        float Fc = 0.04 + 0.96 * pow(1.0 - max(dot(Ng, V), 0.001), 5.0);
        float3 coat = mBrdf(Ng, V, mL1, float3(0.0), float3(0.04), cr) * float3(3.2, 3.0, 2.8) * u.eye.w * sunK * pSh;
        if (u.opt.x > 0.5) { coat += mEnvT(reflect(-V, Ng), cr, tEnv, u.envp) * Fc * u.emis.w * envK; }
        col = col * (1.0 - Fc * u.pr.x) + coat * u.pr.x;
    }
    float3 em = u.emis.xyz;
    if (u.has.z > 0.5) { em *= pow(tEm.sample(sEm, uv, gradient2d(gx, gy)).rgb, float3(2.2)); }
    if (pmOn && u.has.z > 0.5) { em = pow(tEm.sample(sEm, uv, gradient2d(gx, gy)).rgb, float3(2.2)) * u.pq.z; }
    col += em;
    col = mix(col, alb + em, u.prm.w);
    if (u.opt.z > 0.5) {
        float3 v = alb;
        if (u.opt.z > 1.5) { v = float3(rough); }
        if (u.opt.z > 2.5) { v = float3(metal); }
        if (u.opt.z > 3.5) { v = float3(ao); }
        if (u.opt.z > 4.5) { v = em; }
        return float4(pow(max(v, float3(0.0)), float3(1.0 / 2.2)) * a, a);
    }
    col *= u.xtra.x;
    col = col * (1.0 + col / 6.0) / (1.0 + col);
    col = pow(max(col, float3(0.0)), float3(1.0 / 2.2));
    return float4(col * a, a);
}
"""
}

extension MetalModelSL {
    /// Same shader plus hardware ray-traced shadows / ambient occlusion against the model's own triangles.
    static var rtSource: String {
        var s = source
        s = s.replacingOccurrences(of: "struct ModelU {", with: "#include <metal_raytracing>\nusing namespace metal::raytracing;\nstruct ModelU {")
        s = s.replacingOccurrences(of: "fragment float4 modelFragment(", with: "fragment float4 modelFragmentRT(")
        s = s.replacingOccurrences(of: "sampler sEm [[sampler(2)]], sampler sOcc [[sampler(3)]]) {",
            with: "sampler sEm [[sampler(2)]], sampler sOcc [[sampler(3)]],\n primitive_acceleration_structure acc [[buffer(2)]], constant float4& rtp [[buffer(3)]], constant float4x4& rinv [[buffer(4)]]) {")
        let code = """
    float rtVis = 1.0; float rtAo = 1.0;
    if (rtp.x > 0.0) {
        float sc = max(length(rinv[0].xyz), 1e-6);
        float3 Pw = in.w + N * 0.004;
        intersector<triangle_data> it;
        it.assume_geometry_type(geometry_type::triangle);
        ray r;
        r.origin = (rinv * float4(Pw, 1.0)).xyz;
        r.min_distance = 0.0005 * sc;
        float sh = 0.0;
        r.max_distance = 1.0e4;
        r.direction = normalize((rinv * float4(mL1, 0.0)).xyz);
        if (it.intersect(r, acc).type == intersection_type::triangle) { sh = 1.0; }
        rtVis = 1.0 - sh * u.xtra.z;
        float3 T = normalize(abs(N.y) < 0.9 ? cross(N, float3(0.0, 1.0, 0.0)) : cross(N, float3(1.0, 0.0, 0.0)));
        float3 Bt = cross(N, T);
        float occl = 0.0;
        for (int k = 0; k < 8; k++) {
            float a2 = float(k) * 0.7853982;
            float el = (k & 1) == 0 ? 0.45 : 0.85;
            float3 dw = normalize(N * el + (T * cos(a2) + Bt * sin(a2)) * (1.0 - el));
            r.direction = normalize((rinv * float4(dw, 0.0)).xyz);
            r.max_distance = max(rtp.y, 0.01) * sc;
            if (it.intersect(r, acc).type == intersection_type::triangle) { occl += 1.0; }
        }
        rtAo = 1.0 - (occl / 8.0) * u.xtra.y;
    }
    col *= rtVis; ao *= rtAo;
    float3 R = reflect(-V, N);
"""
        s = s.replacingOccurrences(of: "    float3 R = reflect(-V, N);\n", with: code)
        return s
    }
}

/// Must match ModelU in MSL (14 x float4 = 224 bytes).
struct ModelU {
    var vp0 = SIMD4<Float>(0, 0, 0, 0), vp1 = SIMD4<Float>(0, 0, 0, 0)
    var vp2 = SIMD4<Float>(0, 0, 0, 0), vp3 = SIMD4<Float>(0, 0, 0, 0)
    var m0 = SIMD4<Float>(0, 0, 0, 0), m1 = SIMD4<Float>(0, 0, 0, 0)
    var m2 = SIMD4<Float>(0, 0, 0, 0), m3 = SIMD4<Float>(0, 0, 0, 0)
    var color = SIMD4<Float>(1, 1, 1, 1)
    var emis = SIMD4<Float>(0, 0, 0, 0)
    var eye = SIMD4<Float>(0, 0, 3, 0)
    var prm = SIMD4<Float>(0, 0.8, -1, 0)
    var has = SIMD4<Float>(0, 0, 0, 0)
    var opt = SIMD4<Float>(1, 1, 0, 1)
    var xtra = SIMD4<Float>(1, 1, 1, 0)
    var lp0 = SIMD4<Float>(0, 0, 0, 0), lp1 = SIMD4<Float>(0, 0, 0, 0), lp2 = SIMD4<Float>(0, 0, 0, 0)
    var lc0 = SIMD4<Float>(0, 0, 0, 0), lc1 = SIMD4<Float>(0, 0, 0, 0), lc2 = SIMD4<Float>(0, 0, 0, 0)
    var pg = SIMD4<Float>(0, 0, 1, 1), wa = SIMD4<Float>(0, 0, 0, 0), wb = SIMD4<Float>(0, 0, 0, 0)
    var wc = SIMD4<Float>(0.6, 0.15, 0.5, 0.5), wd = SIMD4<Float>(1, 0.6, 0.5, 0.7), we = SIMD4<Float>(0.7, 0.8, 0.15, 0.5), wf = SIMD4<Float>(0, 0, 0, 0), wg = SIMD4<Float>(1, 1, 1, 1), wh = SIMD4<Float>(0, 0, 0.4, 0)
    var envp = SIMD4<Float>(0, 0, 0, 1)
    var sp0 = SIMD4<Float>(0, 0, 0, 0), sp1 = SIMD4<Float>(1, 1, 1, 1), sp2 = SIMD4<Float>(1, 1, 1, 1)
    var pm = SIMD4<Float>(0, 0, 0, 0), pn = SIMD4<Float>(0, 1, 1, 0), pt = SIMD4<Float>(1, 1, 0, 0.5)
    var pq = SIMD4<Float>(1, 1, 1, 0), pr = SIMD4<Float>(0, 0.1, 1, 0)
}

/// GPU copy of one GlbModel (loaded with GlbModel.cpuOnly).
final class MetalModel {
    struct P {
        var vbuf: MTLBuffer?
        var ibuf: MTLBuffer
        var count: Int
        var idx32: Bool
        var points: Bool
        var srcIndex: Int            // index into src.prims
        var tex: [MTLTexture?]       // base, metal-rough, emissive, occlusion
        var clamp: [Bool]
    }
    let src: GlbModel
    var splat: Splat?
    private(set) var prims: [P] = []
    var accel: MTLAccelerationStructure?

    init?(_ src: GlbModel, core: MetalCore) {
        self.src = src
        var texById: [UInt32: MTLTexture] = [:]
        var used: [UInt32] = []
        func tex(_ id: UInt32) -> (MTLTexture?, Bool) {
            guard id != 0, let e = GlbModel.cpuImages[id] else { return (nil, false) }
            used.append(id)
            if let t = texById[id] { return (t, e.clamp) }
            guard let t = MetalModel.makeTexture(core, e.img) else { return (nil, e.clamp) }
            texById[id] = t
            return (t, e.clamp)
        }
        for (si, sp) in src.prims.enumerated() {
            guard !sp.verts.isEmpty, !sp.cpuIdx.isEmpty else { continue }
            let idx32 = sp.indexType != GLenum(GL_UNSIGNED_SHORT)
            let ib: MTLBuffer?
            if idx32 {
                ib = sp.cpuIdx.withUnsafeBytes { core.device.makeBuffer(bytes: $0.baseAddress!, length: $0.count, options: .storageModeShared) }
            } else {
                let small = sp.cpuIdx.map { UInt16(truncatingIfNeeded: $0) }
                ib = small.withUnsafeBytes { core.device.makeBuffer(bytes: $0.baseAddress!, length: $0.count, options: .storageModeShared) }
            }
            guard let ibuf = ib else { continue }
            let t0 = tex(UInt32(sp.texBase)), t1 = tex(UInt32(sp.texMR)), t2 = tex(UInt32(sp.texEm)), t3 = tex(UInt32(sp.texOcc))
            prims.append(P(vbuf: nil, ibuf: ibuf, count: sp.cpuIdx.count, idx32: idx32,
                           points: sp.mode == GLenum(GL_POINTS), srcIndex: si,
                           tex: [t0.0, t1.0, t2.0, t3.0], clamp: [t0.1, t1.1, t2.1, t3.1]))
        }
        for id in used { GlbModel.cpuImages[id] = nil }       // CPU copies are no longer needed
        if prims.isEmpty { return nil }
    }

    /// RGBA8 premultiplied texture with a mip chain (GL generated mipmaps on ES3).
    static func makeTexture(_ core: MetalCore, _ image: UIImage) -> MTLTexture? {
        guard let cg = image.cgImage, cg.width > 0, cg.height > 0 else { return nil }
        let sc = min(1.0, 2048.0 / Double(max(cg.width, cg.height)))
        let w = max(1, Int(Double(cg.width) * sc)), h = max(1, Int(Double(cg.height) * sc))
        var data = [UInt8](repeating: 0, count: w * h * 4)
        let drew: Bool = data.withUnsafeMutableBytes { raw -> Bool in
            guard let ctx = CGContext(data: raw.baseAddress, width: w, height: h, bitsPerComponent: 8,
                                      bytesPerRow: w * 4, space: CGColorSpaceCreateDeviceRGB(),
                                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            ctx.setBlendMode(.copy)
            ctx.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h))
            return true
        }
        guard drew else { return nil }
        let d = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .rgba8Unorm, width: w, height: h, mipmapped: true)
        d.usage = .shaderRead
        d.storageMode = .shared
        guard let t = core.device.makeTexture(descriptor: d) else { return nil }
        data.withUnsafeBytes {
            t.replace(region: MTLRegionMake2D(0, 0, w, h), mipmapLevel: 0, withBytes: $0.baseAddress!, bytesPerRow: w * 4)
        }
        if t.mipmapLevelCount > 1, let cbuf = core.queue.makeCommandBuffer(), let blit = cbuf.makeBlitCommandEncoder() {
            blit.generateMipmaps(for: t)
            blit.endEncoding()
            cbuf.commit()
        }
        return t
    }
}

/// Draws model layers into a layer target with a shared depth buffer (GL drawModelLayer).
final class MetalModelRenderer {
    private let core: MetalCore
    private var lib: MTLLibrary?
    private var rtLib: MTLLibrary?
    /// "" when ray tracing is ready, else why it is not (shown in the 3D editor's Properties).
    static var rtStatus = ""
    private var psos: [String: MTLRenderPipelineState] = [:]
    private var dsWrite: MTLDepthStencilState?
    private var dsNoWrite: MTLDepthStencilState?
    private var smpRepeat: MTLSamplerState?
    private var smpClamp: MTLSamplerState?
    private var dummy: MTLTexture?
    private var depthTex: MTLTexture?
    private var cache: [String: MetalModel] = [:]
    private var failed = Set<String>()
    private var mapTex: [String: MTLTexture] = [:]                                  // imported PBR maps by file path
    private var subCache: [String: (vb: MTLBuffer, ib: MTLBuffer, count: Int)] = [:]   // subdivided meshes for displacement
    static var evictMapPaths = Set<String>()
    static func evictMaps(_ path: String) { evictMapPaths.insert(path) }

    private func mapTexture(_ path: String) -> MTLTexture? {
        if MetalModelRenderer.evictMapPaths.remove(path) != nil { mapTex[path] = nil }
        if let t = mapTex[path] { return t }
        guard let img = UIImage(contentsOfFile: path), let t = MetalModel.makeTexture(core, img) else { return nil }
        mapTex[path] = t
        return t
    }

    /// Midpoint subdivision (1 triangle -> 4) of an interleaved 12-float vertex list.
    static func subdivide(_ verts: [Float], _ idx: [UInt32], _ level: Int, maxTris: Int = 1_400_000) -> ([Float], [UInt32]) {
        var v = verts, ix = idx
        for _ in 0..<level {
            if ix.count / 3 * 4 > maxTris { break }
            var mid: [UInt64: UInt32] = [:]
            var out = [UInt32](); out.reserveCapacity(ix.count * 4)
            func midpoint(_ a: UInt32, _ b: UInt32) -> UInt32 {
                let key = a < b ? (UInt64(a) << 32 | UInt64(b)) : (UInt64(b) << 32 | UInt64(a))
                if let m = mid[key] { return m }
                let n = UInt32(v.count / 12), ia = Int(a) * 12, ib = Int(b) * 12
                var nv = [Float](repeating: 0, count: 12)
                for k in 0..<12 { nv[k] = (v[ia + k] + v[ib + k]) * 0.5 }
                let nl = (nv[3] * nv[3] + nv[4] * nv[4] + nv[5] * nv[5]).squareRoot()
                if nl > 1e-6 { nv[3] /= nl; nv[4] /= nl; nv[5] /= nl }
                v.append(contentsOf: nv); mid[key] = n
                return n
            }
            var t = 0
            while t + 2 < ix.count {
                let a = ix[t], b = ix[t + 1], c = ix[t + 2]
                let ab = midpoint(a, b), bc = midpoint(b, c), ca = midpoint(c, a)
                out.append(contentsOf: [a, ab, ca, ab, b, bc, ca, bc, c, ab, bc, ca])
                t += 3
            }
            ix = out
        }
        return (v, ix)
    }
    /// Paths whose texture files changed: dropped from the cache on the next load.
    static var evict = Set<String>()
    /// Cleared at frame start and per motion-blur sample: the next model draw clears the depth buffer.
    var depthDirty = true
    private var depthCopy: MTLTexture?
    private var dummyDepthT: MTLTexture?
    private var dsAlways: MTLDepthStencilState?

    init(_ core: MetalCore) {
        self.core = core
        lib = try? core.device.makeLibrary(source: MetalModelSL.source, options: nil)
        if !core.device.supportsRaytracing { MetalModelRenderer.rtStatus = "This device's GPU has no hardware ray tracing (needs A13 or newer)." }
        else {
            let o = MTLCompileOptions()
            if #available(iOS 15.0, *) { o.languageVersion = .version2_4 } else { o.languageVersion = .version2_3 }
            do { rtLib = try core.device.makeLibrary(source: MetalModelSL.rtSource, options: o); MetalModelRenderer.rtStatus = "" }
            catch { MetalModelRenderer.rtStatus = "Ray tracing shader failed: \(error.localizedDescription)" }
        }
        let dw = MTLDepthStencilDescriptor()
        dw.depthCompareFunction = .lessEqual; dw.isDepthWriteEnabled = true
        dsWrite = core.device.makeDepthStencilState(descriptor: dw)
        let dn = MTLDepthStencilDescriptor()
        dn.depthCompareFunction = .lessEqual; dn.isDepthWriteEnabled = false
        dsNoWrite = core.device.makeDepthStencilState(descriptor: dn)
        func sampler(_ clamp: Bool) -> MTLSamplerState? {
            let d = MTLSamplerDescriptor()
            d.minFilter = .linear; d.magFilter = .linear; d.mipFilter = .linear
            d.sAddressMode = clamp ? .clampToEdge : .repeat
            d.tAddressMode = clamp ? .clampToEdge : .repeat
            d.maxAnisotropy = 4
            return core.device.makeSamplerState(descriptor: d)
        }
        smpRepeat = sampler(false); smpClamp = sampler(true)
        let td = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .rgba8Unorm, width: 1, height: 1, mipmapped: false)
        td.usage = .shaderRead
        dummy = core.device.makeTexture(descriptor: td)
        var px: [UInt8] = [255, 255, 255, 255]
        dummy?.replace(region: MTLRegionMake2D(0, 0, 1, 1), mipmapLevel: 0, withBytes: &px, bytesPerRow: 4)
    }

    var ready: Bool { lib != nil && dsWrite != nil && dsNoWrite != nil && smpRepeat != nil && smpClamp != nil && dummy != nil }

    func trimMemory() { cache.removeAll(); depthTex = nil; mapTex.removeAll(); subCache.removeAll() }

    /// The shared depth buffer when a model has drawn since the last clear (volume occlusion), else nil.
    func occlusionDepth() -> MTLTexture? { depthDirty ? nil : depthTex }

    private func loadModel(for path: String) -> MetalModel? {
        if MetalModelRenderer.evict.remove(path) != nil { cache[path] = nil; failed.remove(path) }
        if let m = cache[path] { return m }
        if failed.contains(path) { return nil }
        let p = GlbModel.validate(path: path)
        GlbModel.cpuOnly = true
        defer { GlbModel.cpuOnly = false }
        guard let g = GlbModel.load(p), let m = MetalModel(g, core: core) else {
            failed.insert(path)
            return nil
        }
        m.splat = Splat.load(p, core: core, dummy: dummy)
        cache[path] = m
        cache[p] = m
        return m
    }

    private func pso(blend: Bool, format: MTLPixelFormat, rt: Bool = false) -> MTLRenderPipelineState? {
        let key = "\(blend)/\(format.rawValue)/\(rt)"
        if let p = psos[key] { return p }
        guard let lib = rt ? rtLib : lib, let vf = lib.makeFunction(name: "modelVertex"),
              let ff = lib.makeFunction(name: rt ? "modelFragmentRT" : "modelFragment") else { return nil }
        let d = MTLRenderPipelineDescriptor()
        d.vertexFunction = vf
        d.fragmentFunction = ff
        d.colorAttachments[0].pixelFormat = format
        d.depthAttachmentPixelFormat = .depth32Float
        if blend {
            let c = d.colorAttachments[0]!
            c.isBlendingEnabled = true
            c.sourceRGBBlendFactor = .one; c.destinationRGBBlendFactor = .oneMinusSourceAlpha
            c.sourceAlphaBlendFactor = .one; c.destinationAlphaBlendFactor = .oneMinusSourceAlpha
        }
        guard let p = try? core.device.makeRenderPipelineState(descriptor: d) else { return nil }
        psos[key] = p
        return p
    }

    private func depth(_ w: Int, _ h: Int) -> MTLTexture? {
        if let t = depthTex, t.width == w, t.height == h { return t }
        let d = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .depth32Float, width: w, height: h, mipmapped: false)
        d.usage = [.renderTarget, .shaderRead]
        d.storageMode = .private
        depthTex = core.device.makeTexture(descriptor: d)
        depthDirty = true
        return depthTex
    }

    private func buildAccel(_ model: MetalModel, vbufs: [MTLBuffer?], cb: MTLCommandBuffer) -> MTLAccelerationStructure? {
        var geos: [MTLAccelerationStructureTriangleGeometryDescriptor] = []
        for (i, p) in model.prims.enumerated() where !p.points && i < vbufs.count {
            guard let vb = vbufs[i], p.count >= 3 else { continue }
            let g = MTLAccelerationStructureTriangleGeometryDescriptor()
            g.vertexBuffer = vb; g.vertexStride = 48
            g.indexBuffer = p.ibuf; g.indexType = p.idx32 ? .uint32 : .uint16
            g.triangleCount = p.count / 3
            g.opaque = true
            geos.append(g)
        }
        if geos.isEmpty { return nil }
        let d = MTLPrimitiveAccelerationStructureDescriptor()
        d.geometryDescriptors = geos
        let sz = core.device.accelerationStructureSizes(descriptor: d)
        guard let acc = core.device.makeAccelerationStructure(size: sz.accelerationStructureSize),
              let scratch = core.device.makeBuffer(length: max(sz.buildScratchBufferSize, 16), options: .storageModePrivate),
              let e = cb.makeAccelerationStructureCommandEncoder() else { return nil }
        e.build(accelerationStructure: acc, descriptor: d, scratchBuffer: scratch, scratchBufferOffset: 0)
        e.endEncoding()
        return acc
    }

    /// Draws model layer `l` (glb / gltf / obj / abc) into `target` (which the caller has cleared).
    func draw(_ l: Layer, time: Float, fov: Float, into target: MetalTarget, cb: MTLCommandBuffer, sceneTex: MTLTexture? = nil) {
        guard ready, let path = l.imagePath, let model = loadModel(for: path),
              let dtex = depth(target.width, target.height) else { return }
        model.src.setAnimTime(max(0, time - l.start))
        let vp = MetalCam.vpForModel(l, fov: fov, time: time, width: target.width, height: target.height)
        let mm = MetalCam.modelMatrix(l, time: time, normalize: model.src.normalize)
        let eye = GlbModel.eye(fromVP: vp)
        guard vp.count == 16, mm.count == 16 else { return }
        let isWater = l.xf("water", 0) > 0.5
        guard let dummyD = dummyDepth() else { return }
        var depthSrc: MTLTexture = dummyD
        var hasDepth: Float = 0
        if isWater, sceneTex != nil, !depthDirty, let dc = depthCopyTex(target.width, target.height), let bl = cb.makeBlitCommandEncoder() {
            // snapshot of the depth every earlier layer wrote: the water reads it to know how deep each thing below it is
            bl.copy(from: dtex, sourceSlice: 0, sourceLevel: 0, sourceOrigin: MTLOrigin(x: 0, y: 0, z: 0),
                    sourceSize: MTLSize(width: dtex.width, height: dtex.height, depth: 1),
                    to: dc, destinationSlice: 0, destinationLevel: 0, destinationOrigin: MTLOrigin(x: 0, y: 0, z: 0))
            bl.endEncoding()
            depthSrc = dc; hasDepth = 1
        }

        var base = ModelU()
        base.vp0 = SIMD4(vp[0], vp[1], vp[2], vp[3]); base.vp1 = SIMD4(vp[4], vp[5], vp[6], vp[7])
        base.vp2 = SIMD4(vp[8], vp[9], vp[10], vp[11]); base.vp3 = SIMD4(vp[12], vp[13], vp[14], vp[15])
        base.m0 = SIMD4(mm[0], mm[1], mm[2], mm[3]); base.m1 = SIMD4(mm[4], mm[5], mm[6], mm[7])
        base.m2 = SIMD4(mm[8], mm[9], mm[10], mm[11]); base.m3 = SIMD4(mm[12], mm[13], mm[14], mm[15])
        base.eye = SIMD4(eye[0], eye[1], eye[2], l.xf("light", 1) * R3D.g("light", 1))
        var lpos: [SIMD4<Float>] = [], lcol: [SIMD4<Float>] = []
        for L in Editor.scene.layers where L.isLight && L.xf("lightType", 0) < 0.5 && L.visible && time >= L.start && time <= L.end && lpos.count < 3 {
            let lt = L.editTime("x", time), c = UInt32(bitPattern: L.vdbTint), k = L.xf("lightInt", 1)
            lpos.append(SIMD4(L.p("x", lt), L.p("y", lt), Xf.worldZ(L, time), 0))
            lcol.append(SIMD4(Float((c >> 16) & 255) / 255 * k, Float((c >> 8) & 255) / 255 * k, Float(c & 255) / 255 * k, 1))
        }
        while lpos.count < 3 { lpos.append(.zero); lcol.append(.zero) }
        let lightBuf = Lights.buffer(time: time)
        base.pr.w = Float(lightBuf.count)
        base.lp0 = lpos[0]; base.lp1 = lpos[1]; base.lp2 = lpos[2]; base.lc0 = lcol[0]; base.lc1 = lcol[1]; base.lc2 = lcol[2]
        base.opt = SIMD4(l.m3Env ? 1 : 0, l.m3Metal ? 1 : 0, Float(l.m3View), l.m3Ao ? 1 : 0)
        _ = GlobalEnv.tex(core); base.envp = GlobalEnv.uniform
        if let sp = model.splat { base.sp0 = SIMD4(1, Float(sp.count), 0, 0); base.sp1 = sp.tile; base.sp2 = sp.str }

        let animated = model.src.isAnimated
        var vbufs: [MTLBuffer?] = []
        for (i, p) in model.prims.enumerated() {
            guard p.srcIndex < model.src.prims.count else { vbufs.append(nil); continue }
            let sp = model.src.prims[p.srcIndex]
            var vbuf = p.vbuf
            if vbuf == nil || (animated && sp.slot >= 0) {
                vbuf = sp.verts.withUnsafeBytes { core.device.makeBuffer(bytes: $0.baseAddress!, length: $0.count, options: .storageModeShared) }
            }
            if let vb = vbuf, p.vbuf == nil && !(animated && sp.slot >= 0) { model.setVBuf(i, vb) }
            vbufs.append(vbuf)
        }
        // ray tracing: this layer's own switch, or the active camera's
        var rtI: Float = l.rtOn ? l.rtInt : 0
        var rtR: Float = l.rtRad
        if let cam = Xf.camera(for: l), cam.rtOn { rtI = max(rtI, cam.rtInt); rtR = cam.rtRad }
        if R3D.g("rtAll", 0) > 0.5 { rtI = max(rtI, R3D.g("rtMul", 1)) }
        base.xtra = SIMD4(l.xf("exposure", 1) * R3D.g("exposure", 1), min(rtI * l.xf("rtAo", 1), 1), min(rtI * l.xf("rtShadow", 1), 1), l.xf("pbrNorm", 0))
        let pgOn = l.xf("pgOn", 0) > 0.5, sRatio = pgOn ? max(l.p("scale", time) / max(l.xf("pgRef", 1), 1e-4), 1e-3) : 1
        base.pg = SIMD4(pgOn ? 1 : 0, min(l.xf("pbrPom", 0), 0.06), sRatio, sRatio)
        base.wa = SIMD4(l.xf("water", 0), time, l.xf("wAmp", 0.03), l.xf("wFreq", 6))
        base.wb = SIMD4(l.xf("wSpeed", 1), l.xf("wFoam", 0.5), l.xf("wDepth", 0.5), l.xf("wChop", 0.5))
        base.wc = SIMD4(l.xf("wClar", 0.6), l.xf("wTurb", 0.15), l.xf("wRefr", 0.5), l.xf("wSss", 0.5))
        base.wd = SIMD4(l.xf("wGlint", 1), l.xf("wDetail", 0.6), l.xf("wDir", 30) * Float.pi / 180, l.xf("wSeabed", 0.7))
        base.we = SIMD4(l.xf("wVar", 0.7), l.xf("wSwell", 0.8), l.xf("wSwellLen", 0.15), l.xf("wCaps", 0.5))
        base.wf = SIMD4(mm[13], l.xf("wRefl", 0) > 0.5 ? 1 : 0, hasDepth, l.xf("wRays", 0) > 0.5 ? 1 : 0)
        base.wg = SIMD4(l.xf("wRayStr", 1), l.xf("wRayLen", 1), l.xf("wRayWid", 1), l.xf("wRaySpd", 1))
        base.wh = l.xf("wColl", 0) > 0.5 ? SIMD4(l.xf("wCollRock", 1) > 0.5 ? 1 : 0, l.xf("wCollShore", 1) > 0.5 ? 1 : 0, l.xf("wFoamW", 0.4), 0) : SIMD4(0, 0, 0.4, 0)
        // imported PBR maps (Properties > PBR material): drive the shader + real displacement
        var pbrTex: [String: MTLTexture] = [:]
        if !isWater { for (k, pth) in l.pbrMaps { if let t = mapTexture(pth) { pbrTex[k] = t } } }
        let pbrOn = !pbrTex.isEmpty
        var subLevel = 0
        if pbrOn {
            let tile = max(l.xf("pbrTile", 1), 0.01)
            let hasH = pbrTex["height"] != nil
            base.pm = SIMD4(pbrTex["normal"] != nil ? 1 : 0, pbrTex["rough"] != nil ? 1 : 0, pbrTex["metal"] != nil ? 1 : 0, hasH ? 1 : 0)
            base.pn = SIMD4(pbrTex["opacity"] != nil ? 1 : 0, l.xf("pbrNStr", 1), l.xf("pbrFlip", 0) > 0.5 ? -1 : 1, hasH ? l.xf("pbrDisp", 0.05) : 0)
            base.pt = SIMD4(tile, tile, hasH ? l.xf("pbrPar", 0.03) : 0, l.xf("pbrMid", 0.5))
            base.pq = SIMD4(l.xf("pbrRough", 1), l.xf("pbrMetal", 1), l.xf("pbrEm", 1), 1)
            base.pr.x = l.xf("pbrCoat", 0); base.pr.y = l.xf("pbrCoatR", 0.1); base.pr.z = l.xf("pbrAo", 1)
            if hasH && l.xf("pbrDisp", 0.05) != 0 { subLevel = max(0, min(4, Int(l.xf("pbrSub", 2).rounded()))) }
        }
        var accel: MTLAccelerationStructure? = nil
        if rtI > 0.001, rtLib != nil {
            if animated || model.accel == nil { model.accel = buildAccel(model, vbufs: vbufs, cb: cb) }
            accel = model.accel
        }
        let m4 = simd_float4x4(SIMD4(mm[0], mm[1], mm[2], mm[3]), SIMD4(mm[4], mm[5], mm[6], mm[7]),
                               SIMD4(mm[8], mm[9], mm[10], mm[11]), SIMD4(mm[12], mm[13], mm[14], mm[15]))
        var invM = m4.inverse
        var rtp = SIMD4<Float>(min(rtI, 1), rtR, 0, 0)

        let pd = MTLRenderPassDescriptor()
        pd.colorAttachments[0].texture = target.tex
        pd.colorAttachments[0].loadAction = .load
        pd.colorAttachments[0].storeAction = .store
        pd.depthAttachment.texture = dtex
        pd.depthAttachment.loadAction = depthDirty ? .clear : .load
        pd.depthAttachment.clearDepth = 1
        pd.depthAttachment.storeAction = .store
        depthDirty = false
        guard let enc = cb.makeRenderCommandEncoder(descriptor: pd) else { return }
        enc.setCullMode(.none)

        if let a = accel { enc.useResource(a, usage: .read) }
        enc.setFragmentTexture(depthSrc, index: 4)
        enc.setFragmentTexture(sceneTex ?? dummy, index: 5)
        enc.setFragmentTexture(GlobalEnv.cached ?? dummy, index: 6)
        enc.setFragmentTextures(model.splat?.tex ?? [MTLTexture?](repeating: dummy, count: 14), range: 7..<21)
        for (i, k) in ["normal", "rough", "metal", "height", "opacity"].enumerated() { enc.setFragmentTexture(pbrTex[k] ?? dummy, index: 21 + i) }
        enc.setVertexTexture(pbrTex["height"] ?? dummy, index: 0)
        lightBuf.data.withUnsafeBytes { enc.setFragmentBytes($0.baseAddress!, length: $0.count, index: 5) }
        if isWater, eye[1] < mm[13], let up = psoUnder(format: target.tex.pixelFormat), let ds = dsAlwaysState() {
            // camera below the surface (any camera, also the editing one): the whole picture is seen through the water
            var uu = base
            if let sp0 = model.src.prims.first { uu.color = SIMD4(sp0.color[0], sp0.color[1], sp0.color[2], sp0.color[3]) }
            var inv = simd_float4x4(SIMD4(vp[0], vp[1], vp[2], vp[3]), SIMD4(vp[4], vp[5], vp[6], vp[7]),
                                    SIMD4(vp[8], vp[9], vp[10], vp[11]), SIMD4(vp[12], vp[13], vp[14], vp[15])).inverse
            enc.setRenderPipelineState(up)
            enc.setDepthStencilState(ds)
            enc.setFragmentBytes(&uu, length: MemoryLayout<ModelU>.stride, index: 0)
            enc.setFragmentBytes(&inv, length: 64, index: 1)
            enc.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 3)
        }
        var instMs: [simd_float4x4] = [m4]
        if let sc = scatterMatrices(l, model: model, time: time, w: target.width, h: target.height) { instMs = sc }
        for (i, p) in model.prims.enumerated() where p.srcIndex < model.src.prims.count {
            let sp = model.src.prims[p.srcIndex]
            let rtPS = accel != nil ? pso(blend: sp.blend, format: target.tex.pixelFormat, rt: true) : nil
            guard let ps = rtPS ?? pso(blend: sp.blend, format: target.tex.pixelFormat) else { continue }
            guard i < vbufs.count, let vb = vbufs[i] else { continue }

            var u = base
            u.color = SIMD4(sp.color[0], sp.color[1], sp.color[2], sp.color[3])
            u.emis = SIMD4(sp.emissive[0], sp.emissive[1], sp.emissive[2], l.xf("env", 1) * R3D.g("env", 1))
            u.prm = SIMD4(sp.metal, sp.rough, sp.cutoff, sp.unlit)
            var ptex = p.tex, pclamp = p.clamp
            if pbrOn {      // imported maps replace the model's own base colour / emissive / occlusion textures
                if let t = pbrTex["albedo"] { ptex[0] = t; pclamp[0] = false }
                if let t = pbrTex["emissive"] { ptex[2] = t; pclamp[2] = false }
                if let t = pbrTex["ao"] { ptex[3] = t; pclamp[3] = false }
            }
            u.has = SIMD4(ptex[0] != nil ? 1 : 0, ptex[1] != nil ? 1 : 0, ptex[2] != nil ? 1 : 0, ptex[3] != nil ? 1 : 0)
            var useVB = vb, useIB = p.ibuf, useCount = p.count, use32 = p.idx32
            if subLevel > 0, !p.points, !animated, accel == nil, let ip = l.imagePath {
                let key = "\(ip)#\(p.srcIndex)#\(subLevel)"
                if subCache[key] == nil {
                    let (v2, i2) = MetalModelRenderer.subdivide(sp.verts, sp.cpuIdx, subLevel)
                    if let vb2 = v2.withUnsafeBytes({ core.device.makeBuffer(bytes: $0.baseAddress!, length: $0.count, options: .storageModeShared) }),
                       let ib2 = i2.withUnsafeBytes({ core.device.makeBuffer(bytes: $0.baseAddress!, length: $0.count, options: .storageModeShared) }) {
                        subCache[key] = (vb2, ib2, i2.count)
                    }
                }
                if let sc = subCache[key] { useVB = sc.vb; useIB = sc.ib; useCount = sc.count; use32 = true }
            }
            enc.setRenderPipelineState(ps)
            enc.setDepthStencilState((sp.blend && !isWater) ? dsNoWrite : dsWrite)
            enc.setVertexBuffer(useVB, offset: 0, index: 1)
            if rtPS != nil, let a = accel { enc.setFragmentAccelerationStructure(a, bufferIndex: 2); enc.setFragmentBytes(&rtp, length: 16, index: 3) }
            for k in 0..<4 {
                enc.setFragmentTexture(ptex[k] ?? dummy, index: k)
                enc.setFragmentSamplerState(pclamp[k] ? smpClamp : smpRepeat, index: k)
            }
            for im in instMs {          // only the matrices change per instance; state above is set once per primitive
            u.m0 = im.columns.0; u.m1 = im.columns.1; u.m2 = im.columns.2; u.m3 = im.columns.3
            enc.setVertexBytes(&u, length: MemoryLayout<ModelU>.stride, index: 0)
            enc.setFragmentBytes(&u, length: MemoryLayout<ModelU>.stride, index: 0)
            if rtPS != nil { invM = im.inverse; enc.setFragmentBytes(&invM, length: 64, index: 4) }
            enc.drawIndexedPrimitives(type: p.points ? .point : .triangle, indexCount: useCount,
                                      indexType: use32 ? .uint32 : .uint16, indexBuffer: useIB, indexBufferOffset: 0)
            }
        }
        enc.endEncoding()
    }

    /// Scatter: raw world instance matrices for layer `l` (no model normalisation), or nil = not scattering.
    func scatterWorld(_ l: Layer, time: Float) -> [simd_float4x4]? {
        guard l.xf("scOn", 0) > 0.5 else { return nil }
        let tid = Int(l.xf("scTarget", -1))
        func f4(_ m: [Float]) -> simd_float4x4 { simd_float4x4(SIMD4(m[0], m[1], m[2], m[3]), SIMD4(m[4], m[5], m[6], m[7]), SIMD4(m[8], m[9], m[10], m[11]), SIMD4(m[12], m[13], m[14], m[15])) }
        var tris: [Scatter.Tri], tm: simd_float4x4, tl: Layer = l
        if tid == -2 || tid == -3 {
            tris = Scatter.ground(l.xf("scGroundSize", 10), l.xf("scGroundY", 0)); tm = matrix_identity_float4x4
        } else {
            guard tid != l.id, let t = Editor.scene.layers.first(where: { $0.id == tid }) else { return nil }
            tl = t
            if tl.type == .MODEL {
                guard let tp = tl.imagePath, !tp.lowercased().hasSuffix(".vdb"), let t0 = loadModel(for: tp) else { return nil }
                let mm = MetalCam.modelMatrix(tl, time: time, normalize: t0.src.normalize)
                guard mm.count == 16 else { return nil }
                tris = Scatter.tris(t0.src); tm = f4(mm)
            } else {
                let (w, h) = Xf.quadSize(tl)
                let mm = MetalCam.modelMatrix(tl, time: time, normalize: [1, 0, 0, 0])
                guard mm.count == 16 else { return nil }
                tris = Scatter.quad(w, h); tm = f4(mm)
            }
        }
        return Scatter.instances(l, target: tl, tris: tris, targetM: tm, time: time)
    }

    /// Scatter: instance matrices (already including this model's normalisation), or nil = draw normally.
    private func scatterMatrices(_ l: Layer, model: MetalModel, time: Float, w: Int, h: Int) -> [simd_float4x4]? {
        guard var inst = scatterWorld(l, time: time) else { return nil }
        func f4(_ m: [Float]) -> simd_float4x4 { simd_float4x4(SIMD4(m[0], m[1], m[2], m[3]), SIMD4(m[4], m[5], m[6], m[7]), SIMD4(m[8], m[9], m[10], m[11]), SIMD4(m[12], m[13], m[14], m[15])) }
        let n = model.src.normalize
        var N = simd_float4x4(diagonal: SIMD4(n[0], n[0], n[0], 1))
        N.columns.3 = SIMD4(n[0] * n[1], n[0] * n[2] - model.src.baseY * l.xf("scSit", 1), n[0] * n[3], 1)       // S(n0) · T(offset); base rests on the surface
        inst = inst.map { $0 * N }
        // cull instances outside the view (big saving with thousands of trees / rocks)
        if inst.count > 12 {
            let vp = MetalCam.vpForModel(l, fov: Editor.scene.fov, time: time, width: w, height: h)
            if vp.count == 16 {
                inst = inst.filter { m in
                    let p = m.columns.3
                    let cw = vp[3] * p.x + vp[7] * p.y + vp[11] * p.z + vp[15]
                    if cw <= 0.01 { return false }
                    let cx = vp[0] * p.x + vp[4] * p.y + vp[8] * p.z + vp[12], cy = vp[1] * p.x + vp[5] * p.y + vp[9] * p.z + vp[13]
                    let r = max(simd_length(SIMD3(m.columns.1.x, m.columns.1.y, m.columns.1.z)), 0.05) * 1.6 * abs(vp[0]) // generous radius
                    return abs(cx) < cw * 1.4 + r && abs(cy) < cw * 1.4 + r
                }
            }
            if inst.count > 1500 { inst = Array(inst.prefix(1500)) }
        }
        if l.xf("scKeep", 0) > 0.5 { inst.append(f4(MetalCam.modelMatrix(l, time: time, normalize: model.src.normalize))) }
        return inst
    }
}

extension MetalModel {
    /// Caches the static vertex buffer of prim `i`.
    func setVBuf(_ i: Int, _ b: MTLBuffer) {
        guard i < prims.count else { return }
        prims[i].vbuf = b
    }
}

extension MetalModelRenderer {
    fileprivate func depthCopyTex(_ w: Int, _ h: Int) -> MTLTexture? {
        if let t = depthCopy, t.width == w, t.height == h { return t }
        let d = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .depth32Float, width: w, height: h, mipmapped: false)
        d.usage = .shaderRead; d.storageMode = .private
        depthCopy = core.device.makeTexture(descriptor: d)
        return depthCopy
    }
    fileprivate func dummyDepth() -> MTLTexture? {
        if let t = dummyDepthT { return t }
        let d = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .depth32Float, width: 1, height: 1, mipmapped: false)
        d.usage = .shaderRead; d.storageMode = .private
        dummyDepthT = core.device.makeTexture(descriptor: d)
        return dummyDepthT
    }
    private struct PlOccU { var inv = matrix_identity_float4x4, vp = matrix_identity_float4x4; var p0 = SIMD4<Float>(0, 0, 0, 1), n = SIMD4<Float>(0, 0, 1, 0), flags = SIMD4<Float>(0, 0, 0, 0) }

    /// 3D media plane vs models: cuts `src` by the model depth buffer (per pixel, analytic plane depth) into `dst`,
    /// then writes the plane's own depth so models drawn after it hide behind it. Returns false when it could not run.
    func occludePlane(_ l: Layer, time: Float, src: MetalTarget, dst: MetalTarget, cb: MTLCommandBuffer) -> Bool {
        guard ready, let lib = lib, let dtex = depth(src.width, src.height), let dw = dsWrite,
              dst.tex !== src.tex, dst.width == src.width, dst.height == src.height else { return false }
        let fmt = dst.tex.pixelFormat
        func pipe(_ key: String, _ ff: String, color: Bool) -> MTLRenderPipelineState? {
            if let p = psos[key] { return p }
            guard let vf = lib.makeFunction(name: "waterUnderV"), let fn = lib.makeFunction(name: ff) else { return nil }
            let d = MTLRenderPipelineDescriptor(); d.vertexFunction = vf; d.fragmentFunction = fn
            if color { d.colorAttachments[0].pixelFormat = fmt } else { d.depthAttachmentPixelFormat = .depth32Float }
            guard let p = try? core.device.makeRenderPipelineState(descriptor: d) else { return nil }
            psos[key] = p; return p
        }
        guard let p1 = pipe("plocc/\(fmt.rawValue)", "planeOccF", color: true), let p2 = pipe("pldep", "planeDepthF", color: false) else { return false }
        let vpA = MetalCam.vpForModel(l, fov: Editor.scene.fov, time: time, width: src.width, height: src.height)
        guard vpA.count == 16 else { return false }
        let vpM = simd_float4x4(SIMD4(vpA[0], vpA[1], vpA[2], vpA[3]), SIMD4(vpA[4], vpA[5], vpA[6], vpA[7]),
                                SIMD4(vpA[8], vpA[9], vpA[10], vpA[11]), SIMD4(vpA[12], vpA[13], vpA[14], vpA[15]))
        let lt = l.editTime("x", time)
        func rot(_ deg: Float, _ ax: simd_float3) -> simd_float4x4 { simd_float4x4(simd_quatf(angle: deg * .pi / 180, axis: ax)) }
        let r = rot(l.p("rotZ", lt), simd_float3(0, 0, 1)) * rot(l.p("rotX", lt), simd_float3(1, 0, 0)) * rot(l.p("rotY", lt), simd_float3(0, 1, 0))
        let n = r * SIMD4<Float>(0, 0, 1, 0)
        var u = PlOccU()
        u.vp = vpM; u.inv = vpM.inverse
        u.p0 = SIMD4(l.p("x", lt), l.p("y", lt), Xf.worldZ(l, time), 1)
        u.n = SIMD4(n.x, n.y, n.z, 0)
        u.flags = SIMD4(depthDirty ? 0 : 1, 0, 0, 0)
        // 1) colour: cut by nearer model pixels
        let pc = MTLRenderPassDescriptor()
        pc.colorAttachments[0].texture = dst.tex; pc.colorAttachments[0].loadAction = .dontCare; pc.colorAttachments[0].storeAction = .store
        guard let e1 = cb.makeRenderCommandEncoder(descriptor: pc) else { return false }
        e1.setRenderPipelineState(p1)
        e1.setFragmentBytes(&u, length: MemoryLayout<PlOccU>.stride, index: 0)
        e1.setFragmentTexture(src.tex, index: 0); e1.setFragmentTexture(dtex, index: 4)
        e1.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 3); e1.endEncoding()
        // 2) depth: the plane's visible pixels become occluders for models drawn later
        let pd = MTLRenderPassDescriptor()
        pd.depthAttachment.texture = dtex; pd.depthAttachment.loadAction = depthDirty ? .clear : .load
        pd.depthAttachment.clearDepth = 1; pd.depthAttachment.storeAction = .store
        depthDirty = false
        guard let e2 = cb.makeRenderCommandEncoder(descriptor: pd) else { return true }
        e2.setRenderPipelineState(p2); e2.setDepthStencilState(dw)
        e2.setFragmentBytes(&u, length: MemoryLayout<PlOccU>.stride, index: 0)
        e2.setFragmentTexture(dst.tex, index: 0)
        e2.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 3); e2.endEncoding()
        return true
    }

    fileprivate func dsAlwaysState() -> MTLDepthStencilState? {
        if let s = dsAlways { return s }
        let d = MTLDepthStencilDescriptor()
        d.depthCompareFunction = .always; d.isDepthWriteEnabled = false
        dsAlways = core.device.makeDepthStencilState(descriptor: d)
        return dsAlways
    }
    fileprivate func psoUnder(format: MTLPixelFormat) -> MTLRenderPipelineState? {
        let key = "under/\(format.rawValue)"
        if let p = psos[key] { return p }
        guard let lib = lib, let vf = lib.makeFunction(name: "waterUnderV"), let ff = lib.makeFunction(name: "waterUnderF") else { return nil }
        let d = MTLRenderPipelineDescriptor()
        d.vertexFunction = vf; d.fragmentFunction = ff
        d.colorAttachments[0].pixelFormat = format
        d.depthAttachmentPixelFormat = .depth32Float
        guard let p = try? core.device.makeRenderPipelineState(descriptor: d) else { return nil }
        psos[key] = p
        return p
    }
}


/// Terrain splat data embedded in the GLB (asset.extras.splat): weight maps + per-layer diffuse / normal+AO / height+rough+metal images.
final class Splat {
    var tex: [MTLTexture?] = []          // 7..10 diffuse, 11..14 normal+ao, 15..18 height/rough/metal, 19..20 weights
    var tile = SIMD4<Float>(1, 1, 1, 1), str = SIMD4<Float>(1, 1, 1, 1), count = 0
    static func load(_ path: String, core: MetalCore, dummy: MTLTexture?) -> Splat? {
        guard let data = try? Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe), data.count > 28 else { return nil }
        func u32(_ o: Int) -> Int { Int(data[o]) | Int(data[o + 1]) << 8 | Int(data[o + 2]) << 16 | Int(data[o + 3]) << 24 }
        let jl = u32(12)
        guard 20 + jl <= data.count, let j = (try? JSONSerialization.jsonObject(with: data.subdata(in: 20..<(20 + jl)))) as? [String: Any],
              let sp = ((j["asset"] as? [String: Any])?["extras"] as? [String: Any])?["splat"] as? [String: Any],
              let views = j["bufferViews"] as? [[String: Any]], let layers = sp["layers"] as? [[String: Any]] else { return nil }
        let bin = 20 + jl + 8
        func img(_ i: Any?) -> MTLTexture? {
            guard let i = i as? Int, i < views.count, let o = views[i]["byteOffset"] as? Int, let l = views[i]["byteLength"] as? Int,
                  bin + o + l <= data.count, let ui = UIImage(data: data.subdata(in: (bin + o)..<(bin + o + l))) else { return nil }
            return MetalModel.makeTexture(core, ui)
        }
        let r = Splat()
        var d: [MTLTexture?] = [], n: [MTLTexture?] = [], h: [MTLTexture?] = []
        for k in 0..<4 {
            if k < layers.count {
                d.append(img(layers[k]["d"]) ?? dummy); n.append(img(layers[k]["n"]) ?? dummy); h.append(img(layers[k]["r"]) ?? dummy)
                r.tile[k] = (layers[k]["tile"] as? NSNumber)?.floatValue ?? 1; r.str[k] = (layers[k]["str"] as? NSNumber)?.floatValue ?? 1
            } else { d.append(dummy); n.append(dummy); h.append(dummy) }
        }
        r.count = min(4, layers.count)
        r.tex = d + n + h + [img(sp["w0"]) ?? dummy, img(sp["w1"]) ?? dummy]
        return r.count > 0 ? r : nil
    }
}
