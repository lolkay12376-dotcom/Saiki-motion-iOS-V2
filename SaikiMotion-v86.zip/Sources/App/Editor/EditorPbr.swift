// EditorPbr.swift — the PBR material panel: every map is imported as its own file and drives the shader.
//
//   Base colour / Normal / Roughness / Metallic / Ambient occlusion / Height / Emissive / Opacity
//
// Height is used three ways: real vertex displacement of a subdivided mesh (actual 3D relief, silhouettes
// change), parallax occlusion mapping for the fine detail between the vertices, and a self-shadow march.

import UIKit
import UniformTypeIdentifiers

enum PBRMaps {
    static let keys: [(key: String, label: String)] = [
        ("albedo", "Base colour"), ("normal", "Normal"), ("rough", "Roughness"), ("metal", "Metallic"),
        ("ao", "Ambient occlusion"), ("height", "Height / displacement"), ("emissive", "Emissive"), ("opacity", "Opacity")]

    /// Maps a file name such as "brick_diff_2k.jpg" or "Rock_Normal_GL.png" to a slot ("" = unknown).
    static func guessKey(_ file: String) -> String {
        let n = file.lowercased()
        func has(_ a: [String]) -> Bool { a.contains { n.contains($0) } }
        if has(["normal", "_nor", "-nor", "_nrm", "norm"]) { return "normal" }
        if has(["rough"]) { return "rough" }
        if has(["metal", "_met", "metalness"]) { return "metal" }
        if has(["_ao", "-ao", "ambient", "occlusion", "_occ"]) { return "ao" }
        if has(["height", "displ", "_disp", "_dsp", "bump"]) { return "height" }
        if has(["emiss", "emit", "_glow"]) { return "emissive" }
        if has(["opacity", "alpha", "_mask", "transparen"]) { return "opacity" }
        if has(["albedo", "diff", "basecolor", "base_color", "base-color", "color", "colour", "_col", "_alb"]) { return "albedo" }
        return ""
    }
}

extension EditorViewController {
    func buildPbr(_ p: UIStackView, _ l: Layer) {
        guard l.type == .MODEL, l.xf("water", 0) < 0.5 else { return }
        func xs(_ label: String, _ lo: Float, _ hi: Float, _ key: String, _ def: Float, _ dec: Int = 2) {
            let r = RulerSlider(frame: .zero); r.label = label; r.lo = lo; r.hi = hi; r.dec = dec; r.value = l.xf(key, def)
            r.onBegin = { [weak self] in self?.pushUndo() }
            r.onChange = { [weak self] v in l.xset(key, v); self?.render() }
            put(p, r, 90)
        }
        func sw(_ label: String, _ key: String, _ def: Float = 0) {
            let s = SwitchRow(); s.label = label; s.on = l.xf(key, def) > 0.5
            s.onToggle = { [weak self] v in self?.pushUndo(); l.xset(key, v ? 1 : 0); self?.render() }
            put(p, s, 46)
        }
        text(p, "PBR material (imported maps)", C.TEXT, 14, true)
        text(p, "Import every map from a material. Names like albedo / normal / roughness / metallic / ao / height / emissive / opacity are recognised automatically.", C.DIM, 12)
        put(p, pill("Import all maps (pick several files)", "import") { [weak self] in
            gPbrKey = ""; self?.pickFile(R_PBRALL, [.image])
        }, 44)
        for (key, label) in PBRMaps.keys {
            let have = l.pbrMaps[key] != nil
            put(p, pill(have ? "\(label)  ✓  (tap to replace)" : "\(label): import", have ? "checkmark" : "import",
                        have ? C.GREEN_DARK : C.CARD2) { [weak self] in
                gPbrKey = key; self?.pickFile(R_PBRMAP, [.image])
            }, 40)
            if have {
                put(p, pill("Remove \(label.lowercased())", "trash") { [weak self] in
                    self?.pushUndo(); l.pbrMaps[key] = nil; self?.refreshPanel(); self?.render()
                }, 34)
            }
        }
        if l.pbrMaps.isEmpty {
            text(p, "No maps yet. Without maps the model keeps its own materials.", C.DIM, 12)
            return
        }
        text(p, "Surface", C.TEXT, 13, true)
        xs("Texture tiling", 0.1, 30, "pbrTile", 1)
        if l.pbrMaps["normal"] != nil {
            xs("Normal strength", 0, 3, "pbrNStr", 1)
            sw("Flip green channel (DirectX normal map)", "pbrFlip")
        }
        if l.pbrMaps["rough"] != nil { xs("Roughness multiplier", 0, 2, "pbrRough", 1) }
        if l.pbrMaps["metal"] != nil { xs("Metallic multiplier", 0, 2, "pbrMetal", 1) }
        if l.pbrMaps["ao"] != nil { xs("Ambient occlusion strength", 0, 1, "pbrAo", 1) }
        if l.pbrMaps["emissive"] != nil { xs("Emissive strength", 0, 6, "pbrEm", 1) }
        if l.pbrMaps["height"] != nil {
            text(p, "Relief (real 3D)", C.TEXT, 13, true)
            xs("Displacement (moves real geometry)", 0, 0.5, "pbrDisp", 0.05)
            xs("Mesh subdivision (0 = off, 4 = very dense)", 0, 4, "pbrSub", 2, 0)
            xs("Parallax depth (fine detail)", 0, 0.08, "pbrPar", 0.03)
            xs("Height midpoint", 0, 1, "pbrMid", 0.5)
            text(p, "Displacement needs subdivision: each level multiplies the triangles by four (a plane or cube works best). Parallax and self-shadowing add detail smaller than the triangles.", C.DIM, 12)
        }
        text(p, "Clear coat", C.TEXT, 13, true)
        xs("Clear coat (lacquer / car paint)", 0, 1, "pbrCoat", 0)
        xs("Clear coat roughness", 0, 1, "pbrCoatR", 0.1)
    }
}
