// BuiltinsMotion.swift — Oscillate and Twitch (movement effects).
//
// Both move pixels over time, so the renderer treats them as "moving" effects: when the layer's
// Motion Blur is on they are evaluated per sub-frame sample (see SceneRenderer.movingFx).
// Twitch's "Time" operator is a layer re-time done in the renderer (SceneRenderer.twitchRetime).

import Foundation

private let onOff = ["Off", "On"]

func motionFx() -> [EffectDef] {
    var out: [EffectDef] = []

    // MARK: Oscillate
    out.append(EffectDef(
        id: "oscillate", name: "Oscillate",
        desc: "Moves the layer back and forth along an angle with a selectable wave (sine, triangle, square…). Optional scale and rotation pulsing. Works with Motion Blur.",
        category: "Transform and time", props: [
            PropDef("oscAmp", "Amplitude", 0, 1, 0.1, 3),
            PropDef("oscFreq", "Frequency (Hz)", 0, 20, 1, 2),
            PropDef("oscAngle", "Angle", -180, 180, 90, 1, nil, true, 180),
            PropDef("oscPhase", "Phase", -360, 360, 0, 1, nil, true, 180),
            PropDef("oscWave", "Wave type", 0, 4, 0, 0, ["Sine", "Triangle", "Square", "Sawtooth", "Bounce"]),
            PropDef("oscScale", "Scale pulse", 0, 1, 0, 3),
            PropDef("oscRot", "Rotation swing", -90, 90, 0, 1),
            PropDef("oscEvolve", "Amplitude drift", 0, 1, 0, 2),
            PropDef("oscEdge", "Edges", 0, 3, 0, 0, ["Mirror", "Transparent", "Clamp", "Wrap"]),
        ], previewAnim: "oscillate", glsl: """
    float ph = uTime * oscFreq + oscPhase / 360.0;
    float f = fract(ph);
    float w = sin(6.28318 * ph);
    if (oscWave > 3.5) { w = 2.0 * abs(sin(3.14159 * ph)) - 1.0; }
    else if (oscWave > 2.5) { w = 2.0 * f - 1.0; }
    else if (oscWave > 1.5) { w = w >= 0.0 ? 1.0 : -1.0; }
    else if (oscWave > 0.5) { w = 4.0 * abs(fract(ph - 0.25) - 0.5) - 1.0; }
    float amp = oscAmp * (1.0 + oscEvolve * sin(uTime * 0.7) * 0.5);
    float a = radians(oscAngle);
    vec2 asp = vec2(uRes.y / uRes.x, 1.0);
    vec2 p = uv - vec2(cos(a), sin(a)) * (w * amp) * asp;
    p = (p - 0.5) / (1.0 + oscScale * w) ;
    p = rot(p, radians(oscRot) * w) + 0.5;
    if (oscEdge > 2.5) { p = fract(p); }
    else if (oscEdge > 1.5) { p = clamp(p, 0.0, 1.0); }
    else if (oscEdge > 0.5) { if (p.x < 0.0 || p.y < 0.0 || p.x > 1.0 || p.y > 1.0) { return vec4(0.0); } }
    else { p = 1.0 - abs(1.0 - mod(p, 2.0)); }
    return src(p);
"""))

    // MARK: Twitch
    func op(_ pre: String, _ name: String) -> [PropDef] {
        [PropDef(pre + "Speed", name + " speed", 0, 5, 1, 2),
         PropDef(pre + "Twitches", name + " twitches", 0, 1, 0.5, 2),
         PropDef(pre + "Seed", name + " random seed", 0, 1000, 0, 0)]
    }
    var tw: [PropDef] = [
        PropDef("twAmount", "Amount", 0, 3, 1, 2),
        PropDef("twSpeed", "Speed", 0, 10, 1, 2),
        PropDef("twBorder", "Border", 0, 3, 2, 0, ["Mirror", "Tile", "Clamp", "None"]),
        PropDef("twMin", "Randomize minimum", 0, 1, 0, 2),
        PropDef("twEnBlur", "Enable Blur", 0, 1, 0, 0, onOff),
        PropDef("twEnColor", "Enable Color", 0, 1, 0, 0, onOff),
        PropDef("twEnLight", "Enable Light", 0, 1, 0, 0, onOff),
        PropDef("twEnScale", "Enable Scale", 0, 1, 0, 0, onOff),
        PropDef("twEnSlide", "Enable Slide", 0, 1, 1, 0, onOff),
        PropDef("twEnTime", "Enable Time", 0, 1, 0, 0, onOff),
        PropDef("twSlAmount", "Slide amount", 0, 1, 0.1, 3),
        PropDef("twSlDir", "Slide direction", -180, 180, 0, 1, nil, true, 180),
        PropDef("twSlSpread", "Slide spread", 0, 180, 0, 1),
        PropDef("twSlRgb", "RGB split", 0, 0.05, 0, 3),
        PropDef("twSlMblur", "Slide motion blur", 0, 1, 0, 2),
        PropDef("twSlTend", "Slide tendency", -1, 1, 0, 2),
    ]
    tw += op("twSl", "Slide")
    tw.append(PropDef("twBlAmount", "Blur amount", 0, 0.1, 0.02, 3))
    tw.append(PropDef("twBlAspect", "Blur aspect (H ← → V)", -1, 1, 0, 2))
    tw.append(PropDef("twBlMode", "Blur transfer", 0, 2, 0, 0, ["Mix", "Add", "Screen"]))
    tw.append(PropDef("twBlBoost", "Blur boost", 0, 3, 0, 2))
    tw.append(PropDef("twBlOpac", "Blur opacity", 0, 1, 1, 2))
    tw += op("twBl", "Blur")
    tw.append(PropDef("twCoAmount", "Color amount", 0, 1, 0.5, 2))
    tw.append(PropDef("twCoMode", "Color mode", 0, 1, 0, 0, ["Random hue", "Locked tint"]))
    tw += op("twCo", "Color")
    tw.append(PropDef("twLiAmount", "Light amount", 0, 2, 0.5, 2))
    tw.append(PropDef("twLiFunc", "Light function", 0, 2, 2, 0, ["Brighter", "Darker", "Both"]))
    tw += op("twLi", "Light")
    tw.append(PropDef("twScAmount", "Scale amount", 0, 1, 0.2, 2))
    tw.append(PropDef("twScAnchor", "Scale anchor", 0, 1, 0, 0, ["Center", "Random edge"]))
    tw += op("twSc", "Scale")
    tw.append(PropDef("twTmAmount", "Time amount (frames)", 0, 30, 4, 0))
    tw += op("twTm", "Time")

    out.append(EffectDef(
        id: "twitch", name: "Twitch",
        desc: "Random glitch jumps: Slide (with RGB split), Blur, Color, Light, Scale and Time stutter. Switch each operator on, then tune it. Slide / Scale respect Motion Blur.",
        category: "Glitch and motion", props: tw,
        colors: [ColorParam("twTint", "Locked tint", Int32(bitPattern: 0xFFFF4FA8)),
                 ColorParam("twBlTint", "Blur tint", Int32(bitPattern: 0xFFFFFFFF))],
        previewAnim: "twitch", glsl: """
    vec2 asp = vec2(uRes.y / uRes.x, 1.0);
    float spd = uTime * twSpeed * 8.0;
    float amt = twAmount;
    vec2 p = uv;
    float st; float on; float r;
    if (twEnScale > 0.5) {
        st = floor(spd * twScSpeed);
        on = step(hash11(st * 3.17 + twScSeed * 7.3 + 1.0), twScTwitches);
        r = hash11(st * 5.31 + twScSeed * 2.9 + 2.0) * 2.0 - 1.0;
        r = sign(r) * mix(twMin, 1.0, abs(r));
        float s = max(1.0 + twScAmount * amt * r * on, 0.05);
        vec2 an = vec2(0.5);
        if (twScAnchor > 0.5) { an = floor(vec2(hash11(st * 1.9 + twScSeed + 3.0), hash11(st * 2.3 + twScSeed + 4.0)) * 3.0) * 0.5; }
        p = (p - an) / s + an;
    }
    if (twBorder < 0.5) { p = 1.0 - abs(1.0 - mod(p, 2.0)); }
    else if (twBorder < 1.5) { p = fract(p); }
    float pIn = 1.0;
    if (twBorder > 2.5) { pIn = step(0.0, p.x) * step(p.x, 1.0) * step(0.0, p.y) * step(p.y, 1.0); }
    vec2 off = vec2(0.0);
    vec2 rd = vec2(0.0);
    if (twEnSlide > 0.5) {
        st = floor(spd * twSlSpeed);
        on = step(hash11(st * 3.91 + twSlSeed * 7.3 + 5.0), twSlTwitches);
        float ang = radians(twSlDir + (hash11(st * 4.1 + twSlSeed + 6.0) * 2.0 - 1.0) * twSlSpread);
        float rr = clamp(hash11(st * 6.7 + twSlSeed * 1.3 + 7.0) * 2.0 - 1.0 + twSlTend, -1.0, 1.0);
        rr = sign(rr) * mix(twMin, 1.0, abs(rr));
        float mag = rr * twSlAmount * amt * on;
        vec2 dv = vec2(cos(ang), sin(ang));
        off = dv * mag * asp;
        rd = dv * twSlRgb * amt * on * asp;
    }
    vec4 c;
    if (dot(off, off) + dot(rd, rd) < 1e-10) { c = src(p) * pIn; }
    else {
        c = vec4(0.0);
        for (int i = 0; i < 8; i++) {
            float k = float(i) / 7.0;
            vec2 q = p - off * (1.0 - twSlMblur * k);
            vec4 acc = vec4(0.0);
            for (int j = 0; j < 3; j++) {
                vec2 t = q + rd * (1.0 - float(j));
                float ins = 1.0;
                if (twBorder < 0.5) { t = 1.0 - abs(1.0 - mod(t, 2.0)); }
                else if (twBorder < 1.5) { t = fract(t); }
                else if (twBorder > 2.5) { ins = step(0.0, t.x) * step(t.x, 1.0) * step(0.0, t.y) * step(t.y, 1.0); }
                vec4 sx = src(t) * ins;
                acc.a += sx.a / 3.0;
                if (j == 0) { acc.r = sx.r; } else if (j == 1) { acc.g = sx.g; } else { acc.b = sx.b; }
            }
            c += acc;
        }
        c /= 8.0;
    }
    if (twEnBlur > 0.5) {
        st = floor(spd * twBlSpeed);
        on = step(hash11(st * 2.71 + twBlSeed * 7.3 + 8.0), twBlTwitches);
        float rad = twBlAmount * amt * on;
        if (rad > 0.0005) {
            vec2 bs = vec2(1.0 + twBlAspect, 1.0 - twBlAspect) * asp;
            vec4 b = vec4(0.0);
            for (int i = 0; i < 12; i++) {
                float fi = (float(i) + 0.5) / 12.0;
                float an = float(i) * 2.39996;
                b += src(p - off + vec2(cos(an), sin(an)) * sqrt(fi) * rad * bs);
            }
            b /= 12.0;
            b.rgb *= (1.0 + twBlBoost) * twBlTint.rgb;
            vec4 bmx = b;
            if (twBlMode > 1.5) { bmx = vec4(1.0) - (vec4(1.0) - c) * (vec4(1.0) - b); }
            else if (twBlMode > 0.5) { bmx = vec4(c.rgb + b.rgb * 0.6, max(c.a, b.a)); }
            c = mix(c, bmx, twBlOpac);
        }
    }
    if (twEnColor > 0.5) {
        st = floor(spd * twCoSpeed);
        on = step(hash11(st * 1.37 + twCoSeed * 7.3 + 9.0), twCoTwitches);
        float amtC = twCoAmount * on * min(amt, 1.0);
        if (twCoMode > 0.5) {
            c.rgb *= mix(vec3(1.0), twTint.rgb * 1.6, amtC);
        } else {
            float h = hash11(st * 8.3 + twCoSeed + 10.0) * 6.28318 * amtC;
            vec3 k = vec3(0.57735);
            c.rgb = c.rgb * cos(h) + cross(k, c.rgb) * sin(h) + k * dot(k, c.rgb) * (1.0 - cos(h));
        }
    }
    if (twEnLight > 0.5) {
        st = floor(spd * twLiSpeed);
        on = step(hash11(st * 2.13 + twLiSeed * 7.3 + 11.0), twLiTwitches);
        r = hash11(st * 9.1 + twLiSeed + 12.0) * 2.0 - 1.0;
        if (twLiFunc < 0.5) { r = abs(r); } else if (twLiFunc < 1.5) { r = -abs(r); }
        c.rgb *= exp2(r * twLiAmount * amt * 2.0 * on);
    }
    return c;
"""))

    // MARK: Motion Tile (After Effects style)
    out.append(EffectDef(
        id: "motiontile", name: "Motion Tile",
        desc: "Tiles the layer like After Effects' Motion Tile: tile center / size, output size, mirror edges, phase and horizontal phase shift, plus scroll. Works on 3D layers (the layer is tiled flat, then placed in 3D).",
        category: "Transform and time", props: [
            PropDef("mtCX", "Tile center X (%)", 0, 100, 50, 1),
            PropDef("mtCY", "Tile center Y (%)", 0, 100, 50, 1),
            PropDef("mtW", "Tile width (%)", 1, 400, 100, 1),
            PropDef("mtH", "Tile height (%)", 1, 400, 100, 1),
            PropDef("mtOutW", "Output width (%)", 0, 2000, 300, 0),
            PropDef("mtOutH", "Output height (%)", 0, 2000, 300, 0),
            PropDef("mtMirror", "Mirror edges", 0, 1, 0, 0, onOff),
            PropDef("mtPhase", "Phase", -360, 360, 0, 1, nil, true, 180),
            PropDef("mtHShift", "Horizontal phase shift", 0, 1, 0, 0, onOff),
            PropDef("mtScrollX", "Scroll X (tiles/s)", -5, 5, 0, 2),
            PropDef("mtScrollY", "Scroll Y (tiles/s)", -5, 5, 0, 2),
        ], previewAnim: "swipe", glsl: """
    float ar = uRes.x / uRes.y;
    vec2 dw = (uv - 0.5) * vec2(2.0 * ar, 2.0) - uLC;
    float det = uLX.x * uLY.y - uLX.y * uLY.x;
    if (abs(det) < 1e-8) { return vec4(0.0); }
    vec2 l = vec2(dw.x * uLY.y - dw.y * uLY.x, -dw.x * uLX.y + dw.y * uLX.x) / det;
    vec2 rel = l;
    if (abs(rel.x) > mtOutW * 0.005 || abs(rel.y) > mtOutH * 0.005) { return vec4(0.0); }
    vec2 ts = max(vec2(mtW, mtH) * 0.01, 0.001);
    vec2 t = rel / ts + 0.5 + vec2(mtScrollX, mtScrollY) * uTime;
    vec2 id = floor(t);
    float ph = mtPhase / 360.0;
    if (mtHShift > 0.5) { t.x += ph * id.y; } else { t.y += ph * id.x; }
    id = floor(t);
    vec2 f = t - id;
    if (mtMirror > 0.5) {
        if (mod(id.x, 2.0) > 0.5) { f.x = 1.0 - f.x; }
        if (mod(id.y, 2.0) > 0.5) { f.y = 1.0 - f.y; }
    }
    vec2 sl = vec2(mtCX, mtCY) * 0.01 - 0.5 + (f - 0.5) * ts;
    if (abs(sl.x) > 0.5 || abs(sl.y) > 0.5) { return vec4(0.0); }
    vec2 wp = uLC + uLX * sl.x + uLY * sl.y;
    return src(wp / vec2(2.0 * ar, 2.0) + 0.5);
"""))
    return out
}
