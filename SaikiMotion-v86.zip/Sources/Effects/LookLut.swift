// LookLut.swift — .cube 3D LUT store for the MB Looks effect.
//
// Imported files live in Documents/Luts. A LUT is parsed into an RGBA8 "strip" texture
// (size*size wide, size tall; x = blue*size + red, row = size-1-green) that the effect samples
// with manual blue-slice interpolation. Metal only (GL fallback skips the LUT).

import Foundation
import Metal

final class LookLut {
    static let shared = LookLut()
    private var cache: [String: (MTLTexture, Int)] = [:]
    private let lock = NSLock()

    static var dir: URL {
        let d = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Luts")
        try? FileManager.default.createDirectory(at: d, withIntermediateDirectories: true)
        return d
    }

    /// Names of every imported .cube file.
    func names() -> [String] {
        let f = (try? FileManager.default.contentsOfDirectory(atPath: Self.dir.path)) ?? []
        return f.filter { $0.lowercased().hasSuffix(".cube") }.sorted()
    }

    /// Copies a picked .cube into Documents/Luts. Returns the stored name, or nil when it is not a valid 3D cube.
    func importFile(_ url: URL) -> String? {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        guard let txt = (try? String(contentsOf: url, encoding: .utf8))
                ?? (try? String(contentsOf: url, encoding: .isoLatin1)),
              Self.parse(txt) != nil else { return nil }
        var name = url.lastPathComponent
        if !name.lowercased().hasSuffix(".cube") { name += ".cube" }
        let dst = Self.dir.appendingPathComponent(name)
        try? txt.write(to: dst, atomically: true, encoding: .utf8)
        lock.lock(); cache[name] = nil; lock.unlock()
        return name
    }

    /// (size, RGBA8 strip bytes) of a .cube text.
    static func parse(_ txt: String) -> (Int, [UInt8])? {
        var n = 0
        var vals: [Float] = []
        var dmin: Float = 0, dmax: Float = 1
        for sub in txt.split(whereSeparator: { $0 == "\n" || $0 == "\r" }) {
            let line = sub.trimmingCharacters(in: .whitespaces)
            if line.isEmpty || line.hasPrefix("#") { continue }
            let p = line.split(whereSeparator: { $0 == " " || $0 == "\t" })
            if p.count >= 3, let a = Float(p[0]), let b = Float(p[1]), let c = Float(p[2]) {
                vals.append(a); vals.append(b); vals.append(c); continue
            }
            if p[0] == "LUT_3D_SIZE", p.count > 1, let s = Int(p[1]) { n = s }
            else if p[0] == "LUT_1D_SIZE" { return nil }
            else if p[0] == "DOMAIN_MIN", p.count > 1, let v = Float(p[1]) { dmin = v }
            else if p[0] == "DOMAIN_MAX", p.count > 1, let v = Float(p[1]) { dmax = v }
        }
        guard n >= 2, n <= 65, vals.count >= n * n * n * 3 else { return nil }
        var px = [UInt8](repeating: 255, count: n * n * n * 4)
        let span = max(dmax - dmin, 0.0001)
        for i in 0..<(n * n * n) {
            let r = i % n, g = (i / n) % n, b = i / (n * n)
            let o = ((n - 1 - g) * n * n + b * n + r) * 4
            for k in 0..<3 {
                let v = (vals[i * 3 + k] - dmin) / span
                px[o + k] = UInt8(max(0, min(255, v * 255 + 0.5)))
            }
        }
        return (n, px)
    }

    /// The strip texture of an imported LUT (cached) and its cube size.
    func texture(_ name: String, _ device: MTLDevice) -> (MTLTexture, Int)? {
        lock.lock(); defer { lock.unlock() }
        if let t = cache[name] { return t }
        guard let txt = try? String(contentsOf: Self.dir.appendingPathComponent(name), encoding: .utf8),
              let r = Self.parse(txt) else { return nil }
        let n = r.0
        let d = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .rgba8Unorm, width: n * n, height: n, mipmapped: false)
        d.usage = .shaderRead
        guard let t = device.makeTexture(descriptor: d) else { return nil }
        r.1.withUnsafeBytes {
            t.replace(region: MTLRegionMake2D(0, 0, n * n, n), mipmapLevel: 0,
                      withBytes: $0.baseAddress!, bytesPerRow: n * n * 4)
        }
        cache[name] = (t, n)
        return (t, n)
    }
}
