// GlbModel.swift — 3D model loader (Render).
//
// Formats: .glb, .gltf (embedded / data-URI / sibling .bin + images), .obj (vertex colours supported),
// .abc (transcoded to .glb by the native decoder). The format is detected from the file CONTENT, so
// renamed or cached files still load.
//
// glTF support: scene graph (node matrix / TRS, nested), every accessor component type incl.
// normalized + KHR_mesh_quantization, triangles / strips / fans / points, COLOR_0, missing normals are
// generated, PBR metallic-roughness (base colour / metal-rough / emissive textures + factors), alpha
// MASK / BLEND, KHR_materials_unlit, KHR_materials_emissive_strength and the
// KHR_materials_pbrSpecularGlossiness fallback (diffuse). Draco / Meshopt compressed files are
// reported with a clear message instead of failing silently.
//
// Every mesh is normalized: re-centred and rescaled so its largest side is 1.4 world units.
// GPU buffers are context-bound, so there is NO global cache here — each SceneRenderer caches its own.

import Foundation
import CNative
import OpenGLES
import GLKit
import UIKit

final class GlbModel {

    struct Prim {
        var count: GLsizei = 0
        var vbo: GLuint = 0
        var ibo: GLuint = 0
        var indexType: GLenum = GLenum(GL_UNSIGNED_SHORT)
        var mode: GLenum = GLenum(GL_TRIANGLES)
        var color: [Float] = [1, 1, 1, 1]
        var emissive: [Float] = [0, 0, 0]
        var metal: Float = 0
        var rough: Float = 0.8
        var texBase: GLuint = 0
        var texMR: GLuint = 0
        var texEm: GLuint = 0
        var texOcc: GLuint = 0
        var blend = false
        var cutoff: Float = -1
        var unlit: Float = 0
        var slot = -1                 // index of the source mesh (animation sidecar order)
        var verts: [Float] = []       // CPU copy of the interleaved vertices (animated models, and every Metal-loaded model)
        var cpuIdx: [UInt32] = []     // Metal-loaded models only (cpuOnly): the index list
    }

    var prims: [Prim] = []

    // MARK: animation (Alembic sidecar "<model>.glb.anim")

    /// Per-frame vertex positions + normals written by the .abc transcoder.
    private final class AbcAnim {
        let data: Data
        let frames: Int
        let fps: Float
        let counts: [Int]
        let base: Int                 // byte offset of frame 0
        let frameBytes: Int
        var slotOffset: [Int] = []    // byte offset of each mesh inside a frame

        init?(path: String) {
            guard let d = try? Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe), d.count >= 16 else { return nil }
            func u32(_ o: Int) -> UInt32 { d.withUnsafeBytes { $0.loadUnaligned(fromByteOffset: o, as: UInt32.self) } }
            guard u32(0) == 0x41424153 else { return nil }
            let nf = Int(u32(4)), nm = Int(u32(12))
            guard nf > 1, nm > 0, nm < 4096, d.count >= 16 + nm * 4 else { return nil }
            var c: [Int] = []
            var fb = 0
            for i in 0..<nm {
                let n = Int(u32(16 + i * 4))
                c.append(n); slotOffset.append(fb); fb += n * 24
            }
            let b = 16 + nm * 4
            guard fb > 0, b + fb * nf <= d.count else { return nil }
            data = d; frames = nf; counts = c; base = b; frameBytes = fb
            let f = d.withUnsafeBytes { $0.loadUnaligned(fromByteOffset: 8, as: Float.self) }
            fps = (f.isFinite && f > 0.5 && f < 1000) ? f : 24
        }
    }

    private var anim: AbcAnim?
    private var animFrame = -1
    /// Bumped every time setAnimTime poses a new frame (Metal re-uploads the vertices when it changes).
    var animVersion = 0
    var isAnimated: Bool { anim != nil }

    /// Poses the model for `t` seconds from the layer start (loops). Cheap when the frame is unchanged.
    func setAnimTime(_ t: Float) {
        guard let a = anim else { return }
        let f = Int((max(0, t) * a.fps).rounded(.down)) % a.frames
        if f == animFrame { return }
        animFrame = f
        animVersion += 1
        a.data.withUnsafeBytes { raw in
            for i in 0..<prims.count where prims[i].slot >= 0 && prims[i].slot < a.counts.count {
                let n = a.counts[prims[i].slot]
                guard prims[i].verts.count == n * 12 else { continue }
                let off = a.base + f * a.frameBytes + a.slotOffset[prims[i].slot]
                for k in 0..<n {
                    for c in 0..<3 {
                        prims[i].verts[k * 12 + c] = raw.loadUnaligned(fromByteOffset: off + (k * 3 + c) * 4, as: Float.self)
                        prims[i].verts[k * 12 + 3 + c] = raw.loadUnaligned(fromByteOffset: off + n * 12 + (k * 3 + c) * 4, as: Float.self)
                    }
                }
                if prims[i].vbo == 0 { continue }        // Metal-loaded model: MetalModel re-uploads on animVersion
                glBindBuffer(GLenum(GL_ARRAY_BUFFER), prims[i].vbo)
                prims[i].verts.withUnsafeBufferPointer { ptr in
                    glBufferSubData(GLenum(GL_ARRAY_BUFFER), 0, MemoryLayout<Float>.size * ptr.count, ptr.baseAddress)
                }
            }
        }
    }

    private static var keepCPU = false

    /// Metal load: no GL calls at all. Vertices / indices stay on the CPU (Prim.verts / cpuIdx) and
    /// images are kept as UIImage under a synthetic texture id (cpuImages) for MetalModel to upload.
    static var cpuOnly = false
    static var cpuImages: [GLuint: (img: UIImage, clamp: Bool)] = [:]
    private static var cpuImageId: GLuint = 0
    private static func uploadImage(_ img: UIImage, clamp: Bool) -> GLuint? {
        if cpuOnly {
            cpuImageId += 1
            cpuImages[cpuImageId] = (img, clamp)
            return cpuImageId
        }
        return Gl.upload(img, maxSide: 2048)
    }

    /// normalization: [scale, offX, offY, offZ]. The offsets are the RAW (unscaled) centre offset;
    /// the renderer applies them BEFORE rotation/scale so models rotate around their own centre.
    var normalize: [Float] = [1, 0, 0, 0]
    var baseY: Float = 0          // lowest point after normalising (<= 0): scatter lifts by this so objects sit ON the surface

    /// Why the last load failed (for toasts / logs).
    static var lastError = ""

    // MARK: - public entry points

    static func load(_ path: String) -> GlbModel? {
        lastError = ""
        var p = path
        if p.lowercased().hasSuffix(".abc") { p = transcodeAbc(p) ?? p }
        guard let data = FileManager.default.contents(atPath: p), data.count > 4 else {
            lastError = "Cannot read the model file"
            return nil
        }
        let dir = (p as NSString).deletingLastPathComponent
        let ext = (p as NSString).pathExtension.lowercased()
        let head = data.prefix(64)
        let isGlb = head.count >= 4 && head[head.startIndex] == 0x67 && head[head.startIndex + 1] == 0x6C
            && head[head.startIndex + 2] == 0x54 && head[head.startIndex + 3] == 0x46
        if !isGlb && (ext == "obj" || looksLikeObj(data)) {
            let m = parseObj(data)
            if m == nil && lastError.isEmpty { lastError = "OBJ has no faces" }
            return m
        }
        guard let (json, bin) = splitContainer(data) else {
            if lastError.isEmpty { lastError = "Not a valid .glb / .gltf / .obj file" }
            return nil
        }
        if let bad = unsupportedExtension(json) { lastError = bad; return nil }
        let animPath = p + ".anim"
        let fromAbc = ext == "glb" && FileManager.default.fileExists(atPath: animPath)
        keepCPU = fromAbc
        defer { keepCPU = false }
        let m = parseGltf(json, bin: bin, dir: dir)
        if m == nil && lastError.isEmpty { lastError = "No drawable geometry found" }
        if let m = m, fromAbc || isAbcGlb(json) {
            m.applyAbcTextures(dir: dir, stem: ((p as NSString).lastPathComponent as NSString).deletingPathExtension)
            if fromAbc, let a = AbcAnim(path: animPath), m.attach(a) { }
        }
        return m
    }

    private static func isAbcGlb(_ json: JObj) -> Bool {
        json.optJSONObject("asset")?.optString("generator") == "SaikiMotion ABC Import"
    }

    /// Validates the sidecar against the loaded prims and widens the framing to cover every frame.
    private func attach(_ a: AbcAnim) -> Bool {
        for pr in prims {
            guard pr.slot >= 0, pr.slot < a.counts.count, pr.verts.count == a.counts[pr.slot] * 12 else { return false }
        }
        var b = Bounds()
        let step = max(1, a.frames / 48)
        a.data.withUnsafeBytes { raw in
            var f = 0
            while f < a.frames {
                for pr in prims {
                    let n = a.counts[pr.slot]
                    let off = a.base + f * a.frameBytes + a.slotOffset[pr.slot]
                    var k = 0
                    while k < n {
                        b.add(raw.loadUnaligned(fromByteOffset: off + k * 12, as: Float.self),
                              raw.loadUnaligned(fromByteOffset: off + k * 12 + 4, as: Float.self),
                              raw.loadUnaligned(fromByteOffset: off + k * 12 + 8, as: Float.self))
                        k += 1
                    }
                }
                f += step
            }
        }
        if b.valid { finishNormalize(b) }
        anim = a
        return true
    }

    /// .abc carries no pixels: pick up the images that came in the same zip (saved as "<stem>_tex_*")
    /// and bind them by name (colour / roughness-metal / emissive / occlusion).
    private func applyAbcTextures(dir: String, stem: String) {
        let prefix = stem + "_tex_"
        guard let all = try? FileManager.default.contentsOfDirectory(atPath: dir) else { return }
        let imgExt: Set<String> = ["png", "jpg", "jpeg", "webp", "heic", "tga", "bmp", "tif", "tiff"]
        let imgs = all.filter {
            $0.hasPrefix(prefix) ||
            (imgExt.contains(($0 as NSString).pathExtension.lowercased()) && ($0 as NSString).deletingPathExtension.lowercased().hasPrefix(stem.lowercased()))
        }.sorted()
        if imgs.isEmpty { return }
        func has(_ n: String, _ keys: [String]) -> Bool { keys.contains { n.lowercased().contains($0) } }
        let other = ["normal", "nrm", "bump", "height", "disp", "_n."]
        var color: [String] = [], mr: String? = nil, em: String? = nil, occ: String? = nil
        for n in imgs {
            if has(n, other) { continue }
            if has(n, ["rough", "metal", "orm", "_mr"]) { mr = mr ?? n }
            else if has(n, ["emis", "glow"]) { em = em ?? n }
            else if has(n, ["occ", "_ao"]) { occ = occ ?? n }
            else { color.append(n) }
        }
        func load(_ n: String) -> GLuint { GlbModel.uploadFile(dir + "/" + n) }
        var cache: [String: GLuint] = [:]
        for i in 0..<prims.count where prims[i].texBase == 0 {
            // one colour image per mesh when the counts line up, otherwise the first one for all
            let n: String? = color.count == prims.count ? color[min(max(prims[i].slot, 0), color.count - 1)] : color.first
            guard let name = n else { continue }
            if cache[name] == nil { cache[name] = load(name) }
            if let t = cache[name], t != 0 {
                prims[i].texBase = t
                prims[i].color = [1, 1, 1, 1]
                prims[i].metal = 0; prims[i].rough = 0.8
            }
            if let mr = mr, prims[i].texMR == 0 { if cache[mr] == nil { cache[mr] = load(mr) }; prims[i].texMR = cache[mr] ?? 0; prims[i].metal = 1; prims[i].rough = 1 }
            if let em = em, prims[i].texEm == 0 { if cache[em] == nil { cache[em] = load(em) }; prims[i].texEm = cache[em] ?? 0; prims[i].emissive = [1, 1, 1] }
            if let occ = occ, prims[i].texOcc == 0 { if cache[occ] == nil { cache[occ] = load(occ) }; prims[i].texOcc = cache[occ] ?? 0 }
        }
    }

    private static func uploadFile(_ path: String) -> GLuint {
        guard let img = UIImage(contentsOfFile: path), let tex = uploadImage(img, clamp: false) else { return 0 }
        if cpuOnly { return tex }
        glBindTexture(GLenum(GL_TEXTURE_2D), tex)
        if EAGLContext.current()?.api == .openGLES3 {
            glTexParameteri(GLenum(GL_TEXTURE_2D), GLenum(GL_TEXTURE_WRAP_S), GL_REPEAT)
            glTexParameteri(GLenum(GL_TEXTURE_2D), GLenum(GL_TEXTURE_WRAP_T), GL_REPEAT)
            glGenerateMipmap(GLenum(GL_TEXTURE_2D))
            glTexParameteri(GLenum(GL_TEXTURE_2D), GLenum(GL_TEXTURE_MIN_FILTER), GL_LINEAR_MIPMAP_LINEAR)
        }
        return tex
    }

    /// Cheap check used right after import (no GL). nil = looks fine, otherwise a message for the user.
    /// A model that arrives zipped (header "PK"): pulls the first .glb / .gltf / .obj / .abc / .vdb out
    /// of the archive next to it and returns that path; nil when it is not a zip or holds no model.
    static func unwrapZip(_ path: String) -> String? {
        guard let d = FileManager.default.contents(atPath: path), d.count > 64 else { return nil }
        let b = [UInt8](d)
        guard b[0] == 0x50, b[1] == 0x4B, b[2] == 3, b[3] == 4 else { return nil }
        func r16(_ o: Int) -> Int { Int(b[o]) | Int(b[o + 1]) << 8 }
        func r32(_ o: Int) -> Int { r16(o) | r16(o + 2) << 16 }
        var e = b.count - 22
        while e >= 0 && r32(e) != 0x06054b50 { e -= 1 }
        guard e >= 0 else { return nil }
        let n0 = r16(e + 10), p0 = r32(e + 16)
        let stem = ((path as NSString).deletingPathExtension as NSString).lastPathComponent
        let dirPath = (path as NSString).deletingLastPathComponent
        let imgExt: Set<String> = ["png", "jpg", "jpeg"]
        // pass 0: textures bundled with the model -> "<stem>_tex_<name>" beside it
        var n = n0, p = p0
        while n > 0, p + 46 <= b.count, r32(p) == 0x02014b50 {
            let method = r16(p + 10), cs = r32(p + 20), nl = r16(p + 28), el = r16(p + 30), cl = r16(p + 32), lo = r32(p + 42)
            let name = String(bytes: b[(p + 46)..<min(b.count, p + 46 + nl)], encoding: .utf8) ?? ""
            if imgExt.contains((name as NSString).pathExtension.lowercased()), !name.hasPrefix("__MACOSX"), lo + 30 <= b.count {
                let ds = lo + 30 + r16(lo + 26) + r16(lo + 28)
                if ds + cs <= b.count {
                    let raw = Array(b[ds..<(ds + cs)])
                    let out = method == 0 ? raw : (method == 8 ? VdbVolume.inflate(raw) : [])
                    if !out.isEmpty {
                        let leaf = (name as NSString).lastPathComponent
                        try? Data(out).write(to: URL(fileURLWithPath: dirPath + "/" + stem + "_tex_" + leaf))
                    }
                }
            }
            n -= 1; p += 46 + nl + el + cl
        }
        n = n0; p = p0
        let ok: Set<String> = ["glb", "gltf", "obj", "abc", "vdb"]
        while n > 0, p + 46 <= b.count, r32(p) == 0x02014b50 {
            let method = r16(p + 10), cs = r32(p + 20), nl = r16(p + 28), el = r16(p + 30), cl = r16(p + 32), lo = r32(p + 42)
            let name = String(bytes: b[(p + 46)..<min(b.count, p + 46 + nl)], encoding: .utf8) ?? ""
            let ext = (name as NSString).pathExtension.lowercased()
            if ok.contains(ext), !name.hasPrefix("__MACOSX"), lo + 30 <= b.count {
                let ds = lo + 30 + r16(lo + 26) + r16(lo + 28)
                guard ds + cs <= b.count else { return nil }
                let raw = Array(b[ds..<(ds + cs)])
                let out = method == 0 ? raw : (method == 8 ? VdbVolume.inflate(raw) : [])
                guard !out.isEmpty else { return nil }
                let dst = ((path as NSString).deletingPathExtension as NSString).appendingPathExtension(ext) ?? path + "." + ext
                guard (try? Data(out).write(to: URL(fileURLWithPath: dst))) != nil else { return nil }
                return dst
            }
            n -= 1; p += 46 + nl + el + cl
        }
        return nil
    }

    static func preflight(_ path: String) -> String? {
        lastError = ""
        let ext = (path as NSString).pathExtension.lowercased()
        if ext == "vdb" || ext == "abc" { return nil }
        guard let data = FileManager.default.contents(atPath: path), data.count > 4 else { return "Could not read the file" }
        if ext == "obj" || looksLikeObj(data) { return nil }
        guard let (json, _) = splitContainer(data) else {
            let hd = data.prefix(4).map { String(format: "%02X", $0) }.joined()
            return "Not a readable model (" + (lastError.isEmpty ? "unknown format" : lastError) + ", header " + hd + ", " + String(data.count) + " bytes)"
        }
        return unsupportedExtension(json)
    }

    /// Runs the native Ogawa decoder; returns the new .glb path.
    static func transcodeAbc(_ path: String) -> String? {
        var out = [CChar](repeating: 0, count: 1100)
        let ok = path.withCString { cstr in
            saiki_abc_to_glb(cstr, &out, 1100)
        }
        guard ok == 1 else { return nil }
        let glb = String(cString: out)
        return FileManager.default.fileExists(atPath: glb) ? glb : nil
    }

    static func validate(path: String) -> String {
        if path.lowercased().hasSuffix(".abc"), let glb = transcodeAbc(path) {
            return glb
        }
        return path
    }

    /// Camera position (world) recovered from a view-projection matrix; (0,0,3) if it is singular.
    static func eye(fromVP vp: [Float]) -> [Float] {
        guard vp.count == 16 else { return [0, 0, 3] }
        var ok = true
        var copy = vp
        let inv = GLKMatrix4Invert(GLKMatrix4MakeWithArray(&copy), &ok)
        if !ok { return [0, 0, 3] }
        let v = GLKMatrix4MultiplyVector4(inv, GLKVector4Make(0, 0, 1, 0))      // clip-space point (0,0,z,0) is the eye itself
        if abs(v.w) < 1e-9 { return [0, 0, 3] }
        return [v.x / v.w, v.y / v.w, v.z / v.w]
    }

    // MARK: - container

    private static func u32(_ b: [UInt8], _ o: Int) -> UInt32 {
        UInt32(b[o]) | (UInt32(b[o + 1]) << 8) | (UInt32(b[o + 2]) << 16) | (UInt32(b[o + 3]) << 24)
    }

    private static func looksLikeObj(_ data: Data) -> Bool {
        let n = min(data.count, 2048)
        guard n > 2 else { return false }
        guard let s = String(data: data.prefix(n), encoding: .utf8) ?? String(data: data.prefix(n), encoding: .isoLatin1) else { return false }
        var seenV = false
        for line in s.split(whereSeparator: { $0 == "\n" || $0 == "\r" || $0 == "\r\n" }).prefix(200) {
            let t = line.trimmingCharacters(in: .whitespaces)
            if t.hasPrefix("{") { return false }
            if t.hasPrefix("v ") || t.hasPrefix("v\t") || t.hasPrefix("f ") { seenV = true }
        }
        return seenV
    }

    /// Parses JSON text; falls back to Foundation's parser (handles anything valid JSON) if the
    /// lightweight one rejects it, and records the reason in lastError.
    private static func parseJson(_ text: String) -> JObj? {
        if let j = JObj.parse(text) { return j }
        func conv(_ v: Any) -> Any? {
            if let d = v as? [String: Any] {
                let o = JObj()
                for (k, x) in d { if let c = conv(x) { o.put(k, c) } }
                return o
            }
            if let a = v as? [Any] {
                let arr = JArr()
                for x in a { arr.items.append(conv(x) ?? NSNull()) }
                return arr
            }
            if v is NSNull { return nil }
            if let n = v as? NSNumber {
                if CFGetTypeID(n) == CFBooleanGetTypeID() { return n.boolValue }
                let d = n.doubleValue
                if d == d.rounded() && abs(d) < 9e15 && !"\(n)".contains(".") && !"\(n)".lowercased().contains("e") { return n.int64Value }
                return d
            }
            return v
        }
        do {
            let any = try JSONSerialization.jsonObject(with: Data(text.utf8), options: [.fragmentsAllowed])
            if let d = any as? [String: Any], let o = conv(d) as? JObj { return o }
            lastError = "glTF JSON is not an object"
        } catch { lastError = "glTF JSON error: " + error.localizedDescription }
        return nil
    }

    /// Splits a .glb (chunks) or a .gltf (plain JSON) into (json, embedded BIN chunk).
    private static func splitContainer(_ data: Data) -> (JObj, [UInt8]?)? {
        let bytes = [UInt8](data)
        guard bytes.count > 12 else { return nil }
        if bytes[0] == 0x67, bytes[1] == 0x6C, bytes[2] == 0x54, bytes[3] == 0x46 {
            var off = 12
            var jsonObj: JObj? = nil
            var bin: [UInt8]? = nil
            while off + 8 <= bytes.count {
                let len = Int(u32(bytes, off))
                let type = u32(bytes, off + 4)
                let start = off + 8
                var end = min(start + len, bytes.count)
                if type == 0x4E4F534A, jsonObj == nil {
                    while end > start && (bytes[end - 1] == 0 || bytes[end - 1] == 0x20) { end -= 1 }
                    jsonObj = parseJson(String(decoding: bytes[start..<end], as: UTF8.self))
                } else if type == 0x004E4942, bin == nil {
                    bin = Array(bytes[start..<end])
                }
                if len < 0 { break }
                off = start + ((len + 3) & ~3)
            }
            guard let j = jsonObj else {
                if lastError.isEmpty { lastError = "GLB has no readable JSON chunk (\(bytes.count) bytes)" }
                return nil
            }
            return (j, bin)
        }
        guard let text = String(data: data, encoding: .utf8) ?? String(data: data, encoding: .isoLatin1) else { return nil }
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines.union(CharacterSet(charactersIn: "\u{FEFF}")))
        guard t.hasPrefix("{"), let j = parseJson(t) else { return nil }
        return (j, nil)
    }

    private static func unsupportedExtension(_ json: JObj) -> String? {
        guard let req = json.optJSONArray("extensionsRequired") else { return nil }
        for i in 0..<req.count {
            let e = req.optString(i)
            if e == "KHR_draco_mesh_compression" {
                return "This model uses Draco compression. Re-export it without Draco (e.g. glTF-Transform: gltf-transform copy in.glb out.glb, or Blender export with compression off)."
            }
            if e == "EXT_meshopt_compression" || e == "KHR_meshopt_compression" {
                return "This model uses Meshopt compression. Re-export it without compression (glTF-Transform: gltf-transform copy in.glb out.glb)."
            }
        }
        return nil
    }

    // MARK: - math

    private static func mmul(_ a: [Float], _ b: [Float]) -> [Float] {
        var r = [Float](repeating: 0, count: 16)
        for c in 0..<4 {
            for row in 0..<4 {
                var s: Float = 0
                for k in 0..<4 { s += a[k * 4 + row] * b[c * 4 + k] }
                r[c * 4 + row] = s
            }
        }
        return r
    }

    private static let ident: [Float] = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]

    private static func nodeMatrix(_ n: JObj) -> [Float] {
        if let m = n.optJSONArray("matrix"), m.count == 16 {
            return (0..<16).map { m.optFloat($0) }
        }
        var t: [Float] = [0, 0, 0], q: [Float] = [0, 0, 0, 1], s: [Float] = [1, 1, 1]
        if let a = n.optJSONArray("translation"), a.count >= 3 { t = [a.optFloat(0), a.optFloat(1), a.optFloat(2)] }
        if let a = n.optJSONArray("rotation"), a.count >= 4 { q = [a.optFloat(0), a.optFloat(1), a.optFloat(2), a.optFloat(3)] }
        if let a = n.optJSONArray("scale"), a.count >= 3 { s = [a.optFloat(0), a.optFloat(1), a.optFloat(2)] }
        let x = q[0], y = q[1], z = q[2], w = q[3]
        let xx = x * x, yy = y * y, zz = z * z
        let xy = x * y, xz = x * z, yz = y * z, wx = w * x, wy = w * y, wz = w * z
        return [
            (1 - 2 * (yy + zz)) * s[0], 2 * (xy + wz) * s[0], 2 * (xz - wy) * s[0], 0,
            2 * (xy - wz) * s[1], (1 - 2 * (xx + zz)) * s[1], 2 * (yz + wx) * s[1], 0,
            2 * (xz + wy) * s[2], 2 * (yz - wx) * s[2], (1 - 2 * (xx + yy)) * s[2], 0,
            t[0], t[1], t[2], 1,
        ]
    }

    private struct Bounds {
        var mn: [Float] = [Float.greatestFiniteMagnitude, Float.greatestFiniteMagnitude, Float.greatestFiniteMagnitude]
        var mx: [Float] = [-Float.greatestFiniteMagnitude, -Float.greatestFiniteMagnitude, -Float.greatestFiniteMagnitude]
        var valid: Bool { mn[0] <= mx[0] }
        mutating func add(_ x: Float, _ y: Float, _ z: Float) {
            if x < mn[0] { mn[0] = x }; if x > mx[0] { mx[0] = x }
            if y < mn[1] { mn[1] = y }; if y > mx[1] { mx[1] = y }
            if z < mn[2] { mn[2] = z }; if z > mx[2] { mx[2] = z }
        }
    }

    // MARK: - accessors

    private final class Doc {
        let json: JObj
        var buffers: [[UInt8]] = []
        let accessors: JArr
        let views: JArr
        let dir: String
        var texCache: [String: GLuint] = [:]

        init(json: JObj, bin: [UInt8]?, dir: String) {
            self.json = json
            self.dir = dir
            accessors = json.optJSONArray("accessors") ?? JArr()
            views = json.optJSONArray("bufferViews") ?? JArr()
            if let bs = json.optJSONArray("buffers") {
                for i in 0..<bs.count {
                    let o = bs.optJSONObject(i)
                    let uri = o?.optString("uri") ?? ""
                    if uri.isEmpty {
                        buffers.append(i == 0 ? (bin ?? []) : [])
                    } else if let d = Doc.loadURI(uri, dir) {
                        buffers.append([UInt8](d))
                    } else {
                        buffers.append([])
                    }
                }
            } else {
                buffers = [bin ?? []]
            }
        }

        static func loadURI(_ uri: String, _ dir: String) -> Data? {
            if uri.hasPrefix("data:") {
                guard let comma = uri.firstIndex(of: ",") else { return nil }
                let payload = String(uri[uri.index(after: comma)...])
                if uri[..<comma].contains(";base64") {
                    return Data(base64Encoded: payload, options: .ignoreUnknownCharacters)
                }
                return payload.removingPercentEncoding?.data(using: .utf8)
            }
            let rel = uri.removingPercentEncoding ?? uri
            return FileManager.default.contents(atPath: (dir as NSString).appendingPathComponent(rel))
        }

        static func comps(_ t: String) -> Int {
            switch t {
            case "SCALAR": return 1
            case "VEC2": return 2
            case "VEC3": return 3
            case "VEC4": return 4
            case "MAT2": return 4
            case "MAT3": return 9
            case "MAT4": return 16
            default: return 0
            }
        }

        static func csize(_ ct: Int) -> Int {
            switch ct {
            case 5120, 5121: return 1
            case 5122, 5123: return 2
            default: return 4
            }
        }

        static func read(_ p: UnsafeRawPointer, _ o: Int, _ ct: Int, _ norm: Bool) -> Float {
            switch ct {
            case 5120:
                let v = p.load(fromByteOffset: o, as: Int8.self)
                return norm ? max(Float(v) / 127, -1) : Float(v)
            case 5121:
                let v = p.load(fromByteOffset: o, as: UInt8.self)
                return norm ? Float(v) / 255 : Float(v)
            case 5122:
                var v: Int16 = 0
                memcpy(&v, p + o, 2)
                return norm ? max(Float(v) / 32767, -1) : Float(v)
            case 5123:
                var v: UInt16 = 0
                memcpy(&v, p + o, 2)
                return norm ? Float(v) / 65535 : Float(v)
            case 5125:
                var v: UInt32 = 0
                memcpy(&v, p + o, 4)
                return Float(v)
            default:
                var u: UInt32 = 0
                memcpy(&u, p + o, 4)
                return Float(bitPattern: u)
            }
        }

        /// Float view of any accessor (normalized types are mapped to 0…1 / -1…1).
        func floats(_ idx: Int) -> (d: [Float], n: Int, c: Int)? {
            guard idx >= 0, idx < accessors.count, let a = accessors.optJSONObject(idx) else { return nil }
            let n = a.optInt("count")
            let c = Doc.comps(a.optString("type"))
            let ct = a.optInt("componentType", 5126)
            let norm = a.optBool("normalized")
            guard n > 0, c > 0 else { return nil }
            var out = [Float](repeating: 0, count: n * c)
            let csz = Doc.csize(ct)
            let bv = a.optInt("bufferView", -1)
            if bv >= 0, bv < views.count, let v = views.optJSONObject(bv) {
                let bi = v.optInt("buffer")
                guard bi >= 0, bi < buffers.count else { return nil }
                let esz = csz * c
                let stride = max(v.optInt("byteStride"), esz)
                let off = v.optInt("byteOffset") + a.optInt("byteOffset")
                buffers[bi].withUnsafeBytes { raw in
                    guard let base = raw.baseAddress else { return }
                    for i in 0..<n {
                        let eo = off + i * stride
                        if eo < 0 || eo + esz > raw.count { break }
                        for k in 0..<c { out[i * c + k] = Doc.read(base, eo + k * csz, ct, norm) }
                    }
                }
            }
            return (out, n, c)
        }

        func ints(_ idx: Int) -> [UInt32]? {
            guard idx >= 0, idx < accessors.count, let a = accessors.optJSONObject(idx) else { return nil }
            let n = a.optInt("count")
            let ct = a.optInt("componentType", 5123)
            guard n > 0, let v = views.optJSONObject(a.optInt("bufferView", -1)) else { return nil }
            let bi = v.optInt("buffer")
            guard bi >= 0, bi < buffers.count else { return nil }
            let csz = Doc.csize(ct)
            let stride = max(v.optInt("byteStride"), csz)
            let off = v.optInt("byteOffset") + a.optInt("byteOffset")
            var out = [UInt32](repeating: 0, count: n)
            buffers[bi].withUnsafeBytes { raw in
                guard let base = raw.baseAddress else { return }
                for i in 0..<n {
                    let eo = off + i * stride
                    if eo < 0 || eo + csz > raw.count { break }
                    switch ct {
                    case 5121: out[i] = UInt32(base.load(fromByteOffset: eo, as: UInt8.self))
                    case 5123:
                        var x: UInt16 = 0
                        memcpy(&x, base + eo, 2)
                        out[i] = UInt32(x)
                    default:
                        var x: UInt32 = 0
                        memcpy(&x, base + eo, 4)
                        out[i] = x
                    }
                }
            }
            return out
        }

        // MARK: textures

        /// GL texture for a glTF textureInfo ({index}); 0 when absent / undecodable.
        func texture(_ info: JObj?) -> GLuint {
            guard let info = info, info.has("index") else { return 0 }
            let ti = info.optInt("index", -1)
            guard let texs = json.optJSONArray("textures"), ti >= 0, ti < texs.count,
                  let t = texs.optJSONObject(ti) else { return 0 }
            let src = t.optInt("source", -1)
            guard src >= 0, let imgs = json.optJSONArray("images"), src < imgs.count,
                  let im = imgs.optJSONObject(src) else { return 0 }
            var clamp = false
            if let sams = json.optJSONArray("samplers"), let si = Optional(t.optInt("sampler", -1)), si >= 0, si < sams.count,
               let s = sams.optJSONObject(si), s.optInt("wrapS", 10497) == 33071 { clamp = true }
            let key = "\(src)|\(clamp)"
            if let c = texCache[key] { return c }
            var data: Data? = nil
            let uri = im.optString("uri")
            if !uri.isEmpty {
                data = Doc.loadURI(uri, dir)
            } else if let v = views.optJSONObject(im.optInt("bufferView", -1)) {
                let bi = v.optInt("buffer")
                if bi >= 0, bi < buffers.count {
                    let off = v.optInt("byteOffset"), len = v.optInt("byteLength")
                    let b = buffers[bi]
                    if off >= 0, len > 0, off + len <= b.count { data = Data(b[off..<(off + len)]) }
                }
            }
            guard let d = data, let img = UIImage(data: d), let tex = GlbModel.uploadImage(img, clamp: clamp) else {
                texCache[key] = 0
                return 0
            }
            if GlbModel.cpuOnly { texCache[key] = tex; return tex }
            glBindTexture(GLenum(GL_TEXTURE_2D), tex)
            if EAGLContext.current()?.api == .openGLES3 {
                glTexParameteri(GLenum(GL_TEXTURE_2D), GLenum(GL_TEXTURE_WRAP_S), clamp ? GL_CLAMP_TO_EDGE : GL_REPEAT)
                glTexParameteri(GLenum(GL_TEXTURE_2D), GLenum(GL_TEXTURE_WRAP_T), clamp ? GL_CLAMP_TO_EDGE : GL_REPEAT)
                glGenerateMipmap(GLenum(GL_TEXTURE_2D))
                glTexParameteri(GLenum(GL_TEXTURE_2D), GLenum(GL_TEXTURE_MIN_FILTER), GL_LINEAR_MIPMAP_LINEAR)
            }
            texCache[key] = tex
            return tex
        }
    }

    // MARK: - glTF

    private static func parseGltf(_ json: JObj, bin: [UInt8]?, dir: String) -> GlbModel? {
        guard let meshes = json.optJSONArray("meshes"), meshes.count > 0 else {
            lastError = "The file contains no meshes"
            return nil
        }
        let doc = Doc(json: json, bin: bin, dir: dir)
        let m = GlbModel()
        var bounds = Bounds()

        // collect (mesh, world matrix) instances from the scene graph
        var instances: [(Int, [Float])] = []
        if let nodes = json.optJSONArray("nodes"), nodes.count > 0 {
            var roots: [Int] = []
            if let scenes = json.optJSONArray("scenes"), scenes.count > 0 {
                let si = min(max(json.optInt("scene", 0), 0), scenes.count - 1)
                if let sn = scenes.optJSONObject(si)?.optJSONArray("nodes") {
                    for i in 0..<sn.count { roots.append(sn.optInt(i)) }
                }
            }
            if roots.isEmpty {
                var isChild = Set<Int>()
                for i in 0..<nodes.count {
                    if let ch = nodes.optJSONObject(i)?.optJSONArray("children") {
                        for k in 0..<ch.count { isChild.insert(ch.optInt(k)) }
                    }
                }
                for i in 0..<nodes.count where !isChild.contains(i) { roots.append(i) }
            }
            func walk(_ ni: Int, _ parent: [Float], _ depth: Int) {
                guard depth < 64, ni >= 0, ni < nodes.count, instances.count < 4000,
                      let node = nodes.optJSONObject(ni) else { return }
                let w = mmul(parent, nodeMatrix(node))
                if node.has("mesh") { instances.append((node.optInt("mesh"), w)) }
                if let ch = node.optJSONArray("children") {
                    for k in 0..<ch.count { walk(ch.optInt(k), w, depth + 1) }
                }
            }
            for r in roots { walk(r, ident, 0) }
        }
        if instances.isEmpty {
            for i in 0..<meshes.count { instances.append((i, ident)) }
        }

        for (mi, w) in instances {
            guard mi >= 0, mi < meshes.count, let mesh = meshes.optJSONObject(mi),
                  let primsJ = mesh.optJSONArray("primitives") else { continue }
            // linear part + normal matrix
            let a0 = [w[0], w[1], w[2]], a1 = [w[4], w[5], w[6]], a2 = [w[8], w[9], w[10]]
            func cross(_ a: [Float], _ b: [Float]) -> [Float] {
                [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]
            }
            let c0 = cross(a1, a2), c1 = cross(a2, a0), c2 = cross(a0, a1)
            let det = a0[0] * c0[0] + a0[1] * c0[1] + a0[2] * c0[2]
            let sgn: Float = det < 0 ? -1 : 1
            let identity = (w == ident)

            for pi in 0..<primsJ.count {
                guard let pj = primsJ.optJSONObject(pi), let attrs = pj.optJSONObject("attributes") else { continue }
                let mode = pj.optInt("mode", 4)
                guard mode == 0 || mode == 4 || mode == 5 || mode == 6 else { continue }
                guard let pos = doc.floats(attrs.optInt("POSITION", -1)), pos.c == 3 else { continue }
                let n = pos.n
                var P = pos.d

                // indices → triangle list (or a point list)
                var idx: [UInt32]
                if pj.has("indices"), let ii = doc.ints(pj.optInt("indices", -1)) {
                    idx = ii
                } else {
                    idx = (0..<UInt32(n)).map { $0 }
                }
                if mode == 0 {
                    // points
                } else {
                    idx = triangles(idx, mode: mode)
                }
                if idx.isEmpty { continue }
                if let mx = idx.max(), Int(mx) >= n { idx = idx.map { min($0, UInt32(n - 1)) } }

                var N: [Float] = []
                if mode != 0 {
                    if let nn = doc.floats(attrs.optInt("NORMAL", -1)), nn.c == 3, nn.n == n { N = nn.d }
                    else { N = genNormals(P, idx) }
                } else {
                    N = [Float](repeating: 0, count: n * 3)
                    for i in 0..<n { N[i * 3 + 1] = 1 }
                }
                var U = [Float](repeating: 0, count: n * 2)
                if let uu = doc.floats(attrs.optInt("TEXCOORD_0", -1)), uu.c == 2, uu.n == n { U = uu.d }
                var C = [Float](repeating: 1, count: n * 4)
                var hasVC = false
                if let cc = doc.floats(attrs.optInt("COLOR_0", -1)), cc.n == n, cc.c == 3 || cc.c == 4 {
                    hasVC = true
                    for i in 0..<n {
                        C[i * 4] = cc.d[i * cc.c]; C[i * 4 + 1] = cc.d[i * cc.c + 1]; C[i * 4 + 2] = cc.d[i * cc.c + 2]
                        C[i * 4 + 3] = cc.c == 4 ? cc.d[i * 4 + 3] : 1
                    }
                }

                if !identity {
                    for i in 0..<n {
                        let x = P[i * 3], y = P[i * 3 + 1], z = P[i * 3 + 2]
                        P[i * 3] = w[0] * x + w[4] * y + w[8] * z + w[12]
                        P[i * 3 + 1] = w[1] * x + w[5] * y + w[9] * z + w[13]
                        P[i * 3 + 2] = w[2] * x + w[6] * y + w[10] * z + w[14]
                        let nx = N[i * 3], ny = N[i * 3 + 1], nz = N[i * 3 + 2]
                        var rx = (c0[0] * nx + c1[0] * ny + c2[0] * nz) * sgn
                        var ry = (c0[1] * nx + c1[1] * ny + c2[1] * nz) * sgn
                        var rz = (c0[2] * nx + c1[2] * ny + c2[2] * nz) * sgn
                        let l = (rx * rx + ry * ry + rz * rz).squareRoot()
                        if l > 1e-8 { rx /= l; ry /= l; rz /= l } else { rx = 0; ry = 1; rz = 0 }
                        N[i * 3] = rx; N[i * 3 + 1] = ry; N[i * 3 + 2] = rz
                    }
                    if det < 0 && mode != 0 {      // mirrored: keep front faces front
                        var t = 0
                        while t + 2 < idx.count { idx.swapAt(t + 1, t + 2); t += 3 }
                    }
                }

                var prim = makePrim(P, N, U, C, idx, mode: mode == 0 ? GLenum(GL_POINTS) : GLenum(GL_TRIANGLES), bounds: &bounds)

                // material
                let mat = pj.optInt("material", -1)
                if let mats = json.optJSONArray("materials"), mat >= 0, mat < mats.count, let mj = mats.optJSONObject(mat) {
                    applyMaterial(mj, doc, &prim)
                } else {
                    prim.color = [1, 1, 1, 1]
                    prim.metal = 0; prim.rough = 0.8
                    if hasVC { prim.unlit = 1 } else { prim.color = [0.78, 0.8, 0.86, 1] }
                }
                prim.slot = m.prims.count
                m.prims.append(prim)
            }
        }

        guard !m.prims.isEmpty, bounds.valid else {
            lastError = "The model has no triangle / point geometry"
            return nil
        }
        m.prims.sort { !$0.blend && $1.blend }
        m.finishNormalize(bounds)
        return m
    }

    private static func applyMaterial(_ mj: JObj, _ doc: Doc, _ prim: inout Prim) {
        let pbr = mj.optJSONObject("pbrMetallicRoughness")
        var base: [Float] = [1, 1, 1, 1]
        if let bc = pbr?.optJSONArray("baseColorFactor"), bc.count >= 3 {
            base = [bc.optFloat(0), bc.optFloat(1), bc.optFloat(2), bc.count > 3 ? bc.optFloat(3) : 1]
        }
        prim.metal = pbr?.optFloat("metallicFactor", 1) ?? 1
        prim.rough = pbr?.optFloat("roughnessFactor", 1) ?? 1
        prim.texBase = doc.texture(pbr?.optJSONObject("baseColorTexture"))
        prim.texMR = doc.texture(pbr?.optJSONObject("metallicRoughnessTexture"))

        let ext = mj.optJSONObject("extensions")
        if let sg = ext?.optJSONObject("KHR_materials_pbrSpecularGlossiness"), pbr == nil || prim.texBase == 0 {
            if let df = sg.optJSONArray("diffuseFactor"), df.count >= 3 {
                base = [df.optFloat(0), df.optFloat(1), df.optFloat(2), df.count > 3 ? df.optFloat(3) : 1]
            }
            let dt = doc.texture(sg.optJSONObject("diffuseTexture"))
            if dt != 0 { prim.texBase = dt }
            prim.metal = 0
            prim.rough = 1 - min(max(sg.optFloat("glossinessFactor", 1), 0), 1)
        }
        prim.color = base

        var em: [Float] = [0, 0, 0]
        if let e = mj.optJSONArray("emissiveFactor"), e.count >= 3 { em = [e.optFloat(0), e.optFloat(1), e.optFloat(2)] }
        if let es = ext?.optJSONObject("KHR_materials_emissive_strength") {
            let s = es.optFloat("emissiveStrength", 1)
            em = em.map { $0 * s }
        }
        prim.emissive = em
        prim.texEm = doc.texture(mj.optJSONObject("emissiveTexture"))
        prim.texOcc = doc.texture(mj.optJSONObject("occlusionTexture"))
        if prim.texEm != 0 && em == [0, 0, 0] { prim.emissive = [1, 1, 1] }

        switch mj.optString("alphaMode", "OPAQUE") {
        case "MASK": prim.cutoff = mj.optFloat("alphaCutoff", 0.5)
        case "BLEND": prim.blend = true
        default: break
        }
        if ext?.has("KHR_materials_unlit") == true { prim.unlit = 1 }
    }

    // MARK: - OBJ

    private static func parseObj(_ data: Data) -> GlbModel? {
        guard let text = String(data: data, encoding: .utf8) ?? String(data: data, encoding: .isoLatin1) else { return nil }
        var vp: [Float] = [], vcol: [Float] = [], vt: [Float] = [], vn: [Float] = []
        var anyColor = false
        struct Key: Hashable { var v: Int; var t: Int; var n: Int }
        var map: [Key: UInt32] = [:]
        var P: [Float] = [], N: [Float] = [], U: [Float] = [], C: [Float] = []
        var idx: [UInt32] = []
        var hasN = false

        func resolve(_ s: Substring, _ count: Int) -> Int {
            guard let i = Int(s) else { return -1 }
            return i > 0 ? i - 1 : (i < 0 ? count + i : -1)
        }

        text.enumerateLines { line, _ in
            let parts = line.split(whereSeparator: { $0 == " " || $0 == "\t" })
            guard let head = parts.first else { return }
            switch head {
            case "v":
                guard parts.count >= 4, let x = Float(parts[1]), let y = Float(parts[2]), let z = Float(parts[3]) else { return }
                vp.append(x); vp.append(y); vp.append(z)
                if parts.count >= 7, let r = Float(parts[4]), let g = Float(parts[5]), let b = Float(parts[6]) {
                    vcol.append(r); vcol.append(g); vcol.append(b); anyColor = true
                } else {
                    vcol.append(1); vcol.append(1); vcol.append(1)
                }
            case "vn":
                if parts.count >= 4, let x = Float(parts[1]), let y = Float(parts[2]), let z = Float(parts[3]) {
                    vn.append(x); vn.append(y); vn.append(z)
                }
            case "vt":
                if parts.count >= 3, let u = Float(parts[1]), let v = Float(parts[2]) { vt.append(u); vt.append(1 - v) }
            case "f":
                var corner: [UInt32] = []
                for tok in parts.dropFirst() {
                    let f = tok.split(separator: "/", omittingEmptySubsequences: false)
                    let vi = resolve(f[0], vp.count / 3)
                    guard vi >= 0, vi < vp.count / 3 else { continue }
                    let ti = f.count > 1 ? resolve(f[1], vt.count / 2) : -1
                    let ni = f.count > 2 ? resolve(f[2], vn.count / 3) : -1
                    let key = Key(v: vi, t: ti, n: ni)
                    if let id = map[key] { corner.append(id); continue }
                    let id = UInt32(P.count / 3)
                    map[key] = id
                    P.append(vp[vi * 3]); P.append(vp[vi * 3 + 1]); P.append(vp[vi * 3 + 2])
                    if ni >= 0, ni < vn.count / 3 {
                        N.append(vn[ni * 3]); N.append(vn[ni * 3 + 1]); N.append(vn[ni * 3 + 2]); hasN = true
                    } else { N.append(0); N.append(0); N.append(0) }
                    if ti >= 0, ti < vt.count / 2 { U.append(vt[ti * 2]); U.append(vt[ti * 2 + 1]) } else { U.append(0); U.append(0) }
                    C.append(vcol[vi * 3]); C.append(vcol[vi * 3 + 1]); C.append(vcol[vi * 3 + 2]); C.append(1)
                    corner.append(id)
                }
                if corner.count >= 3 {
                    for k in 1..<(corner.count - 1) { idx.append(corner[0]); idx.append(corner[k]); idx.append(corner[k + 1]) }
                }
            default: break
            }
        }
        guard !idx.isEmpty, !P.isEmpty else { lastError = "OBJ has no faces"; return nil }
        if !hasN { N = genNormals(P, idx) }
        else {
            // fill any vertex that had no normal
            let fresh = genNormals(P, idx)
            for i in 0..<(N.count / 3) where N[i * 3] == 0 && N[i * 3 + 1] == 0 && N[i * 3 + 2] == 0 {
                N[i * 3] = fresh[i * 3]; N[i * 3 + 1] = fresh[i * 3 + 1]; N[i * 3 + 2] = fresh[i * 3 + 2]
            }
        }
        var bounds = Bounds()
        var prim = makePrim(P, N, U, C, idx, mode: GLenum(GL_TRIANGLES), bounds: &bounds)
        prim.color = anyColor ? [1, 1, 1, 1] : [0.78, 0.8, 0.86, 1]
        prim.metal = 0; prim.rough = 0.8
        prim.unlit = anyColor ? 1 : 0
        let m = GlbModel()
        m.prims = [prim]
        m.finishNormalize(bounds)
        return m
    }

    // MARK: - geometry helpers

    private static func triangles(_ idx: [UInt32], mode: Int) -> [UInt32] {
        switch mode {
        case 5:
            var out: [UInt32] = []
            if idx.count >= 3 {
                out.reserveCapacity((idx.count - 2) * 3)
                for i in 0..<(idx.count - 2) {
                    if i % 2 == 0 { out.append(idx[i]); out.append(idx[i + 1]); out.append(idx[i + 2]) }
                    else { out.append(idx[i + 1]); out.append(idx[i]); out.append(idx[i + 2]) }
                }
            }
            return out
        case 6:
            var out: [UInt32] = []
            if idx.count >= 3 {
                for i in 1..<(idx.count - 1) { out.append(idx[0]); out.append(idx[i]); out.append(idx[i + 1]) }
            }
            return out
        default:
            return Array(idx.prefix(idx.count / 3 * 3))
        }
    }

    private static func genNormals(_ p: [Float], _ idx: [UInt32]) -> [Float] {
        var n = [Float](repeating: 0, count: p.count)
        var i = 0
        while i + 2 < idx.count {
            let a = Int(idx[i]) * 3, b = Int(idx[i + 1]) * 3, c = Int(idx[i + 2]) * 3
            if a + 2 < p.count, b + 2 < p.count, c + 2 < p.count {
                let ux = p[b] - p[a], uy = p[b + 1] - p[a + 1], uz = p[b + 2] - p[a + 2]
                let vx = p[c] - p[a], vy = p[c + 1] - p[a + 1], vz = p[c + 2] - p[a + 2]
                let nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx
                n[a] += nx; n[a + 1] += ny; n[a + 2] += nz
                n[b] += nx; n[b + 1] += ny; n[b + 2] += nz
                n[c] += nx; n[c + 1] += ny; n[c + 2] += nz
            }
            i += 3
        }
        var v = 0
        while v + 2 < n.count {
            let l = (n[v] * n[v] + n[v + 1] * n[v + 1] + n[v + 2] * n[v + 2]).squareRoot()
            if l > 1e-12 { n[v] /= l; n[v + 1] /= l; n[v + 2] /= l } else { n[v] = 0; n[v + 1] = 1; n[v + 2] = 0 }
            v += 3
        }
        return n
    }

    /// Interleaves pos(3) normal(3) uv(2) colour(4) and uploads. Indices are 16-bit when possible.
    private static func makePrim(_ P: [Float], _ N: [Float], _ U: [Float], _ C: [Float], _ idx: [UInt32],
                                 mode: GLenum, bounds: inout Bounds) -> Prim {
        let n = P.count / 3
        var verts = [Float]()
        verts.reserveCapacity(n * 12)
        for i in 0..<n {
            let x = P[i * 3], y = P[i * 3 + 1], z = P[i * 3 + 2]
            if x.isFinite && y.isFinite && z.isFinite { bounds.add(x, y, z) }
            verts.append(x); verts.append(y); verts.append(z)
            verts.append(N[i * 3]); verts.append(N[i * 3 + 1]); verts.append(N[i * 3 + 2])
            verts.append(U[i * 2]); verts.append(U[i * 2 + 1])
            verts.append(C[i * 4]); verts.append(C[i * 4 + 1]); verts.append(C[i * 4 + 2]); verts.append(C[i * 4 + 3])
        }
        var prim = Prim()
        prim.count = GLsizei(idx.count)
        prim.mode = mode
        if cpuOnly {
            prim.verts = verts
            prim.cpuIdx = idx
            prim.indexType = n <= 65535 ? GLenum(GL_UNSIGNED_SHORT) : GLenum(GL_UNSIGNED_INT)
            return prim
        }
        var vbo = GLuint(0)
        glGenBuffers(1, &vbo)
        glBindBuffer(GLenum(GL_ARRAY_BUFFER), vbo)
        verts.withUnsafeBufferPointer { ptr in
            glBufferData(GLenum(GL_ARRAY_BUFFER), MemoryLayout<Float>.size * verts.count, ptr.baseAddress, GLenum(GL_STATIC_DRAW))
        }
        prim.vbo = vbo
        if keepCPU { prim.verts = verts }
        var ibo = GLuint(0)
        glGenBuffers(1, &ibo)
        glBindBuffer(GLenum(GL_ELEMENT_ARRAY_BUFFER), ibo)
        if n <= 65535 {
            let small = idx.map { UInt16(truncatingIfNeeded: $0) }
            prim.indexType = GLenum(GL_UNSIGNED_SHORT)
            small.withUnsafeBufferPointer { ptr in
                glBufferData(GLenum(GL_ELEMENT_ARRAY_BUFFER), MemoryLayout<UInt16>.size * small.count, ptr.baseAddress, GLenum(GL_STATIC_DRAW))
            }
        } else {
            prim.indexType = GLenum(GL_UNSIGNED_INT)
            idx.withUnsafeBufferPointer { ptr in
                glBufferData(GLenum(GL_ELEMENT_ARRAY_BUFFER), MemoryLayout<UInt32>.size * idx.count, ptr.baseAddress, GLenum(GL_STATIC_DRAW))
            }
        }
        prim.ibo = ibo
        return prim
    }

    private func finishNormalize(_ b: Bounds) {
        let cx = (b.mn[0] + b.mx[0]) / 2, cy = (b.mn[1] + b.mx[1]) / 2, cz = (b.mn[2] + b.mx[2]) / 2
        let span = max(b.mx[0] - b.mn[0], max(b.mx[1] - b.mn[1], b.mx[2] - b.mn[2]))
        let s: Float = span > 0.0001 ? 1.4 / span : 1
        normalize = [s, -cx, -cy, -cz]
        baseY = (b.mn[1] - cy) * s
    }

    // MARK: - drawing

    static let vertexSource = """
attribute vec3 aPos;
attribute vec3 aNormal;
attribute vec2 aUv;
attribute vec4 aCol;
uniform mat4 uVP;
uniform mat4 uModel;
varying vec3 vN;
varying vec3 vW;
varying vec2 vUv;
varying vec4 vCol;
void main() {
    vec4 w = uModel * vec4(aPos, 1.0);
    gl_Position = uVP * w;
    gl_PointSize = 3.0;
    vW = w.xyz;
    vec3 n = uModel[0].xyz * aNormal.x + uModel[1].xyz * aNormal.y + uModel[2].xyz * aNormal.z;
    vN = dot(n, n) > 1e-8 ? normalize(n) : vec3(0.0, 1.0, 0.0);
    vUv = aUv;
    vCol = aCol;
}
"""

    /// Lightweight PBR: GGX / Smith / Schlick, two lights + a procedural sky/ground environment for
    /// diffuse and rough-blurred reflections. Colours are linearised in, gamma-encoded out.
    static let fragmentSource = """
precision highp float;
varying vec3 vN;
varying vec3 vW;
varying vec2 vUv;
varying vec4 vCol;
uniform vec4 uColor;
uniform vec3 uEmis;
uniform vec3 uEye;
uniform float uMetal, uRough, uCutoff, uUnlit;
uniform vec4 uHas;   // x base tex, y metal-rough tex, z emissive tex, w occlusion tex
uniform vec4 uOpt;   // x environment on, y metallic reflectivity on, z view mode, w occlusion strength
uniform sampler2D uTexOcc;
uniform sampler2D uTexBase;
uniform sampler2D uTexMR;
uniform sampler2D uTexEm;
const float PI = 3.14159265;
const vec3 L1 = vec3(0.4170, 0.6672, 0.6672);
const vec3 L2 = vec3(-0.8704, 0.2176, 0.4352);

vec3 envC(vec3 d, float r) {
    float h = d.y * 0.5 + 0.5;
    vec3 c = mix(vec3(0.14, 0.13, 0.15), vec3(0.78, 0.80, 0.84), smoothstep(0.0, 0.5, h));
    c = mix(c, vec3(0.55, 0.68, 0.95), smoothstep(0.5, 1.0, h));
    float sun = pow(max(dot(d, L1), 0.0), mix(150.0, 5.0, r)) * mix(8.0, 0.6, r);
    return c + vec3(1.0, 0.93, 0.82) * sun;
}

vec3 brdf(vec3 N, vec3 V, vec3 L, vec3 diffC, vec3 F0, float r) {
    vec3 H = normalize(V + L);
    float NdL = max(dot(N, L), 0.0);
    float NdV = max(dot(N, V), 0.001);
    float NdH = max(dot(N, H), 0.0);
    float VdH = max(dot(V, H), 0.0);
    float a = r * r;
    float a2 = a * a;
    float dd = NdH * NdH * (a2 - 1.0) + 1.0;
    float D = a2 / (PI * dd * dd + 0.0001);
    float k = (r + 1.0) * (r + 1.0) / 8.0;
    float G = (NdL / (NdL * (1.0 - k) + k)) * (NdV / (NdV * (1.0 - k) + k));
    vec3 F = F0 + (1.0 - F0) * pow(1.0 - VdH, 5.0);
    vec3 spec = D * G * F / max(4.0 * NdV * NdL, 0.001);
    return ((1.0 - F) * diffC / PI + spec) * NdL;
}

void main() {
    float a = uColor.a * vCol.a;
    vec3 tint = uColor.rgb * pow(max(vCol.rgb, vec3(0.0)), vec3(2.2));
    vec3 alb = tint;
    if (uHas.x > 0.5) {
        vec4 t = texture2D(uTexBase, vUv);
        a *= t.a;
        alb *= pow(clamp(t.rgb / max(t.a, 0.001), 0.0, 1.0), vec3(2.2));
    }
    if (uCutoff >= 0.0) {
        if (a < uCutoff) { discard; }
        a = 1.0;
    }
    float metal = uMetal * uOpt.y;
    float rough = uRough;
    float ao = 1.0;
    if (uHas.w > 0.5) { ao = mix(1.0, texture2D(uTexOcc, vUv).r, uOpt.w); }
    if (uHas.y > 0.5) {
        vec4 m = texture2D(uTexMR, vUv);
        rough *= m.g;
        metal *= m.b * uOpt.y;
    }
    rough = clamp(rough, 0.04, 1.0);
    metal = clamp(metal, 0.0, 1.0);

    vec3 N = normalize(vN);
    vec3 V = normalize(uEye - vW);
    if (dot(N, V) < 0.0) { N = -N; }
    float NdV = max(dot(N, V), 0.001);

    vec3 F0 = mix(vec3(0.04), alb, metal);
    vec3 diffC = alb * (1.0 - metal);
    vec3 col = brdf(N, V, L1, diffC, F0, rough) * vec3(3.2, 3.0, 2.8) * 1.0
             + brdf(N, V, L2, diffC, F0, rough) * vec3(0.9, 1.0, 1.3);
    vec3 R = reflect(-V, N);
    vec3 Fr = F0 + (max(vec3(1.0 - rough), F0) - F0) * pow(1.0 - NdV, 5.0);
    if (uOpt.x > 0.5) {
        col += diffC * envC(N, 1.0) * 0.8 * ao;
        col += envC(R, rough) * Fr * (1.0 - 0.5 * rough) * ao;
    } else {
        col += diffC * 0.3 * ao;
    }
    vec3 em = uEmis;
    if (uHas.z > 0.5) { em *= pow(texture2D(uTexEm, vUv).rgb, vec3(2.2)); }
    col += em;
    col = mix(col, alb + em, uUnlit);
    if (uOpt.z > 0.5) {   // PBR texture viewer
        vec3 v = alb;
        if (uOpt.z > 1.5) { v = vec3(rough); }
        if (uOpt.z > 2.5) { v = vec3(metal); }
        if (uOpt.z > 3.5) { v = vec3(ao); }
        if (uOpt.z > 4.5) { v = em; }
        gl_FragColor = vec4(pow(max(v, vec3(0.0)), vec3(1.0 / 2.2)) * a, a);
        return;
    }
    col = col * (1.0 + col / 6.0) / (1.0 + col);          // soft highlight roll-off
    col = pow(max(col, vec3(0.0)), vec3(1.0 / 2.2));
    gl_FragColor = vec4(col * a, a);
}
"""

    /// Draws every part with `program` (built from vertexSource / fragmentSource).
    func draw(_ program: GLProgram, eye: [Float], env: Bool = true, metal: Bool = true, view: Int = 0, ao: Float = 1) {
        program.use()
        program.setVec4("uOpt", env ? 1 : 0, metal ? 1 : 0, Float(view), ao)
        program.setVec3("uEye", eye[0], eye[1], eye[2])
        let aPos = glGetAttribLocation(program.handle, "aPos")
        let aNormal = glGetAttribLocation(program.handle, "aNormal")
        let aUv = glGetAttribLocation(program.handle, "aUv")
        let aCol = glGetAttribLocation(program.handle, "aCol")
        let stride = GLsizei(MemoryLayout<Float>.size * 12)
        func off(_ f: Int) -> UnsafeRawPointer? { UnsafeRawPointer(bitPattern: MemoryLayout<Float>.size * f) }
        for prim in prims {
            glBindBuffer(GLenum(GL_ARRAY_BUFFER), prim.vbo)
            glBindBuffer(GLenum(GL_ELEMENT_ARRAY_BUFFER), prim.ibo)
            if aPos >= 0 {
                glEnableVertexAttribArray(GLuint(aPos))
                glVertexAttribPointer(GLuint(aPos), 3, GLenum(GL_FLOAT), GLboolean(GL_FALSE), stride, nil)
            }
            if aNormal >= 0 {
                glEnableVertexAttribArray(GLuint(aNormal))
                glVertexAttribPointer(GLuint(aNormal), 3, GLenum(GL_FLOAT), GLboolean(GL_FALSE), stride, off(3))
            }
            if aUv >= 0 {
                glEnableVertexAttribArray(GLuint(aUv))
                glVertexAttribPointer(GLuint(aUv), 2, GLenum(GL_FLOAT), GLboolean(GL_FALSE), stride, off(6))
            }
            if aCol >= 0 {
                glEnableVertexAttribArray(GLuint(aCol))
                glVertexAttribPointer(GLuint(aCol), 4, GLenum(GL_FLOAT), GLboolean(GL_FALSE), stride, off(8))
            }
            program.setVec4("uColor", prim.color[0], prim.color[1], prim.color[2], prim.color[3])
            program.setVec3("uEmis", prim.emissive[0], prim.emissive[1], prim.emissive[2])
            program.setFloat("uMetal", prim.metal)
            program.setFloat("uRough", prim.rough)
            program.setFloat("uCutoff", prim.cutoff)
            program.setFloat("uUnlit", prim.unlit)
            program.setVec4("uHas", prim.texBase != 0 ? 1 : 0, prim.texMR != 0 ? 1 : 0, prim.texEm != 0 ? 1 : 0, prim.texOcc != 0 ? 1 : 0)
            if prim.texBase != 0 { program.setTexture("uTexBase", prim.texBase, 0) }
            if prim.texMR != 0 { program.setTexture("uTexMR", prim.texMR, 1) }
            if prim.texEm != 0 { program.setTexture("uTexEm", prim.texEm, 2) }
            if prim.texOcc != 0 { program.setTexture("uTexOcc", prim.texOcc, 3) }
            if prim.blend {
                glEnable(GLenum(GL_BLEND))
                glBlendFunc(GLenum(GL_ONE), GLenum(GL_ONE_MINUS_SRC_ALPHA))
                glDepthMask(GLboolean(GL_FALSE))
            } else {
                glDisable(GLenum(GL_BLEND))
                glDepthMask(GLboolean(GL_TRUE))
            }
            glDrawElements(prim.mode, prim.count, prim.indexType, nil)
            if aPos >= 0 { glDisableVertexAttribArray(GLuint(aPos)) }
            if aNormal >= 0 { glDisableVertexAttribArray(GLuint(aNormal)) }
            if aUv >= 0 { glDisableVertexAttribArray(GLuint(aUv)) }
            if aCol >= 0 { glDisableVertexAttribArray(GLuint(aCol)) }
        }
        glDepthMask(GLboolean(GL_TRUE))
        glDisable(GLenum(GL_BLEND))
        glActiveTexture(GLenum(GL_TEXTURE0))
    }
}
