import Foundation
import Metal
import UIKit
import ImageIO

//  Stage 7a: VDB density volumes in Metal (port of SceneRenderer.drawVdbLayer + the GL ray-march shader).
//  VdbVolume is CPU-only already. The 128^3 lattice is packed as a 2048x1024 atlas (16x8 slices of 128x128),
//  exactly like GL, so the sampling maths is identical.

enum MetalVolumeSL {
    static let source = MetalSL.header + """
struct VolU {
    float4 inv0; float4 inv1; float4 inv2; float4 inv3;
    float4 mvp0; float4 mvp1; float4 mvp2; float4 mvp3;
    float4 bnd;     // uB.xyz
    float4 color;   // uColor
    float4 prm;     // dens, bright, envOn, surround
    float4 flg;     // useDepth
    float4 lp0; float4 lp1; float4 lp2;   // light ball: xyz local pos, w radius
    float4 lc0; float4 lc1; float4 lc2;   // light color * intensity
    float4 la0; float4 la1; float4 la2;   // atmosphere color * amount
    float4 lcnt;                          // x = light count
    float4 edge;                          // rgb edge colour, a = amount
};
constexpr sampler volDepthS(coord::normalized, address::clamp_to_edge, filter::nearest);

float3 volEnvAt(texture2d<float> env, float3 dir) {
    dir = normalize(dir);
    float2 uv = float2(atan2(dir.z, dir.x) * 0.15915494 + 0.5, asin(clamp(dir.y, -1.0, 1.0)) * 0.31830989 + 0.5);
    return env.sample(linearClamp, uv).rgb;
}
float3 volSurroundAt(texture2d<float> scn, float2 uv) {
    float3 a = float3(0.0);
    for (int i = 0; i < 8; i++) {
        float ang = float(i) * 0.7853982;
        float2 q = clamp(uv + float2(cos(ang), sin(ang)) * 0.12, 0.0, 1.0);
        a += scn.sample(linearClamp, flipV(q)).rgb;
    }
    return a / 8.0;
}
float volSamp(texture2d<float> vol, float3 q) {
    q = clamp(q, 0.0, 1.0);
    float fz = q.z * 127.0;
    float z0 = floor(fz);
    float z1 = min(z0 + 1.0, 127.0);
    float2 xy = q.xy * 127.0 + 0.5;
    float2 t0 = (float2(fmod(z0, 16.0), floor(z0 / 16.0)) * 128.0 + xy) / float2(2048.0, 1024.0);
    float2 t1 = (float2(fmod(z1, 16.0), floor(z1 / 16.0)) * 128.0 + xy) / float2(2048.0, 1024.0);
    float s = mix(vol.sample(linearClamp, t0).r, vol.sample(linearClamp, t1).r, fz - z0);
    float3 e3 = min(q, 1.0 - q);
    float fade = smoothstep(0.0, 0.1, min(e3.x, min(e3.y, e3.z)));
    return s * s * fade;
}
float vH(float3 p) { p = fract(p * 0.3183099 + 0.1); p *= 17.0; return fract(p.x * p.y * p.z * (p.x + p.y + p.z)); }
float vN(float3 x) {
    float3 i = floor(x), f = fract(x); f = f * f * (3.0 - 2.0 * f);
    return mix(mix(mix(vH(i), vH(i + float3(1.0, 0.0, 0.0)), f.x), mix(vH(i + float3(0.0, 1.0, 0.0)), vH(i + float3(1.0, 1.0, 0.0)), f.x), f.y),
               mix(mix(vH(i + float3(0.0, 0.0, 1.0)), vH(i + float3(1.0, 0.0, 1.0)), f.x), mix(vH(i + float3(0.0, 1.0, 1.0)), vH(i + float3(1.0, 1.0, 1.0)), f.x), f.y), f.z);
}
// Henyey-Greenstein, normalised so an isotropic phase = 1
float vHG(float c, float g) { float g2 = g * g; return (1.0 - g2) / pow(max(1.0 + g2 - 2.0 * g * c, 1e-3), 1.5); }
// dual lobe: strong forward silver lining + soft back scatter
float vPhase(float c) { return mix(vHG(c, -0.2), vHG(c, 0.6), 0.35); }
fragment float4 vdbFragment(VOut in [[stage_in]], constant VolU& u [[buffer(0)]],
                            texture2d<float> vol [[texture(0)]], depth2d<float> dep [[texture(1)]],
                            texture2d<float> env [[texture(2)]], texture2d<float> scn [[texture(3)]]) {
    float4x4 inv = float4x4(u.inv0, u.inv1, u.inv2, u.inv3);
    float4x4 mvp = float4x4(u.mvp0, u.mvp1, u.mvp2, u.mvp3);
    float3 uB = u.bnd.xyz;
    float uDens = u.prm.x, uBright = u.prm.y, uEnvOn = u.prm.z, uSurround = u.prm.w;
    float2 ndc = in.uv * 2.0 - 1.0;
    float4 n4 = inv * float4(ndc, -1.0, 1.0);
    float4 f4 = inv * float4(ndc, 1.0, 1.0);
    float3 o = n4.xyz / n4.w;
    float3 d = f4.xyz / f4.w - o;
    float3 h = uB * 0.5;
    float3 rd = 1.0 / (d + float3(1e-6));
    float3 t1 = (-h - o) * rd;
    float3 t2 = (h - o) * rd;
    float3 tn = min(t1, t2);
    float3 tf = max(t1, t2);
    float t0 = max(max(max(tn.x, tn.y), tn.z), 0.0);
    float t3 = min(min(tf.x, tf.y), tf.z);
    if (t3 <= t0) { return float4(0.0); }
    float sceneZ = u.flg.x > 0.5 ? dep.sample(volDepthS, flipV(in.uv)) : 1.0;
    float NS = clamp(u.flg.z, 16.0, 160.0);
    float dt = (t3 - t0) / NS;
    float seg = dt * length(d) / max(max(uB.x, uB.y), uB.z) * 8.0;
    float jit = fract(52.9829189 * fract(dot(in.pos.xy, float2(0.06711056, 0.00583715))));   // interleaved gradient noise: kills banding/streaks
    float3 L = normalize(float3(0.3, 1.0, 0.4)) * 0.06;
    float T = 1.0;
    float3 col = float3(0.0);
    float3 amb = float3(0.0);
    if (uEnvOn > 0.5) { amb = 0.5 * (volEnvAt(env, d) + volEnvAt(env, float3(0.0, 1.0, 0.0))); }
    if (uSurround > 0.5) { amb += volSurroundAt(scn, in.uv); }
    float ambOn = (uEnvOn > 0.5 || uSurround > 0.5) ? 1.0 : 0.0;
    for (int i = 0; i < int(NS); i++) {
        float3 pos = o + d * (t0 + (float(i) + jit) * dt);
        if (sceneZ < 1.0) {
            float4 c = mvp * float4(pos, 1.0);
            if (c.z / c.w * 0.5 + 0.5 > sceneZ - 0.0002) { break; }
        }
        float3 q = pos / uB + 0.5;
        float raw = max(volSamp(vol, q), 0.0);
        if (u.lcnt.y > 0.5 && raw > 0.002) {
            // cloud detail: the 128^3 lattice only holds the big shape. Billowy + wispy noise eats the edges
            // (Schneider-style erosion: thin parts vanish first, the dense core survives) so the surface is crisp
            // cauliflower instead of a soft blob, at any zoom.
            float3 wq = q * float3(9.0, 7.0, 9.0) + float3(3.1, 1.7, 5.3);
            float dn = vN(wq) * 0.50 + vN(wq * 2.3) * 0.30 + vN(wq * 5.1) * 0.20;
            float er = dn * 0.42;
            raw = clamp((raw - er * (1.0 - raw * 0.35)) / (1.0 - er), 0.0, 1.0);
        }
        float den = pow(raw, u.flg.w) * uDens;
        if (den > 0.002) {
            float lt = volSamp(vol, q + L * 1.5) + volSamp(vol, q + L * 4.0);
            if (u.lcnt.y > 0.5) { lt += volSamp(vol, q + L * 9.0) * 1.5; }
            float3 lightSum = float3(0.0);
            float3 atmSum = float3(0.0);
            for (int k = 0; k < 3; k++) {
                if (float(k) >= u.lcnt.x) { break; }
                float4 lp = k == 0 ? u.lp0 : (k == 1 ? u.lp1 : u.lp2);
                float3 lc = k == 0 ? u.lc0.xyz : (k == 1 ? u.lc1.xyz : u.lc2.xyz);
                float3 la = k == 0 ? u.la0.xyz : (k == 1 ? u.la1.xyz : u.la2.xyz);
                float3 dl = lp.xyz - pos;
                float r2 = lp.w * lp.w;
                float att = r2 / (r2 + dot(dl, dl));
                float occ = 0.0;
                for (int j = 0; j < 4; j++) { occ += volSamp(vol, (pos + dl * (0.1 + 0.2 * float(j))) / uB + 0.5); }
                lightSum += lc * att * exp(-occ * uDens * 1.2 * u.flg.y);
                atmSum += la * att;
            }
            float baseK = u.lcnt.x > 0.5 ? 0.35 : 1.0;
            float sh = exp(-lt * uDens * 2.4 * u.flg.y);
            float ex = exp(-den * seg);
            float3 shade = ((0.3 + 0.8 * sh) * (1.0 - 0.6 * ambOn) + ambOn * (0.15 + 1.2 * sh) * amb) * baseK;
            if (u.lcnt.y > 0.5) {
                // Photoreal cumulus lighting: 5-tap sun march with growing steps -> Beer-Lambert, three-octave
                // multiple-scattering (keeps shadowed cores lit instead of black), dual-lobe HG phase (bright silver
                // rims toward the sun), powder term (dark thin edges), sky-blue ambient that fades toward the base.
                float3 Ls = normalize(float3(0.3, 1.0, 0.4));
                float3 Lq = normalize(Ls / uB);
                float od = 0.0, acc = 0.0;
                float stps[5] = { 0.012, 0.025, 0.05, 0.10, 0.20 };
                for (int k = 0; k < 5; k++) { acc += stps[k]; od += volSamp(vol, q + Lq * acc) * stps[k]; }
                od *= uDens * 5.5 * u.flg.y;
                float cosT = clamp(dot(normalize(d), Ls), -1.0, 1.0);
                float sunE = 0.0, ma = 1.0, mb = 1.0, mc = 1.0;
                for (int oc = 0; oc < 3; oc++) { sunE += ma * exp(-od * mb) * vPhase(cosT * mc); ma *= 0.5; mb *= 0.5; mc *= 0.5; }
                float powder = mix(1.0, 1.0 - exp(-raw * 7.0), 0.55);
                float hgt = clamp((q.y - 0.12) * 1.5, 0.0, 1.0);
                float3 skyAmb = mix(float3(0.30, 0.38, 0.54), float3(0.66, 0.75, 0.92), hgt);
                float sunA = exp(-od);
                shade = float3(1.0, 0.965, 0.90) * sunE * powder * 0.46 + skyAmb * (0.85 + 0.3 * sunA);
                if (ambOn > 0.5) { shade *= (0.6 + 0.55 * amb); }
                shade += float3(0.10) * pow(sunA, 3.0) * (1.0 - clamp(den, 0.0, 1.0));
                shade = shade / (1.0 + shade * 0.12);
            }
            shade += lightSum * 2.0 + atmSum;
            float3 cTint = mix(u.color.rgb, u.edge.rgb, u.edge.a * (1.0 - clamp(den * 1.6, 0.0, 1.0)));
            col += T * (1.0 - ex) * cTint * shade * uBright;
            T *= ex;
            if (T < 0.02) { break; }
        }
    }
    return float4(col * u.bnd.w, (1.0 - T) * u.bnd.w);
}
"""
}

struct VolU {
    var inv0 = SIMD4<Float>(), inv1 = SIMD4<Float>(), inv2 = SIMD4<Float>(), inv3 = SIMD4<Float>()
    var mvp0 = SIMD4<Float>(), mvp1 = SIMD4<Float>(), mvp2 = SIMD4<Float>(), mvp3 = SIMD4<Float>()
    var bnd = SIMD4<Float>()
    var color = SIMD4<Float>()
    var prm = SIMD4<Float>()
    var flg = SIMD4<Float>()
    var lp0 = SIMD4<Float>(), lp1 = SIMD4<Float>(), lp2 = SIMD4<Float>()
    var lc0 = SIMD4<Float>(), lc1 = SIMD4<Float>(), lc2 = SIMD4<Float>()
    var la0 = SIMD4<Float>(), la1 = SIMD4<Float>(), la2 = SIMD4<Float>()
    var lcnt = SIMD4<Float>()
    var edge = SIMD4<Float>()
}

final class MetalVolumeRenderer {
    private let core: MetalCore
    private let passes: MetalPasses
    private var lib: MTLLibrary?
    private var atlas: [String: MTLTexture] = [:]
    private var envs: [String: MTLTexture] = [:]
    private var dummyTex: MTLTexture?
    private var dummyDepth: MTLTexture?

    init(_ core: MetalCore, _ passes: MetalPasses) {
        self.core = core
        self.passes = passes
        lib = try? core.device.makeLibrary(source: MetalVolumeSL.source, options: nil)
        let td = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .rgba8Unorm, width: 1, height: 1, mipmapped: false)
        td.usage = .shaderRead
        dummyTex = core.device.makeTexture(descriptor: td)
        var px: [UInt8] = [0, 0, 0, 255]
        dummyTex?.replace(region: MTLRegionMake2D(0, 0, 1, 1), mipmapLevel: 0, withBytes: &px, bytesPerRow: 4)
        let dd = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .depth32Float, width: 1, height: 1, mipmapped: false)
        dd.usage = .shaderRead
        dd.storageMode = .private
        dummyDepth = core.device.makeTexture(descriptor: dd)
    }

    var ready: Bool { lib != nil && dummyTex != nil && dummyDepth != nil }

    func trimMemory() { atlas.removeAll(); envs.removeAll() }

    static func inv4(_ m: [Float]) -> [Float] {
        var inv = [Float](repeating: 0, count: 16)
        inv[0] = m[5]*m[10]*m[15] - m[5]*m[11]*m[14] - m[9]*m[6]*m[15] + m[9]*m[7]*m[14] + m[13]*m[6]*m[11] - m[13]*m[7]*m[10]
        inv[4] = -m[4]*m[10]*m[15] + m[4]*m[11]*m[14] + m[8]*m[6]*m[15] - m[8]*m[7]*m[14] - m[12]*m[6]*m[11] + m[12]*m[7]*m[10]
        inv[8] = m[4]*m[9]*m[15] - m[4]*m[11]*m[13] - m[8]*m[5]*m[15] + m[8]*m[7]*m[13] + m[12]*m[5]*m[11] - m[12]*m[7]*m[9]
        inv[12] = -m[4]*m[9]*m[14] + m[4]*m[10]*m[13] + m[8]*m[5]*m[14] - m[8]*m[6]*m[13] - m[12]*m[5]*m[10] + m[12]*m[6]*m[9]
        inv[1] = -m[1]*m[10]*m[15] + m[1]*m[11]*m[14] + m[9]*m[2]*m[15] - m[9]*m[3]*m[14] - m[13]*m[2]*m[11] + m[13]*m[3]*m[10]
        inv[5] = m[0]*m[10]*m[15] - m[0]*m[11]*m[14] - m[8]*m[2]*m[15] + m[8]*m[3]*m[14] + m[12]*m[2]*m[11] - m[12]*m[3]*m[10]
        inv[9] = -m[0]*m[9]*m[15] + m[0]*m[11]*m[13] + m[8]*m[1]*m[15] - m[8]*m[3]*m[13] - m[12]*m[1]*m[11] + m[12]*m[3]*m[9]
        inv[13] = m[0]*m[9]*m[14] - m[0]*m[10]*m[13] - m[8]*m[1]*m[14] + m[8]*m[2]*m[13] + m[12]*m[1]*m[10] - m[12]*m[2]*m[9]
        inv[2] = m[1]*m[6]*m[15] - m[1]*m[7]*m[14] - m[5]*m[2]*m[15] + m[5]*m[3]*m[14] + m[13]*m[2]*m[7] - m[13]*m[3]*m[6]
        inv[6] = -m[0]*m[6]*m[15] + m[0]*m[7]*m[14] + m[4]*m[2]*m[15] - m[4]*m[3]*m[14] - m[12]*m[2]*m[7] + m[12]*m[3]*m[6]
        inv[10] = m[0]*m[5]*m[15] - m[0]*m[7]*m[13] - m[4]*m[1]*m[15] + m[4]*m[3]*m[13] + m[12]*m[1]*m[7] - m[12]*m[3]*m[5]
        inv[14] = -m[0]*m[5]*m[14] + m[0]*m[6]*m[13] + m[4]*m[1]*m[14] - m[4]*m[2]*m[13] - m[12]*m[1]*m[6] + m[12]*m[2]*m[5]
        inv[3] = -m[1]*m[6]*m[11] + m[1]*m[7]*m[10] + m[5]*m[2]*m[11] - m[5]*m[3]*m[10] - m[9]*m[2]*m[7] + m[9]*m[3]*m[6]
        inv[7] = m[0]*m[6]*m[11] - m[0]*m[7]*m[10] - m[4]*m[2]*m[11] + m[4]*m[3]*m[10] + m[8]*m[2]*m[7] - m[8]*m[3]*m[6]
        inv[11] = -m[0]*m[5]*m[11] + m[0]*m[7]*m[9] + m[4]*m[1]*m[11] - m[4]*m[3]*m[9] - m[8]*m[1]*m[7] + m[8]*m[3]*m[5]
        inv[15] = m[0]*m[5]*m[10] - m[0]*m[6]*m[9] - m[4]*m[1]*m[10] + m[4]*m[2]*m[9] + m[8]*m[1]*m[6] - m[8]*m[2]*m[5]
        let det = m[0]*inv[0] + m[1]*inv[4] + m[2]*inv[8] + m[3]*inv[12]
        if abs(det) < 1e-12 { return [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1] }
        return inv.map { $0 / det }
    }

    private static func mul4(_ a: [Float], _ b: [Float]) -> [Float] {
        var o = [Float](repeating: 0, count: 16)
        for c in 0..<4 {
            for r in 0..<4 {
                var s: Float = 0
                for k in 0..<4 { s += a[k * 4 + r] * b[c * 4 + k] }
                o[c * 4 + r] = s
            }
        }
        return o
    }

    /// Density lattice -> 128^3 volume packed as a 16x8 atlas of 128x128 slices (same packing as GL).
    private func atlasTexture(_ path: String, _ vol: VdbVolume) -> MTLTexture? {
        if let t = atlas[path] { return t }
        guard let g = vol.grids.first, g.nx > 0, g.ny > 0, g.nz > 0 else { return nil }
        let n = 128
        var mx: Float = 0.000001
        for v in g.data where v.isFinite { mx = max(mx, v) }
        var px = [UInt8](repeating: 0, count: 2048 * 1024)
        for z in 0..<n { for y in 0..<n { for x in 0..<n {
            let d = vol.density(x * g.nx / n, y * g.ny / n, z * g.nz / n)
            let v = d.isFinite ? min(max(d / mx, 0), 1) : 0
            px[(z / 16 * 128 + y) * 2048 + (z % 16) * 128 + x] = UInt8(v.squareRoot() * 255)
        } } }
        let td = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .r8Unorm, width: 2048, height: 1024, mipmapped: false)
        td.usage = .shaderRead
        td.storageMode = .shared
        guard let t = core.device.makeTexture(descriptor: td) else { return nil }
        px.withUnsafeBytes {
            t.replace(region: MTLRegionMake2D(0, 0, 2048, 1024), mipmapLevel: 0, withBytes: $0.baseAddress!, bytesPerRow: 2048)
        }
        atlas[path] = t
        return t
    }

    /// Environment picture as an equirect texture (same loader as GL: ImageIO, max 1024 side).
    private func environmentTexture(_ path: String) -> MTLTexture? {
        if let t = envs[path] { return t }
        var made: MTLTexture?
        autoreleasepool {
            guard let src = CGImageSourceCreateWithURL(URL(fileURLWithPath: path) as CFURL, nil),
                  let cg = CGImageSourceCreateImageAtIndex(src, 0, nil) else { return }
            made = MetalModel.makeTexture(core, UIImage(cgImage: cg))
        }
        if let m = made { envs[path] = m }
        return made
    }

    /// Ray-marches volume layer `l` into `target` (the caller has cleared it). `depth` = the shared model depth
    /// buffer when occlusion applies, `sceneTex` = the scene so far (for "surroundings" light).
    func draw(_ l: Layer, path: String, time: Float, fov: Float, into target: MetalTarget,
              sceneTex: MTLTexture, depth: MTLTexture?, cb: MTLCommandBuffer, mmOverride: [Float]? = nil, accumulate: Bool = false) {
        guard ready, let vol = VdbVolume.load(path), let tex = atlasTexture(path, vol),
              let lb = lib, let pso = (accumulate
                ? passes.pipelineOver(fragment: "vdbFragment", library: lb, libKey: "vol", format: target.tex.pixelFormat)
                : passes.pipeline(fragment: "vdbFragment", library: lb, libKey: "vol", format: target.tex.pixelFormat)) else { return }
        let vp = MetalCam.vpForModel(l, fov: fov, time: time, width: target.width, height: target.height)
        let mm = mmOverride ?? MetalCam.modelMatrix(l, time: time, normalize: [1, 0, 0, 0])
        guard vp.count == 16, mm.count == 16 else { return }
        let mvp = MetalVolumeRenderer.mul4(vp, mm)
        let inv = MetalVolumeRenderer.inv4(mvp)

        var u = VolU()
        u.inv0 = SIMD4(inv[0], inv[1], inv[2], inv[3]); u.inv1 = SIMD4(inv[4], inv[5], inv[6], inv[7])
        u.inv2 = SIMD4(inv[8], inv[9], inv[10], inv[11]); u.inv3 = SIMD4(inv[12], inv[13], inv[14], inv[15])
        u.mvp0 = SIMD4(mvp[0], mvp[1], mvp[2], mvp[3]); u.mvp1 = SIMD4(mvp[4], mvp[5], mvp[6], mvp[7])
        u.mvp2 = SIMD4(mvp[8], mvp[9], mvp[10], mvp[11]); u.mvp3 = SIMD4(mvp[12], mvp[13], mvp[14], mvp[15])
        u.bnd = SIMD4(max(vol.bounds.0, 0.05) * 2, max(vol.bounds.1, 0.05) * 2, max(vol.bounds.2, 0.05) * 2, l.xf("vdbOpacity", 1))
        var envTex: MTLTexture? = nil
        if l.vdbEnv, let ep = (l.vdbEnvPath ?? (l.xf("cloud", 0) > 0.5 ? GlobalEnv.path : nil)), !ep.isEmpty { envTex = environmentTexture(ep) }
        let envOn: Float = envTex != nil ? 1 : 0
        let surOn: Float = (l.vdbEnv && l.vdbSurround) ? 1 : 0
        u.prm = SIMD4(l.vdbDens * R3D.g("vdbDens", 1), l.vdbBright * R3D.g("vdbBright", 1), envOn, surOn)
        let c = UInt32(bitPattern: l.vdbTint)
        u.color = SIMD4(Float((c >> 16) & 255) / 255, Float((c >> 8) & 255) / 255, Float(c & 255) / 255, 1)
        u.flg = SIMD4(depth != nil ? 1 : 0, l.xf("vdbShadow", 1), l.xf("vdbSteps", 56) * R3D.g("vdbQuality", 1), max(l.xf("vdbContrast", 1), 0.1))

        // light balls (3D Null layers flagged isLight): converted into this volume's local space
        let invM = MetalVolumeRenderer.inv4(mm)
        func rgb(_ c: UInt32) -> SIMD3<Float> { SIMD3(Float((c >> 16) & 255) / 255, Float((c >> 8) & 255) / 255, Float(c & 255) / 255) }
        var lp = [SIMD4<Float>](repeating: SIMD4<Float>(), count: 3), lc = lp, la = lp
        var nl = 0
        for L in Editor.scene.layers where L.isLight && L.visible && time >= L.start && time <= L.end && nl < 3 {
            let lt = L.editTime("x", time)
            let wx = L.p("x", lt), wy = L.p("y", lt), wz = Xf.worldZ(L, time)
            let px = invM[0] * wx + invM[4] * wy + invM[8] * wz + invM[12]
            let py = invM[1] * wx + invM[5] * wy + invM[9] * wz + invM[13]
            let pz = invM[2] * wx + invM[6] * wy + invM[10] * wz + invM[14]
            let sx = (invM[0] * invM[0] + invM[1] * invM[1] + invM[2] * invM[2]).squareRoot()
            lp[nl] = SIMD4(px, py, pz, max(L.xf("lightRad", 0.5) * sx, 0.01))
            let c = rgb(UInt32(bitPattern: L.vdbTint)) * L.xf("lightInt", 1)
            lc[nl] = SIMD4(c.x, c.y, c.z, 0)
            let a = rgb(UInt32(L.xf("atmCol", Float(0x6688FF)))) * L.xf("atmAmt", 0.3)
            la[nl] = SIMD4(a.x, a.y, a.z, 0)
            nl += 1
        }
        u.lp0 = lp[0]; u.lp1 = lp[1]; u.lp2 = lp[2]
        u.lc0 = lc[0]; u.lc1 = lc[1]; u.lc2 = lc[2]
        u.la0 = la[0]; u.la1 = la[1]; u.la2 = la[2]
        u.lcnt = SIMD4(Float(nl), l.xf("cloud", 0) > 0.5 ? 1 : 0, 0, 0)
        let ec = UInt32(l.xf("cEdgeOut", 16777215))
        u.edge = SIMD4(Float((ec >> 16) & 255) / 255, Float((ec >> 8) & 255) / 255, Float(ec & 255) / 255, l.xf("cEdge", 0))

        // only shade pixels inside the box's screen bounds (GL scissor; Metal's origin is top-left)
        let hb = [max(vol.bounds.0, 0.05), max(vol.bounds.1, 0.05), max(vol.bounds.2, 0.05)]
        var x0 = Float.greatestFiniteMagnitude, y0 = x0, x1 = -x0, y1 = -x0
        var ok = true
        for i in 0..<8 where ok {
            let x = (i & 1 == 0 ? -1 : 1) * hb[0], y = (i & 2 == 0 ? -1 : 1) * hb[1], z = (i & 4 == 0 ? -1 : 1) * hb[2]
            let w = mvp[3] * x + mvp[7] * y + mvp[11] * z + mvp[15]
            if w < 0.05 { ok = false; continue }
            let px = (mvp[0] * x + mvp[4] * y + mvp[8] * z + mvp[12]) / w
            let py = (mvp[1] * x + mvp[5] * y + mvp[9] * z + mvp[13]) / w
            x0 = min(x0, px); x1 = max(x1, px); y0 = min(y0, py); y1 = max(y1, py)
        }
        var scissor: MTLScissorRect? = nil
        if ok {
            let W = Float(target.width), H = Float(target.height)
            let fx0 = (x0 * 0.5 + 0.5) * W, fx1 = (x1 * 0.5 + 0.5) * W
            let fy0 = (y0 * 0.5 + 0.5) * H, fy1 = (y1 * 0.5 + 0.5) * H
            guard fx0.isFinite, fx1.isFinite, fy0.isFinite, fy1.isFinite else { return }
            let sx = max(0, Int(fx0) - 3), sy = max(0, Int(fy0) - 3)
            let ex = min(target.width, Int(fx1) + 3), ey = min(target.height, Int(fy1) + 3)
            guard ex > sx, ey > sy else { return }
            scissor = MTLScissorRect(x: sx, y: target.height - ey, width: ex - sx, height: ey - sy)
        }

        let setup: (MTLRenderCommandEncoder) -> Void = { enc in
            enc.setFragmentBytes(&u, length: MemoryLayout<VolU>.stride, index: 0)
            enc.setFragmentTexture(tex, index: 0)
            enc.setFragmentTexture(depth ?? self.dummyDepth, index: 1)
            enc.setFragmentTexture(envTex ?? self.dummyTex, index: 2)
            enc.setFragmentTexture(sceneTex, index: 3)
            if let s = scissor { enc.setScissorRect(s) }
        }
        if accumulate { passes.encodeLoad(cb, into: target, pso: pso, setup) } else { passes.encode(cb, into: target, pso: pso, setup) }
    }
}
