// AspectLayout.swift — letterboxing container (UI).
//
// Frames its subviews to the largest rect with the canvas aspect that fits
// the bounds — the Android FrameLayout + manual aspect math the preview
// area used. Setting `ratio` re-flows immediately.

import UIKit

final class AspectLayout: UIView, UIGestureRecognizerDelegate {

    /// width / height of the canvas (e.g. 1080/1920 = 0.5625).
    var ratio: CGFloat = 9.0 / 16.0 {
        didSet {
            if ratio != oldValue { setNeedsLayout() }
        }
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        clipsToBounds = true
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    override func layoutSubviews() {
        super.layoutSubviews()
        guard bounds.width > 1, bounds.height > 1, ratio > 0 else { return }
        var w = bounds.width
        var h = w / ratio
        if h > bounds.height {
            h = bounds.height
            w = h * ratio
        }
        let f = CGRect(x: (bounds.width - w) / 2, y: (bounds.height - h) / 2, width: w, height: h)
        for v in subviews {
            v.transform = .identity          // frame is only valid on an untransformed view
            v.frame = f
            v.transform = viewTransform
        }
    }

    // MARK: - viewport zoom / pan (two fingers; moves the comp view, never the 3D space)

    var zoomLocked = false      // lock buttons under the cube icon: pinch / two-finger drag ignored (2D comp view only)
    var moveLocked = false
    private(set) var zoom: CGFloat = 1
    private(set) var pan: CGPoint = .zero
    private let resetBtn = UIButton(type: .system)
    private var viewTransform: CGAffineTransform {
        CGAffineTransform(translationX: pan.x, y: pan.y).scaledBy(x: zoom, y: zoom)
    }

    /// Two-finger pinch + drag on the comp view, a two-finger double-tap and a reset chip to go back.
    func enableViewportGestures(chipHost: UIView) {
        let pinch = UIPinchGestureRecognizer(target: self, action: #selector(onPinch(_:)))
        let drag = UIPanGestureRecognizer(target: self, action: #selector(onDrag(_:)))
        drag.minimumNumberOfTouches = 2; drag.maximumNumberOfTouches = 2
        let dbl = UITapGestureRecognizer(target: self, action: #selector(resetViewport))
        dbl.numberOfTouchesRequired = 2; dbl.numberOfTapsRequired = 2
        for g in [pinch, drag, dbl] as [UIGestureRecognizer] { g.delegate = self; addGestureRecognizer(g) }

        resetBtn.setTitle("100%  ↺ Reset", for: .normal)
        resetBtn.titleLabel?.font = .boldSystemFont(ofSize: 12)
        resetBtn.setTitleColor(UIColor(red: 0.05, green: 0.05, blue: 0.06, alpha: 1), for: .normal)
        resetBtn.backgroundColor = argbToUIColor(C.GREEN)
        resetBtn.layer.cornerRadius = 14
        resetBtn.contentEdgeInsets = UIEdgeInsets(top: 0, left: 12, bottom: 0, right: 12)
        resetBtn.isHidden = true
        resetBtn.addTarget(self, action: #selector(resetViewport), for: .touchUpInside)
        resetBtn.translatesAutoresizingMaskIntoConstraints = false
        chipHost.addSubview(resetBtn)
        NSLayoutConstraint.activate([
            resetBtn.trailingAnchor.constraint(equalTo: chipHost.trailingAnchor, constant: -8),
            resetBtn.topAnchor.constraint(equalTo: chipHost.topAnchor, constant: 6),
            resetBtn.heightAnchor.constraint(equalToConstant: 28)])
    }

    func gestureRecognizer(_ a: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith b: UIGestureRecognizer) -> Bool {
        !(a is UITapGestureRecognizer) && !(b is UITapGestureRecognizer)
    }

    private func centre(_ g: UIGestureRecognizer) -> CGPoint {
        let p = g.location(in: self)
        return CGPoint(x: p.x - bounds.midX, y: p.y - bounds.midY)
    }

    @objc private func onPinch(_ g: UIPinchGestureRecognizer) {
        if zoomLocked { g.scale = 1; return }
        guard g.state == .changed || g.state == .began else { return }
        let nz = min(16, max(1, zoom * g.scale))
        let k = nz / zoom
        let f = centre(g)                          // keep the point between the fingers fixed
        pan = CGPoint(x: f.x - k * (f.x - pan.x), y: f.y - k * (f.y - pan.y))
        zoom = nz; g.scale = 1
        applyViewport()
    }

    @objc private func onDrag(_ g: UIPanGestureRecognizer) {
        if moveLocked { g.setTranslation(.zero, in: self); return }
        guard g.state == .changed || g.state == .began else { return }
        let t = g.translation(in: self); g.setTranslation(.zero, in: self)
        pan = CGPoint(x: pan.x + t.x, y: pan.y + t.y)
        applyViewport()
    }

    @objc func resetViewport() {
        zoom = 1; pan = .zero
        UIView.animate(withDuration: 0.2) { self.applyViewport() }
    }

    private func applyViewport() {
        // never let the comp slide fully out of view
        let mx = bounds.width * zoom / 2, my = bounds.height * zoom / 2
        pan.x = min(mx, max(-mx, pan.x)); pan.y = min(my, max(-my, pan.y))
        for v in subviews { v.transform = viewTransform }
        let on = zoom > 1.01 || hypot(pan.x, pan.y) > 1
        resetBtn.isHidden = !on
        resetBtn.setTitle("\(Int(round(zoom * 100)))%  ↺ Reset", for: .normal)
    }
}
