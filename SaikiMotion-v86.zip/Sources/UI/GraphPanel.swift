// GraphPanel.swift — the graph editor panel: tabs, curve-type dropdown, draggable knobs, preset column (UI).
//
//   [ icons ] [ Ease  Value  Speed          Position · ◆1 → ◆2 ] [ + ]
//   [  x    ] [ [Bounce ▾]                   bounce(8, 1.00, in)] [ preset ]
//   [ swap  ] [          the curve, with knobs on it             ] [ preset ]
//   [ paste ] [                                                  ] [ preset ]
//   [ reset ] [                                                  ] [ ...    ]
//
// Knobs: bezier = the two handles; bounce / elastic / wave = a green strength knob (drag up / down) and an
// orange count knob (drag up / down); steps = the orange count knob. Tapping the "bounce(8, 1.00, in)" label
// cycles in / out / in-out.

import UIKit

private let kGreen = Int32(bitPattern: 0xFF34D26B)
private let kOrange = Int32(bitPattern: 0xFFF5A623)
private let kPanel = Int32(bitPattern: 0xFF141416)

// MARK: - the curve

final class CurveGraphView: UIView {
    var key: Key
    var onBegin: (() -> Void)?
    var onChange: (() -> Void)?
    var onRefresh: (() -> Void)?

    private struct Knob { var id: String; var p: CGPoint; var color: Int32; var text: String; var left: Bool }
    private var drag = ""
    private let ins = UIEdgeInsets(top: 14, left: 30, bottom: 16, right: 22)
    private var lo: Float { key.isBezier() ? -0.5 : -0.1 }
    private var hi: Float { key.isBezier() ? 1.5 : 1.35 }

    init(_ key: Key) {
        self.key = key
        super.init(frame: .zero)
        backgroundColor = .clear
        isOpaque = false
        isMultipleTouchEnabled = false
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    // coordinates
    private var w: CGFloat { bounds.width - ins.left - ins.right }
    private var h: CGFloat { bounds.height - ins.top - ins.bottom }
    private func X(_ u: Float) -> CGFloat { ins.left + CGFloat(u) * w }
    private func Y(_ v: Float) -> CGFloat { ins.top + CGFloat((hi - v) / (hi - lo)) * h }
    private func U(_ x: CGFloat) -> Float { clamp(Float((x - ins.left) / w), 0, 1) }
    private func V(_ y: CGFloat) -> Float { hi - Float((y - ins.top) / h) * (hi - lo) }

    private func y(_ u: Float) -> Float { Track.easeAt(key, u) }

    /// Where the strength knob sits: the last peak before the end of the curve.
    private func peakU() -> Float {
        var ymax: Float = -10
        for i in 0...200 { ymax = max(ymax, y(Float(i) / 200 * 0.99)) }
        var best: Float = 0.5
        for i in 0...400 { let u = Float(i) / 400 * 0.99; if y(u) >= ymax - 0.003 { best = u } }
        return best
    }

    private var hasAmp: Bool { key.ease == .BOUNCE || key.ease == .ELASTIC || key.ease == .WAVE }
    private var hasCount: Bool { hasAmp || key.ease == .STEPS }

    private var countWord: String {
        switch key.ease { case .BOUNCE: return "Bounces"; case .STEPS: return "Steps"; default: return "Cycles" }
    }

    private func knobs() -> [Knob] {
        var out: [Knob] = []
        if key.isBezier() && !key.rev {
            out.append(Knob(id: "b1", p: CGPoint(x: X(key.x1), y: Y(key.y1)), color: kGreen, text: "", left: false))
            out.append(Knob(id: "b2", p: CGPoint(x: X(key.x2), y: Y(key.y2)), color: kGreen, text: "", left: false))
        }
        if hasAmp {
            let u = peakU()
            out.append(Knob(id: "amp", p: CGPoint(x: X(u), y: Y(y(u))), color: kGreen, text: "\(Int((key.amp * 100).rounded()))%", left: false))
        }
        if hasCount {
            out.append(Knob(id: "cnt", p: CGPoint(x: X(1), y: Y(0.1 * Float(key.cn))), color: kOrange, text: "\(countWord) \(key.cn)", left: true))
        }
        return out
    }

    /// "bounce(8, 1.00, in)"
    var infoText: String {
        let mode = ["in", "out", "in-out"][min(max(key.bm, 0), 2)]
        switch key.ease {
        case .BOUNCE: return key.bm == 3 ? "bounce" : String(format: "bounce(%d, %.2f, %@)", key.cn, key.amp, mode)
        case .ELASTIC: return key.bm == 3 ? "elastic" : String(format: "elastic(%d, %.2f, %@)", key.cn, key.amp, mode)
        case .WAVE: return String(format: "wave(%d, %.2f)", key.cn, key.amp)
        case .STEPS: return "steps(\(key.cn))"
        case .LINEAR: return "linear"
        default: return String(format: "cubic-bezier(%.2f, %.2f, %.2f, %.2f)", key.x1, key.y1, key.x2, key.y2)
        }
    }
    private var infoRect: CGRect { CGRect(x: bounds.width - 190, y: 2, width: 184, height: 24) }

    private func text(_ s: String, at p: CGPoint, color: UIColor, size: CGFloat, right: Bool = false, bold: Bool = false) {
        let a: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: size, weight: bold ? .semibold : .regular), .foregroundColor: color]
        let sz = (s as NSString).size(withAttributes: a)
        (s as NSString).draw(at: CGPoint(x: right ? p.x - sz.width : p.x, y: p.y - sz.height / 2), withAttributes: a)
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        fillRoundRect(c, bounds, 12, Int32(bitPattern: 0xFF0F0F11))
        let grid = Int32(bitPattern: 0xFF26262B)
        for i in 0...10 { strokeLine(c, X(Float(i) / 10), Y(lo), X(Float(i) / 10), Y(hi), 1, i % 5 == 0 ? Int32(bitPattern: 0xFF2E2E34) : Int32(bitPattern: 0xFF1B1B1F)) }
        for v in [Float(0), Float(1)] { strokeLine(c, X(0), Y(v), X(1), Y(v), 1, grid) }
        text("1", at: CGPoint(x: 12, y: Y(1)), color: UIColor(white: 0.6, alpha: 1), size: 11)
        text("0", at: CGPoint(x: 12, y: Y(0)), color: UIColor(white: 0.6, alpha: 1), size: 11)
        // linear reference
        strokeLine(c, X(0), Y(0), X(1), Y(1), 1.5, Int32(bitPattern: 0xFF3A3A40))
        // end marker: dashed green line
        c.saveGState()
        c.setStrokeColor(argbToUIColor(kGreen).withAlphaComponent(0.8).cgColor)
        c.setLineWidth(1.2); c.setLineDash(phase: 0, lengths: [3, 3])
        c.move(to: CGPoint(x: X(1), y: Y(hi))); c.addLine(to: CGPoint(x: X(1), y: Y(lo))); c.strokePath()
        c.restoreGState()
        // curve
        c.setStrokeColor(UIColor.white.cgColor)
        c.setLineWidth(2.6); c.setLineCap(.round); c.setLineJoin(.round)
        c.beginPath()
        let n = 480
        for i in 0...n {
            let u = Float(i) / Float(n)
            var v = y(u)
            if key.rev { v = 1 - y(1 - u) }
            let pt = CGPoint(x: X(u), y: Y(clamp(v, lo, hi)))
            if i == 0 { c.move(to: pt) } else { c.addLine(to: pt) }
        }
        c.strokePath()
        fillCircle(c, X(0), Y(0), 3.5, Int32(bitPattern: 0xFFDDDDDD))
        fillCircle(c, X(1), Y(1), 4, kGreen)
        text(infoText, at: CGPoint(x: bounds.width - 8, y: 14), color: UIColor(white: 0.62, alpha: 1), size: 11, right: true)
        // knobs
        for k in knobs() {
            if key.isBezier() {
                let anchor = k.id == "b1" ? CGPoint(x: X(0), y: Y(0)) : CGPoint(x: X(1), y: Y(1))
                strokeLine(c, anchor.x, anchor.y, k.p.x, k.p.y, 1.5, kGreen)
            }
            fillCircle(c, k.p.x, k.p.y, 8, k.color)
            strokeCircle(c, k.p.x, k.p.y, 8, 1.5, Int32(bitPattern: 0xFF0F0F11))
            if !k.text.isEmpty {
                let col = argbToUIColor(k.color)
                if k.left { text(k.text, at: CGPoint(x: k.p.x - 13, y: k.p.y), color: col, size: 12, right: true) }
                else { text(k.text, at: CGPoint(x: k.p.x + 13, y: k.p.y), color: col, size: 12) }
            }
        }
    }

    // touches
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        let pt = t.location(in: self)
        if (key.ease == .BOUNCE || key.ease == .ELASTIC) && key.bm != 3 && infoRect.contains(pt) {
            onBegin?()
            key.bm = (key.bm + 1) % 3
            onChange?(); setNeedsDisplay()
            return
        }
        var best = "", bd: CGFloat = 40
        for k in knobs() { let d = hypot(pt.x - k.p.x, pt.y - k.p.y); if d < bd { bd = d; best = k.id } }
        drag = best
        if !drag.isEmpty { onBegin?(); disallowParentScrollInterception(self, true) }
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard !drag.isEmpty, let t = touches.first else { return }
        let pt = t.location(in: self)
        switch drag {
        case "b1": if key.ease != .CUSTOM { key.ease = .CUSTOM }; key.x1 = U(pt.x); key.y1 = clamp(V(pt.y), -0.5, 1.5)
        case "b2": if key.ease != .CUSTOM { key.ease = .CUSTOM }; key.x2 = U(pt.x); key.y2 = clamp(V(pt.y), -0.5, 1.5)
        case "cnt": key.cn = clamp(Int((V(pt.y) / 0.1).rounded()), 1, 12)
        case "amp":
            if key.bm == 3 { key.bm = 0 }       // an old fixed curve becomes the adjustable one as soon as it is tuned
            let u = peakU(), target = clamp(V(pt.y), lo, hi)
            for _ in 0..<4 {                    // solve amp so the curve passes through the finger at the knob's x
                let cur = y(u), a0 = key.amp
                key.amp = a0 + 0.05
                let d = (y(u) - cur) / 0.05
                key.amp = a0
                if abs(d) < 0.02 { break }
                key.amp = clamp(a0 + (target - cur) / d, 0, 2)
            }
        default: break
        }
        onChange?()
        setNeedsDisplay()
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if !drag.isEmpty { drag = ""; disallowParentScrollInterception(self, false); onRefresh?() }
    }
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        if !drag.isEmpty { drag = ""; disallowParentScrollInterception(self, false) }
    }
}

// MARK: - the panel

final class GraphPanelView: UIView {
    // data
    var key: Key
    var tab = 0
    var title = ""
    var segText = "◆1 → ◆2"
    // callbacks
    var onBegin: (() -> Void)?
    var onChange: (() -> Void)?
    var onRefresh: (() -> Void)?
    var onTab: ((Int) -> Void)?
    var onClose: (() -> Void)?
    var onCycleSegment: (() -> Void)?
    var onCopy: (() -> Void)?
    var onPaste: (() -> Void)?
    var makeValueView: ((Bool) -> UIView)?

    private static let customKey = "graphCustomPresets"

    init(key: Key) {
        self.key = key
        super.init(frame: .zero)
        backgroundColor = argbToUIColor(kPanel)
        layer.cornerRadius = 16
        clipsToBounds = true
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    func build() {
        subviews.forEach { $0.removeFromSuperview() }
        let left = column()
        left.addArrangedSubview(iconButton("xmark.circle") { [weak self] in self?.onClose?() })
        left.addArrangedSubview(iconButton("arrow.left.arrow.right") { [weak self] in
            guard let self = self else { return }
            self.onBegin?(); self.key.rev.toggle(); self.onChange?(); self.onRefresh?()
        })
        let paste = iconButton("doc.on.clipboard") { [weak self] in self?.onPaste?() }
        paste.addGestureRecognizer(UILongPressGestureRecognizer(target: self, action: #selector(copyLong(_:))))
        left.addArrangedSubview(paste)
        left.addArrangedSubview(iconButton("arrow.counterclockwise") { [weak self] in
            guard let self = self else { return }
            self.onBegin?(); self.key.preset(.EASE_IN_OUT); self.key.rev = false; self.onChange?(); self.onRefresh?()
        })

        // top row: tabs + title
        let tabs = UIStackView(); tabs.axis = .horizontal; tabs.spacing = 18
        for (i, n) in ["Ease", "Value", "Speed"].enumerated() {
            let b = UIButton(type: .system)
            b.setTitle(n, for: .normal)
            b.titleLabel?.font = .systemFont(ofSize: 15, weight: .semibold)
            b.setTitleColor(i == tab ? argbToUIColor(kGreen) : UIColor(white: 0.72, alpha: 1), for: .normal)
            b.addAction(UIAction { [weak self] _ in self?.onTab?(i) }, for: .touchUpInside)
            tabs.addArrangedSubview(b)
        }
        let info = UIButton(type: .system)
        info.setTitle("\(title) · \(segText)", for: .normal)
        info.titleLabel?.font = .systemFont(ofSize: 12)
        info.setTitleColor(UIColor(white: 0.7, alpha: 1), for: .normal)
        info.addAction(UIAction { [weak self] _ in self?.onCycleSegment?() }, for: .touchUpInside)
        let spacer = UIView()
        let top = UIStackView(arrangedSubviews: [tabs, spacer, info]); top.axis = .horizontal; top.alignment = .center

        // centre: curve (+ dropdown) or value / speed plot
        let centre = UIView()
        if tab == 0 {
            let g = CurveGraphView(key)
            g.onBegin = { [weak self] in self?.onBegin?() }
            g.onChange = { [weak self] in self?.onChange?() }
            g.onRefresh = { [weak self] in self?.onRefresh?() }
            fill(g, in: centre)
            let dd = dropdown()
            dd.translatesAutoresizingMaskIntoConstraints = false
            centre.addSubview(dd)
            NSLayoutConstraint.activate([dd.leadingAnchor.constraint(equalTo: centre.leadingAnchor, constant: 36),
                                         dd.topAnchor.constraint(equalTo: centre.topAnchor, constant: 8),
                                         dd.heightAnchor.constraint(equalToConstant: 30)])
        } else if let v = makeValueView?(tab == 2) {
            fill(v, in: centre)
        }
        let mid = UIStackView(arrangedSubviews: [top, centre]); mid.axis = .vertical; mid.spacing = 6
        top.heightAnchor.constraint(equalToConstant: 30).isActive = true

        let right = presetColumn()

        let row = UIStackView(arrangedSubviews: [left, mid, right])
        row.axis = .horizontal; row.spacing = 10; row.alignment = .fill
        row.translatesAutoresizingMaskIntoConstraints = false
        addSubview(row)
        NSLayoutConstraint.activate([
            row.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 10), row.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -10),
            row.topAnchor.constraint(equalTo: topAnchor, constant: 10), row.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -10),
            left.widthAnchor.constraint(equalToConstant: 40), right.widthAnchor.constraint(equalToConstant: 62)])
    }

    @objc private func copyLong(_ g: UILongPressGestureRecognizer) { if g.state == .began { onCopy?() } }

    private func fill(_ v: UIView, in host: UIView) {
        v.translatesAutoresizingMaskIntoConstraints = false
        host.addSubview(v)
        NSLayoutConstraint.activate([v.leadingAnchor.constraint(equalTo: host.leadingAnchor), v.trailingAnchor.constraint(equalTo: host.trailingAnchor),
                                     v.topAnchor.constraint(equalTo: host.topAnchor), v.bottomAnchor.constraint(equalTo: host.bottomAnchor)])
    }

    private func column() -> UIStackView {
        let s = UIStackView(); s.axis = .vertical; s.spacing = 6; s.distribution = .equalSpacing; s.alignment = .center
        return s
    }

    private func iconButton(_ symbol: String, _ f: @escaping () -> Void) -> UIButton {
        let b = UIButton(type: .system)
        b.setImage(UIImage(systemName: symbol, withConfiguration: UIImage.SymbolConfiguration(pointSize: 20, weight: .regular)), for: .normal)
        b.tintColor = UIColor(white: 0.92, alpha: 1)
        b.addAction(UIAction { _ in f() }, for: .touchUpInside)
        b.widthAnchor.constraint(equalToConstant: 40).isActive = true
        b.heightAnchor.constraint(equalToConstant: 40).isActive = true
        return b
    }

    // curve-type dropdown
    private func typeName() -> String {
        switch key.ease {
        case .LINEAR: return "Linear"
        case .EASE_IN: return "Ease In"
        case .EASE_OUT: return "Ease Out"
        case .EASE_IN_OUT: return "Ease In-Out"
        case .BOUNCE: return "Bounce"
        case .ELASTIC: return "Elastic"
        case .WAVE: return "Wave"
        case .STEPS: return "Steps"
        case .CUSTOM:
            for (n, k) in GraphPanelView.builtins() where k.ease == .CUSTOM && abs(k.x1 - key.x1) < 0.005 && abs(k.y1 - key.y1) < 0.005 && abs(k.x2 - key.x2) < 0.005 && abs(k.y2 - key.y2) < 0.005 { return n }
            return "Bezier"
        }
    }

    private func dropdown() -> UIButton {
        let b = UIButton(type: .system)
        var cfg = UIButton.Configuration.filled()
        cfg.title = typeName()
        cfg.image = UIImage(systemName: "arrowtriangle.down.fill", withConfiguration: UIImage.SymbolConfiguration(pointSize: 8))
        cfg.imagePlacement = .trailing; cfg.imagePadding = 6
        cfg.baseBackgroundColor = UIColor(white: 0.17, alpha: 1); cfg.baseForegroundColor = .white
        cfg.cornerStyle = .medium
        cfg.contentInsets = NSDirectionalEdgeInsets(top: 4, leading: 10, bottom: 4, trailing: 10)
        b.configuration = cfg
        let names = ["Linear", "Ease In", "Ease Out", "Ease In-Out", "Bezier", "Back", "Expo", "Snap", "Elastic", "Bounce", "Wave", "Steps"]
        b.menu = UIMenu(children: names.map { n in
            UIAction(title: n, state: n == typeName() ? .on : .off) { [weak self] _ in self?.apply(n) }
        })
        b.showsMenuAsPrimaryAction = true
        return b
    }

    private func apply(_ n: String) {
        onBegin?()
        func bz(_ x1: Float, _ y1: Float, _ x2: Float, _ y2: Float) { key.ease = .CUSTOM; key.x1 = x1; key.y1 = y1; key.x2 = x2; key.y2 = y2 }
        key.rev = false
        switch n {
        case "Linear": key.preset(.LINEAR)
        case "Ease In": key.preset(.EASE_IN)
        case "Ease Out": key.preset(.EASE_OUT)
        case "Ease In-Out": key.preset(.EASE_IN_OUT)
        case "Bezier": if !key.isBezier() { key.preset(.EASE_IN_OUT) }; key.ease = .CUSTOM
        case "Back": bz(0.34, 1.56, 0.64, 1)
        case "Expo": bz(0.7, 0, 0.84, 0)
        case "Snap": bz(1, 0, 0, 1)
        case "Elastic": key.preset(.ELASTIC)
        case "Bounce": key.preset(.BOUNCE)
        case "Wave": key.ease = .WAVE; key.amp = 1; key.cn = 2
        default: key.ease = .STEPS; key.cn = 4
        }
        onChange?(); onRefresh?()
    }

    // presets
    static func builtins() -> [(String, Key)] {
        func bz(_ x1: Float, _ y1: Float, _ x2: Float, _ y2: Float) -> Key { let k = Key(0, 0, .CUSTOM); k.x1 = x1; k.y1 = y1; k.x2 = x2; k.y2 = y2; return k }
        let el = Key(0, 0, .ELASTIC); el.preset(.ELASTIC)
        let bo = Key(0, 0, .BOUNCE); bo.preset(.BOUNCE)
        let bo2 = Key(0, 0, .BOUNCE); bo2.preset(.BOUNCE); bo2.cn = 3; bo2.bm = 1
        let wv = Key(0, 0, .WAVE); wv.cn = 2
        let st = Key(0, 0, .STEPS); st.cn = 4
        return [("Linear", Key(0, 0, .LINEAR)), ("Ease In", Key(0, 0, .EASE_IN)), ("Ease Out", Key(0, 0, .EASE_OUT)),
                ("Ease In-Out", Key(0, 0, .EASE_IN_OUT)), ("Back", bz(0.34, 1.56, 0.64, 1)), ("Expo", bz(0.7, 0, 0.84, 0)),
                ("Snap", bz(1, 0, 0, 1)), ("Elastic", el), ("Bounce Out", bo2), ("Bounce", bo), ("Wave", wv), ("Steps", st)]
    }

    private static func customPresets() -> [Key] {
        let arr = (UserDefaults.standard.array(forKey: customKey) as? [[String: Double]]) ?? []
        return arr.map { d in
            let k = Key(0, 0, Ease(rawValue: Int(d["e"] ?? 3)) ?? .EASE_IN_OUT)
            k.x1 = Float(d["x1"] ?? 0.42); k.y1 = Float(d["y1"] ?? 0); k.x2 = Float(d["x2"] ?? 0.58); k.y2 = Float(d["y2"] ?? 1)
            k.amp = Float(d["a"] ?? 1); k.cn = Int(d["n"] ?? 3); k.bm = Int(d["m"] ?? 0)
            return k
        }
    }

    private func saveCustom() {
        var arr = (UserDefaults.standard.array(forKey: GraphPanelView.customKey) as? [[String: Double]]) ?? []
        arr.append(["e": Double(key.ease.rawValue), "x1": Double(key.x1), "y1": Double(key.y1), "x2": Double(key.x2), "y2": Double(key.y2),
                    "a": Double(key.amp), "n": Double(key.cn), "m": Double(key.bm)])
        UserDefaults.standard.set(arr, forKey: GraphPanelView.customKey)
        Snack.show("Curve saved to presets")
        onRefresh?()
    }

    private func presetColumn() -> UIView {
        let scroll = UIScrollView()
        scroll.showsVerticalScrollIndicator = false
        let stack = UIStackView(); stack.axis = .vertical; stack.spacing = 6
        stack.translatesAutoresizingMaskIntoConstraints = false
        scroll.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor), stack.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor),
            stack.leadingAnchor.constraint(equalTo: scroll.contentLayoutGuide.leadingAnchor), stack.trailingAnchor.constraint(equalTo: scroll.contentLayoutGuide.trailingAnchor),
            stack.widthAnchor.constraint(equalTo: scroll.frameLayoutGuide.widthAnchor)])
        let plus = UIButton(type: .system)
        plus.setImage(UIImage(systemName: "plus", withConfiguration: UIImage.SymbolConfiguration(pointSize: 18, weight: .medium)), for: .normal)
        plus.tintColor = .white
        plus.backgroundColor = UIColor(white: 0.16, alpha: 1); plus.layer.cornerRadius = 12
        plus.addAction(UIAction { [weak self] _ in self?.saveCustom() }, for: .touchUpInside)
        plus.heightAnchor.constraint(equalToConstant: 40).isActive = true
        stack.addArrangedSubview(plus)
        func thumb(_ k: Key) {
            let t = CurveThumb(k, "")
            t.onClick = { [weak self] in
                guard let self = self else { return }
                self.onBegin?(); self.key.copyCurveFrom(k); self.key.rev = false; self.onChange?(); self.onRefresh?()
            }
            t.heightAnchor.constraint(equalToConstant: 58).isActive = true
            stack.addArrangedSubview(t)
        }
        for (_, k) in GraphPanelView.builtins() { thumb(k) }
        for k in GraphPanelView.customPresets() { thumb(k) }
        return scroll
    }
}
