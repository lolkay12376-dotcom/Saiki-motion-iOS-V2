// SimulationsPanel.swift — full-screen "Simulations" window: Water + volumetric Clouds.
import UIKit

private let simAccent = UIColor(red: 1, green: 0.55, blue: 0.08, alpha: 1)

private func simLabel(_ t: String, _ size: CGFloat = 13, _ w: UIFont.Weight = .regular, _ c: UIColor = UIColor(white: 0.7, alpha: 1)) -> UILabel {
    let l = UILabel(); l.text = t; l.font = .systemFont(ofSize: size, weight: w); l.textColor = c; l.numberOfLines = 0; return l
}

final class SimulationsPanel: UIView {
    private weak var host: EditorViewController?
    private let content = UIView()

    static func present(in host: EditorViewController, over view: UIView) {
        if view.subviews.contains(where: { $0 is SimulationsPanel }) { return }
        let v = SimulationsPanel(host: host); v.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(v)
        NSLayoutConstraint.activate([v.leadingAnchor.constraint(equalTo: view.leadingAnchor), v.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                                     v.topAnchor.constraint(equalTo: view.topAnchor), v.bottomAnchor.constraint(equalTo: view.bottomAnchor)])
    }

    init(host: EditorViewController) {
        self.host = host
        super.init(frame: .zero)
        backgroundColor = UIColor(white: 0.05, alpha: 1)       // whole screen
        let title = simLabel("Simulations", 24, .bold, .white)
        let x = UIButton(type: .system); x.setImage(UIImage(systemName: "xmark"), for: .normal); x.tintColor = .white
        x.addTarget(self, action: #selector(close), for: .touchUpInside)
        let head = UIStackView(arrangedSubviews: [title, UIView(), x]); head.alignment = .center
        let rows = UIStackView(arrangedSubviews: [row("Water", "drop.fill", "Waves, foam, refraction, depth", #selector(addWater)),
                                                  row("Clouds", "cloud.fill", "Photorealistic volumetric clouds", #selector(openClouds))])
        rows.axis = .vertical; rows.spacing = 12
        let st = UIStackView(arrangedSubviews: [head, rows]); st.axis = .vertical; st.spacing = 20
        st.translatesAutoresizingMaskIntoConstraints = false; addSubview(st)
        NSLayoutConstraint.activate([st.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 18), st.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -18),
                                     st.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor, constant: 16)])
    }
    required init?(coder: NSCoder) { fatalError() }

    private func row(_ t: String, _ icon: String, _ sub: String, _ a: Selector) -> UIView {
        let b = UIButton(type: .custom); b.backgroundColor = UIColor(white: 0.12, alpha: 1); b.layer.cornerRadius = 16
        let img = UIImageView(image: UIImage(systemName: icon)); img.tintColor = simAccent; img.contentMode = .scaleAspectFit
        img.widthAnchor.constraint(equalToConstant: 34).isActive = true
        let tx = UIStackView(arrangedSubviews: [simLabel(t, 18, .semibold, .white), simLabel(sub, 12)]); tx.axis = .vertical; tx.spacing = 2
        let h = UIStackView(arrangedSubviews: [img, tx, UIView(), UIImageView(image: UIImage(systemName: "chevron.right"))])
        h.isUserInteractionEnabled = false; h.alignment = .center; h.spacing = 14
        h.translatesAutoresizingMaskIntoConstraints = false; b.addSubview(h)
        NSLayoutConstraint.activate([h.leadingAnchor.constraint(equalTo: b.leadingAnchor, constant: 16), h.trailingAnchor.constraint(equalTo: b.trailingAnchor, constant: -16),
                                     h.topAnchor.constraint(equalTo: b.topAnchor, constant: 16), h.bottomAnchor.constraint(equalTo: b.bottomAnchor, constant: -16)])
        b.addTarget(self, action: a, for: .touchUpInside); return b
    }

    @objc private func close() { removeFromSuperview() }

    @objc private func addWater() {
        guard let host = host else { return }
        guard let path = ProjectIO.writeDataIntoSandbox(ExtrasGLB.water(), name: "extras_water_\(nowMs()).glb") else { return }
        host.addMedia(path, .MODEL)
        if let l = Editor.scene.layers.last(where: { $0.imagePath == path }) {
            l.name = "Water"
            l.xset("water", 1); l.xset("wAmp", 0.03); l.xset("wFreq", 6); l.xset("wSpeed", 1)
            l.xset("wChop", 0.5); l.xset("wFoam", 0.5); l.xset("wDepth", 0.5)
            host.render(); host.refreshPanel()
        }
        close()
    }

    @objc private func openClouds() {
        guard let host = host else { return }
        let c = CloudsPanel(host: host, parentPanel: self); c.translatesAutoresizingMaskIntoConstraints = false
        addSubview(c)
        NSLayoutConstraint.activate([c.leadingAnchor.constraint(equalTo: leadingAnchor), c.trailingAnchor.constraint(equalTo: trailingAnchor),
                                     c.topAnchor.constraint(equalTo: topAnchor), c.bottomAnchor.constraint(equalTo: bottomAnchor)])
    }
}

final class CloudsPanel: UIView, UIColorPickerViewControllerDelegate {
    private weak var host: EditorViewController?
    private weak var parentPanel: SimulationsPanel?
    private let typeSeg = UISegmentedControl(items: CloudGen.types)
    private let dayNight = UISlider(), density = UISlider(), edgeAmt = UISlider()
    private let scatter = UISwitch(), envLight = UISwitch()
    private let tintWell = UIColorWell(), edgeWell = UIColorWell()

    init(host: EditorViewController, parentPanel: SimulationsPanel) {
        self.host = host; self.parentPanel = parentPanel
        super.init(frame: .zero)
        backgroundColor = UIColor(white: 0.05, alpha: 1)
        let back = UIButton(type: .system); back.setImage(UIImage(systemName: "chevron.left"), for: .normal); back.tintColor = .white
        back.addTarget(self, action: #selector(goBack), for: .touchUpInside)
        let head = UIStackView(arrangedSubviews: [back, simLabel("Clouds", 24, .bold, .white), UIView()]); head.spacing = 12; head.alignment = .center

        typeSeg.selectedSegmentIndex = 0; typeSeg.selectedSegmentTintColor = simAccent
        typeSeg.setTitleTextAttributes([.foregroundColor: UIColor.white, .font: UIFont.systemFont(ofSize: 10)], for: .normal)
        typeSeg.setTitleTextAttributes([.foregroundColor: UIColor.black, .font: UIFont.systemFont(ofSize: 10)], for: .selected)
        for s in [dayNight, density, edgeAmt] { s.tintColor = simAccent }
        dayNight.value = 0; density.minimumValue = 0.5; density.maximumValue = 8; density.value = 3; edgeAmt.value = 0.4
        tintWell.selectedColor = .white; tintWell.supportsAlpha = false
        edgeWell.selectedColor = UIColor(red: 1, green: 0.85, blue: 0.7, alpha: 1); edgeWell.supportsAlpha = false
        scatter.onTintColor = simAccent; envLight.onTintColor = simAccent; envLight.isOn = true

        func r(_ t: String, _ v: UIView) -> UIStackView {
            let l = simLabel(t, 14, .regular, .white); l.setContentHuggingPriority(.required, for: .horizontal)
            l.widthAnchor.constraint(greaterThanOrEqualToConstant: 96).isActive = true
            let s = UIStackView(arrangedSubviews: [l, v]); s.spacing = 12; s.alignment = .center; return s
        }
        let sp = UIView(); sp.setContentHuggingPriority(.defaultLow, for: .horizontal)
        let add = UIButton(type: .system); add.setTitle("Add clouds", for: .normal); add.setTitleColor(.black, for: .normal)
        add.titleLabel?.font = .systemFont(ofSize: 17, weight: .bold); add.backgroundColor = simAccent; add.layer.cornerRadius = 14
        add.heightAnchor.constraint(equalToConstant: 50).isActive = true
        add.addTarget(self, action: #selector(addClouds), for: .touchUpInside)
        let note = simLabel("Day ← slider → Night. “Light from environment” lights the clouds with your Environment image/sky.", 12)

        let st = UIStackView(arrangedSubviews: [head, simLabel("Type", 13), typeSeg, r("Day / Night", dayNight), r("Density", density),
                                                r("Tint", tintWell), r("Edge colour", edgeWell), r("Edge amount", edgeAmt),
                                                r("Procedural scatter", scatter), r("Light from environment", envLight), note, UIView(), add])
        st.axis = .vertical; st.spacing = 16; st.translatesAutoresizingMaskIntoConstraints = false; addSubview(st)
        NSLayoutConstraint.activate([st.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 18), st.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -18),
                                     st.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor, constant: 16), st.bottomAnchor.constraint(equalTo: safeAreaLayoutGuide.bottomAnchor, constant: -16)])
    }
    required init?(coder: NSCoder) { fatalError() }

    @objc private func goBack() { removeFromSuperview() }

    private func rgb(_ c: UIColor) -> (CGFloat, CGFloat, CGFloat) { var r: CGFloat = 1, g: CGFloat = 1, b: CGFloat = 1, a: CGFloat = 1; c.getRed(&r, green: &g, blue: &b, alpha: &a); return (r, g, b) }
    private func pack(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> Int32 {
        Int32(bitPattern: 0xFF000000 | UInt32(max(0, min(1, r)) * 255) << 16 | UInt32(max(0, min(1, g)) * 255) << 8 | UInt32(max(0, min(1, b)) * 255))
    }

    @objc private func addClouds() {
        guard let host = host else { return }
        let t = typeSeg.selectedSegmentIndex
        guard let path = CloudSettings.writeFile(type: t, seed: Int(nowMs() % 9973), scatter: scatter.isOn) else { return }
        host.addMedia(path, .MODEL)
        guard let l = Editor.scene.layers.last(where: { $0.imagePath == path }) else { return }
        l.name = "Clouds · \(CloudGen.types[t])"
        let tc = rgb(tintWell.selectedColor ?? .white), ec = rgb(edgeWell.selectedColor ?? .white)
        l.xset("cloud", 1); l.xset("cType", Float(t)); l.xset("cScatter", scatter.isOn ? 1 : 0)
        l.xset("cDay", dayNight.value); l.xset("cDens", density.value); l.xset("cEdge", edgeAmt.value)
        l.xset("cTint", CloudSettings.pack24(tc.0, tc.1, tc.2)); l.xset("cEdgeCol", CloudSettings.pack24(ec.0, ec.1, ec.2))
        l.xset("cEnv", envLight.isOn ? 1 : 0); l.xset("vdbSteps", 30); l.xset("vdbShadow", 1)
        CloudSettings.apply(l)
        host.render(); host.refreshPanel()
        parentPanel?.removeFromSuperview()
    }
}

/// All cloud settings live on the layer (x3s keys) so the Properties panel and the Simulations screen share them.
enum CloudSettings {
    static func pack24(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> Float {
        Float(Int(max(0, min(1, r)) * 255) << 16 | Int(max(0, min(1, g)) * 255) << 8 | Int(max(0, min(1, b)) * 255))
    }
    static func unpack(_ v: Float) -> (Float, Float, Float) {
        let i = Int(v); return (Float((i >> 16) & 255) / 255, Float((i >> 8) & 255) / 255, Float(i & 255) / 255)
    }
    static func writeFile(type: Int, seed: Int, scatter: Bool) -> String? {
        guard let d = "SAIKICLOUD \(type) \(seed) \(scatter ? 1 : 0)".data(using: .utf8) else { return nil }
        return ProjectIO.writeDataIntoSandbox(d, name: "clouds_\(nowMs()).vdb")
    }
    /// Day/night, tint, density, edge colour and environment light -> the volume layer's render values.
    static func apply(_ l: Layer) {
        let n = l.xf("cDay", 0), u = unpack(l.xf("cTint", 16777215)), e = unpack(l.xf("cEdgeCol", 16777215))
        func mix(_ a: Float, _ b: Float) -> Float { a + (b - a) * n }
        l.vdbTint = Int32(bitPattern: 0xFF000000 | UInt32(mix(u.0, u.0 * 0.22) * 255) << 16 | UInt32(mix(u.1, u.1 * 0.28) * 255) << 8 | UInt32(mix(u.2, u.2 * 0.5) * 255))
        l.vdbBright = (1.0 - 0.8 * n) * l.xf("cBright", 1)
        l.vdbDens = l.xf("cDens", 3)
        l.vdbEnv = l.xf("cEnv", 1) > 0.5; l.vdbSurround = l.vdbEnv
        l.xset("cEdgeOut", Float(Int(mix(e.0, e.0 * 0.3) * 255) << 16 | Int(mix(e.1, e.1 * 0.4) * 255) << 8 | Int(mix(e.2, e.2 * 0.7) * 255)))
    }
    /// New shape (type / scatter / reseed): a fresh generated volume file on the same layer.
    static func rebuild(_ l: Layer) {
        guard let p = writeFile(type: Int(l.xf("cType", 0)), seed: Int(l.xf("cSeed", Float(nowMs() % 9973))), scatter: l.xf("cScatter", 0) > 0.5) else { return }
        l.imagePath = p; _ = VdbVolume.load(p)
    }
}
