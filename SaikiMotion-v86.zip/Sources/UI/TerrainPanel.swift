// TerrainPanel.swift — Scene 3D "+" > Terrain. Tabs: Shape (output, presets) · Nodes (a stack of generator/modifier nodes that
// builds the heightfield) · Material (optional Poly Haven PBR). Built as a .glb and imported like Extras.

import UIKit
import simd

// MARK: - node graph (heightfield, 0...1)

enum TKind: Int, CaseIterable {
    case noise, ridged, hills, craters, warp, terrace, curve, level, smooth, erode, island, voronoi, gradient, invert, blend, baked, constant, billow, waves, dunes, slope, sharpen, heightTex, pbr
    var title: String { ["Noise", "Ridged noise", "Rolling hills", "Craters", "Domain warp", "Terrace", "Curve", "Level / plateau", "Smooth", "Erosion", "Island mask", "Voronoi cells", "Gradient", "Invert", "Blend (2 inputs)", "Graph", "Constant", "Billow noise", "Waves", "Dunes", "Slope map", "Sharpen", "Height texture", "PBR material"][rawValue] }
    var icon: String { ["waveform", "mountain.2", "water.waves", "circle.dashed", "tornado", "chart.bar.fill", "point.topleft.down.curvedto.point.bottomright.up", "arrow.up.and.down.square", "drop", "wind", "circle.hexagongrid", "hexagon", "slider.horizontal.below.rectangle", "circle.lefthalf.filled", "arrow.triangle.merge", "point.3.connected.trianglepath.dotted", "equal.square", "cloud", "wave.3.right", "sun.dust", "angle", "wand.and.stars", "photo", "paintpalette"][rawValue] }
    var isGen: Bool {
        switch self { case .noise, .ridged, .hills, .craters, .voronoi, .gradient, .constant, .billow, .waves, .dunes, .heightTex: return true; default: return false }
    }
    /// name, lo, hi, default, choice options
    var params: [(String, Float, Float, Float, [String]?)] {
        let mix: (String, Float, Float, Float, [String]?) = ("Mix", 0, 3, 0, ["Add", "Mul", "Max", "Replace"])
        switch self {
        case .noise, .ridged, .billow: return [("Scale", 1, 16, 3, nil), ("Detail", 1, 8, 5, nil), ("Roughness", 0, 1, 0.5, nil), ("Strength", 0, 1, 1, nil), ("Seed", 1, 99, 1, nil), mix]
        case .hills: return [("Scale", 1, 10, 3, nil), ("Strength", 0, 1, 1, nil), mix]
        case .craters: return [("Count", 1, 40, 10, nil), ("Size", 0.03, 0.3, 0.1, nil), ("Depth", 0, 1, 0.5, nil), ("Seed", 1, 99, 1, nil)]
        case .warp: return [("Amount", 0, 0.3, 0.08, nil), ("Scale", 1, 10, 3, nil), ("Seed", 1, 99, 1, nil)]
        case .terrace: return [("Steps", 2, 20, 6, nil), ("Sharpness", 0, 1, 0.6, nil)]
        case .curve: return [("Power", 0.3, 4, 1.5, nil)]
        case .level: return [("Low", 0, 1, 0, nil), ("High", 0, 1, 1, nil)]
        case .smooth: return [("Iterations", 1, 12, 2, nil)]
        case .erode: return [("Iterations", 1, 40, 12, nil), ("Talus", 0.002, 0.06, 0.015, nil), ("Amount", 0, 1, 0.5, nil)]
        case .island: return [("Radius", 0.2, 1, 0.8, nil), ("Falloff", 0.05, 1, 0.4, nil)]
        case .voronoi: return [("Cells", 2, 30, 8, nil), ("Strength", 0, 1, 1, nil), ("Seed", 1, 99, 1, nil), ("Style", 0, 2, 0, ["Plateaus", "Edges", "Cones"]), mix]
        case .gradient: return [("Angle", 0, 360, 0, nil), ("Strength", 0, 1, 1, nil), ("Shape", 0, 1, 0, ["Linear", "Radial"]), mix]
        case .blend: return [("Mode", 0, 4, 0, ["Add", "Mul", "Max", "Min", "Lerp"]), ("Factor", 0, 1, 0.5, nil)]
        case .invert, .baked: return []
        case .constant: return [("Value", 0, 1, 0.5, nil), mix]
        case .waves: return [("Frequency", 1, 30, 8, nil), ("Angle", 0, 360, 0, nil), ("Warp", 0, 1, 0.3, nil), ("Strength", 0, 1, 1, nil), mix]
        case .dunes: return [("Frequency", 1, 20, 6, nil), ("Angle", 0, 360, 30, nil), ("Sharpness", 0, 1, 0.5, nil), ("Strength", 0, 1, 1, nil), ("Seed", 1, 99, 1, nil), mix]
        case .slope: return [("Gain", 0.5, 6, 2, nil)]
        case .sharpen: return [("Amount", 0, 3, 1, nil)]
        case .heightTex: return [("Strength", 0, 1, 1, nil), ("Invert", 0, 1, 0, ["Off", "On"]), ("Blur", 0, 8, 0, nil), mix]
        case .pbr: return [("Tiling", 1, 30, 6, nil), ("Strength", 0, 1, 1, nil), ("Height from", 0, 1, 0, nil), ("Height to", 0, 1, 1, nil), ("Height soft", 0, 0.5, 0.15, nil), ("Slope from", 0, 1, 0, nil), ("Slope to", 0, 1, 1, nil)]
        }
    }
}

struct TNode {
    private static var counter = 0
    private static let lock = NSLock()
    var kind: TKind, p: [Float], on = true, id: Int, img: HImg? = nil
    init(_ k: TKind, _ over: [Int: Float] = [:]) {
        TNode.lock.lock(); TNode.counter += 1; id = TNode.counter; TNode.lock.unlock()
        kind = k; p = k.params.map { $0.3 }
        for (i, v) in over where i < p.count { p[i] = v }
    }
}

/// grey-scale image used by the Height texture node
struct HImg { var w: Int, h: Int, d: [Float] }
enum HeightImages {
    private static var cache: [String: HImg] = [:]
    private static let lock = NSLock()
    static func load(_ path: String?) -> HImg? {
        guard let path = path, !path.isEmpty else { return nil }
        lock.lock(); defer { lock.unlock() }
        if let c = cache[path] { return c }
        guard let ui = UIImage(contentsOfFile: path), let cg = ui.cgImage else { return nil }
        let k = min(1, 512 / CGFloat(max(cg.width, cg.height))), w = max(2, Int(CGFloat(cg.width) * k)), h = max(2, Int(CGFloat(cg.height) * k))
        var px = [UInt8](repeating: 0, count: w * h)
        guard let ctx = CGContext(data: &px, width: w, height: h, bitsPerComponent: 8, bytesPerRow: w, space: CGColorSpaceCreateDeviceGray(), bitmapInfo: CGImageAlphaInfo.none.rawValue) else { return nil }
        ctx.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h))
        let im = HImg(w: w, h: h, d: px.map { Float($0) / 255 }); cache[path] = im; return im
    }
}

enum TerrainGraph {
    /// the node-graph editor result (evaluated at the requested resolution); used by the `.baked` node so PBR / GLB building reuse it
    static var bakedEval: ((Int, Float, Int) -> [Float])? = nil
    private static func hash(_ x: Int, _ y: Int, _ s: Int) -> Float {
        var h = UInt32(truncatingIfNeeded: x &* 374761393 &+ y &* 668265263 &+ s &* 1274126177)
        h = (h ^ (h >> 13)) &* 1274126177
        return Float((h ^ (h >> 16)) & 0xFFFF) / 65535
    }
    private static func vn(_ x: Float, _ y: Float, _ s: Int) -> Float {
        let ix = Int(floor(x)), iy = Int(floor(y)), fx = x - floor(x), fy = y - floor(y)
        let sx = fx * fx * (3 - 2 * fx), sy = fy * fy * (3 - 2 * fy)
        let a = hash(ix, iy, s), b = hash(ix + 1, iy, s), c = hash(ix, iy + 1, s), d = hash(ix + 1, iy + 1, s)
        return (a + (b - a) * sx) + ((c + (d - c) * sx) - (a + (b - a) * sx)) * sy
    }
    private static func fbm(_ a: Float, _ b: Float, _ scale: Float, _ oct: Int, _ rough: Float, _ seed: Int, ridged: Bool) -> Float {
        var amp: Float = 1, f = scale, sum: Float = 0, norm: Float = 0
        for i in 0..<oct {
            var n = vn(a * f, b * f, seed &+ i * 31)
            if ridged { let r = 1 - abs(2 * n - 1); n = r * r }
            sum += n * amp; norm += amp
            amp *= 0.3 + 0.45 * rough; f *= 2.03
        }
        return sum / norm
    }
    private static func sstep(_ a: Float, _ b: Float, _ x: Float) -> Float { let t = max(0, min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t) }
    private static func lerp3(_ a: simd_float3, _ b: simd_float3, _ t: Float) -> simd_float3 { a + (b - a) * t }
    static func boxBlur(_ a: [Float], _ res: Int, _ it: Int) -> [Float] {
        let R = res + 1; var f = a
        for _ in 0..<max(it, 0) {
            let s = f
            for j in 0..<R { for i in 0..<R {
                var t: Float = 0
                for dj in -1...1 { for di in -1...1 { t += s[min(max(i + di, 0), res) + min(max(j + dj, 0), res) * R] } }
                f[i + j * R] = t / 9
            } }
        }
        return f
    }
    private static func norm(_ f: inout [Float]) {
        guard let lo = f.min(), let hi = f.max(), hi - lo > 1e-6 else { return }
        let k = 1 / (hi - lo); for i in 0..<f.count { f[i] = (f[i] - lo) * k }
    }
    private static func mix(_ f: Float, _ n: Float, _ s: Float, _ mode: Int) -> Float {
        switch mode {
        case 1: return f * (1 + (n - 1) * s)
        case 2: return max(f, n * s)
        case 3: return f + (n - f) * s
        default: return f + n * s
        }
    }

    /// Evaluates the node stack on a (res+1)² grid; result 0...1 with edge fade and sea floor applied.
    static func eval(_ nodes: [TNode], res: Int, edge: Float, sea: Float, scale: Float = 1, seed: Int = 0, masks: ((Int, [Float]) -> Void)? = nil, initial: [Float]? = nil, raw: Bool = false) -> [Float] {
        let R = res + 1, inv = 1 / Float(res)
        var f = initial ?? [Float](repeating: 0, count: R * R)
        let zs = 1 / max(scale, 0.05), so = seed &* 7919          // feature zoom about the centre, seed offset
        func zc(_ t: Float) -> Float { 0.5 + (t - 0.5) * zs }
        for nd in nodes where nd.on {
            let p = nd.p
            let before = masks != nil ? f : []
            switch nd.kind {
            case .noise, .ridged, .billow:
                let mode = Int(p[5]), sd = Int(p[4]) &+ so, ob = Int(p[1]), rg = nd.kind == .ridged
                for j in 0..<R { for i in 0..<R {
                    var n = fbm(zc(Float(i) * inv), zc(Float(j) * inv), p[0], ob, p[2], sd, ridged: rg)
                    if nd.kind == .billow { n = abs(2 * n - 1) }
                    f[i + j * R] = mix(f[i + j * R], n, p[3], mode)
                } }
            case .hills:
                for j in 0..<R { for i in 0..<R {
                    let a = zc(Float(i) * inv), b = zc(Float(j) * inv), k = p[0] / 3, ph = Float(seed) * 0.37
                    let n = 0.5 + 0.28 * sinf(a * 6.2 * k + 0.7 + ph) * cosf(b * 5.1 * k + ph) + 0.14 * sinf(a * 13 * k + b * 9 * k) * cosf(b * 11 * k - a * 4 * k + ph)
                    f[i + j * R] = mix(f[i + j * R], n, p[1], Int(p[2]))
                } }
            case .craters:
                norm(&f)
                for c in 0..<Int(p[0]) {
                    let csd = Int(p[3]) &+ so
                    let cx = 0.5 + (hash(c, 1, csd) - 0.5) * scale, cy = 0.5 + (hash(c, 2, csd) - 0.5) * scale, r = p[1] * (0.5 + hash(c, 3, csd)) * scale
                    let j0 = max(0, Int((cy - r * 1.4) * Float(res))), j1 = min(res, Int((cy + r * 1.4) * Float(res)) + 1)
                    let i0 = max(0, Int((cx - r * 1.4) * Float(res))), i1 = min(res, Int((cx + r * 1.4) * Float(res)) + 1)
                    if j0 > j1 || i0 > i1 { continue }
                    for j in j0...j1 { for i in i0...i1 {
                        let dx = Float(i) * inv - cx, dy = Float(j) * inv - cy, d = sqrtf(dx * dx + dy * dy) / r
                        let bowl: Float = d < 1 ? -(1 - d * d) : 0
                        let rim = 0.35 * expf(-(d - 1) * (d - 1) * 18)
                        f[i + j * R] += (bowl + rim) * p[2] * 0.4
                    } }
                }
            case .warp:
                let src = f, sd = Int(p[2]) &+ so
                for j in 0..<R { for i in 0..<R {
                    let a = Float(i) * inv, b = Float(j) * inv
                    let x = max(0, min(1, a + (vn(zc(a) * p[1], zc(b) * p[1], sd) - 0.5) * 2 * p[0])) * Float(res)
                    let y = max(0, min(1, b + (vn(zc(a) * p[1], zc(b) * p[1], sd &+ 17) - 0.5) * 2 * p[0])) * Float(res)
                    let x0 = min(Int(x), res - 1), y0 = min(Int(y), res - 1), fx = x - Float(x0), fy = y - Float(y0)
                    let v0 = src[x0 + y0 * R] * (1 - fx) + src[x0 + 1 + y0 * R] * fx, v1 = src[x0 + (y0 + 1) * R] * (1 - fx) + src[x0 + 1 + (y0 + 1) * R] * fx
                    f[i + j * R] = v0 * (1 - fy) + v1 * fy
                } }
            case .terrace:
                norm(&f)
                let n = p[0]
                for k in 0..<f.count {
                    let s = f[k] * n, fl = floor(s), fr = s - fl
                    let sharp = fr < 0.5 ? 0.5 * powf(fr * 2, 1 + p[1] * 5) : 1 - 0.5 * powf((1 - fr) * 2, 1 + p[1] * 5)
                    f[k] = (fl + sharp) / n
                }
            case .curve:
                norm(&f); for k in 0..<f.count { f[k] = powf(max(f[k], 0), p[0]) }
            case .level:
                norm(&f)
                let lo = min(p[0], p[1] - 0.01), hi = max(p[1], lo + 0.01)
                for k in 0..<f.count { f[k] = max(0, min(1, (f[k] - lo) / (hi - lo))) }
            case .smooth:
                for _ in 0..<Int(p[0]) {
                    let s = f
                    for j in 1..<res { for i in 1..<res {
                        var t: Float = 0
                        for dj in -1...1 { for di in -1...1 { t += s[(i + di) + (j + dj) * R] } }
                        f[i + j * R] = t / 9
                    } }
                }
            case .erode:
                norm(&f)
                let tal = p[1], amt = p[2] * 0.25
                for _ in 0..<Int(p[0]) {
                    var dl = [Float](repeating: 0, count: R * R)
                    for j in 0..<R { for i in 0..<R {
                        let k = i + j * R
                        for (di, dj) in [(1, 0), (0, 1), (-1, 0), (0, -1)] {
                            let ni = i + di, nj = j + dj
                            if ni < 0 || nj < 0 || ni > res || nj > res { continue }
                            let d = f[k] - f[ni + nj * R]
                            if d > tal { let m = amt * (d - tal); dl[k] -= m; dl[ni + nj * R] += m }
                        }
                    } }
                    for k in 0..<f.count { f[k] += dl[k] }
                }
            case .voronoi:
                let cells = p[0], sd = Int(p[2]) &+ so, style = Int(p[3]), mode = Int(p[4])
                for j in 0..<R { for i in 0..<R {
                    let a = zc(Float(i) * inv) * cells, b = zc(Float(j) * inv) * cells
                    let ia = Int(floor(a)), ib = Int(floor(b))
                    var d1: Float = 9, d2: Float = 9, cid: Float = 0
                    for dj in -1...1 { for di in -1...1 {
                        let cx = ia + di, cy = ib + dj
                        let qx = Float(cx) + hash(cx, cy, sd), qy = Float(cy) + hash(cx, cy, sd &+ 77)
                        let d = sqrtf((qx - a) * (qx - a) + (qy - b) * (qy - b))
                        if d < d1 { d2 = d1; d1 = d; cid = hash(cx, cy, sd &+ 5) } else if d < d2 { d2 = d }
                    } }
                    let n: Float = style == 0 ? cid : (style == 1 ? 1 - sstep(0, 0.18, d2 - d1) : 1 - min(d1, 1))
                    f[i + j * R] = mix(f[i + j * R], n, p[1], mode)
                } }
            case .gradient:
                let ang = p[0] * Float.pi / 180, ca = cosf(ang), sa = sinf(ang), radial = Int(p[2]) == 1, mode = Int(p[3])
                for j in 0..<R { for i in 0..<R {
                    let x = zc(Float(i) * inv) - 0.5, y = zc(Float(j) * inv) - 0.5
                    let n: Float = radial ? 1 - min(1, sqrtf(x * x + y * y) * 2) : max(0, min(1, 0.5 + x * ca + y * sa))
                    f[i + j * R] = mix(f[i + j * R], n, p[1], mode)
                } }
            case .invert:
                norm(&f); for k in 0..<f.count { f[k] = 1 - f[k] }
            case .blend, .pbr: break          // blend has two inputs (node graph); PBR material nodes don't change the height
            case .constant:
                let mode = Int(p[1]); for k in 0..<f.count { f[k] = mix(f[k], p[0], 1, mode) }
            case .waves:
                let fr = p[0], ang = p[1] * Float.pi / 180, ca = cosf(ang), sa = sinf(ang), mode = Int(p[4])
                for j in 0..<R { for i in 0..<R {
                    let a = zc(Float(i) * inv), b = zc(Float(j) * inv), w = vn(a * 3, b * 3, so &+ 9)
                    f[i + j * R] = mix(f[i + j * R], 0.5 + 0.5 * sinf(6.2832 * fr * (a * ca + b * sa) + p[2] * 6 * w), p[3], mode)
                } }
            case .dunes:
                let fr = p[0], ang = p[1] * Float.pi / 180, ca = cosf(ang), sa = sinf(ang), sd = Int(p[4]) &+ so, mode = Int(p[5])
                for j in 0..<R { for i in 0..<R {
                    let a = zc(Float(i) * inv), b = zc(Float(j) * inv), w = vn(a * 2, b * 2, sd)
                    let s = 0.5 + 0.5 * sinf(6.2832 * fr * (a * ca + b * sa) + w * 5)
                    let n = powf(s, 1 + p[2] * 3) * (0.4 + 0.6 * vn(a * 4, b * 4, sd &+ 3))
                    f[i + j * R] = mix(f[i + j * R], n, p[3], mode)
                } }
            case .slope:
                norm(&f)
                var o = [Float](repeating: 0, count: R * R)
                for j in 1..<res { for i in 1..<res {
                    let gx = f[i + 1 + j * R] - f[i - 1 + j * R], gz = f[i + (j + 1) * R] - f[i + (j - 1) * R]
                    o[i + j * R] = sqrtf(gx * gx + gz * gz)
                } }
                norm(&o); for k in 0..<o.count { o[k] = powf(max(o[k], 0), 1 / p[0]) }
                f = o
            case .sharpen:
                let b = TerrainGraph.boxBlur(f, res, 1)
                for k in 0..<f.count { f[k] += (f[k] - b[k]) * p[0] * 2 }
            case .heightTex:
                if let im = nd.img {
                    var t = [Float](repeating: 0, count: R * R)
                    for j in 0..<R { for i in 0..<R {
                        let u = max(0, min(1, zc(Float(i) * inv))) * Float(im.w - 1), v = max(0, min(1, zc(Float(j) * inv))) * Float(im.h - 1)
                        let x0 = min(Int(u), im.w - 2), y0 = min(Int(v), im.h - 2), fx = u - Float(x0), fy = v - Float(y0)
                        let a = im.d[x0 + y0 * im.w] * (1 - fx) + im.d[x0 + 1 + y0 * im.w] * fx
                        let b = im.d[x0 + (y0 + 1) * im.w] * (1 - fx) + im.d[x0 + 1 + (y0 + 1) * im.w] * fx
                        t[i + j * R] = a * (1 - fy) + b * fy
                    } }
                    if p[2] >= 1 { t = TerrainGraph.boxBlur(t, res, Int(p[2])) }
                    if p[1] > 0.5 { for k in 0..<t.count { t[k] = 1 - t[k] } }
                    for k in 0..<f.count { f[k] = mix(f[k], t[k], p[0], Int(p[3])) }
                }
            case .baked: if let g = TerrainGraph.bakedEval { let r = g(res, scale, seed); if r.count == f.count { f = r } }
            case .island:
                norm(&f)
                for j in 0..<R { for i in 0..<R {
                    let dx = Float(i) * inv - 0.5, dy = Float(j) * inv - 0.5, d = sqrtf(dx * dx + dy * dy) * 2
                    f[i + j * R] *= 1 - sstep(p[0] - p[1], p[0], d)
                } }
            }
            if let mk = masks {      // this node's own influence 0...1 (used to assign PBR layers per node)
                var d = [Float](repeating: 0, count: f.count)
                if nd.kind == .noise || nd.kind == .ridged || nd.kind == .hills {
                    for k in 0..<f.count { d[k] = f[k] - before[k] }
                    norm(&d)
                } else {
                    var mxv: Float = 1e-6
                    for k in 0..<f.count { d[k] = abs(f[k] - before[k]); mxv = max(mxv, d[k]) }
                    for k in 0..<f.count { d[k] /= mxv }
                }
                mk(nd.id, d)
            }
        }
        if raw { return f }
        norm(&f)
        for j in 0..<R { for i in 0..<R {
            var v = f[i + j * R]
            if edge > 0 {
                let e = min(min(Float(i) * inv, 1 - Float(i) * inv), min(Float(j) * inv, 1 - Float(j) * inv)) * 2
                v *= sstep(0, max(edge, 0.01), e)
            }
            f[i + j * R] = max(v, sea)
        } }
        return f
    }

    /// Procedural colour: shore sand → grass → rock → snow by height (0...1), slope and sea level.
    static func colour(_ t: Float, _ slope: Float, _ sea: Float) -> simd_float3 {
        let r = max(1 - sea, 0.05), h = (t - sea) / r      // height above the shore, 0...1
        var c = lerp3(simd_float3(0.76, 0.68, 0.46), simd_float3(0.28, 0.5, 0.2), sstep(0.04, 0.2, h))
        c = lerp3(c, simd_float3(0.45, 0.42, 0.4), max(sstep(0.5, 0.75, h), sstep(0.12, 0.35, slope)))
        return lerp3(c, simd_float3(0.95), sstep(0.8, 0.95, h) * (1 - sstep(0.2, 0.5, slope)))
    }

    /// Small shaded preview: terrain colours, or (weights = true) the PBR layer weight map.
    static func preview(_ nodes: [TNode], edge: Float, sea: Float, scale: Float, seed: Int, amp: Float, layers: [PLayer], weights: Bool, size: Int = 96) -> UIImage? {
        let F = TerrainPBR.analyse(nodes, res: size, edge: edge, sea: sea, scale: scale, seed: seed, amp: amp)
        let f = F.f, R = size + 1, wm = weights && !layers.isEmpty
        var px = [UInt8](repeating: 255, count: size * size * 4)
        let L = simd_normalize(simd_float3(-0.5, 0.7, -0.5))
        for j in 0..<size { for i in 0..<size {
            let hx = f[min(i + 1, size) + j * R] - f[max(i - 1, 0) + j * R], hz = f[i + min(j + 1, size) * R] - f[i + max(j - 1, 0) * R]
            let n = simd_normalize(simd_float3(-hx * 6, 1, -hz * 6))
            let sh = 0.35 + 0.75 * max(0, simd_dot(n, L)), k = i + j * R, t = f[k]
            var c: simd_float3
            if t <= sea + 0.001 { c = simd_float3(0.16, 0.36, 0.55) }
            else if wm {
                let w = TerrainPBR.vertexW(F, layers, sea: sea, k), wb = 1 - min(1, w.max() ?? 0)
                var acc = simd_float3(0.4, 0.4, 0.4) * wb, tot = wb
                for (li, x) in w.enumerated() { acc += TerrainPBR.palette[li % 8] * x; tot += x }
                c = acc / max(tot, 1e-4)
            } else { c = colour(t, 1 - n.y, sea) }
            let o = (i + j * size) * 4
            px[o] = UInt8(max(0, min(255, c.x * sh * 255))); px[o + 1] = UInt8(max(0, min(255, c.y * sh * 255))); px[o + 2] = UInt8(max(0, min(255, c.z * sh * 255)))
        } }
        guard let ctx = CGContext(data: &px, width: size, height: size, bitsPerComponent: 8, bytesPerRow: size * 4, space: CGColorSpaceCreateDeviceRGB(),
                                  bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue), let img = ctx.makeImage() else { return nil }
        return UIImage(cgImage: img)
    }

    static let presets: [(String, [TNode], Float, Float)] = [      // name, nodes, edge fade, sea
        ("Rolling hills", [TNode(.hills, [2: 3]), TNode(.noise, [0: 6, 3: 0.15, 5: 0])], 0.3, 0),
        ("Mountains", [TNode(.ridged, [0: 3, 2: 0.55, 5: 3]), TNode(.noise, [0: 8, 3: 0.2, 5: 0]), TNode(.erode), TNode(.curve, [0: 1.4])], 0.25, 0),
        ("Islands", [TNode(.noise, [0: 3, 5: 3]), TNode(.warp), TNode(.island, [0: 0.85, 1: 0.5]), TNode(.smooth)], 0.15, 0.22),
        ("Mesa / canyon", [TNode(.noise, [0: 2.5, 5: 3]), TNode(.warp, [0: 0.1]), TNode(.level, [0: 0.15, 1: 0.7]), TNode(.terrace, [0: 5, 1: 0.5]), TNode(.erode, [0: 6])], 0.25, 0),
        ("Cratered moon", [TNode(.noise, [0: 4, 3: 0.4, 5: 3]), TNode(.craters, [0: 25, 1: 0.08, 2: 0.7])], 0.3, 0)]
}

// MARK: - PBR layers (per node / per node group), mixed by rules, baked into one base/MR/occlusion texture set

struct PLayer {
    var id: Int, nodes: [Int] = [], tex: String? = nil, texName = "", tiling: Float = 6, strength: Float = 1
    var hLo: Float = 0, hHi: Float = 1, hSoft: Float = 0.15       // height above sea, 0...1
    var sLo: Float = 0, sHi: Float = 1, sSoft: Float = 0.15       // slope, 0 flat ... 1 steep
    var wLo: Float = 0, wHi: Float = 0.5, wSoft: Float = 0.05     // shore: height above sea level (field units)
    var on = true
}

enum TerrainPBR {
    static let palette: [simd_float3] = [simd_float3(1, 0.3, 0.3), simd_float3(0.3, 0.8, 0.3), simd_float3(0.3, 0.5, 1), simd_float3(1, 0.85, 0.2),
                                         simd_float3(0.8, 0.4, 1), simd_float3(0.2, 0.9, 0.9), simd_float3(1, 0.6, 0.2), simd_float3(0.9, 0.5, 0.7)]
    struct Field { var f: [Float], slope: [Float], masks: [Int: [Float]], res: Int }
    struct TexSet { var s: Int; var avg = simd_float3(0.5, 0.5, 0.5); var diff: [UInt8]?, nor: [UInt8]?, rough: [UInt8]?, metal: [UInt8]?, ao: [UInt8]?, disp: [UInt8]? }
    struct Smp { var c = simd_float3(0, 0, 0), r: Float = 0.9, m: Float = 0, ao: Float = 1, h: Float = 0.5, nx: Float = 0, ny: Float = 0 }

    static func sst(_ a: Float, _ b: Float, _ x: Float) -> Float { let t = max(0, min(1, (x - a) / max(b - a, 1e-5))); return t * t * (3 - 2 * t) }
    static func band(_ lo: Float, _ hi: Float, _ soft: Float, _ x: Float, _ open: Float) -> Float {
        let up: Float = lo <= 0 ? 1 : sst(lo - soft * 0.5, lo + soft * 0.5, x)
        let dn: Float = hi >= open ? 1 : 1 - sst(hi - soft * 0.5, hi + soft * 0.5, x)
        return up * dn
    }

    static func analyse(_ nodes: [TNode], res: Int, edge: Float, sea: Float, scale: Float, seed: Int, amp: Float) -> Field {
        var masks: [Int: [Float]] = [:]
        let f = TerrainGraph.eval(nodes, res: res, edge: edge, sea: sea, scale: scale, seed: seed, masks: { masks[$0] = $1 })
        let R = res + 1, step = 1 / Float(res)
        var sl = [Float](repeating: 0, count: R * R)
        for j in 0..<R { for i in 0..<R {
            let i0 = max(i - 1, 0), i1 = min(i + 1, res), j0 = max(j - 1, 0), j1 = min(j + 1, res)
            let gx = (f[i1 + j * R] - f[i0 + j * R]) * amp / (Float(i1 - i0) * step), gz = (f[i + j1 * R] - f[i + j0 * R]) * amp / (Float(j1 - j0) * step)
            sl[i + j * R] = min(1, (1 - 1 / sqrtf(gx * gx + gz * gz + 1)) * 3)
        } }
        return Field(f: f, slope: sl, masks: masks, res: res)
    }

    /// Rule weight of every layer at vertex k: node mask × height band × slope band × shore band.
    static func vertexW(_ F: Field, _ L: [PLayer], sea: Float, _ k: Int) -> [Float] {
        let t = F.f[k], h = (t - sea) / max(1 - sea, 0.05), shore = t - sea, sl = F.slope[k]
        return L.map { l in
            var m: Float = 1
            if !l.nodes.isEmpty { m = 0; for n in l.nodes { if let a = F.masks[n] { m = max(m, a[k]) } }; m = sst(0.1, 0.5, m) }
            return m * band(l.hLo, l.hHi, l.hSoft, h, 1) * band(l.sLo, l.sHi, l.sSoft, sl, 1) * band(l.wLo, l.wHi, l.wSoft, shore, 0.5)
        }
    }

    // MARK: texture sampling
    static func raster(_ img: UIImage?, _ s: Int) -> [UInt8]? {
        guard let cg = img?.cgImage else { return nil }
        var d = [UInt8](repeating: 0, count: s * s * 4)
        let ok = d.withUnsafeMutableBytes { raw -> Bool in
            guard let c = CGContext(data: raw.baseAddress, width: s, height: s, bitsPerComponent: 8, bytesPerRow: s * 4, space: CGColorSpaceCreateDeviceRGB(),
                                    bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            c.interpolationQuality = .high; c.draw(cg, in: CGRect(x: 0, y: 0, width: s, height: s)); return true
        }
        return ok ? d : nil
    }
    static func texSet(_ m: PolyHaven.Maps, _ s: Int) -> TexSet {
        func g(_ i: UIImage?) -> [UInt8]? { guard let r = raster(i, s) else { return nil }; return (0..<(s * s)).map { r[$0 * 4] } }
        var ts = TexSet(s: s, diff: raster(m.diff, s), nor: raster(m.nor, s), rough: g(m.rough), metal: g(m.metal), ao: g(m.ao), disp: g(m.disp))
        if let d = ts.diff {
            var a = simd_float3(0, 0, 0), cnt: Float = 0
            for p in stride(from: 0, to: d.count / 4, by: 37) { a += simd_float3(Float(d[p * 4]), Float(d[p * 4 + 1]), Float(d[p * 4 + 2])) / 255; cnt += 1 }
            if cnt > 0 { ts.avg = a / cnt }
        }
        return ts
    }
    @inline(__always) static func bil(_ a: [UInt8], _ s: Int, _ x: Float, _ y: Float, _ st: Int, _ c: Int) -> Float {
        let X = (x - floorf(x)) * Float(s), Y = (y - floorf(y)) * Float(s)
        let x0 = min(Int(X), s - 1), y0 = min(Int(Y), s - 1), tx = X - Float(x0), ty = Y - Float(y0)
        let x1 = (x0 + 1) % s, y1 = (y0 + 1) % s
        let p00 = Float(a[(x0 + y0 * s) * st + c]), p10 = Float(a[(x1 + y0 * s) * st + c]), p01 = Float(a[(x0 + y1 * s) * st + c]), p11 = Float(a[(x1 + y1 * s) * st + c])
        return ((p00 + (p10 - p00) * tx) * (1 - ty) + (p01 + (p11 - p01) * tx) * ty) / 255
    }
    static func sample(_ T: TexSet, _ x: Float, _ y: Float, _ nm: Bool) -> Smp {
        var s = Smp(); let z = T.s
        if let d = T.diff { s.c = simd_float3(bil(d, z, x, y, 4, 0), bil(d, z, x, y, 4, 1), bil(d, z, x, y, 4, 2)) } else { s.c = simd_float3(0.5, 0.5, 0.5) }
        if let a = T.rough { s.r = bil(a, z, x, y, 1, 0) }
        if let a = T.metal { s.m = bil(a, z, x, y, 1, 0) }
        if let a = T.ao { s.ao = bil(a, z, x, y, 1, 0) }
        if let a = T.disp { s.h = bil(a, z, x, y, 1, 0) }
        if nm, let n = T.nor { s.nx = bil(n, z, x, y, 4, 0) * 2 - 1; s.ny = bil(n, z, x, y, 4, 1) * 2 - 1 }
        return s
    }
    static func lerpS(_ a: Smp, _ b: Smp, _ t: Float) -> Smp {
        var o = Smp(); let u = 1 - t
        o.c = a.c * u + b.c * t; o.r = a.r * u + b.r * t; o.m = a.m * u + b.m * t; o.ao = a.ao * u + b.ao * t
        o.h = a.h * u + b.h * t; o.nx = a.nx * u + b.nx * t; o.ny = a.ny * u + b.ny * t
        return o
    }
    /// Anti-repeat: the texture at two scales (second one rotated 37°), mixed by a slow low-frequency pattern.
    static func mix2(_ T: TexSet, _ x: Float, _ y: Float, _ u: Float, _ v: Float, _ nm: Bool) -> Smp {
        let a = sample(T, x, y, nm), cs: Float = 0.7986, sn: Float = 0.6018
        var b = sample(T, (x * cs - y * sn) * 0.93 + 17.3, (x * sn + y * cs) * 0.93 + 5.1, nm)
        let bx = b.nx, by = b.ny; b.nx = bx * cs + by * sn; b.ny = -bx * sn + by * cs
        let k = 0.5 + 0.3 * sinf(u * 9.1 + v * 5.3) * cosf(v * 7.7 - u * 3.9)
        var o = lerpS(a, b, k)
        let g = 1 / sqrtf(k * k + (1 - k) * (1 - k))      // variance-preserving blend: keeps contrast instead of washing out
        o.c = T.avg + (o.c - T.avg) * g; o.h = 0.5 + (o.h - 0.5) * g; o.nx *= g; o.ny *= g
        return o
    }
    /// Planar sample; on steep slopes blended with an XY/ZY projection (triplanar-like) so cliffs don't stretch.
    static func layerSample(_ T: TexSet, _ L: PLayer, _ u: Float, _ v: Float, _ yh: Float, _ sl: Float) -> Smp {
        let tl = L.tiling
        var s = mix2(T, u * tl, v * tl, u, v, true)
        let st = sst(0.35, 0.75, sl)
        if st > 0.02 {
            var t = lerpS(mix2(T, u * tl, yh * tl, u, v, false), mix2(T, v * tl, yh * tl, u, v, false), 0.5)
            t.nx = s.nx; t.ny = s.ny
            s = lerpS(s, t, st)
        }
        return s
    }
    static func img(_ d: [UInt8], _ T: Int) -> UIImage? {
        var d = d
        return d.withUnsafeMutableBytes { raw -> UIImage? in
            guard let c = CGContext(data: raw.baseAddress, width: T, height: T, bitsPerComponent: 8, bytesPerRow: T * 4, space: CGColorSpaceCreateDeviceRGB(),
                                    bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue), let cg = c.makeImage() else { return nil }
            return UIImage(cgImage: cg)
        }
    }
    @inline(__always) static func b8(_ v: Float) -> UInt8 { UInt8(max(0, min(255, v * 255))) }

    struct SplatData { var w0: Data, w1: Data, layers: [(d: Data, n: Data, r: Data, tile: Float, str: Float)] }

    /// Splat export: the renderer tiles each layer's own maps per pixel (no big baked texture), so only the rule
    /// weight maps (1024) and a procedural macro colour are baked here. Max 4 textured layers.
    static func bake(_ o: TerrainGLB.Opt, layers all: [PLayer], sets: [String: TexSet], size: Int) -> (ExtrasGLB.Packed, SplatData)? {
        let layers = Array(all.filter { $0.tex != nil && sets[$0.tex!] != nil }.prefix(4))
        if layers.isEmpty { return nil }
        let F = analyse(o.nodes, res: o.res, edge: o.edge, sea: o.sea, scale: o.scale, seed: o.seed, amp: o.height)
        let res = o.res, R = res + 1, n = layers.count, sea = o.sea, T = 1024
        var VW = [[Float]](repeating: [Float](repeating: 0, count: R * R), count: n)
        for k in 0..<(R * R) { let w = vertexW(F, layers, sea: sea, k); for l in 0..<n { VW[l][k] = w[l] } }
        var w0 = [UInt8](repeating: 255, count: T * T * 4), w1 = w0, base = w0
        let resF = Float(res), invT = 1 / Float(T)
        for y in 0..<T {
            let v = (Float(y) + 0.5) * invT, gy = min(v * resF, resF - 0.001), j0 = Int(gy), fy = gy - Float(j0)
            for x in 0..<T {
                let u = (Float(x) + 0.5) * invT, gx = min(u * resF, resF - 0.001), i0 = Int(gx), fx = gx - Float(i0)
                let k00 = i0 + j0 * R, k10 = k00 + 1, k01 = k00 + R, k11 = k01 + 1
                let a00 = (1 - fx) * (1 - fy), a10 = fx * (1 - fy), a01 = (1 - fx) * fy, a11 = fx * fy
                let q = (x + y * T) * 4
                for l in 0..<n {
                    let a = VW[l], w = a[k00] * a00 + a[k10] * a10 + a[k01] * a01 + a[k11] * a11
                    if l < 3 { w0[q + l] = b8(w) } else { w1[q] = b8(w) }
                }
                for l in n..<3 { w0[q + l] = 0 }
                if n < 4 { w1[q] = 0 }
                w1[q + 1] = 0; w1[q + 2] = 0
                let t = F.f[k00] * a00 + F.f[k10] * a10 + F.f[k01] * a01 + F.f[k11] * a11, sl = F.slope[k00] * a00 + F.slope[k10] * a10 + F.slope[k01] * a01 + F.slope[k11] * a11
                let tint = 0.9 + 0.2 * (0.5 + 0.5 * sinf(u * 17 + sinf(v * 11) * 2) * cosf(v * 13 - u * 5))
                let c = TerrainGraph.colour(t, sl / 3, sea) * tint
                base[q] = b8(c.x); base[q + 1] = b8(c.y); base[q + 2] = b8(c.z)
            }
        }
        var ph = [UInt8](repeating: 255, count: 16 * 4), po = ph
        for i in 0..<16 { ph[i * 4] = 128; ph[i * 4 + 1] = 230; ph[i * 4 + 2] = 0; po[i * 4] = 255; po[i * 4 + 1] = 128; po[i * 4 + 2] = 128 }
        var out: [(d: Data, n: Data, r: Data, tile: Float, str: Float)] = []
        for L in layers {
            let ts = sets[L.tex!]!, z = ts.s, cnt = z * z
            var dd = [UInt8](repeating: 255, count: cnt * 4), nm = dd, rh = dd
            for i in 0..<cnt {
                if let d = ts.diff { dd[i * 4] = d[i * 4]; dd[i * 4 + 1] = d[i * 4 + 1]; dd[i * 4 + 2] = d[i * 4 + 2] } else { dd[i * 4] = 128; dd[i * 4 + 1] = 128; dd[i * 4 + 2] = 128 }
                nm[i * 4] = ts.nor?[i * 4] ?? 128; nm[i * 4 + 1] = ts.nor?[i * 4 + 1] ?? 128; nm[i * 4 + 2] = ts.ao?[i] ?? 255
                rh[i * 4] = ts.disp?[i] ?? 128; rh[i * 4 + 1] = ts.rough?[i] ?? 230; rh[i * 4 + 2] = ts.metal?[i] ?? 0
            }
            guard let dj = img(dd, z)?.jpegData(compressionQuality: 0.9), let np = img(nm, z)?.pngData(), let rp = img(rh, z)?.pngData() else { continue }
            out.append((d: dj, n: np, r: rp, tile: L.tiling, str: L.strength))
        }
        guard !out.isEmpty, let wa = img(w0, T)?.pngData(), let wb = img(w1, T)?.pngData() else { return nil }
        let pk = ExtrasGLB.Packed(base: img(base, T)?.jpegData(compressionQuality: 0.9), mr: img(ph, 4)?.pngData(), occ: img(po, 4)?.pngData(), hasNormal: true)
        return (pk, SplatData(w0: wa, w1: wb, layers: out))
    }
}

enum TerrainGLB {
    struct Opt {
        var nodes: [TNode] = [], res = 128, height: Float = 0.25, edge: Float = 0.3, sea: Float = 0, tiles = 4, scale: Float = 1, seed = 0
    }

    static func build(_ o: Opt, _ p: ExtrasGLB.Packed?, splat: TerrainPBR.SplatData? = nil) -> Data {
        let res = o.res, R = res + 1
        let amp = o.height
        var hs = [Float](repeating: 0, count: R * R)
        let field = TerrainGraph.eval(o.nodes, res: res, edge: o.edge, sea: o.sea, scale: o.scale, seed: o.seed)
        for k in 0..<(R * R) { hs[k] = field[k] * amp }
        var pos: [Float] = [], nor: [Float] = [], uv: [Float] = [], col: [Float] = [], idx: [UInt32] = []
        let step = 1 / Float(res)
        for j in 0..<R { for i in 0..<R {
            let a = Float(i) * step, b = Float(j) * step, y = hs[i + j * R]
            pos += [(a - 0.5) * o.scale, y * o.scale, (b - 0.5) * o.scale]
            let dx = hs[min(i + 1, res) + j * R] - hs[max(i - 1, 0) + j * R], dz = hs[i + min(j + 1, res) * R] - hs[i + max(j - 1, 0) * R]
            let sx = Float(min(i + 1, res) - max(i - 1, 0)) * step, sz = Float(min(j + 1, res) - max(j - 1, 0)) * step
            let n = simd_normalize(simd_float3(-dx / sx, 1, -dz / sz))
            nor += [n.x, n.y, n.z]
            uv += [a * Float(o.tiles), b * Float(o.tiles)]
            if p?.base != nil { col += [1, 1, 1, 1] } else {      // no texture: shore → grass → rock → snow by height and slope
                let c = TerrainGraph.colour(amp > 0 ? y / amp : 0.5, 1 - n.y, o.sea)
                col += [c.x, c.y, c.z, 1]
            }
        } }
        for j in 0..<res { for i in 0..<res {
            let a = UInt32(i + j * R)
            idx += [a, a + 1, a + UInt32(R), a + 1, a + UInt32(R) + 1, a + UInt32(R)]
        } }
        var bin = Data(); var views: [[String: Any]] = []
        func add(_ d: Data, _ t: Int?) -> Int {
            while bin.count % 4 != 0 { bin.append(0) }
            var v: [String: Any] = ["buffer": 0, "byteOffset": bin.count, "byteLength": d.count]
            if let t = t { v["target"] = t }
            bin.append(d); views.append(v); return views.count - 1
        }
        func bytes<T>(_ a: [T]) -> Data { a.withUnsafeBytes { Data($0) } }
        let vp = add(bytes(pos), 34962), vn_ = add(bytes(nor), 34962), vu = add(bytes(uv), 34962), vi = add(bytes(idx), 34963), vc = add(bytes(col), 34962)
        let nv = pos.count / 3
        var mn: [Float] = [1e9, 1e9, 1e9], mx: [Float] = [-1e9, -1e9, -1e9]
        for i in 0..<nv { for k in 0..<3 { mn[k] = min(mn[k], pos[i * 3 + k]); mx[k] = max(mx[k], pos[i * 3 + k]) } }
        let acc: [[String: Any]] = [
            ["bufferView": vp, "componentType": 5126, "count": nv, "type": "VEC3", "min": mn, "max": mx],
            ["bufferView": vn_, "componentType": 5126, "count": nv, "type": "VEC3"],
            ["bufferView": vu, "componentType": 5126, "count": nv, "type": "VEC2"],
            ["bufferView": vi, "componentType": 5125, "count": idx.count, "type": "SCALAR"],
            ["bufferView": vc, "componentType": 5126, "count": nv, "type": "VEC4"]]
        var images: [[String: Any]] = [], textures: [[String: Any]] = []
        func tex(_ d: Data?, _ mime: String) -> Int? {
            guard let d = d else { return nil }
            images.append(["bufferView": add(d, nil), "mimeType": mime]); textures.append(["source": images.count - 1, "sampler": 0])
            return textures.count - 1
        }
        var pbr: [String: Any] = ["metallicFactor": 1.0, "roughnessFactor": 1.0]
        var mat: [String: Any] = ["doubleSided": true]
        if let b = tex(p?.base, "image/jpeg") { pbr["baseColorTexture"] = ["index": b] } else { pbr["baseColorFactor"] = [1, 1, 1, 1] }
        if let m = tex(p?.mr, "image/png") { pbr["metallicRoughnessTexture"] = ["index": m] } else { pbr["metallicFactor"] = 0.0; pbr["roughnessFactor"] = 0.9 }
        if let oc = tex(p?.occ, "image/png") { mat["occlusionTexture"] = ["index": oc] }
        mat["pbrMetallicRoughness"] = pbr
        var asset: [String: Any] = ["version": "2.0", "generator": "SaikiMotion Terrain"]
        if let sd = splat {
            var ls: [[String: Any]] = []
            for L in sd.layers { ls.append(["d": add(L.d, nil), "n": add(L.n, nil), "r": add(L.r, nil), "tile": L.tile, "str": L.str]) }
            asset["extras"] = ["splat": ["w0": add(sd.w0, nil), "w1": add(sd.w1, nil), "layers": ls]]
        }
        let json: [String: Any] = [
            "asset": asset, "scene": 0, "scenes": [["nodes": [0]]], "nodes": [["mesh": 0]],
            "meshes": [["primitives": [["attributes": ["POSITION": 0, "NORMAL": 1, "TEXCOORD_0": 2, "COLOR_0": 4], "indices": 3, "material": 0]]]],
            "materials": [mat], "accessors": acc, "bufferViews": views, "buffers": [["byteLength": bin.count]],
            "samplers": [["magFilter": 9729, "minFilter": 9987, "wrapS": 10497, "wrapT": 10497]], "images": images, "textures": textures]
        var js = (try? JSONSerialization.data(withJSONObject: json)) ?? Data()
        while js.count % 4 != 0 { js.append(0x20) }
        while bin.count % 4 != 0 { bin.append(0) }
        var out = Data()
        func u32(_ v: UInt32) { var x = v.littleEndian; withUnsafeBytes(of: &x) { out.append(contentsOf: $0) } }
        u32(0x46546C67); u32(2); u32(UInt32(12 + 8 + js.count + 8 + bin.count))
        u32(UInt32(js.count)); u32(0x4E4F534A); out.append(js)
        u32(UInt32(bin.count)); u32(0x004E4942); out.append(bin)
        return out
    }
}

// MARK: - panel

final class TerrainPanel: UIView, UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate {
    private weak var host: EditorViewController?
    private let accent = UIColor(red: 1, green: 0.55, blue: 0.08, alpha: 1)
    private let tabs = UISegmentedControl(items: ["Shape", "Nodes", "Material"])
    private let resSeg = UISegmentedControl(items: ["Low", "Medium", "High"])
    private let texRes = UISegmentedControl(items: ["1k (fast)", "2k"])
    private let search = UISearchBar(), table = UITableView(), status = UILabel(), addBtn = UIButton(type: .system)
    private let previewView = UIImageView(), nodeStack = UIStackView()
    private var pages: [UIStackView] = []
    private var all: [(id: String, name: String)] = [], shown: [(id: String, name: String)] = []
    private var busy = false, previewWork: DispatchWorkItem?
    private let viewSeg = UISegmentedControl(items: ["Shaded", "PBR weights"])
    private let layerStack = UIStackView(), layerEditor = UIStackView(), layerSliders = UIStackView(), assignBtn = UIButton(type: .system)
    private var curLayer: PLayer? { let i = TerrainPanel.selLayer; return TerrainPanel.layers.indices.contains(i) ? TerrainPanel.layers[i] : nil }
    private var pick: Int { guard let id = curLayer?.tex else { return -1 }; return shown.firstIndex { $0.id == id } ?? -1 }
    // remembered between openings
    static var nodes: [TNode] = TerrainGraph.presets[1].1
    static var height: Float = 0.35, edge: Float = 0.25, sea: Float = 0, genScale: Float = 1, genSeed: Float = 1, relief: Float = 0.8
    static var pendingGraph: String? = nil, replacing: Layer? = nil, localSets: [String: PolyHaven.Maps] = [:]
    static var procOpen = false, layers: [PLayer] = [], selNodes = Set<Int>(), selLayer = -1, viewMode = 0, nextLayer = 1

    static func present(in host: EditorViewController, over view: UIView) {
        if view.subviews.contains(where: { $0 is TerrainPanel }) { return }
        let v = TerrainPanel(host: host)
        v.translatesAutoresizingMaskIntoConstraints = false; view.addSubview(v)
        NSLayoutConstraint.activate([v.leadingAnchor.constraint(equalTo: view.leadingAnchor), v.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                                     v.topAnchor.constraint(equalTo: view.topAnchor), v.bottomAnchor.constraint(equalTo: view.bottomAnchor)])
    }

    init(host: EditorViewController) {
        self.host = host
        super.init(frame: .zero)
        backgroundColor = UIColor(white: 0, alpha: 0.55)
        build(); rebuildNodes(); rebuildMaterial(); updatePreview()
        PolyHaven.list { [weak self] l in DispatchQueue.main.async {
            self?.all = l; self?.filter("")
            if l.isEmpty { self?.status.text = "Could not reach Poly Haven. Check your connection." } } }
    }
    required init?(coder: NSCoder) { fatalError() }

    // MARK: ui helpers
    private func label(_ t: String, _ size: CGFloat = 13, _ w: UIFont.Weight = .regular, _ c: UIColor = UIColor(white: 0.7, alpha: 1)) -> UILabel {
        let l = UILabel(); l.text = t; l.textColor = c; l.font = .systemFont(ofSize: size, weight: w); return l
    }
    private func style(_ s: UISegmentedControl) {
        s.selectedSegmentTintColor = accent
        s.setTitleTextAttributes([.foregroundColor: UIColor.white], for: .normal); s.setTitleTextAttributes([.foregroundColor: UIColor.black], for: .selected)
    }
    private func slider(_ title: String, _ lo: Float, _ hi: Float, _ v: Float, _ fmt: String = "%.2f", _ cb: @escaping (Float) -> Void) -> UIStackView {
        let l = label(title); l.widthAnchor.constraint(equalToConstant: 84).isActive = true
        let val = label(String(format: fmt, v), 12); val.textAlignment = .right; val.widthAnchor.constraint(equalToConstant: 42).isActive = true
        let s = UISlider(); s.minimumValue = lo; s.maximumValue = hi; s.value = v; s.tintColor = accent
        s.addAction(UIAction { [weak s, weak val] _ in guard let s = s else { return }; val?.text = String(format: fmt, s.value); cb(s.value) }, for: .valueChanged)
        let r = UIStackView(arrangedSubviews: [l, s, val]); r.spacing = 8; r.alignment = .center; return r
    }
    private func iconBtn(_ name: String, _ tint: UIColor = .white, _ h: @escaping () -> Void) -> UIButton {
        let b = UIButton(type: .system); b.setImage(UIImage(systemName: name), for: .normal); b.tintColor = tint
        b.widthAnchor.constraint(equalToConstant: 30).isActive = true; b.addAction(UIAction { _ in h() }, for: .touchUpInside); return b
    }

    private func build() {
        let card = UIView(); card.backgroundColor = UIColor(white: 0.09, alpha: 1); card.layer.cornerRadius = 22
        card.translatesAutoresizingMaskIntoConstraints = false; addSubview(card)
        let title = label("Terrain", 22, .bold, .white)
        let x = UIButton(type: .system); x.setImage(UIImage(systemName: "xmark"), for: .normal); x.tintColor = .white
        x.addTarget(self, action: #selector(close), for: .touchUpInside)
        let head = UIStackView(arrangedSubviews: [title, UIView(), x]); head.alignment = .center
        previewView.contentMode = .scaleAspectFill; previewView.clipsToBounds = true; previewView.layer.cornerRadius = 12
        previewView.layer.magnificationFilter = .linear; previewView.backgroundColor = UIColor(white: 0.14, alpha: 1)
        previewView.heightAnchor.constraint(equalToConstant: 150).isActive = true
        for s in [tabs, resSeg, texRes, viewSeg] { style(s) }
        viewSeg.selectedSegmentIndex = TerrainPanel.viewMode
        viewSeg.addAction(UIAction { [weak self] _ in TerrainPanel.viewMode = self?.viewSeg.selectedSegmentIndex ?? 0; self?.updatePreview() }, for: .valueChanged)
        tabs.selectedSegmentIndex = 0; resSeg.selectedSegmentIndex = 1; texRes.selectedSegmentIndex = 0
        tabs.addAction(UIAction { [weak self] _ in self?.showTab() }, for: .valueChanged)

        // Shape
        let presetBtn = UIButton(type: .system); presetBtn.setTitle("Start from a preset…", for: .normal); presetBtn.tintColor = accent
        presetBtn.contentHorizontalAlignment = .leading; presetBtn.showsMenuAsPrimaryAction = true
        presetBtn.menu = UIMenu(children: TerrainGraph.presets.map { pr in UIAction(title: pr.0) { [weak self] _ in
            guard let self = self else { return }
            TerrainPanel.nodes = pr.1; TerrainPanel.edge = pr.2; TerrainPanel.sea = pr.3
            TerrainPanel.layers = []; TerrainPanel.selLayer = -1; TerrainPanel.selNodes = []
            self.rebuildShape(); self.rebuildNodes(); self.rebuildMaterial(); self.updatePreview() } })
        shapeBox.axis = .vertical; shapeBox.spacing = 10
        rebuildShape()

        // Nodes
        let addNode = UIButton(type: .system); addNode.setTitle("＋ Add node", for: .normal); addNode.tintColor = accent
        addNode.contentHorizontalAlignment = .leading; addNode.showsMenuAsPrimaryAction = true
        func grp(_ t: String, _ gen: Bool) -> UIMenu {
            UIMenu(title: t, options: .displayInline, children: TKind.allCases.filter { $0.isGen == gen && ![.baked, .blend, .pbr, .heightTex].contains($0) }.map { k in
                UIAction(title: k.title, image: UIImage(systemName: k.icon)) { [weak self] _ in
                    TerrainPanel.nodes.append(TNode(k)); self?.rebuildNodes(); self?.updatePreview() } })
        }
        addNode.menu = UIMenu(children: [grp("Modifiers", false), grp("Generators", true)])
        nodeStack.axis = .vertical; nodeStack.spacing = 10
        let hint = label("Nodes run top to bottom. Generators build height, modifiers reshape what's above them.", 11)
        hint.numberOfLines = 0
        assignBtn.tintColor = accent; assignBtn.contentHorizontalAlignment = .leading; assignBtn.isHidden = true
        assignBtn.addAction(UIAction { [weak self] _ in
            let ids = TerrainPanel.nodes.map { $0.id }.filter { TerrainPanel.selNodes.contains($0) }
            if !ids.isEmpty { self?.newLayer(ids) } }, for: .touchUpInside)
        let graphBtn = UIButton(type: .system); graphBtn.setTitle("◇ Open node graph (wires + 3D preview)", for: .normal); graphBtn.tintColor = accent
        graphBtn.contentHorizontalAlignment = .leading
        graphBtn.addAction(UIAction { [weak self] _ in
            guard let self = self, let h = self.host else { return }
            TerrainNodeEditor.present(in: h, over: self, graph: TGraph.fromStack(TerrainPanel.nodes, edge: TerrainPanel.edge, sea: TerrainPanel.sea), layer: nil, parent: self) }, for: .touchUpInside)
        let nodesBox = UIStackView(arrangedSubviews: [graphBtn, addNode, hint, assignBtn, nodeStack]); nodesBox.axis = .vertical; nodesBox.spacing = 8

        // Material
        search.placeholder = "Search Poly Haven textures (rock, sand, grass…)"; search.searchBarStyle = .minimal; search.delegate = self
        search.searchTextField.textColor = .white; search.autocapitalizationType = .none
        table.dataSource = self; table.delegate = self; table.backgroundColor = .clear; table.rowHeight = 56
        table.separatorColor = UIColor(white: 1, alpha: 0.08)
        table.heightAnchor.constraint(equalToConstant: 220).isActive = true
        layerStack.axis = .vertical; layerStack.spacing = 4; layerSliders.axis = .vertical; layerSliders.spacing = 8
        let addLayer = UIButton(type: .system); addLayer.setTitle("＋ PBR layer for the whole terrain", for: .normal); addLayer.tintColor = accent
        addLayer.contentHorizontalAlignment = .leading; addLayer.addAction(UIAction { [weak self] _ in self?.newLayer([]) }, for: .touchUpInside)
        layerEditor.axis = .vertical; layerEditor.spacing = 10
        for v in [label("Poly Haven material (selected layer)", 15, .semibold, .white), search, table, layerSliders] { layerEditor.addArrangedSubview(v) }
        let matBox = UIStackView(arrangedSubviews: [label("PBR layers", 15, .semibold, .white), layerStack, addLayer, layerEditor,
            slider("Relief", 0, 1, TerrainPanel.relief) { TerrainPanel.relief = $0 },
            { let r = UIStackView(arrangedSubviews: [self.label("Tex quality"), self.texRes]); r.spacing = 10; return r }()])
        matBox.axis = .vertical; matBox.spacing = 10

        pages = [shapeBox, nodesBox, matBox]
        status.textColor = UIColor(white: 0.7, alpha: 1); status.font = .systemFont(ofSize: 12); status.numberOfLines = 2
        addBtn.setTitle("Add terrain", for: .normal); addBtn.setTitleColor(.black, for: .normal)
        addBtn.titleLabel?.font = .systemFont(ofSize: 17, weight: .bold); addBtn.backgroundColor = accent; addBtn.layer.cornerRadius = 14
        addBtn.addTarget(self, action: #selector(addTap), for: .touchUpInside)
        addBtn.heightAnchor.constraint(equalToConstant: 48).isActive = true

        let body = UIStackView(arrangedSubviews: pages); body.axis = .vertical; body.translatesAutoresizingMaskIntoConstraints = false
        let scroll = UIScrollView(); scroll.translatesAutoresizingMaskIntoConstraints = false; scroll.keyboardDismissMode = .onDrag
        scroll.addSubview(body)
        let stack = UIStackView(arrangedSubviews: [head, previewView, viewSeg, tabs, scroll, status, addBtn]); stack.axis = .vertical; stack.spacing = 10
        stack.translatesAutoresizingMaskIntoConstraints = false; card.addSubview(stack)
        NSLayoutConstraint.activate([
            card.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 12), card.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -12),
            card.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor, constant: 40), card.bottomAnchor.constraint(equalTo: safeAreaLayoutGuide.bottomAnchor, constant: -12),
            stack.leadingAnchor.constraint(equalTo: card.leadingAnchor, constant: 16), stack.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -16),
            stack.topAnchor.constraint(equalTo: card.topAnchor, constant: 16), stack.bottomAnchor.constraint(equalTo: card.bottomAnchor, constant: -16),
            body.leadingAnchor.constraint(equalTo: scroll.contentLayoutGuide.leadingAnchor), body.trailingAnchor.constraint(equalTo: scroll.contentLayoutGuide.trailingAnchor),
            body.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor), body.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor),
            body.widthAnchor.constraint(equalTo: scroll.frameLayoutGuide.widthAnchor)])
        presetRef = presetBtn
        shapeBox.insertArrangedSubview(presetBtn, at: 0)
        showTab()
    }
    private let shapeBox = UIStackView()
    private var presetRef: UIButton?

    private func rebuildShape() {
        for v in shapeBox.arrangedSubviews where v !== presetRef { shapeBox.removeArrangedSubview(v); v.removeFromSuperview() }
        shapeBox.addArrangedSubview(slider("Height", 0, 1, TerrainPanel.height) { [weak self] in TerrainPanel.height = $0; self?.updatePreview() })
        shapeBox.addArrangedSubview(slider("Edge fade", 0, 1, TerrainPanel.edge) { [weak self] in TerrainPanel.edge = $0; self?.updatePreview() })
        shapeBox.addArrangedSubview(slider("Sea level", 0, 0.6, TerrainPanel.sea) { [weak self] in TerrainPanel.sea = $0; self?.updatePreview() })
        let disc = UIButton(type: .system)
        disc.setTitle((TerrainPanel.procOpen ? "▾ " : "▸ ") + "Procedural generation", for: .normal); disc.tintColor = accent
        disc.titleLabel?.font = .systemFont(ofSize: 15, weight: .semibold); disc.contentHorizontalAlignment = .leading
        disc.addAction(UIAction { [weak self] _ in TerrainPanel.procOpen.toggle(); self?.rebuildShape() }, for: .touchUpInside)
        shapeBox.addArrangedSubview(disc)
        if TerrainPanel.procOpen {
            shapeBox.addArrangedSubview(slider("Scale", 0.25, 4, TerrainPanel.genScale) { [weak self] in TerrainPanel.genScale = $0; self?.updatePreview() })
            shapeBox.addArrangedSubview(slider("Seed", 1, 999, TerrainPanel.genSeed, "%.0f") { [weak self] in TerrainPanel.genSeed = $0.rounded(); self?.updatePreview() })
            let rnd = UIButton(type: .system); rnd.setTitle("🎲 Randomize", for: .normal); rnd.tintColor = accent; rnd.contentHorizontalAlignment = .leading
            rnd.addAction(UIAction { [weak self] _ in TerrainPanel.genSeed = Float(Int.random(in: 1...999)); self?.rebuildShape(); self?.updatePreview() }, for: .touchUpInside)
            shapeBox.addArrangedSubview(rnd)
        }
        let r = UIStackView(arrangedSubviews: [label("Mesh detail"), resSeg]); r.spacing = 10; r.alignment = .center
        shapeBox.addArrangedSubview(r)
    }

    private func rebuildNodes() {
        nodeStack.arrangedSubviews.forEach { nodeStack.removeArrangedSubview($0); $0.removeFromSuperview() }
        for (idx, nd) in TerrainPanel.nodes.enumerated() {
            let card = UIStackView(); card.axis = .vertical; card.spacing = 8; card.isLayoutMarginsRelativeArrangement = true
            card.layoutMargins = UIEdgeInsets(top: 10, left: 12, bottom: 10, right: 12)
            let bg = UIView(); bg.backgroundColor = UIColor(white: 0.15, alpha: 1); bg.layer.cornerRadius = 12; bg.translatesAutoresizingMaskIntoConstraints = false
            card.insertSubview(bg, at: 0)
            NSLayoutConstraint.activate([bg.leadingAnchor.constraint(equalTo: card.leadingAnchor), bg.trailingAnchor.constraint(equalTo: card.trailingAnchor),
                                         bg.topAnchor.constraint(equalTo: card.topAnchor), bg.bottomAnchor.constraint(equalTo: card.bottomAnchor)])
            let ic = UIImageView(image: UIImage(systemName: nd.kind.icon)); ic.tintColor = nd.kind.isGen ? accent : UIColor(red: 0.4, green: 0.7, blue: 1, alpha: 1)
            ic.contentMode = .scaleAspectFit; ic.widthAnchor.constraint(equalToConstant: 22).isActive = true
            let t = label("\(idx + 1). \(nd.kind.title)", 14, .semibold, nd.on ? .white : UIColor(white: 0.45, alpha: 1))
            let hd = UIStackView(arrangedSubviews: [ic, t, UIView(),
                iconBtn(nd.on ? "eye" : "eye.slash") { [weak self] in TerrainPanel.nodes[idx].on.toggle(); self?.rebuildNodes(); self?.updatePreview() },
                iconBtn("chevron.up") { [weak self] in if idx > 0 { TerrainPanel.nodes.swapAt(idx, idx - 1); self?.rebuildNodes(); self?.updatePreview() } },
                iconBtn("chevron.down") { [weak self] in if idx < TerrainPanel.nodes.count - 1 { TerrainPanel.nodes.swapAt(idx, idx + 1); self?.rebuildNodes(); self?.updatePreview() } },
                iconBtn("trash", UIColor(red: 1, green: 0.4, blue: 0.4, alpha: 1)) { [weak self] in TerrainPanel.selNodes.remove(TerrainPanel.nodes[idx].id); TerrainPanel.nodes.remove(at: idx); self?.rebuildNodes(); self?.updatePreview() }])
            hd.alignment = .center; hd.spacing = 2; card.addArrangedSubview(hd)
            let sel = TerrainPanel.selNodes.contains(nd.id)
            let selB = UIButton(type: .system); selB.setTitle(sel ? "☑ Selected" : "☐ Select", for: .normal)
            selB.tintColor = sel ? accent : UIColor(white: 0.75, alpha: 1); selB.titleLabel?.font = .systemFont(ofSize: 12, weight: .medium)
            selB.addAction(UIAction { [weak self] _ in
                if TerrainPanel.selNodes.contains(nd.id) { TerrainPanel.selNodes.remove(nd.id) } else { TerrainPanel.selNodes.insert(nd.id) }
                self?.rebuildNodes() }, for: .touchUpInside)
            let pb = UIButton(type: .system); pb.setTitle("＋ PBR layer", for: .normal); pb.tintColor = accent; pb.titleLabel?.font = .systemFont(ofSize: 12, weight: .medium)
            pb.addAction(UIAction { [weak self] _ in self?.newLayer([nd.id]) }, for: .touchUpInside)
            let used = TerrainPanel.layers.enumerated().filter { $0.element.nodes.contains(nd.id) }.map { "L\($0.offset + 1)" }
            let info = label(used.isEmpty ? "" : "PBR: " + used.joined(separator: ", "), 11, .regular, accent)
            let prow = UIStackView(arrangedSubviews: [selB, pb, UIView(), info]); prow.spacing = 12; prow.alignment = .center; card.addArrangedSubview(prow)
            for (pi, sp) in nd.kind.params.enumerated() {
                if let opts = sp.4 {
                    let seg = UISegmentedControl(items: opts); style(seg); seg.selectedSegmentIndex = Int(nd.p[pi])
                    seg.addAction(UIAction { [weak self, weak seg] _ in
                        guard let seg = seg else { return }; TerrainPanel.nodes[idx].p[pi] = Float(seg.selectedSegmentIndex); self?.updatePreview() }, for: .valueChanged)
                    let r = UIStackView(arrangedSubviews: [label(sp.0), seg]); r.spacing = 8; r.alignment = .center; card.addArrangedSubview(r)
                } else {
                    let whole = sp.2 - sp.1 >= 8
                    card.addArrangedSubview(slider(sp.0, sp.1, sp.2, nd.p[pi], whole ? "%.0f" : "%.2f") { [weak self] v in
                        TerrainPanel.nodes[idx].p[pi] = whole ? v.rounded() : v; self?.updatePreview() })
                }
            }
            nodeStack.addArrangedSubview(card)
        }
        let ns = TerrainPanel.selNodes.count
        assignBtn.setTitle("◎ One PBR layer for \(ns) selected node\(ns == 1 ? "" : "s")", for: .normal); assignBtn.isHidden = ns == 0
        if TerrainPanel.nodes.isEmpty { nodeStack.addArrangedSubview(label("No nodes — the terrain is flat. Add a generator.", 12)) }
    }

    private func newLayer(_ ids: [Int]) {
        TerrainPanel.layers.append(PLayer(id: TerrainPanel.nextLayer, nodes: ids)); TerrainPanel.nextLayer += 1
        if ids.isEmpty {      // whole-terrain layers share the height range in even bands so each one actually shows
            let w = TerrainPanel.layers.indices.filter { TerrainPanel.layers[$0].nodes.isEmpty }, k = Float(w.count)
            for (n, i) in w.enumerated() { TerrainPanel.layers[i].hLo = Float(n) / k; TerrainPanel.layers[i].hHi = Float(n + 1) / k }
        }
        TerrainPanel.selLayer = TerrainPanel.layers.count - 1; TerrainPanel.selNodes.removeAll()
        rebuildNodes(); rebuildMaterial(); updatePreview()
        tabs.selectedSegmentIndex = 2; showTab()
    }

    private func rebuildMaterial() {
        for st in [layerStack, layerSliders] { st.arrangedSubviews.forEach { st.removeArrangedSubview($0); $0.removeFromSuperview() } }
        for (i, l) in TerrainPanel.layers.enumerated() {
            let sel = i == TerrainPanel.selLayer
            let b = UIButton(type: .system)
            let nn = l.nodes.isEmpty ? "whole terrain" : "\(l.nodes.count) node\(l.nodes.count == 1 ? "" : "s")"
            b.setTitle("\(sel ? "● " : "○ ")L\(i + 1) · \(l.texName.isEmpty ? "procedural" : l.texName) · \(nn)", for: .normal)
            b.tintColor = sel ? accent : .white; b.contentHorizontalAlignment = .leading; b.titleLabel?.lineBreakMode = .byTruncatingTail
            b.addAction(UIAction { [weak self] _ in TerrainPanel.selLayer = i; self?.rebuildMaterial() }, for: .touchUpInside)
            let eye = iconBtn(l.on ? "eye" : "eye.slash") { [weak self] in TerrainPanel.layers[i].on.toggle(); self?.rebuildMaterial(); self?.updatePreview() }
            let del = iconBtn("trash", UIColor(red: 1, green: 0.4, blue: 0.4, alpha: 1)) { [weak self] in
                TerrainPanel.layers.remove(at: i); TerrainPanel.selLayer = min(TerrainPanel.selLayer, TerrainPanel.layers.count - 1)
                self?.rebuildMaterial(); self?.rebuildNodes(); self?.updatePreview() }
            let r = UIStackView(arrangedSubviews: [b, eye, del]); r.alignment = .center; layerStack.addArrangedSubview(r)
        }
        if TerrainPanel.layers.isEmpty { layerStack.addArrangedSubview(label("No PBR layers: the terrain uses procedural colours. Assign layers from the Nodes tab or add one here.", 12)) }
        layerEditor.isHidden = curLayer == nil
        table.reloadData()
        guard let cur = curLayer else { return }
        let si = TerrainPanel.selLayer
        func ls(_ t: String, _ lo: Float, _ hi: Float, _ v: Float, _ fmt: String = "%.2f", _ set: @escaping (inout PLayer, Float) -> Void) {
            layerSliders.addArrangedSubview(slider(t, lo, hi, v, fmt) { [weak self] x in
                guard TerrainPanel.layers.indices.contains(si) else { return }
                set(&TerrainPanel.layers[si], x); self?.updatePreview() })
        }
        ls("Tiling", 1, 24, cur.tiling, "%.0f") { $0.tiling = $1.rounded() }
        ls("Strength", 0, 2, cur.strength) { $0.strength = $1 }
        layerSliders.addArrangedSubview(label("Rules (each has a softness)", 13, .semibold, .white))
        ls("Height min", 0, 1, cur.hLo) { $0.hLo = $1 }; ls("Height max", 0, 1, cur.hHi) { $0.hHi = $1 }; ls("H softness", 0, 0.5, cur.hSoft) { $0.hSoft = $1 }
        ls("Slope min", 0, 1, cur.sLo) { $0.sLo = $1 }; ls("Slope max", 0, 1, cur.sHi) { $0.sHi = $1 }; ls("S softness", 0, 0.5, cur.sSoft) { $0.sSoft = $1 }
        ls("Shore min", 0, 0.5, cur.wLo) { $0.wLo = $1 }; ls("Shore max", 0, 0.5, cur.wHi) { $0.wHi = $1 }; ls("W softness", 0, 0.3, cur.wSoft) { $0.wSoft = $1 }
    }

    private func updatePreview() {
        previewWork?.cancel()
        let nodes = TerrainPanel.nodes, e = TerrainPanel.edge, s = TerrainPanel.sea, sc = TerrainPanel.genScale, sd = Int(TerrainPanel.genSeed)
        let amp = TerrainPanel.height * 0.5, ly = TerrainPanel.layers.filter { $0.on }, wm = TerrainPanel.viewMode == 1
        let w = DispatchWorkItem { [weak self] in
            let img = TerrainGraph.preview(nodes, edge: e, sea: s, scale: sc, seed: sd, amp: amp, layers: ly, weights: wm)
            DispatchQueue.main.async { self?.previewView.image = img }
        }
        previewWork = w
        DispatchQueue.global(qos: .userInitiated).asyncAfter(deadline: .now() + 0.12, execute: w)
    }

    private func showTab() { for (i, p) in pages.enumerated() { p.isHidden = i != tabs.selectedSegmentIndex }; addBtn.isHidden = false }

    @objc private func close() { removeFromSuperview() }

    private func filter(_ q: String) {
        let k = q.trimmingCharacters(in: .whitespaces).lowercased()
        shown = k.isEmpty ? all : all.filter { $0.name.lowercased().contains(k) || $0.id.contains(k) }
        table.reloadData()
    }
    func searchBar(_ s: UISearchBar, textDidChange t: String) { filter(t) }
    func searchBarSearchButtonClicked(_ s: UISearchBar) { s.resignFirstResponder() }
    func tableView(_ t: UITableView, numberOfRowsInSection s: Int) -> Int { shown.count + 1 }
    func tableView(_ t: UITableView, cellForRowAt ip: IndexPath) -> UITableViewCell {
        let c = t.dequeueReusableCell(withIdentifier: "c") ?? UITableViewCell(style: .default, reuseIdentifier: "c")
        c.backgroundColor = .clear; c.textLabel?.textColor = .white; c.tintColor = accent
        let i = ip.row - 1
        c.textLabel?.text = i < 0 ? "Procedural colours (shore / grass / rock / snow)" : shown[i].name
        c.accessoryType = i == pick ? .checkmark : .none; c.imageView?.image = nil
        if i >= 0 {
            let id = shown[i].id
            c.imageView?.image = UIImage(systemName: "photo")
            PolyHaven.thumb(id) { [weak c] img in
                guard let img = img, let c = c, c.textLabel?.text == self.shown.first(where: { $0.id == id })?.name else { return }
                c.imageView?.image = img; c.setNeedsLayout()
            }
        }
        return c
    }
    func tableView(_ t: UITableView, didSelectRowAt ip: IndexPath) {
        let i = ip.row - 1, si = TerrainPanel.selLayer
        if TerrainPanel.layers.indices.contains(si) {
            TerrainPanel.layers[si].tex = i >= 0 ? shown[i].id : nil; TerrainPanel.layers[si].texName = i >= 0 ? shown[i].name : ""
        }
        search.resignFirstResponder(); rebuildMaterial()
    }

    var statusText: String { status.text ?? "" }
    var isBusy: Bool { busy }
    @objc func addTap() {
        guard !busy, let host = host else { return }
        busy = true; addBtn.alpha = 0.5
        var o = TerrainGLB.Opt()
        o.nodes = TerrainPanel.nodes; o.res = [64, 128, 224][resSeg.selectedSegmentIndex]
        o.height = TerrainPanel.height * 0.5; o.edge = TerrainPanel.edge; o.sea = TerrainPanel.sea
        o.scale = TerrainPanel.genScale; o.seed = Int(TerrainPanel.genSeed)
        let layers = TerrainPanel.layers.filter { $0.on }, opt = o
        let q = texRes.selectedSegmentIndex == 0 ? "1k" : "2k", T = q == "1k" ? 2048 : 3072
        let ids = Array(Set(layers.compactMap { $0.tex })), anyTex = !ids.isEmpty
        status.text = layers.isEmpty ? "Building…" : (anyTex ? "Downloading maps…" : "Baking layers…")
        let finish: ([String: TerrainPBR.TexSet]) -> Void = { [weak self] sets in
            DispatchQueue.main.async { self?.status.text = layers.isEmpty ? "Building…" : "Baking PBR layers…" }
            var oo = opt, pk: ExtrasGLB.Packed? = nil, sd: TerrainPBR.SplatData? = nil
            if !layers.isEmpty, let r = TerrainPBR.bake(oo, layers: layers, sets: sets, size: T) { oo.tiles = 1; pk = r.0; sd = r.1 }
            let glb = TerrainGLB.build(oo, pk, splat: sd), pp = pk
            DispatchQueue.main.async {
                guard let self = self else { return }
                self.busy = false; self.addBtn.alpha = 1
                guard let path = ProjectIO.writeDataIntoSandbox(glb, name: "terrain_\(nowMs()).glb") else { self.status.text = "Could not build the terrain."; return }
                host.addMedia(path, .MODEL)
                if let l = Editor.scene.layers.last(where: { $0.imagePath == path }) {
                    l.name = "Terrain"
                    l.tgraph = TerrainPanel.pendingGraph ?? TGraph.fromStack(TerrainPanel.nodes, edge: TerrainPanel.edge, sea: TerrainPanel.sea).json()
                    if let old = TerrainPanel.replacing, old !== l {
                        for k in ["x", "y", "z", "scale", "rotX", "rotY", "rotZ"] { l.track(k).set(Editor.time, old.p(k, Editor.time), false) }
                        Editor.scene.layers.removeAll { $0 === old }
                    }
                    TerrainPanel.pendingGraph = nil; TerrainPanel.replacing = nil
                    if pp != nil { let rl = TerrainPanel.relief; l.xset("pbrNorm", 0.8 + 1.4 * rl); l.xset("pbrExtra", 1); l.xset("pbrPom", 0.035 * rl) }
                    host.render(); host.refreshPanel()
                }
                self.close()
            }
        }
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            var sets: [String: TerrainPBR.TexSet] = [:]
            func next(_ k: Int) {
                if k >= ids.count { finish(sets); return }
                if let m = TerrainPanel.localSets[ids[k]] { sets[ids[k]] = TerrainPBR.texSet(m, q == "1k" ? 1024 : 2048); next(k + 1); return }
                PolyHaven.maps(ids[k], res: q) { m in
                    DispatchQueue.global(qos: .userInitiated).async {
                        guard let m = m else { DispatchQueue.main.async { self?.busy = false; self?.addBtn.alpha = 1; self?.status.text = "Download failed. Try again." }; return }
                        sets[ids[k]] = TerrainPBR.texSet(m, q == "1k" ? 1024 : 2048)
                        next(k + 1)
                    }
                }
            }
            next(0)
        }
    }
}
