// LooksEditor.swift — full-screen MB Looks editor: own live preview, a tool chain along the bottom
// (tap to select, x to remove, + to add), a Properties panel for the selected tool, portrait + landscape,
// .cube LUT import, Apply (keep) and Close (discard). Parameters live on the layer like any effect parameter.

import UIKit
import UniformTypeIdentifiers

final class LooksEditorViewController: UIViewController, UIDocumentPickerDelegate {
    private let lay: Layer
    private let entry: String
    private let onDone: () -> Void
    private let def: EffectDef?
    private var defs: [String: PropDef] = [:]
    private var snap: [String: Float] = [:]
    private var snapLut: String?
    private var snapMods: String?
    private var savedVideoCb: (() -> Void)?
    private lazy var pv: PreviewView = {
        savedVideoCb = MetalSceneRenderer.onVideoFrame
        return PreviewView()
    }()
    private let chainStack = UIStackView()
    private let body = UIStackView()
    private var curTab = "Presets"
    private var holdInt: Float? = nil
    private let accent = argbToUIColor(C.GREEN)

    // tool chain: name -> params reset to neutral when removed
    private static let allMods = ["Basic", "Wheels", "Color", "LUT", "Lens", "Post", "Streak", "Haze"]
    private static let defaultMods = ["Basic", "Wheels", "Color", "LUT", "Lens", "Post"]
    private static let neutral: [String: [String: Float]] = [
        "Basic": ["lkExpo": 0, "lkCon": 0, "lkHi": 0, "lkSh": 0, "lkWh": 0, "lkBl": 0, "lkTemp": 0, "lkTint": 0, "lkVib": 0, "lkSat": 1],
        "Wheels": ["lkLiftA": 0, "lkGamA": 0, "lkGainA": 0, "lkToneA": 0, "lkToneB": 0],
        "Color": ["lkSecAmt": 0],
        "LUT": ["lkLutAmt": 0],
        "Lens": ["lkBloom": 0, "lkHal": 0, "lkDif": 0, "lkSharp": 0, "lkDist": 0, "lkChroma": 0],
        "Post": ["lkVig": 0, "lkGrain": 0, "lkFade": 0, "lkLb": 0],
        "Streak": ["lkStrk": 0],
        "Haze": ["lkHaze": 0],
    ]
    private static let onVals: [String: [String: Float]] = ["Streak": ["lkStrk": 0.8], "Haze": ["lkHaze": 0.4]]

    private var portraitC: [NSLayoutConstraint] = []
    private var landscapeC: [NSLayoutConstraint] = []
    private var isLandscapeLayout: Bool? = nil

    init(_ l: Layer, _ entry: String, onDone: @escaping () -> Void) {
        self.lay = l; self.entry = entry; self.onDone = onDone
        self.def = Registry.get(entry)
        super.init(nibName: nil, bundle: nil)
        for p in def?.props ?? [] { defs[p.key] = p }
        let pre = entry + "__"
        for (k, t) in l.props where k.hasPrefix(pre) { snap[k] = t.base }
        snapLut = l.pbrMaps["lut:" + entry]
        snapMods = l.pbrMaps["mods:" + entry]
    }
    required init?(coder: NSCoder) { fatalError() }

    // MARK: parameter access

    private func key(_ k: String) -> String { entry + "__" + k }

    private func val(_ k: String) -> Float {
        let kk = key(k)
        if let tr = lay.props[kk] { return tr.eval(lay.editTime(kk, Editor.time)) }
        return defs[k]?.def ?? 0
    }

    private func set(_ k: String, _ v: Float) {
        lay.track(key(k)).base = v
        pv.requestDraw()
    }

    private func comp(_ k: String, _ s: String, _ d: Float) -> Float {
        let kk = key(k) + "_" + s
        if let tr = lay.props[kk] { return tr.eval(lay.editTime(kk, Editor.time)) }
        return d
    }

    // MARK: tool chain

    private var mods: [String] {
        get {
            guard let s = lay.pbrMaps["mods:" + entry] else { return Self.defaultMods }
            return s.split(separator: ",").map(String.init).filter { Self.allMods.contains($0) }
        }
        set { lay.pbrMaps["mods:" + entry] = newValue.joined(separator: ",") }
    }

    private func addMod(_ m: String) {
        var cur = mods
        if !cur.contains(m) { cur.append(m) }
        mods = cur
        if let on = Self.onVals[m] {
            for (k, v) in on { set(k, v) }
        } else {
            for k in (Self.neutral[m] ?? [:]).keys { set(k, defs[k]?.def ?? 0) }
        }
        curTab = m
        pv.requestDraw(); showTab()
    }

    private func removeMod(_ m: String) {
        mods = mods.filter { $0 != m }
        for (k, v) in Self.neutral[m] ?? [:] { set(k, v) }
        if m == "LUT" { lay.pbrMaps["lut:" + entry] = nil }
        if curTab == m { curTab = "Presets" }
        pv.requestDraw(); showTab()
    }

    private func showAddMenu() {
        let avail = Self.allMods.filter { !mods.contains($0) }
        let a = UIAlertController(title: "Add tool", message: avail.isEmpty ? "All tools are in the chain." : nil, preferredStyle: .actionSheet)
        let blurb = ["Basic": "Exposure, contrast, color balance", "Wheels": "Lift / gamma / gain, toning",
                     "Color": "Secondary hue select", "LUT": ".cube LUTs", "Lens": "Bloom, halation, diffusion, distortion",
                     "Post": "Vignette, grain, fade, letterbox", "Streak": "Shutter streak light leak", "Haze": "Haze / atmosphere"]
        for m in avail { a.addAction(UIAlertAction(title: "\(m) — \(blurb[m] ?? "")", style: .default) { [weak self] _ in self?.addMod(m) }) }
        a.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        a.popoverPresentationController?.sourceView = chainStack
        a.popoverPresentationController?.sourceRect = chainStack.bounds
        present(a, animated: true)
    }

    // MARK: layout

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(white: 0.06, alpha: 1)
        let safe = view.safeAreaLayoutGuide

        let bar = UIView(); bar.translatesAutoresizingMaskIntoConstraints = false
        let close = UIButton(type: .system)
        close.setImage(UIImage(systemName: "xmark"), for: .normal)
        close.setTitle("  Close", for: .normal)
        close.tintColor = .white
        close.addAction(UIAction { [weak self] _ in self?.finish(apply: false) }, for: .touchUpInside)
        let apply = UIButton(type: .system)
        apply.setTitle("Apply", for: .normal)
        apply.titleLabel?.font = .systemFont(ofSize: 16, weight: .bold)
        apply.setTitleColor(.black, for: .normal)
        apply.backgroundColor = accent
        apply.layer.cornerRadius = 17
        apply.contentEdgeInsets = UIEdgeInsets(top: 0, left: 18, bottom: 0, right: 18)
        apply.addAction(UIAction { [weak self] _ in self?.finish(apply: true) }, for: .touchUpInside)
        let title = UILabel(); title.text = "Looks Editor"
        title.font = .systemFont(ofSize: 16, weight: .semibold); title.textColor = .white
        for v in [close, apply, title] as [UIView] { v.translatesAutoresizingMaskIntoConstraints = false; bar.addSubview(v) }
        view.addSubview(bar)

        let box = UIView(); box.translatesAutoresizingMaskIntoConstraints = false
        box.backgroundColor = .black
        box.clipsToBounds = true
        view.addSubview(box)
        pv.translatesAutoresizingMaskIntoConstraints = false
        box.addSubview(pv)
        let cmp = UIButton(type: .system)
        cmp.setTitle("Hold: before", for: .normal)
        cmp.titleLabel?.font = .systemFont(ofSize: 12, weight: .semibold)
        cmp.setTitleColor(.white, for: .normal)
        cmp.backgroundColor = UIColor(white: 0, alpha: 0.6)
        cmp.layer.cornerRadius = 13
        cmp.contentEdgeInsets = UIEdgeInsets(top: 5, left: 12, bottom: 5, right: 12)
        cmp.translatesAutoresizingMaskIntoConstraints = false
        cmp.addAction(UIAction { [weak self] _ in
            guard let self = self else { return }
            self.holdInt = self.val("lkInt"); self.set("lkInt", 0)
        }, for: .touchDown)
        cmp.addAction(UIAction { [weak self] _ in
            guard let self = self, let h = self.holdInt else { return }
            self.set("lkInt", h); self.holdInt = nil
        }, for: [.touchUpInside, .touchUpOutside, .touchCancel])
        box.addSubview(cmp)

        // bottom tool chain (MBL-style)
        let chainWrap = UIView(); chainWrap.translatesAutoresizingMaskIntoConstraints = false
        chainWrap.backgroundColor = UIColor(white: 0.09, alpha: 1)
        let scroll = UIScrollView(); scroll.translatesAutoresizingMaskIntoConstraints = false
        scroll.showsHorizontalScrollIndicator = false
        chainStack.axis = .horizontal; chainStack.spacing = 8
        chainStack.translatesAutoresizingMaskIntoConstraints = false
        scroll.addSubview(chainStack)
        chainWrap.addSubview(scroll)
        view.addSubview(chainWrap)

        // Properties panel
        let bodyScroll = UIScrollView(); bodyScroll.translatesAutoresizingMaskIntoConstraints = false
        bodyScroll.keyboardDismissMode = .onDrag
        body.axis = .vertical; body.spacing = 14
        body.translatesAutoresizingMaskIntoConstraints = false
        bodyScroll.addSubview(body)
        view.addSubview(bodyScroll)

        let aspect = CGFloat(max(Editor.project.w, 1)) / CGFloat(max(Editor.project.h, 1))
        // preview: fill the box as far as the aspect ratio allows (fully determined, never 0x0)
        let fillH = pv.heightAnchor.constraint(equalTo: box.heightAnchor); fillH.priority = UILayoutPriority(750)
        let fillW = pv.widthAnchor.constraint(equalTo: box.widthAnchor); fillW.priority = UILayoutPriority(749)
        NSLayoutConstraint.activate([
            bar.topAnchor.constraint(equalTo: safe.topAnchor),
            bar.leadingAnchor.constraint(equalTo: safe.leadingAnchor),
            bar.trailingAnchor.constraint(equalTo: safe.trailingAnchor),
            bar.heightAnchor.constraint(equalToConstant: 52),
            close.leadingAnchor.constraint(equalTo: bar.leadingAnchor, constant: 12),
            close.centerYAnchor.constraint(equalTo: bar.centerYAnchor),
            title.centerXAnchor.constraint(equalTo: bar.centerXAnchor),
            title.centerYAnchor.constraint(equalTo: bar.centerYAnchor),
            apply.trailingAnchor.constraint(equalTo: bar.trailingAnchor, constant: -12),
            apply.centerYAnchor.constraint(equalTo: bar.centerYAnchor),
            apply.heightAnchor.constraint(equalToConstant: 34),

            pv.centerXAnchor.constraint(equalTo: box.centerXAnchor),
            pv.centerYAnchor.constraint(equalTo: box.centerYAnchor),
            pv.widthAnchor.constraint(lessThanOrEqualTo: box.widthAnchor),
            pv.heightAnchor.constraint(lessThanOrEqualTo: box.heightAnchor),
            pv.widthAnchor.constraint(equalTo: pv.heightAnchor, multiplier: aspect),
            fillH, fillW,
            cmp.trailingAnchor.constraint(equalTo: box.trailingAnchor, constant: -10),
            cmp.bottomAnchor.constraint(equalTo: box.bottomAnchor, constant: -10),

            scroll.topAnchor.constraint(equalTo: chainWrap.topAnchor, constant: 6),
            scroll.bottomAnchor.constraint(equalTo: chainWrap.bottomAnchor, constant: -6),
            scroll.leadingAnchor.constraint(equalTo: chainWrap.leadingAnchor),
            scroll.trailingAnchor.constraint(equalTo: chainWrap.trailingAnchor),
            chainStack.leadingAnchor.constraint(equalTo: scroll.contentLayoutGuide.leadingAnchor, constant: 12),
            chainStack.trailingAnchor.constraint(equalTo: scroll.contentLayoutGuide.trailingAnchor, constant: -12),
            chainStack.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor),
            chainStack.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor),
            chainStack.heightAnchor.constraint(equalTo: scroll.frameLayoutGuide.heightAnchor),

            body.topAnchor.constraint(equalTo: bodyScroll.contentLayoutGuide.topAnchor, constant: 8),
            body.bottomAnchor.constraint(equalTo: bodyScroll.contentLayoutGuide.bottomAnchor, constant: -24),
            body.leadingAnchor.constraint(equalTo: bodyScroll.frameLayoutGuide.leadingAnchor, constant: 16),
            body.trailingAnchor.constraint(equalTo: bodyScroll.frameLayoutGuide.trailingAnchor, constant: -16),
            body.widthAnchor.constraint(equalTo: bodyScroll.frameLayoutGuide.widthAnchor, constant: -32),
            chainWrap.heightAnchor.constraint(equalToConstant: 56),
        ])
        // portrait: preview on top, properties in the middle, chain pinned to the bottom
        portraitC = [
            box.topAnchor.constraint(equalTo: bar.bottomAnchor),
            box.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            box.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            box.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.36),
            chainWrap.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            chainWrap.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            chainWrap.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            bodyScroll.topAnchor.constraint(equalTo: box.bottomAnchor, constant: 4),
            bodyScroll.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            bodyScroll.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            bodyScroll.bottomAnchor.constraint(equalTo: chainWrap.topAnchor),
        ]
        // landscape: preview on the left half, properties + chain on the right
        landscapeC = [
            box.topAnchor.constraint(equalTo: bar.bottomAnchor),
            box.leadingAnchor.constraint(equalTo: safe.leadingAnchor),
            box.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            box.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.5),
            chainWrap.leadingAnchor.constraint(equalTo: box.trailingAnchor),
            chainWrap.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            chainWrap.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            bodyScroll.topAnchor.constraint(equalTo: bar.bottomAnchor),
            bodyScroll.leadingAnchor.constraint(equalTo: box.trailingAnchor),
            bodyScroll.trailingAnchor.constraint(equalTo: safe.trailingAnchor),
            bodyScroll.bottomAnchor.constraint(equalTo: chainWrap.topAnchor),
        ]
        updateOrientationLayout()
        showTab()
    }

    private func updateOrientationLayout() {
        let land = view.bounds.width > view.bounds.height
        if isLandscapeLayout == land { return }
        isLandscapeLayout = land
        NSLayoutConstraint.deactivate(land ? portraitC : landscapeC)
        NSLayoutConstraint.activate(land ? landscapeC : portraitC)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        updateOrientationLayout()
        pv.requestDraw()
    }

    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        coordinator.animate(alongsideTransition: nil) { [weak self] _ in self?.pv.requestDraw() }
    }

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .allButUpsideDown }
    override var shouldAutorotate: Bool { true }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        pv.requestDraw()
        DispatchQueue.main.async { [weak self] in self?.pv.requestDraw() }
    }

    // MARK: chain + properties

    private func chip(_ text: String, on: Bool, _ action: @escaping () -> Void) -> UIButton {
        let b = UIButton(type: .system)
        b.setTitle(text, for: .normal)
        b.titleLabel?.font = .systemFont(ofSize: 14, weight: .semibold)
        b.setTitleColor(on ? .black : .white, for: .normal)
        b.backgroundColor = on ? accent : UIColor(white: 0.17, alpha: 1)
        b.layer.cornerRadius = 16
        b.contentEdgeInsets = UIEdgeInsets(top: 6, left: 14, bottom: 6, right: 14)
        b.addAction(UIAction { _ in action() }, for: .touchUpInside)
        return b
    }

    /// One chain entry: name chip + a small x to remove it (Presets can't be removed).
    private func chainItem(_ name: String, removable: Bool) -> UIView {
        let on = curTab == name
        let c = chip(name, on: on) { [weak self] in self?.curTab = name; self?.showTab() }
        guard removable else { return c }
        let x = UIButton(type: .system)
        x.setImage(UIImage(systemName: "xmark.circle.fill"), for: .normal)
        x.tintColor = on ? .black : UIColor(white: 0.6, alpha: 1)
        x.addAction(UIAction { [weak self] _ in self?.removeMod(name) }, for: .touchUpInside)
        x.translatesAutoresizingMaskIntoConstraints = false
        x.widthAnchor.constraint(equalToConstant: 28).isActive = true
        let row = UIStackView(arrangedSubviews: [c, x]); row.spacing = -6; row.alignment = .center
        row.layer.backgroundColor = (on ? accent : UIColor(white: 0.17, alpha: 1)).cgColor
        row.layer.cornerRadius = 16; row.clipsToBounds = true
        c.backgroundColor = .clear
        row.isLayoutMarginsRelativeArrangement = true
        row.layoutMargins = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 4)
        return row
    }

    private func showTab() {
        chainStack.arrangedSubviews.forEach { $0.removeFromSuperview() }
        chainStack.addArrangedSubview(chainItem("Presets", removable: false))
        for m in mods { chainStack.addArrangedSubview(chainItem(m, removable: true)) }
        let plus = chip("＋ Add", on: false) { [weak self] in self?.showAddMenu() }
        plus.setTitleColor(accent, for: .normal)
        chainStack.addArrangedSubview(plus)

        body.arrangedSubviews.forEach { $0.removeFromSuperview() }
        func add(_ v: UIView) { body.addArrangedSubview(v) }
        let ph = UILabel(); ph.text = "PROPERTIES  ·  " + curTab.uppercased()
        ph.font = .systemFont(ofSize: 11, weight: .bold); ph.textColor = UIColor(white: 0.55, alpha: 1)
        add(ph)
        switch curTab {
        case "Presets":
            add(sliderRow("Intensity", "lkInt"))
            add(presetGrid())
            add(sliderRow("Preset strength", "lkPStr"))
        case "Basic":
            for (t, k) in [("Exposure (stops)", "lkExpo"), ("Contrast", "lkCon"), ("Highlights", "lkHi"),
                           ("Shadows", "lkSh"), ("Whites", "lkWh"), ("Blacks", "lkBl"),
                           ("Temperature", "lkTemp"), ("Tint", "lkTint"), ("Vibrance", "lkVib"),
                           ("Saturation", "lkSat")] { add(sliderRow(t, k)) }
        case "Wheels":
            add(header("Lift (shadows)")); add(colorRow("Lift color", "lkLiftC")); add(sliderRow("Lift amount", "lkLiftA"))
            add(header("Gamma (midtones)")); add(colorRow("Gamma color", "lkGamC")); add(sliderRow("Gamma amount", "lkGamA"))
            add(header("Gain (highlights)")); add(colorRow("Gain color", "lkGainC")); add(sliderRow("Gain amount", "lkGainA"))
            add(header("Toning")); add(colorRow("Shadow tone", "lkShC")); add(colorRow("Highlight tone", "lkHiC"))
            add(sliderRow("Toning amount", "lkToneA")); add(sliderRow("Toning balance", "lkToneB"))
        case "Color":
            add(header("Secondary: pick a hue and change only that"))
            for (t, k) in [("Hue to select", "lkSecHue"), ("Range", "lkSecRange"), ("Softness", "lkSecSoft"),
                           ("Hue shift", "lkSecShift"), ("Saturation", "lkSecSat"),
                           ("Luminance", "lkSecLum"), ("Amount", "lkSecAmt")] { add(sliderRow(t, k)) }
        case "LUT":
            lutTab()
        case "Lens":
            for (t, k) in [("Bloom amount", "lkBloom"), ("Bloom threshold", "lkBThr"), ("Bloom radius", "lkBRad"),
                           ("Halation", "lkHal")] { add(sliderRow(t, k)) }
            add(colorRow("Halation color", "lkHalC"))
            for (t, k) in [("Diffusion", "lkDif"), ("Sharpen", "lkSharp"), ("Distortion", "lkDist"),
                           ("Chromatic aberration", "lkChroma")] { add(sliderRow(t, k)) }
        case "Streak":
            add(header("Shutter streak: light leaking in at the top and bottom edges"))
            add(sliderRow("Boost", "lkStrk")); add(sliderRow("Size", "lkStrkSz")); add(sliderRow("Falloff", "lkStrkFall"))
            add(colorRow("Streak color", "lkStrkC"))
        case "Haze":
            add(header("Haze: lifts blacks, softens contrast, tints the air"))
            add(sliderRow("Amount", "lkHaze")); add(sliderRow("Gradient (− top / + bottom)", "lkHazeSp"))
            add(sliderRow("Desaturation", "lkHazeSat")); add(colorRow("Haze color", "lkHazeC"))
        default:
            for (t, k) in [("Vignette", "lkVig"), ("Vignette midpoint", "lkVigMid"), ("Vignette feather", "lkVigF"),
                           ("Vignette roundness", "lkVigR"), ("Film grain", "lkGrain"), ("Grain size", "lkGrainSz"),
                           ("Grain color", "lkGrainC"), ("Faded blacks", "lkFade"),
                           ("Letterbox", "lkLb")] { add(sliderRow(t, k)) }
        }
    }

    // MARK: building blocks

    private func header(_ t: String) -> UILabel {
        let l = UILabel(); l.text = t.uppercased()
        l.font = .systemFont(ofSize: 11, weight: .bold); l.textColor = accent
        return l
    }

    private func sliderRow(_ title: String, _ k: String) -> UIView {
        guard let pd = defs[k] else { return UIView() }
        let fmt = pd.dec <= 0 ? "%.0f" : "%.\(pd.dec)f"
        let t = UILabel(); t.text = title
        t.font = .systemFont(ofSize: 14, weight: .medium); t.textColor = .white
        let v = UILabel(); v.font = .monospacedDigitSystemFont(ofSize: 13, weight: .regular)
        v.textColor = accent; v.textAlignment = .right
        v.setContentHuggingPriority(.required, for: .horizontal)
        let s = UISlider(); s.minimumValue = pd.min; s.maximumValue = pd.max
        s.value = val(k); s.tintColor = accent
        v.text = String(format: fmt, s.value)
        s.addAction(UIAction { [weak self, weak s, weak v] _ in
            guard let self = self, let s = s, let v = v else { return }
            self.set(k, s.value); v.text = String(format: fmt, s.value)
        }, for: .valueChanged)
        let r = UIButton(type: .system)
        r.setTitle("↺", for: .normal); r.tintColor = UIColor(white: 0.6, alpha: 1)
        r.addAction(UIAction { [weak self, weak s, weak v] _ in
            guard let self = self, let s = s, let v = v else { return }
            self.set(k, pd.def); s.value = pd.def; v.text = String(format: fmt, pd.def)
        }, for: .touchUpInside)
        let top = UIStackView(arrangedSubviews: [t, UIView(), v, r])
        top.spacing = 8; top.alignment = .center
        let col = UIStackView(arrangedSubviews: [top, s]); col.axis = .vertical; col.spacing = 2
        return col
    }

    private func colorRow(_ title: String, _ k: String) -> UIView {
        let cp = def?.colors.first { $0.key == k }
        let u = UInt32(bitPattern: cp?.def ?? Int32(bitPattern: 0xFF808080))
        let w = UIColorWell(); w.supportsAlpha = false; w.title = title
        w.selectedColor = UIColor(red: CGFloat(comp(k, "r", Float((u >> 16) & 0xFF) / 255)),
                                  green: CGFloat(comp(k, "g", Float((u >> 8) & 0xFF) / 255)),
                                  blue: CGFloat(comp(k, "b", Float(u & 0xFF) / 255)), alpha: 1)
        w.addAction(UIAction { [weak self, weak w] _ in
            guard let self = self, let c = w?.selectedColor else { return }
            var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
            c.getRed(&r, green: &g, blue: &b, alpha: &a)
            self.lay.track(self.key(k) + "_r").base = Float(r)
            self.lay.track(self.key(k) + "_g").base = Float(g)
            self.lay.track(self.key(k) + "_b").base = Float(b)
            self.lay.track(self.key(k) + "_a").base = 1
            self.pv.requestDraw()
        }, for: .valueChanged)
        let t = UILabel(); t.text = title
        t.font = .systemFont(ofSize: 14, weight: .medium); t.textColor = .white
        let row = UIStackView(arrangedSubviews: [t, UIView(), w]); row.alignment = .center
        return row
    }

    private func presetGrid() -> UIView {
        let cur = Int(val("lkPreset") + 0.5)
        let col = UIStackView(); col.axis = .vertical; col.spacing = 8
        var rowV = UIStackView()
        for (i, n) in looksPresetNames.enumerated() {
            if i % 2 == 0 {
                rowV = UIStackView(); rowV.spacing = 8; rowV.distribution = .fillEqually
                col.addArrangedSubview(rowV)
            }
            rowV.addArrangedSubview(chip(n, on: i == cur) { [weak self] in
                self?.set("lkPreset", Float(i)); self?.showTab()
            })
        }
        if looksPresetNames.count % 2 == 1 { rowV.addArrangedSubview(UIView()) }
        return col
    }

    // MARK: LUT

    private func lutTab() {
        let cur = lay.pbrMaps["lut:" + entry]
        let imp = chip("Import LUT (.cube)", on: true) { [weak self] in self?.pickLut() }
        body.addArrangedSubview(imp)
        let info = UILabel(); info.numberOfLines = 0
        info.font = .systemFont(ofSize: 12); info.textColor = UIColor(white: 0.6, alpha: 1)
        info.text = "Imported LUTs are kept on this device. Tap one to use it on this effect."
        body.addArrangedSubview(info)
        body.addArrangedSubview(chip("None", on: cur == nil) { [weak self] in
            guard let self = self else { return }
            self.lay.pbrMaps["lut:" + self.entry] = nil; self.pv.requestDraw(); self.showTab()
        })
        for n in LookLut.shared.names() {
            body.addArrangedSubview(chip((cur == n ? "✓  " : "") + n, on: cur == n) { [weak self] in
                guard let self = self else { return }
                self.lay.pbrMaps["lut:" + self.entry] = n; self.pv.requestDraw(); self.showTab()
            })
        }
        body.addArrangedSubview(sliderRow("LUT strength", "lkLutAmt"))
    }

    private func pickLut() {
        var types: [UTType] = [.data]
        if let c = UTType(filenameExtension: "cube") { types.insert(c, at: 0) }
        let p = UIDocumentPickerViewController(forOpeningContentTypes: types, asCopy: true)
        p.delegate = self
        present(p, animated: true)
    }

    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let u = urls.first else { return }
        if let name = LookLut.shared.importFile(u) {
            lay.pbrMaps["lut:" + entry] = name
            pv.requestDraw(); showTab()
        } else {
            let a = UIAlertController(title: "Can't use this LUT",
                                      message: "Only 3D .cube files (LUT_3D_SIZE) are supported.", preferredStyle: .alert)
            a.addAction(UIAlertAction(title: "OK", style: .default))
            present(a, animated: true)
        }
    }

    // MARK: finish

    private func finish(apply: Bool) {
        if !apply {
            let pre = entry + "__"
            for k in Array(lay.props.keys) where k.hasPrefix(pre) {
                if let b = snap[k] { lay.props[k]?.base = b } else { lay.props[k] = nil }
            }
            lay.pbrMaps["lut:" + entry] = snapLut
            lay.pbrMaps["mods:" + entry] = snapMods
        }
        MetalSceneRenderer.onVideoFrame = savedVideoCb      // hand the video-frame callback back to the main preview
        let done = onDone
        dismiss(animated: true) { done() }
    }
}
