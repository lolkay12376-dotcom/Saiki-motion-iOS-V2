// BuiltinsLooks.swift — MB Looks (single-pass port of the MB Looks Pro .aureaplugin).
//
// Presets, Lumetri-style basics, lift/gamma/gain wheels, toning, hue-qualifier secondary, .cube LUT
// (strip texture bound as in1 by MetalSceneRenderer), glow (bloom / halation / diffusion), sharpen,
// distortion, chromatic aberration, vignette, grain, fade, letterbox. The effects panel only shows
// "Open Looks Editor" + Intensity; every other parameter is edited in LooksEditorViewController.

import Foundation

let looksPresetNames = ["Custom", "Teal & Orange", "Bleach Bypass", "Vintage Film", "Cool Noir", "Warm Sunset",
                        "Cyberpunk", "Matte Fade", "Moody Green", "Dreamy Glow", "High Contrast B&W",
                        "Faded Pastel", "Golden Hour"]

func looksFx() -> [EffectDef] {
    func col(_ h: UInt32) -> Int32 { Int32(bitPattern: h) }
    return [EffectDef(
        id: "mblooks", name: "MB Looks",
        desc: "Full look studio: presets, Lumetri-style basics, wheels, toning, secondary, LUTs, glow, lens and film post. Tap Open Looks Editor.",
        category: "Color", props: [
            PropDef("lkInt", "Intensity", 0, 1, 1, 2),
            PropDef("lkPreset", "Preset", 0, 12, 1, 0, looksPresetNames),
            PropDef("lkPStr", "Preset strength", 0, 1, 1, 2),
            PropDef("lkExpo", "Exposure", -3, 3, 0, 2),
            PropDef("lkCon", "Contrast", -1, 1, 0, 2),
            PropDef("lkHi", "Highlights", -1, 1, 0, 2),
            PropDef("lkSh", "Shadows", -1, 1, 0, 2),
            PropDef("lkWh", "Whites", -1, 1, 0, 2),
            PropDef("lkBl", "Blacks", -1, 1, 0, 2),
            PropDef("lkTemp", "Temperature", -1, 1, 0, 2),
            PropDef("lkTint", "Tint", -1, 1, 0, 2),
            PropDef("lkVib", "Vibrance", -1, 1, 0, 2),
            PropDef("lkSat", "Saturation", 0, 2, 1, 2),
            PropDef("lkLiftA", "Lift amount", 0, 1, 0, 2),
            PropDef("lkGamA", "Gamma amount", 0, 1, 0, 2),
            PropDef("lkGainA", "Gain amount", 0, 1, 0, 2),
            PropDef("lkToneA", "Toning amount", 0, 1, 0, 2),
            PropDef("lkToneB", "Toning balance", -1, 1, 0, 2),
            PropDef("lkSecHue", "Hue to select", -360, 360, 30, 0),
            PropDef("lkSecRange", "Range", 0, 0.5, 0.08, 2),
            PropDef("lkSecSoft", "Softness", 0, 0.5, 0.06, 2),
            PropDef("lkSecShift", "Hue shift", -360, 360, 0, 0),
            PropDef("lkSecSat", "Saturation", 0, 2, 1, 2),
            PropDef("lkSecLum", "Luminance", -2, 2, 0, 2),
            PropDef("lkSecAmt", "Amount", 0, 1, 0, 2),
            PropDef("lkLutAmt", "LUT strength", 0, 1, 1, 2),
            PropDef("lkLutSize", "LUT size (internal)", 0, 65, 0, 0),
            PropDef("lkBloom", "Bloom amount", 0, 2, 0, 2),
            PropDef("lkBThr", "Bloom threshold", 0, 1, 0.5, 2),
            PropDef("lkBRad", "Bloom radius (px)", 0, 120, 30, 0),
            PropDef("lkHal", "Halation", 0, 1, 0, 2),
            PropDef("lkDif", "Diffusion", 0, 1, 0, 2),
            PropDef("lkSharp", "Sharpen", 0, 2, 0, 2),
            PropDef("lkDist", "Distortion", -1, 1, 0, 2),
            PropDef("lkChroma", "Chromatic aberration (px)", 0, 20, 0, 1),
            PropDef("lkVig", "Vignette", 0, 1, 0, 2),
            PropDef("lkVigMid", "Vignette midpoint", 0, 1, 0.45, 2),
            PropDef("lkVigF", "Vignette feather", 0.01, 1, 0.5, 2),
            PropDef("lkVigR", "Vignette roundness", 0, 1, 1, 2),
            PropDef("lkGrain", "Film grain", 0, 1, 0, 2),
            PropDef("lkGrainSz", "Grain size (px)", 1, 8, 1.5, 1),
            PropDef("lkGrainC", "Grain color", 0, 1, 0.3, 2),
            PropDef("lkFade", "Faded blacks", 0, 1, 0, 2),
            PropDef("lkLb", "Letterbox", 0, 0.4, 0, 2),
            PropDef("lkPivot", "Contrast pivot", 0.05, 0.95, 0.5, 2),
            PropDef("lkOD", "Diffusion density", 0, 1, 0, 2),
            PropDef("lkODSize", "Diffusion size", 0.02, 1, 0.4, 2),
            PropDef("lkODFall", "Diffusion falloff", 0, 1, 0.5, 2),
            PropDef("lkODGlow", "Diffusion glow", 0, 1, 0.4, 2),
            PropDef("lkODHi", "Highlights only", 0, 1, 0.5, 2),
            PropDef("lkCurvAmt", "Curves amount", 0, 1, 0, 2),
            PropDef("lkStrk", "Streak boost", 0, 3, 0, 2),
            PropDef("lkStrkSz", "Streak size", 0.05, 1, 0.5, 2),
            PropDef("lkStrkFall", "Streak falloff", -1, 1, 0, 2),
            PropDef("lkHaze", "Haze amount", 0, 1, 0, 2),
            PropDef("lkHazeSp", "Haze gradient", -1, 1, 0, 2),
            PropDef("lkHazeSat", "Haze desaturation", 0, 1, 0.3, 2),
        ] + looksCurveProps(), colors: [
            ColorParam("lkODC", "Diffusion color", col(0xFFFFE6CC)),
            ColorParam("lkLiftC", "Lift color", col(0xFF808080)),
            ColorParam("lkGamC", "Gamma color", col(0xFF808080)),
            ColorParam("lkGainC", "Gain color", col(0xFF808080)),
            ColorParam("lkShC", "Shadow tone", col(0xFF3B6EA8)),
            ColorParam("lkHiC", "Highlight tone", col(0xFFFFB877)),
            ColorParam("lkHalC", "Halation color", col(0xFFFF4A1C)),
            ColorParam("lkStrkC", "Streak color", col(0xFFFF8A3C)),
            ColorParam("lkHazeC", "Haze color", col(0xFFB8C8D8)),
        ], previewAnim: "fade", glsl: """
    vec2 px = 1.0 / uRes;
    float asp = uRes.x / max(uRes.y, 1.0);
    vec2 cc = uv - 0.5;
    vec2 ccA = cc * vec2(asp, 1.0);
    vec2 duv = 0.5 + cc * (1.0 + lkDist * dot(ccA, ccA) * 0.6);
    vec4 s0 = src(duv);
    float a = s0.a;
    vec3 c0 = s0.rgb / max(a, 0.0001);
    vec3 c = c0;
    if (lkChroma > 0.01) {
        vec2 ch = cc * lkChroma * px.x * 2.0;
        c = vec3(src(duv + ch).r, s0.g, src(duv - ch).b) / max(a, 0.0001);
    }
    if (lkSharp > 0.001) {
        vec3 bl = (src(duv + vec2(px.x, 0.0)).rgb + src(duv - vec2(px.x, 0.0)).rgb
                 + src(duv + vec2(0.0, px.y)).rgb + src(duv - vec2(0.0, px.y)).rgb) * 0.25 / max(a, 0.0001);
        c += (c - bl) * lkSharp;
    }
    float pp = floor(lkPreset + 0.5);
    float pf = lkPStr;
    vec4 pA = vec4(0.0);
    vec4 pB = vec4(0.0);
    vec4 pC = vec4(0.0, 1.0, 0.0, 0.0);
    vec3 pShC = vec3(0.5);
    vec3 pHiC = vec3(0.5);
    vec4 pFx = vec4(0.0);
    if (pp == 1.0) {
        pA = vec4(0.0, 0.0, 0.0, 0.18); pB = vec4(0.0, 0.15, 0.0, 0.0); pC = vec4(0.25, 1.05, 0.85, 0.0);
        pShC = vec3(0.05, 0.30, 0.38); pHiC = vec3(1.0, 0.50, 0.20); pFx = vec4(0.10, 0.0, 0.15, 0.05);
    } else if (pp == 2.0) {
        pA = vec4(0.0, 0.0, 0.0, 0.45); pB = vec4(-0.1, -0.1, 0.0, 0.1); pC = vec4(0.0, 0.45, 0.0, 0.0);
    } else if (pp == 3.0) {
        pA = vec4(0.0, 0.25, -0.1, -0.05); pB = vec4(0.0, 0.0, 0.0, 0.7); pC = vec4(0.0, 0.85, 0.5, 0.0);
        pShC = vec3(0.10, 0.22, 0.28); pHiC = vec3(1.0, 0.72, 0.45); pFx = vec4(0.15, 0.5, 0.35, 0.35);
    } else if (pp == 4.0) {
        pA = vec4(0.0, -0.35, 0.0, 0.35); pB = vec4(0.0, -0.2, 0.0, 0.0); pC = vec4(0.0, 0.35, 0.5, 0.0);
        pShC = vec3(0.04, 0.10, 0.28); pHiC = vec3(0.7, 0.85, 1.0); pFx = vec4(0.0, 0.0, 0.40, 0.20);
    } else if (pp == 5.0) {
        pA = vec4(0.0, 0.55, 0.15, 0.15); pC = vec4(0.0, 1.2, 0.6, 0.0);
        pShC = vec3(0.28, 0.10, 0.30); pHiC = vec3(1.0, 0.45, 0.15); pFx = vec4(0.25, 0.3, 0.20, 0.0);
    } else if (pp == 6.0) {
        pA = vec4(0.0, 0.0, 0.3, 0.3); pC = vec4(0.0, 1.35, 1.0, 0.0);
        pShC = vec3(0.03, 0.15, 0.9); pHiC = vec3(1.0, 0.1, 0.6); pFx = vec4(0.40, 0.0, 0.30, 0.0);
    } else if (pp == 7.0) {
        pA = vec4(0.0, 0.0, 0.0, -0.15); pB = vec4(-0.15, 0.0, 0.0, 1.0); pC = vec4(0.0, 0.9, 0.0, 0.0);
    } else if (pp == 8.0) {
        pA = vec4(0.0, -0.1, -0.45, 0.2); pB = vec4(0.0, -0.15, 0.0, 0.0); pC = vec4(0.0, 0.8, 0.5, 0.0);
        pShC = vec3(0.04, 0.20, 0.10); pHiC = vec3(0.9, 1.0, 0.6); pFx = vec4(0.10, 0.0, 0.30, 0.15);
    } else if (pp == 9.0) {
        pA = vec4(0.2, 0.0, 0.0, -0.1); pC = vec4(0.3, 1.0, 0.3, 0.0);
        pHiC = vec3(1.0, 0.85, 0.8); pFx = vec4(0.60, 0.1, 0.0, 0.0);
    } else if (pp == 10.0) {
        pA = vec4(0.0, 0.0, 0.0, 0.7); pB = vec4(0.0, 0.0, 0.3, -0.5); pC = vec4(0.0, 0.0, 0.0, 0.0);
    } else if (pp == 11.0) {
        pA = vec4(0.25, 0.0, 0.0, -0.25); pB = vec4(0.0, 0.4, 0.0, 0.8); pC = vec4(0.0, 0.75, 0.4, 0.0);
        pShC = vec3(0.3, 0.5, 0.8); pHiC = vec3(1.0, 0.8, 0.9);
    } else if (pp == 12.0) {
        pA = vec4(0.1, 0.45, 0.0, 0.12); pB = vec4(-0.1, 0.0, 0.0, 0.0); pC = vec4(0.0, 1.12, 0.5, 0.0);
        pHiC = vec3(1.0, 0.70, 0.30); pFx = vec4(0.25, 0.4, 0.10, 0.05);
    }
    for (int gp = 0; gp < 2; gp++) {
        vec4 gA = pA; vec4 gB = pB; vec4 gC = pC;
        vec3 gS = pShC; vec3 gH = pHiC;
        vec3 gL = vec3(0.5); vec3 gG = vec3(0.5); vec3 gN = vec3(0.5);
        float gLa = 0.0; float gGa = 0.0; float gNa = 0.0;
        if (gp == 1) {
            gA = vec4(lkExpo, lkTemp, lkTint, lkCon);
            gB = vec4(lkHi, lkSh, lkWh, lkBl);
            gC = vec4(lkVib, lkSat, lkToneA, lkToneB);
            gS = lkShC.rgb; gH = lkHiC.rgb;
            gL = lkLiftC.rgb; gG = lkGamC.rgb; gN = lkGainC.rgb;
            gLa = lkLiftA; gGa = lkGamA; gNa = lkGainA;
        }
        vec3 g = c * exp2(gA.x);
        g *= vec3(1.0 + gA.y * 0.25, 1.0, 1.0 - gA.y * 0.25);
        g *= vec3(1.0 + gA.z * 0.08, 1.0 - gA.z * 0.16, 1.0 + gA.z * 0.08);
        float pvt = 0.5;
        if (gp == 1) { pvt = lkPivot; }
        g = pvt * pow(max(g / pvt, vec3(0.0001)), vec3(1.0 + gA.w * 0.8));
        float l = dot(g, vec3(0.2126, 0.7152, 0.0722));
        float shW = 1.0 - smoothstep(0.0, 0.45, l);
        float hiW = smoothstep(0.4, 1.0, l);
        float whW = smoothstep(0.7, 1.1, l);
        float blW = 1.0 - smoothstep(0.0, 0.15, l);
        g = g * (1.0 + gB.y * 0.8 * shW + gB.x * 0.5 * hiW + gB.z * 0.5 * whW) + gB.w * 0.1 * blW;
        float mxv = max(g.r, max(g.g, g.b));
        float mnv = min(g.r, min(g.g, g.b));
        float snv = (mxv - mnv) / max(mxv, 0.0001);
        float l2 = dot(g, vec3(0.2126, 0.7152, 0.0722));
        g = mix(vec3(l2), g, 1.0 + gC.x * (1.0 - snv));
        l2 = dot(g, vec3(0.2126, 0.7152, 0.0722));
        g = mix(vec3(l2), g, gC.y);
        g += (gL - 0.5) * gLa * 0.5;
        g = pow(max(g, vec3(0.0)), vec3(1.0) - (gG - 0.5) * gGa);
        g *= 1.0 + (gN - 0.5) * gNa * 2.0;
        float lt = dot(g, vec3(0.2126, 0.7152, 0.0722));
        float tw = smoothstep(0.0, 1.0, lt + gC.w * 0.5);
        vec3 tt = mix(gS, gH, tw);
        tt = tt / max(dot(tt, vec3(0.2126, 0.7152, 0.0722)), 0.001);
        g = mix(g, g * tt, clamp(gC.z, 0.0, 1.0));
        if (gp == 0) { c = mix(c, g, pf); } else { c = g; }
    }
    if (lkSecAmt > 0.001) {
        float ox = c.r - 0.5 * (c.g + c.b);
        float oy = 0.8660254 * (c.g - c.b);
        float ang = atan(oy, ox);
        float dd = ang - lkSecHue * 0.0174533 + 3.14159265;
        dd = abs(dd - 6.2831853 * floor(dd / 6.2831853) - 3.14159265) / 6.2831853;
        float chr = length(vec2(ox, oy));
        float mk = (1.0 - smoothstep(lkSecRange, lkSecRange + lkSecSoft + 0.001, dd)) * smoothstep(0.0, 0.05, chr);
        float m3 = (c.r + c.g + c.b) / 3.0;
        float sa = lkSecShift * 0.0174533;
        float nx = (ox * cos(sa) - oy * sin(sa)) * lkSecSat;
        float ny = (ox * sin(sa) + oy * cos(sa)) * lkSecSat;
        vec3 scc = vec3(m3 + 0.6666667 * nx, m3 - 0.3333333 * nx + ny / 1.7320508, m3 - 0.3333333 * nx - ny / 1.7320508) * exp2(lkSecLum);
        c = mix(c, scc, mk * lkSecAmt);
    }
    if (uHas1 > 0.5 && lkLutAmt > 0.001 && lkLutSize > 1.5) {
        vec3 lc = clamp(c, 0.0, 1.0);
        float nn = lkLutSize;
        float bq = lc.b * (nn - 1.0);
        float b0 = floor(bq);
        float b1 = min(b0 + 1.0, nn - 1.0);
        float vv = (lc.g * (nn - 1.0) + 0.5) / nn;
        float u0 = (b0 * nn + lc.r * (nn - 1.0) + 0.5) / (nn * nn);
        float u1 = (b1 * nn + lc.r * (nn - 1.0) + 0.5) / (nn * nn);
        vec3 lut = mix(in1(vec2(u0, vv)).rgb, in1(vec2(u1, vv)).rgb, bq - b0);
        c = mix(c, lut, lkLutAmt);
    }
    \(looksCurveGlsl())
    c = max(c, vec3(0.0)) * (1.0 - lkFade * 0.8) + lkFade * 0.12;
    float gAmt = lkBloom + pFx.x * pf + lkDif * 0.6;
    float hAmt = lkHal + pFx.y * pf;
    if (gAmt > 0.001 || hAmt > 0.001) {
        float thr = mix(lkBThr, 0.0, lkDif);
        float rad = lkBRad * (1.0 + lkDif * 2.0) + 2.0;
        vec3 glow = vec3(0.0);
        for (int i = 0; i < 8; i++) {
            float an = float(i) * 0.785398;
            vec2 d = vec2(cos(an), sin(an)) * px * rad;
            vec3 t1 = src(duv + d).rgb;
            vec3 t2 = src(duv + d * 2.0).rgb;
            glow += t1 * smoothstep(thr - 0.1, thr + 0.1, dot(t1, vec3(0.2126, 0.7152, 0.0722)));
            glow += t2 * smoothstep(thr - 0.1, thr + 0.1, dot(t2, vec3(0.2126, 0.7152, 0.0722)));
        }
        glow /= 16.0;
        c += glow * gAmt * 1.5;
        c += lkHalC.rgb * dot(glow, vec3(0.3333)) * hAmt * 3.0;
    }
    if (lkOD > 0.001) {
        float odR = lkODSize * 0.12 * uRes.y + 2.0;
        vec3 odF = vec3(0.0);
        vec3 odH = vec3(0.0);
        float odW = 0.0;
        for (int i = 0; i < 24; i++) {
            float fi = float(i) + 0.5;
            float rad = sqrt(fi / 24.0);
            float an = fi * 2.3999632;
            vec3 sm = src(duv + vec2(cos(an), sin(an)) * rad * odR * px).rgb;
            float wt = pow(max(1.0 - rad, 0.001), lkODFall * 3.0 + 0.3);
            float sl = dot(sm, vec3(0.2126, 0.7152, 0.0722));
            odF += sm * wt;
            odH += sm * wt * smoothstep(0.35, 0.9, sl);
            odW += wt;
        }
        odF /= odW;
        odH /= odW;
        c = mix(c, odF, lkOD * 0.6);
        c += odH * mix(vec3(1.0), lkODC.rgb, 0.6) * lkODGlow * lkOD * 2.0 * mix(1.0, 0.5, lkODHi);
    }
    if (lkHaze > 0.001) {
        float hg = mix(1.0, uv.y, max(lkHazeSp, 0.0));
        hg = mix(hg, 1.0 - uv.y, max(-lkHazeSp, 0.0));
        float hz = clamp(lkHaze * (0.25 + 0.75 * hg), 0.0, 1.0);
        float hl = dot(c, vec3(0.2126, 0.7152, 0.0722));
        c = mix(c, vec3(hl), hz * lkHazeSat * 0.6);
        c = mix(c, lkHazeC.rgb * (0.55 + 0.45 * hl), hz * 0.55);
        c = c * (1.0 - hz * 0.18) + lkHazeC.rgb * hz * 0.10;
    }
    if (lkStrk > 0.001) {
        float se = min(uv.y, 1.0 - uv.y);
        float sw = exp(-pow(abs(cc.x) / (lkStrkSz * 0.9 + 0.05), 2.0));
        float sy = pow(clamp(1.0 - se / 0.33, 0.0, 1.0), max(2.0 + lkStrkFall * 2.5, 0.4));
        float sn = 0.8 + 0.4 * hash21(vec2(floor(uv.y * uRes.y / 3.0), 0.5));
        c += lkStrkC.rgb * sw * sy * sn * lkStrk * 0.6;
    }
    float vg = lkVig + pFx.z * pf;
    if (vg > 0.001) {
        vec2 sc = vec2(mix(1.0, asp, lkVigR), 1.0);
        float vd = length(cc * 2.0 * sc) / length(sc);
        c *= 1.0 - vg * smoothstep(lkVigMid, lkVigMid + lkVigF, vd);
    }
    float gr = lkGrain + pFx.w * pf;
    if (gr > 0.001) {
        vec2 gq = floor(uv * uRes / lkGrainSz) + floor(uTime * 24.0) * 13.7;
        vec3 gv = vec3(hash21(gq) - 0.5) + (vec3(hash21(gq + 1.3), hash21(gq + 7.1), hash21(gq + 3.9)) - 0.5) * lkGrainC;
        c += gv * gr * 0.35;
    }
    if (lkLb > 0.001) {
        float lbm = step(lkLb, uv.y) * step(lkLb, 1.0 - uv.y);
        c *= lbm;
        a = max(a, 1.0 - lbm);
    }
    c = mix(c0, c, lkInt);
    return vec4(max(c, vec3(0.0)) * a, a);
""")]
}


// MARK: curves (7 points per channel at x = i/6, Catmull-Rom between them; Master + R + G + B)

let looksCurveChannels = ["M", "R", "G", "B"]

func looksCurveProps() -> [PropDef] {
    var out: [PropDef] = []
    for ch in looksCurveChannels {
        for i in 0..<7 { out.append(PropDef("lkCv\(ch)\(i)", "Curve \(ch)\(i)", 0, 1, Float(i) / 6, 3)) }
    }
    return out
}

func looksCurveGlsl() -> String {
    func ev(_ v: String, _ P: String, _ o: String, _ id: String) -> String {
        var s = "{ float t\(id) = clamp(\(v), 0.0, 1.0) * 6.0; float fi\(id) = min(floor(t\(id)), 5.0); float f\(id) = t\(id) - fi\(id); float q0\(id) = 0.0; float q1\(id) = 0.0; float q2\(id) = 0.0; float q3\(id) = 0.0;\n"
        for seg in 0..<6 {
            let idx = [max(seg - 1, 0), seg, seg + 1, min(seg + 2, 6)]
            let head = seg == 0 ? "if" : "else if"
            let cond = seg == 5 ? "" : " (fi\(id) < \(Double(seg) + 0.5))"
            let assign = (0..<4).map { "q\($0)\(id) = lkCv\(P)\(idx[$0]);" }.joined(separator: " ")
            s += seg == 5 ? "else { \(assign) }\n" : "\(head)\(cond) { \(assign) }\n"
        }
        s += "\(o) = 0.5 * (2.0 * q1\(id) + (q2\(id) - q0\(id)) * f\(id) + (2.0 * q0\(id) - 5.0 * q1\(id) + 4.0 * q2\(id) - q3\(id)) * f\(id) * f\(id) + (3.0 * q1\(id) - q0\(id) - 3.0 * q2\(id) + q3\(id)) * f\(id) * f\(id) * f\(id); }\n"
        return s
    }
    var g = "if (lkCurvAmt > 0.001) {\nvec3 cvIn = clamp(c, 0.0, 1.0);\nvec3 cvOut = cvIn;\nfloat cvT = 0.0;\n"
    for (comp, P) in [("r", "R"), ("g", "G"), ("b", "B")] {
        g += ev("cvIn.\(comp)", "M", "cvT", "m\(comp)")
        g += ev("cvT", P, "cvOut.\(comp)", "k\(comp)")
    }
    g += "c = mix(c, cvOut, lkCurvAmt);\n}\n"
    return g
}
