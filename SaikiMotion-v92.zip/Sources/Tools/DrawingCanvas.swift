// DrawingCanvas.swift — bitmap layers, brush / eraser / smudge engine, undo and the canvas view.
//
// Every layer is a premultiplied-RGBA buffer the size of the canvas. A stroke is accumulated
// in an 8-bit coverage covMask and composited from a snapshot at the stroke opacity, so
// overlapping dabs never stack (the same behaviour as Ibis Paint's opacity slider).

import UIKit
import Foundation

enum DrawTool { case brush, eraser, smudge, eyedropper, transform, wand }

/// Customisable brush tip / stroke behaviour (shared by brush and eraser).
struct BrushStyle: Codable, Equatable {
    var name = "Pen"
    var hardness: CGFloat = 0.78      // 0 = fully soft edge, 1 = hard edge
    var spacing: CGFloat = 0.12       // dab distance as a fraction of the radius
    var scatter: CGFloat = 0          // random dab offset (fraction of radius)
    var grain: CGFloat = 0            // paper / chalk texture strength
    var sizeJitter: CGFloat = 0       // random dab size reduction
    var pressureSize: CGFloat = 1     // how much pen pressure changes the size
    var square = false                // square tip
    var pressureOpacity: CGFloat = 0  // how much pen pressure changes the opacity
    var tipStart: CGFloat = 0         // taper-in length at the start of a stroke (0 = none)
    var tipEnd: CGFloat = 0           // taper-out length at the end of a stroke (0 = none)

    enum CodingKeys: String, CodingKey {
        case name, hardness, spacing, scatter, grain, sizeJitter, pressureSize, square, pressureOpacity, tipStart, tipEnd
    }

    static let presets: [BrushStyle] = [
        BrushStyle(),
        BrushStyle(name: "G-Pen", hardness: 0.92, spacing: 0.06, pressureSize: 1, tipStart: 0.3, tipEnd: 0.5),
        BrushStyle(name: "Pencil", hardness: 0.55, spacing: 0.1, grain: 0.55, pressureOpacity: 0.7),
        BrushStyle(name: "Marker", hardness: 0.92, spacing: 0.08, pressureSize: 0, square: true),
        BrushStyle(name: "Airbrush", hardness: 0, spacing: 0.08, pressureSize: 0.3, pressureOpacity: 0.85),
        BrushStyle(name: "Chalk", hardness: 0.6, spacing: 0.3, scatter: 0.25, grain: 0.85, sizeJitter: 0.25),
        BrushStyle(name: "Watercolor", hardness: 0.12, spacing: 0.1, grain: 0.2, pressureSize: 0.4, pressureOpacity: 0.9),
    ]
    /// Eraser tips: soft edges + pressure opacity, so erasing fades instead of cutting in one go (like Ibis Paint).
    static let eraserPresets: [BrushStyle] = [
        BrushStyle(name: "Soft", hardness: 0.3, spacing: 0.1, pressureSize: 0.7, pressureOpacity: 0.8),
        BrushStyle(name: "Hard", hardness: 0.95, spacing: 0.08, pressureSize: 0.5),
        BrushStyle(name: "Pencil", hardness: 0.5, spacing: 0.1, grain: 0.5, pressureSize: 0.6, pressureOpacity: 0.7),
        BrushStyle(name: "Tapered", hardness: 0.85, spacing: 0.06, pressureSize: 1, tipStart: 0.3, tipEnd: 0.5),
    ]
}

extension BrushStyle {
    init(from d: Decoder) throws {
        self.init()
        let c = try d.container(keyedBy: CodingKeys.self)
        name = try c.decodeIfPresent(String.self, forKey: .name) ?? name
        hardness = try c.decodeIfPresent(CGFloat.self, forKey: .hardness) ?? hardness
        spacing = try c.decodeIfPresent(CGFloat.self, forKey: .spacing) ?? spacing
        scatter = try c.decodeIfPresent(CGFloat.self, forKey: .scatter) ?? scatter
        grain = try c.decodeIfPresent(CGFloat.self, forKey: .grain) ?? grain
        sizeJitter = try c.decodeIfPresent(CGFloat.self, forKey: .sizeJitter) ?? sizeJitter
        pressureSize = try c.decodeIfPresent(CGFloat.self, forKey: .pressureSize) ?? pressureSize
        square = try c.decodeIfPresent(Bool.self, forKey: .square) ?? square
        pressureOpacity = try c.decodeIfPresent(CGFloat.self, forKey: .pressureOpacity) ?? pressureOpacity
        tipStart = try c.decodeIfPresent(CGFloat.self, forKey: .tipStart) ?? tipStart
        tipEnd = try c.decodeIfPresent(CGFloat.self, forKey: .tipEnd) ?? tipEnd
    }
}

// MARK: - Layer bitmap ------------------------------------------------------------------

final class PixLayer {
    var meta: DrawLayerMeta
    let w: Int, h: Int
    var sourceURL: URL?
    var dirty = false
    private var store: UnsafeMutablePointer<UInt8>?
    private var _ctx: CGContext?
    static var loadedBytes = 0

    init(_ meta: DrawLayerMeta, w: Int, h: Int, url: URL? = nil) {
        self.meta = meta; self.w = w; self.h = h; self.sourceURL = url
    }
    deinit { release() }

    var isLoaded: Bool { store != nil }
    /// Pixels (premultiplied RGBA). Loaded from disk on first use.
    var buf: UnsafeMutablePointer<UInt8> { load(); return store! }
    var ctx: CGContext? { if meta.isFolder { return nil }; load(); return _ctx }

    private func load() {
        if store != nil { return }
        if meta.isFolder {
            store = UnsafeMutablePointer<UInt8>.allocate(capacity: 4)
            store!.initialize(repeating: 0, count: 4)
            return
        }
        let n = w * h * 4
        let p = UnsafeMutablePointer<UInt8>.allocate(capacity: n)
        p.initialize(repeating: 0, count: n)
        store = p
        PixLayer.loadedBytes += n
        _ctx = CGContext(data: p, width: w, height: h, bitsPerComponent: 8, bytesPerRow: w * 4,
                         space: CGColorSpaceCreateDeviceRGB(),
                         bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)
        if let u = sourceURL, FileManager.default.fileExists(atPath: u.path) { loadPNG(u) }
    }

    private func release() {
        guard let p = store else { return }
        p.deallocate(); store = nil; _ctx = nil
        if !meta.isFolder { PixLayer.loadedBytes -= w * h * 4 }
    }

    /// Frees the pixels of a layer whose PNG on disk is up to date.
    func unload() { if !dirty && !meta.isFolder { release() } }

    /// Live (not copied) view of the pixels, for drawing.
    func liveImage() -> CGImage? {
        let n = w * h * 4
        guard let p = CGDataProvider(dataInfo: nil, data: buf, size: n, releaseData: { _, _, _ in }) else { return nil }
        return CGImage(width: w, height: h, bitsPerComponent: 8, bitsPerPixel: 32, bytesPerRow: w * 4,
                       space: CGColorSpaceCreateDeviceRGB(),
                       bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.premultipliedLast.rawValue),
                       provider: p, decode: nil, shouldInterpolate: true, intent: .defaultIntent)
    }

    private func loadPNG(_ url: URL) {
        guard let c = _ctx, let cg = UIImage(contentsOfFile: url.path)?.cgImage else { return }
        c.interpolationQuality = .high
        c.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h))
    }

    func pngData() -> Data? {
        guard let cg = ctx?.makeImage() else { return nil }
        return UIImage(cgImage: cg).pngData()
    }

    func clear() { buf.update(repeating: 0, count: w * h * 4); dirty = true }
}

// MARK: - Document ----------------------------------------------------------------------

final class DrawDoc {
    var item: DrawItem
    var layers: [PixLayer] = []          // index 0 = bottom
    var activeId: String?
    var w: Int { item.w }
    var h: Int { item.h }

    init(_ item: DrawItem) {
        self.item = item
        for m in item.layers {
            layers.append(PixLayer(m, w: item.w, h: item.h, url: m.isFolder ? nil : DrawStore.layerURL(item.id, m.id)))
        }
        activeId = item.activeLayer ?? layers.last(where: { !$0.meta.isFolder })?.meta.id
        if layers.isEmpty { addLayer(name: "Layer 1") }
        if active == nil { activeId = layers.last(where: { !$0.meta.isFolder })?.meta.id }
    }

    /// The Selection Layer (like Ibis Paint): blue paint = selected area. Not part of the artwork / export.
    lazy var selLayer: PixLayer = PixLayer(DrawLayerMeta(id: "__sel__", name: "Selection Layer"), w: item.w, h: item.h)
    var selHas = false
    func recomputeSel() {
        guard selLayer.isLoaded else { selHas = false; return }
        let p = selLayer.buf
        let n = w * h * 4
        var i = 3, any = false
        while i < n { if p[i] != 0 { any = true; break }; i += 4 }
        selHas = any
    }

    var active: PixLayer? { layers.first { $0.meta.id == activeId && !$0.meta.isFolder } }
    var activeIndex: Int { layers.firstIndex { $0.meta.id == activeId } ?? -1 }

    func layer(_ id: String) -> PixLayer? { layers.first { $0.meta.id == id } }
    func parentChain(_ l: PixLayer) -> [PixLayer] {
        var out: [PixLayer] = []
        var p = l.meta.parent
        while let pid = p, let f = layer(pid) { out.append(f); p = f.meta.parent }
        return out
    }
    func shown(_ l: PixLayer) -> Bool { l.meta.visible && parentChain(l).allSatisfy { $0.meta.visible } }
    func alpha(_ l: PixLayer) -> CGFloat {
        var a = CGFloat(l.meta.opacity)
        for f in parentChain(l) { a *= CGFloat(f.meta.opacity) }
        return a
    }

    @discardableResult
    func addLayer(name: String? = nil, folder: Bool = false) -> PixLayer {
        let count = layers.filter { $0.meta.isFolder == folder }.count + 1
        var m = DrawLayerMeta(id: UUID().uuidString, name: name ?? (folder ? "Folder \(count)" : "Layer \(count)"))
        m.isFolder = folder
        if let a = layers.first(where: { $0.meta.id == activeId }) {
            m.parent = a.meta.isFolder ? a.meta.id : a.meta.parent
        }
        let l = PixLayer(m, w: w, h: h, url: nil)
        l.dirty = !folder
        var at = layers.count
        if let ai = layers.firstIndex(where: { $0.meta.id == activeId }) { at = ai + 1 }
        layers.insert(l, at: min(at, layers.count))
        if folder, let a = active, a.meta.parent == m.parent { a.meta.parent = m.id }
        activeId = folder ? activeId : m.id
        return l
    }

    func duplicate(_ l: PixLayer) {
        guard !l.meta.isFolder, let i = layers.firstIndex(where: { $0 === l }) else { return }
        var m = l.meta
        m.id = UUID().uuidString; m.name += " copy"
        let c = PixLayer(m, w: w, h: h, url: nil)
        c.buf.update(from: l.buf, count: w * h * 4)
        c.dirty = true
        layers.insert(c, at: i + 1)
        activeId = m.id
    }

    func remove(_ l: PixLayer) {
        let id = l.meta.id
        for c in layers where c.meta.parent == id { c.meta.parent = l.meta.parent }
        layers.removeAll { $0 === l }
        try? FileManager.default.removeItem(at: DrawStore.layerURL(item.id, id))
        if layers.filter({ !$0.meta.isFolder }).isEmpty { addLayer(name: "Layer 1") }
        if active == nil { activeId = layers.last(where: { !$0.meta.isFolder })?.meta.id }
    }

    func mergeDown(_ l: PixLayer) -> Bool {
        guard !l.meta.isFolder, let i = layers.firstIndex(where: { $0 === l }) else { return false }
        guard let below = layers[..<i].last(where: { !$0.meta.isFolder }), let ctx = below.ctx,
              let img = l.liveImage() else { return false }
        ctx.setAlpha(alpha(l))
        ctx.draw(img, in: CGRect(x: 0, y: 0, width: w, height: h))
        ctx.setAlpha(1)
        below.dirty = true
        remove(l)
        activeId = below.meta.id
        return true
    }

    /// Moves a layer one step up (+1) or down (-1) among its siblings. At the top / bottom of a
    /// folder the layer leaves the folder instead (so things can always be taken out again).
    func move(_ l: PixLayer, by d: Int) {
        guard let i = layers.firstIndex(where: { $0 === l }) else { return }
        if let pid = l.meta.parent {
            let sib = layers.indices.filter { layers[$0].meta.parent == pid }
            let atEdge = d > 0 ? sib.last == i : sib.first == i
            if atEdge { l.meta.parent = layer(pid)?.meta.parent; return }
        }
        var j = i + d
        while j >= 0 && j < layers.count && layers[j].meta.parent != l.meta.parent { j += d }
        guard j >= 0 && j < layers.count else { return }
        layers.remove(at: i)
        layers.insert(l, at: j)
    }

    /// Number of real (non-folder) layers.
    var pixelLayerCount: Int { layers.filter { !$0.meta.isFolder }.count }

    // MARK: composite helpers

    func composite(range: Range<Int>, into ctx: CGContext) {
        for i in range where i >= 0 && i < layers.count {
            let l = layers[i]
            guard !l.meta.isFolder, shown(l), let img = l.liveImage() else { continue }
            ctx.setAlpha(alpha(l))
            ctx.draw(img, in: CGRect(x: 0, y: 0, width: w, height: h))
            trim(keep: nil)
        }
        ctx.setAlpha(1)
    }

    /// Keeps the RAM used by layer bitmaps bounded: clean layers are re-read from disk when needed.
    func trim(keep: PixLayer?) {
        guard PixLayer.loadedBytes > 380_000_000 else { return }
        for l in layers where l !== keep && l !== active && l.isLoaded && !l.dirty {
            l.unload()
            if PixLayer.loadedBytes <= 300_000_000 { break }
        }
    }

    func makeContext() -> CGContext? {
        CGContext(data: nil, width: w, height: h, bitsPerComponent: 8, bytesPerRow: 0,
                  space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)
    }

    func flattenContext(withPaper: Bool) -> CGContext? {
        guard let c = makeContext() else { return nil }
        if withPaper && item.paperWhite {
            c.setFillColor(UIColor.white.cgColor)
            c.fill(CGRect(x: 0, y: 0, width: w, height: h))
        }
        composite(range: 0..<layers.count, into: c)
        return c
    }
    func flatten(withPaper: Bool) -> CGImage? { flattenContext(withPaper: withPaper)?.makeImage() }

    // MARK: saving

    func syncMeta() {
        item.layers = layers.map { $0.meta }
        item.activeLayer = activeId
        item.updated = Date()
    }

    func save() {
        for l in layers where !l.meta.isFolder && l.dirty {
            if let d = l.pngData() { try? d.write(to: DrawStore.layerURL(item.id, l.meta.id), options: .atomic) }
            l.dirty = false
        }
        trim(keep: nil)
        if let cg = flatten(withPaper: true) {
            let maxS: CGFloat = 360
            let sc = min(1, maxS / CGFloat(max(w, h)))
            let tw = max(1, Int(CGFloat(w) * sc)), th = max(1, Int(CGFloat(h) * sc))
            let r = UIGraphicsImageRenderer(size: CGSize(width: tw, height: th))
            let img = r.image { _ in UIImage(cgImage: cg).draw(in: CGRect(x: 0, y: 0, width: tw, height: th)) }
            try? img.pngData()?.write(to: DrawStore.thumbURL(item.id), options: .atomic)
        }
        syncMeta()
        DrawStore.upsert(item)
    }
}

// MARK: - Undo --------------------------------------------------------------------------

struct DrawUndo {
    var layerId: String
    var x: Int, y: Int, w: Int, h: Int
    var before: [UInt8]
    var after: [UInt8]
}

// MARK: - Canvas view -------------------------------------------------------------------

final class DrawingCanvasView: UIView, UIGestureRecognizerDelegate {
    var doc: DrawDoc! { didSet { cachesDirty = true; fit() } }
    var tool: DrawTool = .brush { didSet { if tool != .transform { cancelTransform() } } }
    var brushSize: CGFloat = 12          // canvas pixels
    var opacity: CGFloat = 1
    var style = BrushStyle()
    var eraserStyle = BrushStyle.eraserPresets[0]
    /// true = brush / eraser / wand edit the Selection Layer instead of the active layer
    var selectionMode = false { didSet { setNeedsDisplay() } }
    var wandTolerance = 32
    var wandContiguous = true
    var wandSubtract = false
    var onSelectionChanged: (() -> Void)?
    private var st: BrushStyle { tool == .eraser ? eraserStyle : style }
    private var target: PixLayer? { selectionMode ? doc.selLayer : doc.active }
    private var clip: UnsafeMutablePointer<UInt8>?          // selection alpha clipping normal painting
    private var strokePts: [(CGPoint, CGFloat)] = []
    private var strokeDist: CGFloat = 0
    private var strokeTotal: CGFloat = -1
    private var wandPt: CGPoint?
    private var wandStartView = CGPoint.zero
    var color = UIColor.black
    var onColorPicked: ((UIColor) -> Void)?
    var onChanged: (() -> Void)?         // after a stroke / undo / redo / transform
    var onTransformState: ((Bool) -> Void)?
    var onBlocked: ((String) -> Void)?

    private(set) var undoStack: [DrawUndo] = []
    private(set) var redoStack: [DrawUndo] = []
    private var undoBytes = 0

    // view transform
    private var scale: CGFloat = 1, tx: CGFloat = 0, ty: CGFloat = 0
    private var angle: CGFloat = 0          // canvas view rotation (two-finger twist, like Ibis Paint)
    // caches
    private var below: CGImage?, above: CGImage?
    var cachesDirty = true
    // stroke state
    private var snap: UnsafeMutablePointer<UInt8>?
    private var covMask: UnsafeMutablePointer<UInt8>?
    private var stroking = false
    private var pending: CGPoint?
    private var pendingTime: TimeInterval = 0
    private var lastPt = CGPoint.zero
    private var carry: CGFloat = 0
    private var dminX = 0, dminY = 0, dmaxX = 0, dmaxY = 0
    private var strokeLayer: PixLayer?
    private var patch: [Float] = []
    private var patchR = 0
    private var holdTimer: Timer?
    private var picking = false
    private let bubble = UIView()
    private let ring = CAShapeLayer()       // brush / eraser radius indicator under the finger
    private let ringDark = CAShapeLayer()
    // layer transform
    private var tfDX: CGFloat = 0, tfDY: CGFloat = 0, tfScale: CGFloat = 1, tfAngle: CGFloat = 0
    var isTransforming: Bool { tfDX != 0 || tfDY != 0 || tfScale != 1 || tfAngle != 0 }

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor(white: 0.12, alpha: 1)
        isMultipleTouchEnabled = true
        clipsToBounds = true
        let pinch = UIPinchGestureRecognizer(target: self, action: #selector(onPinch(_:)))
        let pan = UIPanGestureRecognizer(target: self, action: #selector(onPan(_:)))
        pan.minimumNumberOfTouches = 2
        let rot = UIRotationGestureRecognizer(target: self, action: #selector(onRotate(_:)))
        for g in [pinch, pan, rot] as [UIGestureRecognizer] { g.delegate = self; addGestureRecognizer(g) }
        bubble.frame = CGRect(x: 0, y: 0, width: 54, height: 54)
        bubble.layer.cornerRadius = 27
        bubble.layer.borderWidth = 4
        bubble.layer.borderColor = UIColor(white: 0.9, alpha: 1).cgColor
        bubble.isHidden = true
        bubble.isUserInteractionEnabled = false
        addSubview(bubble)
        for (l, w, a) in [(ringDark, CGFloat(3.0), CGFloat(0.55)), (ring, CGFloat(1.4), CGFloat(1.0))] {
            l.fillColor = UIColor.clear.cgColor
            l.strokeColor = UIColor(white: l === ring ? 1 : 0, alpha: a).cgColor
            l.lineWidth = w
            l.isHidden = true
            layer.addSublayer(l)
        }
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
    deinit { snap?.deallocate(); covMask?.deallocate() }

    func gestureRecognizer(_ a: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith b: UIGestureRecognizer) -> Bool { true }

    override func layoutSubviews() {
        super.layoutSubviews()
        if scale == 1 && tx == 0 && ty == 0 && angle == 0 && doc != nil { fit() }
    }

    func fit() {
        guard doc != nil, bounds.width > 10 else { return }
        let s = min(bounds.width / CGFloat(doc.w), bounds.height / CGFloat(doc.h)) * 0.94
        scale = s
        angle = 0
        tx = (bounds.width - CGFloat(doc.w) * s) / 2
        ty = (bounds.height - CGFloat(doc.h) * s) / 2
        setNeedsDisplay()
    }

    var zoomScale: CGFloat { scale }
    func toCanvas(_ p: CGPoint) -> CGPoint {
        let dx = p.x - tx, dy = p.y - ty
        let c = cos(angle), sn = sin(angle)
        return CGPoint(x: (c * dx + sn * dy) / scale, y: (-sn * dx + c * dy) / scale)
    }
    private func toView(_ p: CGPoint) -> CGPoint {
        let c = cos(angle), sn = sin(angle)
        return CGPoint(x: scale * (c * p.x - sn * p.y) + tx, y: scale * (sn * p.x + c * p.y) + ty)
    }
    /// A finger movement in view space expressed in canvas pixels (rotation + zoom undone).
    private func canvasDelta(_ d: CGPoint) -> CGPoint {
        let c = cos(angle), sn = sin(angle)
        return CGPoint(x: (c * d.x + sn * d.y) / scale, y: (-sn * d.x + c * d.y) / scale)
    }
    /// Invalidates the view-space bounding box of a canvas-space rectangle.
    private func invalidateCanvasRect(_ r: CGRect) {
        let pts = [toView(CGPoint(x: r.minX, y: r.minY)), toView(CGPoint(x: r.maxX, y: r.minY)),
                   toView(CGPoint(x: r.maxX, y: r.maxY)), toView(CGPoint(x: r.minX, y: r.maxY))]
        let x0 = pts.map { $0.x }.min() ?? 0, x1 = pts.map { $0.x }.max() ?? 0
        let y0 = pts.map { $0.y }.min() ?? 0, y1 = pts.map { $0.y }.max() ?? 0
        setNeedsDisplay(CGRect(x: x0 - 2, y: y0 - 2, width: x1 - x0 + 4, height: y1 - y0 + 4))
    }

    private var pickCtx: CGContext?
    func invalidateCaches() { cachesDirty = true; pickCtx = nil; setNeedsDisplay() }

    // MARK: drawing the view

    private func rebuildCaches() {
        cachesDirty = false
        below = nil; above = nil
        guard doc != nil else { return }
        let ai = doc.activeIndex
        let n = doc.layers.count
        if ai > 0, let c = doc.makeContext() { doc.composite(range: 0..<ai, into: c); below = c.makeImage() }
        if ai >= 0 && ai + 1 < n, let c = doc.makeContext() { doc.composite(range: (ai + 1)..<n, into: c); above = c.makeImage() }
        if ai < 0, let c = doc.makeContext() { doc.composite(range: 0..<n, into: c); below = c.makeImage() }
    }

    override func draw(_ rect: CGRect) {
        guard doc != nil, let c = UIGraphicsGetCurrentContext() else { return }
        if cachesDirty { rebuildCaches() }
        let cw = CGFloat(doc.w), ch = CGFloat(doc.h)
        let canvasRect = CGRect(x: 0, y: 0, width: cw, height: ch)
        c.saveGState()
        // everything below is drawn in canvas pixels; the view transform (move / zoom / rotate) is here
        c.translateBy(x: tx, y: ty)
        c.rotate(by: angle)
        c.scaleBy(x: scale, y: scale)
        c.saveGState()
        c.clip(to: canvasRect)
        if doc.item.paperWhite {
            c.setFillColor(UIColor.white.cgColor); c.fill(canvasRect)
        } else {
            c.setFillColor(UIColor(white: 0.30, alpha: 1).cgColor); c.fill(canvasRect)
            c.setFillColor(UIColor(white: 0.42, alpha: 1).cgColor)
            let t: CGFloat = 12 / scale
            let corners = [toCanvas(CGPoint(x: rect.minX, y: rect.minY)), toCanvas(CGPoint(x: rect.maxX, y: rect.minY)),
                           toCanvas(CGPoint(x: rect.maxX, y: rect.maxY)), toCanvas(CGPoint(x: rect.minX, y: rect.maxY))]
            let bx0 = corners.map { $0.x }.min() ?? 0, bx1 = corners.map { $0.x }.max() ?? 0
            let by0 = corners.map { $0.y }.min() ?? 0, by1 = corners.map { $0.y }.max() ?? 0
            let vis = CGRect(x: bx0, y: by0, width: bx1 - bx0, height: by1 - by0).intersection(canvasRect)
            if !vis.isNull {
                var y = floor(vis.minY / t) * t
                while y < vis.maxY {
                    var x = floor(vis.minX / t) * t
                    while x < vis.maxX {
                        let ix = Int((x / t).rounded()), iy = Int((y / t).rounded())
                        if (ix + iy) & 1 == 0 { c.fill(CGRect(x: x, y: y, width: t, height: t)) }
                        x += t
                    }
                    y += t
                }
            }
        }
        c.interpolationQuality = scale < 1 ? .medium : .none
        let full = canvasRect
        if let b = below { UIImage(cgImage: b).draw(in: full) }
        if let a = doc.active, doc.shown(a), let img = a.liveImage() {
            c.saveGState()
            if tool == .transform && isTransforming {
                c.concatenate(layerTransform())
            }
            UIImage(cgImage: img).draw(in: full, blendMode: .normal, alpha: doc.alpha(a))
            c.restoreGState()
        }
        if let a = above { UIImage(cgImage: a).draw(in: full) }
        if doc.selLayer.isLoaded, doc.selHas || selectionMode, let simg = doc.selLayer.liveImage() {
            UIImage(cgImage: simg).draw(in: full, blendMode: .normal, alpha: selectionMode ? 0.65 : 0.38)
        }
        c.restoreGState()
        c.setStrokeColor(UIColor(white: 1, alpha: 0.18).cgColor)
        c.setLineWidth(1 / scale)
        c.stroke(canvasRect)
        c.restoreGState()
    }

    // MARK: navigation gestures

    @objc private func onPan(_ g: UIPanGestureRecognizer) {
        if g.state == .began { abortStroke() }
        let d = g.translation(in: self)
        g.setTranslation(.zero, in: self)
        if tool == .transform { let cd = canvasDelta(CGPoint(x: d.x, y: d.y)); tfDX += cd.x; tfDY += cd.y; onTransformState?(true) }
        else { tx += d.x; ty += d.y }
        setNeedsDisplay()
    }

    @objc private func onPinch(_ g: UIPinchGestureRecognizer) {
        if g.state == .began { abortStroke() }
        let f = g.scale
        g.scale = 1
        if tool == .transform {
            tfScale = max(0.05, min(20, tfScale * f)); onTransformState?(true)
        } else {
            let p = g.location(in: self)
            let ns = max(0.05, min(40, scale * f))
            let k = ns / scale
            tx = p.x - (p.x - tx) * k
            ty = p.y - (p.y - ty) * k
            scale = ns
        }
        setNeedsDisplay()
    }

    @objc private func onRotate(_ g: UIRotationGestureRecognizer) {
        if g.state == .began { abortStroke() }
        if tool == .transform {
            tfAngle += g.rotation
            onTransformState?(true)
            setNeedsDisplay()
        } else {
            // rotate the whole view around the fingers' midpoint (Ibis Paint style)
            let r = g.rotation
            let p = g.location(in: self)
            let c = cos(r), sn = sin(r)
            let vx = tx - p.x, vy = ty - p.y
            tx = p.x + c * vx - sn * vy
            ty = p.y + sn * vx + c * vy
            angle += r
            // gentle snap back to upright when the canvas is almost level
            if g.state == .ended || g.state == .cancelled {
                let a = atan2(sin(angle), cos(angle))
                if abs(a) < 0.06 {
                    let back = -a
                    let c2 = cos(back), s2 = sin(back)
                    let ux = tx - p.x, uy = ty - p.y
                    tx = p.x + c2 * ux - s2 * uy
                    ty = p.y + s2 * ux + c2 * uy
                    angle = 0
                }
            }
            setNeedsDisplay()
        }
        g.rotation = 0
    }

    // MARK: layer transform

    private func layerTransform() -> CGAffineTransform {
        let cx = CGFloat(doc.w) / 2, cy = CGFloat(doc.h) / 2
        var t = CGAffineTransform(translationX: cx + tfDX, y: cy + tfDY)
        t = t.rotated(by: tfAngle).scaledBy(x: tfScale, y: tfScale)
        return t.translatedBy(x: -cx, y: -cy)
    }

    func cancelTransform() {
        guard isTransforming else { return }
        tfDX = 0; tfDY = 0; tfScale = 1; tfAngle = 0
        onTransformState?(false)
        setNeedsDisplay()
    }

    func applyTransform() {
        guard isTransforming, let layer = doc.active, let old = layer.liveImage() else { return }
        let n = doc.w * doc.h * 4
        let before = Array(UnsafeBufferPointer(start: layer.buf, count: n))
        let tmp = UnsafeMutablePointer<UInt8>.allocate(capacity: n)
        tmp.initialize(repeating: 0, count: n)
        defer { tmp.deallocate() }
        guard let c = CGContext(data: tmp, width: doc.w, height: doc.h, bitsPerComponent: 8, bytesPerRow: doc.w * 4,
                                space: CGColorSpaceCreateDeviceRGB(),
                                bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return }
        c.interpolationQuality = .high
        c.translateBy(x: 0, y: CGFloat(doc.h)); c.scaleBy(x: 1, y: -1)
        UIGraphicsPushContext(c)
        c.concatenate(layerTransform())
        UIImage(cgImage: old).draw(in: CGRect(x: 0, y: 0, width: doc.w, height: doc.h))
        UIGraphicsPopContext()
        layer.buf.update(from: tmp, count: n)
        layer.dirty = true
        let after = Array(UnsafeBufferPointer(start: layer.buf, count: n))
        pushUndo(DrawUndo(layerId: layer.meta.id, x: 0, y: 0, w: doc.w, h: doc.h, before: before, after: after))
        tfDX = 0; tfDY = 0; tfScale = 1; tfAngle = 0
        onTransformState?(false)
        setNeedsDisplay()
        onChanged?()
    }

    // MARK: undo / redo

    private func pushUndo(_ u: DrawUndo) {
        undoStack.append(u); undoBytes += u.before.count + u.after.count
        for r in redoStack { undoBytes -= r.before.count + r.after.count }
        redoStack.removeAll()
        while undoBytes > 160_000_000 && undoStack.count > 1 {
            let f = undoStack.removeFirst(); undoBytes -= f.before.count + f.after.count
        }
    }
    var canUndo: Bool { !undoStack.isEmpty }
    var canRedo: Bool { !redoStack.isEmpty }

    private func apply(_ u: DrawUndo, _ pixels: [UInt8]) {
        guard let l = doc.layer(u.layerId) ?? (u.layerId == "__sel__" ? doc.selLayer : nil), !l.meta.isFolder else { return }
        pixels.withUnsafeBufferPointer { src in
            for row in 0..<u.h {
                let d = l.buf + ((u.y + row) * doc.w + u.x) * 4
                (d).update(from: src.baseAddress! + row * u.w * 4, count: u.w * 4)
            }
        }
        l.dirty = true
        if l === doc.selLayer { doc.recomputeSel(); onSelectionChanged?() }
        invalidateCaches()
    }

    func undo() {
        guard let u = undoStack.popLast() else { return }
        apply(u, u.before); redoStack.append(u); onChanged?()
    }
    func redo() {
        guard let u = redoStack.popLast() else { return }
        apply(u, u.after); undoStack.append(u); onChanged?()
    }

    // MARK: touches

    private func pressure(_ t: UITouch) -> CGFloat {
        guard t.type == .pencil, t.maximumPossibleForce > 0 else { return 1 }
        return 0.35 + 0.65 * min(1, t.force / t.maximumPossibleForce)
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first, doc != nil else { return }
        if (event?.allTouches?.count ?? 1) > 1 { abortStroke(); return }
        let p = toCanvas(t.location(in: self))
        if tool == .eyedropper { picking = true; pickAt(p, t.location(in: self)); return }
        if tool == .transform { lastPt = t.location(in: self); return }
        if tool == .wand {
            guard doc.active != nil else { onBlocked?("Select a layer first"); return }
            wandPt = p; wandStartView = t.location(in: self); return
        }
        if selectionMode && (tool == .smudge) { onBlocked?("Not available on the Selection Layer"); return }
        guard let l = target else { onBlocked?("Select a layer first"); return }
        if !selectionMode && !doc.shown(l) { onBlocked?("This layer is hidden"); return }
        pending = p
        pendingTime = t.timestamp
        lastPt = p
        moveRing(t.location(in: self), pressure: pressure(t))
        holdTimer?.invalidate()
        if tool == .brush || tool == .eraser {
            holdTimer = Timer.scheduledTimer(withTimeInterval: 0.45, repeats: false) { [weak self] _ in
                guard let self = self, self.pending != nil, !self.stroking else { return }
                self.pending = nil
                self.picking = true
                self.hideRing()
                self.pickAt(self.lastPt, self.toView(self.lastPt))
            }
        }
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first, doc != nil else { return }
        if (event?.allTouches?.count ?? 1) > 1 { abortStroke(); return }
        let vp = t.location(in: self)
        let p = toCanvas(vp)
        if picking { hideRing(); pickAt(p, vp); return }
        if tool == .wand {
            if wandPt != nil, hypot(vp.x - wandStartView.x, vp.y - wandStartView.y) > 10 { wandPt = nil }
            return
        }
        if tool != .transform { moveRing(vp, pressure: pressure(t)) }
        if tool == .transform {
            let cd = canvasDelta(CGPoint(x: vp.x - lastPt.x, y: vp.y - lastPt.y)); tfDX += cd.x; tfDY += cd.y
            lastPt = vp; onTransformState?(true); setNeedsDisplay(); return
        }
        if let s = pending {
            if hypot(p.x - s.x, p.y - s.y) * scale < 4 { return }
            holdTimer?.invalidate()
            beginStroke(at: s, pressure: pressure(t))
            pending = nil
        }
        guard stroking else { return }
        // use coalesced touches for smooth lines
        let all = event?.coalescedTouches(for: t) ?? [t]
        for ct in all { extendStroke(to: toCanvas(ct.location(in: self)), pressure: pressure(ct)) }
        if tool != .smudge { flush() } else { markDirtyView() }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        holdTimer?.invalidate()
        hideRing()
        if picking { picking = false; bubble.isHidden = true; return }
        if tool == .wand { if let p = wandPt { wandPt = nil; wandTap(p) }; return }
        if let s = pending, let t = touches.first {                // a tap = one dab
            pending = nil
            beginStroke(at: s, pressure: pressure(t))
        }
        if stroking { endStroke() }
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        holdTimer?.invalidate()
        hideRing()
        picking = false; bubble.isHidden = true
        abortStroke()
    }

    // MARK: radius indicator

    /// Circle showing exactly what the brush / eraser / smudge covers, centred on the finger.
    private func moveRing(_ viewPt: CGPoint, pressure pr: CGFloat) {
        guard tool == .brush || tool == .eraser || tool == .smudge else { hideRing(); return }
        let r = max(2, brushSize / 2 * (tool == .smudge ? pr : effP(pr)) * scale)
        let path = tool == .brush && st.square
            ? CGPath(rect: CGRect(x: -r, y: -r, width: 2 * r, height: 2 * r), transform: nil)
            : CGPath(ellipseIn: CGRect(x: -r, y: -r, width: 2 * r, height: 2 * r), transform: nil)
        CATransaction.begin(); CATransaction.setDisableActions(true)
        for l in [ringDark, ring] {
            l.path = path
            l.position = viewPt
            l.lineDashPattern = tool == .eraser ? [5, 4] : nil
            l.isHidden = false
        }
        CATransaction.commit()
    }

    private func hideRing() {
        CATransaction.begin(); CATransaction.setDisableActions(true)
        ring.isHidden = true; ringDark.isHidden = true
        CATransaction.commit()
    }

    // MARK: eyedropper

    private func pickAt(_ p: CGPoint, _ viewPt: CGPoint) {
        if pickCtx == nil { pickCtx = doc.flattenContext(withPaper: true) }
        let x = Int(p.x), y = Int(p.y)
        bubble.center = CGPoint(x: viewPt.x, y: max(40, viewPt.y - 70))
        guard let c = pickCtx, let d = c.data, x >= 0, y >= 0, x < c.width, y < c.height else { return }
        let px = d.assumingMemoryBound(to: UInt8.self) + y * c.bytesPerRow + x * 4
        let a = CGFloat(px[3]) / 255
        let col: UIColor
        if a <= 0.004 { col = UIColor(white: 0.5, alpha: 1) } else {
            col = UIColor(red: min(1, CGFloat(px[0]) / 255 / a), green: min(1, CGFloat(px[1]) / 255 / a),
                          blue: min(1, CGFloat(px[2]) / 255 / a), alpha: 1)
        }
        bubble.backgroundColor = col
        bubble.isHidden = false
        if a > 0.004 { onColorPicked?(col) }
    }

    // MARK: strokes

    private func ensureBuffers() {
        let n = doc.w * doc.h
        if snap == nil || snapCount != n * 4 {
            snap?.deallocate(); covMask?.deallocate()
            snap = UnsafeMutablePointer<UInt8>.allocate(capacity: n * 4)
            covMask = UnsafeMutablePointer<UInt8>.allocate(capacity: n)
            covMask!.initialize(repeating: 0, count: n)
            snapCount = n * 4
        }
    }
    private var snapCount = 0

    private func beginStroke(at p: CGPoint, pressure: CGFloat) {
        guard let l = target else { return }
        ensureBuffers()
        snap!.update(from: l.buf, count: doc.w * doc.h * 4)
        strokeLayer = l
        clip = (!selectionMode && doc.selHas && doc.selLayer.isLoaded) ? doc.selLayer.buf : nil
        strokePts = [(p, pressure)]; strokeDist = 0; strokeTotal = -1
        stroking = true
        dminX = Int.max; dminY = Int.max; dmaxX = -1; dmaxY = -1
        lastPt = p
        carry = 0
        if tool == .smudge {
            patchR = max(2, Int(brushSize / 2 * pressure))
            patch = [Float](repeating: 0, count: (patchR * 2 + 1) * (patchR * 2 + 1) * 4)
            samplePatch(at: p, into: &patch, r: patchR, keep: 0, layer: l)
        } else {
            dab(p, pressure: pressure, along: 0)
            flush()
        }
    }

    private func extendStroke(to p: CGPoint, pressure: CGFloat, record: Bool = true) {
        guard stroking, let l = strokeLayer else { return }
        let r = max(0.5, brushSize / 2 * (tool == .smudge ? pressure : effP(pressure)))
        let step = max(0.7, r * (tool == .smudge ? 0.18 : max(0.03, st.spacing)))
        var dx = p.x - lastPt.x, dy = p.y - lastPt.y
        let dist = hypot(dx, dy)
        if dist < 0.01 { return }
        dx /= dist; dy /= dist
        var pos = step - carry
        while pos <= dist {
            let q = CGPoint(x: lastPt.x + dx * pos, y: lastPt.y + dy * pos)
            if tool == .smudge { smudgeStep(q, pressure: pressure, layer: l) } else { dab(q, pressure: pressure, along: strokeDist + pos) }
            pos += step
        }
        carry = dist - (pos - step)
        strokeDist += dist
        if record && tool != .smudge { strokePts.append((p, pressure)) }
        lastPt = p
    }

    private func abortStroke() {
        wandPt = nil
        holdTimer?.invalidate()
        hideRing()
        pending = nil
        guard stroking, let l = strokeLayer, let sn = snap else { stroking = false; return }
        if dmaxX >= dminX { restoreFromSnap(l, sn); clearMask() }
        stroking = false
        invalidateCaches()
    }

    private func restoreFromSnap(_ l: PixLayer, _ sn: UnsafeMutablePointer<UInt8>) {
        let x0 = max(0, dminX), x1 = min(doc.w - 1, dmaxX), y0 = max(0, dminY), y1 = min(doc.h - 1, dmaxY)
        if x1 >= x0 && y1 >= y0 {
            for y in y0...y1 {
                let o = (y * doc.w + x0) * 4
                (l.buf + o).update(from: sn + o, count: (x1 - x0 + 1) * 4)
            }
        }
    }

    /// Re-draws the finished stroke with a tapered end (needs the total length, so it can only happen on lift).
    private func replayWithEndTaper() {
        guard let l = strokeLayer, let sn = snap, dmaxX >= dminX, strokePts.count > 1 else { return }
        let pts = strokePts
        var total: CGFloat = 0
        for i in 1..<pts.count { total += hypot(pts[i].0.x - pts[i - 1].0.x, pts[i].0.y - pts[i - 1].0.y) }
        restoreFromSnap(l, sn)
        clearMask()
        strokeTotal = total; strokeDist = 0; carry = 0; lastPt = pts[0].0
        dab(pts[0].0, pressure: pts[0].1, along: 0)
        for i in 1..<pts.count { extendStroke(to: pts[i].0, pressure: pts[i].1, record: false) }
        flush()
    }

    private func endStroke() {
        guard stroking, let l = strokeLayer, let sn = snap else { return }
        if tool != .smudge && st.tipEnd > 0 { replayWithEndTaper() }
        stroking = false
        pickCtx = nil
        if dmaxX >= dminX {
            let x = max(0, dminX), y = max(0, dminY)
            let w = min(doc.w - 1, dmaxX) - x + 1, h = min(doc.h - 1, dmaxY) - y + 1
            if w > 0 && h > 0 {
                var before = [UInt8](repeating: 0, count: w * h * 4)
                var after = before
                for row in 0..<h {
                    let o = ((y + row) * doc.w + x) * 4
                    before.withUnsafeMutableBufferPointer { ($0.baseAddress! + row * w * 4).update(from: sn + o, count: w * 4) }
                    after.withUnsafeMutableBufferPointer { ($0.baseAddress! + row * w * 4).update(from: l.buf + o, count: w * 4) }
                }
                if before != after {                       // erasing already-transparent pixels changes nothing
                    pushUndo(DrawUndo(layerId: l.meta.id, x: x, y: y, w: w, h: h, before: before, after: after))
                    l.dirty = true
                }
            }
            clearMask()
        }
        if selectionMode { doc.recomputeSel(); onSelectionChanged?() }
        onChanged?()
    }

    private func clearMask() {
        guard let m = covMask, dmaxX >= dminX else { return }
        let x0 = max(0, dminX), x1 = min(doc.w - 1, dmaxX)
        let y0 = max(0, dminY), y1 = min(doc.h - 1, dmaxY)
        if x1 < x0 || y1 < y0 { return }
        let count = x1 - x0 + 1
        for y in y0...y1 {
            let row: Int = y * doc.w + x0
            (m + row).update(repeating: 0, count: count)
        }
    }

    private func grow(_ x0: Int, _ y0: Int, _ x1: Int, _ y1: Int) {
        dminX = min(dminX, x0); dminY = min(dminY, y0); dmaxX = max(dmaxX, x1); dmaxY = max(dmaxY, y1)
    }

    private var flushX0 = Int.max, flushY0 = Int.max, flushX1 = -1, flushY1 = -1

    /// Stamps a soft round dab into the coverage covMask.
    private func effP(_ pr: CGFloat) -> CGFloat { 1 - st.pressureSize + st.pressureSize * pr }

    private func grainNoise(_ x: Int, _ y: Int) -> CGFloat {
        var h = UInt32(truncatingIfNeeded: x &* 73856093) ^ UInt32(truncatingIfNeeded: y &* 19349663)
        h = (h ^ (h >> 13)) &* 1274126177
        h ^= h >> 16
        return CGFloat(h & 0xFFFF) / 65535
    }

    private func taperScale(_ d: CGFloat) -> CGFloat {
        let L = max(8, brushSize * 5)
        var t: CGFloat = 1
        if st.tipStart > 0 { t = min(t, d / (st.tipStart * L)) }
        if st.tipEnd > 0, strokeTotal >= 0 { t = min(t, (strokeTotal - d) / (st.tipEnd * L)) }
        t = min(1, max(0, t))
        return 0.1 + 0.9 * (t * t * (3 - 2 * t))
    }

    private func dab(_ p0: CGPoint, pressure: CGFloat, along: CGFloat = 0) {
        guard let m = covMask else { return }
        let sy = st, W = doc.w, H = doc.h
        var p = p0
        var r = max(0.5, brushSize / 2 * effP(pressure))
        if sy.tipStart > 0 || sy.tipEnd > 0 { r = max(0.5, r * taperScale(along)) }
        let flow = 1 - sy.pressureOpacity + sy.pressureOpacity * pressure
        if sy.sizeJitter > 0 { r = max(0.5, r * (1 - sy.sizeJitter * CGFloat.random(in: 0...1))) }
        if sy.scatter > 0 {
            let an = CGFloat.random(in: 0..<(2 * CGFloat.pi))
            let dd = r * sy.scatter * CGFloat.random(in: 0...1)
            p.x += cos(an) * dd; p.y += sin(an) * dd
        }
        let x0 = max(0, Int(floor(p.x - r - 1))), x1 = min(W - 1, Int(ceil(p.x + r + 1)))
        let y0 = max(0, Int(floor(p.y - r - 1))), y1 = min(H - 1, Int(ceil(p.y + r + 1)))
        if x1 < x0 || y1 < y0 { return }
        let aa = max(1, r * (1 - sy.hardness))
        for y in y0...y1 {
            let dy = CGFloat(y) + 0.5 - p.y
            for x in x0...x1 {
                let dx = CGFloat(x) + 0.5 - p.x
                let d = sy.square ? max(abs(dx), abs(dy)) : (dx * dx + dy * dy).squareRoot()
                var cov = min(1, max(0, (r - d) / aa))
                if cov <= 0 { continue }
                if sy.grain > 0 { cov *= 1 - sy.grain + sy.grain * grainNoise(x, y) }
                if flow < 1 { cov *= flow }
                let v = UInt8(cov * 255)
                let i = y * W + x
                if v > m[i] { m[i] = v }
            }
        }
        grow(x0, y0, x1, y1)
        flushX0 = min(flushX0, x0); flushY0 = min(flushY0, y0); flushX1 = max(flushX1, x1); flushY1 = max(flushY1, y1)
    }

    /// Composites the covMask over the stroke-start snapshot for the pixels touched since the last flush.
    private func flush() {
        guard flushX1 >= flushX0, let l = strokeLayer, let m = covMask, let sn = snap else { return }
        var cr: CGFloat = 0, cg: CGFloat = 0, cb: CGFloat = 0, ca: CGFloat = 0
        color.getRed(&cr, green: &cg, blue: &cb, alpha: &ca)
        var R = Float(cr * 255), G = Float(cg * 255), B = Float(cb * 255)
        if selectionMode { R = 51; G = 102; B = 255 }          // selection paint is always blue
        let op = Float(opacity)
        let erase = tool == .eraser
        let dst = l.buf, W = doc.w
        for y in flushY0...flushY1 {
            for x in flushX0...flushX1 {
                let i = y * W + x
                let mv = m[i]
                if mv == 0 { continue }
                var a = Float(mv) / 255 * op
                let o = i * 4
                if let cp = clip { a *= Float(cp[o + 3]) / 255 }
                if erase {
                    let k = 1 - a
                    dst[o] = UInt8(Float(sn[o]) * k); dst[o + 1] = UInt8(Float(sn[o + 1]) * k)
                    dst[o + 2] = UInt8(Float(sn[o + 2]) * k); dst[o + 3] = UInt8(Float(sn[o + 3]) * k)
                } else {
                    let k = 1 - a
                    dst[o] = UInt8(min(255, R * a + Float(sn[o]) * k))
                    dst[o + 1] = UInt8(min(255, G * a + Float(sn[o + 1]) * k))
                    dst[o + 2] = UInt8(min(255, B * a + Float(sn[o + 2]) * k))
                    dst[o + 3] = UInt8(min(255, 255 * a + Float(sn[o + 3]) * k))
                }
            }
        }
        invalidateCanvasRect(CGRect(x: flushX0, y: flushY0, width: flushX1 + 1 - flushX0, height: flushY1 + 1 - flushY0))
        flushX0 = Int.max; flushY0 = Int.max; flushX1 = -1; flushY1 = -1
    }

    // MARK: smudge

    private func samplePatch(at p: CGPoint, into pt: inout [Float], r: Int, keep: Float, layer: PixLayer) {
        let d = r * 2 + 1
        let cx = Int(p.x), cy = Int(p.y)
        for j in 0..<d {
            let y = cy + j - r
            if y < 0 || y >= doc.h { continue }
            for i in 0..<d {
                let x = cx + i - r
                if x < 0 || x >= doc.w { continue }
                let o = (y * doc.w + x) * 4
                let k = (j * d + i) * 4
                for c in 0..<4 { pt[k + c] = pt[k + c] * keep + Float(layer.buf[o + c]) * (1 - keep) }
            }
        }
    }

    private func smudgeStep(_ p: CGPoint, pressure: CGFloat, layer l: PixLayer) {
        let r = patchR
        let dst = l.buf
        let d = r * 2 + 1
        let cx = Int(p.x.rounded()), cy = Int(p.y.rounded())
        let strength = Float(max(0.08, opacity)) * 0.8
        let rr = Float(r)
        for j in 0..<d {
            let y = cy + j - r
            if y < 0 || y >= doc.h { continue }
            for i in 0..<d {
                let x = cx + i - r
                if x < 0 || x >= doc.w { continue }
                let dx = Float(i - r), dy = Float(j - r)
                let dist = (dx * dx + dy * dy).squareRoot()
                let cov = min(1, max(0, (rr - dist) / max(1, rr * 0.5)))
                if cov <= 0 { continue }
                let o = (y * doc.w + x) * 4
                var k = cov * strength
                if let cp = clip { k *= Float(cp[o + 3]) / 255 }
                let pk = (j * d + i) * 4
                for c in 0..<4 { dst[o + c] = UInt8(max(0, min(255, Float(dst[o + c]) * (1 - k) + patch[pk + c] * k))) }
            }
        }
        grow(cx - r, cy - r, cx + r, cy + r)
        flushX0 = min(flushX0, cx - r); flushY0 = min(flushY0, cy - r)
        flushX1 = max(flushX1, cx + r); flushY1 = max(flushY1, cy + r)
        let keep = Float(min(0.97, 0.55 + 0.42 * opacity))
        samplePatch(at: p, into: &patch, r: r, keep: keep, layer: l)
    }

    private func markDirtyView() {
        guard flushX1 >= flushX0 else { return }
        let x0 = max(0, flushX0), y0 = max(0, flushY0), x1 = min(doc.w, flushX1 + 1), y1 = min(doc.h, flushY1 + 1)
        invalidateCanvasRect(CGRect(x: x0, y: y0, width: max(0, x1 - x0), height: max(0, y1 - y0)))
        flushX0 = Int.max; flushY0 = Int.max; flushX1 = -1; flushY1 = -1
    }

    // MARK: selection layer / magic wand

    private func snapshot(_ l: PixLayer) -> [UInt8] {
        Array(UnsafeBufferPointer(start: l.buf, count: doc.w * doc.h * 4))
    }

    /// Diffs the layer against `before`, stores only the changed rectangle as one undo step.
    private func commit(_ l: PixLayer, before: [UInt8]) {
        let w = doc.w, h = doc.h
        var x0 = w, y0 = h, x1 = -1, y1 = -1
        before.withUnsafeBufferPointer { b in
            let bp = b.baseAddress!
            for y in 0..<h {
                let row = y * w * 4
                if memcmp(bp + row, l.buf + row, w * 4) == 0 { continue }
                var xs = 0
                while xs < w && memcmp(bp + row + xs * 4, l.buf + row + xs * 4, 4) == 0 { xs += 1 }
                var xe = w - 1
                while xe > xs && memcmp(bp + row + xe * 4, l.buf + row + xe * 4, 4) == 0 { xe -= 1 }
                x0 = min(x0, xs); x1 = max(x1, xe); y0 = min(y0, y); y1 = max(y1, y)
            }
        }
        guard x1 >= x0 else { return }
        let rw = x1 - x0 + 1, rh = y1 - y0 + 1
        var bef = [UInt8](repeating: 0, count: rw * rh * 4)
        var aft = bef
        before.withUnsafeBufferPointer { bp in
            for row in 0..<rh {
                let o = ((y0 + row) * w + x0) * 4
                bef.withUnsafeMutableBufferPointer { ($0.baseAddress! + row * rw * 4).update(from: bp.baseAddress! + o, count: rw * 4) }
                aft.withUnsafeMutableBufferPointer { ($0.baseAddress! + row * rw * 4).update(from: l.buf + o, count: rw * 4) }
            }
        }
        pushUndo(DrawUndo(layerId: l.meta.id, x: x0, y: y0, w: rw, h: rh, before: bef, after: aft))
        l.dirty = true
    }

    private func finishSelOp(_ before: [UInt8]) {
        commit(doc.selLayer, before: before)
        doc.recomputeSel()
        setNeedsDisplay()
        onSelectionChanged?()
        onChanged?()
    }

    @inline(__always) private func setSel(_ p: UnsafeMutablePointer<UInt8>, _ i: Int, _ a: Int) {
        let o = i * 4
        p[o] = UInt8(51 * a / 255); p[o + 1] = UInt8(102 * a / 255); p[o + 2] = UInt8(a); p[o + 3] = UInt8(a)
    }

    func removeSelection() {
        guard doc.selHas else { return }
        let sl = doc.selLayer, b = snapshot(sl)
        sl.clear()
        finishSelOp(b)
    }

    func invertSelection() {
        let sl = doc.selLayer, b = snapshot(sl), p = sl.buf
        for i in 0..<(doc.w * doc.h) { setSel(p, i, 255 - Int(p[i * 4 + 3])) }
        finishSelOp(b)
    }

    /// Select every pixel that has paint on the active layer.
    func selectOpacity() {
        guard let src = doc.active else { onBlocked?("Select a layer first"); return }
        let sl = doc.selLayer, b = snapshot(sl), p = sl.buf, s = src.buf
        for i in 0..<(doc.w * doc.h) {
            let a = Int(s[i * 4 + 3])
            if a > Int(p[i * 4 + 3]) { setSel(p, i, a) }
        }
        finishSelOp(b)
    }

    /// Clears the active layer inside the selection (whole layer if nothing is selected).
    func clearLayer() {
        guard let l = doc.active else { onBlocked?("Select a layer first"); return }
        let b = snapshot(l), p = l.buf
        if doc.selHas {
            let sp = doc.selLayer.buf
            for i in 0..<(doc.w * doc.h) {
                let sa = Int(sp[i * 4 + 3])
                if sa == 0 { continue }
                let k = 255 - sa
                let o = i * 4
                for c in 0..<4 { p[o + c] = UInt8(Int(p[o + c]) * k / 255) }
            }
        } else {
            l.clear()
        }
        commit(l, before: b)
        invalidateCaches()
        onChanged?()
    }

    /// Magic wand: picks the colour under the tap on the active layer and adds (or subtracts) it to the Selection Layer.
    private func wandTap(_ pt: CGPoint) {
        let w = doc.w, h = doc.h
        let x = Int(pt.x), y = Int(pt.y)
        guard x >= 0, y >= 0, x < w, y < h, let src = doc.active else { return }
        let s = src.buf
        let o0 = (y * w + x) * 4
        let r0 = Int(s[o0]), g0 = Int(s[o0 + 1]), b0 = Int(s[o0 + 2]), a0 = Int(s[o0 + 3])
        let tol = wandTolerance
        let match: (Int) -> Bool = { i in
            let o = i * 4
            return abs(Int(s[o]) - r0) <= tol && abs(Int(s[o + 1]) - g0) <= tol
                && abs(Int(s[o + 2]) - b0) <= tol && abs(Int(s[o + 3]) - a0) <= tol
        }
        var mark = [UInt8](repeating: 0, count: w * h)
        if wandContiguous {
            var stack = [y * w + x]
            while let seed = stack.popLast() {
                if mark[seed] != 0 { continue }
                let sy = seed / w, sx = seed % w
                var l = sx, r = sx
                while l > 0 && mark[sy * w + l - 1] == 0 && match(sy * w + l - 1) { l -= 1 }
                while r < w - 1 && mark[sy * w + r + 1] == 0 && match(sy * w + r + 1) { r += 1 }
                for xx in l...r { mark[sy * w + xx] = 1 }
                for ny in [sy - 1, sy + 1] where ny >= 0 && ny < h {
                    var xx = l
                    while xx <= r {
                        let ii = ny * w + xx
                        if mark[ii] == 0 && match(ii) {
                            stack.append(ii)
                            xx += 1
                            while xx <= r && mark[ny * w + xx] == 0 && match(ny * w + xx) { xx += 1 }
                        } else { xx += 1 }
                    }
                }
            }
        } else {
            for i in 0..<(w * h) where match(i) { mark[i] = 1 }
        }
        let sl = doc.selLayer, before = snapshot(sl), p = sl.buf
        let sub = wandSubtract
        for i in 0..<(w * h) where mark[i] != 0 {
            if sub { let o = i * 4; p[o] = 0; p[o + 1] = 0; p[o + 2] = 0; p[o + 3] = 0 } else { setSel(p, i, 255) }
        }
        finishSelOp(before)
    }

    // MARK: copy / cut / paste

    struct Clip { var x: Int, y: Int, w: Int, h: Int, px: [UInt8] }
    static var clipboard: Clip?

    /// Copies the active layer's pixels inside the selection (whole layer if nothing is selected).
    @discardableResult
    func copySelection(cut: Bool) -> Bool {
        guard let l = doc.active else { onBlocked?("Select a layer first"); return false }
        let W = doc.w, H = doc.h
        let src = l.buf
        let sp: UnsafeMutablePointer<UInt8>? = doc.selHas ? doc.selLayer.buf : nil
        var x0 = W, y0 = H, x1 = -1, y1 = -1
        for y in 0..<H {
            for x in 0..<W {
                let o = (y * W + x) * 4
                if src[o + 3] == 0 { continue }
                if let sp = sp, sp[o + 3] == 0 { continue }
                x0 = min(x0, x); x1 = max(x1, x); y0 = min(y0, y); y1 = max(y1, y)
            }
        }
        guard x1 >= x0 else { onBlocked?("Nothing to copy"); return false }
        let cw = x1 - x0 + 1, ch = y1 - y0 + 1
        var px = [UInt8](repeating: 0, count: cw * ch * 4)
        for y in 0..<ch {
            for x in 0..<cw {
                let o = ((y0 + y) * W + x0 + x) * 4
                let k = sp.map { Int($0[o + 3]) } ?? 255
                let d = (y * cw + x) * 4
                for c in 0..<4 { px[d + c] = UInt8(Int(src[o + c]) * k / 255) }
            }
        }
        DrawingCanvasView.clipboard = Clip(x: x0, y: y0, w: cw, h: ch, px: px)
        if cut { clearLayer() }
        return true
    }

    /// Pastes the clipboard into `l` at its original position.
    func paste(into l: PixLayer) {
        guard let c = DrawingCanvasView.clipboard else { return }
        let W = doc.w
        c.px.withUnsafeBufferPointer { sp in
            for y in 0..<c.h where c.y + y >= 0 && c.y + y < doc.h {
                let d = l.buf + ((c.y + y) * W + c.x) * 4
                d.update(from: sp.baseAddress! + y * c.w * 4, count: min(c.w, W - c.x) * 4)
            }
        }
        l.dirty = true
        doc.activeId = l.meta.id
        invalidateCaches()
        onChanged?()
    }
}
