// DrawingNewSheet.swift — the "New" sheet of the drawing gallery (Folder, Import Picture, Illustration and Printing sizes).

import UIKit

private final class SizeShape: UIView {
    var w = 1, h = 1, dashed = true
    override init(frame: CGRect) { super.init(frame: frame); backgroundColor = .clear; isUserInteractionEnabled = false }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let box = bounds.insetBy(dx: 3, dy: 3)
        let k = min(box.width / CGFloat(w), box.height / CGFloat(h))
        let rw = max(6, CGFloat(w) * k), rh = max(6, CGFloat(h) * k)
        let r = CGRect(x: bounds.midX - rw / 2, y: bounds.midY - rh / 2, width: rw, height: rh)
        c.setStrokeColor(UIColor.black.cgColor)
        c.setLineWidth(3)
        if dashed { c.setLineDash(phase: 0, lengths: [8, 5]) }
        c.stroke(r)
    }
}

private final class NewRow: TapView {
    let left = UIView(), title = UILabel()
    var trailing = UIView()
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor(white: 0.91, alpha: 1)
        title.font = .systemFont(ofSize: 21); title.textColor = .black
        for v in [left, title, trailing] { addSubview(v) }
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
    override func layoutSubviews() {
        super.layoutSubviews()
        let h = bounds.height
        left.frame = CGRect(x: 10, y: (h - 48) / 2, width: 48, height: 48)
        let tw = trailing.frame.width
        trailing.frame = CGRect(x: bounds.width - tw - 6, y: (h - trailing.frame.height) / 2, width: tw, height: trailing.frame.height)
        title.frame = CGRect(x: 70, y: 0, width: max(10, trailing.frame.minX - 76), height: h)
    }
}

final class DrawingNewSheetViewController: UIViewController {
    var onFolder: (() -> Void)?
    var onImport: (() -> Void)?
    var onCreate: ((Int, Int, String) -> Void)?

    private var customW = 2000, customH = 2000
    private var swapped = Set<String>()
    private let scroll = UIScrollView()
    private let stack = UIStackView()

    private let illustration: [(String, Int, Int, Bool)] = [
        ("HD (Quality)", 1080, 2340, true), ("1:1 (2K)", 2048, 2048, true), ("3:4 (2K)", 1536, 2048, true),
        ("9:16 (2K)", 1080, 1920, true), ("X Header", 1500, 500, false), ("Chat Stamp", 370, 320, false),
        ("Vertical", 690, 4096, false),
    ]
    private let printing: [(String, Int, Int, String?)] = [
        ("Manga Manuscript", 2039, 2894, nil), ("Postcard (JP)", 1181, 1748, "300 dpi"), ("A4", 1240, 1754, "150 dpi"),
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(white: 0.18, alpha: 1)
        let head = UIView(); head.tag = 1
        let t = UILabel(); t.text = "New"; t.font = .boldSystemFont(ofSize: 24); t.textColor = .white; t.tag = 2
        let x = TapView(); x.tag = 3
        let ic = IconView("close", Int32(bitPattern: 0xFFFFFFFF), 26); ic.isUserInteractionEnabled = false
        ic.frame = CGRect(x: 8, y: 8, width: 34, height: 34); x.addSubview(ic)
        x.onClick = { [weak self] in self?.dismiss(animated: true) }
        head.addSubview(t); head.addSubview(x)
        view.addSubview(head)
        scroll.showsVerticalScrollIndicator = true
        scroll.layer.cornerRadius = 12; scroll.clipsToBounds = true
        view.addSubview(scroll)
        stack.axis = .vertical; stack.spacing = 0
        scroll.addSubview(stack)
        build()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let w = view.bounds.width
        view.viewWithTag(1)?.frame = CGRect(x: 0, y: 8, width: w, height: 50)
        view.viewWithTag(2)?.frame = CGRect(x: 18, y: 8, width: 200, height: 34)
        view.viewWithTag(3)?.frame = CGRect(x: w - 56, y: 0, width: 50, height: 50)
        scroll.frame = CGRect(x: 8, y: 62, width: w - 16, height: view.bounds.height - 62 - max(view.safeAreaInsets.bottom, 8))
        layoutStack()
    }

    private func layoutStack() {
        let w = scroll.bounds.width
        var y: CGFloat = 0
        for v in stack.arrangedSubviews { v.frame = CGRect(x: 0, y: y, width: w, height: v.bounds.height); y += v.bounds.height }
        stack.frame = CGRect(x: 0, y: 0, width: w, height: y)
        scroll.contentSize = CGSize(width: w, height: y)
    }

    private func rebuildKeepScroll() {
        let off = scroll.contentOffset
        build()
        layoutStack()
        scroll.contentOffset = off
    }

    private func sectionHeader(_ s: String) -> UIView {
        let v = UIView(); v.backgroundColor = UIColor(white: 0.32, alpha: 1)
        v.bounds = CGRect(x: 0, y: 0, width: 10, height: 44)
        let l = UILabel(); l.text = s; l.font = .systemFont(ofSize: 20); l.textColor = .white
        l.frame = CGRect(x: 16, y: 0, width: 300, height: 44); v.addSubview(l)
        return v
    }

    private func line() -> UIView {
        let v = UIView(); v.backgroundColor = UIColor(white: 0.62, alpha: 1); v.bounds = CGRect(x: 0, y: 0, width: 10, height: 1)
        return v
    }

    private func pill(_ text: String, icon: String, width: CGFloat, tap: @escaping () -> Void) -> UIView {
        let v = TapView()
        v.frame = CGRect(x: 0, y: 0, width: width, height: 46)
        v.backgroundColor = .white; v.layer.cornerRadius = 8
        let l = UILabel(); l.text = text; l.font = .systemFont(ofSize: 23); l.textColor = .black
        l.frame = CGRect(x: 14, y: 0, width: width - 56, height: 46); l.isUserInteractionEnabled = false
        let ic = IconView(icon, Int32(bitPattern: 0xFF555555), 22); ic.isUserInteractionEnabled = false
        ic.frame = CGRect(x: width - 40, y: 8, width: 30, height: 30)
        v.addSubview(l); v.addSubview(ic)
        v.onClick = tap
        return v
    }

    private func row(title: String, shape: UIView, trailing: UIView?, action: @escaping () -> Void) -> NewRow {
        let r = NewRow()
        r.bounds = CGRect(x: 0, y: 0, width: 10, height: 74)
        r.title.text = title
        shape.frame = r.left.bounds; r.left.addSubview(shape)
        if let t = trailing { r.trailing = t; r.addSubview(t) }
        r.onClick = action
        return r
    }

    private func iconShape(_ name: String) -> UIView {
        let iv = IconView(name, Int32(bitPattern: 0xFF000000), 34)
        iv.isUserInteractionEnabled = false
        iv.frame = CGRect(x: 4, y: 4, width: 40, height: 40)
        return iv
    }

    private func sizeShape(_ w: Int, _ h: Int, dashed: Bool) -> UIView {
        let s = SizeShape(frame: CGRect(x: 0, y: 0, width: 48, height: 48))
        s.w = w; s.h = h; s.dashed = dashed
        return s
    }

    private func sizeLabel(_ w: Int, _ h: Int) -> UIView {
        let l = UILabel(); l.text = "\(w) x \(h)"; l.font = .systemFont(ofSize: 23); l.textColor = .black
        l.textAlignment = .right; l.frame = CGRect(x: 0, y: 0, width: 150, height: 46)
        return l
    }

    private func build() {
        stack.arrangedSubviews.forEach { stack.removeArrangedSubview($0); $0.removeFromSuperview() }
        func add(_ v: UIView) { stack.addArrangedSubview(v) }
        add(row(title: "Folder", shape: iconShape("folder"), trailing: nil) { [weak self] in
            self?.dismiss(animated: true) { self?.onFolder?() }
        }); add(line())
        add(row(title: "Import Picture", shape: iconShape("camera"), trailing: nil) { [weak self] in
            self?.dismiss(animated: true) { self?.onImport?() }
        }); add(line())
        add(sectionHeader("Illustration")); add(line())

        add(row(title: "Custom", shape: sizeShape(customW, customH, dashed: true),
                trailing: pill("\(customW) x \(customH)", icon: "edit", width: 230) { [weak self] in self?.editCustom() }) { [weak self] in
            guard let s = self else { return }
            s.dismiss(animated: true) { s.onCreate?(s.customW, s.customH, "Illustration") }
        }); add(line())

        for p in illustration {
            let sw = swapped.contains(p.0)
            let w = sw ? p.2 : p.1, h = sw ? p.1 : p.2
            let tr: UIView = p.3
                ? pill("\(w) x \(h)", icon: "chev_up", width: 230) { [weak self] in
                    guard let s = self else { return }
                    if s.swapped.contains(p.0) { s.swapped.remove(p.0) } else { s.swapped.insert(p.0) }
                    s.rebuildKeepScroll()
                }
                : sizeLabel(w, h)
            add(row(title: p.0, shape: sizeShape(w, h, dashed: true), trailing: tr) { [weak self] in
                self?.dismiss(animated: true) { self?.onCreate?(w, h, p.0) }
            }); add(line())
        }

        add(sectionHeader("For Printing")); add(line())
        for p in printing {
            let sw = swapped.contains(p.0)
            let w = sw ? p.2 : p.1, h = sw ? p.1 : p.2
            var tr: UIView? = nil
            if let dpi = p.3 {
                tr = pill("\(dpi)  \(w) x \(h)", icon: "chev_up", width: 290) { [weak self] in
                    guard let s = self else { return }
                    if s.swapped.contains(p.0) { s.swapped.remove(p.0) } else { s.swapped.insert(p.0) }
                    s.rebuildKeepScroll()
                }
            }
            add(row(title: p.0, shape: sizeShape(w, h, dashed: false), trailing: tr) { [weak self] in
                self?.dismiss(animated: true) { self?.onCreate?(w, h, p.0) }
            }); add(line())
        }
    }

    private func editCustom() {
        let a = UIAlertController(title: "Custom canvas", message: "Max \(DrawPresets.maxSide) px per side", preferredStyle: .alert)
        a.addTextField { $0.placeholder = "Width"; $0.text = "\(self.customW)"; $0.keyboardType = .numberPad }
        a.addTextField { $0.placeholder = "Height"; $0.text = "\(self.customH)"; $0.keyboardType = .numberPad }
        a.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        a.addAction(UIAlertAction(title: "OK", style: .default) { [weak self] _ in
            guard let s = self else { return }
            let w = Int(a.textFields?[0].text ?? "") ?? 0, h = Int(a.textFields?[1].text ?? "") ?? 0
            if DrawPresets.valid(w, h) { s.customW = w; s.customH = h; s.rebuildKeepScroll() }
            else { Toast.show("Size not supported (max \(DrawPresets.maxSide) px)") }
        })
        present(a, animated: true)
    }
}
