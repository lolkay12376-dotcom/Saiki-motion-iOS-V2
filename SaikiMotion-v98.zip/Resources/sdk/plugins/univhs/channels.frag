// uni.VHS (AUREA port) — pass 1/4: "Channel Controls".
// Each colour channel is isolated, blurred horizontally by its own radius and
// nudged sideways (red right, blue left), then the three are added back
// together. This is the classic "smeared, offset channels" look of a VHS
// deck reading degraded chroma off the tape.

const float BLUR_RATIO_R = 0.45;
const float BLUR_RATIO_G = 1.00;
const float BLUR_RATIO_B = 0.82;
const int TAPS = 9;

vec3 blurChannel(vec2 uv, float radiusPx, vec3 mask) {
    if (radiusPx < 0.25) return texture(aurea_source, uv).rgb * mask;
    vec3 sum = vec3(0.0);
    float wsum = 0.0;
    for (int i = -TAPS; i <= TAPS; i++) {
        float t = float(i) / float(TAPS);
        float w = exp(-t * t * 2.0);
        vec2 off = aurea_px_to_uv(vec2(t * radiusPx, 0.0));
        sum += texture(aurea_source, uv + off).rgb * w;
        wsum += w;
    }
    return (sum / wsum) * mask;
}

vec4 aurea_main(vec2 uv) {
    vec4 base = texture(aurea_source, uv);
    vec2 offR = aurea_px_to_uv(vec2(channelOffset, 0.0));
    vec2 offB = aurea_px_to_uv(vec2(-channelOffset, 0.0));

    vec3 r = blurChannel(uv + offR, channelBlur * BLUR_RATIO_R, vec3(1.0, 0.0, 0.0));
    vec3 g = blurChannel(uv,        channelBlur * BLUR_RATIO_G, vec3(0.0, 1.0, 0.0));
    vec3 b = blurChannel(uv + offB, channelBlur * BLUR_RATIO_B, vec3(0.0, 0.0, 1.0));

    return vec4(r + g + b, base.a);
}
