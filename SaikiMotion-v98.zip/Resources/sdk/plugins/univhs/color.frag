// uni.VHS (AUREA port) — pass 2/4: "Color Controls".
// Splits the picture into a blurred luminance and a (separately blurred)
// chroma, scales the chroma by Saturation, lifts the luma by Black Level,
// recombines them (chroma's hue/sat with the luma's brightness — like the
// original's "Color" blend mode), applies a small per-Tape-Style colour
// grade, then overlays interlace scanlines in two tints with a hard-light mix.

const int LTAPS = 6;

float lumaOf(vec3 c) { return dot(c, vec3(0.3, 0.59, 0.11)); }

float blurredLuma(vec2 uv, float radiusPx) {
    if (radiusPx < 0.25) return lumaOf(texture(aurea_source, uv).rgb);
    float sum = 0.0, wsum = 0.0;
    for (int y = -LTAPS; y <= LTAPS; y++) {
        for (int x = -LTAPS; x <= LTAPS; x++) {
            vec2 t = vec2(float(x), float(y)) / float(LTAPS);
            float w = exp(-dot(t, t) * 2.0);
            vec2 off = aurea_px_to_uv(t * radiusPx);
            sum += lumaOf(texture(aurea_source, uv + off).rgb) * w;
            wsum += w;
        }
    }
    return sum / wsum;
}

vec3 blurredChroma(vec2 uv, float radiusX, float radiusY) {
    if (radiusX < 0.25 && radiusY < 0.25) return texture(chroma, uv).rgb;
    vec3 sum = vec3(0.0);
    float wsum = 0.0;
    for (int y = -LTAPS; y <= LTAPS; y++) {
        for (int x = -LTAPS; x <= LTAPS; x++) {
            vec2 t = vec2(float(x), float(y)) / float(LTAPS);
            float w = exp(-dot(t, t) * 2.0);
            vec2 off = aurea_px_to_uv(vec2(t.x * radiusX, t.y * radiusY));
            sum += texture(chroma, uv + off).rgb * w;
            wsum += w;
        }
    }
    return sum / wsum;
}

vec3 tapeGrade(vec3 c, float style) {
    int s = int(style + 0.5);
    if (s == 0)      c = mix(c, c * vec3(1.05, 1.00, 0.92), 0.6);                       // VHS: warm
    else if (s == 1) { c = mix(c, vec3(lumaOf(c)), 0.25); c *= vec3(1.02, 1.00, 0.95); } // Bad VHS: washed
    else if (s == 2) c = mix(c, c * vec3(0.98, 1.00, 1.03), 0.5);                       // S-VHS: near-neutral, cool
    else if (s == 3) { c = mix(c, c * vec3(0.90, 0.97, 1.08), 0.7); c = pow(max(c, 0.0), vec3(1.08)); } // U-matic
    else if (s == 4) { c = mix(c, c * vec3(1.06, 0.95, 1.05), 0.6); c = max(c - 0.02, 0.0); }           // Beta
    return c;
}

vec4 aurea_main(vec2 uv) {
    vec4 ch = texture(chroma, uv);
    vec3 crm = max(ch.rgb * (saturation / 100.0), 0.0);

    float black = blackLevel / 100.0;
    float l = blurredLuma(uv, lumaBlur);
    l = pow(clamp((l - black) / max(1.0 - black, 0.0001), 0.0, 1.0), 0.8);

    vec3 crmBlurred = blurredChroma(uv, chromaBlur / 3.0, chromaBlur / 6.0);
    float lc = lumaOf(crmBlurred);
    vec3 col = max(crmBlurred + (l - lc), 0.0);

    col = tapeGrade(col, tapeStyle);

    if (interlace > 0.0) {
        float rowPx = uv.y * aurea.layer.y;
        float field = mod(floor(rowPx / 4.0), 2.0);
        vec3 c1 = vec3(0.941, 0.118, 0.490); // #F01E7D
        vec3 c2 = vec3(0.494, 1.000, 1.000); // #7EFFFF
        vec3 scan = mix(c1, c2, field);
        vec3 hl = vec3(
            col.r < 0.5 ? 2.0 * scan.r * col.r : 1.0 - (1.0 - scan.r) * (1.0 - col.r) * 2.0,
            col.g < 0.5 ? 2.0 * scan.g * col.g : 1.0 - (1.0 - scan.g) * (1.0 - col.g) * 2.0,
            col.b < 0.5 ? 2.0 * scan.b * col.b : 1.0 - (1.0 - scan.b) * (1.0 - col.b) * 2.0);
        col = mix(col, hl, clamp(interlace / 100.0, 0.0, 1.0));
    }

    return vec4(col, ch.a);
}
