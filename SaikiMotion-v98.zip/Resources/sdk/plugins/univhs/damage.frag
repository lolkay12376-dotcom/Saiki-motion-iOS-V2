// uni.VHS (AUREA port) — pass 3/4: "Tape Damage" + "Tape Wrinkle".
// Procedural grain/streak noise (hard-light blended, since real captured tape
// stock isn't available to a plugin), a noise-driven horizontal displacement,
// an occasional bright "pop line" band near the top, and an occasional
// stretched-line "wrinkle" band — each gated by its own frame-held random
// chance so they flicker in and out like real dropouts instead of every frame.

vec4 aurea_main(vec2 uv) {
    vec4 src = texture(colorPass, uv);
    vec3 col = src.rgb;
    vec2 layerPx = uv * aurea.layer.xy;
    float frame = floor(aurea.time.y);

    // --- Tape Noise: fine grain + slow horizontal streaks ---
    if (tapeNoise > 0.0) {
        float grain  = aurea_noise(layerPx * vec2(0.9, 0.55) + frame * 7.3) * 2.0 - 1.0;
        float streak = aurea_noise(vec2(layerPx.y * 0.15, frame * 3.1)) * 2.0 - 1.0;
        float noiseVal = clamp(0.5 + grain * 0.35 + streak * 0.25, 0.0, 1.0);
        float amt = clamp(tapeNoise / 100.0, 0.0, 1.0);
        vec3 hl = vec3(
            col.r < 0.5 ? 2.0 * noiseVal * col.r : 1.0 - (1.0 - noiseVal) * (1.0 - col.r) * 2.0,
            col.g < 0.5 ? 2.0 * noiseVal * col.g : 1.0 - (1.0 - noiseVal) * (1.0 - col.g) * 2.0,
            col.b < 0.5 ? 2.0 * noiseVal * col.b : 1.0 - (1.0 - noiseVal) * (1.0 - col.b) * 2.0);
        col = mix(col, hl, amt);
    }

    // --- Distortion: horizontal displacement driven by a slow noise field ---
    if (distortion > 0.0) {
        float d = (aurea_noise(vec2(layerPx.y * 0.08, frame * 1.7)) - 0.5) * distortion;
        vec2 duv = aurea_px_to_uv(vec2(d, 0.0));
        col = texture(colorPass, uv + duv).rgb;
    }

    // --- Pop Lines: a thin flickering bright band near the top ---
    if (popLines > 0.0) {
        float chance = aurea_hash(vec2(floor(frame / 24.0), 11.0));
        if (chance < popLines / 100.0) {
            float bandY = 0.12, bandH = 0.011;
            float d2 = abs(uv.y - bandY);
            if (d2 < bandH) {
                float streakX = aurea_noise(vec2(layerPx.x * 0.25, frame * 9.0));
                float v = smoothstep(0.5, 0.95, streakX) * (1.0 - d2 / bandH) * 0.5;
                col = 1.0 - (1.0 - vec3(v)) * (1.0 - col);
            }
        }
    }

    // --- Tape Wrinkle: an occasional rolling band showing one stretched source line ---
    if (wrinkleAmount > 0.0) {
        float chance2 = aurea_hash(vec2(floor(frame / 30.0), 47.0));
        if (chance2 < wrinkleAmount / 100.0) {
            float radius = 0.02 + 0.08 * (wrinkleAmount / 100.0);
            float center = fract(aurea_hash(vec2(floor(frame / 30.0), 5.0)) + aurea.time.x * 0.05);
            float d3 = abs(uv.y - center);
            if (d3 < radius) {
                float srcY = fract(center + aurea.time.x * 0.3);
                col = texture(colorPass, vec2(uv.x, srcY)).rgb;
            }
        }
    }

    return vec4(col, src.a);
}
