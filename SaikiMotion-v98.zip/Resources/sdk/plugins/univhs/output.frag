// uni.VHS (AUREA port) — pass 4/4: output.
// Frame Jitter (a small random vertical bob, held for a couple of frames like
// a tracking dropout), the Frame Style 4x3 pillarbox crop (shiftable with
// Image Offset), and Blend with Original.

vec4 aurea_main(vec2 uv) {
    vec2 layerPx = aurea.layer.xy;
    float frame = floor(aurea.time.y);

    vec2 jitterUV = uv;
    if (frameJitter > 0.0) {
        float j = (aurea_hash(vec2(floor(frame / 2.0), 3.0)) - 0.5) * 2.0 * frameJitter;
        jitterUV = clamp(uv + aurea_px_to_uv(vec2(0.0, j)), vec2(0.0), vec2(1.0));
    }
    vec4 col = texture(damagePass, jitterUV);

    if (frameStyle > 0.5) {
        float targetAspect = 4.0 / 3.0;
        float curAspect = layerPx.x / max(layerPx.y, 1.0);
        if (curAspect > targetAspect) {
            float boxW = layerPx.y * targetAspect;
            float marginPx = (layerPx.x - boxW) * 0.5 - imageOffset;
            float x0 = marginPx / layerPx.x;
            float x1 = 1.0 - (layerPx.x - boxW - marginPx) / layerPx.x;
            if (uv.x < x0 || uv.x > x1) col = vec4(0.0);
        }
    }

    if (blend > 0.0) {
        vec4 orig = texture(aurea_source, uv);
        col = mix(col, orig, clamp(blend / 100.0, 0.0, 1.0));
    }

    return col;
}
