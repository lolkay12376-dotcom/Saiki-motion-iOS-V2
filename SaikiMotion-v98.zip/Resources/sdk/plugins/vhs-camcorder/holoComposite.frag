// VHS Camcorder — pass 8 (final): Holomatrix tint/scan/grid/noise/glow/flicker
// (skipped cheaply when holoOn is off), then aspect ratio / black bars / corner rounding.
#define H(u) texture(holoA, clamp((u), 0.0, 1.0))

void auHoloPreset(int pr, out float tintAmount, out float holoScanlines, out float holoScanSpeed, out float gridAmount, out float gridScale, out float glitchAmount, out float glitchFreq, out float rgbSplit, out float noiseAmount, out float edgeGlow, out float flicker, out float flickerSpeed, out float vignette) {
    if (pr == 0) {
        tintAmount = 0.25;
        holoScanlines = 0.1;
        holoScanSpeed = 0.6;
        gridAmount = 0.05;
        gridScale = 40.0;
        glitchAmount = 0.02;
        glitchFreq = 0.02;
        rgbSplit = 1.0;
        noiseAmount = 0.05;
        edgeGlow = 0.1;
        flicker = 0.03;
        flickerSpeed = 2.5;
        vignette = 0.15;
    }
    else if (pr == 1) {
        tintAmount = 0.55;
        holoScanlines = 0.3;
        holoScanSpeed = 0.6;
        gridAmount = 0.18;
        gridScale = 40.0;
        glitchAmount = 0.25;
        glitchFreq = 0.12;
        rgbSplit = 4.0;
        noiseAmount = 0.25;
        edgeGlow = 0.4;
        flicker = 0.15;
        flickerSpeed = 2.5;
        vignette = 0.35;
    }
    else if (pr == 2) {
        tintAmount = 0.5;
        holoScanlines = 0.4;
        holoScanSpeed = 0.6;
        gridAmount = 0.12;
        gridScale = 40.0;
        glitchAmount = 0.5;
        glitchFreq = 0.3;
        rgbSplit = 8.0;
        noiseAmount = 0.4;
        edgeGlow = 0.5;
        flicker = 0.3;
        flickerSpeed = 2.5;
        vignette = 0.45;
    }
    else if (pr == 3) {
        tintAmount = 0.2;
        holoScanlines = 0.15;
        holoScanSpeed = 0.6;
        gridAmount = 0.08;
        gridScale = 40.0;
        glitchAmount = 0.02;
        glitchFreq = 0.02;
        rgbSplit = 1.0;
        noiseAmount = 0.08;
        edgeGlow = 0.15;
        flicker = 0.04;
        flickerSpeed = 2.5;
        vignette = 0.2;
    }
    else if (pr == 4) {
        tintAmount = 0.65;
        holoScanlines = 0.6;
        holoScanSpeed = 0.6;
        gridAmount = 0.2;
        gridScale = 40.0;
        glitchAmount = 1.0;
        glitchFreq = 0.7;
        rgbSplit = 22.0;
        noiseAmount = 0.75;
        edgeGlow = 0.75;
        flicker = 0.55;
        flickerSpeed = 2.5;
        vignette = 0.5;
    }
    else if (pr == 5) {
        tintAmount = 0.4;
        holoScanlines = 0.7;
        holoScanSpeed = 0.6;
        gridAmount = 0.55;
        gridScale = 40.0;
        glitchAmount = 0.0;
        glitchFreq = 0.0;
        rgbSplit = 1.0;
        noiseAmount = 0.05;
        edgeGlow = 0.2;
        flicker = 0.08;
        flickerSpeed = 2.5;
        vignette = 0.3;
    }
    else if (pr == 6) {
        tintAmount = 0.15;
        holoScanlines = 0.2;
        holoScanSpeed = 0.6;
        gridAmount = 0.05;
        gridScale = 40.0;
        glitchAmount = 0.08;
        glitchFreq = 0.06;
        rgbSplit = 1.0;
        noiseAmount = 0.35;
        edgeGlow = 0.15;
        flicker = 0.1;
        flickerSpeed = 2.5;
        vignette = 0.65;
    }
    else if (pr == 7) {
        tintAmount = 0.5;
        holoScanlines = 0.5;
        holoScanSpeed = 0.6;
        gridAmount = 0.1;
        gridScale = 40.0;
        glitchAmount = 0.55;
        glitchFreq = 0.4;
        rgbSplit = 16.0;
        noiseAmount = 0.5;
        edgeGlow = 0.5;
        flicker = 0.35;
        flickerSpeed = 2.5;
        vignette = 0.4;
    }
    else if (pr == 8) {
        tintAmount = 0.1;
        holoScanlines = 0.1;
        holoScanSpeed = 0.6;
        gridAmount = 0.03;
        gridScale = 40.0;
        glitchAmount = 0.0;
        glitchFreq = 0.0;
        rgbSplit = 0.3;
        noiseAmount = 0.03;
        edgeGlow = 0.08;
        flicker = 0.02;
        flickerSpeed = 2.5;
        vignette = 0.1;
    }
    else if (pr == 9) {
        tintAmount = 0.3;
        holoScanlines = 0.75;
        holoScanSpeed = 0.6;
        gridAmount = 0.15;
        gridScale = 40.0;
        glitchAmount = 0.5;
        glitchFreq = 0.3;
        rgbSplit = 18.0;
        noiseAmount = 0.4;
        edgeGlow = 0.35;
        flicker = 0.25;
        flickerSpeed = 2.5;
        vignette = 0.35;
    }
    else if (pr == 10) {
        tintAmount = 0.75;
        holoScanlines = 0.5;
        holoScanSpeed = 0.6;
        gridAmount = 0.08;
        gridScale = 40.0;
        glitchAmount = 0.45;
        glitchFreq = 0.35;
        rgbSplit = 10.0;
        noiseAmount = 0.95;
        edgeGlow = 0.3;
        flicker = 0.6;
        flickerSpeed = 2.5;
        vignette = 0.6;
    }
    else if (pr == 11) {
        tintAmount = 0.15;
        holoScanlines = 0.25;
        holoScanSpeed = 0.6;
        gridAmount = 0.03;
        gridScale = 40.0;
        glitchAmount = 0.15;
        glitchFreq = 0.15;
        rgbSplit = 5.0;
        noiseAmount = 1.0;
        edgeGlow = 0.15;
        flicker = 0.75;
        flickerSpeed = 2.5;
        vignette = 0.7;
    }
    else {
        tintAmount = 0.55;
        holoScanlines = 0.3;
        holoScanSpeed = 0.6;
        gridAmount = 0.18;
        gridScale = 40.0;
        glitchAmount = 0.25;
        glitchFreq = 0.12;
        rgbSplit = 4.0;
        noiseAmount = 0.25;
        edgeGlow = 0.4;
        flicker = 0.15;
        flickerSpeed = 2.5;
        vignette = 0.35;
    }
}

void aurea_holoVals(out float _tintAmount, out float _holoScanlines, out float _holoScanSpeed, out float _gridAmount,
                     out float _gridScale, out float _glitchAmount, out float _glitchFreq, out float _rgbSplit,
                     out float _noiseAmount, out float _edgeGlow, out float _flicker, out float _flickerSpeed, out float _vignette) {
    auHoloPreset(int(preset + 0.5), _tintAmount, _holoScanlines, _holoScanSpeed, _gridAmount, _gridScale, _glitchAmount,
                 _glitchFreq, _rgbSplit, _noiseAmount, _edgeGlow, _flicker, _flickerSpeed, _vignette);
    _tintAmount = clamp(_tintAmount * intensity, 0.0, 1.0);
    _holoScanlines = clamp(_holoScanlines * intensity, 0.0, 1.0);
    _gridAmount = clamp(_gridAmount * intensity, 0.0, 1.0);
    _glitchAmount = clamp(_glitchAmount * intensity, 0.0, 1.0);
    _glitchFreq = clamp(_glitchFreq * intensity, 0.0, 1.0);
    _rgbSplit = clamp(_rgbSplit * intensity, 0.0, 40.0);
    _noiseAmount = clamp(_noiseAmount * intensity, 0.0, 1.0);
    _edgeGlow = clamp(_edgeGlow * intensity, 0.0, 1.2);
    _flicker = clamp(_flicker * intensity, 0.0, 1.0);
    _vignette = clamp(_vignette * intensity, 0.0, 1.0);
}
const float holoMix = 1.0;


float aurea_h1(float a, float b) { return aurea_hash(vec2(a, b)); }

vec4 aurea_frame(vec4 c, vec2 uv) {
    int am = int(aspect + 0.5);
    if (am == 0) return c;
    vec2 L = aurea.layer.xy;
    float targetAR = (am == 1) ? (4.0/3.0) : (am == 2) ? (3.0/4.0) : (am == 3) ? 1.0 : (am == 4) ? (16.0/9.0) : (9.0/16.0);
    float curAR = L.x / max(L.y, 1.0);
    vec2 rectHalf;
    if (curAR > targetAR) {
        rectHalf = vec2(L.y * targetAR, L.y) * 0.5;
    } else {
        rectHalf = vec2(L.x, L.x / targetAR) * 0.5;
    }
    float cr = max(cornerRound, 0.0);
    vec2 p = aurea_layer_uv(uv) * L - L * 0.5;
    vec2 d = abs(p) - rectHalf + vec2(cr);
    float dist = length(max(d, 0.0)) + min(max(d.x, d.y), 0.0) - cr;
    float inside = 1.0 - smoothstep(-1.0, 1.0, dist);
    vec4 outColor = (blackBars > 0.5) ? vec4(0.0, 0.0, 0.0, 1.0) : vec4(0.0);
    return mix(outColor, c, inside);
}

vec4 aurea_main(vec2 uv) {
    vec4 orig = texture(postOut, uv);
    vec4 result;
    if (holoOn < 0.5) {
        result = orig;
    } else {
    float _tintAmount, _holoScanlines, _holoScanSpeed, _gridAmount, _gridScale, _glitchAmount, _glitchFreq, _rgbSplit, _noiseAmount, _edgeGlow, _flicker, _flickerSpeed, _vignette;
    aurea_holoVals(_tintAmount, _holoScanlines, _holoScanSpeed, _gridAmount, _gridScale, _glitchAmount, _glitchFreq, _rgbSplit, _noiseAmount, _edgeGlow, _flicker, _flickerSpeed, _vignette);

        float sc = length(aurea.layer.xy) / 2203.0;
        vec2 L = aurea.layer.xy;
        vec2 p = aurea_layer_uv(uv) * L;
        vec2 vp = aurea_layer_uv(uv);
        float fr = floor(aurea.time.y + 0.5) + seed * 29.0;
        float t = aurea.time.x;

        vec4 s = H(uv);
        vec4 un = aurea_unpremultiply(s);
        vec3 g = aurea_linear_to_srgb(clamp(un.rgb, 0.0, 1.0));
        float lum = dot(g, vec3(0.299, 0.587, 0.114));

        vec3 tintC = aurea_linear_to_srgb(clamp(tint.rgb, 0.0, 1.0));
        vec3 toned = mix(vec3(lum), tintC, 0.65) * (0.35 + 0.9 * lum);
        g = mix(g, toned, _tintAmount);

        float period = max(L.y / 180.0, 2.0);
        float scanPh = p.y / period - t * _holoScanSpeed;
        float sl = 0.5 - 0.5 * cos(6.2831853 * scanPh);
        g *= (1.0 - _holoScanlines * 0.6 * sl);

        float gscale = max(_gridScale * sc, 4.0);
        vec2 gp = p / gscale;
        float glx = smoothstep(0.9, 1.0, 1.0 - abs(fract(gp.x) - 0.5) * 2.0);
        float gly = smoothstep(0.9, 1.0, 1.0 - abs(fract(gp.y) - 0.5) * 2.0);
        float gridLine = max(glx, gly);
        g += tintC * gridLine * _gridAmount * 0.3;

        vec2 cell = floor(p / max(1.5 * sc, 1.0));
        float ns = aurea_hash(cell + vec2(fr * 3.1, fr * 7.3));
        g += (ns - 0.5) * _noiseAmount * 0.5;
        g += smoothstep(0.985, 1.0, ns) * _noiseAmount * 0.9 * tintC;

        vec2 dpx = aurea_px_to_uv(vec2(2.0 * sc, 0.0));
        vec2 dpy = aurea_px_to_uv(vec2(0.0, 2.0 * sc));
        float aL = aurea_unpremultiply(H(uv - dpx)).a;
        float aR = aurea_unpremultiply(H(uv + dpx)).a;
        float aT = aurea_unpremultiply(H(uv - dpy)).a;
        float aB = aurea_unpremultiply(H(uv + dpy)).a;
        float glow = clamp(abs(aL - aR) + abs(aT - aB), 0.0, 1.0);
        g += tintC * glow * _edgeGlow;

        float dip = step(0.5, aurea_hash(vec2(fr, 9.1)));
        float fk = 1.0 - _flicker * 0.5 * dip
                 * (0.5 + 0.5 * sin(t * _flickerSpeed * 6.2831853 + aurea_h1(float(seed), 2.0) * 6.2831853));
        g *= clamp(fk, 0.0, 1.0);

        float vig = 1.0 - _vignette * smoothstep(0.25, 0.85, length(vp - 0.5));
        g *= vig;

        g = clamp(g, 0.0, 1.0);
        vec3 lin = aurea_srgb_to_linear(g);
        float al = un.a;
        vec4 res = vec4(lin * al, al);
        result = mix(orig, res, clamp(holoMix, 0.0, 1.0));
    }

    return aurea_frame(result, uv);
}
