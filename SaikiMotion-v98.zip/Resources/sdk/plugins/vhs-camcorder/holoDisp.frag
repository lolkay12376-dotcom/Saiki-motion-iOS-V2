// VHS Camcorder — pass 7: Holomatrix glitch-block displacement + RGB split.
#define SRC(u) texture(postOut, clamp((u), 0.0, 1.0))

void auHoloPreset(int pr, out float tintAmount, out float holoScanlines, out float holoScanSpeed, out float gridAmount, out float gridScale, out float glitchAmount, out float glitchFreq, out float rgbSplit, out float noiseAmount, out float edgeGlow, out float flicker, out float flickerSpeed, out float vignette) {
    if (pr == 0) {
        tintAmount = 0.25;
        holoScanlines = 0.1;
        holoScanSpeed = 0.6;
        gridAmount = 0.05;
        gridScale = 40.0;
        glitchAmount = 0.02;
        glitchFreq = 0.02;
        rgbSplit = 1.0;
        noiseAmount = 0.05;
        edgeGlow = 0.1;
        flicker = 0.03;
        flickerSpeed = 2.5;
        vignette = 0.15;
    }
    else if (pr == 1) {
        tintAmount = 0.55;
        holoScanlines = 0.3;
        holoScanSpeed = 0.6;
        gridAmount = 0.18;
        gridScale = 40.0;
        glitchAmount = 0.25;
        glitchFreq = 0.12;
        rgbSplit = 4.0;
        noiseAmount = 0.25;
        edgeGlow = 0.4;
        flicker = 0.15;
        flickerSpeed = 2.5;
        vignette = 0.35;
    }
    else if (pr == 2) {
        tintAmount = 0.5;
        holoScanlines = 0.4;
        holoScanSpeed = 0.6;
        gridAmount = 0.12;
        gridScale = 40.0;
        glitchAmount = 0.5;
        glitchFreq = 0.3;
        rgbSplit = 8.0;
        noiseAmount = 0.4;
        edgeGlow = 0.5;
        flicker = 0.3;
        flickerSpeed = 2.5;
        vignette = 0.45;
    }
    else if (pr == 3) {
        tintAmount = 0.2;
        holoScanlines = 0.15;
        holoScanSpeed = 0.6;
        gridAmount = 0.08;
        gridScale = 40.0;
        glitchAmount = 0.02;
        glitchFreq = 0.02;
        rgbSplit = 1.0;
        noiseAmount = 0.08;
        edgeGlow = 0.15;
        flicker = 0.04;
        flickerSpeed = 2.5;
        vignette = 0.2;
    }
    else if (pr == 4) {
        tintAmount = 0.65;
        holoScanlines = 0.6;
        holoScanSpeed = 0.6;
        gridAmount = 0.2;
        gridScale = 40.0;
        glitchAmount = 1.0;
        glitchFreq = 0.7;
        rgbSplit = 22.0;
        noiseAmount = 0.75;
        edgeGlow = 0.75;
        flicker = 0.55;
        flickerSpeed = 2.5;
        vignette = 0.5;
    }
    else if (pr == 5) {
        tintAmount = 0.4;
        holoScanlines = 0.7;
        holoScanSpeed = 0.6;
        gridAmount = 0.55;
        gridScale = 40.0;
        glitchAmount = 0.0;
        glitchFreq = 0.0;
        rgbSplit = 1.0;
        noiseAmount = 0.05;
        edgeGlow = 0.2;
        flicker = 0.08;
        flickerSpeed = 2.5;
        vignette = 0.3;
    }
    else if (pr == 6) {
        tintAmount = 0.15;
        holoScanlines = 0.2;
        holoScanSpeed = 0.6;
        gridAmount = 0.05;
        gridScale = 40.0;
        glitchAmount = 0.08;
        glitchFreq = 0.06;
        rgbSplit = 1.0;
        noiseAmount = 0.35;
        edgeGlow = 0.15;
        flicker = 0.1;
        flickerSpeed = 2.5;
        vignette = 0.65;
    }
    else if (pr == 7) {
        tintAmount = 0.5;
        holoScanlines = 0.5;
        holoScanSpeed = 0.6;
        gridAmount = 0.1;
        gridScale = 40.0;
        glitchAmount = 0.55;
        glitchFreq = 0.4;
        rgbSplit = 16.0;
        noiseAmount = 0.5;
        edgeGlow = 0.5;
        flicker = 0.35;
        flickerSpeed = 2.5;
        vignette = 0.4;
    }
    else if (pr == 8) {
        tintAmount = 0.1;
        holoScanlines = 0.1;
        holoScanSpeed = 0.6;
        gridAmount = 0.03;
        gridScale = 40.0;
        glitchAmount = 0.0;
        glitchFreq = 0.0;
        rgbSplit = 0.3;
        noiseAmount = 0.03;
        edgeGlow = 0.08;
        flicker = 0.02;
        flickerSpeed = 2.5;
        vignette = 0.1;
    }
    else if (pr == 9) {
        tintAmount = 0.3;
        holoScanlines = 0.75;
        holoScanSpeed = 0.6;
        gridAmount = 0.15;
        gridScale = 40.0;
        glitchAmount = 0.5;
        glitchFreq = 0.3;
        rgbSplit = 18.0;
        noiseAmount = 0.4;
        edgeGlow = 0.35;
        flicker = 0.25;
        flickerSpeed = 2.5;
        vignette = 0.35;
    }
    else if (pr == 10) {
        tintAmount = 0.75;
        holoScanlines = 0.5;
        holoScanSpeed = 0.6;
        gridAmount = 0.08;
        gridScale = 40.0;
        glitchAmount = 0.45;
        glitchFreq = 0.35;
        rgbSplit = 10.0;
        noiseAmount = 0.95;
        edgeGlow = 0.3;
        flicker = 0.6;
        flickerSpeed = 2.5;
        vignette = 0.6;
    }
    else if (pr == 11) {
        tintAmount = 0.15;
        holoScanlines = 0.25;
        holoScanSpeed = 0.6;
        gridAmount = 0.03;
        gridScale = 40.0;
        glitchAmount = 0.15;
        glitchFreq = 0.15;
        rgbSplit = 5.0;
        noiseAmount = 1.0;
        edgeGlow = 0.15;
        flicker = 0.75;
        flickerSpeed = 2.5;
        vignette = 0.7;
    }
    else {
        tintAmount = 0.55;
        holoScanlines = 0.3;
        holoScanSpeed = 0.6;
        gridAmount = 0.18;
        gridScale = 40.0;
        glitchAmount = 0.25;
        glitchFreq = 0.12;
        rgbSplit = 4.0;
        noiseAmount = 0.25;
        edgeGlow = 0.4;
        flicker = 0.15;
        flickerSpeed = 2.5;
        vignette = 0.35;
    }
}

void aurea_holoVals(out float _tintAmount, out float _holoScanlines, out float _holoScanSpeed, out float _gridAmount,
                     out float _gridScale, out float _glitchAmount, out float _glitchFreq, out float _rgbSplit,
                     out float _noiseAmount, out float _edgeGlow, out float _flicker, out float _flickerSpeed, out float _vignette) {
    auHoloPreset(int(preset + 0.5), _tintAmount, _holoScanlines, _holoScanSpeed, _gridAmount, _gridScale, _glitchAmount,
                 _glitchFreq, _rgbSplit, _noiseAmount, _edgeGlow, _flicker, _flickerSpeed, _vignette);
    _tintAmount = clamp(_tintAmount * intensity, 0.0, 1.0);
    _holoScanlines = clamp(_holoScanlines * intensity, 0.0, 1.0);
    _gridAmount = clamp(_gridAmount * intensity, 0.0, 1.0);
    _glitchAmount = clamp(_glitchAmount * intensity, 0.0, 1.0);
    _glitchFreq = clamp(_glitchFreq * intensity, 0.0, 1.0);
    _rgbSplit = clamp(_rgbSplit * intensity, 0.0, 40.0);
    _noiseAmount = clamp(_noiseAmount * intensity, 0.0, 1.0);
    _edgeGlow = clamp(_edgeGlow * intensity, 0.0, 1.2);
    _flicker = clamp(_flicker * intensity, 0.0, 1.0);
    _vignette = clamp(_vignette * intensity, 0.0, 1.0);
}
const float holoMix = 1.0;


float aurea_h1(float a, float b) { return aurea_hash(vec2(a, b)); }

vec4 aurea_main(vec2 uv) {
    if (holoOn < 0.5) return texture(postOut, clamp(uv, 0.0, 1.0));
    float _tintAmount, _holoScanlines, _holoScanSpeed, _gridAmount, _gridScale, _glitchAmount, _glitchFreq, _rgbSplit, _noiseAmount, _edgeGlow, _flicker, _flickerSpeed, _vignette;
    aurea_holoVals(_tintAmount, _holoScanlines, _holoScanSpeed, _gridAmount, _gridScale, _glitchAmount, _glitchFreq, _rgbSplit, _noiseAmount, _edgeGlow, _flicker, _flickerSpeed, _vignette);

    float sc = length(aurea.layer.xy) / 2203.0;
    vec2 L = aurea.layer.xy;
    vec2 p = aurea_layer_uv(uv) * L;
    float fr = floor(aurea.time.y + 0.5) + seed * 13.0;

    float bandH = max(L.y / 24.0, 4.0);
    float bi = floor(p.y / bandH);
    float bOn = step(1.0 - clamp(_glitchFreq, 0.0, 1.0), aurea_h1(bi, fr));
    float bShift = (aurea_h1(bi, fr + 3.7) - 0.5) * 2.0 * _glitchAmount * 60.0 * sc * bOn;

    float tearOn = step(0.6, aurea_h1(bi, fr + 9.1)) * bOn;
    float tear = (aurea_h1(bi, fr + 21.0) - 0.5) * 2.0 * _glitchAmount * 140.0 * sc * tearOn
               * step(0.5, aurea_h1(floor(p.y / max(bandH * 0.2, 1.0)), fr + 44.0));

    vec2 base = uv - aurea_px_to_uv(vec2(bShift + tear, 0.0));

    vec2 rs = aurea_px_to_uv(vec2(max(_rgbSplit, 0.0) * sc, 0.0));
    vec4 cr = SRC(base - rs);
    vec4 cg = SRC(base);
    vec4 cb = SRC(base + rs);

    float al = cg.a;
    vec3 rgb = vec3(aurea_unpremultiply(cr).r, aurea_unpremultiply(cg).g, aurea_unpremultiply(cb).b);
    return vec4(clamp(rgb, 0.0, 1.0) * al, al);
}
