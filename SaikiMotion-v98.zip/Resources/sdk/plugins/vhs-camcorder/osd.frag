// VHS Camcorder — pass 5: retro on-screen display (content, timecode, tape speed)
// + optional camcorder-viewfinder corner brackets. Builds on "tapeOut".
// 5x7 pixel font (extends the original VHS OSD font with D/G/H/M for AUTO DATE / NIGHTSHOT / MENU / END OF TAPE).
const int GLYPH_LO[36] = int[36](0, 714286, 135364, 279086, 266527, 305544, 539711, 492620, 139807, 476718, 1001006, 4224, 498785, 1012496, 1048544, 1048000, 1033774, 509487, 34350, 492607, 492607, 135310, 33825, 708209, 575022, 509487, 509487, 459838, 135327, 575025, 706097, 141873, 575023, 951854, 1033777, 579441);
const int GLYPH_HI[36] = int[36](0, 14899, 14468, 31812, 14896, 8479, 14896, 14897, 2114, 14897, 6416, 132, 1127, 17180, 1023, 479, 17969, 15921, 14881, 31777, 1057, 14468, 31777, 18233, 14897, 1057, 17701, 15888, 4228, 14897, 18293, 4228, 15921, 14897, 17969, 17969);
const int CT_CH[300] = int[300](0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 0, 25, 22, 16, 31, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 0, 27, 28, 24, 25, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 15, 0, 26, 19, 18, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 13, 13, 0, 26, 19, 30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 12, 0, 20, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 0, 25, 16, 29, 27, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16, 29, 28, 24, 0, 18, 16, 22, 21, 17, 26, 16, 28, 21, 24, 23, 0, 0, 0, 0, 16, 29, 28, 24, 0, 32, 16, 28, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23, 21, 33, 34, 28, 27, 34, 24, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 24, 18, 29, 27, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 28, 17, 18, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 18, 24, 23, 28, 26, 16, 27, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35, 19, 23, 29, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19, 23, 32, 0, 24, 20, 0, 28, 16, 25, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0);
const int ROW_W = 20;
const int CT_LEN[15] = int[15](0, 6, 6, 5, 6, 5, 7, 16, 9, 9, 5, 3, 8, 4, 11);
const int CT_ICON[15] = int[15](0, 2, 2, 2, 3, 3, 2, 0, 0, 0, 0, 0, 0, 0, 0);
const int SPD_CH[9] = int[9](27, 25, 0, 22, 25, 0, 27, 22, 25);
const int SPD_LEN[3] = int[3](2, 2, 3);

const bool showIcon = true;
const float blinkRate = 1.0;
const vec2 statusPos = vec2(0.07, 0.1);
const float timeOffset = 0.0;
const vec2 timePos = vec2(0.07, 0.88);
const vec2 speedPos = vec2(0.8, 0.1);
const float wobble = 0.5;

int TC_V[4];

int aurea_gbit(int gi, int gx, int gy) {
    int bits = (gy < 4) ? (GLYPH_LO[gi] >> (gy * 5 + gx)) : (GLYPH_HI[gi] >> ((gy - 4) * 5 + gx));
    return bits & 1;
}

int aurea_char(int kind, int idx) {
    if (kind == 0) {
        int ct = int(content + 0.5);
        return CT_CH[ct * ROW_W + idx];
    }
    if (kind == 1) {
        int tf = int(timeFormat + 0.5);
        int first = (tf == 1) ? 1 : 0;
        int fi = first + idx / 3;
        int wi = idx - (idx / 3) * 3;
        if (wi == 2) return 11;
        int v = TC_V[fi];
        int tens = v / 10;
        return ((wi == 0) ? tens : (v - tens * 10)) + 1;
    }
    int sp = int(speedMode + 0.5) - 1;
    return SPD_CH[sp * 3 + idx];
}

int aurea_textbit(int kind, int n, int skip, int cx, int cy) {
    if (cy < 0 || cy > 6 || cx < 0) return 0;
    int ci = cx / 6;
    int gx = cx - ci * 6;
    if (ci >= n || gx > 4) return 0;
    return aurea_gbit(aurea_char(kind, ci + skip), gx, cy);
}

vec4 aurea_main(vec2 uv) {
    vec4 src = texture(tapeOut, uv);
    vec2 L = aurea.layer.xy;
    vec2 p = aurea_layer_uv(uv) * L;
    int ct0 = int(content + 0.5);
    bool osdOn = (ct0 != 0);

    if (!osdOn && viewfinder < 0.5) return src;

    float ps = max(min(L.x, L.y) * 0.0065 * osdSize, 1.0);

    float tt = max(aurea.time.x + timeOffset, 0.0);
    TC_V[0] = int(mod(floor(tt / 3600.0), 100.0));
    TC_V[1] = int(mod(floor(tt / 60.0), 60.0));
    TC_V[2] = int(mod(floor(tt), 60.0));
    TC_V[3] = int(mod(floor(fract(tt) * aurea.time.z + 0.001), 100.0));

    float wob = (aurea_hash(vec2(floor(p.y / ps), floor(aurea.time.y))) - 0.5) * wobble * ps;
    int tf = int(timeFormat + 0.5);
    int ct = int(content + 0.5);
    int sm = int(speedMode + 0.5);

    float cover = 0.0;
    float halo = 0.0;
    if (osdOn) {
        for (int k = 0; k < 3; k++) {
            int n = 0;
            int skip = 0;
            vec2 org = vec2(0.0);
            float vis = 1.0;
            if (k == 0) {
                skip = (showIcon) ? 0 : CT_ICON[ct];
                n = (ct == 0) ? 0 : (CT_LEN[ct] - skip);
                org = aurea_layer_uv(statusPos) * L;
                if (blink > 0.5) vis = step(0.5, fract(aurea.time.x * blinkRate));
            } else if (k == 1) {
                n = (tf == 0) ? 0 : (3 * (tf + 1) - 1);
                org = aurea_layer_uv(timePos) * L;
            } else {
                n = (sm == 0) ? 0 : SPD_LEN[sm - 1];
                org = aurea_layer_uv(speedPos) * L;
            }
            if (n <= 0) continue;
            vec2 lp = (vec2(p.x + wob, p.y) - org) / ps;
            if (lp.x < -1.5 || lp.y < -1.5 || lp.x > float(n * 6) + 0.5 || lp.y > 8.5) continue;
            int cx = int(floor(lp.x));
            int cy = int(floor(lp.y));
            float v = float(aurea_textbit(k, n, skip, cx, cy));
            float ring = 0.0;
            for (int dy = -1; dy <= 1; dy++) {
                for (int dx = -1; dx <= 1; dx++) {
                    ring = max(ring, float(aurea_textbit(k, n, skip, cx + dx, cy + dy)));
                }
            }
            cover = max(cover, v * vis);
            halo = max(halo, ring * vis);
        }
    }

    float cv = max(cover, halo) * osdMix * osdColor.a;
    vec3 col = osdColor.rgb * cover;
    vec4 ov = vec4(col * osdMix * osdColor.a, cv);
    vec4 result = ov + src * (1.0 - cv);

    if (viewfinder > 0.5) {
        float bw = max(min(L.x, L.y) * 0.035 * osdSize, 2.0);
        float bt = max(bw * 0.12, 1.0);
        float m = max(min(L.x, L.y) * 0.045, 4.0);
        float vf = 0.0;
        for (int k2 = 0; k2 < 4; k2++) {
            float sx = (k2 == 1 || k2 == 3) ? -1.0 : 1.0;
            float sy = (k2 == 2 || k2 == 3) ? -1.0 : 1.0;
            vec2 c = vec2(sx > 0.0 ? m : L.x - m, sy > 0.0 ? m : L.y - m);
            vec2 rp = p - c;
            float armH = step(0.0, sx * rp.x) * step(abs(sx * rp.x), bw) * step(abs(rp.y), bt);
            float armV = step(0.0, sy * rp.y) * step(abs(sy * rp.y), bw) * step(abs(rp.x), bt);
            vf = max(vf, max(armH, armV));
        }
        float vfA = vf * osdMix * osdColor.a;
        result = vec4(osdColor.rgb * vfA + result.rgb * (1.0 - vfA), result.a + vfA * (1.0 - result.a));
    }

    return result;
}
