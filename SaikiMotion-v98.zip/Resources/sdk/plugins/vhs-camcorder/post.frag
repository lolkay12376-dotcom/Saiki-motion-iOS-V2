// VHS Camcorder — pass 6: softness, fine grain, scanlines, dry/wet mix.
// Builds on "osdOut" (colour + tape + the on-screen display already composited).
void auPostPreset(int pr, out float grainAmount, out float scanlines, out float softness) {
    if (pr == 0) {
        grainAmount = 0.08;
        scanlines = 0.08;
        softness = 0.4;
    }
    else if (pr == 1) {
        grainAmount = 0.25;
        scanlines = 0.15;
        softness = 0.8;
    }
    else if (pr == 2) {
        grainAmount = 0.5;
        scanlines = 0.3;
        softness = 1.2;
    }
    else if (pr == 3) {
        grainAmount = 0.1;
        scanlines = 0.18;
        softness = 0.2;
    }
    else if (pr == 4) {
        grainAmount = 0.7;
        scanlines = 0.4;
        softness = 1.8;
    }
    else if (pr == 5) {
        grainAmount = 0.08;
        scanlines = 0.85;
        softness = 0.15;
    }
    else if (pr == 6) {
        grainAmount = 0.75;
        scanlines = 0.25;
        softness = 1.3;
    }
    else if (pr == 7) {
        grainAmount = 0.35;
        scanlines = 0.3;
        softness = 0.9;
    }
    else if (pr == 8) {
        grainAmount = 0.04;
        scanlines = 0.2;
        softness = 0.1;
    }
    else if (pr == 9) {
        grainAmount = 0.45;
        scanlines = 0.75;
        softness = 1.5;
    }
    else if (pr == 10) {
        grainAmount = 0.95;
        scanlines = 0.4;
        softness = 2.2;
    }
    else if (pr == 11) {
        grainAmount = 1.0;
        scanlines = 0.2;
        softness = 3.5;
    }
    else {
        grainAmount = 0.25;
        scanlines = 0.15;
        softness = 0.8;
    }
}

void aurea_postVals(out float _grainAmount, out float _scanlines, out float _softness) {
    auPostPreset(int(preset + 0.5), _grainAmount, _scanlines, _softness);
    _grainAmount = clamp(_grainAmount * intensity, 0.0, 1.0);
    _scanlines = clamp(_scanlines * intensity, 0.0, 1.0);
    _softness = clamp(_softness * intensity, 0.0, 6.0);
}
const float grainSize = 1.5;
const float grainChroma = 0.3;
const float postMix = 1.0;


vec4 aurea_main(vec2 uv) {
    float _grainAmount, _scanlines, _softness;
    aurea_postVals(_grainAmount, _scanlines, _softness);

    float sc = length(aurea.layer.xy) / 2203.0;
    vec2 L = aurea.layer.xy;
    vec2 p = aurea_layer_uv(uv) * L;
    vec4 orig = texture(osdOut, uv);

    vec2 dd = aurea_px_to_uv(vec2(_softness * sc, 0.0));
    vec4 s = texture(osdOut, clamp(uv - dd, 0.0, 1.0)) * 0.25
           + orig * 0.5
           + texture(osdOut, clamp(uv + dd, 0.0, 1.0)) * 0.25;

    vec4 un = aurea_unpremultiply(s);
    vec3 base = un.rgb;
    float al = s.a;
    vec3 g = aurea_linear_to_srgb(clamp(base, 0.0, 1.0));
    float lum = dot(g, vec3(0.299, 0.587, 0.114));

    float fr = floor(aurea.time.y + 0.5) + seed * 31.0;
    vec2 cell = floor(p / max(grainSize * sc, 1.0));
    float gl = aurea_hash(cell + vec2(fr * 13.1, fr * 7.7)) - 0.5;
    vec3 gc = vec3(aurea_hash(cell + vec2(fr * 3.3 + 17.0, fr * 5.1 + 3.0)),
                   aurea_hash(cell + vec2(fr * 9.1 + 41.0, fr * 2.3 + 29.0)),
                   aurea_hash(cell + vec2(fr * 6.7 + 5.0, fr * 11.9 + 61.0))) - 0.5;
    float wt = 0.5 + 0.5 * (1.0 - abs(2.0 * lum - 1.0));
    g += (vec3(gl) + gc * grainChroma) * _grainAmount * 0.35 * wt;

    float period = max(L.y / 270.0, 2.0);
    g = g * (1.0 - _scanlines * 0.35 * (0.5 - 0.5 * cos(6.2831853 * p.y / period)));

    g = clamp(g, 0.0, 1.0);
    vec3 lin = aurea_srgb_to_linear(g);
    vec4 res = vec4(lin * al, al);
    return mix(orig, res, postMix);
}
