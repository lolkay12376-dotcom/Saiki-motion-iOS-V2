// VHS Camcorder — pass 2: sharpened luma (horizontal, like a VCR) + blurred chroma, saturation, black point.
#define SRC(u) texture(aurea_source, clamp((u), 0.0, 1.0))

void auColorPreset(int pr, out float blackPoint, out float saturation, out float chromaBlur, out float sharpen, out float chromaOffX, out float chromaOffY, out float weaveAmount, out float weaveSpeedX, out float weaveSpeedY, out float redX, out float redY, out float blueX, out float blueY, out float channelBlur) {
    if (pr == 0) {
        blackPoint = 0.015;
        saturation = 1.0;
        chromaBlur = 6.0;
        sharpen = 0.3;
        chromaOffX = 3.0;
        chromaOffY = 0.0;
        weaveAmount = 1.0;
        weaveSpeedX = 0.35;
        weaveSpeedY = 0.2;
        redX = 1.0;
        redY = 0.0;
        blueX = -1.0;
        blueY = 0.0;
        channelBlur = 0.8;
    }
    else if (pr == 1) {
        blackPoint = 0.04;
        saturation = 0.9;
        chromaBlur = 12.0;
        sharpen = 0.6;
        chromaOffX = 6.0;
        chromaOffY = 0.0;
        weaveAmount = 3.0;
        weaveSpeedX = 0.35;
        weaveSpeedY = 0.2;
        redX = 3.0;
        redY = 0.0;
        blueX = -3.0;
        blueY = 0.0;
        channelBlur = 1.5;
    }
    else if (pr == 2) {
        blackPoint = 0.09;
        saturation = 0.5;
        chromaBlur = 14.0;
        sharpen = 0.45;
        chromaOffX = 8.0;
        chromaOffY = 0.0;
        weaveAmount = 4.0;
        weaveSpeedX = 0.35;
        weaveSpeedY = 0.2;
        redX = 5.0;
        redY = 0.0;
        blueX = -5.0;
        blueY = 0.0;
        channelBlur = 2.0;
    }
    else if (pr == 3) {
        blackPoint = 0.01;
        saturation = 1.35;
        chromaBlur = 5.0;
        sharpen = 1.4;
        chromaOffX = 3.0;
        chromaOffY = 0.0;
        weaveAmount = 0.8;
        weaveSpeedX = 0.35;
        weaveSpeedY = 0.2;
        redX = 1.5;
        redY = 0.0;
        blueX = -1.5;
        blueY = 0.0;
        channelBlur = 0.6;
    }
    else if (pr == 4) {
        blackPoint = 0.1;
        saturation = 0.45;
        chromaBlur = 38.0;
        sharpen = 0.2;
        chromaOffX = 22.0;
        chromaOffY = 5.0;
        weaveAmount = 16.0;
        weaveSpeedX = 1.4;
        weaveSpeedY = 0.2;
        redX = 22.0;
        redY = 0.0;
        blueX = -22.0;
        blueY = 0.0;
        channelBlur = 5.0;
    }
    else if (pr == 5) {
        blackPoint = 0.06;
        saturation = 0.8;
        chromaBlur = 4.0;
        sharpen = 1.6;
        chromaOffX = 1.5;
        chromaOffY = 0.0;
        weaveAmount = 0.5;
        weaveSpeedX = 0.35;
        weaveSpeedY = 0.2;
        redX = 1.0;
        redY = 0.0;
        blueX = -1.0;
        blueY = 0.0;
        channelBlur = 0.6;
    }
    else if (pr == 6) {
        blackPoint = 0.2;
        saturation = 0.08;
        chromaBlur = 18.0;
        sharpen = 0.15;
        chromaOffX = 5.0;
        chromaOffY = 0.0;
        weaveAmount = 2.0;
        weaveSpeedX = 0.35;
        weaveSpeedY = 0.2;
        redX = 2.0;
        redY = 0.0;
        blueX = -2.0;
        blueY = 0.0;
        channelBlur = 2.5;
    }
    else if (pr == 7) {
        blackPoint = 0.07;
        saturation = 0.65;
        chromaBlur = 16.0;
        sharpen = 0.35;
        chromaOffX = 24.0;
        chromaOffY = 5.0;
        weaveAmount = 9.0;
        weaveSpeedX = 0.9;
        weaveSpeedY = 0.2;
        redX = 14.0;
        redY = 0.0;
        blueX = -14.0;
        blueY = 0.0;
        channelBlur = 3.5;
    }
    else if (pr == 8) {
        blackPoint = 0.01;
        saturation = 1.08;
        chromaBlur = 2.5;
        sharpen = 0.6;
        chromaOffX = 1.0;
        chromaOffY = 0.0;
        weaveAmount = 0.2;
        weaveSpeedX = 0.35;
        weaveSpeedY = 0.2;
        redX = 0.5;
        redY = 0.0;
        blueX = -0.5;
        blueY = 0.0;
        channelBlur = 0.3;
    }
    else if (pr == 9) {
        blackPoint = 0.1;
        saturation = 0.55;
        chromaBlur = 34.0;
        sharpen = 0.3;
        chromaOffX = 10.0;
        chromaOffY = 0.0;
        weaveAmount = 16.0;
        weaveSpeedX = 0.6;
        weaveSpeedY = 0.2;
        redX = 16.0;
        redY = 0.0;
        blueX = -16.0;
        blueY = 0.0;
        channelBlur = 4.5;
    }
    else if (pr == 10) {
        blackPoint = 0.14;
        saturation = 0.2;
        chromaBlur = 32.0;
        sharpen = 0.1;
        chromaOffX = 18.0;
        chromaOffY = 0.0;
        weaveAmount = 14.0;
        weaveSpeedX = 0.35;
        weaveSpeedY = 0.2;
        redX = 14.0;
        redY = 0.0;
        blueX = -14.0;
        blueY = 0.0;
        channelBlur = 5.5;
    }
    else if (pr == 11) {
        blackPoint = 0.28;
        saturation = 0.08;
        chromaBlur = 40.0;
        sharpen = 0.05;
        chromaOffX = 10.0;
        chromaOffY = 0.0;
        weaveAmount = 8.0;
        weaveSpeedX = 0.35;
        weaveSpeedY = 0.2;
        redX = 10.0;
        redY = 0.0;
        blueX = -10.0;
        blueY = 0.0;
        channelBlur = 6.0;
    }
    else {
        blackPoint = 0.04;
        saturation = 0.9;
        chromaBlur = 12.0;
        sharpen = 0.6;
        chromaOffX = 6.0;
        chromaOffY = 0.0;
        weaveAmount = 3.0;
        weaveSpeedX = 0.35;
        weaveSpeedY = 0.2;
        redX = 3.0;
        redY = 0.0;
        blueX = -3.0;
        blueY = 0.0;
        channelBlur = 1.5;
    }
}

void aurea_colorVals(out float _blackPoint, out float _saturation, out float _chromaBlur, out float _sharpen,
                      out float _chromaOffX, out float _chromaOffY, out float _weaveAmount, out float _weaveSpeedX,
                      out float _weaveSpeedY, out float _redX, out float _redY, out float _blueX, out float _blueY,
                      out float _channelBlur) {
    auColorPreset(int(preset + 0.5), _blackPoint, _saturation, _chromaBlur, _sharpen, _chromaOffX, _chromaOffY,
                  _weaveAmount, _weaveSpeedX, _weaveSpeedY, _redX, _redY, _blueX, _blueY, _channelBlur);
    _blackPoint = clamp(_blackPoint * intensity, 0.0, 0.3);
    _saturation = clamp(1.0 + (_saturation - 1.0) * intensity, 0.0, 2.0);
    _sharpen = clamp(_sharpen * intensity, 0.0, 3.0);
    _chromaBlur = clamp(_chromaBlur * intensity, 0.0, 60.0);
    _chromaOffX = clamp(_chromaOffX * intensity, -60.0, 60.0);
    _weaveAmount = clamp(_weaveAmount * intensity, -40.0, 40.0);
    _redX = clamp(_redX * intensity, -40.0, 40.0);
    _blueX = clamp(_blueX * intensity, -40.0, 40.0);
    _channelBlur = clamp(_channelBlur * intensity, 0.0, 20.0);
}
const float colorMix = 1.0;
const float weaveScale = 400.0;


float aurea_vhs_luma(vec4 c) {
    vec4 un = aurea_unpremultiply(c);
    vec3 gm = aurea_linear_to_srgb(clamp(un.rgb, 0.0, 1.0));
    return dot(gm, vec3(0.299, 0.587, 0.114));
}

vec4 aurea_main(vec2 uv) {
    float _blackPoint, _saturation, _chromaBlur, _sharpen, _chromaOffX, _chromaOffY, _weaveAmount, _weaveSpeedX, _weaveSpeedY, _redX, _redY, _blueX, _blueY, _channelBlur;
    aurea_colorVals(_blackPoint, _saturation, _chromaBlur, _sharpen, _chromaOffX, _chromaOffY, _weaveAmount, _weaveSpeedX, _weaveSpeedY, _redX, _redY, _blueX, _blueY, _channelBlur);

    float sc = length(aurea.layer.xy) / 2203.0;
    vec4 s0 = SRC(uv);
    vec2 dd = aurea_px_to_uv(vec2(2.0 * sc, 0.0));
    float y0 = aurea_vhs_luma(s0);
    float ym = aurea_vhs_luma(SRC(uv - dd));
    float yp = aurea_vhs_luma(SRC(uv + dd));
    float yy = y0 + _sharpen * (y0 - 0.5 * (ym + yp)) * 1.5;

    vec2 cc = (texture(chromaTex, clamp(uv, 0.0, 1.0)).rg - 0.5) * _saturation;
    float r = yy + 1.403 * cc.y;
    float b = yy + 1.773 * cc.x;
    float g = (yy - 0.299 * r - 0.114 * b) / 0.587;
    vec3 rgb = vec3(r, g, b);

    rgb = rgb * (1.0 - _blackPoint) + _blackPoint;
    return vec4(clamp(rgb, 0.0, 1.0), s0.a);
}
