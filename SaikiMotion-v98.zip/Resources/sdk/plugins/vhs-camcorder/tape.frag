// VHS Camcorder — pass 4: tape noise, noise-driven warp, tracking bar, pop lines,
// frame jitter, interlace error, rolling tape wrinkle. Builds on "colorOut".
#define SRC(u) texture(colorOut, clamp((u), 0.0, 1.0))

void auTapePreset(int pr, out float noiseIntensity, out float noiseScale, out float distortion, out float trackBar, out float popFreq, out float jitter, out float interlaceAmount, out float interlaceScale, out float interlaceOffset, out float wrinkleRadius, out float wrinkleSpeed, out float wrinkleProb) {
    if (pr == 0) {
        noiseIntensity = 0.06;
        noiseScale = 1.0;
        distortion = 1.5;
        trackBar = 0.0;
        popFreq = 0.0;
        jitter = 0.5;
        interlaceAmount = 0.0;
        interlaceScale = 1.0;
        interlaceOffset = 0.0;
        wrinkleRadius = 80.0;
        wrinkleSpeed = 0.3;
        wrinkleProb = 0.0;
    }
    else if (pr == 1) {
        noiseIntensity = 0.2;
        noiseScale = 1.0;
        distortion = 5.0;
        trackBar = 0.3;
        popFreq = 0.3;
        jitter = 3.0;
        interlaceAmount = 0.12;
        interlaceScale = 1.0;
        interlaceOffset = 0.0;
        wrinkleRadius = 80.0;
        wrinkleSpeed = 0.3;
        wrinkleProb = 0.15;
    }
    else if (pr == 2) {
        noiseIntensity = 0.3;
        noiseScale = 1.0;
        distortion = 10.0;
        trackBar = 0.5;
        popFreq = 0.85;
        jitter = 14.0;
        interlaceAmount = 0.95;
        interlaceScale = 1.0;
        interlaceOffset = 0.0;
        wrinkleRadius = 80.0;
        wrinkleSpeed = 0.3;
        wrinkleProb = 0.65;
    }
    else if (pr == 3) {
        noiseIntensity = 0.04;
        noiseScale = 1.0;
        distortion = 1.0;
        trackBar = 0.0;
        popFreq = 0.02;
        jitter = 1.0;
        interlaceAmount = 0.0;
        interlaceScale = 1.0;
        interlaceOffset = 0.0;
        wrinkleRadius = 80.0;
        wrinkleSpeed = 0.3;
        wrinkleProb = 0.0;
    }
    else if (pr == 4) {
        noiseIntensity = 0.7;
        noiseScale = 1.0;
        distortion = 45.0;
        trackBar = 0.9;
        popFreq = 0.95;
        jitter = 32.0;
        interlaceAmount = 0.6;
        interlaceScale = 1.0;
        interlaceOffset = 0.0;
        wrinkleRadius = 80.0;
        wrinkleSpeed = 0.3;
        wrinkleProb = 0.8;
    }
    else if (pr == 5) {
        noiseIntensity = 0.03;
        noiseScale = 1.0;
        distortion = 0.8;
        trackBar = 0.0;
        popFreq = 0.0;
        jitter = 0.3;
        interlaceAmount = 0.02;
        interlaceScale = 1.0;
        interlaceOffset = 0.0;
        wrinkleRadius = 80.0;
        wrinkleSpeed = 0.3;
        wrinkleProb = 0.0;
    }
    else if (pr == 6) {
        noiseIntensity = 0.5;
        noiseScale = 1.0;
        distortion = 5.0;
        trackBar = 0.05;
        popFreq = 0.1;
        jitter = 4.0;
        interlaceAmount = 0.05;
        interlaceScale = 1.0;
        interlaceOffset = 0.0;
        wrinkleRadius = 80.0;
        wrinkleSpeed = 0.3;
        wrinkleProb = 0.05;
    }
    else if (pr == 7) {
        noiseIntensity = 0.55;
        noiseScale = 1.0;
        distortion = 16.0;
        trackBar = 0.85;
        popFreq = 0.85;
        jitter = 16.0;
        interlaceAmount = 1.0;
        interlaceScale = 1.0;
        interlaceOffset = 0.0;
        wrinkleRadius = 80.0;
        wrinkleSpeed = 0.3;
        wrinkleProb = 0.25;
    }
    else if (pr == 8) {
        noiseIntensity = 0.02;
        noiseScale = 1.0;
        distortion = 0.5;
        trackBar = 0.0;
        popFreq = 0.0;
        jitter = 0.2;
        interlaceAmount = 0.0;
        interlaceScale = 1.0;
        interlaceOffset = 0.0;
        wrinkleRadius = 80.0;
        wrinkleSpeed = 0.3;
        wrinkleProb = 0.0;
    }
    else if (pr == 9) {
        noiseIntensity = 0.4;
        noiseScale = 1.0;
        distortion = 14.0;
        trackBar = 0.15;
        popFreq = 0.05;
        jitter = 6.0;
        interlaceAmount = 0.1;
        interlaceScale = 1.0;
        interlaceOffset = 0.0;
        wrinkleRadius = 80.0;
        wrinkleSpeed = 0.3;
        wrinkleProb = 0.1;
    }
    else if (pr == 10) {
        noiseIntensity = 0.95;
        noiseScale = 1.0;
        distortion = 38.0;
        trackBar = 0.95;
        popFreq = 0.6;
        jitter = 24.0;
        interlaceAmount = 0.5;
        interlaceScale = 1.0;
        interlaceOffset = 0.0;
        wrinkleRadius = 80.0;
        wrinkleSpeed = 0.3;
        wrinkleProb = 0.4;
    }
    else if (pr == 11) {
        noiseIntensity = 1.0;
        noiseScale = 1.0;
        distortion = 20.0;
        trackBar = 1.0;
        popFreq = 1.0;
        jitter = 15.0;
        interlaceAmount = 0.7;
        interlaceScale = 1.0;
        interlaceOffset = 0.0;
        wrinkleRadius = 80.0;
        wrinkleSpeed = 0.3;
        wrinkleProb = 0.3;
    }
    else {
        noiseIntensity = 0.2;
        noiseScale = 1.0;
        distortion = 5.0;
        trackBar = 0.3;
        popFreq = 0.3;
        jitter = 3.0;
        interlaceAmount = 0.12;
        interlaceScale = 1.0;
        interlaceOffset = 0.0;
        wrinkleRadius = 80.0;
        wrinkleSpeed = 0.3;
        wrinkleProb = 0.15;
    }
}

void aurea_tapeVals(out float _noiseIntensity, out float _noiseScale, out float _distortion, out float _trackBar,
                     out float _popFreq, out float _jitter, out float _interlaceAmount, out float _interlaceScale,
                     out float _interlaceOffset, out float _wrinkleRadius, out float _wrinkleSpeed, out float _wrinkleProb) {
    auTapePreset(int(preset + 0.5), _noiseIntensity, _noiseScale, _distortion, _trackBar, _popFreq, _jitter,
                 _interlaceAmount, _interlaceScale, _interlaceOffset, _wrinkleRadius, _wrinkleSpeed, _wrinkleProb);
    _noiseIntensity = clamp(_noiseIntensity * intensity, 0.0, 1.0);
    _distortion = clamp(_distortion * intensity, 0.0, 60.0);
    _trackBar = clamp(_trackBar * intensity, 0.0, 1.0);
    _popFreq = clamp(_popFreq * intensity, 0.0, 1.0);
    _jitter = clamp(_jitter * intensity, 0.0, 40.0);
    _interlaceAmount = clamp(_interlaceAmount * intensity, 0.0, 1.0);
    _wrinkleProb = clamp(_wrinkleProb * intensity, 0.0, 1.0);
}
const float tapeMix = 1.0;
const vec3 INTERLACE_C1 = vec3(1.0, 0.176, 0.584);
const vec3 INTERLACE_C2 = vec3(0.0, 0.898, 1.0);


float aurea_h1(float a, float b) { return aurea_hash(vec2(a, b)); }

vec4 aurea_main(vec2 uv) {
    float _noiseIntensity, _noiseScale, _distortion, _trackBar, _popFreq, _jitter, _interlaceAmount, _interlaceScale, _interlaceOffset, _wrinkleRadius, _wrinkleSpeed, _wrinkleProb;
    aurea_tapeVals(_noiseIntensity, _noiseScale, _distortion, _trackBar, _popFreq, _jitter, _interlaceAmount, _interlaceScale, _interlaceOffset, _wrinkleRadius, _wrinkleSpeed, _wrinkleProb);

    float sc = length(aurea.layer.xy) / 2203.0;
    vec2 L = aurea.layer.xy;
    vec2 p = aurea_layer_uv(uv) * L;
    float fr = floor(aurea.time.y + 0.5) + seed * 17.0;
    float lineH = max(L.y / 480.0, 1.0);
    float yi = floor(p.y / lineH);

    float ns = max(_noiseScale, 0.05);
    float tn = 0.65 * aurea_noise(vec2(p.x / (28.0 * sc * ns), yi * 3.7 + fr * 5.3))
             + 0.35 * aurea_h1(floor(p.x / (2.0 * sc * ns + 1.0)) + yi * 1.37, fr);

    float jy = (aurea_h1(fr, 3.1) - 0.5) * 2.0 * _jitter * sc * step(0.35, aurea_h1(fr, 8.7));

    float wr = max(_wrinkleRadius * sc, 2.0);
    float wcy = (fract(aurea.time.x * _wrinkleSpeed * 0.5 + aurea_h1(seed, 1.7)) * 1.6 - 0.3) * L.y;
    float wOn = step(aurea_h1(fr, 5.9), _wrinkleProb);
    float wd = (p.y - wcy) / wr;
    float wenv = exp(-wd * wd) * wOn;
    float wdx = sin(wd * 5.0 + aurea.time.x * 9.0) * wenv * wr * 0.35
              + (aurea_noise(vec2(p.y / (wr * 0.15 + 1.0), fr)) - 0.5) * wenv * wr * 0.5;
    float wdy = wd * wenv * wr * 0.3;

    float ndx = (tn - 0.5) * 2.0 * _distortion * sc;

    float vy = aurea_layer_uv(uv).y;
    float barH = _trackBar * 0.12;
    float barT = (barH > 0.001) ? smoothstep(1.0 - barH, 1.0, vy) : 0.0;
    float bdx = barT * (sin(yi * 0.9 + fr) * 12.0 + (aurea_h1(yi, fr) - 0.5) * 40.0) * sc * _trackBar;

    vec2 dpx = vec2(ndx + wdx + bdx, jy + wdy);
    vec4 s = SRC(uv - aurea_px_to_uv(dpx));
    vec4 un = aurea_unpremultiply(s);
    vec3 g = aurea_linear_to_srgb(clamp(un.rgb, 0.0, 1.0));

    g += (tn - 0.5) * _noiseIntensity * 0.5;
    g += smoothstep(0.78, 0.97, tn) * _noiseIntensity * 0.35;
    g = mix(g, vec3(tn * 0.6), barT * _trackBar * 0.85);

    float popOn = step(aurea_h1(fr, 11.3), _popFreq * 0.6);
    float pop = 0.0;
    for (int j = 0; j < 3; j++) {
        float fj = float(j);
        float ly = aurea_h1(fr + fj * 3.3, 21.7) * L.y;
        float lx0 = aurea_h1(fr + fj, 33.1) * L.x * 0.7;
        float lw = (0.2 + aurea_h1(fr + fj, 44.9) * 0.8) * L.x;
        float th = lineH * (1.0 + 2.0 * aurea_h1(fr + fj * 1.7, 55.5));
        float on = step(abs(p.y - ly), th) * step(lx0, p.x) * step(p.x, lx0 + lw)
                 * step(fj * 0.34, aurea_h1(fr, 66.3 + fj));
        pop = max(pop, on);
    }
    g = mix(g, vec3(1.0), pop * popOn * 0.85);

    float isc = max(_interlaceScale, 0.1);
    float fi = floor((fr + _interlaceOffset) * 0.5);
    float bandY = floor(p.y / (lineH * 36.0 * isc));
    float bandOn = step(1.0 - _interlaceAmount * 0.5, aurea_h1(bandY, fi + 77.7));
    float bx0 = aurea_h1(bandY, fi + 5.0) * 0.6 * L.x;
    float bx1 = bx0 + (0.3 + 0.7 * aurea_h1(bandY, fi + 9.0)) * L.x;
    float inX = step(bx0, p.x) * step(p.x, bx1);
    float rowI = floor(p.y / max(lineH * 2.0 * isc, 2.0));
    vec3 ic = (mod(rowI, 2.0) < 1.0) ? INTERLACE_C1 : INTERLACE_C2;
    float glum = dot(g, vec3(0.299, 0.587, 0.114));
    vec3 tinted = ic * (0.3 + 0.9 * glum);
    g = mix(g, tinted, bandOn * inX * 0.85);

    g = clamp(g, 0.0, 1.0);
    vec3 lin = aurea_srgb_to_linear(g);
    vec4 res = vec4(lin * un.a, un.a);
    vec4 orig = texture(colorOut, uv);
    return mix(orig, res, tapeMix);
}
