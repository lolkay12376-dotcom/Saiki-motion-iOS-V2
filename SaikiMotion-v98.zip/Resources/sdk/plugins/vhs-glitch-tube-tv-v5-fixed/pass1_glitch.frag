vec3 toG(vec3 l) { return sqrt(max(l, vec3(0.0))); }
vec3 rgb2yiq(vec3 c) {
    return vec3(dot(c, vec3(0.299, 0.587, 0.114)),
                dot(c, vec3(0.596, -0.274, -0.322)),
                dot(c, vec3(0.211, -0.523, 0.312)));
}
vec3 yiq2rgb(vec3 q) {
    return vec3(q.x + 0.956 * q.y + 0.621 * q.z,
                q.x - 0.272 * q.y - 0.647 * q.z,
                q.x - 1.106 * q.y + 1.703 * q.z);
}
float H(float a, float b) { return aurea_hash(vec2(a, b)); }
float win(float y, float c, float h) { return 1.0 - smoothstep(0.0, max(h, 0.0001), abs(y - c)); }
float qn(float x) { return x * x * x * (x * (x * 6.0 - 15.0) + 10.0); }
float vn(float x, float seed) {
    float i = floor(x);
    float f = x - i;
    return mix(H(i, seed), H(i + 1.0, seed), qn(f)) * 2.0 - 1.0;
}
float fb(float x, float seed) {
    return 0.60 * vn(x, seed) + 0.30 * vn(x * 2.37 + 7.1, seed + 1.3) + 0.10 * vn(x * 5.13 + 3.3, seed + 2.7);
}
float noiseField(vec2 np, float fr, float typ) {
    vec2 ft = vec2(fr * 13.1, fr * 7.7);
    float n;
    if (typ < 0.5) {
        n = aurea_hash(np + ft) - 0.5;
    } else if (typ < 1.5) {
        vec2 cp = floor(np * 0.33);
        n = aurea_hash(cp + ft) * 0.65 + aurea_hash(np + ft + 3.0) * 0.35 - 0.5;
    } else if (typ < 2.5) {
        vec2 sp = vec2(floor(np.x * 0.07), np.y);
        n = (aurea_hash(sp + ft) - 0.5) * 1.4;
    } else if (typ < 3.5) {
        float r = aurea_hash(np + ft);
        n = (step(0.97, r) - step(r, 0.03)) * 0.9;
    } else {
        float r = aurea_hash(np + ft);
        n = (r - 0.5) * 1.6 + step(0.985, aurea_hash(np + ft + 9.0)) * 0.6;
    }
    return n;
}
vec4 aurea_main(vec2 uv) {
    vec2 L = aurea.layer.xy;
    vec2 lp = aurea_layer_uv(uv);
    float sc = L.y / 1080.0;
    float fr = floor(aurea.time.y);
    float t = aurea.time.x;
    float gA = pow(clamp(glitchAmt * 0.01, 0.0, 1.0), 0.8) * 1.5;
    float gS = glitchSize * 0.01;
    float sz = exp2((gS - 0.4) * 2.4);
    float gC = 0.35 + 0.5 * gA;
    float gRl = glitchRoll * 0.01;
    float rate01 = clamp(glitchRate * 0.01, 0.0, 1.0);
    float spd = 1.0 + 2.5 * rate01;
    float period = 5.0 * pow(0.02, rate01);
    float ev = t / period;
    float slot = floor(ev);
    float ph = fract(ev);
    float dur = clamp(mix(0.12, 0.70, gS) / period, 0.12, 0.85);
    float durE = clamp(dur * mix(0.65, 1.15, H(slot, 5.9)), 0.10, 0.90);
    float offS = (1.0 - durE) * H(slot, 6.3);
    float chance = mix(0.55, 1.0, rate01);
    float on = step(H(slot, 3.7), chance) * step(offS, ph) * step(ph, offS + durE);
    on *= step(0.5, glitchType) * step(0.001, gA);
    // type 0 = off, 1-7 = single glitch, 8 = random (1-7), 9 = tear-band glitch (same motion as 1) with light RGB,
    // 10 = clean slices: hard-edged horizontal strips sliding left/right - no RGB, no colour, nothing else
    float kind = (glitchType > 9.5) ? 9.0 : ((glitchType > 8.5) ? 8.0 : ((glitchType > 7.5) ? floor(1.0 + H(slot, 8.1) * 7.0) : floor(glitchType + 0.5)));
    kind = min(kind, 9.0);
    float u = clamp((ph - offS) / max(durE, 0.001), 0.0, 1.0);
    float env = on * smoothstep(0.0, 0.18, u) * (1.0 - smoothstep(0.72, 1.0, u));
    env *= 0.78 + 0.22 * (0.5 + 0.5 * vn(t * 16.0, slot + 7.3));
    float rB = H(slot, 32.9);
    float rC = H(slot, 33.3);
    float rD = H(slot, 34.1);
    float gE = gA * mix(0.6, 1.15, H(slot, 31.7));
    float dirS = (rD > 0.5) ? 1.0 : -1.0;
    float tt = t * (2.5 + 4.0 * rate01);
    float tq = floor(t * 12.0);
    float y0 = H(slot, 1.3);
    float yc = clamp(y0 + 0.07 * vn(tt * 0.9, slot + 1.1), 0.0, 1.0);
    float y1 = fract(y0 + 0.30 + 0.40 * H(slot, 9.1));
    float w2 = smoothstep(0.35, 1.0, gA / 1.5) * step(0.35, H(slot, 9.7));
    float bh = mix(0.04, 0.35, gS);
    float row = floor(lp.y * 360.0);
    float jit = (H(row, fr) - 0.5) * 2.0;
    float ja = jitterAmt * 0.01;
    float shift = (H(row + 40.0, fr + 2.0) - 0.5) * 2.0 * ja * 6.0 * sc + (H(fr, 5.5) - 0.5) * ja * 8.0 * sc;
    float dy = 0.0;
    float washM = 0.0;
    float rainbow = 0.0;
    float burst = 0.0;
    float blackBar = 0.0;
    float foldLine = 0.0;
    vec2 blk = vec2(0.0);
    if (kind == 1.0 || kind == 8.0) {
        float rbAmt = (kind == 8.0) ? 0.22 : 0.5;
        float bhh = bh * mix(1.2, 2.0, rB);
        float m = max(win(lp.y, yc, bhh), w2 * 0.8 * win(lp.y, y1, bhh * 0.7));
        float ys = lp.y * mix(10.0, 48.0, H(slot, 2.2)) / sz;
        float st = (H(floor(ys), slot + tq) - 0.5) * 2.0;
        float sm = fb(ys * 0.75 + tt * 1.7, slot);
        shift += env * m * mix(st, sm, 0.65) * 90.0 * gE * sc * dirS;
        washM += env * m * 0.25 * gC;
        rainbow += env * m * rbAmt;
    }
    if (kind == 2.0) {
        float bhh = bh * mix(1.0, 1.8, rB);
        float m = max(win(lp.y, yc, bhh), w2 * 0.8 * win(lp.y, y1, bhh * 0.7));
        float f1 = 140.0 * mix(0.45, 1.25, rC) / sz;
        float ph1 = lp.y * f1 + t * 25.0 * spd * mix(0.6, 1.4, rD);
        float wv = 0.62 * sin(ph1) + 0.38 * sin(ph1 * 0.41 + 2.0 + 3.0 * vn(lp.y * 4.0 + tt, slot + 2.0));
        float amp = 28.0 + 16.0 * vn(lp.y * 5.0 + tt * 1.3, slot + 4.0);
        float fine = fb(lp.y * 90.0 / sz + tt * 3.0, slot + 8.0);
        shift += env * m * (wv * amp + 8.0 * fine) * gE * sc;
        washM += env * m * gE;
        rainbow += env * m;
    }
    if (kind == 3.0) {
        vec2 gr = max(vec2(mix(5.0, 14.0, H(slot, 4.4)), mix(10.0, 28.0, H(slot, 5.5))) / sz, vec2(2.0, 3.0));
        vec2 g = floor(lp * gr);
        float idH = H(g.x * 13.0 + g.y * 7.0, slot);
        float cyc = floor(t * 7.0 + idH * 3.0);
        float bph = fract(t * 7.0 + idH * 3.0);
        float pulse = smoothstep(0.0, 0.25, bph) * (1.0 - smoothstep(0.65, 1.0, bph));
        float rk = H(idH * 91.0 + cyc, slot);
        float b3 = step(1.0 - 0.18 * gS - 0.12 * gE, rk) * env * pulse;
        blk = b3 * (vec2(H(g.x + cyc, g.y + slot), H(g.y + cyc, g.x + slot)) - 0.5) * 0.22 * gE;
        rainbow += b3 * 0.6;
    }
    if (kind == 4.0) {
        float roll = env * gRl * 0.7;
        float ly = lp.y - roll;
        float wrapped = step(ly, 0.0);
        ly += wrapped;
        dy += ly - lp.y;
        blackBar = step(0.002, roll) * (1.0 - smoothstep(0.0, (0.03 + 0.03 * gS) * sqrt(sz), abs(lp.y - roll)));
        shift += blackBar * 40.0 * sc * mix(jit, vn(lp.y * 140.0 + tt * 6.0, slot + 5.0), 0.5) * (0.4 + gE);
    }
    if (kind == 5.0) {
        float yl = fract(0.15 * t * spd + H(slot, 6.6));
        float d = lp.y - yl - 0.035 * sin(lp.x * 9.4 + t * 2.0 * spd) * gE;
        float m = 1.0 - smoothstep(0.0, (0.02 + 0.05 * gS) * sqrt(sz), abs(d));
        dy += env * m * clamp(d * 45.0, -1.0, 1.0) * 0.03 * gE;
        shift += env * m * 30.0 * gE * sc * sin(lp.x * 3.0 + slot * 1.7 + t * 0.9);
        foldLine = env * m;
        rainbow += env * m * 0.5;
    }
    if (kind == 6.0) {
        float m = mix(1.0, win(lp.y, yc, bh * 2.0), 0.6);
        burst = env * m * gE;
        float n6 = mix(H(floor(row / sz), fr + 9.0) - 0.5, 0.5 * fb(lp.y * 200.0 / sz + tt * 6.0, slot + 3.0), 0.55);
        shift += env * m * n6 * 18.0 * gE * sc;
    }
    if (kind == 7.0) {
        float jmp = on * smoothstep(0.0, 0.08, u) * (1.0 - smoothstep(0.5, 0.7, u));
        dy += jmp * (H(slot, 8.8) - 0.5) * 2.0 * gRl * 0.5 * (0.5 + gE);
        shift += jmp * (H(slot, 9.9) - 0.5) * 40.0 * gE * sc;
    }
    if (kind == 9.0) {
        // clean slices: two layers of hard-edged strips (coarse + fine) that each slide sideways by a random amount.
        // Only `shift` is touched, so no rainbow / wash / burst / black bar is ever added.
        float n1 = mix(5.0, 14.0, H(slot, 2.2)) / sz;
        float n2 = n1 * mix(2.3, 3.7, H(slot, 2.9));
        float c1 = floor(lp.y * n1 + H(slot, 4.1));
        float c2 = floor(lp.y * n2 + 3.0 * H(slot, 4.7));
        float dens = 0.30 + 0.35 * clamp(gA / 1.5, 0.0, 1.0);
        float a1 = step(1.0 - dens, H(c1 + 17.0, slot + tq));
        float a2 = step(1.0 - 0.6 * dens, H(c2 + 31.0, slot + tq + 5.0));
        float s1 = (H(c1, slot + tq + 1.0) - 0.5) * 2.0;
        float s2 = (H(c2 + 7.0, slot + tq + 2.0) - 0.5) * 2.0;
        shift += env * (a1 * s1 * 70.0 + a2 * s2 * 40.0) * gE * sc;
    }
    vec2 uvS = uv + aurea_px_to_uv(vec2(shift, dy * L.y)) + aurea_px_to_uv(blk * L);
    vec4 s = aurea_unpremultiply(texture(aurea_source, uvS));
    vec3 yiq = rgb2yiq(toG(s.rgb));
    float Y = yiq.x;
    float I = yiq.y;
    float Q = yiq.z;
    float rp = lp.y * 18.0 + t * 4.0 * spd + H(slot, 2.0) * 6.0;
    I += rainbow * gC * 0.30 * sin(rp);
    Q += rainbow * gC * 0.30 * sin(rp + 2.1);
    Y = mix(Y, Y * 0.6 + 0.45, clamp(washM, 0.0, 1.0) * 0.7);
    Y += foldLine * 0.25;
    vec2 np = floor(lp * vec2(640.0, 360.0));
    float na = noiseAmt * 0.01;
    float nc = noiseColor * 0.01;
    float n = noiseField(np, fr, floor(noiseType + 0.5));
    Y += n * (0.30 * na + burst * 0.5);
    float cAmp = 0.25 * nc + burst * 0.3 * nc;
    I += (aurea_hash(np + vec2(fr * 3.3, 91.0)) - 0.5) * cAmp;
    Q += (aurea_hash(np + vec2(fr * 5.9, 47.0)) - 0.5) * cAmp;
    float rr = aurea_hash(vec2(row * 0.731, fr * 1.913));
    float drop = step(1.0 - dropoutAmt * 0.0004, rr);
    float seg0 = H(row, fr + 5.0);
    float segLen = 0.04 + 0.30 * H(fr, row + 9.0);
    Y = mix(Y, 1.0, drop * step(seg0, lp.x) * step(lp.x, seg0 + segLen) * 0.85);
    float sl = 0.5 - 0.5 * cos(6.28318 * lp.y * 360.0);
    Y *= 1.0 - linesAmt * 0.01 * 0.30 * sl;
    Y = mix(Y, 0.04 + 0.05 * (n + 0.5), blackBar);
    I *= 1.0 - blackBar;
    Q *= 1.0 - blackBar;
    vec3 rgb = max(yiq2rgb(vec3(Y, I, Q)), vec3(0.0));
    return vec4(rgb, texture(aurea_source, uv).a);
}
