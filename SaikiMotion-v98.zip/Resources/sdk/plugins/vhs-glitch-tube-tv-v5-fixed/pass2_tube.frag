vec3 fromG(vec3 g) { return g * g; }
float lumaG(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
vec4 aurea_main(vec2 uv) {
    vec2 L = aurea.layer.xy;
    float sc = L.y / 1080.0;
    vec2 lp = aurea_layer_uv(uv);
    vec2 c2 = (lp - 0.5) * 2.0;
    float kc = curvature * 0.01 * 0.40;
    vec2 cw = c2 + c2 * (c2.yx * c2.yx) * kc;
    float rr = curveRound * 0.01 * 0.30;
    vec2 q = abs(cw) - (1.0 - rr);
    float dm = length(max(q, vec2(0.0))) + min(max(q.x, q.y), 0.0) - rr;
    float aaw = 1.0 / L.y;
    bool geo = (curvature > 0.01) || (curveRound > 0.01);
    float mask = geo ? (1.0 - smoothstep(-aaw, aaw, dm + aaw)) : 1.0;
    vec2 uvW = uv + aurea_px_to_uv((cw - c2) * 0.5 * L);
    vec2 ab = aurea_px_to_uv(cw * chromaAberr * 0.01 * 0.012 * 0.5 * L);
    vec4 b0 = texture(sig, uvW);
    vec3 c = vec3(texture(sig, uvW + ab).r, b0.g, texture(sig, uvW - ab).b);
    float md = floor(sharpMode + 0.5);
    float rad = 1.5;
    float hz = 0.6;
    float lumaMix = 0.0;
    float halo = 0.0;
    if (md > 0.5 && md < 1.5) { rad = 3.0; }
    else if (md > 1.5 && md < 2.5) { hz = 0.95; rad = 2.0; }
    else if (md > 2.5 && md < 3.5) { lumaMix = 1.0; }
    else if (md > 3.5 && md < 4.5) { halo = 0.8; }
    else if (md > 5.5 && md < 6.5) { rad = 3.0; halo = 1.0; }
    else if (md > 6.5) { hz = 0.95; lumaMix = 1.0; halo = 0.6; }
    bool soft = (md > 4.5 && md < 5.5);
    float amt = sharpAmt * 0.01;
    float r = rad * sc;
    vec2 dx = aurea_px_to_uv(vec2(r, 0.0));
    vec2 dy = aurea_px_to_uv(vec2(0.0, r));
    vec3 nb = (texture(sig, uvW - dx).rgb + texture(sig, uvW + dx).rgb) * 0.5 * hz
            + (texture(sig, uvW - dy).rgb + texture(sig, uvW + dy).rgb) * 0.5 * (1.0 - hz);
    vec3 detail = c - nb;
    detail = mix(detail, vec3(lumaG(detail)), lumaMix);
    if (soft) {
        c = mix(c, c * 0.4 + nb * 0.6, amt * 0.9);
    } else {
        c += amt * 1.5 * detail;
        if (halo > 0.0) {
            vec2 hx = dx * 3.0;
            vec2 hy = dy * 3.0;
            vec3 wide = (texture(sig, uvW - hx).rgb + texture(sig, uvW + hx).rgb
                       + texture(sig, uvW - hy).rgb + texture(sig, uvW + hy).rgb) * 0.25;
            c += halo * amt * 2.0 * (c - wide);
        }
    }
    c *= 1.0 - (kc / 0.40) * 0.30 * smoothstep(0.60, 1.15, length(cw));
    c *= mask;
    float a = geo ? mix(b0.a, 1.0, 1.0 - mask) : b0.a;
    return vec4(fromG(max(c, vec3(0.0))) * a, a);
}
