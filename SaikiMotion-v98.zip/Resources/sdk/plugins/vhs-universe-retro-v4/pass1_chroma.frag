vec3 toG(vec3 l) { return sqrt(max(l, vec3(0.0))); }
vec4 aurea_main(vec2 uv) {
    float sc = aurea.layer.y / 1080.0;
    float rowN = aurea_layer_uv(uv).y * 1080.0;
    float t = aurea.time.x;
    float weave = chromaWeaveX * 0.12 * sc *
                  (sin(rowN * 0.045 + t * 3.1) + 0.5 * sin(rowN * 0.11 - t * 5.3));
    float shift = chromaOffsetX * sc + weave;
    float reach = max(chromaBlur * sc, 0.5);
    vec4 acc = vec4(0.0);
    float wsum = 0.0;
    for (int i = -8; i <= 8; ++i) {
        float f = float(i) / 8.0;
        float w = exp(-3.5 * f * f);
        vec2 o = aurea_px_to_uv(vec2(shift + f * reach, 0.0));
        acc += texture(aurea_source, uv + o) * w;
        wsum += w;
    }
    vec4 c = acc / wsum;
    vec4 s = aurea_unpremultiply(c);
    return vec4(toG(s.rgb), c.a);
}
