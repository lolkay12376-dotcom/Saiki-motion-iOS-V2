vec3 toG(vec3 l) { return sqrt(max(l, vec3(0.0))); }
float lumaG(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
vec3 rgb2yiq(vec3 c) {
    return vec3(dot(c, vec3(0.299, 0.587, 0.114)),
                dot(c, vec3(0.596, -0.274, -0.322)),
                dot(c, vec3(0.211, -0.523, 0.312)));
}
vec3 yiq2rgb(vec3 q) {
    return vec3(q.x + 0.956 * q.y + 0.621 * q.z,
                q.x - 0.272 * q.y - 0.647 * q.z,
                q.x - 1.106 * q.y + 1.703 * q.z);
}
float srcLuma(vec2 uv) {
    vec4 c = aurea_unpremultiply(texture(aurea_source, uv));
    return lumaG(toG(c.rgb));
}
vec4 aurea_main(vec2 uv) {
    vec2 L = aurea.layer.xy;
    vec2 lp = aurea_layer_uv(uv);
    float sc = L.y / 1080.0;
    float fr = floor(aurea.time.y);
    float t = aurea.time.x;
    float dmg = tapeDamage * 0.01;
    float row = floor(lp.y * 360.0);
    float jit = (aurea_hash(vec2(row, fr)) - 0.5) * 2.0;
    float shift = jit * dmg * 2.5 * sc;
    shift += dmg * 3.0 * sc * sin(lp.y * 9.0 + t * 1.7);
    float band = smoothstep(1.0 - 0.06 - 0.05 * dmg, 1.0, lp.y);
    shift += band * band * dmg * 60.0 * sc * (aurea_hash(vec2(row * 1.7, fr + 3.0)) - 0.35);
    float bt = t * 0.37;
    float barOn = step(0.62, aurea_hash(vec2(floor(bt), 11.0)));
    float inBar = barOn * (1.0 - smoothstep(0.0, 0.018, abs(lp.y - fract(bt))));
    shift += inBar * dmg * 22.0 * sc * (jit + 0.3);
    vec2 uvS = uv + aurea_px_to_uv(vec2(shift, 0.0));
    float lb = lumaBlur * 0.75 * sc;
    vec2 d1 = aurea_px_to_uv(vec2(lb, 0.0));
    vec2 d2 = d1 * 2.0;
    float y0 = srcLuma(uvS);
    float y1 = srcLuma(uvS - d1) + srcLuma(uvS + d1);
    float y2 = srcLuma(uvS - d2) + srcLuma(uvS + d2);
    float Y = (6.0 * y0 + 4.0 * y1 + y2) / 16.0;
    vec3 yiq = rgb2yiq(texture(chroma, uvS).rgb);
    float sat = vhsSat * 0.01;
    float I = yiq.y * sat;
    float Q = yiq.z * sat;
    float bl = blackLevel * 0.004;
    Y = bl + Y * (1.0 - bl);
    vec2 np = floor(lp * vec2(640.0, 360.0));
    Y += (aurea_hash(np + vec2(fr * 13.1, fr * 7.7)) - 0.5) * (0.02 + 0.08 * dmg);
    I += (aurea_hash(np + vec2(fr * 3.3, 91.0)) - 0.5) * (0.015 + 0.05 * dmg);
    float rr = aurea_hash(vec2(row * 0.731, fr * 1.913));
    float drop = step(1.0 - 0.02 * dmg, rr);
    float seg0 = aurea_hash(vec2(row, fr + 5.0));
    float segLen = 0.04 + 0.30 * aurea_hash(vec2(fr, row + 9.0));
    float inSeg = step(seg0, lp.x) * step(lp.x, seg0 + segLen);
    Y = mix(Y, 1.0, drop * inSeg * 0.85);
    Y *= 1.0 - 0.04 * mod(row, 2.0);
    vec3 rgb = max(yiq2rgb(vec3(Y, I, Q)), vec3(0.0));
    float a = texture(aurea_source, uv).a;
    return vec4(rgb, a);
}
