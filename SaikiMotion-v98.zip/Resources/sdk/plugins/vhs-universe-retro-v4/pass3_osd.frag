#define osdOn        (osdStyle > 0.5 ? 1.0 : 0.0)
#define osdOpacity   100.0
#define osdMargin    100.0
#define osdFlicker   15.0
#define osdGlitch    25.0
#define osdBloom     20.0
// osdStyle (menu 0-8): 0 None, 1-7 overlay styles, 8 = pure Nightshot: only the green night-vision look,
//                      no REC dot, no focus frame, no bar, no text - nothing is drawn on top
// recMode  (menu 0-8): text content. 0 = same as overlay, 1-7 = text of overlay style 1-7, 8 = text hidden
// recLook  (menu 0-7): 0 = White, the classic base colour (white text + overlay, red REC dot, green accents)
//                      1-7 = Red, Orange, Yellow, Green, Blue, Indigo, Violet (text + overlay)
//                      12-18 are the old rainbow slots, still accepted so saved projects keep their colour
#define lookIdx      floor(recLook + 0.5)
#define txtClrIdx    (lookIdx - 4.0 * floor(lookIdx / 4.0))
#define ovClrIdx     floor(lookIdx / 4.0)
#define rainbowIdx   ((lookIdx > 11.5) ? (lookIdx - 11.0) : min(lookIdx, 7.0))
ivec2 glyphBits(int g) {
    switch (g) {
        case 0: return ivec2(708142, 14905);
        case 1: return ivec2(135556, 14468);
        case 2: return ivec2(67118, 32004);
        case 3: return ivec2(459838, 30753);
        case 4: return ivec2(600258, 2143);
        case 5: return ivec2(64031, 14881);
        case 6: return ivec2(999686, 14897);
        case 7: return ivec2(133183, 8456);
        case 8: return ivec2(476718, 14897);
        case 9: return ivec2(509486, 12353);
        case 10: return ivec2(4096, 4);
        case 11: return ivec2(1001022, 16912);
        case 12: return ivec2(541200, 32272);
        case 13: return ivec2(1033774, 17969);
        case 14: return ivec2(141873, 4228);
        case 15: return ivec2(475663, 30753);
        case 18: return ivec2(133185, 16648);
        case 19: return ivec2(1015808, 0);
        case 20: return ivec2(710513, 17969);
        case 21: return ivec2(135310, 14468);
        case 22: return ivec2(714545, 18035);
        case 23: return ivec2(1001022, 18004);
        case 24: return ivec2(999967, 32272);
        case 25: return ivec2(541230, 14896);
        case 26: return ivec2(999967, 16912);
        case 27: return ivec2(575038, 31281);
        case 28: return ivec2(135327, 4228);
        case 29: return ivec2(575025, 14897);
        case 30: return ivec2(575022, 14897);
        case 31: return ivec2(706097, 18293);
        case 32: return ivec2(1033777, 17969);
        case 33: return ivec2(770606, 15921);
        case 34: return ivec2(1001022, 31281);
        case 35: return ivec2(0, 4096);
        case 36: return ivec2(913275, 28539);
        case 37: return ivec2(1048544, 1023);
    }
    return ivec2(0, 0);
}
float gBold;
float gS;
float gAccF;
float sdTriangle(vec2 p, vec2 p0, vec2 p1, vec2 p2) {
    vec2 e0 = p1 - p0; vec2 e1 = p2 - p1; vec2 e2 = p0 - p2;
    vec2 v0 = p - p0;  vec2 v1 = p - p1;  vec2 v2 = p - p2;
    vec2 pq0 = v0 - e0 * clamp(dot(v0, e0) / dot(e0, e0), 0.0, 1.0);
    vec2 pq1 = v1 - e1 * clamp(dot(v1, e1) / dot(e1, e1), 0.0, 1.0);
    vec2 pq2 = v2 - e2 * clamp(dot(v2, e2) / dot(e2, e2), 0.0, 1.0);
    float sg = sign(e0.x * e2.y - e0.y * e2.x);
    vec2 d = min(min(vec2(dot(pq0, pq0), sg * (v0.x * e0.y - v0.y * e0.x)),
                     vec2(dot(pq1, pq1), sg * (v1.x * e1.y - v1.y * e1.x))),
                     vec2(dot(pq2, pq2), sg * (v2.x * e2.y - v2.y * e2.x)));
    return -sqrt(d.x) * sign(d.y);
}
float sdBox(vec2 p, vec2 c, vec2 h) {
    vec2 e = abs(p - c) - h;
    return length(max(e, vec2(0.0))) + min(max(e.x, e.y), 0.0);
}
float glyphDist(vec2 q, int g) {
    if (g == 17) return 1000.0;
    if (q.x < -3.0 || q.x > 8.0 || q.y < -3.0 || q.y > 10.0) return 1000.0;
    if (g == 16) {
        return sdTriangle(q, vec2(0.5, 0.7), vec2(0.5, 6.3), vec2(5.0, 3.5)) - gBold;
    }
    ivec2 rows = glyphBits(g);
    ivec2 cellBase = ivec2(floor(q));
    float d = 1000.0;
    for (int j = -1; j <= 1; ++j) {
        for (int i = -1; i <= 1; ++i) {
            ivec2 c = cellBase + ivec2(i, j);
            if (c.x < 0 || c.x > 4 || c.y < 0 || c.y > 6) continue;
            int sh = (c.y < 4) ? (5 * c.y) : (5 * (c.y - 4));
            int word = (c.y < 4) ? rows.x : rows.y;
            if (((word >> (sh + 4 - c.x)) & 1) == 0) continue;
            vec2 e = abs(q - (vec2(c) + vec2(0.5))) - vec2(0.5);
            d = min(d, length(max(e, vec2(0.0))) + min(max(e.x, e.y), 0.0));
        }
    }
    return d - gBold;
}
int pick(ivec4 v, int i) {
    return (i == 0) ? v.x : ((i == 1) ? v.y : ((i == 2) ? v.z : v.w));
}
float strDist(vec2 q, ivec4 ga, ivec4 gb, ivec4 gc, int n, float totalW) {
    vec2 e = abs(q - vec2(totalW * 0.5, 3.5)) - vec2(totalW * 0.5, 3.5);
    if (length(max(e, vec2(0.0))) > 7.0) return 1000.0;
    float x = 0.0;
    float d = 1000.0;
    for (int i = 0; i < 12; ++i) {
        if (i >= n) break;
        int g = (i < 4) ? pick(ga, i) : ((i < 8) ? pick(gb, i - 4) : pick(gc, i - 8));
        bool dotg = (g == 10 || g == 35);
        d = min(d, glyphDist(q - vec2(x + (dotg ? -1.0 : 0.0), 0.0), g));
        x += dotg ? 4.0 : ((g == 17) ? 3.0 : 6.0);
    }
    return d;
}
float it(vec2 p, vec2 o, float k, ivec4 a, ivec4 b, ivec4 c, int n, float w) {
    float s = gS * k;
    return strDist((p - o) / s, a, b, c, n, w) * s;
}
float itR(vec2 p, vec2 o, float k, ivec4 a, ivec4 b, ivec4 c, int n, float w) {
    return it(p, vec2(o.x - w * gS * k, o.y), k, a, b, c, n, w);
}
float itC(vec2 p, vec2 o, float k, ivec4 a, ivec4 b, ivec4 c, int n, float w) {
    return it(p, vec2(o.x - 0.5 * w * gS * k, o.y), k, a, b, c, n, w);
}
vec2 gL;
float mgx;
float mgy;
int gSty;
float gFrN;
float gTm;
int gLay;
int gTyp;
float gFp;
ivec4 gTA;
ivec4 gTB;
ivec4 gFC;
ivec4 gMA;
ivec4 gMB;
float ringBox(vec2 p, vec2 c, vec2 h, float w) { return abs(sdBox(p, c, h)) - w; }
float battery(vec2 p, vec2 o, float s) {
    float d = ringBox(p, o + vec2(4.5, 3.5) * s, vec2(4.5, 2.5) * s, 0.35 * s);
    d = min(d, sdBox(p, o + vec2(9.8, 3.5) * s, vec2(0.5, 1.0) * s));
    for (int i = 0; i < 3; ++i) {
        d = min(d, sdBox(p, o + vec2(1.9 + 2.3 * float(i), 3.5) * s, vec2(0.8, 1.5) * s));
    }
    return d;
}
float meter(vec2 p, vec2 o, float kk) {
    float s = gS * kk;
    vec2 eb = abs(p - (o + vec2(14.0, 4.6) * s)) - vec2(16.0, 5.0) * s;
    if (length(max(eb, vec2(0.0))) > 7.0 * s) return 1000.0;
    float d = 1000.0;
    for (int r = 0; r < 2; ++r) {
        float rr = float(r);
        d = min(d, it(p, o + vec2(0.0, rr * 4.6 * s), kk * 0.65, (r == 0) ? ivec4(12, 0, 0, 0) : ivec4(23, 0, 0, 0), ivec4(0), ivec4(0), 1, 5.0));
        float lvl = 4.0 + 6.0 * aurea_hash(vec2(floor(gFrN * 0.25) + rr * 3.0, 21.0 + rr));
        for (int i = 0; i < 10; ++i) {
            if (float(i) + 0.5 < lvl) {
                d = min(d, sdBox(p, o + vec2(8.0 + 2.2 * float(i), 2.3 + 4.6 * rr) * s, vec2(0.8, 1.4) * s));
            }
        }
    }
    return d;
}
float blinkP(float r) {
    return step(fract(gTm * r), 0.6);
}
float osdDist(vec2 p) {
    float dm = 1000.0;
    float da = 1000.0;
    float dr = 1000.0;
    float cellH = 7.0 * gS;
    float yB = gL.y - mgy - cellH;
    float xR = gL.x - mgx;
    if (gLay == 0) {
        if (gSty == 0) {
            dm = it(p, vec2(mgx + 27.0 * gS, mgy), 1.0, ivec4(16,0,0,0), ivec4(0,0,0,0), ivec4(0,0,0,0), 1, 5.0);
        } else if (gSty == 1) {
            float k = 0.7;
            float s = gS * k;
            dm = battery(p, vec2(mgx, mgy), s);
            dm = min(dm, ringBox(p, vec2(gL.x * 0.5, mgy + 3.5 * s), vec2(8.0, 5.0) * s, 0.3 * s));
            da = itR(p, vec2(xR, mgy + 9.5 * s), k, ivec4(16,36,0,0), ivec4(0,0,0,0), ivec4(0,0,0,0), 2, 11.0);
        } else if (gSty == 2) {
            float k = 0.8;
            float s = gS * k;
            da = ringBox(p, vec2(mgx + 7.5 * s, mgy + 5.0 * s), vec2(8.0, 5.5) * s, 0.3 * s);
            dm = it(p, vec2(mgx, yB), 1.0, ivec4(16,0,0,0), ivec4(0,0,0,0), ivec4(0,0,0,0), 1, 5.0);
        } else if (gSty == 3) {
            float k = 0.8;
            float s = gS * k;
            dm = it(p, vec2(mgx, gL.y - mgy - 16.5 * s), k, ivec4(16,0,0,0), ivec4(0,0,0,0), ivec4(0,0,0,0), 1, 5.0);
            dm = min(dm, meter(p, vec2(xR - 27.0 * s, gL.y - mgy - 9.2 * s), k));
        } else if (gSty == 4) {
            float k = 0.8;
            float s = gS * k;
            float yN = gL.y - mgy - 7.0 * s;
            dm = sdBox(p, vec2(mgx + 14.5 * s, mgy + 3.5 * s), vec2(6.5 * s, 0.3 * s));
            if (blinkP(0.8) > 0.5) dr = length(p - vec2(mgx + 3.0 * s, yN + 3.5 * s)) - 2.9 * s;
            // focus frame: fixed size and position (the old "focus hunt" zoom every 3.5 s was removed)
            vec2 fq = abs(p - vec2(gL.x * 0.5, gL.y * 0.5));
            vec2 fh = vec2(12.0, 8.5) * s;
            float arm = 4.2 * s;
            float aw = 0.3 * s;
            da = sdBox(fq, vec2(fh.x - 0.5 * arm + 0.5 * aw, fh.y), vec2(0.5 * arm + 0.5 * aw, aw));
            da = min(da, sdBox(fq, vec2(fh.x, fh.y - 0.5 * arm + 0.5 * aw), vec2(aw, 0.5 * arm + 0.5 * aw)));
            da = min(da, sdBox(fq, vec2(0.0), vec2(1.7 * s, aw)));
            da = min(da, sdBox(fq, vec2(0.0), vec2(aw, 1.7 * s)));
        } else if (gSty == 6) {
            float k = 0.9;
            float s = gS * k;
            vec2 o = vec2(mgx, mgy);
            da = sdTriangle(p, o + vec2(0.0, 3.5) * s, o + vec2(6.0, 3.5) * s, o + vec2(3.0, 0.0) * s);
            da = min(da, sdBox(p, o + vec2(3.0, 5.6) * s, vec2(3.0, 0.7) * s));
        }
    } else {
        if (gTyp == 0) {
            dm = it(p, vec2(mgx, mgy), 1.0, ivec4(11,12,13,14), ivec4(0,0,0,0), ivec4(0,0,0,0), 4, 23.0);
            dm = min(dm, it(p, vec2(mgx, yB), 1.0, ivec4(15,11,0,0), ivec4(0,0,0,0), ivec4(0,0,0,0), 2, 11.0));
            dm = min(dm, itR(p, vec2(xR, yB), 1.0, gTA, gTB, ivec4(0), 8, 43.0));
        } else if (gTyp == 1) {
            float k = 0.7;
            float s = gS * k;
            dm = it(p, vec2(mgx + 11.5 * s, mgy), k, ivec4(3,7,20,21), ivec4(22,0,0,0), ivec4(0,0,0,0), 5, 29.0);
            dm = min(dm, itR(p, vec2(xR, mgy), k, ivec4(20,19,1,2), ivec4(18,0,6,18), ivec4(2,0,0,3), 12, 71.0));
            dm = min(dm, itC(p, vec2(gL.x * 0.5, mgy), k, ivec4(15,11,0,0), ivec4(0,0,0,0), ivec4(0,0,0,0), 2, 11.0));
        } else if (gTyp == 2) {
            float k = 0.8;
            float s = gS * k;
            da = it(p, vec2(mgx + 2.0 * s, mgy + 1.5 * s), k, ivec4(15,11,0,0), ivec4(0,0,0,0), ivec4(0,0,0,0), 2, 11.0);
            if (blinkP(0.8) > 0.5) dr = itR(p, vec2(xR, mgy), k, ivec4(23,24,25,0), ivec4(0,0,0,0), ivec4(0,0,0,0), 3, 17.0);
            dm = itR(p, vec2(xR, mgy + 9.5 * s), k, gTA, gTB, gFC, 11, 59.0);
            dm = min(dm, itR(p, vec2(xR, mgy + 19.0 * s), k, ivec4(1,2,20,21), ivec4(22,0,0,0), ivec4(0,0,0,0), 5, 29.0));
            dm = min(dm, itR(p, vec2(xR, yB), k, ivec4(26,23,13,20), ivec4(24,0,0,0), ivec4(0,0,0,0), 5, 29.0));
        } else if (gTyp == 3) {
            float k = 0.8;
            float s = gS * k;
            dm = it(p, vec2(mgx, gL.y * 0.28), k, ivec4(13,29,28,30), ivec4(0,0,0,0), ivec4(0,0,0,0), 4, 23.0);
            da = itR(p, vec2(xR, mgy), k, ivec4(11,13,29,15), ivec4(24,0,0,0), ivec4(0,0,0,0), 5, 29.0);
            dm = min(dm, it(p, vec2(mgx, gL.y - mgy - 7.0 * s), k, ivec4(26,24,34,35), ivec4(1,5,35,2), ivec4(0,0,6,0), 11, 61.0));
            dm = min(dm, it(p, vec2(mgx, gL.y - mgy - 16.5 * s), k, ivec4(38,17,3,10), ivec4(0,0,17,13), ivec4(20,0,0,0), 9, 45.0));
        } else if (gTyp == 4) {
            float k = 0.8;
            float s = gS * k;
            float yN = gL.y - mgy - 7.0 * s;
            dm = it(p, vec2(mgx, mgy), k, ivec4(28,0,0,0), ivec4(0,0,0,0), ivec4(0,0,0,0), 1, 5.0);
            dm = min(dm, it(p, vec2(mgx + 22.0 * s, mgy), k, ivec4(31,0,0,0), ivec4(0,0,0,0), ivec4(0,0,0,0), 1, 5.0));
            dm = min(dm, itR(p, vec2(xR, mgy), k, ivec4(11,19,20,24), ivec4(22,29,0,0), ivec4(0,0,0,0), 6, 35.0));
            dm = min(dm, itR(p, vec2(xR, yB), k, gTA, gTB, gFC, 11, 59.0));
            dr = it(p, vec2(mgx + 8.0 * s, yN), k, ivec4(23,24,25,0), ivec4(0,0,0,0), ivec4(0,0,0,0), 3, 17.0);
        } else if (gTyp == 5) {
            dm = it(p, vec2(mgx, mgy), 1.0, ivec4(23,24,31,0), ivec4(0,0,0,0), ivec4(0,0,0,0), 3, 17.0);
            dm = min(dm, itR(p, vec2(xR, yB), 1.0, gTA, gTB, ivec4(0), 8, 43.0));
        } else {
            float k = 0.9;
            dm = itR(p, vec2(xR, mgy), k, ivec4(0,20,21,22), ivec4(0,0,0,0), ivec4(0,0,0,0), 4, 23.0);
            if (blinkP(1.5) > 0.5) da = itC(p, vec2(gL.x * 0.5, gL.y * 0.5 - 4.2 * gS), 1.2, ivec4(28,13,11,24), ivec4(17,24,22,27), ivec4(0,0,0,0), 8, 44.0);
        }
    }
    float d = min(dm, min(da, dr));
    gAccF = (dr <= d) ? 2.0 : ((da <= d) ? 1.0 : 0.0);
    return d;
}
vec3 txtPal(float i) {
    if (i > 2.5) return vec3(0.50, 0.95, 1.00);
    if (i > 1.5) return vec3(0.45, 1.00, 0.50);
    if (i > 0.5) return vec3(1.00, 0.90, 0.25);
    return vec3(0.93, 0.93, 0.97);
}
vec3 ovPal(float i) {
    if (i > 1.5) return vec3(1.00, 0.75, 0.25);
    if (i > 0.5) return vec3(0.50, 0.95, 1.00);
    return vec3(0.93, 0.93, 0.97);
}
vec3 rbPal(float i) {
    if (i < 1.5) return vec3(1.00, 0.13, 0.12);
    if (i < 2.5) return vec3(1.00, 0.52, 0.06);
    if (i < 3.5) return vec3(1.00, 0.92, 0.12);
    if (i < 4.5) return vec3(0.18, 0.92, 0.25);
    if (i < 5.5) return vec3(0.15, 0.45, 1.00);
    if (i < 6.5) return vec3(0.38, 0.22, 0.95);
    return vec3(0.78, 0.38, 1.00);
}
float textVis(float mode) {
    if (mode > 1.5) return 0.0;
    if (mode > 0.5) {
        float c = mod(gTm, 8.0);
        return 1.0 - smoothstep(5.0, 5.6, c) * (1.0 - smoothstep(7.4, 8.0, c));
    }
    return 1.0;
}
vec3 osdLayer(vec3 col, vec2 po, int lay, vec3 mainC, bool classic, int sty, float opa) {
    gLay = lay;
    float dG = osdDist(po);
    float accF = gAccF;
    if (dG > 7.5 * gS) return col;
    vec3 redC = vec3(1.0, 0.18, 0.15);
    vec3 accC = mainC;
    if (classic) {
        accC = vec3(0.35, 1.0, 0.45);
        if (sty == 6) accC = vec3(1.0, 0.70, 0.20);
        if (sty == 4) accC = mainC;
    }
    vec3 baseC = (accF < 0.5) ? mainC : ((accF < 1.5) ? accC : redC);
    float depth = osdDepth * 0.01;
    vec2 dir = vec2(0.6, 0.8);
    float E = depth * 1.15 * gS;
    float aa = 0.7 * gFp;
    float fx = 0.07 * gS;
    float dR = osdDist(po + vec2(-fx, 0.0));
    float dB = osdDist(po + vec2(fx, 0.0));
    vec3 face = vec3(1.0 - smoothstep(-aa, aa, dR),
                     1.0 - smoothstep(-aa, aa, dG),
                     1.0 - smoothstep(-aa, aa, dB));
    float bevL = smoothstep(-aa, aa, osdDist(po - dir * 0.30 * gS));
    float bevD = smoothstep(-aa, aa, osdDist(po + dir * 0.30 * gS));
    vec3 faceCol = baseC * 0.9 + vec3(0.07 * bevL);
    faceCol *= 1.0 - 0.22 * bevD;
    float ext = 0.0;
    float extShade = 0.0;
    if (E > 0.01) {
        for (int k = 4; k >= 1; --k) {
            float kk = float(k) * 0.25;
            float ck = 1.0 - smoothstep(-aa, aa, osdDist(po - dir * E * kk));
            if (ck > 0.0) { ext = max(ext, ck); extShade = kk; }
        }
    }
    vec3 tintR = clamp(baseC / vec3(0.93, 0.93, 0.97), 0.0, 1.0);
    vec3 extCol = mix(vec3(0.46, 0.47, 0.55), vec3(0.12, 0.12, 0.18), extShade) * tintR;
    float dS = osdDist(po - dir * (E + 0.9 * gS));
    float soft = (0.35 + 1.1 * depth) * gS;
    float shCov = (1.0 - smoothstep(-soft, soft, dS)) * (0.35 + 0.5 * depth);
    float olCov = 1.0 - smoothstep(-aa, aa, dG - 0.20 * gS);
    vec3 oc = col;
    oc *= 1.0 - shCov;
    oc = mix(oc, extCol, ext);
    oc = mix(oc, vec3(0.04, 0.04, 0.10), olCov * 0.85);
    oc = mix(oc, faceCol, face);
    oc += baseC * exp(-max(dG, 0.0) / (1.8 * gS)) * osdBloom * 0.01 * 0.6 * (1.0 - face.g);
    return mix(col, oc, osdOpacity * 0.01 * opa);
}
vec4 aurea_main(vec2 uv) {
    vec4 t = texture(tape, uv);
    vec3 col = t.rgb;
    int sIdx = int(floor(osdStyle + 0.5));
    bool nvTextOff = (sIdx >= 8);
    if (nvTextOff) sIdx = 5;
    gSty = sIdx - 1;
    if (osdOn < 0.5 || osdOpacity < 0.5) return vec4(col, t.a);
    if (gSty == 4) {
        float y = dot(col, vec3(0.299, 0.587, 0.114));
        col = mix(col, vec3(0.12, 1.0, 0.30) * y * 1.15 + vec3(0.0, 0.03, 0.0), 0.85 * osdOpacity * 0.01);
    }
    if (nvTextOff) return vec4(col, t.a);
    float rm = floor(recMode + 0.5);
    float tMode = (rm > 7.5) ? 2.0 : 0.0;
    float tTyp = min(rm, 7.0);
    gTyp = (tTyp < 0.5) ? gSty : (int(tTyp) - 1);
    float vis = textVis(tMode);
    vec2 L = aurea.layer.xy;
    gL = L;
    vec2 lp = aurea_layer_uv(uv);
    vec2 p = lp * L;
    float sc = L.y / 1080.0;
    float m = min(L.x, L.y);
    gFp = 1.0 / aurea.layer.z;
    float fr = floor(aurea.time.y);
    gFrN = fr;
    gTm = max(aurea.time.x, 0.0);
    float ts = floor(gTm + 0.0001);
    float hh = mod(floor(ts / 3600.0), 100.0);
    float mm = mod(floor(ts / 60.0), 60.0);
    float ss = mod(ts, 60.0);
    float ff = floor(fract(gTm) * 24.0);
    gTA = ivec4(int(hh / 10.0), int(mod(hh, 10.0)), 10, int(mm / 10.0));
    gTB = ivec4(int(mod(mm, 10.0)), 10, int(ss / 10.0), int(mod(ss, 10.0)));
    gFC = ivec4(10, int(ff / 10.0), int(mod(ff, 10.0)), 0);
    gMA = ivec4(int(mm / 10.0), int(mod(mm, 10.0)), 10, int(ss / 10.0));
    gMB = ivec4(int(mod(ss, 10.0)), 0, 0, 0);
    float row = floor(lp.y * 360.0);
    float jt = (aurea_hash(vec2(row, fr)) - 0.5) * 2.0;
    float bnd = smoothstep(0.93, 1.0, lp.y);
    float dmg = tapeDamage * 0.01;
    float og = osdGlitch * 0.01;
    float fl = osdFlicker * 0.01;
    float shiftO = og * (jt * 3.0 * sc * (1.0 + 2.0 * dmg)
                   + bnd * bnd * 45.0 * sc * dmg * 2.0 * (aurea_hash(vec2(row * 1.7, fr + 3.0)) - 0.35));
    vec2 po = p + vec2(shiftO, (aurea_hash(vec2(fr, 2.2)) - 0.5) * 4.0 * sc * fl);
    float flick = 1.0 - fl * 0.35 * step(0.8, aurea_hash(vec2(fr, 3.3)));
    float mk = osdMargin * 0.01;
    mgx = 0.07 * m * mk;
    mgy = 0.05 * m * mk;
    gS = 0.0089 * m * osdSize;
    gBold = max(0.13, 1.1 * gFp / gS);
    float ocI = ovClrIdx;
    float tcI = txtClrIdx;
    float rbI = rainbowIdx;
    bool rb = rbI > 0.5;
    vec3 ovC = rb ? rbPal(rbI) : ovPal(ocI);
    vec3 txC = rb ? rbPal(rbI) : txtPal(tcI);
    col = osdLayer(col, po, 0, ovC, (!rb) && (ocI < 0.5), gSty, flick);
    if (vis > 0.003) col = osdLayer(col, po, 1, txC, (!rb) && (tcI < 0.5), gTyp, flick * vis);
    return vec4(col, t.a);
}
