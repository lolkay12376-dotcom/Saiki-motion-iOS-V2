#define sharpAmt 40.0
#define origBlend 0.0
vec3 toG(vec3 l) { return sqrt(max(l, vec3(0.0))); }
vec3 fromG(vec3 g) { return g * g; }
float lumaG(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
vec3 overlayBlend(vec3 b, vec3 s) {
    return mix(2.0 * b * s, vec3(1.0) - 2.0 * (vec3(1.0) - b) * (vec3(1.0) - s), step(vec3(0.5), b));
}
vec4 aurea_main(vec2 uv) {
    float sc = aurea.layer.y / 1080.0;
    vec2 lp = aurea_layer_uv(uv);
    float ra = retroAmount * 0.01;
    float tb = tintBalance * 0.01;
    float sa = shadowAmt * 0.01;
    vec4 b0 = texture(base, uv);
    vec3 c = b0.rgb;
    float r = 1.5 * sc;
    vec2 dx = aurea_px_to_uv(vec2(r, 0.0));
    vec2 dy = aurea_px_to_uv(vec2(0.0, r));
    vec3 nb = (texture(base, uv - dx).rgb + texture(base, uv + dx).rgb) * 0.3
            + (texture(base, uv - dy).rgb + texture(base, uv + dy).rgb) * 0.2;
    c += sharpAmt * 0.015 * (c - nb);
    float g = ghostAmt * 0.01;
    vec3 e1 = texture(base, uv - aurea_px_to_uv(vec2(16.0 * sc, 1.5 * sc))).rgb;
    vec3 e2 = texture(base, uv - aurea_px_to_uv(vec2(30.0 * sc, 2.5 * sc))).rgb;
    vec3 echo = e1 * 0.65 + e2 * 0.35;
    float eLum = lumaG(echo);
    float eHi = smoothstep(0.28, 0.95, eLum);
    vec3 ghostCol = mix(vec3(0.30, 0.45, 1.0), vec3(0.72, 0.36, 1.0), tb);
    vec3 ghostAdd = g * 0.7 * eHi * (0.5 + 0.5 * eLum) * ghostCol;
    c = vec3(1.0) - (vec3(1.0) - c) * (vec3(1.0) - ghostAdd);
    float lum = lumaG(c);
    c = mix(vec3(lum), c, 1.0 - 0.40 * ra);
    vec3 curve = c * c * (vec3(3.0) - 2.0 * c);
    c = mix(c, curve, 0.45 * ra);
    lum = lumaG(c);
    vec3 blue = vec3(0.30, 0.42, 0.95);
    vec3 purple = vec3(0.62, 0.36, 0.90);
    vec3 shTint = mix(blue, purple, tb * 0.55);
    vec3 miTint = mix(blue, purple, 0.30 + 0.70 * tb);
    vec3 hiTint = mix(vec3(0.80, 0.90, 1.00), vec3(1.00, 0.80, 0.98), tb);
    float wS = 1.0 - smoothstep(0.0, 0.55, lum);
    float wH = smoothstep(0.50, 1.0, lum);
    float wM = clamp(1.0 - wS - wH, 0.0, 1.0);
    vec3 tint = shTint * wS + miTint * wM + hiTint * wH;
    c = mix(c, overlayBlend(c, tint), 0.55 * ra);
    float inv = 1.0 - lum;
    c += sa * 0.17 * shTint * inv * inv * inv;
    float vig = smoothstep(0.35, 0.85, length(lp - vec2(0.5)));
    c = mix(c, c * (shTint * 0.9 + vec3(0.1)) * 0.55, sa * 0.5 * vig);
    c += wH * ra * 0.05 * hiTint;
    float gn = aurea_hash(floor(lp * vec2(960.0, 540.0)) + vec2(floor(aurea.time.y) * 5.1, 3.0)) - 0.5;
    c += gn * 0.02 * (0.4 + ra);
    float ob = origBlend * 0.01;
    if (ob > 0.0) {
        vec4 o = aurea_unpremultiply(texture(aurea_source, uv));
        c = mix(c, toG(o.rgb), ob);
    }
    vec3 lin = fromG(max(c, vec3(0.0)));
    return vec4(lin * b0.a, b0.a);
}
