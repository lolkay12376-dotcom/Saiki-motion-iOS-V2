// AureaPlugin.swift — multi-pass .aureaplugin effects (plugin.json + pass .frag files).
//
// The plugin shaders are GLSL ES 3.00 with an `aurea_main(uv)` entry, named pass inputs and a small
// host library (aurea_hash / aurea_noise / aurea_px_to_uv / ...). They run only in the GL renderer
// (SceneRenderer.applyPluginEffect); the Metal renderer falls back to GL for frames that use one.

import Foundation

struct FxPass {
    var code: String
    var target: String?
    var scale: Float
    var inputs: [String: String]      // shader sampler name -> earlier pass target
}

extension EffectDef {

    private static func en(_ o: JObj?, _ fallback: String = "") -> String {
        guard let o = o else { return fallback }
        let e = o.optString("en")
        if !e.isEmpty { return e }
        for k in o.keys { let v = o.optString(k); if !v.isEmpty { return v } }
        return fallback
    }

    /// Loads one plugin folder. nil when plugin.json / a pass shader is missing.
    static func fromAureaPlugin(_ dir: URL) -> EffectDef? {
        guard let data = try? Data(contentsOf: dir.appendingPathComponent("plugin.json")),
              let txt = String(data: data, encoding: .utf8), let o = JObj.parse(txt) else { return nil }
        let name = en(o.optJSONObject("name"), dir.lastPathComponent)
        let pid = o.optString("id")
        var slug = String((pid.isEmpty ? name : pid).lowercased().map { $0.isLetter || $0.isNumber ? $0 : "_" })
        slug = slug.trimmingCharacters(in: CharacterSet(charactersIn: "_"))
        let d = EffectDef(id: "aurea_" + slug, name: name, desc: en(o.optJSONObject("description")),
                          category: o.optString("category", "Glitch"), source: dir.path)

        if let pa = o.optJSONArray("params") {
            for i in 0..<pa.count {
                guard let po = pa.optJSONObject(i) else { continue }
                let key = po.optString("id").trimmingCharacters(in: .whitespaces)
                if key.isEmpty { continue }
                let label = en(po.optJSONObject("label"), key)
                switch po.optString("type") {
                case "color":
                    d.colors.append(ColorParam(key, label, parseColor(po.optString("default", "#FFFFFF"))))
                case "bool":
                    d.props.append(PropDef(key, label, 0, 1, po.optBool("default") ? 1 : 0, 0, ["Off", "On"]))
                case "enum":
                    var opts: [String] = []
                    if let oa = po.optJSONArray("options") {
                        for j in 0..<oa.count { opts.append(en(oa.optJSONObject(j), oa.optString(j))) }
                    }
                    d.props.append(PropDef(key, label, 0, Float(max(opts.count - 1, 0)), po.optFloat("default"), 0, opts))
                case "int":
                    d.props.append(PropDef(key, label, po.optFloat("min"), po.optFloat("max", 100), po.optFloat("default"), 0))
                default:
                    let lo = po.optFloat("min"), hi = po.optFloat("max", 1)
                    let span = hi - lo
                    d.props.append(PropDef(key, label, lo, hi, po.optFloat("default"), span <= 5 ? 2 : (span <= 100 ? 1 : 0)))
                }
            }
        }
        guard let pa = o.optJSONArray("passes"), pa.count > 0 else { return nil }
        for i in 0..<pa.count {
            guard let po = pa.optJSONObject(i),
                  let code = try? String(contentsOf: dir.appendingPathComponent(po.optString("shader")), encoding: .utf8)
            else { return nil }
            var inputs: [String: String] = [:]
            if let io = po.optJSONObject("inputs") { for k in io.keys { inputs[k] = io.optString(k) } }
            let sc = po.optFloat("scale", 1)
            let t = po.optString("target")
            d.passes.append(FxPass(code: code, target: t.isEmpty ? nil : t, scale: sc > 0 ? min(sc, 1) : 1, inputs: inputs))
        }
        return d
    }

    /// GLSL ES 3.00 source of pass `i`.
    func aureaPassSource(_ i: Int) -> String {
        let ps = passes[i]
        var s = """
#version 300 es
precision highp float;
precision highp int;
precision highp sampler2D;
in vec2 vUv;
out vec4 aureaOut;
uniform sampler2D aurea_source;

"""
        for k in ps.inputs.keys.sorted() { s += "uniform sampler2D \(k);\n" }
        s += "struct AureaU { vec3 layer; vec3 time; };\nuniform AureaU aurea;\n"
        for p in props { s += "uniform float \(p.key);\n" }
        for c in colors { s += "uniform vec4 \(c.key);\n" }
        s += """
float aurea_hash(vec2 p) { vec3 q = fract(vec3(p.xyx) * 0.1031); q += dot(q, q.yzx + 33.33); return fract((q.x + q.y) * q.z); }
float aurea_noise(vec2 p) {
    vec2 i = floor(p); vec2 f = fract(p); vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(mix(aurea_hash(i), aurea_hash(i + vec2(1.0, 0.0)), u.x),
               mix(aurea_hash(i + vec2(0.0, 1.0)), aurea_hash(i + vec2(1.0, 1.0)), u.x), u.y);
}
vec2 aurea_px_to_uv(vec2 px) { return px / max(aurea.layer.xy, vec2(1.0)); }
vec2 aurea_layer_uv(vec2 p) { return p; }
vec4 aurea_unpremultiply(vec4 c) { return c.a > 0.0 ? vec4(c.rgb / c.a, c.a) : vec4(0.0); }
vec3 aurea_srgb_to_linear(vec3 c) { return mix(c / 12.92, pow((c + 0.055) / 1.055, vec3(2.4)), step(vec3(0.04045), c)); }
vec3 aurea_linear_to_srgb(vec3 c) { return mix(c * 12.92, 1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055, step(vec3(0.0031308), c)); }
vec4 aurea_srgb_to_linear(vec4 c) { return vec4(aurea_srgb_to_linear(c.rgb), c.a); }
vec4 aurea_linear_to_srgb(vec4 c) { return vec4(aurea_linear_to_srgb(c.rgb), c.a); }

"""
        s += ps.code
        s += "\nvoid main() { aureaOut = aurea_main(vUv); }\n"
        return s
    }
}
