// Layer.swift — the layer model (Model).
//
// Kotlin Core/Layer.kt. A Layer is one item on the timeline: media (image /
// video / audio / glb), text, a shape, a camera, a null, a group, particles,
// an optical flare or an adjustment. Everything animatable lives in `props`
// (a Track per parameter key); effects are ids in `fx` with per-instance
// parameter tracks prefixed `"<entry>__<key>"` so the same effect can be
// applied twice with different settings.
//
// Time model: `start`/`end` are seconds on the scene timeline; `srcOffset` is
// where in the source media playback begins; `srcDur` is the source length.

import Foundation

enum LayerType: String {
    case SHAPE, TEXT, IMAGE, VIDEO, CAMERA, NULL, MODEL, PARTICLES, GROUP, ADJUST, AUDIO, FLARE
}

enum ShapeKind: String {
    case RECT, ROUND, CIRCLE, TRIANGLE, STAR
}

/// One animatable parameter definition (the "defs" tables in Defs below).
struct PropDef {
    let key: String
    let label: String
    let min: Float
    let max: Float
    var def: Float
    var dec: Int = 2
    var options: [String]? = nil
    var inf: Bool = false
    var span: Float = 1

    init(_ key: String, _ label: String, _ min: Float, _ max: Float, _ def: Float,
         _ dec: Int = 2, _ options: [String]? = nil, _ inf: Bool = false, _ span: Float = 1) {
        self.key = key
        self.label = label
        self.min = min
        self.max = max
        self.def = def
        self.dec = dec
        self.options = options
        self.inf = inf
        self.span = span
    }
}

/// One color parameter of an effect (stored as four _r/_g/_b/_a tracks).
struct ColorParam {
    let key: String
    let label: String
    var def: Int32

    init(_ key: String, _ label: String, _ def: Int32) {
        self.key = key
        self.label = label
        self.def = def
    }
}

// MARK: - TextAnim

/// One effect inside a custom text animation (3D, wiggle, transform, tracking, skew).
final class TextFx {
    static let KINDS = ["Transform", "Wiggle", "3D", "Tracking", "Skew"]
    /// per kind: (label, lo, hi, default, decimals) for each of the value slots
    static let PARAMS: [[(String, Float, Float, Float, Int)]] = [
        [("Move X from", -2, 2, 0, 2), ("Move Y from", -2, 2, 0.3, 2), ("Scale from", 0, 4, 1, 2),
         ("Rotate from (deg)", -720, 720, 0, 0), ("Opacity from", 0, 1, 0, 2)],
        [("Wiggle X", 0, 1, 0.03, 3), ("Wiggle Y", 0, 1, 0.03, 3), ("Wiggle rotate (deg)", 0, 90, 8, 1),
         ("Wiggle scale", 0, 1, 0, 2), ("Speed (Hz)", 0, 20, 4, 1), ("Letter offset", 0, 3, 0.5, 2)],
        [("Rotate X (deg)", -360, 360, 90, 0), ("Rotate Y (deg)", -360, 360, 0, 0),
         ("Perspective", 0, 1, 0.3, 2)],
        [("Tracking from (em)", -1, 3, 1, 2)],
        [("Skew X (deg)", -80, 80, 25, 0), ("Skew Y (deg)", -80, 80, 0, 0)],
    ]
    var kind: Int
    var v: [Float]
    var id = String(UUID().uuidString.prefix(6)).lowercased()
    init(_ kind: Int) {
        self.kind = kind
        v = Self.PARAMS[kind].map { $0.3 }
    }
    func name() -> String { Self.KINDS.indices.contains(kind) ? Self.KINDS[kind] : "Effect" }
    func copy() -> TextFx { let f = TextFx(kind); f.v = v; f.id = id; return f }
    func toJson() -> JObj {
        let a = JArr(); for x in v { _ = a.put(Double(x)) }
        return JObj().put("kind", Int64(kind)).put("v", a).put("id", id)
    }
    static func fromJson(_ o: JObj) -> TextFx {
        let k = clamp(o.optInt("kind"), 0, KINDS.count - 1)
        let f = TextFx(k)
        let fid = o.optString("id"); if !fid.isEmpty { f.id = fid }
        if let a = o.optJSONArray("v") {
            for i in 0..<min(a.count, f.v.count) { f.v[i] = Float((a.opt(i) as? Double) ?? Double((a.opt(i) as? Int64) ?? 0)) }
        }
        return f
    }
}

/// Per-letter text animation (the Animate tab of the text panel).
/// type 12 = fully custom (start/end + a stack of TextFx); 0-11 are the old fixed ones.
final class TextAnim {
    static let TYPES = ["Slide up in", "Slide down in", "Fade in", "Scale in", "Typewriter",
                        "Pop in", "Rotate in", "Slide up out", "Fade out", "Slide down out",
                        "Bounce in", "Outline draw", "Custom"]

    var type: Int
    var mode = 0                 // 0 in, 1 out, 2 loop
    var start: Float = 0
    var dur: Float = 0.5
    var stagger: Float = 0.04
    var distance: Float = 0.15
    var scaleFrom: Float = 0.6
    var rotFrom: Float = 0
    var speed: Float = 1
    var ease = 0                 // 0 linear 1 ease out 2 ease in-out 3 bounce 4 custom curve
    var curve = Key(0, 0, .EASE_IN_OUT)
    var fade = true
    var fx: [TextFx] = []
    var id = String(UUID().uuidString.prefix(6)).lowercased()

    init(_ type: Int, _ mode: Int = 0) {
        self.type = type
        self.mode = mode
    }

    func name() -> String {
        Self.TYPES.indices.contains(type) ? Self.TYPES[type] : "Animation"
    }

    func copy() -> TextAnim {
        let a = TextAnim(type, mode)
        a.start = start; a.dur = dur; a.stagger = stagger; a.distance = distance
        a.scaleFrom = scaleFrom; a.rotFrom = rotFrom; a.speed = speed; a.ease = ease
        a.curve = curve.copy(); a.fade = fade
        a.fx = fx.map { $0.copy() }; a.id = id
        return a
    }

    func toJson() -> JObj {
        JObj().put("type", Int64(type)).put("mode", Int64(mode)).put("start", Double(start))
            .put("dur", Double(dur)).put("stagger", Double(stagger)).put("distance", Double(distance))
            .put("scaleFrom", Double(scaleFrom)).put("rotFrom", Double(rotFrom)).put("speed", Double(speed))
            .put("ease", Int64(ease)).put("curve", curve.toJson()).put("fade", fade)
            .put("id", id).put("fx", { () -> JArr in let a = JArr(); for f in fx { _ = a.put(f.toJson()) }; return a }())
    }

    static func fromJson(_ o: JObj) -> TextAnim {
        let a = TextAnim(o.optInt("type"), o.optInt("mode"))
        a.start = o.optFloat("start"); a.dur = max(0.05, o.optFloat("dur", 0.5))
        a.stagger = o.optFloat("stagger", 0.04); a.distance = o.optFloat("distance", 0.15)
        a.scaleFrom = o.optFloat("scaleFrom", 0.6); a.rotFrom = o.optFloat("rotFrom")
        a.speed = o.optFloat("speed", 1); a.ease = o.optInt("ease")
        if let c = o.optJSONObject("curve") { a.curve = Key.fromJson(c) }
        a.fade = o.optBool("fade", true)
        let aid = o.optString("id"); if !aid.isEmpty { a.id = aid }
        if let fa = o.optJSONArray("fx") {
            for i in 0..<fa.count { if let fo = fa.optJSONObject(i) { a.fx.append(TextFx.fromJson(fo)) } }
        }
        return a
    }
}

// MARK: - Layer

final class Layer: Hashable {
    // Identity-based Hashable so Layer can key dictionaries / sets in the
    // renderer (visited maps). Value equality is meaningless for layers —
    // two layers with equal fields are still two layers.
    static func == (a: Layer, b: Layer) -> Bool { a === b }
    func hash(into hasher: inout Hasher) { hasher.combine(ObjectIdentifier(self)) }
    var id: Int
    var name: String
    var type: LayerType

    /// True when `a` is `b` itself or any descendant of `b` (walking
    /// parentId chains through `all`). The Parent popup uses this to keep
    /// cycles out of the layer tree.
    static func isDescendant(_ a: Layer, of b: Layer, in all: [Layer]) -> Bool {
        var cur = a
        while true {
            if cur === b { return true }
            if cur.parentId < 0 { return false }
            guard let p = all.first(where: { $0.id == cur.parentId }) else { return false }
            cur = p
        }
    }

    // identity + timing
    var parentId: Int = -1
    /// Parent helper: what this layer does NOT inherit from its parent (ferris-wheel cabins: orbit but stay upright).
    var lockRot = false, lockScale = false, lockMove = false
    var visible = true
    var start: Float = 0
    var end: Float = 5
    var srcDur: Float = 0
    var srcOffset: Float = 0
    var blend = 0
    var mask = 0

    // content
    var text = ""
    var imagePath: String? = nil
    var shape: ShapeKind = .RECT
    var flare: Flare? = nil

    // text style
    var color: Int32 = Int32(bitPattern: 0xFFFFFFFF)
    var color2: Int32 = Int32(bitPattern: 0xFF7A7A84)
    var font = "sans-serif"
    var fontPath: String? = nil
    var bold = false
    var italic = false
    var underline = false
    var strike = false
    var align = 1                       // 0 left, 1 center, 2 right
    var caps = 0                        // 0 as typed, 1 upper, 2 lower
    var spacing: Float = 0
    var strokeW: Float = 0
    var strokeColor: Int32 = Int32(bitPattern: 0xFF000000)
    var strokePos = 0
    var strokeJoin = 0
    var stroke2W: Float = 0
    var stroke2Color: Int32 = Int32(bitPattern: 0xFF000000)
    var borderW: Float = 0
    var borderColor: Int32 = Int32(bitPattern: 0xFFFFFFFF)
    var borderFill: Int32 = 0
    var borderPad: Float = 0
    var borderDash = false
    var shadowOn = false
    var shadowColor: Int32 = Int32(bitPattern: 0xFF000000)
    var anims: [TextAnim] = []

    // 3d / fx
    var is3d = false
    var mblur = false
    /// Group only: render the children into their own buffer first (like an After Effects precomp),
    /// then apply the group's effects, mask, opacity and blend mode to the result as one image.
    var precomp = true
    /// Group only: bake the group's finished frames to disk (PreRender) and play those back.
    var prerender = false
    var mbStutter = false
    var mbRgb = false
    // 3D model settings: environment light, metallic reflectivity, texture viewer (0 final, 1 base,
    // 2 rough, 3 metal, 4 occlusion, 5 emissive), texture occlusion, depth occlusion between 3D layers
    var m3Env = true, m3Metal = true, m3Ao = true, occlude = true
    var m3View = 0
    var vdbTint: Int32 = Int32(bitPattern: 0xFFFFFFFF)
    var tgraph = ""                 // terrain node-graph JSON (TGraph) so a terrain can be edited again
    /// PBR material maps imported for this layer: key (albedo, normal, rough, metal, ao, height, emissive, opacity) -> file path
    var pbrMaps: [String: String] = [:]
    var x3s = ""                    // extra 3D / render / VDB settings "key=value;key=value" (see xf / xset)
    func xf(_ k: String, _ d: Float) -> Float {
        for kv in x3s.split(separator: ";") { let p = kv.split(separator: "="); if p.count == 2, p[0] == k { return Float(p[1]) ?? d } }
        return d
    }
    func xset(_ k: String, _ v: Float) {
        var out: [String] = x3s.split(separator: ";").map(String.init).filter { !$0.hasPrefix(k + "=") }
        out.append("\(k)=\(v)"); x3s = out.joined(separator: ";")
    }
    var vdbDens: Float = 1          // VDB volume: density multiplier
    var rtOn = false                // ray tracing (3D model layer or camera)
    var rtInt: Float = 1            // ray tracing intensity
    var rtRad: Float = 0.5          // ray tracing occlusion radius
    var vdbBright: Float = 1        // VDB volume: brightness
    var vdbEnv = false              // VDB volume: environment lighting on
    var vdbEnvPath: String? = nil   // imported image / .hdr / .exr
    var vdbSurround = false         // light from the scene around it (no image)
    var fx: [String] = []
    var fxOff: Set<String> = []
    var inputs: [String: Int] = [:]
    var props: [String: Track] = [:]
    var puppet: Puppet? = nil
    var rig: Rig? = nil                 // set on a rig group
    var rigOff: [String: Float] = [:]   // runtime: rig parameter contributions
    var deformer = 0                    // group only: 0 folder/plain, 1 warp deformer, 2 rotate deformer
    var warp: Warp? = nil               // warp deformer control grid

    init(_ id: Int, _ name: String, _ type: LayerType) {
        self.id = id
        self.name = name
        self.type = type
        // transform defaults
        props["x"] = Track(0)
        props["y"] = Track(0)
        props["z"] = Track(0)
        props["scale"] = Track(1)
        props["scaleX"] = Track(1)
        props["scaleY"] = Track(1)
        props["rotX"] = Track(0)
        props["rotY"] = Track(0)
        props["rotZ"] = Track(0)
        props["anchorX"] = Track(50)
        props["anchorY"] = Track(50)
        props["opacity"] = Track(1)
    }

    /// Effects to run on this layer: its own, then Squeeze effects of ancestors that have
    /// "Affect parent hierarchy" ticked (read from the owning ancestor, so all kids squeeze identically).
    func fxChain() -> [(owner: Layer, entry: String)] {
        var out: [(owner: Layer, entry: String)] = fx.map { (self, $0) }
        var cur = self, hops = 0
        let all = Editor.scene.layers
        while cur.parentId >= 0, hops < 64, let par = all.first(where: { $0.id == cur.parentId }) {
            hops += 1; cur = par
            if par.type == .GROUP && par.precomp { continue }      // a pre-comp group already squeezes its whole content
            for e in par.fx where !par.fxOff.contains(e) && Registry.get(e)?.id == "squeeze" {
                if let h = par.props[e + "__sqHier"], h.eval(Editor.time) > 0.5 { out.append((par, e)) }
                else if let h = par.props[e + "__sqHier"], !h.keys.isEmpty { continue }
            }
        }
        return out
    }

    // MARK: tracks
    /// Moves every keyframe by dt so animation travels with the layer in the timeline.
    func shiftKeys(_ dt: Float) {
        if dt == 0 { return }
        for (_, tr) in props { for k in tr.keys { k.t += dt } }
    }


    /// Gets or creates the track for `key`.
    func track(_ key: String) -> Track {
        if let t = props[key] { return t }
        let t = Track(Registry.propDef(key)?.def ?? 0)
        props[key] = t
        return t
    }

    /// Evaluated value with defaults per key (mirrors the Kotlin `p` map).
    func p(_ key: String, _ t: Float) -> Float {
        let tr = props[key]
        let base: Float
        if let tr = tr {
            base = tr.evalExpr(editTime(key, t), t, tr.exprActive() ? Editor.scene.markersByName() : [:])
        } else {
            base = Self.defaults[key] ?? (Registry.propDef(key)?.def ?? 0)
        }
        return rigOff.isEmpty ? base : base + (rigOff[key] ?? 0)
    }

    /// Time used when evaluating `key` — remapped for media layers so
    /// speed/time-remap curves drive playback.
    func editTime(_ key: String, _ t: Float) -> Float {
        if (type == .VIDEO || type == .MODEL) && !key.hasPrefix("remap") {
            let rt = props["remapT"]
            if rt != nil && !(rt?.keys.isEmpty ?? true) {
                return t
            }
        }
        return t
    }

    /// Effect parameter key (single-instance effects use the bare key).
    func pkey(_ entry: String, _ pd: PropDef) -> String {
        let d = Registry.get(entry)
        return (d?.kind ?? 0) == 1 ? pd.key : entry + "__" + pd.key
    }

    func ckey(_ entry: String, _ cp: ColorParam) -> String {
        let d = Registry.get(entry)
        return (d?.kind ?? 0) == 1 ? cp.key : entry + "__" + cp.key
    }

    /// Layers that draw something (used by toolbars + input pickers).
    func isRenderable() -> Bool {
        switch type {
        case .SHAPE, .TEXT, .IMAGE, .VIDEO, .MODEL, .FLARE, .PARTICLES:
            return true
        default:
            return false
        }
    }

    /// Instantaneous playback speed from the remap tracks.
    func speedAt(_ t: Float) -> Float {
        if let rt = props["remapT"], !rt.keys.isEmpty {
            let a = rt.eval(max(t - 0.05, 0))
            let b = rt.eval(t + 0.05)
            let d = b - a
            if abs(d) > 0.0001 { return clamp(0.1 * d, -10, 10) / 0.1 }
        }
        let sp = props["remapSpeed"]?.eval(t) ?? 1
        return sp
    }

    // MARK: serialization

    /// `canonical`: used for the pre-render fingerprint — skips tracks that were only created lazily
    /// (untouched defaults), since they must not count as an edit.
    func toJson(canonical: Bool = false) -> JObj {
        let o = JObj()
        o.put("id", Int64(id)).put("name", name).put("type", type.rawValue)
        o.put("parentId", Int64(parentId)).put("visible", visible)
        if lockRot { o.put("lockRot", true) }
        if lockScale { o.put("lockScale", true) }
        if lockMove { o.put("lockMove", true) }
        o.put("start", Double(start)).put("end", Double(end))
        o.put("srcDur", Double(srcDur)).put("srcOffset", Double(srcOffset))
        o.put("blend", Int64(blend)).put("mask", Int64(mask))
        o.put("text", text).put("imagePath", imagePath ?? "")
        o.put("shape", shape.rawValue)
        if let f = flare { o.put("flare", f.toJson()) }
        o.put("color", Double(UInt32(bitPattern: color)))
        o.put("color2", Double(UInt32(bitPattern: color2)))
        o.put("font", font).put("fontPath", fontPath ?? "")
        o.put("bold", bold).put("italic", italic).put("underline", underline).put("strike", strike)
        o.put("align", Int64(align)).put("caps", Int64(caps)).put("spacing", Double(spacing))
        o.put("strokeW", Double(strokeW)).put("strokeColor", Double(UInt32(bitPattern: strokeColor)))
        o.put("strokePos", Int64(strokePos)).put("strokeJoin", Int64(strokeJoin))
        o.put("stroke2W", Double(stroke2W)).put("stroke2Color", Double(UInt32(bitPattern: stroke2Color)))
        o.put("borderW", Double(borderW)).put("borderColor", Double(UInt32(bitPattern: borderColor)))
        o.put("borderFill", Double(UInt32(bitPattern: borderFill)))
        o.put("borderPad", Double(borderPad)).put("borderDash", borderDash)
        o.put("shadowOn", shadowOn).put("shadowColor", Double(UInt32(bitPattern: shadowColor)))
        let aa = JArr()
        for a in anims { aa.put(a.toJson()) }
        o.put("anims", aa)
        o.put("precomp", precomp)
        if prerender { o.put("prerender", true) }
        o.put("is3d", is3d).put("mblur", mblur).put("mbStutter", mbStutter).put("mbRgb", mbRgb)
        o.put("m3Env", m3Env).put("m3Metal", m3Metal).put("m3Ao", m3Ao).put("occlude", occlude).put("m3View", Int64(m3View)).put("vdbDens", Double(vdbDens)).put("vdbBright", Double(vdbBright)).put("rtOn", rtOn).put("rtInt", Double(rtInt)).put("rtRad", Double(rtRad)).put("vdbEnv", vdbEnv).put("vdbSurround", vdbSurround).put("vdbEnvPath", vdbEnvPath ?? "").put("vdbTint", Double(UInt32(bitPattern: vdbTint))).put("x3s", x3s).put("pbrMaps", pbrMaps.map { $0.key + "\u{2}" + $0.value }.joined(separator: "\u{1}")).put("tgraph", tgraph)
        let fa = JArr()
        for e in fx { fa.put(e) }
        o.put("fx", fa)
        let fo = JArr()
        for e in fxOff { fo.put(e) }
        o.put("fxOff", fo)
        let io = JObj()
        for (k, v) in inputs.sorted(by: { $0.key < $1.key }) { io.put(k, Int64(v)) }
        o.put("inputs", io)
        let po = JObj()
        // sorted: Swift dictionaries iterate in a different (random) order every launch / insert,
        // which made identical layers look different
        for (k, tr) in props.sorted(by: { $0.key < $1.key }) {
            if canonical, tr.keys.isEmpty, !tr.exprOn, tr.base == (Registry.propDef(k)?.def ?? 0) { continue }
            po.put(k, tr.toJson())
        }
        o.put("props", po)
        if let pp = puppet { o.put("puppet", pp.toJson()) }
        if let rg = rig { o.put("rig", rg.toJson()) }
        if deformer != 0 { o.put("deformer", Int64(deformer)) }
        if let w = warp { o.put("warp", w.toJson()) }
        return o
    }

    static func fromJson(_ o: JObj) -> Layer {
        let l = Layer(o.optInt("id"),
                      o.optString("name", "Layer"),
                      LayerType(rawValue: o.optString("type", "SHAPE")) ?? .SHAPE)
        l.parentId = o.optInt("parentId", -1)
        l.lockRot = o.optBool("lockRot", false); l.lockScale = o.optBool("lockScale", false); l.lockMove = o.optBool("lockMove", false)
        l.visible = o.optBool("visible", true)
        l.start = o.optFloat("start")
        l.end = o.optFloat("end", 5)
        l.srcDur = o.optFloat("srcDur")
        l.srcOffset = o.optFloat("srcOffset")
        l.blend = o.optInt("blend")
        l.mask = o.optInt("mask")
        l.text = o.optString("text")
        let ip = o.optString("imagePath")
        l.imagePath = ip.isEmpty ? nil : ip
        l.shape = ShapeKind(rawValue: o.optString("shape", "RECT")) ?? .RECT
        if let fo = o.optJSONObject("flare") { l.flare = Flare.fromJson(fo) }
        l.color = Int32(bitPattern: UInt32(clamping: Int64(o.optDouble("color"))))
        l.color2 = Int32(bitPattern: UInt32(clamping: Int64(o.optDouble("color2"))))
        l.font = o.optString("font", "sans-serif")
        let fp = o.optString("fontPath")
        l.fontPath = fp.isEmpty ? nil : fp
        l.bold = o.optBool("bold"); l.italic = o.optBool("italic")
        l.underline = o.optBool("underline"); l.strike = o.optBool("strike")
        l.align = o.optInt("align", 1); l.caps = o.optInt("caps")
        l.spacing = o.optFloat("spacing")
        l.strokeW = o.optFloat("strokeW")
        l.strokeColor = Int32(bitPattern: UInt32(clamping: Int64(o.optDouble("strokeColor"))))
        l.strokePos = o.optInt("strokePos"); l.strokeJoin = o.optInt("strokeJoin")
        l.stroke2W = o.optFloat("stroke2W")
        l.stroke2Color = Int32(bitPattern: UInt32(clamping: Int64(o.optDouble("stroke2Color"))))
        l.borderW = o.optFloat("borderW")
        l.borderColor = Int32(bitPattern: UInt32(clamping: Int64(o.optDouble("borderColor"))))
        l.borderFill = Int32(bitPattern: UInt32(clamping: Int64(o.optDouble("borderFill"))))
        l.borderPad = o.optFloat("borderPad")
        l.borderDash = o.optBool("borderDash")
        l.shadowOn = o.optBool("shadowOn")
        l.shadowColor = Int32(bitPattern: UInt32(clamping: Int64(o.optDouble("shadowColor"))))
        if let aa = o.optJSONArray("anims") {
            for i in 0..<aa.count {
                if let ao = aa.optJSONObject(i) { l.anims.append(TextAnim.fromJson(ao)) }
            }
        }
        l.is3d = o.optBool("is3d"); l.mblur = o.optBool("mblur"); l.precomp = o.optBool("precomp", true)
        l.prerender = o.optBool("prerender")
        l.mbStutter = o.optBool("mbStutter"); l.mbRgb = o.optBool("mbRgb")
        l.m3Env = o.optBool("m3Env", true); l.m3Metal = o.optBool("m3Metal", true); l.m3Ao = o.optBool("m3Ao", true)
        l.occlude = o.optBool("occlude", true); l.m3View = o.optInt("m3View", 0); l.vdbDens = o.optFloat("vdbDens", 1); l.vdbBright = o.optFloat("vdbBright", 1); l.rtOn = o.optBool("rtOn", false); l.rtInt = o.optFloat("rtInt", 1); l.rtRad = o.optFloat("rtRad", 0.5); l.vdbEnv = o.optBool("vdbEnv", false); l.vdbSurround = o.optBool("vdbSurround", false); let vep = o.optString("vdbEnvPath", ""); l.vdbEnvPath = vep.isEmpty ? nil : vep
        l.x3s = o.optString("x3s", "")
        for kv in o.optString("pbrMaps", "").split(separator: "\u{1}") {
            let p = kv.split(separator: "\u{2}", maxSplits: 1).map(String.init)
            if p.count == 2 { l.pbrMaps[p[0]] = p[1] }
        }
        l.tgraph = o.optString("tgraph", "")
        if o.has("vdbTint") { l.vdbTint = Int32(bitPattern: UInt32(clamping: Int64(o.optDouble("vdbTint")))) }
        if let fa = o.optJSONArray("fx") {
            for i in 0..<fa.count { l.fx.append(fa.optString(i)) }
        }
        if let fo = o.optJSONArray("fxOff") {
            for i in 0..<fo.count { l.fxOff.insert(fo.optString(i)) }
        }
        if let io = o.optJSONObject("inputs") {
            for k in io.keys { l.inputs[k] = io.optInt(k) }
        }
        if let po = o.optJSONObject("props") {
            for k in po.keys {
                if let to = po.optJSONObject(k) {
                    let tr = Track()
                    tr.load(to)
                    l.props[k] = tr
                }
            }
        }
        if let pj = o.optJSONObject("puppet") { l.puppet = Puppet.fromJson(pj) }
        if let rj = o.optJSONObject("rig") { l.rig = Rig.fromJson(rj) }
        l.deformer = o.optInt("deformer", 0)
        if let wj = o.optJSONObject("warp") { l.warp = Warp.fromJson(wj) }
        return l
    }

    /// Defaults for keys that have no track yet (the Kotlin DEF map).
    static let defaults: [String: Float] = [
        "x": 0, "y": 0, "z": 0,
        "scale": 1, "scaleX": 1, "scaleY": 1, "scaleZ": 1,
        "rotX": 0, "rotY": 0, "rotZ": 0,
        "anchorX": 50, "anchorY": 50, "opacity": 1,
        "volume": 1, "fov": 55,
        "mbSamples": 8, "mbAmount": 1,
        "remapSpeed": 1, "remapInterp": 0,
    ]
}

extension Layer {
    /// A light is a 3D Null flagged "isLight": a movable ball that lights VDB volumes.
    var isLight: Bool { type == .NULL && xf("isLight", 0) > 0.5 }
}

/// Global 3D render settings (apply to every layer, kept across projects).
enum R3D {
    static func g(_ k: String, _ d: Float) -> Float { UserDefaults.standard.object(forKey: "r3d." + k) == nil ? d : UserDefaults.standard.float(forKey: "r3d." + k) }
    static func set(_ k: String, _ v: Float) { UserDefaults.standard.set(v, forKey: "r3d." + k) }
}
