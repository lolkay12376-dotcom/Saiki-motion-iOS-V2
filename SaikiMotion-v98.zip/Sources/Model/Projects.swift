// Projects.swift — the project store (Model).
//
// One JSON file per project in <Documents>/SaikiMotion/projects, media in
// <Documents>/SaikiMotion/media — the same sandbox layout every round of the
// finished app used, so old projects keep opening.

import Foundation

enum Projects {

    static var lastError: String? = nil

    static var root: URL { Paths.root }

    static var dir: URL { root.appendingPathComponent("projects", isDirectory: true) }

    static func mediaDir() -> URL { root.appendingPathComponent("media", isDirectory: true) }

    static func fileURL(_ id: String) -> URL {
        dir.appendingPathComponent("\(id).json")
    }

    /// Creates the sandbox folders. Safe any number of times.
    static func ensureDirs() {
        Paths.ensure()
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        try? FileManager.default.createDirectory(at: mediaDir(), withIntermediateDirectories: true)
    }

    /// Saves the project (bumps updatedAt). The editor's spelling takes the
    /// id + the live object; the home list uses the inout form.
    @discardableResult
    static func save(_ id: String, _ project: Project) -> String? {
        ensureDirs()
        project.updatedAt = Date()
        project.id = id
        let text = project.toJson().toString()      // compact: fast enough to run on every change
        let url = fileURL(id)
        do {
            // keep the previous good file as a backup before replacing it
            if FileManager.default.fileExists(atPath: url.path) {
                let bak = url.deletingPathExtension().appendingPathExtension("bak")
                try? FileManager.default.removeItem(at: bak)
                try? FileManager.default.copyItem(at: url, to: bak)
            }
            try text.write(to: url, atomically: true, encoding: .utf8)
            // verify: the file we just wrote must read back and parse
            if let back = try? String(contentsOf: url, encoding: .utf8), JObj.parse(back) != nil {
                lastError = nil
            } else {
                lastError = "the saved file could not be read back"
            }
        } catch {
            lastError = error.localizedDescription
            NSLog("Project save failed: \(error)")
        }
        StoreNotification.post(.projectsChanged)
        return text
    }

    @discardableResult
    static func save(_ project: inout Project) -> String? {
        save(project.id, project)
    }

    static func load(_ id: String) -> Project? {
        guard let text = try? String(contentsOf: fileURL(id), encoding: .utf8) else { return nil }
        if let o = JObj.parse(text) { return Project.fromJson(o) }
        // unreadable main file → fall back to the backup instead of an empty project
        let bak = fileURL(id).deletingPathExtension().appendingPathExtension("bak")
        if let t2 = try? String(contentsOf: bak, encoding: .utf8), let o2 = JObj.parse(t2) {
            return Project.fromJson(o2)
        }
        return nil
    }

    /// All projects, newest-touched first.
    static func list() -> [Project] {
        ensureDirs()
        let files = (try? FileManager.default.contentsOfDirectory(at: dir, includingPropertiesForKeys: [.contentModificationDateKey])) ?? []
        return files
            .filter { $0.pathExtension == "json" }
            .compactMap { load($0.deletingPathExtension().lastPathComponent) }
            .sorted { $0.updatedAt > $1.updatedAt }
    }

    static func delete(_ id: String) {
        try? FileManager.default.removeItem(at: fileURL(id))
        StoreNotification.post(.projectsChanged)
    }

    /// Renames a project in place (keeps id, timestamps refresh on save).
    static func rename(_ id: String, _ name: String) {
        guard var p = load(id) else { return }
        p.name = name
        save(&p)
    }

    /// Deep-copies a project under a new id ("Name copy"), like the
    /// original's Projects.duplicate(name).
    @discardableResult
    static func duplicate(_ id: String) -> Project? {
        guard let p = load(id) else { return nil }
        guard let o = JObj.parse(p.toJson().toString()) else { return nil }
        var copy = Project.fromJson(o)
        copy.id = UUID().uuidString
        copy.name = p.name + " copy"
        save(&copy)
        return copy
    }

    /// The JSON file as stored on disk — the share/export payload.
    /// (Same as fileURL(_:); the original exposed this for the share sheet.)
    static func exportURL(_ id: String) -> URL { fileURL(id) }

    /// Replaces project `id` with the contents of a project file (keeps its id and name).
    /// `includeMedia` only matters for a .saikiproject bundle: off = keep the media the project
    /// already has (matched by layer id) instead of taking the bundle's.
    @discardableResult
    static func overwrite(_ id: String, from url: URL, includeMedia: Bool) -> Project? {
        guard let old = load(id) else { return nil }
        let isArc: Bool = {
            let sc = url.startAccessingSecurityScopedResource()
            defer { if sc { url.stopAccessingSecurityScopedResource() } }
            return ProjectArchive.isArchive(url)
        }()
        guard var p = isArc ? ProjectArchive.importArchive(url, includeMedia: includeMedia) : importFile(url) else { return nil }
        let tmp = p.id
        if isArc && !includeMedia {
            var img: [Int: String] = [:], font: [Int: String] = [:]
            for s in old.scenes { for l in s.layers {
                if let a = l.imagePath { img[l.id] = a }
                if let f = l.fontPath { font[l.id] = f }
            } }
            for s in p.scenes { for l in s.layers {
                l.imagePath = img[l.id] ?? nil
                l.fontPath = font[l.id] ?? nil
            } }
        }
        p.id = id
        p.name = old.name
        guard save(&p) == nil else { return nil }
        if tmp != id { delete(tmp) }
        return p
    }

    /// Imports a project JSON picked in the document picker: copies it into
    /// the store under a fresh id so re-importing never collides. (The picker
    /// opens asCopy, so security scope is optional.)
    @discardableResult
    static func importFile(_ url: URL) -> Project? {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        // a .saikiproject bundle (project + media) unpacks through its own reader
        if ProjectArchive.isArchive(url) { return ProjectArchive.importArchive(url) }
        guard let data = try? Data(contentsOf: url), var o = lenientParse(data) else { return nil }
        // unwrap {"project": {...}} style containers
        if o.optJSONArray("scenes") == nil && o.optJSONArray("layers") == nil {
            for k in ["project", "data", "composition", "comp", "root", "document"] {
                if let inner = o.optJSONObject(k) { o = inner; break }
            }
        }
        var p = Project.fromJson(o)
        // a bare composition ({"layers": [...]} with no scenes list) becomes the first scene
        if o.optJSONArray("scenes") == nil, o.optJSONArray("layers") != nil {
            p.scenes = [Scene.fromJson(o)]
        }
        p.id = UUID().uuidString
        if p.name.isEmpty || p.name == "Untitled" { p.name = url.deletingPathExtension().lastPathComponent }
        lastImportNote = "\(p.scenes.count) scenes · \(p.scenes.reduce(0) { $0 + $1.layers.count }) layers"
            + (p.scenes.reduce(0) { $0 + $1.layers.count } == 0 ? " · file keys: " + o.keys.prefix(8).joined(separator: ",") : "")
        save(&p)
        return p
    }

    /// Short description of the last import (scene / layer counts) for the toast.
    static var lastImportNote = ""

    /// Parses project text from any encoding / wrapper: BOM, UTF-16, NULs and junk before or
    /// after the JSON object are tolerated.
    static func lenientParse(_ data: Data) -> JObj? {
        var texts: [String] = []
        if let t = String(data: data, encoding: .utf8) { texts.append(t) }
        if let t = String(data: data, encoding: .utf16) { texts.append(t) }
        if let t = String(data: data, encoding: .isoLatin1) { texts.append(t) }
        for raw in texts {
            var t = raw.replacingOccurrences(of: "\u{FEFF}", with: "").replacingOccurrences(of: "\0", with: "")
            t = t.trimmingCharacters(in: .whitespacesAndNewlines)
            if let o = JObj.parse(t) { return o }
            if let a = t.firstIndex(of: "{"), let b = t.lastIndex(of: "}"), a < b,
               let o = JObj.parse(String(t[a...b])) { return o }
        }
        return nil
    }

    /// "1080p portrait · 30 fps" style label for list rows.
    static func resLabel(_ w: Int, _ h: Int) -> String {
        let ar: String
        let r = Double(w) / Double(max(h, 1))
        if r > 1.2 { ar = "landscape" }
        else if r < 0.83 { ar = "portrait" }
        else { ar = "square" }
        let hd = max(w, h)
        let tag = hd >= 2000 ? "2K" : (hd >= 1000 ? "1080p" : "SD")
        return "\(tag) \(ar)"
    }

    /// Project-row label (scene + layer counts).
    static func resLabel(_ p: Project) -> String {
        let layers = p.scenes.reduce(0) { $0 + $1.layers.count }
        let word = p.scenes.count == 1 ? "scene" : "scenes"
        return "\(p.scenes.count) \(word) · \(layers) layers · \(p.fps) fps"
    }
}
