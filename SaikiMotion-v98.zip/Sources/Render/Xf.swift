// Xf.swift — transforms (Render).
//
// The 2D world: x spans [-ar, ar], y spans [-1, 1] (ar = canvas aspect).
// Every layer quad is placed by (x, y), scaled by (scale * scaleX/Y),
// rotated by rotZ around its anchor, and inherits the parent chain. The
// same math feeds the renderer and the overlay's selection box, so what
// you drag is what you see.

import Foundation
import CoreGraphics
import UIKit

enum Xf {

    /// Particle layers (dedicated type, or a shape carrying the Particles effect).
    static func isParticles(_ l: Layer) -> Bool {
        l.type == .PARTICLES || (l.fx.contains("particles") && !l.fxOff.contains("particles"))
    }

    /// Natural quad size (world units) of a layer's content.
    /// Puppet pin space. A group's puppet warps the flattened canvas image, so its pin space is
    /// the whole canvas (identity matrix, canvas-sized quad); other layers use their own quad.
    static func puppetQuad(_ l: Layer) -> (Float, Float) {
        if l.type == .GROUP { return (2 * Float(Editor.project.w) / Float(max(Editor.project.h, 1)), 2) }
        return quadSize(l)
    }
    static func puppetMatrix(_ l: Layer, _ t: Float) -> [Float] {
        l.type == .GROUP ? [1, 0, 0, 0, 1, 0, 0, 0, 1] : matrix(l, t)
    }

    static func quadSize(_ l: Layer) -> (Float, Float) {
        switch l.type {
        case .IMAGE, .VIDEO:
            let (iw, ih) = contentAspect(l)
            let h: Float = 1.0
            return (h * iw / max(ih, 0.0001), h)
        case .TEXT:
            let fs = l.p("fontSize", Editor.time)
            let (cw, ch) = TextRaster.measure(l, Editor.time)
            let lh = max(TextRaster.lineHeight(l, Editor.time), 0.0001)
            return (cw / lh * fs, ch / lh * fs)
        case .SHAPE:
            return (0.8, 0.84)
        case .FLARE:
            return (2, 2)
        case .PARTICLES:
            return (2, 2)
        case .MODEL:
            return (1, 1)
        default:
            return (0.8, 0.84)
        }
    }

    /// Source pixel aspect of a layer's media (1:1 when unknown).
    private static var aspectCache: [String: (Float, Float)] = [:]
    static func contentAspect(_ l: Layer) -> (Float, Float) {
        guard let path = l.imagePath else { return (1, 1) }
        if let c = aspectCache[path] { return c }          // was re-reading the image from disk on every call
        let r = contentAspectRaw(l)
        aspectCache[path] = r
        return r
    }
    private static func contentAspectRaw(_ l: Layer) -> (Float, Float) {
        guard let path = l.imagePath else { return (1, 1) }
        let ext = (path as NSString).pathExtension.lowercased()
        if ["glb", "gltf", "obj", "abc", "vdb"].contains(ext) {
            return (1, 1)
        }
        if let img = UIImage(contentsOfFile: path) {
            return (Float(img.size.width), Float(img.size.height))
        }
        if let (w, h) = VideoFrames.videoSize(path) {
            return (Float(w), Float(h))
        }
        return (1, 1)
    }

    /// 3x3 affine (a..f) of a layer at time `t`, parents included.
    /// Column-major like CGAffineTransform: [a b c d tx ty].
    static func matrix(_ l: Layer, _ t: Float) -> [Float] {
        return chainMatrix(l, t, 0)
    }

    private static func chainMatrix(_ l: Layer, _ t: Float, _ depth: Int, fixPos: Bool = false) -> [Float] {
        guard depth < 16 else { return [1, 0, 0, 1, 0, 0] }
        // while a group is being baked its own transform (and everything above it) is left out:
        // the baked picture lives in the group's local space and the plane is moved live
        if l.id == bakeRoot { return [1, 0, 0, 1, 0, 0] }
        var m = localMatrix(l, t, posT: fixPos ? l.start : nil)
        if l.parentId >= 0, let parent = Editor.scene.layers.first(where: { $0.id == l.parentId }) {
            let lk = lockFlags(l, t)
            let pm = chainMatrix(parent, t, depth + 1, fixPos: lk.move)
            m = (lk.rot || lk.scale) ? mulLocked(pm, m, lk.rot, lk.scale) : mul(pm, m)
        }
        return m
    }

    /// Flags of the layer's Parent Lock effect (all false when the effect is missing or switched off).
    static func lockFlags(_ l: Layer, _ t: Float) -> (rot: Bool, scale: Bool, move: Bool) {
        guard !l.fx.isEmpty,
              l.fx.contains(where: { !l.fxOff.contains($0) && Registry.get($0)?.id == "parentlock" })
        else { return (false, false, false) }
        return (l.p("plRot", t) > 0.5, l.p("plScale", t) > 0.5, l.p("plMove", t) > 0.5)
    }

    private static func lockedLinear(_ p: [Float], _ rot: Bool, _ scl: Bool) -> [Float] {
        var a = p[0], b = p[1], c = p[2], d = p[3]
        if rot {
            let ang = atan2(b, a), cs = cos(-ang), sn = sin(-ang)
            let na = a * cs - b * sn, nb = a * sn + b * cs
            let nc = c * cs - d * sn, nd = c * sn + d * cs
            a = na; b = nb; c = nc; d = nd
        }
        if scl {
            let sx = max(1e-6, (a * a + b * b).squareRoot()), sy = max(1e-6, (c * c + d * d).squareRoot())
            a /= sx; b /= sx; c /= sy; d /= sy
        }
        return [a, b, c, d, 0, 0]
    }

    /// Changes a layer's parent without moving it: its own position / rotation / scale are recomputed so the
    /// picture looks exactly the same afterwards (Parent Lock effect included).
    static func reparentKeepingPose(_ l: Layer, to newId: Int, _ t: Float, autoKey: Bool) {
        let world = matrix(l, t)
        l.parentId = newId
        var loc = world
        if newId >= 0, let par = Editor.scene.layers.first(where: { $0.id == newId }) {
            let pm = chainMatrix(par, t, 0)
            let lk = lockFlags(l, t)
            guard let invP = invert(pm), let invL = invert(lockedLinear(pm, lk.rot, lk.scale)) else { return }
            let lin = mul(invL, [world[0], world[1], world[2], world[3], 0, 0])
            let tr = apply(invP, world[4], world[5])
            loc = [lin[0], lin[1], lin[2], lin[3], tr.0, tr.1]
        }
        func put(_ k: String, _ v: Float) { l.track(k).set(l.editTime(k, t), v, autoKey) }
        let a = loc[0], b = loc[1], c = loc[2], d = loc[3]
        var deg = atan2(b, a) * 180 / Float.pi
        let curRot = l.p("rotZ", l.editTime("rotZ", t))
        deg += 360 * ((curRot - deg) / 360).rounded()
        let sxCur = max(1e-4, abs(l.p("scaleX", l.editTime("scaleX", t))))
        let newSc = (a * a + b * b).squareRoot() / sxCur
        let newSy = (c * c + d * d).squareRoot() / max(1e-4, newSc)
        put("rotZ", deg); put("scale", newSc); put("scaleY", newSy)
        let lm = localMatrix(l, t)
        let x = l.p("x", l.editTime("x", t)), y = l.p("y", l.editTime("y", t))
        put("x", x + (loc[4] - lm[4])); put("y", y + (loc[5] - lm[5]))
    }

    /// Parent helper: like `mul`, but the child's own orientation ignores the parent's rotation and/or scale
    /// while its position still follows the parent (a ferris-wheel cabin orbits the hub and stays upright).
    private static func mulLocked(_ p: [Float], _ m: [Float], _ rot: Bool, _ scl: Bool) -> [Float] {
        var a = p[0], b = p[1], c = p[2], d = p[3]
        if rot {
            let ang = atan2(b, a), cs = cos(-ang), sn = sin(-ang)
            let na = a * cs - b * sn, nb = a * sn + b * cs
            let nc = c * cs - d * sn, nd = c * sn + d * cs
            a = na; b = nb; c = nc; d = nd
        }
        if scl {
            let sx = max(1e-6, (a * a + b * b).squareRoot()), sy = max(1e-6, (c * c + d * d).squareRoot())
            a /= sx; b /= sx; c /= sy; d /= sy
        }
        return [m[0] * a + m[1] * c, m[0] * b + m[1] * d,
                m[2] * a + m[3] * c, m[2] * b + m[3] * d,
                m[4] * p[0] + m[5] * p[2] + p[4], m[4] * p[1] + m[5] * p[3] + p[5]]
    }

    /// Z position including the parent chain: a child's Z is relative to its 3D parent (null / model),
    /// so moving the parent on Z carries the child with it, and moving the child on Z moves only it.
    static func worldZ(_ l: Layer, _ t: Float) -> Float {
        var z = l.p("z", l.editTime("x", t))
        var cur = l
        var depth = 0
        while cur.parentId >= 0, depth < 16,
              let par = Editor.scene.layers.first(where: { $0.id == cur.parentId }) {
            if par.id == bakeRoot { break }
            if par.is3d || par.type == .MODEL { z += par.p("z", par.editTime("x", t)) }
            cur = par; depth += 1
        }
        return z
    }

    /// A world-space movement (dx, dy) expressed in the layer's own position space, i.e. with the
    /// parent chain (null / group scale + rotation) undone — so dragging a linked child moves only
    /// that child, exactly under the finger, instead of being scaled/rotated by its parent.
    static func toParentSpace(_ l: Layer, _ t: Float, _ dx: Float, _ dy: Float) -> (Float, Float) {
        guard l.parentId >= 0, let par = Editor.scene.layers.first(where: { $0.id == l.parentId }) else { return (dx, dy) }
        let pm = matrix(par, t)
        let det = pm[0] * pm[3] - pm[1] * pm[2]
        guard abs(det) > 1e-6 else { return (dx, dy) }
        return ((pm[3] * dx - pm[2] * dy) / det, (-pm[1] * dx + pm[0] * dy) / det)
    }

    /// The layer's own matrix: translate to (x, y), rotate, scale, then
    /// offset by the anchor inside the quad.
    static func localMatrix(_ l: Layer, _ t: Float, posT: Float? = nil) -> [Float] {
        let lt = l.editTime("x", t)
        let pt = posT.map { l.editTime("x", $0) } ?? lt      // posT: position frozen at that time (Lock Movement)
        let x = l.p("x", pt)
        let y = l.p("y", pt)
        let sc = l.p("scale", lt)
        let sx = l.p("scaleX", lt)
        let sy = l.p("scaleY", lt)
        let rz = l.p("rotZ", lt) * Float.pi / 180
        let ax = l.p("anchorX", lt)
        let ay = l.p("anchorY", lt)
        let (qw, qh) = quadSize(l)

        // anchor offset in world units (rotated with the quad)
        let ox = -(ax - 50) / 100 * qw * sc * sx
        let oy = (ay - 50) / 100 * qh * sc * sy
        let c = cos(rz), s = sin(rz)
        let rox = ox * c - oy * s
        let roy = ox * s + oy * c

        // T(x + rox, y + roy) * R(rz) * S(sc*sx, sc*sy)
        let a = c * sc * sx, b = s * sc * sx
        let cc = -s * sc * sy, d = c * sc * sy
        return [a, b, cc, d, x + rox, y + roy]
    }

    /// C * M (row-vector convention like CGAffineTransform concatenation).
    static func mul(_ c: [Float], _ m: [Float]) -> [Float] {
        // CGAffineTransformConcat(child, parent) semantics:
        // result = child applied first, then parent.
        let a = m[0] * c[0] + m[1] * c[2]
        let b = m[0] * c[1] + m[1] * c[3]
        let cc = m[2] * c[0] + m[3] * c[2]
        let d = m[2] * c[1] + m[3] * c[3]
        let tx = m[4] * c[0] + m[5] * c[2] + c[4]
        let ty = m[4] * c[1] + m[5] * c[3] + c[5]
        return [a, b, cc, d, tx, ty]
    }

    /// Applies the matrix to a point.
    static func apply(_ m: [Float], _ x: Float, _ y: Float) -> (Float, Float) {
        (m[0] * x + m[2] * y + m[4], m[1] * x + m[3] * y + m[5])
    }

    /// World-space corners of the layer quad at time t (tl, tr, br, bl).
    static func quadCorners(_ l: Layer, _ t: Float) -> [(Float, Float)] {
        let m = matrix(l, t)
        let (qw, qh) = quadSize(l)
        let hw = qw / 2, hh = qh / 2
        return [apply(m, -hw, hh), apply(m, hw, hh), apply(m, hw, -hh), apply(m, -hw, -hh)]
    }

    /// Hit test in world space.
    static func hit(_ l: Layer, _ x: Float, _ y: Float, _ t: Float) -> Bool {
        let m = matrix(l, t)
        let inv = invert(m)
        guard let inv = inv else { return false }
        let (qw, qh) = quadSize(l)
        let p = apply(inv, x, y)
        return abs(p.0) <= qw / 2 && abs(p.1) <= qh / 2
    }

    static func invert(_ m: [Float]) -> [Float]? {
        let det = m[0] * m[3] - m[1] * m[2]
        if abs(det) < 1e-9 { return nil }
        let id = 1 / det
        return [m[3] * id, -m[1] * id, -m[2] * id, m[0] * id,
                (m[2] * m[5] - m[3] * m[4]) * id, (m[1] * m[4] - m[0] * m[5]) * id]
    }

    /// The camera that drives a 3D layer (nearest camera above it), or nil.
    /// True while a pre-rendered group bakes its flat plane: the scene camera is ignored inside.
    static var bakingPlane = false
    /// Id of the group currently being baked (-1 = none): its transform is treated as identity.
    static var bakeRoot = -1
    /// Draw 3D layers flat (no rotation / camera) — used to tile a layer before it is placed in 3D.
    static var flatDraw = false

    /// A group that is flattened into its own 2D picture (pre-render / pre-comp): like an After Effects
    /// pre-comp it owns its own camera scope.
    static func isFlatScope(_ g: Layer) -> Bool {
        g.type == .GROUP && ((g.prerender && PreRender.enabled) || g.precomp)
    }

    /// Id of the nearest flattened group above `l` (-1 = the main scene).
    static func cameraScope(_ l: Layer) -> Int {
        var cur = l
        var depth = 0
        while cur.parentId >= 0, depth < 16,
              let par = Editor.scene.layers.first(where: { $0.id == cur.parentId }) {
            if isFlatScope(par) { return par.id }
            cur = par; depth += 1
        }
        return -1
    }

    /// The camera that looks at `l`: the nearest visible camera above it in the stack that lives in the
    /// same scope. A camera grouped together with layers drives only that group's content (the group
    /// stays a flat plane for whatever is outside it).
    static func camera(for l: Layer) -> Layer? {
        if flatDraw { return nil }
        if bakingPlane && l.id == bakeRoot { return nil }
        guard let idx = Editor.scene.layers.firstIndex(where: { $0 === l }) else { return nil }
        let scope = cameraScope(l)
        var best: Layer? = nil
        var bestIdx = -1
        for (j, c) in Editor.scene.layers.enumerated() where c.type == .CAMERA && c.visible && j > idx {
            if cameraScope(c) != scope { continue }
            if bestIdx < 0 || j < bestIdx {
                best = c
                bestIdx = j
            }
        }
        return best
    }

    /// Convert canvas-normalized (0..1, 0..1 top-left) to world units.
    static func world(_ nx: Float, _ ny: Float, ar: Float) -> (Float, Float) {
        (nx * 2 * ar - ar, 1 - ny * 2)
    }
}
