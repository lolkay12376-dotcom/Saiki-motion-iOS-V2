// TimelineView.swift — the real timeline (UI), ported 1:1 from the Android
// version's TimelineView.kt (the reference the user shipped on Android).
//
// Timeline with a CENTRED playhead: the playhead is a fixed orange line in
// the middle of the view and time flows under it — dragging anywhere in the
// tracks scrubs (content follows the finger), never the playhead. Top row =
// front-most layer. "^" (the chevron) expands a layer into its keyframe rows
// (or a group into its content), long-press a layer — or drag its right-edge
// handle — then drag up or down to reorder it. Pinch anywhere to zoom.
// Move / trim handles only appear on the SELECTED layer, so an accidental
// drag can never shift a clip you didn't tap first.
//
// Colors, row heights, hit slop, snap distances and the timecode format
// (MM:SS:FF) all match the Android build exactly.

import UIKit
import AVFoundation
import Foundation

// MARK: - host protocols (the editor implements both)

protocol EditHost: AnyObject {
    func selectedLayer() -> Layer?
    func selectedId() -> Int
    func isSelected(_ id: Int) -> Bool
    func onSelect(_ id: Int)
    func beginEdit()
    func onEdited()
    func autoKey() -> Bool
    func puppetPanelOpen() -> Bool
    func moveAnchor(_ l: Layer, _ ax: Float, _ ay: Float)
}

protocol TimelineHost: AnyObject {
    func selectedLayer() -> Layer?
    func autoKey() -> Bool
    func beginEdit()
    func onEdited()
    func onSeek(_ t: Float)
    func onSelect(_ id: Int)
    func onToggleVisible(_ l: Layer)
    func onTimingChanged()
    func onReorder(_ l: Layer, _ listIndex: Int)
    func onKeyTap(_ l: Layer, _ key: String, _ idx: Int)
}

// MARK: - the view

final class TimelineView: UIView {

    private weak var editHost: EditHost?
    private weak var tlHost: TimelineHost?

    // Android used density-multiplied px; UIKit works in points, so d = 1.
    private let d: CGFloat = 1
    private var pxPerSec: CGFloat = 80
    private var scrollY: CGFloat = 0
    private let rulerH: CGFloat = 40
    private let rowH: CGFloat = 40
    private let paramH: CGFloat = 28
    private let leftCol: CGFloat = 84
    private var openIds = Set<Int>()

    // Android palette (Ui.kt + TimelineView.kt), kept identical on purpose:
    // the playhead "green" on Android is this orange.
    private static let A_BG     = Int32(bitPattern: 0xFF0E0E10)
    private static let A_GREEN  = Int32(bitPattern: 0xFFFF8A1F)   // playhead / accents
    private static let A_AMBER  = Int32(bitPattern: 0xFFF5B301)
    private static let A_BLUE   = Int32(bitPattern: 0xFF38BDF8)
    private static let A_TEXT   = Int32(bitPattern: 0xFFFFFFFF)
    private static let A_DIM    = Int32(bitPattern: 0xFF8C8C96)
    private static let A_CACHE  = Int32(bitPattern: 0xFF34D27B)   // cached-frames bar (like After Effects)
    private static let A_TICK   = Int32(bitPattern: 0xFF55555E)
    private static let A_PILLTX = Int32(bitPattern: 0xFF2B1400)   // text on the playhead pill
    private static let A_EYE_OFF  = Int32(bitPattern: 0xFF666670)
    private static let A_CHEV_CLS = Int32(bitPattern: 0xFF777782)
    private static let A_GRPHDR = Int32(bitPattern: 0xFF14141A)   // keyframe group header row
    private static let A_KEYROW = Int32(bitPattern: 0xFF101015)   // keyframe row
    private static let A_KEYLBL = Int32(bitPattern: 0xCC0E0E10)   // keyframe label strip
    private static let A_DRAGBG = Int32(bitPattern: 0x66000000)   // reorder drop overlay
    private static let A_THMVOV = Int32(bitPattern: 0x77000000)   // thumbnail scrim
    private static let A_FXSTRIP = Int32(bitPattern: 0x33FFFFFF)
    private static let A_AUDWAV = Int32(bitPattern: 0xAAFFFFFF)
    private static let A_ARROW  = Int32(bitPattern: 0xFF222222)

    /// Clip pill fill per layer type (Android TimelineView.drawRow).
    private static func tlFill(_ t: LayerType) -> Int32 {
        switch t {
        case .SHAPE:     return Int32(bitPattern: 0xFF2F6BFF)
        case .TEXT:      return Int32(bitPattern: 0xFFD9822B)
        case .IMAGE:     return Int32(bitPattern: 0xFF1FA67A)
        case .VIDEO:     return Int32(bitPattern: 0xFF8B5CF6)
        case .CAMERA:    return Int32(bitPattern: 0xFF6B7280)
        case .NULL:      return Int32(bitPattern: 0xFF9CA3AF)
        case .MODEL:     return Int32(bitPattern: 0xFFEC4899)
        case .PARTICLES: return Int32(bitPattern: 0xFFCA8A04)
        case .GROUP:     return Int32(bitPattern: 0xFF4B4B55)
        case .ADJUST:    return Int32(bitPattern: 0xFF0EA5E9)
        case .AUDIO:     return Int32(bitPattern: 0xFF64748B)
        case .FLARE:     return Int32(bitPattern: 0xFFF59E0B)
        }
    }

    // MARK: rows

    private final class TRow {
        let kind: Int            // 0 layer, 1 keyframe-group header, 2 keyframe row, 3 note row
        let layer: Layer
        let depth: Int
        let label: String
        let key: String
        var top: CGFloat = 0
        var h: CGFloat = 0
        init(_ kind: Int, _ layer: Layer, _ depth: Int, _ label: String = "", _ key: String = "") {
            self.kind = kind; self.layer = layer; self.depth = depth
            self.label = label; self.key = key
        }
    }
    private var trows: [TRow] = []
    private var totalH: CGFloat = 0

    // MARK: gesture state

    private var mode = 0          // 0 none, 1 scrub, 2 pending tap, 3 trim start, 4 trim end,
                                  // 5 move bar, 6 vscroll, 7 reorder, 8 keyframe drag
    private var downX: CGFloat = 0
    private var downY: CGFloat = 0
    private var lastX: CGFloat = 0
    private var lastY: CGFloat = 0
    private var moved = false
    private var tapLayer: Layer? = nil
    private var tapEye: Layer? = nil
    private var tapChev: Layer? = nil
    private var tapKey: (Layer, String, Int)? = nil
    private var dragLayer: Layer? = nil
    private var dragY: CGFloat = 0
    private var dragKey: Key? = nil
    private var dragTrack: Track? = nil
    private var keyBegun = false
    private var dragGrab: CGFloat = 0
    private var offCur: [Int: CGFloat] = [:]
    private var offTgt: [Int: CGFloat] = [:]

    private var longPress: Timer? = nil
    private var pinchDist: CGFloat? = nil       // span of the tracked 2-finger pinch
    private var haptic = UIImpactFeedbackGenerator(style: .medium)
    private var settleLink: CADisplayLink? = nil

    /// CADisplayLink retains its target; this proxy keeps the link from
    /// retaining the view itself (the editor is rebuilt on every project
    /// open, so a strong link would leak one view per open).
    private final class WeakProxy: NSObject {
        weak var target: TimelineView?
        @objc func tick(_ link: CADisplayLink) { target?.settleTick() }
    }
    private var settleProxy: WeakProxy? = nil

    init(_ edit: EditHost, _ timeline: TimelineHost) {
        super.init(frame: .zero)
        editHost = edit
        tlHost = timeline
        backgroundColor = argbToUIColor(TimelineView.A_BG)
        contentMode = .redraw
        isMultipleTouchEnabled = true
        isOpaque = true
        let proxy = WeakProxy()
        proxy.target = self
        settleProxy = proxy
        let link = CADisplayLink(target: proxy, selector: #selector(WeakProxy.tick(_:)))
        link.add(to: .main, forMode: .common)
        link.isPaused = true
        settleLink = link
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    deinit {
        longPress?.invalidate()
        settleLink?.invalidate()
    }

    // MARK: - public surface

    func timecode(_ t: Float) -> String {
        let fps = max(1, Editor.project.fps)
        let total = Int((t * Float(fps)).rounded())
        return String(format: "%02d:%02d:%02d", total / fps / 60, (total / fps) % 60, total % fps)
    }

    func fitToScene() {
        let usable = bounds.width - leftCol - 24 * d
        if usable > 0, Editor.scene.duration > 0.01 {
            pxPerSec = clamp(usable / CGFloat(Editor.scene.duration), 10 * d, 900 * d)
        }
        setNeedsDisplay()
    }

    /// Opens every layer and group, or closes them all if everything is already open.
    func expandAll() {
        let ls = Editor.scene.layers
        if ls.contains(where: { !openIds.contains($0.id) }) {
            openIds.formUnion(ls.map { $0.id })
        } else {
            openIds.removeAll()
        }
        setNeedsDisplay()
    }

    // MARK: - geometry

    private func cx() -> CGFloat { bounds.width / 2 }
    private func tx(_ t: Float) -> CGFloat { cx() + (CGFloat(t) - CGFloat(Editor.time)) * pxPerSec }
    private func xt(_ x: CGFloat) -> Float { Editor.time + Float((x - cx()) / max(pxPerSec, 0.001)) }

    // MARK: - thumbnails

    private var thumbs: [Int: UIImage] = [:]      // main-thread only
    private var loading = Set<Int>()              // main-thread only

    private func thumb(_ l: Layer) -> UIImage? {
        if l.type != .IMAGE && l.type != .VIDEO { return nil }
        if let t = thumbs[l.id] { return t }
        guard let p = l.imagePath else { return nil }
        if loading.contains(l.id) { return nil }
        loading.insert(l.id)
        let isImage = l.type == .IMAGE
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            var img: UIImage? = nil
            if isImage {
                if let full = UIImage(contentsOfFile: p) {
                    let h = max(full.size.height, 1)
                    let scale = min(1, 160 / h)
                    if scale < 1 {
                        let sz = CGSize(width: max(1, full.size.width * scale), height: max(1, h * scale))
                        let fmt = UIGraphicsImageRendererFormat()
                        fmt.scale = 1
                        img = UIGraphicsImageRenderer(size: sz, format: fmt).image { _ in
                            full.draw(in: CGRect(origin: .zero, size: sz))
                        }
                    } else {
                        img = full
                    }
                }
            } else {
                let asset = AVURLAsset(url: URL(fileURLWithPath: p))
                let gen = AVAssetImageGenerator(asset: asset)
                gen.appliesPreferredTrackTransform = true
                gen.maximumSize = CGSize(width: 100000, height: 80)
                if let cg = try? gen.copyCGImage(at: CMTime.zero, actualTime: nil) {
                    img = UIImage(cgImage: cg)
                }
            }
            DispatchQueue.main.async { [weak self] in
                guard let self = self else { return }
                self.loading.remove(l.id)
                if let img = img {
                    self.thumbs[l.id] = img
                    self.setNeedsDisplay()
                }
            }
        }
        return nil
    }

    // MARK: - row building

    private func puppetLabel(_ l: Layer, _ k: String) -> String {
        guard k.hasPrefix("pp"), let pp = l.puppet, let ax = k.last else { return k }
        let id = Int(k.dropFirst(2).dropLast()) ?? 0
        return "Pin \(pp.number(id)) " + (ax == "x" ? "X" : "Y")
    }

    private func groupOf(_ l: Layer, _ k: String) -> String {
        if Defs.transform.contains(where: { $0.key == k })
            || Defs.pos3d.contains(where: { $0.key == k })
            || Defs.rot3d.contains(where: { $0.key == k }) { return "Transform" }
        if k == "camFov" { return "Camera" }
        if k.hasPrefix("pp"), l.puppet != nil { return "Puppet" }
        for id in l.fx {
            if let e = Registry.get(id), e.props.contains(where: { l.pkey(id, $0) == k }) {
                return id.contains("~") ? e.name + " " + (id.components(separatedBy: "~").last ?? "") : e.name
            }
        }
        return "Other"
    }

    private func build() {
        trows.removeAll()
        let ls = Editor.scene.layers

        func emit(_ l: Layer, _ depth: Int) {
            trows.append(TRow(0, l, depth))
            if !openIds.contains(l.id) || depth > 4 { return }
            if l.type == .GROUP {
                for c in ls.reversed() where c.parentId == l.id { emit(c, depth + 1) }
            } else {
                var groups: [String: [String]] = [:]
                var order: [String] = []
                for (k, tr) in l.props where !tr.keys.isEmpty {
                    let g = groupOf(l, k)
                    if groups[g] == nil { groups[g] = []; order.append(g) }
                    groups[g]!.append(k)
                }
                if groups.isEmpty {
                    trows.append(TRow(3, l, depth + 1, "No keyframes yet"))
                }
                for g in order {
                    trows.append(TRow(1, l, depth + 1, g))
                    for k in groups[g]! {
                        trows.append(TRow(2, l, depth + 2, Registry.propDef(k)?.label ?? puppetLabel(l, k), k))
                    }
                }
            }
        }

        for l in ls.reversed() {
            let par = ls.first { $0.id == l.parentId }
            if par == nil || par!.type != .GROUP { emit(l, 0) }
        }
        var y: CGFloat = 0
        for row in trows {
            row.top = y
            row.h = row.kind == 0 ? rowH : paramH
            y += row.h
        }
        totalH = y
    }

    /// Start and end shown for a layer; groups span their children.
    private func extent(_ l: Layer) -> (Float, Float) {
        if l.type != .GROUP { return (l.start, l.end) }
        let kids = Editor.scene.layers.filter { $0.parentId == l.id }
        if kids.isEmpty { return (0, Editor.scene.duration) }
        return (kids.map { $0.start }.min() ?? 0, kids.map { $0.end }.max() ?? 0)
    }

    private func fitDuration() {
        let mx = Editor.scene.layers.filter { $0.type != .GROUP }.map { $0.end }.max() ?? 0
        if mx > Editor.scene.duration + 0.001 { Editor.scene.duration = min(mx, 600) }
    }

    private func rowFor(_ l: Layer) -> TRow? {
        trows.first { $0.kind == 0 && $0.layer === l }
    }

    private func rowAt(_ y: CGFloat) -> TRow? {
        if y < rulerH { return nil }
        for row in trows {
            let t = rulerH + row.top - scrollY
            if y >= t && y < t + row.h { return row }
        }
        return nil
    }

    /// True for the top layer of a group that has its mask turned on.
    private func isMaskLayer(_ l: Layer) -> Bool {
        guard let g = Editor.scene.layers.first(where: { $0.id == l.parentId }) else { return false }
        if g.type != .GROUP || g.mask == 0 { return false }
        return Editor.scene.layers.last { $0.parentId == g.id }?.id == l.id
    }

    private func siblings(_ l: Layer) -> [TRow] {
        trows.filter { $0.kind == 0 && $0.layer.parentId == l.parentId }
    }

    // MARK: - drawing

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        draw0(c)
    }

    private func draw0(_ c: CGContext) {
        let w = bounds.width
        let h = bounds.height
        let scene = Editor.scene
        build()
        fillRect(c, CGRect(x: 0, y: 0, width: w, height: h), TimelineView.A_BG)

        // ruler
        let steps: [CGFloat] = [0.1, 0.2, 0.5, 1, 2, 5, 10, 30, 60]
        var step: CGFloat = 60
        for s in steps where s * pxPerSec >= 88 * d { step = s; break }
        var t = Float((xt(0) / Float(step)).rounded(.down)) * Float(step)
        let t1 = xt(w)
        while t <= t1 {
            if t >= -0.0001 {
                let x = tx(t)
                strokeLine(c, x, rulerH - 14 * d, x, rulerH, 1 * d, TimelineView.A_TICK)
                let label = step >= 1 ? String(format: "%d", Int(t.rounded())) : String(format: "%.1f", t)
                drawText(label, x, rulerH - 18 * d, color: TimelineView.A_DIM, size: 11 * d, align: .center)
            }
            for k in 1..<5 {
                let mt = t + Float(step) * Float(k) / 5
                if mt >= 0 && step * pxPerSec / 5 > 14 * d {
                    strokeLine(c, tx(mt), rulerH - 6 * d, tx(mt), rulerH, 1 * d, TimelineView.A_TICK)
                }
            }
            t += Float(step)
        }
        strokeLine(c, max(tx(0), 0), 1.5 * d, min(tx(scene.duration), w), 1.5 * d, 3 * d, TimelineView.A_GREEN)
        if FrameCache.enabled {
            for (a, b) in FrameCache.cachedRuns() {
                let x0 = max(tx(a), 0), x1 = min(tx(min(b, scene.duration)), w)
                if x1 > x0 { strokeLine(c, x0, 5.5 * d, x1, 5.5 * d, 3 * d, TimelineView.A_CACHE) }
            }
        }
        for m in scene.markers {
            let x = tx(m)
            fillTri(c, CGPoint(x: x - 6 * d, y: rulerH - 12 * d),
                    CGPoint(x: x + 6 * d, y: rulerH - 12 * d),
                    CGPoint(x: x, y: rulerH), TimelineView.A_BLUE)
            strokeLine(c, x, rulerH, x, h, 1 * d, TimelineView.A_TICK)
            if let mnm = scene.markerName(m) {
                drawText(mnm, x + 8 * d, rulerH - 14 * d, color: TimelineView.A_BLUE,
                         size: 10 * d, bold: true)
            }
        }

        // rows
        advanceOffsets()
        c.saveGState()
        c.clip(to: CGRect(x: 0, y: rulerH, width: w, height: h - rulerH))
        let sel = editHost?.selectedId() ?? -1
        for row in trows {
            if row.layer === dragLayer && row.kind == 0 { continue }
            var top = rulerH + row.top - scrollY
            if row.kind == 0 { top += offCur[row.layer.id] ?? 0 }
            if top > h || top + row.h < rulerH { continue }
            drawRow(c, row, top, sel)
        }
        if let dl = dragLayer, let row = rowFor(dl) {
            let top = clamp(dragY - dragGrab, rulerH, h - rowH)
            fillRect(c, CGRect(x: 0, y: top - 2 * d, width: w, height: rowH + 4 * d), TimelineView.A_DRAGBG)
            drawRow(c, row, top, sel)
        }
        c.restoreGState()

        // playhead: fixed at the horizontal centre
        let px = cx()
        strokeLine(c, px, 0, px, h, 2 * d, TimelineView.A_GREEN)
        let tc = timecode(Editor.time)
        let bw = measureText(tc, 12 * d, true) + 18 * d
        fillRoundRect(c, CGRect(x: px - bw / 2, y: 4 * d, width: bw, height: 20 * d),
                      10 * d, TimelineView.A_GREEN)
        drawText(tc, px, 19 * d, color: TimelineView.A_PILLTX, size: 12 * d, bold: true, align: .center)
    }

    private func drawRow(_ c: CGContext, _ row: TRow, _ top: CGFloat, _ sel: Int) {
        let w = bounds.width
        let l = row.layer
        let indent = CGFloat(row.depth) * 10 * d
        let multiSel = editHost?.isSelected(l.id) ?? false

        if row.kind == 0 {
            var s0 = l.start
            var e0 = l.end
            if l.type == .GROUP {
                let kids = Editor.scene.layers.filter { $0.parentId == l.id }
                if !kids.isEmpty {
                    s0 = kids.map { $0.start }.min() ?? 0
                    e0 = kids.map { $0.end }.max() ?? 0
                } else {
                    s0 = 0
                    e0 = Editor.scene.duration
                }
            }
            let x0 = tx(s0)
            let x1 = tx(e0)
            let r = CGRect(x: x0, y: top + 4 * d, width: x1 - x0, height: rowH - 8 * d)
            let base = TimelineView.tlFill(l.type)
            let body = l.visible ? argbToUIColor(base)
                                 : argbToUIColor(base).withAlphaComponent(90.0 / 255.0)
            c.setFillColor(body.cgColor)
            c.addPath(CGPath(roundedRect: r, cornerWidth: 7 * d, cornerHeight: 7 * d, transform: nil))
            c.fillPath()

            if let tb = thumb(l), l.visible {
                c.saveGState()
                c.clip(to: r)
                if let cg = tb.cgImage {
                    let th = r.height
                    let tw = max(1, th * CGFloat(cg.width) / max(CGFloat(cg.height), 1))
                    var x = max(r.minX, 0)
                    let endX = min(r.maxX, w)
                    while x < endX {
                        tb.draw(in: CGRect(x: x, y: r.minY, width: tw, height: th))
                        x += tw
                    }
                }
                c.restoreGState()
                fillRoundRect(c, r, 7 * d, TimelineView.A_THMVOV)
            }
            if l.type == .AUDIO {
                let origin = tx(l.start)
                var x = max(r.minX, leftCol)
                let ex = min(r.maxX, w)
                let mid = r.midY
                let pk = l.imagePath.flatMap { Waveform.peaks($0) { [weak self] in self?.setNeedsDisplay() } }
                let dur = max(l.srcDur, 0.01)
                while x < ex {
                    var amp: Float = 0.05
                    if let pk = pk, !pk.isEmpty {
                        // time in the source file under this pixel column
                        let t0 = (Float(x - origin) / Float(tx(l.start + 1) - origin)) + l.srcOffset
                        let t1 = t0 + 3 * Float(d) / Float(tx(l.start + 1) - origin)
                        let i0 = max(0, min(pk.count - 1, Int(t0 / dur * Float(pk.count))))
                        let i1 = max(i0, min(pk.count - 1, Int(t1 / dur * Float(pk.count))))
                        for i in i0...i1 { amp = max(amp, pk[i]) }
                    }
                    let hh = amp * Float(r.height) * 0.45
                    strokeLine(c, x, mid - CGFloat(hh), x, mid + CGFloat(hh), 1.5 * d, TimelineView.A_AUDWAV)
                    x += 3 * d
                }
            }
            if !l.fx.isEmpty {
                fillRect(c, CGRect(x: r.minX + 6 * d, y: r.maxY - 6 * d,
                                   width: r.maxX - r.minX - 12 * d, height: 3 * d),
                         TimelineView.A_FXSTRIP)
            }
            if l.type != .GROUP {
                var seen = Set<Int>()
                for (_, tr) in l.props {
                    for k in tr.keys {
                        let kx = tx(k.t)
                        if kx < x0 || kx > x1 { continue }
                        let key100 = Int((k.t * 100).rounded())
                        if !seen.insert(key100).inserted { continue }
                        diamond(c, kx, r.midY, 4.5 * d, TimelineView.A_TEXT)
                    }
                }
            }
            // name inside the pill
            c.saveGState()
            c.clip(to: CGRect(x: max(r.minX + 8 * d, leftCol), y: r.minY,
                              width: max(0, r.maxX - 8 * d - max(r.minX + 8 * d, leftCol)),
                              height: r.height))
            let maskTag = isMaskLayer(l) ? "ask] " : ""
            let durTag = String(format: "%.1fs", l.end - l.start)
            let fxTag = l.fx.isEmpty ? "" : "  fx\(l.fx.count)"
            let nameStr = l.type == .GROUP
                ? l.name + (l.mask != 0 ? "  (mask" + (l.mask == 2 || l.mask == 4 ? ", inverted" : "") + ")" : "")
                : maskTag + l.name + "  " + durTag + fxTag
            drawText(nameStr, max(r.minX, leftCol) + 8 * d + indent, top + rowH / 2 + 4 * d,
                     color: TimelineView.A_TEXT, size: 11 * d, bold: true)
            c.restoreGState()

            if l.id == sel && l.type != .GROUP {
                strokeRoundRect(c, r, 7 * d, 2 * d, TimelineView.A_TEXT)
                for side in 0...1 {
                    let hx = side == 0 ? r.minX : r.maxX
                    let hr = CGRect(x: hx - 9 * d, y: r.minY - 1 * d, width: 18 * d, height: r.height + 2 * d)
                    fillRoundRect(c, hr, 6 * d, TimelineView.A_TEXT)
                    let cy = r.midY
                    let dir: CGFloat = side == 0 ? -1 : 1
                    fillTri(c, CGPoint(x: hx + dir * 3 * d, y: cy - 4 * d),
                            CGPoint(x: hx + dir * 3 * d, y: cy + 4 * d),
                            CGPoint(x: hx - dir * 2 * d, y: cy), TimelineView.A_ARROW)
                }
            } else if multiSel {
                strokeRoundRect(c, r, 7 * d, 2 * d, TimelineView.A_TEXT)
            }

            // left column (drawn over the track)
            fillRect(c, CGRect(x: 0, y: top, width: leftCol, height: rowH), TimelineView.A_BG)
            let cy = top + rowH / 2
            Icons.draw(c, l.visible ? "eye" : "eye_off", leftCol * 0.27, cy, 19 * d,
                       l.visible ? TimelineView.A_TEXT : TimelineView.A_EYE_OFF)
            Icons.draw(c, "chev_up", leftCol * 0.74, cy, 19 * d,
                       openIds.contains(l.id) ? TimelineView.A_AMBER : TimelineView.A_CHEV_CLS)
            // right drag handle column
            fillRect(c, CGRect(x: w - 30 * d, y: top, width: 30 * d, height: rowH), TimelineView.A_BG)
            Icons.draw(c, "handle", w - 16 * d, cy, 16 * d, TimelineView.A_DIM)
        } else if row.kind == 1 {
            fillRect(c, CGRect(x: 0, y: top, width: w, height: row.h), TimelineView.A_GRPHDR)
            drawText(row.label, leftCol + 8 * d + indent, top + row.h / 2 + 4 * d,
                     color: TimelineView.A_GREEN, size: 11 * d, bold: true)
        } else if row.kind == 2 {
            fillRect(c, CGRect(x: 0, y: top, width: w, height: row.h), TimelineView.A_KEYROW)
            if let tr = l.props[row.key] {
                for k in tr.keys {
                    let on = abs(k.t - Editor.time) < 0.03
                    diamond(c, tx(k.t), top + row.h / 2, 5 * d,
                            on ? TimelineView.A_GREEN : TimelineView.A_TEXT)
                }
            }
            fillRect(c, CGRect(x: leftCol, y: top, width: 150 * d, height: row.h), TimelineView.A_KEYLBL)
            drawText(row.label, leftCol + 8 * d + indent, top + row.h / 2 + 4 * d,
                     color: TimelineView.A_DIM, size: 11 * d)
        } else {
            drawText(row.label, leftCol + 8 * d + indent, top + row.h / 2 + 4 * d,
                     color: TimelineView.A_DIM, size: 11 * d)
        }
    }

    private func diamond(_ c: CGContext, _ x: CGFloat, _ y: CGFloat, _ s: CGFloat, _ col: Int32) {
        fillTri(c, CGPoint(x: x, y: y - s), CGPoint(x: x + s, y: y),
                CGPoint(x: x, y: y + s), col)
        fillTri(c, CGPoint(x: x, y: y + s), CGPoint(x: x - s, y: y),
                CGPoint(x: x, y: y - s), col)
    }

    private func fillTri(_ c: CGContext, _ a: CGPoint, _ b: CGPoint, _ p: CGPoint, _ col: Int32) {
        let path = CGMutablePath()
        path.move(to: a)
        path.addLine(to: b)
        path.addLine(to: p)
        path.closeSubpath()
        c.addPath(path)
        c.setFillColor(argbToUIColor(col).cgColor)
        c.fillPath()
    }

    /// Drags a keyframe along the timeline; snaps to beat markers and frames.
    private func moveKey(_ x: CGFloat) {
        guard let k = dragKey, let tr = dragTrack else { return }
        let fps = Float(max(1, Editor.project.fps))
        var t = xt(x)
        if let m = Editor.scene.markers.min(by: { abs($0 - t) < abs($1 - t) }),
           abs(m - t) < Float(8 * d / pxPerSec) {
            t = m
        } else {
            t = (t * fps).rounded() / fps
        }
        t = clamp(t, 0, Editor.scene.duration)
        if tr.keys.contains(where: { $0 !== k && abs($0.t - t) < 0.5 / fps }) { return }
        k.t = t
        tr.keys.sort { $0.t < $1.t }
        tlHost?.onTimingChanged()
        setNeedsDisplay()
    }

    /// Smoothly slides the rows that the dragged layer passes over.
    private func advanceOffsets() {
        offTgt.removeAll()
        if let dl = dragLayer {
            let sib = siblings(dl)
            let src = sib.firstIndex { $0.layer === dl } ?? 0
            let tgt = targetIndex(sib)
            for (i, s) in sib.enumerated() where s.layer !== dl {
                if tgt < src && i >= tgt && i < src {
                    offTgt[s.layer.id] = rowH
                } else if tgt > src && i > src && i <= tgt {
                    offTgt[s.layer.id] = -rowH
                } else {
                    offTgt[s.layer.id] = 0
                }
            }
        }
        var busy = false
        var ids = Set(offCur.keys)
        ids.formUnion(offTgt.keys)
        for id in ids {
            let cur = offCur[id] ?? 0
            let tg = offTgt[id] ?? 0
            let nv = cur + (tg - cur) * 0.32
            if abs(tg - nv) < 0.5 {
                if tg == 0 { offCur.removeValue(forKey: id) } else { offCur[id] = tg }
            } else {
                offCur[id] = nv
                busy = true
            }
        }
        settleLink?.isPaused = !(busy || dragLayer != nil)
    }

    @objc private func settleTick() {
        setNeedsDisplay()
    }

    private func targetIndex(_ sib: [TRow]) -> Int {
        guard dragLayer != nil else { return 0 }
        let center = dragY - dragGrab + rowH / 2
        var best = sib.firstIndex { $0.layer === dragLayer } ?? 0
        var bd = CGFloat.greatestFiniteMagnitude
        for (i, s) in sib.enumerated() {
            let cc = rulerH + s.top - scrollY + rowH / 2
            let dd = abs(cc - center)
            if dd < bd { bd = dd; best = i }
        }
        return best
    }

    // MARK: - long press

    private func scheduleLongPress() {
        cancelLongPress()
        let lp = Timer(timeInterval: 0.42, target: self, selector: #selector(longPressFired),
                       userInfo: nil, repeats: false)
        RunLoop.main.add(lp, forMode: .common)
        longPress = lp
    }

    private func cancelLongPress() {
        longPress?.invalidate()
        longPress = nil
    }

    @objc private func longPressFired() {
        longPress = nil
        guard let l = tapLayer else { return }
        if mode == 2 || mode == 5 || mode == 3 || mode == 4 {
            dragLayer = l
            mode = 7
            openIds.remove(l.id)
            haptic.impactOccurred()
            let row = rowFor(l)
            dragGrab = row != nil ? downY - (rulerH + row!.top - scrollY) : rowH / 2
            dragY = downY
            setNeedsDisplay()
        }
    }

    // MARK: - touches

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        let p = t.location(in: self)

        if touches.count > 1 || (event?.allTouches?.count ?? 1) > 1 {
            // second finger landed: pinch takes over
            cancelLongPress()
            if mode != 7 { mode = 0 }
            pinchDist = nil
            return
        }

        downX = p.x; downY = p.y; lastX = p.x; lastY = p.y; moved = false
        tapLayer = nil; tapEye = nil; tapChev = nil; tapKey = nil
        pinchDist = nil
        disallowParentScrollInterception(self, true)
        let row = rowAt(p.y)
        mode = 1
        if let row = row, row.kind == 0 {
            let l = row.layer
            if p.x > bounds.width - 30 * d {
                dragLayer = l
                mode = 7
                openIds.remove(l.id)
                dragGrab = downY - (rulerH + row.top - scrollY)
                dragY = downY
                haptic.impactOccurred()
            } else if p.x < leftCol * 0.5 {
                tapEye = l
                mode = 0
            } else if p.x < leftCol {
                tapChev = l
                mode = 0
            } else {
                let (e0, e1) = extent(l)
                let x0 = tx(e0)
                let x1 = tx(e1)
                let hit: CGFloat = 22 * d
                let isSel = l.id == (editHost?.selectedId() ?? -1) && l.type != .GROUP
                if isSel && abs(p.x - x0) < hit {
                    tlHost?.beginEdit(); mode = 3
                } else if isSel && abs(p.x - x1) < hit {
                    tlHost?.beginEdit(); mode = 4
                } else if l.id == (editHost?.selectedId() ?? -1) && p.x >= x0 && p.x <= x1 {
                    tlHost?.beginEdit(); mode = 5
                } else {
                    mode = 2
                }
                tapLayer = l
                scheduleLongPress()
            }
        } else if let row = row, row.kind == 2 {
            if let tr = row.layer.props[row.key] {
                var hitIdx = -1
                for (i, k) in tr.keys.enumerated() where abs(p.x - tx(k.t)) < 20 * d { hitIdx = i }
                tapLayer = row.layer
                mode = 2
                if hitIdx >= 0 {
                    tapKey = (row.layer, row.key, hitIdx)
                    dragKey = tr.keys[hitIdx]
                    dragTrack = tr
                    mode = 8
                }
            } else {
                tapLayer = row.layer
                mode = 2
            }
        } else if p.y > rulerH {
            tapLayer = row?.layer
            mode = 2
        }
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        let p = t.location(in: self)
        let all = event?.allTouches ?? []
        let live = all.filter { $0.phase == .moved || $0.phase == .began || $0.phase == .stationary }

        // ---- manual two-finger pinch (Android ScaleGestureDetector)
        if live.count > 1 {
            cancelLongPress()
            if mode != 7 { mode = 0 }
            let pair = live.sorted { $0.hashValue < $1.hashValue }
            let a = pair[0].location(in: self)
            let b = pair[1].location(in: self)
            let dist = hypot(a.x - b.x, a.y - b.y)
            if let prev = pinchDist, prev > 1 {
                pxPerSec = clamp(pxPerSec * dist / prev, 10 * d, 900 * d)
                setNeedsDisplay()
            }
            pinchDist = dist
            lastX = a.x; lastY = a.y
            return
        }
        if pinchDist != nil { pinchDist = nil; lastX = p.x; lastY = p.y }

        let dx = p.x - lastX
        let dy = p.y - lastY
        if abs(p.x - downX) > 8 * d || abs(p.y - downY) > 8 * d {
            moved = true
            if mode != 7 { cancelLongPress() }
        }

        switch mode {
        case 7:
            dragY = p.y
            setNeedsDisplay()
        case 8:
            if moved {
                if !keyBegun { tlHost?.beginEdit(); keyBegun = true }
                moveKey(p.x)
            }
        case 1, 2:
            if (mode == 2 || mode == 1) && moved && abs(p.y - downY) > abs(p.x - downX) * 1.2
                && totalH > bounds.height - rulerH - 1 {
                mode = 6
            } else if moved {
                mode = 1
                tlHost?.onSeek(clamp(Editor.time - Float(dx / pxPerSec), 0, Editor.scene.duration))
            }
        case 6:
            scrollY = clamp(scrollY - dy, 0, max(0, totalH + 8 * d - (bounds.height - rulerH)))
            setNeedsDisplay()
        case 3, 4, 5:
            let layers = Editor.scene.layers
            if let l = layers.first(where: { $0.id == (editHost?.selectedId() ?? -1) }), moved {
                let fps = Float(max(1, Editor.project.fps))
                if mode == 3 {
                    let ns = clamp((xt(p.x) * fps).rounded() / fps, 0, max(0, l.end - 0.1))
                    if l.type == .VIDEO || l.type == .AUDIO { l.srcOffset += ns - l.start }
                    l.start = ns
                } else if mode == 4 {
                    var ne = max((xt(p.x) * fps).rounded() / fps, l.start + 0.1)
                    if (l.type == .VIDEO || l.type == .AUDIO) && l.srcDur > 0 {
                        ne = min(ne, l.start + l.srcDur - l.srcOffset)
                    }
                    l.end = max(ne, l.start + 0.1)
                    fitDuration()
                } else {
                    if l.type == .GROUP {
                        let kids = layers.filter { $0.parentId == l.id }
                        if !kids.isEmpty {
                            let lo = -(kids.map { $0.start }.min() ?? 0)
                            let dt = max(Float(dx / pxPerSec), lo)
                            for k in kids { k.start += dt; k.end += dt; k.shiftKeys(dt) }
                            fitDuration()
                        }
                    } else {
                        let len = l.end - l.start
                        let ns = max(l.start + Float(dx / pxPerSec), 0)
                        l.shiftKeys(ns - l.start)
                        l.start = ns
                        l.end = ns + len
                        fitDuration()
                    }
                }
                tlHost?.onTimingChanged()
                setNeedsDisplay()
            }
        default:
            break
        }
        lastX = p.x; lastY = p.y
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        let remaining = (event?.allTouches ?? []).filter { $0.phase != .ended && $0.phase != .cancelled }
        if remaining.count >= 2 {
            pinchDist = nil
            return
        }
        if remaining.count == 1 {
            // a pinch just lost one finger: the rest of the gesture is dead,
            // exactly like the Android early-return on pointerCount > 1
            pinchDist = nil
            if let rp = remaining.first?.location(in: self) { lastX = rp.x; lastY = rp.y }
            return
        }

        cancelLongPress()
        disallowParentScrollInterception(self, false)
        let layers = Editor.scene.layers
        if mode == 7 {
            if let dl = dragLayer {
                let sib = siblings(dl)
                let ti = targetIndex(sib)
                if let tl = sib.indices.contains(ti) ? sib[ti].layer : nil, tl !== dl {
                    let listIdx = layers.firstIndex { $0 === tl } ?? 0
                    tlHost?.onReorder(dl, listIdx)
                }
            }
            dragLayer = nil
            offCur.removeAll()
            offTgt.removeAll()
            settleLink?.isPaused = true
            setNeedsDisplay()
        } else if !moved {
            let eye = tapEye
            let chev = tapChev
            let key = tapKey
            let tl = tapLayer
            if let eye = eye {
                tlHost?.onToggleVisible(eye)
            } else if let chev = chev {
                if openIds.remove(chev.id) == nil { openIds.insert(chev.id) }
                setNeedsDisplay()
            } else if let key = key {
                tlHost?.onKeyTap(key.0, key.1, key.2)
            } else if let tl = tl {
                tlHost?.onSelect(tl.id)
            } else if mode == 2 {
                tlHost?.onSelect(-1)
            }
        }
        dragKey = nil; dragTrack = nil; keyBegun = false
        mode = 0
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        cancelLongPress()
        disallowParentScrollInterception(self, false)
        dragLayer = nil
        offCur.removeAll()
        offTgt.removeAll()
        settleLink?.isPaused = true
        pinchDist = nil
        mode = 0
    }
}
